from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import re, hashlib, json

C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Qin_curvature_rank_review_20261009')
old=Path('/workspace/book-completion-drafts/NA-maximal-extension-staging-v2-20261009/manuscript/book.log')
new=C/'book_compiled_staged_v3/book.log'
out=C/'book_underfull_delta_v3_20261009.json'
assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def blocks(t):
    rows=t.splitlines()
    ans=[]
    for i,x in enumerate(rows):
        if not re.match(r'Underfull \\[hv]box',x):
            continue
        a=[re.sub(r'at lines \d+(?:--\d+)?','at lines <range>',x)]
        for y in rows[i+1:]:
            if not y.strip():
                break
            a.append(y)
        ans.append('\n'.join(a))
    return Counter(ans)
a=blocks(old.read_text(errors='replace'))
b=blocks(new.read_text(errors='replace'))
assert sum(a.values())==955
added=b-a
removed=a-b
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — nonfatal underfull diagnostic comparison',
    baseline_log=dict(path=str(old),SHA256=sha(old)),
    staged_log=dict(path=str(new),SHA256=sha(new)),
    normalization='Only paragraph source line ranges are normalized; all content/font diagnostic text and multiplicities are compared.',
    prior_blocks=sum(a.values()),current_blocks=sum(b.values()),
    added_blocks=dict(added),removed_blocks=dict(removed),
    all_normalized_blocks_and_multiplicities_identical=(a==b),
    new_blocks_require_actual_rendered_review=bool(added),
    visual_reading_credit=0,helper_source=dict(path=__file__,SHA256=sha(__file__)))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',record_SHA256=sha(out),prior=sum(a.values()),
                     current=sum(b.values()),added=sum(added.values()),removed=sum(removed.values()))))
