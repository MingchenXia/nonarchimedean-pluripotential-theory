from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Qin_curvature_rank_review_20261009'
out=C/'GitHub_source_publication_v1_20261009.json';assert not out.exists()
repo='MingchenXia/nonarchimedean-pluripotential-theory';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
api=lambda ep:json.loads(subprocess.check_output(['gh','api',ep],cwd=R,text=True))
local=json.loads((C/'local_source_commit_v1_20261009.json').read_text());head=local['commit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==head
assert api(f'repos/{repo}/git/ref/heads/work')['object']['sha']==head
main=api(f'repos/{repo}/git/ref/heads/main')['object']['sha']
assert main=='00957114db21b627e97369563032ceda9cea09c7'
tree=api(f'repos/{repo}/git/trees/{head}?recursive=1');assert not tree['truncated']
mapping={x['path']:x for x in tree['tree'] if x['type']=='blob'};rows=[]
for rel,row in local['files'].items():
 p=R/rel;assert sha(p)==row['SHA256'] and p.stat().st_size==row['bytes']
 blob=subprocess.check_output(['git','hash-object',str(p)],cwd=R,text=True).strip()
 assert mapping[rel]['sha']==blob and mapping[rel]['size']==p.stat().st_size
 rows.append(dict(path=rel,bytes=p.stat().st_size,SHA256=sha(p),local_and_remote_Git_blob_SHA1=blob))
assert len(rows)==9
a=json.loads((C/'source_checkpoint_v1_20261009.json').read_text())
for n,h in a['protected_core_inputs'].items():assert sha(R/n)==h
pr=api(f'repos/{repo}/pulls/2');assert pr['state']=='open' and pr['draft'] and pr['head']['sha']==head
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — nine remote source/evidence/progress blobs verified',repository=repo,branch='work',commit=head,main_unchanged=main,files=rows,actual_primary_pages=39,actual_matching_images=20,whole_Qin_primary_PDF_actually_read=True,active_book_pages=4669,active_book_changed=False,native_editor_changed=False,external_primary_PDF_text_images_uploaded=False,reading_credit_from_upload=0,canonical_status_changes=[],BJ22_Theorem_6_21_repaired=False,PR=dict(url=pr['html_url'],state=pr['state'],draft=pr['draft'],head=pr['head']['sha']),helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='DONE',commit=head,files=9,record_SHA256=sha(out))))
