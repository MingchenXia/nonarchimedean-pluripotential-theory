from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction as F
import hashlib, json, subprocess, zipfile, shutil, fitz

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Qin_curvature_rank_review_20261009'
E=R/'manuscript/editorial'; O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
stamp=lambda:datetime.now(timezone.utc).isoformat()
write=lambda p,a:p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
actual=C/'actual_primary_reading_v1_20261009.json'
diagpath=C/'exact_diagnostics_v1_20261009.json'; checkpoint=C/'source_checkpoint_v1_20261009.json'
paths={k:E/f'Qin_curvature_rank_source_{k}_20261009.{ext}' for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
dest=E/'artifact_exports/20261009_Qin_curvature_rank_sources'
owned=O/'Qin_Curvature_Rank_Authored_Records_V1_2026-10-09.zip'
full=O/'Qin_Curvature_Rank_Actual_Source_Evidence_V1_2026-10-09.zip'
assert not any(p.exists() for p in [actual,diagpath,checkpoint,*paths.values(),dest,owned,full])
prep_path=C/'source_preparation_v2_20261009.json'; prep=json.loads(prep_path.read_text())
assert sha(prep['source']['path'])==prep['source']['SHA256']
assert sha(prep['manifest_path'])==prep['manifest_SHA256']
assert prep['actual_primary_reading_credit']==0 and not prep['book_changed']
rows=json.loads(Path(prep['manifest_path']).read_text()); assert len(rows)==20
views=[];last=None
for i,x in enumerate(rows,1):
    note=C/f'primary_notes_v2/note_{i:02d}.md'; rp=note.with_name(note.stem+'_receipt.json')
    a=json.loads(rp.read_text())
    assert a['number']==i and a['physical_pages']==x['physical_pages']
    assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
    assert last is None or a['UTC']>last;last=a['UTC']
    assert not x['actually_viewed'] and not x['selected_text_read']
    assert sha(note)==a['note_SHA256'] and sha(a['helper_source'])==a['helper_SHA256']
    for key,h in [('path','image_SHA256'),('selected_text_path','selected_text_SHA256')]:assert sha(x[key])==x[h]==a[h]
    assert a['source_PDF_SHA256']==prep['source']['SHA256']
    views.append(dict(**a,note_path=str(note),image_path=x['path'],selected_text_path=x['selected_text_path'],observation_receipt_path=str(rp),observation_receipt_SHA256=sha(rp)))
pages=[p for v in views for p in v['physical_pages']];assert pages==list(range(1,40))
families=[]
for n in range(1,7):
 for r in range(n+1):
  for k in range(1,9):
   t_exp=F(-1,2*k+5)
   count=-2*n*t_exp+r*(1+2*t_exp)
   assert count==r+F(2*(n-r),2*k+5)
families.append(dict(name='global counting exponent',cases=216,identity='t^(-2n)(p t^2)^r = p^(r+2(n-r)/(2k+5)) for fixed k',status='PASS'))
for k in range(1,9):
 a=F(-1,2*k+5)
 assert 1+(4+2*k)*a==-a
 for m in range(7):assert -2*k*m*a+m*(1+(4+2*k)*a)==m*(1+4*a)
families.append(dict(name='last scale and internal grid',identity='P_k=t^(-1), t^(-2km) P_k^m=(p t^4)^m',status='PASS'))
assert -2*3*F(-1,7)+1*(1+2*F(-1,7))==F(11,7)
families.append(dict(name='first nontrivial depth',n=3,r=1,k=1,exponent='11/7 > 1',sharp_bound_inferred=False,status='PASS'))
families.append(dict(name='fixed epsilon versus arbitrary divergent factor',example='p^r log p is O_delta(p^(r+delta)) for every fixed delta>0, but not O(p^r)',k_depending_on_p_justified=False,status='PASS — exact quantifier separation'))
for s in range(1,7):
 for j in range(1,11):assert (j+1)**s>j**s
families.append(dict(name='Remark 11.4 diagonal obstruction',construction='choose p_j increasing with normalized a_(p_j)>(j+1)^s; epsilon(p)=j on [p_j,p_(j+1))',violation_at_every_selected_p_j=True,status='PASS'))
families.append(dict(name='Chern sign calibration',squared_metric='exp(-|z|^2)',connection='-partial phi',correct_R='-barpartial partial phi = partial barpartial phi',printed_R_has_opposite_sign=True,correct_Theta='i partial barpartial phi',rank_sign_invariant=True,positivity_sign_invariant=False,status='LITERAL PRINTED SIGN DEFECT'))
families.append(dict(name='changing rank in blowup chart',f='u v',df='v du + u dv',zero_set_of_df='u=v=0',kernel_on_v_zero='span(partial_u)',kernel_on_u_zero='span(partial_v)',common_continuous_kernel_extension=False,status='PASS'))
families.append(dict(name='product endpoint sharpness',X='P^r times connected compact complex Y',L='pullback O(1)',h0='binomial(p+r,r)',leading_coefficient='1/r!',status='PASS — classical endpoint example'))
families.append(dict(name='HRR rank truncation and surface',alpha='Theta/(2pi)',rank_condition='alpha^(r+1)=0',chi_growth='O(p^r)',surface_identity='h1=h0+h2-chi',sharp_surface_all_degree_bound_is_new=False,status='PASS — direct classical consequence'))
families.append(dict(name='duality and positive rescaling',dual_curvature='-Theta',dual_rank_equals_rank=True,book_Chern_form='Theta/(2pi)=ddc phi',book_rank_unchanged=True,status='PASS'))
for n in range(2,7):
 for r in range(n+1):
  for d in range(n+1):assert ((n-d)<(n-r))==(d>r)
families.append(dict(name='Appendix C volume power direction',lower='c epsilon^(n-d)',upper='C epsilon^(n-r)',d_greater_r_violates_as_epsilon_decreases=True,constants_independent_of_epsilon=True,status='PASS'))
families.append(dict(name='nonimmersive model maps',actual_old_variables_retained=True,metric_error_divided_by_next_t_squared=False,rank_assertion_on_accumulated_error=False,ungridded_parameter_copies_counted_as_grid=False,status='CHECKED FROM COMPLETE SOURCE ARGUMENT'))
assert len(families)==12
write(diagpath,dict(UTC=stamp(),status='DONE — twelve elementary calibration families',families=families,external_dependencies_recursively_certified=False,independent_model_receipt=None,original_results_promoted=[],helper_source=__file__,helper_SHA256=sha(__file__)))
protected={str(p.relative_to(R)):sha(p) for p in (R/'manuscript').rglob('*.tex') if 'editorial' not in p.parts}
assert len(protected)==425
for p in [R/'manuscript/bibliography/ComplexGeometry.bib',R/'manuscript/bibliography/NonArchimedean.bib',R/'manuscript/book.pdf',R/'output/open_problems_catalogue_2026-10-03.tex',R/'output/open_problems_catalogue_2026-10-03.pdf']:protected[str(p.relative_to(R))]=sha(p)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
with fitz.open(R/'manuscript/book.pdf') as d:assert len(d)==4669
reading=dict(UTC=stamp(),status='DONE — whole exact Qin v1 physical PDF read',source=prep['source'],actual_unique_physical_pages=39,actual_individually_displayed_matching_views=20,actually_read_physical_pages=pages,unread_physical_pages=[],whole_primary_PDF_actually_read=True,views=views,preparation=dict(path=str(prep_path),SHA256=sha(prep_path)),preparation_flags_unchanged=True,diagnostics_SHA256=sha(diagpath),actual_book_reading_credit=0,whole_book_new_reading_claim=False,recursive_original_dependency_certification=False,independent_model_receipt=None,original_results_promoted=[],canonical_status_changes=[],active_book_changed=False,native_editor_changed=False,BJ22_Theorem_6_21_repaired=False,baseline_commit=head,protected_core_inputs=protected,helper_source=__file__,helper_SHA256=sha(__file__))
write(actual,reading)
draft=Path('/tmp/Qin_curvature_rank_source_review_draft_v1_20261009.md');assert draft.stat().st_size>6500
paths['review'].write_text(draft.read_text())
paths['reading_notes'].write_text('# Actual Qin curvature-rank source reading\n\n39/39 physical pages, twenty individually displayed matching text/image views. External references are not recursively certified.\n'+''.join('\n---\n\n'+Path(v['note_path']).read_text() for v in views))
files={f'records/{p.name}':p for p in C.glob('*.json')}
files['manifests/prepared_views_v2.json']=Path(prep['manifest_path'])
for v in views:
 for key,kind in [('note_path','notes'),('observation_receipt_path','receipts')]:
  p=Path(v[key]);files[f'{kind}/{p.name}']=p
for p in Path('/tmp').glob('Qin_curvature_rank_*_v*_20261009.py'):files[f'helpers/{p.name}']=p
files[f'drafts/{draft.name}']=draft
metadata=R/'source_material/research_discovery_20261009_round2/recent_primary_metadata_v1_20261009.json';files[f'discovery/{metadata.name}']=metadata
for k in ['review','reading_notes']:files[f'editorial/{paths[k].name}']=paths[k]
def archive(p,entries):
 with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n,q in sorted(entries.items()):z.write(q,n)
 with zipfile.ZipFile(p) as z:
  assert len(z.namelist())==len(entries) and z.testzip() is None
  for n,q in entries.items():assert z.read(n)==q.read_bytes()
archive(owned,files)
fullfiles=dict(files);fullfiles['primary/PDF/Qin_2610.09295v1.pdf']=Path(prep['source']['path'])
for v in views:
 for key,kind in [('image_path','images'),('selected_text_path','text')]:
  p=Path(v[key]);fullfiles[f'primary/{kind}/{p.name}']=p
archive(full,fullfiles)
artifacts={k:dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p),members=n) for k,p,n in [('authored_records_archive',owned,len(files)),('cloud_source_evidence_archive',full,len(fullfiles))]}
write(paths['manifest'],dict(UTC=stamp(),status='DONE — source checkpoint; integration separately gated',actual_reading=reading,exact_diagnostics=json.loads(diagpath.read_text()),artifacts=artifacts,book_changed=False,GitHub_published=False))
write(paths['artifacts'],dict(UTC=stamp(),status='DONE — all archive members byte-verified',artifacts=artifacts,reading_credit_from_export=0,external_primary_PDF_text_images_uploaded=False,GitHub_published=False))
dest.mkdir(parents=True);target=dest/owned.name;shutil.copyfile(owned,target);assert sha(target)==sha(owned)
(dest/'SHA256SUMS').write_text(sha(target)+'  '+target.name+'\n')
(dest/'README.md').write_text(f'''# Qin curvature-rank source evidence, 9 October 2026

All 39 physical pages of arXiv:2610.09295v1 were actually read in twenty
matching individual text/image displays. The {len(files)}-member authored
archive preserves chronological notes, receipts, immutable preparation,
the acquisition case failure, twelve calibration families, helpers and
the source review. Every member is byte-verified. The {len(fullfiles)}-member
cloud archive additionally preserves the controlling PDF and matching
text/images. Upload and export add zero reading credit.

Theorem A has a fixed positive exponent loss in intermediate degrees;
sharp O(p^r) remains the source's Question 11.3. No recursive certification
of cited originals, independent-model receipt or new theorem is claimed.
The active 4,669-page book and native catalogue/editor are unchanged.
General BJ22 Siu/envelopes remain OPEN; Theorem 6.21 is not repaired.
''')
intro='''**Latest curvature-rank source checkpoint, 9 October 2026:**
the [source review](manuscript/editorial/Qin_curvature_rank_source_review_20261009.md)
records the complete 39-page Qin arXiv v1 read in twenty matching displays.
Its all-degree estimate retains a fixed positive exponent loss; sharp
intermediate-degree growth remains open. The [authored evidence](manuscript/editorial/artifact_exports/20261009_Qin_curvature_rank_sources/README.md)
preserves twelve calibrations and exact scope. The 4,669-page book and
native catalogue/editor are unchanged in this source checkpoint.

'''
p=R/'README.md';s=p.read_text();marker='**Latest checked maximal-ray/extension book integration, 9 October 2026:**';assert s.count(marker)==1;p.write_text(s.replace(marker,intro+marker,1))
p=E/'second_reading_and_research_programme_20261002.md';s=p.read_text();marker='## Latest checked maximal-ray/extension book checkpoint, 9 October 2026\n';assert s.count(marker)==1
intro='''## Latest curvature-rank source checkpoint, 9 October 2026

The [source review](Qin_curvature_rank_source_review_20261009.md) records
39/39 actual Qin v1 pages in twenty matching displays. The fixed-epsilon
Theorem A estimate is distinct from sharp O(p^r), source Question 11.3,
and from the MMZ arbitrary-divergent-factor formulation. Endpoints and
surfaces remain classical in the source's own novelty separation.
Twelve elementary calibrations check exponents, Chern signs, volume
directions and changing-rank geometry. External original dependencies
are not recursively certified; no independent-model receipt is claimed.
The [authored evidence](artifact_exports/20261009_Qin_curvature_rank_sources/README.md)
is ready for authorized publication. Integration into Chapter 55 is the
next separate book gate. The active 4,669-page book, native catalogue,
42 atoms/twelve problems and tiers (0,3,7,15,17) remain unchanged here.
General BJ22 Siu/envelopes stay OPEN, LPWZ density UNVERIFIED, and the
Theorem 6.21 warning remains binding. Continue cloud-only; Xean suspended.

''';p.write_text(s.replace(marker,intro+marker,1))
editorial=[*paths.values(),dest/owned.name,dest/'SHA256SUMS',dest/'README.md',R/'README.md',p]
assert len(editorial)==9
for rel,h in protected.items():assert sha(R/rel)==h
write(checkpoint,dict(UTC=stamp(),status='DONE — source export ready for exact nine-file commit',baseline_commit=head,editorial_files={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in editorial},actual_reading_SHA256=sha(actual),diagnostics_SHA256=sha(diagpath),artifacts=artifacts,protected_core_inputs=protected,active_book_changed=False,native_editor_changed=False,GitHub_published=False,helper_source=__file__,helper_SHA256=sha(__file__)))
print(json.dumps(dict(status='DONE',actual_pages=39,actual_views=20,authored_members=len(files),cloud_members=len(fullfiles),actual_SHA256=sha(actual),diagnostics_SHA256=sha(diagpath),checkpoint_SHA256=sha(checkpoint))))
