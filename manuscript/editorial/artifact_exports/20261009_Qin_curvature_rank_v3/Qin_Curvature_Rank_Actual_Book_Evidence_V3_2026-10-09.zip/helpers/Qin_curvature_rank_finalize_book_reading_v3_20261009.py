from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,re,subprocess,difflib,fitz

R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Qin_curvature_rank_review_20261009'
S=Path('/workspace/book-completion-drafts/Qin-curvature-rank-staging-v3-20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
ch=load('book_release_checks_v3_20261009.json');prep=load('book_staging_preparation_v3_20261009.json')
mp=Path(ch['manifest_path']);assert sha(mp)==ch['manifest_SHA256'];xs=json.loads(mp.read_text())
reading=C/'actual_book_reading_v3_20261009.json';audit=C/'book_mathematical_self_audit_v3_20261009.json';post=C/'book_post_render_checks_v3_20261009.json'
assert not any(p.exists() for p in [reading,audit,post])
views=[];last=None
for x in xs:
    assert not x['actually_viewed'] and not x['selected_text_read']
    n=C/'book_notes_v3'/f"note_{x['number']:02d}.md";rp=n.with_name(n.stem+'_receipt.json');a=json.loads(rp.read_text())
    assert 'Read the complete selected text and displayed matching rendered image' in n.read_text()
    assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
    assert a['number']==x['number'] and a['physical_pages']==x['physical_pages']
    assert a['source_PDF_SHA256']==ch['PDF']['SHA256'] and sha(n)==a['note_SHA256']
    assert sha(x['path'])==a['image_SHA256']==x['image_SHA256']
    assert sha(x['selected_text_path'])==a['selected_text_SHA256']==x['selected_text_SHA256']
    assert last is None or a['UTC']>last;last=a['UTC']
    y={k:v for k,v in x.items() if k not in ['actually_viewed','selected_text_read']}
    y.update(actual_complete_text_read=True,actual_matching_image_freshly_displayed=True,sequential_note_path=str(n),sequential_note_SHA256=sha(n),observation_receipt_path=str(rp),observation_receipt_SHA256=sha(rp));views.append(y)
pages=sorted({p for x in xs for p in x['physical_pages']});assert pages==ch['selected_book_physical_pages']
assert sum(len(x['physical_pages']) for x in xs)==len(pages)==ch['prepared_book_pages'] and len(views)==ch['prepared_views']
checks=[]
for command in [['python3','editorial/tools/refcheck.py'],['python3','editorial/tools/check_open_problem_inventory.py']]:
    run=subprocess.run(command,cwd=S/'manuscript',text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);assert run.returncode==0,run.stdout
    checks.append(dict(command=command,returncode=run.returncode,output=run.stdout))
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
for n,h in prep['other_active_TeX_preserved'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['unchanged_bibliographies'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
assert sha(ch['PDF']['path'])==ch['PDF']['SHA256']
historical={};whitespace={}
for row in prep['historical_formal_environment_counts_preserved']:
    n=row['path'];before=(R/n).read_text();after=(S/n).read_text()
    for e,count in row['environment_counts'].items():
        pat=r'\\begin\{'+e+r'\}';assert len(re.findall(pat,before))==len(re.findall(pat,after))==count
    assert re.findall(r'\\tag\{([^}]+)\}',after)==re.findall(r'\\tag\{([^}]+)\}',before)
    assert re.findall(r'\\label\{([^}]+)\}',before)==re.findall(r'\\label\{([^}]+)\}',after)
    historical[n]=row
for n in prep['after']:
    before=(R/n).read_text().splitlines();after=(S/n).read_text().splitlines()
    assert Counter(x for x in before if x!=x.rstrip())==Counter(x for x in after if x!=x.rstrip())
    added=[x[2:] for x in difflib.ndiff(before,after) if x.startswith('+ ')];assert all(x==x.rstrip() for x in added)
    run=subprocess.run(['git','diff','--no-index','--check',str(R/n),str(S/n)],text=True,capture_output=True)
    assert run.returncode in [0,1] and not(run.stdout+run.stderr).strip()
    whitespace[n]=dict(added_lines=len(added),added_trailing_whitespace=0)
for p,h in prep['draft_fragments'].items():assert sha(p)==h
under=load('book_underfull_delta_v3_20261009.json')
assert not under['added_blocks'] and not under['removed_blocks']
with fitz.open(ch['PDF']['path']) as doc:blank=[p for p in pages if not doc[p-1].get_text().strip()]
reading.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — all selected final book pages read with matching individual display',PDF=ch['PDF'],actual_unique_book_pages=len(pages),fresh_complete_text_and_individually_displayed_pages=len(pages),substantive_selected_pages=len(pages)-len(blank),explicitly_reviewed_blank_versos=blank,fresh_matching_views=len(views),reused_matching_views=0,views=views,legacy_preparation_flags_rewritten=False,remaining_repairs=[],whole_book_new_reading_claim=False,last_complete_ordered_book_pass='2026-10-04',active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
mathchecks=['The imported signature is connected compact complex smooth X, smooth Hermitian holomorphic L and a fixed holomorphic vector bundle E. No positivity, constant curvature rank, regular kernel foliation or Kahler hypothesis is imposed. The source also treats finitely many connected components separately.', 'The book Chern form is c_h=Theta_L/(2pi)=ddc phi with squared frame norm exp(-phi). The connection -partial phi gives R=-barpartial partial phi=partial barpartial phi. Source equation (2.2) prints the opposite R sign; the consistent real-form convention is used. Rank is sign-invariant; semipositivity is not.', 'The exact Qin v1 Theorem A and formulas (1.1)-(1.2) state all-degree O_epsilon(p^(r+epsilon)) for fixed epsilon. The quantitative k>=0 exponent is r+2(n-r)/(2k+5). Constants and log powers depend on fixed k/data and are independent of p. No k=k(p) step is justified.', 'Endpoint q=0,n bounds are O(p^r). The source separates the geometric Kodaira comparison, classical Serre-Siegel growth, fixed-bundle reductions, dual canonical twist and surface conclusion from its new all-degree estimate. No endpoint novelty is claimed.', 'The exact source Question 11.3 has n>=3, 1<=r<n and intermediate q. The final v3 chapter explicitly retains that r range. Flat and full-rank cases are not described as open.', 'The fixed-loss family does not imply an arbitrarily prescribed divergent factor: p^r log p is an elementary obstruction. Remark 11.4 uses a diagonal step function to make the arbitrary-factor formulation equivalent to sharp growth for fixed data. No sharp intermediate-degree claim is promoted.', 'On P^r times connected compact complex Y, pullback O(1) has binomial(p+r,r) sections and rank r. Zero top-dimensional volume is stated only for a projective product with dim Y>0. This complete-series example does not identify the non-pluripolar mass of a prescribed singular metric.', 'The source blowup example has f=uv, with differential v du+u dv. Kernel limits along the two axes differ at the isolated critical point; h0=p+1 survives the blowup. It illustrates varying rank without a global regular null foliation, not a new all-degree application.', 'For a smooth curvature form of rank at most r, c_h^(r+1)=0. Analytic HRR truncates chi to O(p^r); on surfaces h1=h0+h2-chi combines the endpoint bounds. These are direct classical consequences, not new formal results.', 'Curvature rank of a chosen smooth metric, Kodaira dimension, class numerical dimension and current-level Cao dimension are distinct data. The smooth estimate supplies no P-sensitive zero-mass partial-body construction or resolution of Problem 72.3.2.', 'The exact source arXiv:2610.09295v1, primary class math.AG with math.CV cross-list, was read in all 39 physical pages and twenty matching views. Berndtsson, Binyamini-Novikov and Hormander original dependencies remain imported and not recursively certified. No independent-model production receipt is claimed.', 'Fresh v3 condenses the source paragraph after actual v2 reading found a two-line spill on physical 4420; v2 source and actual notes remain frozen. Final reading is fresh for the v3 PDF, with separate unchanged preparation flags. All prior numbered values, 600 cited keys/labels, TOC titles/hierarchy and index terms are retained.', 'No new formal result, semantic label or manual equation tag is added. Qin is an expressly attributed recent-preprint input. General BJ22 homogeneous Siu/envelopes remain OPEN, LPWZ density UNVERIFIED, and the user warning about Theorem 6.21 remains binding.']

audit.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — ordinary scoped mathematical audit and actual final render clearance',checks=mathchecks,actual_final_book_reading_SHA256=sha(reading),source_input_hashes=prep['after'],draft_fragments=prep['draft_fragments'],original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
post.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — post-render references, inventory and input preservation checked',checks=checks,historical_formal_environment_counts_preserved=historical,whitespace_checks=whitespace,underfull_delta_SHA256=sha(C/'book_underfull_delta_v3_20261009.json'),actual_final_reading_SHA256=sha(reading),mathematical_audit_SHA256=sha(audit),release_checks_SHA256=sha(C/'book_release_checks_v3_20261009.json'),active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',pages=len(pages),views=len(views),blank_pages=blank,reading_SHA256=sha(reading),math_SHA256=sha(audit),post_SHA256=sha(post))))
