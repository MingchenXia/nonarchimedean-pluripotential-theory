from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,shutil,subprocess,zipfile
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Qin_curvature_rank_review_20261009'
B=Path('/workspace/book-completion-drafts/NA-maximal-extension-staging-v2-20261009')
S=Path('/workspace/book-completion-drafts/Qin-curvature-rank-staging-v2-20261009')
D=Path('/workspace/book-completion-drafts/Qin-curvature-rank-integration-v2-20261009')
out=C/'book_staging_preparation_v2_20261009.json';assert not S.exists() and not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pubpath=C/'GitHub_source_publication_v1_20261009.json';pub=json.loads(pubpath.read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==pub['commit']
assert pub['actual_primary_pages']==39 and pub['actual_matching_images']==20 and pub['whole_Qin_primary_PDF_actually_read']
for row in pub['files']:assert sha(R/row['path'])==row['SHA256']
reading=json.loads((C/'actual_primary_reading_v1_20261009.json').read_text());protected=reading['protected_core_inputs']
for n,h in protected.items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==sha(B/'manuscript/book.pdf')=='4a04ec08caacec24cb2bb4e6c1aadc8edb4aeccc8b674dac0ebe7426de9f7302'
a=json.loads((R/'source_material/BJ_original_NA_model_dependencies_review_20261009/book_export_v1_20261009.json').read_text());m=a['artifacts']['minimal_TeX_source_archive'];archive=Path(m['path']);assert sha(archive)==m['SHA256']
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==472
 for n in z.namelist():assert not Path(n).is_absolute() and '..' not in Path(n).parts
 S.mkdir();z.extractall(S)
progress=['README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']
for n in progress:shutil.copyfile(R/n,S/n)
alltex={n:h for n,h in protected.items() if n.startswith('manuscript/') and n.endswith('.tex')};assert len(alltex)==425
for n,h in alltex.items():assert sha(S/n)==sha(R/n)==sha(B/n)==h
changed=['manuscript/parts/part5/ch55_okounkov_dh.tex','manuscript/appendices/appL_provenance.tex','manuscript/bibliography/ComplexGeometry.bib']
before={n:sha(R/n) for n in changed}
for n in changed:assert sha(S/n)==sha(R/n)==sha(B/n)
for p in D.iterdir():assert all(line==line.rstrip() for line in p.read_text().splitlines())
p=S/changed[0];s=p.read_text();marker='\\section{Provenance and safeguards}';assert s.count(marker)==1
p.write_text(s.replace(marker,(D/'ch55_curvature_rank_fragment.tex').read_text().rstrip()+'\n\n'+marker,1))
p=S/changed[1];p.write_text(p.read_text().rstrip()+'\n\n'+(D/'appL_curvature_rank_fragment.tex').read_text().rstrip()+'\n')
p=S/changed[2];s=p.read_text();assert 'Qin26CurvatureRankV1' not in s
p.write_text(s.rstrip()+'''

@misc{Qin26CurvatureRankV1,
  author = {Qin, Xiangsen},
  title = {Dolbeault Cohomology Growth under Curvature Rank Bounds},
  year = {2026},
  eprint = {2610.09295v1},
  archivePrefix = {arXiv},
  primaryClass = {math.AG},
  url = {https://arxiv.org/abs/2610.09295v1},
  shorthand = {Qin26CR},
  note = {Exact version 1, 7 October 2026; all thirty-nine physical pages read. Theorem A retains a fixed positive exponent loss; sharp intermediate-degree growth is Question 11.3}
}
''')
checks=[]
for n in changed[:2]:
 old=(R/n).read_text();new=(S/n).read_text();counts={}
 for e in ['theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important']:
  pattern=r'\\begin\{'+e+r'\}';counts[e]=len(re.findall(pattern,old));assert counts[e]==len(re.findall(pattern,new))
 assert re.findall(r'\\tag\{([^}]+)\}',old)==re.findall(r'\\tag\{([^}]+)\}',new)
 assert re.findall(r'\\label\{([^}]+)\}',old)==re.findall(r'\\label\{([^}]+)\}',new)
 checks.append(dict(path=n,environment_counts=counts))
unchanged={n:h for n,h in alltex.items() if n not in changed};assert len(unchanged)==423
for n,h in unchanged.items():assert sha(R/n)==sha(S/n)==h
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — attributed smooth curvature-rank discussion prepared',stage_path=str(S),baseline_stage_path=str(B),baseline_compiled_snapshot=str(R/'source_material/BJ_original_NA_model_dependencies_review_20261009/book_compiled_staged_v2'),baseline_commit=head,baseline_minimal_source=m,draft_path=str(D),before=before,after={n:sha(S/n) for n in changed},draft_fragments={str(p):sha(p) for p in D.iterdir()},active_inputs_preserved=before,other_active_TeX_preserved=unchanged,other_active_TeX_count=423,unchanged_bibliographies={'manuscript/bibliography/NonArchimedean.bib':sha(R/'manuscript/bibliography/NonArchimedean.bib')},historical_formal_environment_counts_preserved=checks,active_book_PDF_SHA256=sha(R/'manuscript/book.pdf'),native_catalogue_preserved={n:h for n,h in protected.items() if n.startswith('output/')},source_checkpoint_SHA256=sha(C/'source_checkpoint_v1_20261009.json'),actual_primary_reading_SHA256=sha(C/'actual_primary_reading_v1_20261009.json'),exact_diagnostics_SHA256=sha(C/'exact_diagnostics_v1_20261009.json'),source_publication_SHA256=sha(pubpath),new_bibliographic_keys=['Qin26CurvatureRankV1'],new_semantic_labels=[],new_formal_environments=0,original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],active_book_changed=False,GitHub_published=False,actual_book_reading_credit=0,helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='DONE',record_SHA256=sha(out),unchanged_TeX=423,changed_files=3)))
