from pathlib import Path
from datetime import datetime, timezone
import urllib.request, hashlib, json, fitz

C = Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Qin_curvature_rank_review_20261009')
assert not C.exists()
url = 'https://arxiv.org/pdf/2610.09295v1'
request = urllib.request.Request(url, headers={'User-Agent': 'Book-source-audit/1.0'})
with urllib.request.urlopen(request, timeout=60) as response:
    data = response.read(); final_url = response.url; content_type = response.headers.get('Content-Type')
assert data.startswith(b'%PDF-') and len(data) > 10000
C.mkdir(parents=True)
pdf = C / 'Qin_Dolbeault_curvature_rank_2610.09295v1.pdf'; pdf.write_bytes(data)
with fitz.open(pdf) as doc:
    pages = len(doc); title_text = doc[0].get_text()
    assert 'Dolbeault' in title_text and 'Qin' in title_text
    text_path = C / 'Qin_Dolbeault_curvature_rank_2610.09295v1_preparation_text.txt'
    text_path.write_text('\n\n'.join(f'PREPARATION PHYSICAL PAGE {i+1}\n' + p.get_text() for i, p in enumerate(doc)))
obj = dict(UTC=datetime.now(timezone.utc).isoformat(), status='ACQUIRED — no actual reading credit',
    exact_version='arXiv:2610.09295v1', submitted_UTC='2026-10-07 01:57:38', requested_URL=url,
    resolved_URL=final_url, content_type=content_type, path=str(pdf), bytes=len(data),
    SHA256=hashlib.sha256(data).hexdigest(), physical_pages=pages, first_page_identity=title_text[:700],
    preparation_text_path=str(text_path), preparation_text_SHA256=hashlib.sha256(text_path.read_bytes()).hexdigest(),
    actual_reading_credit=0, mathematical_clearance=False, book_changed=False,
    helper_source=__file__, helper_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
(C / 'source_acquisition_v1_20261009.json').write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({k:obj[k] for k in ['status','exact_version','physical_pages','bytes','SHA256']}))
