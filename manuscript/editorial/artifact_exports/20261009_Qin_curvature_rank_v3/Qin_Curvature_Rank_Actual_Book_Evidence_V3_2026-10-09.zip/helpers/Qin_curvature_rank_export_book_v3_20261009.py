from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile,shutil,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Qin_curvature_rank_review_20261009'
S=Path('/workspace/book-completion-drafts/Qin-curvature-rank-staging-v3-20261009');E=R/'manuscript/editorial';O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
write=lambda p,a:p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
prep=load('book_staging_preparation_v3_20261009.json');release=load('book_release_checks_v3_20261009.json')
reading=load('actual_book_reading_v3_20261009.json');post=load('book_post_render_checks_v3_20261009.json');math=load('book_mathematical_self_audit_v3_20261009.json');under=load('book_underfull_delta_v3_20261009.json')
assert reading['status'].startswith('DONE') and not reading['remaining_repairs']
assert reading['actual_unique_book_pages']==24 and reading['fresh_matching_views']==12 and reading['reused_matching_views']==0
assert reading['explicitly_reviewed_blank_versos']==[4420]
assert all(x['returncode']==0 for x in post['checks']) and not under['added_blocks'] and not under['removed_blocks']
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['before'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
assert sha(release['PDF']['path'])==release['PDF']['SHA256']==reading['PDF']['SHA256']
record=C/'book_export_v3_20261009.json'
paths={k:E/f'Qin_curvature_rank_staged_integration_{k}_v3_20261009.{ext}' for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
full=O/'Non-Archimedean_Pluripotential_Theory_Curvature_Rank_V3_2026-10-09.pdf'
review=O/'Qin_Curvature_Rank_Actual_Book_Review_V3_2026-10-09.pdf'
minimal=O/'Qin_Curvature_Rank_Minimal_Source_V3_2026-10-09.zip'
evidence=O/'Qin_Curvature_Rank_Actual_Book_Evidence_V3_2026-10-09.zip'
dest=E/'artifact_exports/20261009_Qin_curvature_rank_v3'
assert not any(p.exists() for p in [record,*paths.values(),full,review,minimal,evidence,dest])
shutil.copyfile(release['PDF']['path'],full);assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as b:
 d=fitz.open()
 for n in release['selected_book_physical_pages']:d.insert_pdf(b,from_page=n-1,to_page=n-1)
 assert len(d)==24
 d.set_metadata(dict(title='Smooth curvature rank and section growth — actual book review',subject='24 selected physical pages actually read in twelve matching displays, including one blank verso. Export adds zero reading credit.'))
 d.save(review,garbage=4,deflate=True);d.close()
audit='''# Smooth curvature rank book integration, 9 October 2026

The checked 4,671-page edition adds a short attributed discussion to the
end of Chapter 55 and its source audit to Appendix L. Smooth metric
curvature rank, Kodaira dimension and current/class numerical dimensions
remain distinct. Qin's recent arXiv v1 provides an all-degree estimate
with each fixed positive exponent loss; constants are chosen before the
tensor power and do not permit a variable rescaling depth. The sharp
intermediate-degree question retains n>=3 and 1<=r<n. Classical endpoints
and surfaces are not described as new discoveries. The product and blowup
examples explain sharp section growth and varying rank without a regular
null foliation. No P-sensitive zero-mass body construction is inferred.

The controlling Qin v1 was read in all 39 physical pages and twenty
matching displays. Its original deep dependencies were not recursively
certified. The book uses the consistent Chern sign and positive 1/(2pi)
conversion rather than the source's printed R term in formula (2.2).
The primary arXiv class is math.AG, with math.CV as a cross-list.
This is an expressly imported preprint estimate, not a new book theorem.

All 24 selected final book pages were completely read with twelve fresh
individual matching displays: revised passages and seams, two contents
pages, an orientation page, all twelve index pages and the entire new
Qin26CR bibliography entry. Physical 4420 is an explicitly reviewed blank
verso. The selection metadata field called selected_contents_pages also
includes orientation page 102; actual contents are 55 and 71. This does
not constitute a new whole-book pass; the last complete ordered reading
remains 4 October. Preparation flags remain unchanged and actual receipts
are separate. No earlier v2 reading was transferred to the final PDF.

Required validation, six existing tests and post-render checks pass.
There are zero errors, package/pdfTeX warnings, missing glyphs, overfull
boxes, unresolved references/citations or rerun requests. The 955 inherited
underfull blocks retain identical normalized content and multiplicity.
All 13,382 prior numbered values, 600 cited keys and citation labels,
2,765 contents titles/hierarchy and 900 index entries are preserved.
One new attributed key gives 601 cited entries. All internal links resolve.
Two selected core TeX inputs and the ComplexGeometry bibliography change;
the other 423 selected core TeX inputs and NA bibliography are unchanged.
No formal result, manual equation tag or semantic label is added.

The executed v1 export preflight had an incorrect protected-input count;
fresh v2 recovered the 425-input build closure without rewriting the
original calibrations. Book stage v1 was superseded before rendered
reading for bibliography metadata and connected/projective scope.
View-helper v1 assumed an outline level of one instead of two and failed
before preparing images. Actual v2 reading stopped after five views when
a two-line source-paragraph spill was found. Fresh v3 condenses that
paragraph and makes the sharp-bound r range explicit. Earlier drafts,
helpers, logs, preparations and observations remain frozen.

Canonical inventory remains 42 atoms/twelve formal problems, tiers
(0,3,7,15,17). General BJ22 homogeneous Siu/envelopes stay OPEN, LPWZ
density UNVERIFIED, and the user's Theorem 6.21 warning remains binding.
No independent-model production receipt or general Siu repair is claimed.
The native catalogue/editor is unchanged. Activation and GitHub publication
are subsequent separate records. Export/upload add zero reading credit.

The scoped mathematical checks are:

'''+''.join(f'{i}. {x}\n\n' for i,x in enumerate(math['checks'],1))
paths['audit'].write_text(audit.rstrip()+'\n')
paths['reading_notes'].write_text(('# Actual final curvature-rank book reading\n\n24 complete selected physical pages, twelve fresh matching views, one explicitly reviewed blank verso. No fresh whole-book or primary-source reading credit.\n'+''.join('\n---\n\n'+Path(x['sequential_note_path']).read_text() for x in reading['views'])).rstrip()+'\n')
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md'
p=S/'README.md';s=p.read_text();marker='**Latest curvature-rank source checkpoint, 9 October 2026:**';assert s.count(marker)==1
intro='''**Latest checked curvature-rank book integration, 9 October 2026:**
the [integration audit](manuscript/editorial/Qin_curvature_rank_staged_integration_audit_v3_20261009.md)
records the 4,671-page edition: Chapter 55 connects smooth curvature rank
to section growth, keeping the fixed-exponent-loss preprint estimate and
sharp intermediate-degree question separate. Appendix L records source
scope and the Chern sign. All 24 selected final pages were read in twelve
fresh matching displays; required validation and post-render checks pass.
All old numbered values, cited labels, contents and index terms remain.
The [artifacts](manuscript/editorial/artifact_exports/20261009_Qin_curvature_rank_v3/README.md)
preserve full book, selected review, minimal source and actual evidence.
The [activation record](manuscript/editorial/Qin_curvature_rank_cloud_activation_v3_20261009.json)
records activation separately. General BJ22 Siu/envelopes remain OPEN.

''';p.write_text(s.replace(marker,intro+marker,1))
p=S/programme;s=p.read_text();marker='## Latest curvature-rank source checkpoint, 9 October 2026\n';assert s.count(marker)==1
intro='''## Latest checked curvature-rank book checkpoint, 9 October 2026

The [integration audit](Qin_curvature_rank_staged_integration_audit_v3_20261009.md)
records the 4,671-page edition. Chapter 55 imports Qin v1's fixed-positive-
exponent-loss estimate with exact smooth complex hypotheses, fixed E and
constants chosen before degree growth. The sharp intermediate-degree
question retains n>=3, 1<=r<n; endpoints and surfaces remain classical.
Smooth metric rank, Kodaira growth and numerical/mass data are distinct.
Appendix L records the positive Chern conversion and literal source sign.
The complete source read is 39/39 pages, twenty matching views; deeper
original references are not recursively certified.

All 24 selected final book pages were actually read in twelve fresh
matching displays, including all twelve index pages and the entire new
Qin26CR bibliography entry. Physical 4420 is an explicitly reviewed blank
verso. Two contents pages and contextual orientation page 102 were read.
The earlier v2 source-paragraph spill was repaired in fresh v3 before
activation; all prior helpers, stages and partial observations stay frozen.
Last complete ordered whole-book read remains 4 October.

Required validation, six tests and post-render checks pass. All 13,382
old numbered values, 600 prior cited keys/labels, 2,765 contents titles
and 900 index entries are preserved. One new key gives 601 cited entries.
All internal links resolve. Zero overfull boxes; the 955 inherited
underfull blocks are identical in normalized content/multiplicity.
The other 423 selected core TeX inputs and NA bibliography are unchanged.
No new formal result, semantic label or manual tag is added.

The [artifacts](artifact_exports/20261009_Qin_curvature_rank_v3/README.md)
preserve full PDF, actual review, minimal source and reading evidence.
The Qin source/evidence commit ded64b93658e0d4d7b52f4e052b9f57a44ddfc38
has all nine remote blobs verified. Activation and book publication are
separate records. Preserve the native catalogue/editor and canonical
42 atoms/twelve problems, tiers (0,3,7,15,17). General BJ22 Siu/envelopes
remain OPEN, LPWZ density UNVERIFIED and Theorem 6.21 warning binding.
No independent-model receipt or critical homogeneous repair is claimed.
Continue cloud-only with incoming author progress and related papers.
The newly published Ballaÿ–Sombra adelic approximation/equidistribution
edition is a next source candidate; its acquisition adds no reading credit.
Xean remains suspended.

''';p.write_text(s.replace(marker,intro+marker,1))
with zipfile.ZipFile(prep['baseline_minimal_source']['path']) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 members=old.namelist();assert len(members)==len(set(members))==472
 for n in members:z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
 assert z.testzip() is None
 for n in z.namelist():assert z.read(n)==(S/n).read_bytes()
files={f'records/{q.name}':q for q in C.glob('*.json')}
for v in [1,2,3]:
 q=C/f'book_validation_v{v}_20261009.log';files[f'logs/{q.name}']=q
 stage=Path(f'/workspace/book-completion-drafts/Qin-curvature-rank-staging-v{v}-20261009');draft=Path(f'/workspace/book-completion-drafts/Qin-curvature-rank-integration-v{v}-20261009')
 for rel in prep['after']:files[f'staged_inputs/v{v}/{rel}']=stage/rel
 for q in draft.iterdir():files[f'drafts/v{v}/{q.name}']=q
 for q in (C/f'book_compiled_staged_v{v}').iterdir():
  if q.suffix!='.pdf':files[f'compiled/v{v}/{q.name}']=q
for v in [2,3]:
 for rp in (C/f'book_notes_v{v}').glob('*_receipt.json'):
  a=json.loads(rp.read_text());n=a['number'];w=Path(f'/tmp/Qin_curvature_rank_staged_book_views_v{v}_20261009')
  for kind,q in [('notes',rp.with_name(rp.name.replace('_receipt.json','.md'))),('receipts',rp),('images',w/f'sheet_{n:02d}.png'),('text',w/f'sheet_{n:02d}.txt')]:files[f'actual_v{v}/{kind}/{q.name}']=q
 files[f'actual_v{v}/prepared_manifest.json']=Path(load(f'book_release_checks_v{v}_20261009.json')['manifest_path'])
for q in Path('/tmp').glob('Qin_curvature_rank_*_v*_20261009.py'):files[f'helpers/{q.name}']=q
for q in [paths['audit'],paths['reading_notes'],S/programme,S/'README.md']:files[f'editorial/{q.name}']=q
q=E/'artifact_exports/20261009_Qin_curvature_rank_sources/Qin_Curvature_Rank_Authored_Records_V1_2026-10-09.zip';files[f'source_owned_records/{q.name}']=q
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
 assert len(z.namelist())==len(files) and z.testzip() is None
 for n,q in files.items():assert z.read(n)==q.read_bytes()
artifacts={k:dict(path=str(q),bytes=q.stat().st_size,SHA256=sha(q)) for k,q in [('full_book_PDF',full),('selected_review_PDF',review),('minimal_TeX_source_archive',minimal),('actual_book_evidence_archive',evidence)]}
artifacts['full_book_PDF']['physical_pages']=4671;artifacts['selected_review_PDF']['physical_pages']=24
artifacts['minimal_TeX_source_archive']['members']=472;artifacts['actual_book_evidence_archive']['members']=len(files)
progress={n:sha(S/n) for n in ['README.md',programme]}
write(paths['manifest'],dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — mathematical/mechanical/actual-final-render gate',preparation=prep,release=release,actual_reading=reading,mathematical_audit=math,post_render=post,underfull_comparison=under,artifacts=artifacts,active_book_changed=False,GitHub_published=False))
write(paths['artifacts'],dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — all export members byte-verified',artifacts=artifacts,actual_final_book_pages=24,fresh_matching_views=12,explicitly_reviewed_blank_versos=[4420],reading_credit_from_export=0,GitHub_published=False))
dest.mkdir(parents=True)
for q in [full,review,minimal,evidence]:shutil.copyfile(q,dest/q.name);assert sha(dest/q.name)==sha(q)
(dest/'SHA256SUMS').write_text(''.join(sha(q)+'  '+q.name+'\n' for q in [full,review,minimal,evidence]))
(dest/'README.md').write_text(f'''# Curvature-rank book artifacts, 9 October 2026

Checked 4,671-page final-v3 book. Actual review: 24 selected physical pages,
twelve fresh matching displays, including one explicitly reviewed blank
verso (4420), full twelve-page index and complete new Qin26CR entry.
The two contents pages and orientation page 102 retain their distinct roles.
No new whole-book pass; last complete ordered reading remains 4 October.

The full PDF is accompanied by a 24-page actual-review PDF, 472-member
minimal build source and {len(files)}-member evidence archive. Every archive
member is byte-verified. Evidence preserves final notes, receipts, matching
text/images, the provisional v2 ten-page reading and its actual layout
repair, frozen helpers, stages and logs, and the authored Qin source records.
External source PDF/text/images remain in their separate cloud archive.
Export, commit and upload add zero reading credit.

Qin v1's fixed-epsilon complex estimate is imported with its exact scope.
Sharp intermediate-degree growth, P-sensitive zero-mass bodies and general
BJ22 Siu/envelopes remain open. No independent-model receipt is claimed.
The native catalogue/editor and 42 atoms/twelve problems are unchanged.
Activation and remote book publication are separately recorded.
''')
editorial={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in paths.values()}
for p in dest.iterdir():editorial[str(p.relative_to(R))]=dict(bytes=p.stat().st_size,SHA256=sha(p))
write(record,dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — final book/evidence export',artifacts=artifacts,editorial_files=editorial,progress_document_hashes=progress,actual_final_book_pages=24,actual_final_matching_views=12,reused_matching_views=0,explicitly_reviewed_blank_versos=[4420],active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)))
print(json.dumps(dict(status='DONE',record_SHA256=sha(record),evidence_members=len(files),artifacts=artifacts)))
