from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, sys

C = Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Qin_curvature_rank_review_20261009')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
a = json.load(sys.stdin); n = a['number']; assert isinstance(n, int) and 1 <= n <= 20
prep = json.loads((C / 'source_preparation_v2_20261009.json').read_text())
manifest = Path(prep['manifest_path']); assert sha(manifest) == prep['manifest_SHA256']
x = json.loads(manifest.read_text())[n-1]; assert x['number'] == n
assert not x['actually_viewed'] and not x['selected_text_read']
assert sha(x['path']) == x['image_SHA256'] and sha(x['selected_text_path']) == x['selected_text_SHA256']
note = C / 'primary_notes_v2' / f'note_{n:02d}.md'; receipt = note.with_name(note.stem + '_receipt.json')
assert not note.exists() and not receipt.exists() and a['observations'].strip()
now = datetime.now(timezone.utc).isoformat()
if n > 1:
    prev = json.loads((C / 'primary_notes_v2' / f'note_{n-1:02d}_receipt.json').read_text()); assert now > prev['UTC']
note.write_text(f'# Qin curvature-rank source review — view {n}\n\nPhysical pages: {x["physical_pages"]}.\n\n'
    'Read the complete selected text and displayed matching rendered image.\n\n' + a['observations'].strip()
    + '\n\nScope: these selected source pages only; no recursive reference certification or book-integration clearance.\n')
obj = dict(UTC=now, number=n, physical_pages=x['physical_pages'], source_PDF_SHA256=prep['source']['SHA256'],
    complete_selected_text_actually_read=True, matching_image_individually_displayed_and_reviewed=True,
    note_SHA256=sha(note), image_SHA256=sha(x['path']), selected_text_SHA256=sha(x['selected_text_path']),
    helper_source=__file__, helper_SHA256=sha(__file__))
receipt.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(number=n, physical_pages=x['physical_pages'], note_SHA256=sha(note), receipt_SHA256=sha(receipt))))
