from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,re,fitz
from PIL import Image,ImageDraw
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Qin_curvature_rank_review_20261009'
S=Path('/workspace/book-completion-drafts/Qin-curvature-rank-staging-v2-20261009')
B=Path('/workspace/book-completion-drafts/NA-maximal-extension-staging-v2-20261009')
snap=C/'book_compiled_staged_v2';W=Path('/tmp/Qin_curvature_rank_staged_book_views_v2_20261009')
out=C/'book_release_checks_v2_20261009.json';notes=C/'book_notes_v2'
assert not any(p.exists() for p in (W,out,notes))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
vp=C/'book_validation_v2_20261009.json';v=json.loads(vp.read_text());assert v['status']=='DONE' and v['returncode']==0
prep=json.loads((C/'book_staging_preparation_v2_20261009.json').read_text());pdf=snap/'book.pdf'
assert sha(pdf)==v['compiled_PDF']['SHA256'];assert sha(B/'manuscript/book.pdf')==sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
log=(snap/'book.log').read_text(errors='replace')
patterns={'TeX_errors':r'^!','LaTeX_package_warnings':r'LaTeX Warning:|Package .* Warning:','pdfTeX_warnings':r'pdfTeX warning','missing_characters':r'Missing character:','overfull_boxes':r'Overfull \\[hv]box','underfull_boxes':r'Underfull \\[hv]box','unresolved_refs_cites':r'undefined references|undefined citations','rerun_requests':r'Rerun to get|Label\(s\) may have changed'}
counts={k:len(re.findall(p,log,re.M)) for k,p in patterns.items()};assert all(x==0 for k,x in counts.items() if k!='underfull_boxes'),counts
bib=lambda p:{k:x for x,k in re.findall(r'\\bibitem\[([^\]]+)\]\{([^}]+)\}',p.read_text())}
ob=bib(B/'manuscript/book.bbl');nb=bib(snap/'book.bbl');assert len(ob)==600 and len(nb)==601
assert all(nb.get(k)==x for k,x in ob.items());assert set(nb)-set(ob)=={'Qin26CurvatureRankV1'}
def fields(s):
 ans=[];depth=0;start=0
 for i,ch in enumerate(s):
  if i and s[i-1]=='\\':continue
  if ch=='{':
   if depth==0:start=i+1
   depth+=1
  elif ch=='}':
   depth-=1
   if depth==0:ans.append(s[start:i])
 assert depth==0;return ans
def labels(base):
 ans={}
 for q in [base/'manuscript/book.aux']+[q for patt in ['frontmatter/*.aux','parts/**/*.aux','appendices/*.aux'] for q in (base/'manuscript').glob(patt)]:
  if not q.exists():continue
  for line in q.read_text().splitlines():
   m=re.match(r'\\newlabel\{([^}]+)\}\{(.*)\}\s*$',line)
   if m and not m[1].endswith('@cref') and m[1]!='LastPage':
    f=fields(m[2]);ans[m[1]]=dict(number=f[0],printed_page=f[1],destination=f[3] if len(f)>3 else None)
 return ans
ol=labels(B);nl=labels(S);assert all(nl.get(k,{}).get('number')==x['number'] for k,x in ol.items())
assert set(nl)==set(ol)
idx=lambda p:Counter(re.findall(r'^\\indexentry\{(.*)\}\{[^{}]*\}$',p.read_text(),re.M))
assert idx(B/'manuscript/book.idx')==idx(S/'manuscript/book.idx')
ilg=(snap/'book.ilg').read_text();m=re.search(r'(\d+) entries accepted, (\d+) rejected',ilg);assert m
index=dict(accepted=int(m[1]),rejected=int(m[2]),warnings=int(re.search(r'(\d+) warnings',ilg)[1]),added_terms={});assert index['accepted']==900 and index['rejected']==index['warnings']==0
with fitz.open(R/'manuscript/book.pdf') as d:oldtoc=d.get_toc()
doc=fitz.open(pdf);toc=doc.get_toc();names=doc.resolve_names();assert [(x[0],x[1]) for x in toc]==[(x[0],x[1]) for x in oldtoc]
invalid=[];internal=external=0
for page in doc:
 for link in page.get_links():
  if link.get('kind')==fitz.LINK_GOTO:
   internal+=1
   if not 0<=link.get('page',-1)<len(doc):invalid.append(dict(page=page.number+1,link=link))
  elif link.get('kind')==fitz.LINK_NAMED:
   internal+=1;target=link.get('nameddest') or link.get('name')
   if target and target not in names:invalid.append(dict(page=page.number+1,target=target))
  elif link.get('kind')==fitz.LINK_URI:external+=1
assert not invalid and all(1<=x[2]<=len(doc) for x in toc)
for x in nl.values():
 if x['destination']:assert x['destination'] in names,x
location=lambda label:names[nl[label]['destination']]['page']+1
chstart=location('chap:transcendental-okounkov-dh');prstart=location('sec:ok-provenance')
heading='Smooth curvature rank and section growth'
found=[p+1 for p in range(chstart-1,prstart) if heading in ' '.join(doc[p].get_text().split())];assert len(found)==1
newstart=found[0];selected=set(range(newstart-1,prstart+2))
astart=location('app:provenance');afound=[p.number+1 for p in doc if p.number+1>=astart and 'Smooth curvature rank and cohomology growth.' in ' '.join(p.get_text().split())];assert len(afound)==1
aindex=next(i for i,x in enumerate(toc) if x[1]=='Theorem provenance and status ledger')
nextapp=next(x[2] for x in toc[aindex+1:] if x[0]<=toc[aindex][0])
selected.update(range(afound[0]-1,nextapp+1))
istart=next(x[2] for x in toc if x[1]=='Index');bstart=next(x[2] for x in toc if x[1]=='References');selected.update(range(istart,bstart))
contents=[]
for n in range(1,200):
 t=' '.join(doc[n-1].get_text().split())
 if 'Okounkov bodies and Duistermaat' in t or 'Theorem provenance and status ledger' in t:contents.append(n);selected.add(n)
assert contents
order=re.findall(r'\\bibitem\[[^\]]+\]\{([^}]+)\}',(snap/'book.bbl').read_text());key='Qin26CurvatureRankV1';i=order.index(key)
bst=names['cite.'+key]['page']+1;ben=names['cite.'+order[i+1]]['page']+1 if i+1<len(order) else len(doc);bibpages=list(range(bst,ben+1));selected.update(bibpages)
inputs=[]
for line in (snap/'book.fls').read_text().splitlines():
 if not line.startswith('INPUT '):continue
 p=Path(line[6:]);p=p if p.is_absolute() else S/'manuscript'/p
 try:n=p.resolve().relative_to((S/'manuscript').resolve())
 except ValueError:continue
 if p.suffix=='.tex' and p.exists() and n not in inputs:inputs.append(n)
assert len(inputs)==425
changed={str(n):dict(before=sha(B/'manuscript'/n),after=sha(S/'manuscript'/n)) for n in inputs if sha(B/'manuscript'/n)!=sha(S/'manuscript'/n)}
assert set(changed)=={'parts/part5/ch55_okounkov_dh.tex','appendices/appL_provenance.tex'}
pages=sorted(selected);assert all(1<=n<=len(doc) for n in pages);W.mkdir();notes.mkdir();views=[]
for i in range(0,len(pages),2):
 pp=pages[i:i+2];panels=[];texts=[]
 for n in pp:
  pix=doc[n-1].get_pixmap(matrix=fitz.Matrix(1.4,1.4),alpha=False);panels.append(Image.frombytes('RGB',[pix.width,pix.height],pix.samples));texts.append(f'QIN CURVATURE-RANK STAGED BOOK V2 PHYSICAL PAGE {n}\n'+doc[n-1].get_text())
 canvas=Image.new('RGB',(sum(p.width for p in panels),max(p.height for p in panels)+28),'white');draw=ImageDraw.Draw(canvas);x=0
 for n,panel in zip(pp,panels):draw.text((x+8,8),f'Qin curvature rank staged v2: physical {n}',fill='black');canvas.paste(panel,(x,28));x+=panel.width
 number=i//2+1;ip=W/f'sheet_{number:02d}.png';tp=W/f'sheet_{number:02d}.txt';canvas.save(ip);tp.write_text('\n\n'.join(texts));views.append(dict(number=number,physical_pages=pp,path=str(ip),image_SHA256=sha(ip),selected_text_path=str(tp),selected_text_SHA256=sha(tp),source_PDF_SHA256=sha(pdf),actually_viewed=False,selected_text_read=False))
mp=W/'manifest.json';mp.write_text(json.dumps(views,ensure_ascii=False,indent=2)+'\n')
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — release checks and selected-view preparation; zero reading credit',validation_SHA256=sha(vp),PDF=dict(path=str(pdf),SHA256=sha(pdf),bytes=pdf.stat().st_size,physical_pages=len(doc)),build_checks=counts,bibliography=dict(cited_entries=len(nb),prior_cited_keys_and_labels_preserved=len(ob),new_labels={key:nb[key]},selected_complete_entry_pages={key:bibpages}),all_prior_numbered_label_values_preserved=len(ol),new_semantic_labels={},index=index,navigation=dict(named_destinations=len(names),internal_links=internal,external_URL_links=external,invalid_internal_links=0,toc_entries=len(toc),prior_toc_title_hierarchy_preserved=len(oldtoc),new_toc_entries=[]),source_closure=dict(TeX_inputs=425,changed_TeX_inputs=changed),sections=dict(ch55_start=chstart,new_discussion_start=newstart,provenance_start=prstart,new_source_audit_start=afound[0],next_appendix_start=nextapp,index_start=istart,references_start=bstart,selected_contents_pages=contents),selected_book_physical_pages=pages,prepared_book_pages=len(pages),prepared_views=len(views),manifest_path=str(mp),manifest_SHA256=sha(mp),actual_book_reading_credit=0,active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='DONE',SHA256=sha(out),physical_pages=len(doc),selected_pages=len(pages),views=len(views),prior_label_values=len(ol),checks=counts,sections=obj['sections'])))
