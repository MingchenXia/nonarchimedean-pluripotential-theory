from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, fitz, subprocess
from PIL import Image, ImageDraw

C = Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Qin_curvature_rank_review_20261009')
W = Path('/tmp/Qin_curvature_rank_primary_views_v2_20261009')
pdf = C / 'Qin_Dolbeault_curvature_rank_2610.09295v1.pdf'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
record = C / 'source_preparation_v2_20261009.json'
failure = C / 'acquisition_identity_case_failure_v1_20261009.json'
assert not W.exists() and not record.exists() and not failure.exists()
assert sha(pdf) == '5eeee98001d83be27931205933d22eabe831c883ff6c0802b44aa54d043e0efb'
with fitz.open(pdf) as d:
    assert len(d) == 39
    first = d[0].get_text()
    assert 'dolbeault cohomology' in first.lower() and 'xiangsen qin' in first.lower()
    assert '2610.09295v1' in first and '7 Oct 2026' in first
failure.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(), status='FROZEN — case-sensitive identity preflight failed after PDF acquisition',
    error='Assertion expected mixed-case Dolbeault and Qin; actual first-page title and author are uppercase.',
    failed_helper='/tmp/Qin_curvature_rank_acquire_v1_20261009.py', failed_helper_SHA256=sha('/tmp/Qin_curvature_rank_acquire_v1_20261009.py'),
    acquired_PDF_path=str(pdf), acquired_PDF_SHA256=sha(pdf), acquired_PDF_bytes=pdf.stat().st_size,
    actual_reading_credit=0, mathematical_clearance=False, book_changed=False), ensure_ascii=False, indent=2) + '\n')
W.mkdir()
text_path = C / 'Qin_Dolbeault_curvature_rank_2610.09295v1_preparation_text.txt'
assert not text_path.exists()
subprocess.run(['pdftotext', '-layout', str(pdf), str(text_path)], check=True)
texts = text_path.read_text().split('\f'); assert len(texts) == 40 and not texts[-1].strip()
views = []
with fitz.open(pdf) as d:
    for number, start in enumerate(range(1, 40, 2), 1):
        pages = list(range(start, min(start + 2, 40)))
        imgs = []
        for p in pages:
            pix = d[p-1].get_pixmap(matrix=fitz.Matrix(1.4, 1.4), alpha=False)
            imgs.append(Image.frombytes('RGB', [pix.width, pix.height], pix.samples))
        canvas = Image.new('RGB', (sum(i.width for i in imgs)+20, max(i.height for i in imgs)+38), 'white')
        draw = ImageDraw.Draw(canvas); x = 0
        for p, img in zip(pages, imgs):
            draw.text((x+8, 8), f'Qin arXiv v1: physical page {p}', fill='black')
            canvas.paste(img, (x, 30)); x += img.width + 20
        image_path = W / f'sheet_{number:02d}.png'; canvas.save(image_path)
        selected = W / f'sheet_{number:02d}.txt'
        selected.write_text('\n\n'.join(f'QIN ARXIV V1 PHYSICAL PAGE {p}\n' + texts[p-1] for p in pages))
        views.append(dict(number=number, physical_pages=pages, path=str(image_path), image_SHA256=sha(image_path),
            selected_text_path=str(selected), selected_text_SHA256=sha(selected), source_PDF_SHA256=sha(pdf),
            actually_viewed=False, selected_text_read=False))
manifest = W / 'manifest.json'; manifest.write_text(json.dumps(views, ensure_ascii=False, indent=2) + '\n')
(C / 'primary_notes_v2').mkdir()
obj = dict(UTC=datetime.now(timezone.utc).isoformat(), status='PREPARED — zero actual-reading credit',
    source=dict(path=str(pdf), requested_acquisition_URL='https://arxiv.org/pdf/2610.09295v1', exact_version='arXiv:2610.09295v1',
                submitted_UTC='2026-10-07 01:57:38', bytes=pdf.stat().st_size, SHA256=sha(pdf), physical_pages=39),
    preparation_text_path=str(text_path), preparation_text_SHA256=sha(text_path), prepared_unique_pages=39, prepared_views=20,
    manifest_path=str(manifest), manifest_SHA256=sha(manifest), frozen_case_failure_SHA256=sha(failure),
    actual_primary_reading_credit=0, mathematical_clearance=False, book_changed=False,
    helper_source=__file__, helper_SHA256=sha(__file__))
record.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(status=obj['status'], pages=39, views=20, preparation_SHA256=sha(record))))
