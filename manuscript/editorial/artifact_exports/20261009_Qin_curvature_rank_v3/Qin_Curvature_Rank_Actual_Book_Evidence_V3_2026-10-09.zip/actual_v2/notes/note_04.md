# Qin curvature-rank book review — view 4

Physical pages: [3229, 4418].

Read the complete selected text and displayed matching rendered image.

Read the complete provenance continuation on physical 3229 and the preceding Appendix L seam on 4418. Historical proof receipts remain tied to frozen proof objects; the real/rational toric arguments, I-sensitive obstruction and zero-volume problem stay distinct. The Seo Newton-domain comparison remains local and does not become a compact global body or mass formula. Appendix L retains the finite-spectrum extension example, maximal-apartment hypothesis and signed first-moment BE volume signature, with geometrically reduced projective data and stronger geometric-integrality hypothesis stated separately. The final incomplete sentence about the big-case field extension continues onto the next selected page. Both matching pages are legible without clipping or altered reference numbering.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
