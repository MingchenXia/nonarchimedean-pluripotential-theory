# Adapted frozen finalizer SHA256: 4d5b3b901bbc11c849238f1cd043aa02286eb8f0521a87531d6acb1e385951cd
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Chen_Maclean_spectral_distribution_review_20261009'
out=C/'actual_primary_reading_v1_20261009.json'
assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=C/'primary_view_preparation_v1_20261009.json'
prep=json.loads(p.read_text())
assert prep['actual_source_reading_credit']==prep['actually_read_pages']==0
assert sha(prep['source_PDF']['path'])==prep['source_PDF']['SHA256']
assert sha(prep['manifest_path'])==prep['manifest_SHA256']
rows=json.loads(Path(prep['manifest_path']).read_text())
views=[];pages=[];last=None
for i,row in enumerate(rows,1):
    receipt=C/f'primary_notes_v1/note_{i:02d}_receipt.json'
    a=json.loads(receipt.read_text())
    assert a['number']==i and a['physical_pages']==row['physical_pages']
    assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
    assert last is None or a['UTC']>last
    last=a['UTC']
    assert not row['actually_viewed'] and not row['selected_text_read']
    for k,h in [('image_path','image_SHA256'),('selected_text_path','selected_text_SHA256'),('note_path','note_SHA256')]:assert sha(a[k])==a[h]
    assert a['source_PDF_SHA256']==prep['source_PDF']['SHA256']==row['source_PDF_SHA256']
    assert 'Read the complete selected text and displayed matching rendered image.' in Path(a['note_path']).read_text()
    views.append(dict(batch=p.name,**a,observation_receipt_path=str(receipt),observation_receipt_SHA256=sha(receipt)))
    pages.extend(row['physical_pages'])
assert len(views)==14 and pages==list(range(1,28)) and len(set(pages))==27
for n,h in prep['protected_core_inputs'].items():assert sha(R/n)==h
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==prep['baseline_commit']
d=C/'exact_diagnostics_v1_20261009.json';diag=json.loads(d.read_text())
assert len(diag['families'])==9 and all(x['status'].startswith('PASS') for x in diag['families'])
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete pinned primary PDF actually read in order; qualified ordinary source audit',
    source_PDF=prep['source_PDF'],actual_source_unique_pages=27,actual_individually_displayed_matching_views=14,
    selected_physical_pages=pages,views=views,preparation_record_SHA256={p.name:sha(p)},exact_diagnostics_SHA256=sha(d),
    complete_selected_text_read=True,preparation_flags_unchanged=True,whole_primary_PDF_reading_claim=True,
    whole_book_new_reading_claim=False,active_book_changed=False,native_editor_changed=False,baseline_commit=prep['baseline_commit'],
    ordinary_importable_interfaces=['Non-Archimedean determinant degree and dimension-normalized spectral probabilities','Common near-orthogonal/diagonal approximation with correctly allocated losses','Exact max-norm truncation and stop-loss means, with degree scaling','Admissible-semigroup tail formula explicitly excluding critical theta','Clipped-mean argument with corrected union-tail bound and bounded paired difference'],
    general_main_theorem_accepted_as_recursively_complete=False,
    load_bearing_qualifications=['Complex determinant slopes equal half log Gram eigenvalues; ordinary complex Haar needs a half-log calibration','Hermitian displays need squared norms and absolute squares','Dimension-normalized polygons still require division by degree n','Earlier one-norm induction needs two smaller allocated losses','(32) needs sum and h composed with the concave transform','(33) intermediate correlated-tail inequality must be replaced by A times union probability','Integral/projective/regular rational-point and admissible-semigroup signature retained','o(n) perturbations handled through polygon Lipschitz, not mixed unprimed truncations'],
    earlier_inputs_not_recursively_certified=['Lazarsfeld–Mustata admissible-semigroup lattice filling/counts','Chambert-Loir 2002 pp205–206 non-Archimedean analytic coefficient bound','Chen 2010 polygon convergence proposition','Complex Berman–Boucksom energy/L2 comparison','General scalar-extension reduction to a regular rational-point setup'],
    published_2015_edition_audited=False,
    internal_footer_date='May 30, 2018; version remains arXiv1304.5842v3, 15 October 2013',
    general_local_weak_psh_or_affine_regularization_admitted=False,general_envelope_theorem_admitted=False,
    BJ22_Theorem_6_21_repaired=False,canonical_status_changes=[],original_results_promoted=[],independent_model_receipt=None,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],pages=27,views=14,record_SHA256=sha(out))))
