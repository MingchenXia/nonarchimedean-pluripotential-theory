# Frozen failed preflight helper SHA256: d6aeebe1d7b3659e8b63550df87557e9dddcfa630f549545c82d6cdcb6172a65
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,fitz,subprocess
from PIL import Image,ImageDraw
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Chen_Maclean_spectral_distribution_review_20261009'
W=Path('/tmp/CM15_primary_views_v1_20261009');N=C/'primary_notes_v1';out=C/'primary_view_preparation_v1_20261009.json';assert not any(p.exists() for p in [W,N,out]);sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((C/'primary_acquisition_v1_20261009.json').read_text());row=next(x for x in a['rows'] if x.get('path','').endswith('.pdf'));pdf=Path(row['path']);assert sha(pdf)==row['SHA256'];bookprep=json.loads((R/'source_material/Reboulet_asymptotic_FS_review_20261009/staging_preparation_v1_20261009.json').read_text());names=sorted(set(bookprep['other_active_TeX_preserved'])|{n for n in bookprep['after'] if n.endswith('.tex')});assert len(names)==425
names+=['manuscript/book.pdf','manuscript/bibliography/ComplexGeometry.bib','manuscript/bibliography/NonArchimedean.bib','output/open_problems_catalogue_2026-10-03.tex','output/open_problems_catalogue_2026-10-03.pdf','README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md'];protected={n:sha(R/n) for n in names}
W.mkdir();N.mkdir();views=[]
with fitz.open(pdf) as d:
 assert len(d)==27;selected=list(range(1,28))
 for i in range(0,len(selected),2):
  pp=selected[i:i+2];panels=[];texts=[]
  for n in pp:
   pix=d[n-1].get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False);panels.append(Image.frombytes('RGB',[pix.width,pix.height],pix.samples));texts.append(f'CHEN-MACLEAN ARXIV 1304.5842v3 PRIMARY PHYSICAL PAGE {n}\n'+d[n-1].get_text())
  canvas=Image.new('RGB',(sum(p.width for p in panels),max(p.height for p in panels)+28),'white');draw=ImageDraw.Draw(canvas);x=0
  for n,panel in zip(pp,panels):draw.text((x+8,8),f'Chen-Maclean 1304.5842v3 physical {n}',fill='black');canvas.paste(panel,(x,28));x+=panel.width
  number=i//2+1;ip=W/f'sheet_{number:02d}.png';tp=W/f'sheet_{number:02d}.txt';canvas.save(ip);tp.write_text('\n\n'.join(texts));views.append(dict(number=number,physical_pages=pp,path=str(ip),image_SHA256=sha(ip),selected_text_path=str(tp),selected_text_SHA256=sha(tp),source_PDF_SHA256=sha(pdf),actually_viewed=False,selected_text_read=False))
mp=W/'manifest.json';mp.write_text(json.dumps(views,ensure_ascii=False,indent=2)+'\n')
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete primary views prepared; zero reading credit',source_PDF=dict(path=str(pdf),bytes=pdf.stat().st_size,SHA256=sha(pdf),physical_pages=27),acquisition_SHA256=sha(C/'primary_acquisition_v1_20261009.json'),selected_physical_pages=selected,prepared_pages=27,prepared_views=14,manifest_path=str(mp),manifest_SHA256=sha(mp),protected_core_inputs=protected,baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),actual_source_reading_credit=0,actually_read_pages=0,active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='DONE',prepared_pages=27,prepared_views=14,record_SHA256=sha(out))))
