# Frozen failed builder SHA256: 885a5a647f8144f9756cbd32f9cc46aee4613a0cc6e92d9d760444ccbd53f3b9
from pathlib import Path
import hashlib
old=Path('/tmp/Reboulet_asymptotic_FS_export_source_v1_20261009.py');p=Path('/tmp/CM15_export_source_v1_20261009.py');assert not p.exists();t=old.read_text();top=t[:t.index("(dest/'README.md').write_text")];tail=t[t.index('published=[*paths.values()'):]
for a,b in [('Reboulet_asymptotic_FS_review_20261009','Chen_Maclean_spectral_distribution_review_20261009'),('Reboulet_asymptotic_FS_source_','CM15_spectral_distribution_source_'),('Reboulet_Asymptotic_FS_','Chen_Maclean_Spectral_Distribution_'),('20261009_Reboulet_asymptotic_FS_sources','20261009_CM15_spectral_distribution_sources'),('actual_source_unique_pages\']==43','actual_source_unique_pages\']==27'),('actual_individually_displayed_matching_views\']==22','actual_individually_displayed_matching_views\']==14'),("len(diag['families'])==13","len(diag['families'])==9"),('Reboulet_asymptotic_FS_source_review_draft_v1_20261009.md','CM15_source_review_draft_v1_20261009.md'),('Actual Reboulet asymptotic FS source notes','Actual Chen-Maclean spectral distribution source notes'),('Complete pinned v1: 43 physical pages in 22 individually displayed matching views.','Complete pinned v3: 27 physical pages in 14 individually displayed matching views.'),('Reboulet_2004.11635v1.pdf','Chen_Maclean_1304.5842v3.pdf'),('Reboulet_2004.11635v1.txt','Chen_Maclean_1304.5842v3.txt'),('actual_primary_pages=43,actual_matching_views=22','actual_primary_pages=27,actual_matching_views=14')]:top=top.replace(a,b);tail=tail.replace(a,b)
top=top.replace("for p in Path('/tmp').glob('Reboulet_asymptotic_FS_*_v1_20261009.py'):","for p in sorted(Path('/tmp').glob('CM15_*_v*_20261009.py')):")
top=top.replace("files[f'drafts/{draft.name}']=draft", "files['helpers/CM15_Reboulet_filtrations_acquire_primaries_v1_20261009.py']=Path('/tmp/CM15_Reboulet_filtrations_acquire_primaries_v1_20261009.py')\nfiles[f'drafts/{draft.name}']=draft")
top=top.replace("archive(full,fullfiles)","fullfiles['primary/Chen_Maclean_1304.5842v3.abs.html']=C/'Chen_Maclean_1304.5842v3.abs.html'\narchive(full,fullfiles)")
middle=r'''(dest/'README.md').write_text(f"""# Chen–Maclean spectral primary checkpoint, 9 October 2026

All 27 physical pages of arXiv:1304.5842v3 were actually read in order
with complete text, fourteen individual matching image displays and
chronological notes/receipts. Nine elementary diagnostic families retain
complex Haar/determinant and Gram factors, squared norm formulas,
degree-scaled polygons, near-orthogonal loss allocation, exact
non-Archimedean truncation, critical-tail exclusion, corrected paired-tail
bounds, sublinear perturbations and actual rational-point/lattice scope.
The useful non-Archimedean clipped-mean proof does not subtract infinite
marginal expectations. Its coefficient/lattice inputs remain attributed.
The 2015 published edition has not been audited; the pinned PDF's internal
May 30, 2018 footer is recorded separately from arXiv version metadata.

The {len(files)}-member authored archive pins notes, receipts, diagnostics,
records, helpers and source audit. The separate {len(fullfiles)}-member
cloud archive also preserves external PDF, text, images and metadata HTML.
Only authored evidence is in this GitHub checkpoint. Preparation/export/
upload supply zero reading credit. The failed initial core-list preflight
created no views; fresh v2 uses the validated 425-input core and passes.

The 4,661-page book, all core inputs, bibliographies, native editor and
42 atoms/twelve problem statuses remain unchanged. General BJ22 critical
homogeneous Siu/envelopes remain OPEN and LPWZ density UNVERIFIED; the
BJ22 Theorem 6.21 proof warning remains binding. No original general
theorem, independent-model receipt or new complete whole-book pass is
claimed. Remote publication receives a separate later verification record.
""")
readme=R/'README.md';s=readme.read_text();marker='**Latest verified graded-norm and upper semicontinuous FS GitHub publication, 9 October 2026:**';assert s.count(marker)==1
intro="""**Latest Chen–Maclean spectral primary checkpoint, 9 October 2026:**
the [complete source audit](manuscript/editorial/CM15_spectral_distribution_source_review_20261009.md)
reads all 27 pages of arXiv:1304.5842v3 in fourteen individual matching
displays. Nine elementary diagnostic families check spectral/probability
and polygon degree conventions, near-orthogonal loss allocation, exact
non-Archimedean truncation and bounded paired-tail estimates. The
[authored evidence](manuscript/editorial/artifact_exports/20261009_CM15_spectral_distribution_sources/README.md)
retains actual notes/receipts. Regular rational-point, admissible-lattice
and coefficient-estimate dependencies stay explicit. The 2015 published
edition is not claimed audited. Book, native editor and canonical statuses
stay unchanged; export/upload supply zero reading credit.

""";readme.write_text(s.replace(marker,intro+marker,1))
programme=E/'second_reading_and_research_programme_20261002.md';s=programme.read_text();marker='## Latest graded-norm and upper semicontinuous FS GitHub publication, 9 October 2026\n';assert s.count(marker)==1
intro="""## Latest Chen–Maclean spectral source checkpoint, 9 October 2026

The [complete source audit](CM15_spectral_distribution_source_review_20261009.md)
reads all 27 pages of arXiv:1304.5842v3 with fourteen individual matching
image displays, complete selected text and chronological notes. Nine
exact elementary diagnostic families pass. The initial tracked/core TeX
list mismatch failed before any view preparation and is frozen; fresh v2
uses the actual validated 425-input book core. The pinned PDF's internal
May 30, 2018 footer differs from its arXiv version stamp and is separately
recorded. The 2015 published edition is not claimed audited.

The non-Archimedean proof uses determinant degree, common diagonal
approximations, exact max-norm truncation, admissible semigroups and
bounded-variable stop-loss means. It explicitly excludes the critical
tail endpoint and clips negative marginal tails before taking paired
mean differences. The middle correlated-tail bound is replaced by the
correct A times union probability, retaining its needed final estimate.
Complex Haar/Gram calibration, squared norm displays, the omitted degree
division in polygon statement 5.2(2) and the earlier one-norm loss
allocation remain explicit corrections. No intended correctly formulated
spectral theorem is declared false. Lattice counts, the actual
Chambert-Loir coefficient source and regular rational-point reductions
remain separate external inputs.

The [owned archive](artifact_exports/20261009_CM15_spectral_distribution_sources/README.md)
pins the audit and reading evidence; the cloud archive additionally holds
external primary PDF/text/images. Export/upload add zero credit. The
4,661-page book, all 425 core TeX inputs, bibliographies, native editor,
42 atoms/twelve problem statuses and 4 October complete ordered pass stay
unchanged. General BJ22 critical homogeneous Siu/envelopes remain OPEN,
LPWZ density UNVERIFIED; BJ22 Theorem 6.21 proof warning remains binding.
No original general theorem or independent-model receipt is claimed.

Continue cloud-only with the actual coefficient/lattice primary inputs,
the later published comparison editions and Reboulet arXiv2508.16322v2
of 3 March 2026. Its downloaded 39 pages have zero reading credit until
actually inspected. Check incoming author updates and regularly push
verified authored evidence. Xean stays suspended.

""";programme.write_text(s.replace(marker,intro+marker,1))
'''
p.write_text('# Adapted frozen exporter SHA256: '+hashlib.sha256(old.read_bytes()).hexdigest()+'\n'+top+middle+tail);compile(p.read_text(),str(p),'exec');print(p)
