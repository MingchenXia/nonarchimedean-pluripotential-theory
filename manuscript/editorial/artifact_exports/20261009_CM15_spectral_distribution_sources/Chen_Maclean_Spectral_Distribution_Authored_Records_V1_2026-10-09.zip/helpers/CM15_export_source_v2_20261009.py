# Frozen preceding exporter SHA256: fbb7869a6edc2ac3ae11e808b4823caa50095251604f331ea3be7fb74b4909a0
# Adapted frozen exporter SHA256: ece3f0782320f944511e05e44b6a1a2f1e8889d66c98778059523c6d9507b4ac
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, zipfile

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Chen_Maclean_spectral_distribution_review_20261009'
E=R/'manuscript/editorial'
O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
reading=json.loads((C/'actual_primary_reading_v1_20261009.json').read_text())
diag=json.loads((C/'exact_diagnostics_v1_20261009.json').read_text())
assert reading['actual_source_unique_pages']==27 and reading['actual_individually_displayed_matching_views']==14
assert len(diag['families'])==9 and reading['whole_primary_PDF_reading_claim']
for name,h in reading['preparation_record_SHA256'].items():
    prep=json.loads((C/name).read_text());assert sha(C/name)==h
    for n,pin in prep['protected_core_inputs'].items():assert sha(R/n)==pin
paths={k:E/f'CM15_spectral_distribution_source_{k}_20261009.{ext}' for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
record=C/'source_checkpoint_v1_20261009.json'
owned=O/'Chen_Maclean_Spectral_Distribution_Authored_Records_V1_2026-10-09.zip'
full=O/'Chen_Maclean_Spectral_Distribution_Actual_Source_Evidence_V1_2026-10-09.zip'
dest=E/'artifact_exports/20261009_CM15_spectral_distribution_sources'
assert not any(p.exists() for p in [*paths.values(),record,owned,full,dest])
draft=Path('/tmp/CM15_source_review_draft_v1_20261009.md')
paths['review'].write_bytes(draft.read_bytes());assert sha(paths['review'])==sha(draft)
paths['reading_notes'].write_text('# Actual Chen-Maclean spectral distribution source notes, 9 October 2026\n\nComplete pinned v3: 27 physical pages in 14 individually displayed matching views.\n'+''.join('\n---\n\n'+Path(v['note_path']).read_text() for v in reading['views']))
files={f'records/{p.name}':p for p in C.glob('*.json')}
for v in reading['views']:
    for k,folder in [('note_path','notes'),('observation_receipt_path','receipts')]:
        p=Path(v[k]);files[f'primary/{folder}/{p.name}']=p
files['manifests/manifest.json']=Path(prep['manifest_path'])
for p in sorted(Path('/tmp').glob('CM15_*_v*_20261009.py')):files[f'helpers/{p.name}']=p
files['helpers/CM15_Reboulet_filtrations_acquire_primaries_v1_20261009.py']=Path('/tmp/CM15_Reboulet_filtrations_acquire_primaries_v1_20261009.py')
files[f'drafts/{draft.name}']=draft
for k in ['review','reading_notes']:files[f'editorial/{paths[k].name}']=paths[k]
def archive(target,entries):
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,p in sorted(entries.items()):z.write(p,n)
    with zipfile.ZipFile(target) as z:
        assert len(z.namelist())==len(entries)
        for n,p in entries.items():assert z.read(n)==p.read_bytes()
archive(owned,files)
fullfiles=dict(files)
fullfiles['primary/Chen_Maclean_1304.5842v3.pdf']=Path(reading['source_PDF']['path'])
fullfiles['primary/Chen_Maclean_1304.5842v3.txt']=C/'Chen_Maclean_1304.5842v3.txt'
for v in reading['views']:
    for k,folder in [('image_path','images'),('selected_text_path','text')]:
        p=Path(v[k]);fullfiles[f'primary/{folder}/{p.name}']=p
fullfiles['primary/Chen_Maclean_1304.5842v3.abs.html']=C/'Chen_Maclean_1304.5842v3.abs.html'
archive(full,fullfiles)
artifacts={k:dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p),members=count) for k,p,count in [('authored_records_archive',owned,len(files)),('cloud_complete_source_evidence_archive',full,len(fullfiles))]}
paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete pinned primary reading and qualified ordinary source audit',actual_reading=reading,exact_diagnostics=diag,artifacts=artifacts,active_book_changed=False,native_editor_changed=False,GitHub_published=False,canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — byte-verified source exports',artifacts=artifacts,reading_credit_from_export=0,external_primary_PDF_text_images_uploaded=False,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
dest.mkdir(parents=True)
target=dest/owned.name;shutil.copyfile(owned,target);assert sha(target)==sha(owned)
(dest/'SHA256SUMS').write_text(sha(target)+'  '+target.name+'\n')
(dest/'README.md').write_text(f"""# Chen–Maclean spectral primary checkpoint, 9 October 2026

All 27 physical pages of arXiv:1304.5842v3 were actually read in order
with complete text, fourteen individual matching image displays and
chronological notes/receipts. Nine elementary diagnostic families retain
complex Haar/determinant and Gram factors, squared norm formulas,
degree-scaled polygons, near-orthogonal loss allocation, exact
non-Archimedean truncation, critical-tail exclusion, corrected paired-tail
bounds, sublinear perturbations and actual rational-point/lattice scope.
The useful non-Archimedean clipped-mean proof does not subtract infinite
marginal expectations. Its coefficient/lattice inputs remain attributed.
The 2015 published edition has not been audited; the pinned PDF's internal
May 30, 2018 footer is recorded separately from arXiv version metadata.

The {len(files)}-member authored archive pins notes, receipts, diagnostics,
records, helpers and source audit. The separate {len(fullfiles)}-member
cloud archive also preserves external PDF, text, images and metadata HTML.
Only authored evidence is in this GitHub checkpoint. Preparation/export/
upload supply zero reading credit. The failed initial core-list preflight
created no views; fresh v2 uses the validated 425-input core and passes.

The 4,661-page book, all core inputs, bibliographies, native editor and
42 atoms/twelve problem statuses remain unchanged. General BJ22 critical
homogeneous Siu/envelopes remain OPEN and LPWZ density UNVERIFIED; the
BJ22 Theorem 6.21 proof warning remains binding. No original general
theorem, independent-model receipt or new complete whole-book pass is
claimed. Remote publication receives a separate later verification record.
""")
readme=R/'README.md';s=readme.read_text();marker='**Latest verified graded-norm and upper semicontinuous FS GitHub publication, 9 October 2026:**';assert s.count(marker)==1
intro="""**Latest Chen–Maclean spectral primary checkpoint, 9 October 2026:**
the [complete source audit](manuscript/editorial/CM15_spectral_distribution_source_review_20261009.md)
reads all 27 pages of arXiv:1304.5842v3 in fourteen individual matching
displays. Nine elementary diagnostic families check spectral/probability
and polygon degree conventions, near-orthogonal loss allocation, exact
non-Archimedean truncation and bounded paired-tail estimates. The
[authored evidence](manuscript/editorial/artifact_exports/20261009_CM15_spectral_distribution_sources/README.md)
retains actual notes/receipts. Regular rational-point, admissible-lattice
and coefficient-estimate dependencies stay explicit. The 2015 published
edition is not claimed audited. Book, native editor and canonical statuses
stay unchanged; export/upload supply zero reading credit.

""";readme.write_text(s.replace(marker,intro+marker,1))
programme=E/'second_reading_and_research_programme_20261002.md';s=programme.read_text();marker='## Latest graded-norm and upper semicontinuous FS GitHub publication, 9 October 2026\n';assert s.count(marker)==1
intro="""## Latest Chen–Maclean spectral source checkpoint, 9 October 2026

The [complete source audit](CM15_spectral_distribution_source_review_20261009.md)
reads all 27 pages of arXiv:1304.5842v3 with fourteen individual matching
image displays, complete selected text and chronological notes. Nine
exact elementary diagnostic families pass. The initial tracked/core TeX
list mismatch failed before any view preparation and is frozen; fresh v2
uses the actual validated 425-input book core. The pinned PDF's internal
May 30, 2018 footer differs from its arXiv version stamp and is separately
recorded. The 2015 published edition is not claimed audited.

The non-Archimedean proof uses determinant degree, common diagonal
approximations, exact max-norm truncation, admissible semigroups and
bounded-variable stop-loss means. It explicitly excludes the critical
tail endpoint and clips negative marginal tails before taking paired
mean differences. The middle correlated-tail bound is replaced by the
correct A times union probability, retaining its needed final estimate.
Complex Haar/Gram calibration, squared norm displays, the omitted degree
division in polygon statement 5.2(2) and the earlier one-norm loss
allocation remain explicit corrections. No intended correctly formulated
spectral theorem is declared false. Lattice counts, the actual
Chambert-Loir coefficient source and regular rational-point reductions
remain separate external inputs.

The [owned archive](artifact_exports/20261009_CM15_spectral_distribution_sources/README.md)
pins the audit and reading evidence; the cloud archive additionally holds
external primary PDF/text/images. Export/upload add zero credit. The
4,661-page book, all 425 core TeX inputs, bibliographies, native editor,
42 atoms/twelve problem statuses and 4 October complete ordered pass stay
unchanged. General BJ22 critical homogeneous Siu/envelopes remain OPEN,
LPWZ density UNVERIFIED; BJ22 Theorem 6.21 proof warning remains binding.
No original general theorem or independent-model receipt is claimed.

Continue cloud-only with the actual coefficient/lattice primary inputs,
the later published comparison editions and Reboulet arXiv2508.16322v2
of 3 March 2026. Its downloaded 39 pages have zero reading credit until
actually inspected. Check incoming author updates and regularly push
verified authored evidence. Xean stays suspended.

""";programme.write_text(s.replace(marker,intro+marker,1))
published=[*paths.values(),*sorted(dest.iterdir()),readme,programme]
assert len(published)==9
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete primary checkpoint and byte-verified authored artifacts exported',editorial_files={str(p.relative_to(R)):dict(SHA256=sha(p),bytes=p.stat().st_size) for p in published},artifacts=artifacts,actual_primary_pages=27,actual_matching_views=14,active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],GitHub_published=False,helper_source=__file__)
record.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],files=9,owned_members=len(files),cloud_members=len(fullfiles),record_SHA256=sha(record))))
