# Chen-Maclean spectral distribution actual primary view 02

UTC: 2026-10-09T02:53:24.181497+00:00. Physical pages: 3, 4.

Read the complete selected text and displayed matching rendered image.

The main introduction now explicitly rescales the random variable by n and divides the spectral measure by h0. It requires a big line bundle, projective variety of dimension at least one and continuous metrics; general graded systems must satisfy the later three conditions. The complex Hermitian approximants are at logarithmic operator distance o(n) from sup norms. The introductory wording about Hermitian approximants cannot itself define the non-Archimedean analogue; section 3 must supply that formalism. Equation (3) identifies ordinary complex Haar unit-ball log-volume ratio with the logarithmic determinant norm ratio. In complex dimension one these differ by a factor two under the stated ordinary norm/Haar convention; the next definition must be checked before importing any energy normalization. The source's own degree-rescaled main convergence statement is unaffected by merely diagnosing that normalization. Truncation Propositions 2.8/3.8 and semigroup Theorem 4.5 are identified as the actual proof interfaces. Both full pages, including footnote defining the operator distance with absolute values, were reviewed and render clearly.
