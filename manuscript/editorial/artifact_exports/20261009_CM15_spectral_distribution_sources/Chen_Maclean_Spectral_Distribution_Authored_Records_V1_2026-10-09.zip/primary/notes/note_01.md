# Chen-Maclean spectral distribution actual primary view 01

UTC: 2026-10-09T02:53:07.827481+00:00. Physical pages: 1, 2.

Read the complete selected text and displayed matching rendered image.

The pinned file is arXiv:1304.5842v3, 15 October 2013, by Huayi Chen and Catriona MacLean, 27 physical pages. The introduction requires a big line bundle and retains vol(L)=lim h0/(n^d/d!). It distinguishes a complex projective setup from a complete non-Archimedean alternative; the non-Archimedean argument must be checked in its own section. Page 2 gives an equilibrium-energy display, the L2 integral convention, unit-ball Haar volumes and the introductory probability normalization by section dimension. Its introductory eigenvalue discussion has not yet explicitly divided weights by degree; the final theorem and finite-dimensional sign/factor conventions still require checking, so this is not accepted as an unqualified normalization input. The envelope and Berman–Boucksom energy assertions are cited external foundations. Both complete rendered pages are legible; all expressions and footers are visible. No theorem/proof credit is inferred from the abstract.
