# Chen-Maclean spectral distribution actual primary view 07

UTC: 2026-10-09T02:55:12.015866+00:00. Physical pages: 13, 14.

Read the complete selected text and displayed matching rendered image.

Proposition 3.4 proves alpha-orthogonality of the dual using the concrete inverse bound ||e_i^vee||<=alpha^-1/||e_i||. Proposition 3.5 gives the product alpha^2 bound for the operator tensor norm; its lower estimate follows directly by testing dual basis vectors. The determinant norm is the quotient from the r-fold tensor product, with Hadamard upper bound and alpha^r lower bound; the footnote explicitly uses the alternating-coordinate sum and an absolute-value-at-least-one coefficient. Near-orthogonal bases with losses tending to zero establish exact degree additivity for subquotient flags, without assuming all norms split. Section 3.2 consistently defines non-Archimedean degree by determinant ratios rather than Haar volumes and probability by dimension-normalized polygon slopes. Consequently the preceding complex factor-two problem is not an automatic defect of this separately defined non-Archimedean convention. The formal near-orthogonal-basis argument still requires the corrected allocation of losses identified in the previous view. Both complete pages and the lengthy determinant footnote render legibly; no source page is omitted.
