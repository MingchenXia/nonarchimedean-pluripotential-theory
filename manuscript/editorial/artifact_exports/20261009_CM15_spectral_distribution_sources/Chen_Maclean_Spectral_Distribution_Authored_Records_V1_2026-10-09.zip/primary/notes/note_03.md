# Chen-Maclean spectral distribution actual primary view 03

UTC: 2026-10-09T02:53:43.637088+00:00. Physical pages: 5, 6.

Read the complete selected text and displayed matching rendered image.

Section 2.1 defines the finite-dimensional complex degree as log determinant-psi minus log determinant-phi, with no square or half-volume convention. This confirms that introductory ordinary complex Haar log-volume identity (3) needs a factor two. Proposition 2.1's maximal-ratio eigenspace is mathematically standard; the printed parallelogram equalities omit the squares on all norm terms. For standard Euclidean e1/e2, the unsquared identity reads 2 sqrt(2)=4 and is false. Using squared norms and lambda squared gives the intended eigenspace argument, so this diagnoses a displayed proof step rather than disproving the proposition. The bottom determinant-map sentence also reverses the displayed operator direction: lambda controls phi-to-psi, not psi-to-phi. Page 6 carefully builds the successive maximal-slope quotient filtration, weighted probabilities, concave polygon and normalized polygon on [0,1]. It explicitly warns that this two-norm filtration is not functorial; no adelic/graded-filtration functoriality is imported automatically. The polygon slopes sum to degree with dimension weighting as required. Full expressions and superscripts were visually checked on both pages.
