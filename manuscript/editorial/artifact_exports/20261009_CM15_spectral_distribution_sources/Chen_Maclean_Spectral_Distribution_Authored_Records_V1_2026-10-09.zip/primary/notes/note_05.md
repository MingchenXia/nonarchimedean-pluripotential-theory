# Chen-Maclean spectral distribution actual primary view 05

UTC: 2026-10-09T02:54:21.756544+00:00. Physical pages: 9, 10.

Read the complete selected text and displayed matching rendered image.

Proposition 2.7 compares degrees along a flag using John/Löwner Hermitian approximations with sqrt(r) norm bounds; the approximation is an attributed external ellipsoid input. Its constants use the determinant/half-Haar convention, so the unresolved full-Haar mismatch must not be ignored. Proposition 2.8 introduces the correct pointwise maximum of norms and scaling phi(a)=e^a phi, then relates the truncated degree to sum max(mu_i,a) up to O(r log r). Its concave-polygon Legendre identity is direct and correctly represents a finite list of decreasing slopes, aside from a j/i index typo inside a partial sum. The Hermitian comparison constructs the diagonal norm with coefficients max(lambda_i^2,e^(2a)) and a sqrt(2) comparison. The displayed sums use x_i^2 for complex coefficients; literal complex norm formulas require |x_i|^2. The scalar C example phi=psi=standard, a=1 shows that retaining full Haar degree while using threshold a makes the literal truncation error fail (2 versus 1, exceeding half log 2). This diagnoses the normalization interface; with half-Haar degree the intended direct construction is consistent. The image confirms all these powers and the full proof seam.
