# Parseval and raw FS book review — view 8

Physical pages: [4414, 4415].

Read the complete selected text and displayed matching rendered image.

The L.100 continuation on physical page 4414 completes the finite-spectral-function example with a common bounded finite-spectral interval, distinguishes finite-p vanishing from persistent infinity outliers, and keeps the revised RWN arXiv edition distinct from its unread published edition. It retains the norm/ray scaling cautions and the maximal-apartment requirement, including the scalar factor and the rank-one example. The relative-volume subsection begins with the complete-valued-field/geometrically-reduced signature and adds geometric integrality for the theorem. Page 4415 completes that subsection: the algebraically closed extension comes before rational Okounkov leaves, the two leaf logarithms are separately superadditive, the determinant and probability means differ by vol(L), and the trivial-field/nonpure-scheme diagnostics concern the displayed proof interfaces rather than contradicting the leading-order theorem. The final content page contains the full normalization display and several substantive paragraphs; it is not an orphan closing fragment. Both rendered pages have adequate margins, intact formulas and no collision.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
