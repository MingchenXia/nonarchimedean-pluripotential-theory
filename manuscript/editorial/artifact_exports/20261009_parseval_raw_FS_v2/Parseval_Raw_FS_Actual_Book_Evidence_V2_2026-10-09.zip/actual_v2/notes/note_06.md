# Parseval and raw FS book review — view 6

Physical pages: [4410, 4411].

Read the complete selected text and displayed matching rendered image.

The L.98 continuation on physical page 4410 uses finite anchored integrals and uniform approximation, keeping the minus-log convention and the BJ22 Theorem 6.21/open-envelope boundary explicit. L.99 begins on the same page with its exact forty-three-page Reboulet arXiv-v1 provenance. Its continuation on page 4411 keeps the probability normalization 1/N_m, signed versus absolute means, and the factor r under regrading distinct. The P1 penalized constant-coefficient example verifies bounded submultiplicativity, d1/m=a/(m+1) tending to zero and d-infinity/m=a, without promoting an asymptotic quotient theorem. The matching rendering has legible formulas and heading spacing. The raw FS calculation begins at the foot of page 4411 with its frame and reference convention and continues on the next selected page, without an orphan display or lost qualification.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
