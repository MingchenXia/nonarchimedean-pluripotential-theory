# Parseval and raw FS book review — view 7

Physical pages: [4412, 4413].

Read the complete selected text and displayed matching rendered image.

Physical page 4412 contains the complete new attribution within L.99: after the explicit bounded P1 raw-FS downward jump and Q versus Q-star calculation, it identifies the algebraically closed trivially valued specialization, shifted and scaled, with BJKS1 Example 2.21. The attribution does not enlarge the field signature of the primary source or turn the worked example into a general quotient proof. Physical page 4413 opens L.100 with the controlling published forty-seven-page Finski edition and the now-actually-read Section 4/Parseval input; external extension and Darvas inputs stay separate. Its new canonical-FS paragraph states projective reduced irreducible X, algebraically closed trivially valued field and ample Q-line bundle; distinguishes bounded lower semicontinuous raw FS from its upper regularization; and preserves the L-psh premise of BJKS1 Lemma 6.17(iii), full versus weak envelope inputs, and the BJ22/addendum dependency warning. Cross-references resolve to Sections 65.19 and L.99. Both rendered pages are complete, readable, and retain the old formal numbering.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
