# Parseval and raw FS book review — view 10

Physical pages: [4625, 4626].

Read the complete selected text and displayed matching rendered image.

Read the complete first two index pages, physical 4625–4626 (printed 4547–4548). The A/B/C ordering, hanging subentries, continued Berkovich-line entries across the page boundary, two-column layout and links are legible. The apartment/maximal-system entry points to the beginning of the L.100 discussion at printed 4335; neighbouring late-book entries correctly carry their shifted page numbers. No column overlap, clipped page number, broken alphabetical transition or missing index heading is visible. The new FS/tensor entries occur later in the ordered index and are reviewed in their own matching views.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
