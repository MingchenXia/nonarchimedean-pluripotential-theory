# Parseval and raw FS book review — view 2

Physical pages: [3512, 3513].

Read the complete selected text and displayed matching rendered image.

Read both complete selected pages and matching rendered image. The six historical comparison boundaries and the complete source note retain their proof domains and quarantine. The new material remains inside existing 65.19 after that note, preserving the implicit old Source note label. Finite exhaustive separated filtration, scalar invariance and genuine complex norm are visible before the sum-envelope definition; decompositions exclude zero pieces and positivity comes from the finite weight range. The largest-norm-below-gauge explanation and the adapted quadratic Hermitian ray are readable without missing factors. The quadratic formula fits the bottom of printed 3435 and continues coherently onto the next page. Historical theorem/section references are rendered with their preserved numbers; no extension of the MP/MA comparison or full Kähler domain is inferred.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
