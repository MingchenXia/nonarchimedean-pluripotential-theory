from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile, shutil, fitz

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BJKS1_Finski_dependencies_review_20261009'
S=Path('/workspace/book-completion-drafts/parseval-raw-FS-staging-v2-20261009')
E=R/'manuscript/editorial';O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
prep=load('staging_preparation_v2_20261009.json')
release=load('staged_book_release_checks_v2_20261009.json')
reading=load('actual_staged_book_reading_v2_20261009.json')
post=load('post_render_checks_v2_20261009.json')
math=load('staged_mathematical_self_audit_v2_20261009.json')
under=load('staged_underfull_delta_v2_20261009.json')
assert reading['status'].startswith('DONE') and not reading['remaining_repairs']
assert reading['actual_unique_book_pages']==31 and reading['fresh_matching_views']==16
assert all(x['returncode']==0 for x in post['checks'])
assert not under['added_blocks'] and not under['removed_blocks']
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['before'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
assert sha(release['PDF']['path'])==release['PDF']['SHA256']==reading['PDF']['SHA256']
record=C/'staged_export_v2_20261009.json'
paths={k:E/f'parseval_raw_FS_staged_integration_{k}_v2_20261009.{ext}'
       for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
full=O/'Non-Archimedean_Pluripotential_Theory_Parseval_Raw_FS_V2_2026-10-09.pdf'
review=O/'Parseval_Raw_FS_Actual_Book_Review_V2_2026-10-09.pdf'
minimal=O/'Parseval_Raw_FS_Minimal_Source_V2_2026-10-09.zip'
evidence=O/'Parseval_Raw_FS_Actual_Book_Evidence_V2_2026-10-09.zip'
dest=E/'artifact_exports/20261009_parseval_raw_FS_v2'
assert not any(p.exists() for p in [record,*paths.values(),full,review,minimal,evidence,dest])
shutil.copyfile(release['PDF']['path'],full);assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as book:
    d=fitz.open()
    for n in release['selected_book_physical_pages']:d.insert_pdf(book,from_page=n-1,to_page=n-1)
    assert len(d)==31
    d.set_metadata(dict(title='Fixed-variable Parseval and raw/canonical FS — actual selected book review',
        subject='31 actual selected physical pages in 16 matching views, including 2 blank versos. Export supplies zero reading credit.'))
    d.save(review,garbage=4,deflate=True);d.close()
audit_text='''# Fixed-variable Parseval and canonical FS book integration, 9 October 2026

The checked 4,667-page book adds a complete fixed-variable Parseval
explanation to Chapter 65.19. The symmetric coefficient-sum quotient,
normalized complex-torus integral and sqrt(D_k) comparison are written
with fixed rank and the correct degree asymptotic. This is an attributed
finite calculation, not a full-tensor equality or a dimension-uniform bound.
The original holomorphic extension input keeps its own assumptions.

L.99 identifies the shifted/scaled P1 raw-FS example with published
BJKS1 Example 2.21 in its algebraically closed trivially valued scope.
L.100 separates raw lower-semicontinuous FS from upper regularization,
states the psh-membership premise of Lemma 6.17(iii), and distinguishes
full from weak envelope inputs. The Finski bibliography note records the
complete 47-page published-source reading and Remark 4.3 locator.
Original BBJ21, extension, Okounkov and BJ22/addendum proofs are separate
dependencies. No Siu proof repair or original general theorem is claimed.

The frozen Finski source audit is complete: 47 physical pages/24 matching
views across two ordered checkpoints. The published BJKS1 source audit
is partial: 50 of 100 physical pages/25 views. This book integration does
not add primary reading or recursively certify either source's references.

All 31 selected final book pages were actually read in 16 individually
displayed matching text/image views with chronological notes. The review
includes the changed sections and their seams, contents, all 12 index
pages and the complete updated bibliography entry. Two blank versos are
identified separately; they supply no additional mathematical-content
credit. The last complete ordered whole-book pass remains 4 October.
Preparation flags remain false and the actual receipts are separate.

Required validation and the six existing tests pass. The final log has
zero TeX errors, LaTeX/package/pdfTeX warnings, missing glyphs, overfull
boxes, unresolved references/citations or rerun requests. All 955 inherited
underfull blocks have identical normalized content and multiplicities.
All 13,382 prior numbered values, 599 prior bibliography labels and 2,765
TOC titles/hierarchies are retained. No new semantic label or source key
is added. All 898 index entries are accepted without warning/rejection;
two index terms are added. All 48,760 internal links resolve. The 172
external URL links are recorded, without certifying their availability.

The two changed TeX roots preserve all 51 historical formal blocks and
92 manual equation tags, adding none. The other 423 core TeX inputs and
the non-Archimedean bibliography are unchanged. ComplexGeometry.bib
changes only the existing Fin25SM note. The first isolated stage failed
reference preflight at a mistaken L.99 label before TeX; its draft, source,
log and record are frozen. Fresh v2 fixes that reference and passes all
gates. No compiled-PDF or actual-reading credit is assigned to v1.

The native catalogue/editor, 42 atoms/twelve formal problems and canonical
statuses are preserved. BJ22 critical homogeneous Siu/general envelopes
remain OPEN, LPWZ density UNVERIFIED, and the BJ22 Theorem 6.21 warning
binding. Activation/publication get separate later records. Export and
upload supply zero reading credit; no independent-model receipt is claimed.

The scoped mathematical checks are:

'''+''.join(f'{i}. {a}\n\n' for i,a in enumerate(math['checks'],1))
paths['audit'].write_text(audit_text.rstrip()+'\n')
paths['reading_notes'].write_text(('# Actual Parseval/raw-FS book reading, 9 October 2026\n\n31 complete selected physical pages in 16 individually displayed matching views, including 2 explicitly recorded blank versos. This is scoped actual reading, not a complete new book pass.\n'+''.join('\n---\n\n'+Path(x['sequential_note_path']).read_text() for x in reading['views'])).rstrip()+'\n')
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md'
marker='**Latest selected BJKS1 dependency source checkpoint, 9 October 2026:**'
p=S/'README.md';s=p.read_text();assert s.count(marker)==1
intro='''**Latest checked Parseval/raw-FS book integration, 9 October 2026:**
the [integration audit](manuscript/editorial/parseval_raw_FS_staged_integration_audit_v2_20261009.md)
records the 4,667-page edition: fixed-variable symmetric Parseval in
Chapter 65.19, BJKS1 attribution of L.99's P1 example, and the canonical
FS psh-membership gate in L.100. All 31 selected physical pages were
read in 16 matching views, including two explicit blank versos and the
complete index. Required validation and post-render checks pass; all
13,382 old numbered values and 599 citation labels are preserved.
The [owned artifacts](manuscript/editorial/artifact_exports/20261009_parseval_raw_FS_v2/README.md)
contain the full PDF, selected review, minimal sources and actual evidence.
The [activation record](manuscript/editorial/parseval_raw_FS_cloud_activation_v2_20261009.json)
will record cloud activation separately. BJ22 critical Siu/general envelopes
remain OPEN; no new general theorem or complete whole-book pass is claimed.

''';p.write_text(s.replace(marker,intro+marker,1))
marker='## Latest selected published BJKS1 dependency checkpoint, 9 October 2026\n'
p=S/programme;s=p.read_text();assert s.count(marker)==1
intro='''## Latest checked Parseval/raw-FS book checkpoint, 9 October 2026

The [integration audit](parseval_raw_FS_staged_integration_audit_v2_20261009.md)
records fixed-variable Parseval in 65.19, the published BJKS1 anchor for
L.99's P1 raw-FS example, and L.100's raw/canonical FS distinction with
the exact psh premise of Lemma 6.17(iii). Full and weak envelope properties
remain separate, as do the original BBJ21, holomorphic extension, Okounkov
and BJ22/addendum proof obligations. Finski's published 47 pages/24 views
are completely read; BJKS1's 50 of 100 pages/25 views remain partial.
This integration adds no new primary-reading credit or recursive certificate.

The final book has 4,667 physical pages: two additional content pages and
two ordinary recto-opening blank versos relative to 4,663. All 31 selected
physical pages were read with complete text and 16 matching individual
displays. They include both changed sections and seams, contents, the full
12-page index, and the complete updated reference entry. Two blank versos
are recorded separately and do not add mathematical-content credit.
Last complete ordered whole-book reading remains 4 October.

Required validation and six existing tests pass. Post-render references
and canonical inventory pass; zero errors, unresolved references, missing
glyphs, overfull boxes or invalid internal links. All 955 inherited
underfull blocks have identical normalized content and multiplicities.
All 13,382 numbered values, 599 citation labels and 2,765 TOC titles/
hierarchies are retained; no new formal block, manual tag, semantic label
or bibliography key is added. Two index terms give 898 accepted entries.
Other 423 core TeX inputs and the NA bibliography remain unchanged.
The v1 mistaken-reference preflight is preserved with no TeX/PDF credit.

The [artifact directory](artifact_exports/20261009_parseval_raw_FS_v2/README.md)
contains full book, 31-page review, 472-member build source and actual
evidence. Activation and remote publication get separate verified records;
upload adds zero reading credit. Preserve the native catalogue/editor and
canonical 42 atoms/twelve problems. BJ22 critical homogeneous Siu/general
envelopes remain OPEN, LPWZ density UNVERIFIED, and the Theorem 6.21 warning
binding. No original general result or independent-model receipt is added.
Next read the original maximal-ray and holomorphic-extension sources and
the relevant Okounkov lattice prerequisites, integrate incoming author
progress and publish reviewed units regularly. Continue cloud only;
Xean stays suspended.

''';p.write_text(s.replace(marker,intro+marker,1))
with zipfile.ZipFile(prep['baseline_minimal_source']['path']) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    members=old.namelist();assert len(members)==len(set(members))==472
    for n in members:z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
    assert z.testzip() is None
    for n in z.namelist():assert z.read(n)==(S/n).read_bytes()
files={f'records/{q.name}':q for q in C.glob('*.json')}
for v in [1,2]:
    q=C/f'staged_book_validation_v{v}_20261009.log';files[f'logs/{q.name}']=q
    stage=Path(f'/workspace/book-completion-drafts/parseval-raw-FS-staging-v{v}-20261009')
    draft=Path(f'/workspace/book-completion-drafts/parseval-raw-FS-integration-v{v}-20261009')
    for rel in prep['after']:files[f'staged_inputs/v{v}/{rel}']=stage/rel
    for q in draft.iterdir():files[f'drafts/v{v}/{q.name}']=q
for q in (C/'compiled_staged_v2').iterdir():
    if q.suffix!='.pdf':files[f'compiled_v2/{q.name}']=q
for a in reading['views']:
    for key,folder in [('sequential_note_path','notes'),('observation_receipt_path','receipts'),('path','images'),('selected_text_path','text')]:
        q=Path(a[key]);files[f'actual_v2/{folder}/{q.name}']=q
files['actual_v2/prepared_manifest.json']=Path(release['manifest_path'])
for q in sorted(Path('/tmp').glob('Parseval_raw_FS_*_v*_20261009.py')):files[f'helpers/{q.name}']=q
for q in [paths['audit'],paths['reading_notes'],S/programme,S/'README.md']:files[f'editorial/{q.name}']=q
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
    assert len(z.namelist())==len(files) and z.testzip() is None
    for n,q in files.items():assert z.read(n)==q.read_bytes()
artifacts={k:dict(path=str(q),bytes=q.stat().st_size,SHA256=sha(q))
           for k,q in [('full_book_PDF',full),('selected_review_PDF',review),('minimal_TeX_source_archive',minimal),('actual_book_evidence_archive',evidence)]}
artifacts['full_book_PDF']['physical_pages']=4667
artifacts['selected_review_PDF']['physical_pages']=31
artifacts['minimal_TeX_source_archive']['members']=472
artifacts['actual_book_evidence_archive']['members']=len(files)
progress={n:sha(S/n) for n in ['README.md',programme]}
paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — staged mathematical/mechanical/actual-rendered gate',preparation=prep,release=release,
    actual_reading=reading,mathematical_audit=math,post_render=post,underfull_comparison=under,
    artifacts=artifacts,progress_document_hashes=progress,active_book_changed=False,
    GitHub_published=False,canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — all owned archive members byte-verified',artifacts=artifacts,
    reading_credit_from_export=0,active_book_changed=False,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
dest.mkdir(parents=True)
for row in artifacts.values():
    q=Path(row['path']);target=dest/q.name;shutil.copyfile(q,target);assert sha(target)==row['SHA256']
(dest/'SHA256SUMS').write_text(''.join(row['SHA256']+'  '+Path(row['path']).name+'\n' for row in artifacts.values()))
(dest/'README.md').write_text(f'''# Checked Parseval and raw/canonical FS edition, 9 October 2026

Full 4,667-page book, 31-page actual selected review, 472-member minimal
source and {len(files)}-member actual evidence archive. SHA256SUMS pins
all four owned artifacts; every archive member was byte-verified.
All 31 selected physical pages were completely read in 16 individually
displayed matching views. Two blank versos are explicit and give no
additional mathematical-content credit. Last complete ordered book
reading remains 4 October. Preparation/export/upload add zero credit.

Chapter 65.19 explains fixed-variable symmetric Parseval and the correct
degree asymptotic. L.99 attributes the shifted/scaled P1 raw-FS example
to BJKS1 Example 2.21 in its exact field scope. L.100 separates raw FS
from upper regularization and retains the psh premise for strong E1
convergence, full versus weak envelopes and original cited dependencies.
Finski published 47 pages/24 views are fully read; published BJKS1
50 of 100 pages/25 views are partial. No recursive original-proof
certificate or fresh primary-reading credit is assigned by this increment.

Required validation, six existing tests and post-render gates pass.
All 13,382 old numbered values, 599 citation labels, 51 historical
formal blocks, 92 manual tags and 2,765 TOC titles/hierarchies are
retained. No new source key, semantic label or formal block is added.
All 898 index entries and 48,760 internal links pass. Zero overfull
boxes; all 955 inherited underfull blocks have identical normalized
content/multiplicity. Other 423 core TeX inputs and NA bibliography
are unchanged. The failed v1 reference preflight is preserved.

Native catalogue/editor and canonical 42 atoms/twelve formal problems
are unchanged. General BJ22 critical Siu/envelopes remain OPEN, LPWZ
density UNVERIFIED and the Theorem 6.21 warning binding. No original
general result or independent-model receipt is claimed. External
primary PDFs stay in their cloud source archive; the owned book
evidence here contains book text/images and authored records.
Cloud activation and remote publication get separate later records.
'''.rstrip()+'\n')
published=[*paths.values(),*sorted(dest.iterdir())]
assert len(published)==10
for p in [paths['audit'],paths['reading_notes'],dest/'README.md']:
    assert p.read_bytes().endswith(b'\n') and not p.read_bytes().endswith(b'\n\n')
    assert all(line==line.rstrip() for line in p.read_text().splitlines())
record.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — actual staged book checkpoint and owned artifacts exported',artifacts=artifacts,
    editorial_files={str(q):sha(q) for q in published},progress_document_hashes=progress,
    actual_final_book_pages=31,actual_final_matching_views=16,actual_final_fresh_matching_views=16,
    actual_final_reused_matching_views=0,active_book_changed=False,GitHub_published=False,
    canonical_status_changes=[],helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',book_pages=4667,selected_pages=31,views=16,
    evidence_members=len(files),record_SHA256=sha(record))))
