# Fresh existing-section underfull comparison from frozen template 27931f194c0292971197f79b36551da29f34498eb47cd1198712bdb0f18bbdb1
# Fresh v4 follows source whitespace check. Frozen v3 helper SHA256: de12c4ce9c049db3e1dc22f4ccd0d675687abbfdafc1754dbfbae0fec46b0b06
# Fresh v4 condenses repeated prose to repair actual v2 short closing pages. Frozen v2 helper SHA256: 091d941207fa535476814cd6fabf0e5ec5d62f5f7facd8feb0e18bf7c3b730d3
# Adapted frozen underfull helper SHA256: 8db9c9f048fd81e733bbfc63557f58f4dda1999b17acc8af6a4bf6ae62325503
# Adapted frozen helper SHA256: 9919b34ac274c59c96c025bbb7ac0f42df2074228640618b5ead8900158f221d
# Frozen preceding v2 helper SHA256: 946a21a8870d4cb17445bfb69f4aa3cc84edff91d482d51357b16bed8409f360
# Frozen preceding v1 helper SHA256: c6bd1464b81de6280c76f5f6b49f667cbd340ef26698ec9a882f4a2b98e76502
# Frozen underfull template SHA256: 55797ec9ff9f03d1b33e086d08227a15d1b55e7d7c984591403d8dd35c71734e
# Frozen preceding v2 helper SHA256: 87db5e59791eb9be7ac87b7e54fe9c0810bbd22bb643414a4678383178f982fe
# Prepared unexecuted v1 comparison helper SHA256: 48a05f717eff4d4a4ca135c82fb7624af6e62ea027b52444283e669aedbb915c
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import re, hashlib, json

C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/BJKS1_Finski_dependencies_review_20261009')
old=Path('/workspace/book-completion-drafts/norm-ray-interfaces-staging-v4-20261009/manuscript/book.log')
new=C/'compiled_staged_v2/book.log'
out=C/'staged_underfull_delta_v2_20261009.json'
assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def blocks(t):
    rows=t.splitlines()
    ans=[]
    for i,x in enumerate(rows):
        if not re.match(r'Underfull \\[hv]box',x):
            continue
        a=[re.sub(r'at lines \d+(?:--\d+)?','at lines <range>',x)]
        for y in rows[i+1:]:
            if not y.strip():
                break
            a.append(y)
        ans.append('\n'.join(a))
    return Counter(ans)
a=blocks(old.read_text(errors='replace'))
b=blocks(new.read_text(errors='replace'))
assert sum(a.values())==955
added=b-a
removed=a-b
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — nonfatal underfull diagnostic comparison',
    baseline_log=dict(path=str(old),SHA256=sha(old)),
    staged_log=dict(path=str(new),SHA256=sha(new)),
    normalization='Only paragraph source line ranges are normalized; all content/font diagnostic text and multiplicities are compared.',
    prior_blocks=sum(a.values()),current_blocks=sum(b.values()),
    added_blocks=dict(added),removed_blocks=dict(removed),
    all_normalized_blocks_and_multiplicities_identical=(a==b),
    new_blocks_require_actual_rendered_review=bool(added),
    visual_reading_credit=0,helper_source=dict(path=__file__,SHA256=sha(__file__)))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',record_SHA256=sha(out),prior=sum(a.values()),
                     current=sum(b.values()),added=sum(added.values()),removed=sum(removed.values()))))
