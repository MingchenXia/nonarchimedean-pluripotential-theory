from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, json, re, subprocess, difflib

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BJKS1_Finski_dependencies_review_20261009'
S=Path('/workspace/book-completion-drafts/parseval-raw-FS-staging-v2-20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
ch=load('staged_book_release_checks_v2_20261009.json')
prep=load('staging_preparation_v2_20261009.json')
mp=Path(ch['manifest_path']);assert sha(mp)==ch['manifest_SHA256']
xs=json.loads(mp.read_text());views=[];last=None
for x in xs:
    assert not x['actually_viewed'] and not x['selected_text_read']
    n=C/'staged_book_notes_v2'/f"note_{x['number']:02d}.md"
    r=n.with_name(n.stem+'_receipt.json');a=json.loads(r.read_text())
    assert 'Read the complete selected text and displayed matching rendered image' in n.read_text()
    assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
    assert a['number']==x['number'] and a['physical_pages']==x['physical_pages']
    assert a['source_PDF_SHA256']==ch['PDF']['SHA256']
    assert sha(n)==a['note_SHA256']
    assert sha(x['path'])==a['image_SHA256']==x['image_SHA256']
    assert sha(x['selected_text_path'])==a['selected_text_SHA256']==x['selected_text_SHA256']
    assert last is None or a['UTC']>last;last=a['UTC']
    y={k:v for k,v in x.items() if k not in ['actually_viewed','selected_text_read']}
    y.update(actual_complete_text_read=True,actual_matching_image_freshly_displayed=True,
             sequential_note_path=str(n),sequential_note_SHA256=sha(n),
             observation_receipt_path=str(r),observation_receipt_SHA256=sha(r))
    views.append(y)
pages=sorted({p for x in xs for p in x['physical_pages']})
assert pages==ch['selected_book_physical_pages']
assert sum(len(x['physical_pages']) for x in xs)==len(pages)==31 and len(views)==16
reading=C/'actual_staged_book_reading_v2_20261009.json'
audit=C/'staged_mathematical_self_audit_v2_20261009.json'
post=C/'post_render_checks_v2_20261009.json'
assert not any(p.exists() for p in [reading,audit,post])
checks=[]
for command in [['python3','editorial/tools/refcheck.py'],['python3','editorial/tools/check_open_problem_inventory.py']]:
    run=subprocess.run(command,cwd=S/'manuscript',text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    assert run.returncode==0,run.stdout
    checks.append(dict(command=command,returncode=run.returncode,output=run.stdout))
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
for n,h in prep['other_active_TeX_preserved'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['unchanged_bibliographies'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
assert sha(ch['PDF']['path'])==ch['PDF']['SHA256']
historical={};whitespace={}
for row in prep['historical_formal_blocks_preserved']:
    n=row['path'];before=(R/n).read_text();after=(S/n).read_text()
    for e,count in row['environment_counts'].items():
        pat=r'\\begin\{'+e+r'\}.*?\\end\{'+e+r'\}'
        blocks=re.findall(pat,before,re.S)
        assert all(b in after for b in blocks)
        assert len(blocks)==len(re.findall(pat,after,re.S))==count
    assert re.findall(r'\\tag\{([^}]+)\}',after)==row['historical_manual_tags']
    assert re.findall(r'\\label\{([^}]+)\}',before)==re.findall(r'\\label\{([^}]+)\}',after)
    historical[n]=row
for n in prep['after']:
    before=(R/n).read_text().splitlines();after=(S/n).read_text().splitlines()
    assert Counter(x for x in before if x!=x.rstrip())==Counter(x for x in after if x!=x.rstrip())
    added=[x[2:] for x in difflib.ndiff(before,after) if x.startswith('+ ')]
    assert all(x==x.rstrip() for x in added)
    run=subprocess.run(['git','diff','--no-index','--check',str(R/n),str(S/n)],text=True,capture_output=True)
    assert run.returncode in [0,1] and not(run.stdout+run.stderr).strip()
    whitespace[n]=dict(added_lines=len(added),added_trailing_whitespace=0,check_returncode=run.returncode)
for p,h in prep['draft_fragments'].items():assert sha(p)==h
under=load('staged_underfull_delta_v2_20261009.json')
assert not under['added_blocks'] and not under['removed_blocks']
reading.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — every selected final book page freshly read with matching individual display',
    PDF=ch['PDF'],actual_unique_book_pages=31,fresh_complete_text_and_individually_displayed_pages=31,
    substantive_selected_pages=29,explicitly_reviewed_blank_versos=[3516,4416],
    fresh_matching_views=16,reused_exact_complete_text_and_rendered_pixel_pages=0,
    reused_matching_views=0,views=views,legacy_preparation_flags_rewritten=False,remaining_repairs=[],
    whole_book_new_reading_claim=False,last_complete_ordered_book_pass='2026-10-04',
    active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__),
    ensure_ascii=False,indent=2)+'\n')
mathchecks=[
    'For a fixed positive integer r, the complex ell-1 projective quotient on Sym^k C^r is exactly the coefficient sum: collecting words gives the lower bound, and choosing one word per monomial gives the upper bound. This is a direct source-attributed finite calculation.',
    'Normalized Haar measure on the complex r-torus gives integral |P|^2=sum |a_alpha|^2. Coefficient Cauchy–Schwarz therefore gives evaluation <= projective <= sqrt(D_k) evaluation, D_k=binom(k+r-1,r-1), with log(D_k)/k tending to zero for fixed r. It is neither a full-tensor equality nor a dimension-uniform estimate.',
    'In the general-norm source argument the auxiliary quotient accuracy and finite rank are fixed before the degree limit. Its holomorphic extension input retains continuous psh metric, ample line bundle, compact complex X, closed complex submanifold Y and eventual surjective restriction. The elementary Parseval calculation does not prove this external extension theorem.',
    'The existing P1 raw-FS/Q example is identified after shift and scaling with published BJKS1 Example 2.21 over an algebraically closed trivially valued field. The primary field signature is not silently enlarged.',
    'Raw FS in BJKS1 Definition 2.13 is a bounded lower semicontinuous supremum and need not be upper semicontinuous or psh. FS-star denotes upper regularization, distinct from the lower regularization used by infimum norms. Homogeneity alone does not supply usc membership.',
    'For projective reduced irreducible X and an ample Q-line bundle over an algebraically closed trivially valued field, Lemma 6.17(iii) assumes FS-star is L-psh before strong E1 convergence. The full envelope property supplies membership; the weak envelope property supplies equality on linear-growth valuations and extended energy, without by itself supplying the full psh claim.',
    'Published Finski raw equation (6.15) is separated from the canonical psh extension used in Theorem 6.6. The paragraph diagnoses that literal interface while preserving the intended maximal-ray statement and its original external inputs.',
    'The BJKS1 chain includes BJ22 Global pluripotential theory and its separate addendum. No independence from, counterexample to, or repair of the reported BJ22 Theorem 6.21 proof gap is claimed. The general critical homogeneous Siu and envelope gates remain OPEN and LPWZ density remains UNVERIFIED.',
    'The controlling Finski published author PDF is completely read, all 47 pages in 24 ordered matching views across two pinned checkpoints. BJKS1 remains partially read, 50 of 100 pages in 25 views. Full reading of either source does not recursively certify the original references. Actual source diagnostics outside the three scoped prose changes are retained in their own source records.',
    'This increment changes only two core TeX roots and the Fin25SM bibliography note. It adds no section label, formal environment, manual equation tag or bibliography key. All 51 historical formal blocks, 92 manual tags, 13,382 old numbered values, 599 old citation labels and all 2,765 TOC titles/hierarchies remain intact.',
    'Thirty-one selected final book pages were completely read in sixteen matching displays, including two identified blank versos, all twelve index pages and the complete updated citation entry. This is scoped new reading; the last complete ordered whole-book pass remains 4 October. No independent-model receipt or original general result is claimed.',
    'The first isolated stage failed reference preflight at a mistaken existing L.99 label before TeX compilation. Fresh v2 corrects only that reference and passes; the failed v1 source, draft and record are preserved, with no compiled-PDF or reading credit assigned to v1.'
]
scope='Complete published Finski 47 pages/24 matching views across pinned source checkpoints; selected published BJKS1 50 of 100 physical pages/25 matching views. Original BBJ21, extension, Okounkov and BJ22/addendum dependencies retain their own audit gates.'
audit.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — ordinary scoped mathematical audit and actual rendered clearance',checks=mathchecks,
    actual_final_book_reading_SHA256=sha(reading),source_scope=scope,
    source_input_hashes=prep['after'],draft_fragments=prep['draft_fragments'],
    original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],helper_source=__file__),
    ensure_ascii=False,indent=2)+'\n')
post.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — post-render reference/inventory and source preservation checks',checks=checks,
    historical_formal_blocks_preserved=historical,whitespace_checks=whitespace,
    underfull_delta_SHA256=sha(C/'staged_underfull_delta_v2_20261009.json'),
    actual_final_reading_SHA256=sha(reading),mathematical_audit_SHA256=sha(audit),
    release_checks_SHA256=sha(C/'staged_book_release_checks_v2_20261009.json'),
    semantic_notation_delimiter_review='Complete selected text and individual matching image review; no unavailable legacy automated audit claimed',
    active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],helper_source=__file__),
    ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',selected_book_pages=31,views=16,reading_SHA256=sha(reading),math_SHA256=sha(audit),post_SHA256=sha(post))))
