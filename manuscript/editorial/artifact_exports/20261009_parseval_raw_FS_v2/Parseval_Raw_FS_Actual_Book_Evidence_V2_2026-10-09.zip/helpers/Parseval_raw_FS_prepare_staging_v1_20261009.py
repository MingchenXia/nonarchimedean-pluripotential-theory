from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,shutil,subprocess,zipfile
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/BJKS1_Finski_dependencies_review_20261009'
B=Path('/workspace/book-completion-drafts/norm-ray-interfaces-staging-v4-20261009')
S=Path('/workspace/book-completion-drafts/parseval-raw-FS-staging-v1-20261009');D=Path('/workspace/book-completion-drafts/parseval-raw-FS-integration-v1-20261009')
out=C/'staging_preparation_v1_20261009.json';assert not S.exists() and not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
pubpath=C/'GitHub_source_publication_v1_20261009.json';pub=json.loads(pubpath.read_text());assert head==pub['commit']=='8bded7da74d163839a26bdac35259df4b655a8c7'
assert pub['actual_primary_pages']==50 and pub['actual_matching_images']==25 and not pub['whole_primary_PDF_read']
protected=json.loads((C/'primary_view_preparation_v1_20261009.json').read_text())['protected_core_inputs'];progress=['README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']
for n,h in protected.items():
    if n not in progress:assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==sha(B/'manuscript/book.pdf')=='32cb8f5fa3ee656ec7f53ab525c3a28c6a638af27a9a04cf4ad893dfcda1bd20'
for row in pub['files']:assert sha(R/row['path'])==row['SHA256']
prior=R/'source_material/Metric_radial_dependencies_review_20261009/staged_export_v5_20261009.json';m=json.loads(prior.read_text())['artifacts']['minimal_TeX_source_archive'];archive=Path(m['path']);assert sha(archive)==m['SHA256']
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==472
    for n in z.namelist():assert not Path(n).is_absolute() and '..' not in Path(n).parts
    S.mkdir();z.extractall(S)
for n in progress:
    p=S/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,p)
changed=['manuscript/parts/part6/ch65_rays_filtrations.tex','manuscript/appendices/appL_provenance.tex','manuscript/bibliography/ComplexGeometry.bib']
before={n:sha(R/n) for n in changed};alltex={n:h for n,h in protected.items() if n.startswith('manuscript/') and n.endswith('.tex')};assert len(alltex)==425
for n,h in alltex.items():assert sha(S/n)==sha(R/n)==sha(B/n)==h
for n in changed:assert sha(S/n)==sha(R/n)==sha(B/n)
for p in D.iterdir():assert all(line==line.rstrip() for line in p.read_text().splitlines()) and not p.read_bytes().endswith(b'\n\n')
p=S/changed[0];p.write_text(p.read_text().rstrip()+'\n\n'+(D/'ch65_parseval_fragment.tex').read_text().rstrip()+'\n')
p=S/changed[1];s=p.read_text();start=s.index('\\Cref{sec:rf-norm-envelope-rays} gives the elementary');end=s.index('\\paragraph{Functions must be defined at finite spectral values.}',start)
s=s[:start]+(D/'appL_Finski_scope_replacement.tex').read_text().rstrip()+'\n\n'+s[end:]
marker='The bounded-obstacle convergence in\n';assert s.count(marker)==1
anchor='''Over an algebraically closed trivially valued field, shifting
and scaling the weights identifies this calculation with
\\cite[Example~2.21]{BJKS1}. That primary example separates
homogeneity of a graded norm from upper semicontinuity of its
raw FS function.
''';s=s.replace(marker,anchor+marker,1);p.write_text(s.rstrip()+'\n')
p=S/changed[2];s=p.read_text();old='Published author copy, forty-seven physical pages; selected pages 1--24 read. Ray comparison is Lemma 2.6 and finite-p FS isometry Corollary 3.5 in this edition';new='Published author copy, all forty-seven physical pages read. Ray comparison is Lemma 2.6, finite-p FS isometry Corollary 3.5, and fixed-variable Parseval Remark 4.3; original cited inputs remain separate';assert s.count(old)==1;p.write_text(s.replace(old,new,1))
unchanged={n:h for n,h in alltex.items() if n not in changed};assert len(unchanged)==423
historical=[]
for n in changed[:2]:
    old=(R/n).read_text();new=(S/n).read_text();counts={}
    for e in ['theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important']:
        pat=r'\\begin\{'+e+r'\}.*?\\end\{'+e+r'\}';blocks=re.findall(pat,old,re.S);assert all(b in new for b in blocks);assert len(blocks)==len(re.findall(pat,new,re.S));counts[e]=len(blocks)
    tags=re.findall(r'\\tag\{([^}]+)\}',old);assert tags==re.findall(r'\\tag\{([^}]+)\}',new)
    assert re.findall(r'\\label\{([^}]+)\}',old)==re.findall(r'\\label\{([^}]+)\}',new)
    historical.append(dict(path=n,environment_counts=counts,historical_manual_tags=tags))
for n,h in unchanged.items():assert sha(R/n)==sha(S/n)==h
for row in pub['files']:
    if row['path'].startswith('manuscript/editorial/') and '/artifact_exports/' not in row['path']:
        p=S/row['path'];p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/row['path'],p)
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — attributed Parseval and raw/canonical FS explanation prepared in isolated stage',stage_path=str(S),baseline_stage_path=str(B),baseline_compiled_snapshot=str(R/'source_material/Metric_radial_dependencies_review_20261009/compiled_staged_v4'),baseline_commit=head,baseline_minimal_source=m,draft_path=str(D),before=before,after={n:sha(S/n) for n in changed},draft_fragments={str(p):sha(p) for p in D.iterdir()},active_inputs_preserved=before,other_active_TeX_preserved=unchanged,other_active_TeX_count=423,unchanged_bibliographies={'manuscript/bibliography/NonArchimedean.bib':sha(R/'manuscript/bibliography/NonArchimedean.bib')},historical_formal_blocks_preserved=historical,active_book_PDF_SHA256=sha(R/'manuscript/book.pdf'),native_catalogue_preserved={n:h for n,h in protected.items() if n.startswith('output/')},source_checkpoint_SHA256=sha(C/'source_checkpoint_v1_20261009.json'),actual_primary_reading_SHA256=sha(C/'actual_primary_reading_v2_20261009.json'),exact_diagnostics_SHA256=sha(C/'exact_diagnostics_v1_20261009.json'),Finski_complete_actual_reading_SHA256=sha(R/'source_material/Finski_published_completion_review_20261009/actual_primary_reading_v1_20261009.json'),source_publication_SHA256=sha(pubpath),new_bibliographic_keys=[],new_semantic_labels=[],new_formal_environments=0,original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],active_book_changed=False,GitHub_published=False,actual_book_reading_credit=0,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='DONE',record_SHA256=sha(out),other_TeX=423,changed_files=3,historical_formal_blocks=sum(sum(x['environment_counts'].values()) for x in historical))))
