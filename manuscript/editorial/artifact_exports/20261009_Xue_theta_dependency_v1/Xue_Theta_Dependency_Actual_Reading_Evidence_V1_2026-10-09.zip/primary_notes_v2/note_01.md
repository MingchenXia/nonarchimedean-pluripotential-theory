# FRSS arXiv v2 actual dependency reading — view 1

Physical pages 1–2; exact arXiv:1705.08212v2 PDF SHA256
607a917de1a5a0f88f7da6e5ee45f08779178db3412adedb083dd77e2d1317c9.

Complete selected text and displayed matching image read. The category is
a nontrivially valued complete algebraically closed non-Archimedean field
and an abelian variety, with mixed reduction allowed in the actual general
theorems. The first running explanation temporarily assumes total
degeneration and principal polarization: the lattice's multiplicative
pairing has positive-definite minus-log absolute value, the analytic
uniformization is a torus modulo its period lattice, and the theta series
tropicalizes into a minimum of affine functions with a quadratic lattice
constant. These preliminary formulas should not be applied as the general
mixed-reduction statement without the later Raynaud construction.

Theorem A is the general theta tropicalization statement (arXiv Theorem
4.10); Theorem B treats a principal Riemann theta function up to a
translation and additive constant (arXiv Theorem 4.13). Theorem C concerns
differences of tropicalized theta functions with equal automorphy factor:
their difference is the tropicalization of a rational function on A,
with its precise statement at arXiv Theorem 5.2. The introduction
explicitly discusses rational functions whose minus-log absolute values
on the skeleton have prescribed piecewise-linear behavior. Constancy of
all such functions is not a property assumed here.

Notation distinguishes the character lattice M, its dual N, real
cocharacter space N_R, valuation minus log absolute value, and completed
residue fields. This is a fresh reading of pages 1–2 of this dependency
only, with no added Xue page credit. The published 2018 paper uses
different numbering according to primary metadata; none of its journal
locators is authenticated by these arXiv pages. The later cocycle,
skeleton-point and Picard-zero calculations remain to be read.
