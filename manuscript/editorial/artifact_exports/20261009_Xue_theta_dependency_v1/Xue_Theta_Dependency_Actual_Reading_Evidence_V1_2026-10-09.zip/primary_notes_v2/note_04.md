# FRSS arXiv v2 actual dependency reading — view 4

Physical pages 7–8; exact PDF SHA256
607a917de1a5a0f88f7da6e5ee45f08779178db3412adedb083dd77e2d1317c9.

Complete selected text and matching image read. Pushing the Raynaud
extension out by a character produces the rigidified translation-invariant
bundle E_u on the good-reduction B, with a pullback frame e_u. Its model
norm gives tropicalization on E. The period lattice is characterized by
its full-rank lattice image in N_R, not by lying in the valuation-zero
affinoid torus. The zero tropical fiber A0 is the formal Raynaud extension
of B by that affinoid torus; its local splittings are on generic fibers of
**formal affine opens**. This precise formal-open convention matters for
the base norm in Xue's proposed skeleton point. The annulus observation
in the partial audit is a warning about arbitrary affinoids; these
intended good-reduction formal opens may supply the requisite canonical
generic-reduction/Shilov point, to be checked in FRSS Section 4.1.

The dual Raynaud cross distinguishes M' in E from M in E-dual. The
biextension pairing comes from the common Poincare fiber, and its minus-
log model norm is bilinear and nondegenerate. FRSS explicitly reverses
the names M/M' relative to BL91 to keep the standard tropical convention.
Thus a copied character or dual-factor formula needs its lattice roles
reconciled. In the total-degeneration example, the character formula
chi^(u')(u)=t(u',u) has u in M and describes the dual-period embedding;
the adjacent displayed domain M' is an index transposition. The general
dual cross and formula specify the intended roles.

Descent of line bundles requires the M'-linearization, not just the
pulled-back bundle on E. Example 3.8 gives the specific linearization
e_u on q*E_u that descends to the trivial rigidified bundle. Its period
norms are determined by the pairing and need not be one simply because
E_u belongs to Pic0(B). The theorem classifying general line-bundle
triples starts on the next page. No inference about all Picard-zero
period cocycles being trivial is licensed by these pages.

Actual dependency reading covers pages 1–8 only, without extra Xue
page credit or journal-number authentication.
