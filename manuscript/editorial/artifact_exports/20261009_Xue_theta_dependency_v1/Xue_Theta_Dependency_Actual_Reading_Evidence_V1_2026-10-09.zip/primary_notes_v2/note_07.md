# FRSS arXiv v2 actual dependency reading — view 7

Physical pages 13–14; exact PDF SHA256
607a917de1a5a0f88f7da6e5ee45f08779178db3412adedb083dd77e2d1317c9.

Complete selected text and matching image read. Proposition 3.25 removes
the extra additive homomorphism in the period norm by **translating the
principally polarized line bundle** and choosing an equivalent triple.
It starts with Q'=-log||c'||, subtracts the half-quadratic form Q, realizes
Q-Q' as tropical data of a point of the dual Raynaud extension, and uses
the principal polarization's lifted isomorphism to choose the actual
translation. Thus the normalization is a geometric operation with a
principal-polarization hypothesis, not a conclusion from rigidification
alone. The final symmetry adjustment uses division by two and a
unit-norm correction. These operations cannot simply be substituted into
the zero-lambda Picard-zero case, where that polarization isomorphism
is absent.

Example 3.26 retains the bilinear period pairing, character-lattice map
and square-root choices in the totally degenerate Riemann theta series.
The positive-definite quadratic period data supply convergence and the
half-quadratic coefficient norm. The source's geometric/dual-torus
translation notation must be interpreted through the lifted polarization,
as in the preceding proof; no unlabeled identification of E and E-dual
is used in our later comparison.

Section 4 begins the skeleton/tropicalization construction. It cites
Gubler's Example 7.2 and explicitly chooses a local **formal Raynaud**
splitting as in Remark 3.3. The full skeleton section goes from N_R into
Ean, with the zero-valued formal extension just one fiber. It is not a
section whose entire image lies in the compact unit torus. The proposed
Gauss norm and its formal-base meaning continue on p. 15; source
clearance for Xue's base-norm convention is not claimed prematurely.

Actual dependency reading now covers pages 1–14. No extra Xue coverage,
published-locator verdict or original mathematical promotion is added.
