# FRSS arXiv v2 actual dependency reading — view 2

Physical pages 3–4; exact PDF SHA256
607a917de1a5a0f88f7da6e5ee45f08779178db3412adedb083dd77e2d1317c9.

Complete selected text and matching displayed image read. The notation
for fibers/rigidified constant line bundles, the dual abelian variety and
translation homomorphism of a line bundle precede the tropical setup.
The whole acknowledgment text was read as part of these selected pages;
it contributes no mathematical proof clearance.

A real torus with integral structure uses the slope lattice N inside
N_R and a full quotient lattice Lambda, which need not equal N.
Integral affine maps may have real translation constants but their
linear part comes from lattice homomorphisms. Piecewise integral affine
functions on the quotient are defined by their lifted function on N_R;
Kummer functions additionally factor through negation. None of these
definitions replaces integral slopes by unrestricted real slopes.

The tropical abelian data are paired lattices M and M-prime of equal
rank with a nondegenerate real pairing. A polarization lambda maps
M-prime to M and makes the induced pairing symmetric positive-definite;
principal means lambda is an isomorphism. This lambda is not an arbitrary
zero-curvature or Picard-zero datum. Definition 2.8 begins specifically
with a lambda defining a polarization, so its theta-function statement
must not be cited without checking the later treatment of general
line bundles and meromorphic ratios. The quasi-periodicity and cocycle
condition continue on p. 5.

Actual dependency reading covers pages 1–4 only. No Xue reading credit,
published-journal locator clearance or independent verdict is added.
