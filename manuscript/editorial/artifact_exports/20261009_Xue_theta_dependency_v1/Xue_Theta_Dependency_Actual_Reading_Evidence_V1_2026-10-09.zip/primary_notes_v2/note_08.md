# Actual ordered reading 08 — FRSS arXiv:1705.08212v2, physical pages 15–16

Read the complete prepared text and matching displayed two-page image. This is arXiv v2, not an authenticated reading of the differently numbered journal edition. No Xue page credit or independent-model verdict.

Page 15 completes §4.1: on the formal Raynaud affine-open splitting V from Remark 3.3, analytic h on U^v × V has a convergent Laurent expansion with coefficient supremum norms, and (4.1.1) defines the canonical skeleton point. Lemma 4.2 explicitly supplies the missing scope fact: the good-reduction abelian model has a unique analytic point ξ reducing to the generic point of its special fiber; its evaluation is precisely the supremum norm on every V used here, and q(σ(v))=ξ. Consequently this particular coefficient supremum norm is multiplicative. The earlier diagnostic involving an arbitrary affinoid supremum norm does not refute this intended formal-model construction. Xue Definition 4.21 must be checked with this precise V and canonical point scope; retain the earlier note as a conditional diagnostic and add this clearance rather than rewriting it.

Lemma 4.3 gives translation equivariance σ(v)+x=σ(v+trop(x)). Definition 4.4 is the real quotient N_R/trop(M'), with τ proper/surjective and σ descending to the skeleton deformation retract. Example 4.5 specializes to ordinary weighted Gauss points for toric reduction; coefficients are constants only in that special case.

Page 16 Proposition 4.7 makes the period pairing and λ into the tropical polarization and relates the analytic polarization to its quotient map. Definition 4.9 defines f_trop(v)=-log ||f(σ(v))|| using the pullback of the canonical MODEL metric on L over B. This is not an assertion that the uncorrected theta representative already gives the descended canonical metric on L_A over A. Theorem 4.10 begins here and continues on the next page; do not claim its full proof read yet.

The canonical base point resolves the generic supremum-norm objection in the intended formal scope. It does not remove the descent factors c(γ), e_{λγ}, or their norms, which remain separate data in Theorem 3.10 and Proposition 3.19.
