# Actual ordered reading 11 — FRSS arXiv:1705.08212v2, physical page 21

Read the entire prepared text and matching displayed single-page image. This completes the exact 21-page arXiv v2 source in physical order, with eleven separate notes and receipts. It does not authenticate the differently numbered journal edition, recursively clear all cited inputs, add any Xue reading credit, or supply an independent original-result verdict.

The remainder of the references records Baker–Rabinoff 2015, Faltings–Chai 1990, Fujiwara–Kato's 2017 preprint, Fresnel–van der Put 2004, Gubler 2010 (Compositio 146(3), 683–730), Mumford 1972, Mikhalkin–Zharkov 2008 and Teitelbaum 1988. Author institutional contact lines complete the page. No additional theorem or proof occurs here.

The full reading supports the formal-model canonical base-point interpretation of the weighted Gauss norm, and the explicit persistence of period multiplier norms. It does not clear Xue's rigidification-only removal of the tropical Pic^0 correction. The arXiv version's general rational-lifting proof step in Theorem 5.2 remains separately flagged; the exact translate-product construction of Proposition 5.6 has stronger matching-descent hypotheses and is tracked distinctly.
