# FRSS arXiv v2 actual dependency reading — view 3

Physical pages 5–6; exact PDF SHA256
607a917de1a5a0f88f7da6e5ee45f08779178db3412adedb083dd77e2d1317c9.

Complete selected text and matching displayed image read. Definition 2.8
requires the cocycle relation c(u1+u2)-c(u1)-c(u2)=[u1,lambda(u2)] and
the transformation law phi(v)=phi(v+u')+c(u')+<lambda(u'),v>.
The source explicitly observes that c differs from half the quadratic
polarization pairing by a homomorphism to R. That linear term is part
of the data; rigidification/normalization is not stated to remove it.
The principal tropical Riemann theta minimum has the symmetric quadratic
choice of c, but the general transformation law allows a different
homomorphism term. Positivity/polarization restrictions from the previous
page continue to matter.

The non-Archimedean theta section recalls Bosch–Lütkebohmert uniformization
and analytic GAGA on proper varieties. A theta function is associated
with a global line-bundle section; extending to rational/meromorphic
sections requires a quotient construction rather than automatically
using every holomorphic-section statement in the Picard-zero case.

The metric convention defines fiber scaling compatible with the analytic
Gm action and continuity, with scaling in the relevant completed residue
field value group. Integral-model metrics are defined through the
valuative extension of a point and a local model frame; transition units
give independence. The **canonical model metric here is on a rigidified
line bundle on the good-reduction abelian variety B**. This is different
from already having constructed a canonical descended metric on the
possibly bad-reduction original A. Raynaud uniformization has the
algebraic extension T→E→B and the analytic lattice cover M'→Ean→Aan;
the covering map p is not algebraic. Confusing these two bases or their
metrics would lose the period-descent information under audit.

Actual dependency reading covers pages 1–6. Published journal numbers
remain unauthenticated by these arXiv pages, and no new main-paper result
has been cleared.
