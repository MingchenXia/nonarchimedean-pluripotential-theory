# FRSS arXiv v2 actual dependency reading — view 6

Physical pages 11–12; exact PDF SHA256
607a917de1a5a0f88f7da6e5ee45f08779178db3412adedb083dd77e2d1317c9.

Complete selected text and matching displayed image read. The source
explicitly uses the contravariant line-bundle/invertible-sheaf convention:
the sheaf associated to a geometric bundle L is Hom(L,O), and a section
of the geometric bundle corresponds to a section of the inverse sheaf.
This distinction has to be carried through a theta-factor comparison;
one cannot interchange a numerator/denominator or add a dual without
tracking the actual section and character. These arXiv source conventions
are recorded without assuming identical journal numbering.

Fourier coefficients of a global theta section live in twisted bundles
on B. Remark 3.18 specifies a **formal affinoid** splitting the formal
Raynaud extension and formally trivializing the bundle; there the model
norm becomes the ordinary absolute value of the Laurent expression.
This supports the intended restricted formal-chart reading, not a
claim about multiplicative sup norms on arbitrary affinoids.

Proposition 3.19 gives descent as f=c(u')*e_lambda(u')*T_u'^*f and the
coefficient recurrence with t(u',u), c(u') and the base translation.
Definition 3.20 defines a theta function as a global section invariant
under this linearization, and stresses it is not intrinsic to the
descended bundle because equivalent triples give different representatives.
Corollary 3.21 retains the norms of both t and c. Its norm-one
compatibility of the canonical model identifications does **not** erase
those explicit period multipliers. Example 3.22 spells out the same
recurrence on a totally degenerate torus.

The polarization subsection identifies lambda through both the torus
character map and the period-lattice restriction of the lifted Picard
homomorphism, with the good-reduction quotient map supplied by phi_L.
The degree formula has the lattice-index square. The unique principal
Riemann theta series uses the c coefficients and translated a0, rather
than replacing all of them by unit coefficients. Global holomorphic
theta sections and meromorphic representatives of rational Picard-zero
sections remain distinct.

Actual dependency reading covers pages 1–12 only. Xue page coverage,
main-theorem clearance and independent-model status do not change.
