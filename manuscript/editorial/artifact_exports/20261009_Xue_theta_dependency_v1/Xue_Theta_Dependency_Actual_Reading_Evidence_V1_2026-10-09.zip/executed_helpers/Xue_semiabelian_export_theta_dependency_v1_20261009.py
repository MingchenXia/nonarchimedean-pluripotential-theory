from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,zipfile
R=Path('/workspace/nonarchimedean-pluripotential-theory');E=R/'manuscript/editorial'
C=R/'source_material/Xue_semiabelian_review_20261009';F=C/'dependencies_v1/FRSS18ArxivV2'
W=Path('/tmp/Xue_semiabelian_dependency_views_v1_20261009/FRSS18ArxivV2')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
prep=json.loads((F/'source_preparation_v2_20261009.json').read_text())
assert sha(prep['source']['path'])==prep['source']['SHA256']
assert sha(W/'manifest.json')==prep['manifest_SHA256']
receipts=[];pages=[];previous=None
for i in range(1,12):
 n=F/'primary_notes_v2'/('note_%02d.md'%i);p=n.with_name('note_%02d_receipt.json'%i)
 d=json.loads(p.read_text());assert d['view_number']==i and d['note_SHA256']==sha(n)
 assert d['previous_receipt_SHA256']==previous and d['source_PDF_SHA256']==prep['source']['SHA256']
 assert d['full_selected_text_read'] and d['matching_rendered_image_displayed_and_read']
 assert sha(d['image_path'])==d['image_SHA256'] and sha(d['selected_text_path'])==d['selected_text_SHA256']
 pages+=d['physical_pages'];previous=sha(p)
 receipts.append(dict(view=i,pages=d['physical_pages'],note_path=str(n),note_SHA256=sha(n),receipt_path=str(p),receipt_SHA256=sha(p)))
assert pages==list(range(1,22))
cp=F/'actual_source_checkpoint_v1_20261009.json';assert not cp.exists()
checkpoint=dict(UTC=now(),status='COMPLETE ACTUAL READING OF EXACT ARXIV V2 — 21 pages, 11 matching views',
 exact_version='arXiv:1705.08212v2',source_SHA256=prep['source']['SHA256'],actual_pages=pages,actual_matching_views=11,
 receipts=receipts,journal_locators_authenticated=False,all_recursive_inputs_verified=False,
 Xue_actual_pages=list(range(1,21)),new_Xue_page_credit=0,Kuhne_actual_page_credit=0,
 book_changed=False,canonical_status_changes=[],independent_verifier_receipt=False,
 clarified_scope='Formal Raynaud affine-open supremum norm is evaluation at canonical generic-special-fiber point ξ (Lemma 4.2), hence multiplicative. Arbitrary affinoid diagnostic does not refute this intended scope.',
 remaining_input='Pic^0 period multiplier norms survive λ=0; raw theta canonical-metric comparison in Xue Proposition 4.24 unverified.',
 additional_arxiv_proof_caution='Theorem 5.2 selects a nonzero zero Fourier coefficient of a generally meromorphic quotient without establishing these steps in the displayed argument; no theorem refutation or journal-version verdict.',
 frozen_prior_Xue_checkpoint_SHA256=sha(C/'source_checkpoint_v1_20261009.json'),helper_source=__file__,helper_SHA256=sha(__file__))
cp.write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2)+'\n')
X=E/'artifact_exports/20261009_Xue_theta_dependency_v1';assert not X.exists();X.mkdir()
prefix='Xue_theta_dependency_source_'
paths={k:E/(prefix+k+'_v1_20261009.'+ext) for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in paths.values())
review='''# Original theta dependency: complete exact arXiv-v2 reading

Foster–Rabinoff–Shokrieh–Soto, *Non-Archimedean and tropical theta functions*,
**arXiv:1705.08212v2**, revised 19 January 2018. All **21 physical pages**
were read in eleven ordered complete-text and matching-image displays.
PDF SHA256: `607a917de1a5a0f88f7da6e5ee45f08779178db3412adedb083dd77e2d1317c9`.

The published journal article is Math. Ann. 372 (2018), 891–914,
DOI 10.1007/s00208-018-1646-3. Its PDF could not be acquired in this check;
the official institutional repository supplies metadata only. Primary
arXiv metadata explicitly says that journal numbering differs. Therefore
**every theorem locator below is an arXiv-v2 locator**, and none authenticates
a differently numbered journal citation. No recursive verification of all
cited proofs or independent original-result receipt is claimed.

## Correction of an earlier conditional diagnostic

Remark 3.3, Remark 3.18 and §4.1 use formal Raynaud affine-open splittings,
not arbitrary affinoids. **Lemma 4.2, p. 15** identifies the coefficient
supremum norm with evaluation at the unique analytic point reducing to
the generic point of the good-reduction abelian special fiber. This norm
is multiplicative. Hence the weighted Gauss construction is legitimate
in this intended scope; the earlier arbitrary-affinoid example does not
refute it. This is an addendum to the frozen Xue 20/83-page checkpoint,
not a rewrite of that checkpoint or a main-theorem clearance.

## Remaining distinction: theta representatives and descended metrics

Theorem 3.10 and Proposition 3.19 retain both c(γ) and e_{λγ} in descent.
Example 3.16 gives Picard-zero data with λ=0 and c(γ)=x'^γ in the totally
degenerate case: c(0)=1 does not force all period norms to be one.
Definition 4.9 uses the pullback of the model metric on the good-reduction
base B. The proof of **Theorem 4.10, p. 17** explicitly retains the norms
of the descent factors; its polarized transformation law includes
c_trop(γ). Proposition 3.25 removes an additive period term using a
translation of a **principally polarized** bundle, not rigidification
alone. That normalization cannot simply be transferred to λ=0.

Consequently the inference in Xue Proposition 4.24 from λ=0 to a constant
tropical correction remains unverified. Theorem 4.1's unit-norm period
transition claim remains a separate input to metric gluing. These source
checks do not establish a counterexample to the intended equidistribution
or Bogomolov theorem.

The arXiv version's general rational-lifting proof (Theorem 5.2, p. 19)
forms a meromorphic quotient, then uses a global Fourier expansion and a
nonzero zero coefficient without justifying those steps in the displayed
argument. It is flagged separately; no claim is made about a correction
in the journal version. The explicit translate-product construction of
Proposition 5.6 uses exactly matching tensor descent data and is tracked
under those stronger hypotheses.

## Scope and next work

Xue's main source remains **20/83 actually read pages** at this checkpoint;
the acquired published Kühne source has **zero actual local text/image
reading credit**. Search of its prepared text helps locate the next
reading, but does not verify its proofs. Neither this dependency reading
nor uploading evidence changes the 4,675-page book, native catalogue,
42 canonical atoms or 12 formal problems. General BJ22 Siu/envelopes
remain OPEN. The native catalogue's separate arithmetic supplement has a
source audit but its native-editor compiler still has not returned.

The archive preserves our authored notes, receipts, acquisition and
preparation records, exact prepared-view manifest and executed helpers.
It does not redistribute paper PDFs, extracted full text or page images.
'''
paths['review'].write_text(review)
paths['reading_notes'].write_text('# Actual ordered theta dependency reading\n\n'+ '\n\n---\n\n'.join((F/'primary_notes_v2'/('note_%02d.md'%i)).read_text().rstrip() for i in range(1,12))+'\n')
paths['manifest'].write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2)+'\n')
members={}
for i in range(1,12):
 for suffix in ['.md','_receipt.json']:
  p=F/'primary_notes_v2'/('note_%02d'%i+suffix);members['primary_notes_v2/'+p.name]=p
for name in ['source_acquisition_v2_20261009.json','source_preparation_v2_20261009.json','actual_source_checkpoint_v1_20261009.json']:
 members['records/'+name]=F/name
members['records/prepared_view_manifest.json']=W/'manifest.json'
members['records/published_acquisition_failure.json']=C/'dependencies_v1/FRSS18Published/source_acquisition_failure_v1_20261009.json'
members['records/official_repository_metadata.json']=C/'dependencies_v1/FRSS18Repository_metadata_v1_20261009.json'
for name in ['Xue_semiabelian_acquire_dependency_v1_20261009.py','Xue_semiabelian_prepare_FRSS_arxiv_v2_20261009.py','Xue_semiabelian_record_dependency_reading_v1_20261009.py','Xue_semiabelian_export_theta_dependency_v1_20261009.py']:
 members['executed_helpers/'+name]=Path('/tmp')/name
assert len(members)==32
archive=X/'Xue_Theta_Dependency_Actual_Reading_Evidence_V1_2026-10-09.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==32 and len(set(z.namelist()))==32
 for name,p in members.items():assert z.read(name)==p.read_bytes()
(X/'README.md').write_text('# Original theta dependency evidence\n\nExact arXiv:1705.08212v2: 21/21 physical pages, eleven matching displays.\nJournal numbering is not authenticated. Xue remains 20/83; main proofs\nremain unverified and are not integrated.\n\nThe ZIP contains 32 authored evidence/helper/receipt members. No primary\npaper PDF, full extracted text or page image is redistributed. Exact\nsource: https://arxiv.org/pdf/1705.08212v2.\n')
(X/'SHA256SUMS').write_text(sha(archive)+'  '+archive.name+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=now(),status='EXPORTED — exact arXiv dependency evidence',archive=str(archive.relative_to(R)),SHA256=sha(archive),bytes=archive.stat().st_size,members=32,actual_pages=21,matching_views=11,new_Xue_page_credit=0,book_changed=False,no_reading_credit_for_upload=True),ensure_ascii=False,indent=2)+'\n')
update='''
## Original theta dependency: source addendum, 9 October 2026

All **21 pages of FRSS arXiv:1705.08212v2** were read in eleven matching
text/image displays. Its formal-model canonical base point clears the
conditional arbitrary-affinoid Gauss-norm objection. Period multiplier
norms persist; Xue's raw-theta/canonical-metric identification remains
unverified. Journal numbering differs and is not authenticated by this
arXiv reading. Xue remains **20/83**; the active book remains **4,675 pages**.

See [source addendum](manuscript/editorial/Xue_theta_dependency_source_review_v1_20261009.md)
and [authored evidence](manuscript/editorial/artifact_exports/20261009_Xue_theta_dependency_v1/).
'''
readme=R/'README.md';readme.write_text(readme.read_text().rstrip()+'\n'+update)
progress=E/'second_reading_and_research_programme_20261002.md'
progress.write_text(progress.read_text().rstrip()+'\n'+update.replace('manuscript/editorial/',''))
owned=list(paths.values())+sorted(X.iterdir())+[readme,progress];assert len(owned)==9
assert sha(R/'manuscript/book.pdf')=='2c90129c35506ac72005c5189ff235b0e1bd52f5b529ef44e5fc58bf7dbfcfe8'
assert sha(R/'output/open_problems_catalogue_2026-10-03.tex')=='ec3a2a9d8c4d713afe2c0ff8dcf17720ef0d77442b6086d515dea382fe7b77ec'
record=C/'theta_dependency_export_v1_20261009.json';assert not record.exists()
obj=dict(UTC=now(),status='READY FOR EXPLICIT NINE-FILE SOURCE PUBLICATION',owned_files=[dict(path=str(p.relative_to(R)),SHA256=sha(p),bytes=p.stat().st_size) for p in owned],archive_members=32,actual_FRSS_pages=21,actual_Xue_pages=20,book_changed=False,native_catalogue_changed=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__))
record.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],archive_SHA256=sha(archive),record_SHA256=sha(record),owned_files=[str(p.relative_to(R)) for p in owned])))
