from pathlib import Path
from datetime import datetime, timezone
import urllib.request, hashlib, json, subprocess, fitz
from PIL import Image, ImageDraw

C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009/dependencies_v1/FRSS18ArxivV2')
W=Path('/tmp/Xue_semiabelian_dependency_views_v1_20261009/FRSS18ArxivV2')
assert not C.exists() and not W.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
url='https://arxiv.org/pdf/1705.08212v2'
with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Book-source-audit/1.0'}),timeout=45) as r:
 data=r.read();resolved=r.url;content_type=r.headers.get('Content-Type')
assert data.startswith(b'%PDF-') and len(data)>10000
C.mkdir(parents=True);pdf=C/'FRSS_NonArchimedean_tropical_theta_1705.08212v2.pdf';pdf.write_bytes(data)
with fitz.open(pdf) as doc:
 count=len(doc);identity=' '.join(doc[0].get_text().lower().split())
 assert 'tropical theta functions' in identity and 'foster' in identity and 'rabinoff' in identity
 assert '1705.08212v2' in doc[0].get_text()
text_path=C/'FRSS_1705.08212v2_preparation_text.txt'
subprocess.run(['pdftotext','-layout',str(pdf),str(text_path)],check=True)
texts=text_path.read_text().split('\f');assert len(texts)==count+1 and not texts[-1].strip()
acq=dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACQUIRED — zero actual-reading credit',
 exact_version='arXiv:1705.08212v2',revision_UTC='2018-01-19 16:30:18',
 requested_URL=url,resolved_URL=resolved,content_type=content_type,path=str(pdf),bytes=len(data),
 SHA256=sha(pdf),physical_pages=count,preparation_text_path=str(text_path),preparation_text_SHA256=sha(text_path),
 related_DOI='10.1007/s00208-018-1646-3',
 edition_firewall='Public arXiv v2. Journal numbering differs according to primary arXiv metadata; journal theorem numbers are not authenticated by this file.',
 published_acquisition_failure='FRSS18Published/source_acquisition_failure_v1_20261009.json',
 official_repository='https://publikationen.uni-tuebingen.de/xmlui/handle/10900/89554 is a bibliography record, not a deposited full PDF.',
 actual_primary_reading_credit=0,mathematical_clearance=False,book_changed=False,
 helper_source=__file__,helper_SHA256=sha(__file__))
(C/'source_acquisition_v2_20261009.json').write_text(json.dumps(acq,ensure_ascii=False,indent=2)+'\n')
W.mkdir(parents=True);views=[]
with fitz.open(pdf) as doc:
 for n,start in enumerate(range(1,count+1,2),1):
  pages=list(range(start,min(start+2,count+1)));imgs=[]
  for p in pages:
   pix=doc[p-1].get_pixmap(matrix=fitz.Matrix(1.4,1.4),alpha=False)
   imgs.append(Image.frombytes('RGB',(pix.width,pix.height),pix.samples))
  canvas=Image.new('RGB',(sum(i.width for i in imgs)+20,max(i.height for i in imgs)+38),'white')
  draw=ImageDraw.Draw(canvas);x=0
  for p,img in zip(pages,imgs):
   draw.text((x+8,8),'FRSS arXiv 1705.08212v2: physical page '+str(p),fill='black')
   canvas.paste(img,(x,30));x+=img.width+20
  im=W/('sheet_%02d.png'%n);canvas.save(im)
  txt=W/('sheet_%02d.txt'%n);txt.write_text('\n\n'.join('FRSS ARXIV V2 PHYSICAL PAGE '+str(p)+'\n'+texts[p-1] for p in pages))
  views.append(dict(number=n,physical_pages=pages,path=str(im),image_SHA256=sha(im),selected_text_path=str(txt),
   selected_text_SHA256=sha(txt),source_PDF_SHA256=sha(pdf),actually_viewed=False,selected_text_read=False))
manifest=W/'manifest.json';manifest.write_text(json.dumps(views,ensure_ascii=False,indent=2)+'\n')
(C/'primary_notes_v2').mkdir()
prep=dict(UTC=datetime.now(timezone.utc).isoformat(),status='PREPARED — zero actual-reading credit',
 source=acq,prepared_pages=count,prepared_views=len(views),manifest_path=str(manifest),manifest_SHA256=sha(manifest),
 actual_primary_reading_credit=0,mathematical_clearance=False,book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__))
(C/'source_preparation_v2_20261009.json').write_text(json.dumps(prep,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=prep['status'],pages=count,views=len(views),PDF_SHA256=sha(pdf),bytes=len(data))))
