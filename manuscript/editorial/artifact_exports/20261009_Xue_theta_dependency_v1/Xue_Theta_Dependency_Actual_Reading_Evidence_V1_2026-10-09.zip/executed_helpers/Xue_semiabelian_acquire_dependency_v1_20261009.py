from pathlib import Path
from datetime import datetime, timezone
import urllib.request, hashlib, json, subprocess, sys, fitz
from PIL import Image, ImageDraw

root=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009')
config={
 'FRSS18Published':dict(url='https://link.springer.com/content/pdf/10.1007/s00208-018-1646-3.pdf',
  title='Non-Archimedean and tropical theta functions',identity='tropical theta functions',
  DOI='10.1007/s00208-018-1646-3',edition='Math. Ann. 372 (2018), 891–914; published edition'),
 'Kuhne22Published':dict(url='https://ems.press/content/serial-article-files/32695?nt=1',
  title='Points of small height on semiabelian varieties',identity='small height on semiabelian varieties',
  DOI='10.4171/JEMS/1125',edition='JEMS 24 (2022), 2077–2131; published edition, CC BY 4.0')
}
key=sys.argv[1]; cfg=config[key]
C=root/'dependencies_v1'/key
W=Path('/tmp/Xue_semiabelian_dependency_views_v1_20261009')/key
assert not C.exists() and not W.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
req=urllib.request.Request(cfg['url'],headers={'User-Agent':'Book-source-audit/1.0'})
try:
 with urllib.request.urlopen(req,timeout=45) as response:
  data=response.read(); resolved=response.url; kind=response.headers.get('Content-Type')
 assert data.startswith(b'%PDF-') and len(data)>10000
except Exception as error:
 C.mkdir(parents=True)
 record=dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACQUISITION FAILED — no reading credit',
  requested=cfg,error=type(error).__name__+': '+str(error),actual_primary_reading_credit=0,
  helper_source=__file__,helper_SHA256=sha(__file__))
 (C/'source_acquisition_failure_v1_20261009.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
 print(json.dumps(record)); raise
C.mkdir(parents=True)
pdf=C/(key+'.pdf'); pdf.write_bytes(data)
with fitz.open(pdf) as doc:
 count=len(doc); first=doc[0].get_text()
 assert cfg['identity'] in ' '.join(first.lower().split())
 assert cfg['DOI'] in first
text=C/(key+'_preparation_text.txt')
subprocess.run(['pdftotext','-layout',str(pdf),str(text)],check=True)
texts=text.read_text().split('\f'); assert len(texts)==count+1 and not texts[-1].strip()
acq=dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACQUIRED — zero actual-reading credit',
 source=cfg,requested_URL=cfg['url'],resolved_URL=resolved,content_type=kind,
 path=str(pdf),bytes=len(data),SHA256=sha(pdf),physical_pages=count,
 preparation_text_path=str(text),preparation_text_SHA256=sha(text),
 actual_primary_reading_credit=0,mathematical_clearance=False,book_changed=False,
 helper_source=__file__,helper_SHA256=sha(__file__))
(C/'source_acquisition_v1_20261009.json').write_text(json.dumps(acq,ensure_ascii=False,indent=2)+'\n')
W.mkdir(parents=True)
views=[]
with fitz.open(pdf) as doc:
 for n,start in enumerate(range(1,count+1,2),1):
  pages=list(range(start,min(start+2,count+1))); images=[]
  for p in pages:
   pix=doc[p-1].get_pixmap(matrix=fitz.Matrix(1.4,1.4),alpha=False)
   images.append(Image.frombytes('RGB',(pix.width,pix.height),pix.samples))
  canvas=Image.new('RGB',(sum(i.width for i in images)+20,max(i.height for i in images)+38),'white')
  draw=ImageDraw.Draw(canvas); x=0
  for p,img in zip(pages,images):
   draw.text((x+8,8),key+': physical page '+str(p),fill='black')
   canvas.paste(img,(x,30));x+=img.width+20
  image_path=W/('sheet_%02d.png'%n);canvas.save(image_path)
  selected=W/('sheet_%02d.txt'%n)
  selected.write_text('\n\n'.join(key+' PHYSICAL PAGE '+str(p)+'\n'+texts[p-1] for p in pages))
  views.append(dict(number=n,physical_pages=pages,path=str(image_path),image_SHA256=sha(image_path),
   selected_text_path=str(selected),selected_text_SHA256=sha(selected),source_PDF_SHA256=sha(pdf),
   actually_viewed=False,selected_text_read=False))
manifest=W/'manifest.json';manifest.write_text(json.dumps(views,ensure_ascii=False,indent=2)+'\n')
(C/'primary_notes_v1').mkdir()
prep=dict(UTC=datetime.now(timezone.utc).isoformat(),status='PREPARED — zero actual-reading credit',
 source=acq,prepared_pages=count,prepared_views=len(views),manifest_path=str(manifest),manifest_SHA256=sha(manifest),
 actual_primary_reading_credit=0,mathematical_clearance=False,book_changed=False,
 helper_source=__file__,helper_SHA256=sha(__file__))
(C/'source_preparation_v1_20261009.json').write_text(json.dumps(prep,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(source=key,status=prep['status'],pages=count,views=len(views),bytes=len(data),PDF_SHA256=sha(pdf))))
