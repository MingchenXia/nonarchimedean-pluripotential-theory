from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
D=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Hultberg_GVF_dependency_review_20261009/GVFFoundations26ArxivV2')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
n=int(sys.argv[1]);v=json.loads((D/'scope_preparation_v1_20261009.json').read_text());x=v['entries'][n-1]
assert x['number']==n and sha(x['image_path'])==x['image_SHA256'] and sha(x['text_path'])==x['text_SHA256']
assert sha(v['PDF'])==v['PDF_SHA256']
p=D/'primary_notes_v1'/('note_'+str(n).zfill(2)+'.md');q=p.with_suffix('.json')
assert p.exists() and len(p.read_text())>300 and not q.exists()
assert 'Read the complete selected text and displayed matching rendered image' in p.read_text()
if n>1:assert (p.parent/('note_'+str(n-1).zfill(2)+'.json')).exists()
o=dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACTUAL MATCHING COMPLETE-TEXT/IMAGE SOURCE READING',
    number=n,physical_pages=x['physical_pages'],complete_text_actually_read=True,matching_image_actually_viewed=True,
    text_SHA256=x['text_SHA256'],image_SHA256=x['image_SHA256'],note_SHA256=sha(p),source_version='2409.04570v2',
    PDF_SHA256=v['PDF_SHA256'],whole_source_read=False,independent_verifier_receipt=False,helper_source=__file__,helper_SHA256=sha(__file__))
q.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(number=n,actual_pages=x['physical_pages'],receipt_SHA256=sha(q))))
