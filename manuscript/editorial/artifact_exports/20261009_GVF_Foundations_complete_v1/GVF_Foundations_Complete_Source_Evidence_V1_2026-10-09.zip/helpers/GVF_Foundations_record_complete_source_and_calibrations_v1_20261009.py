from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
from fractions import Fraction
import sympy as sp
F=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Hultberg_GVF_dependency_review_20261009/GVFFoundations26ArxivV2')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prep=json.loads((F/'scope_preparation_v1_20261009.json').read_text())
assert sha(prep['PDF'])==prep['PDF_SHA256']=='b22a534273148c226bd1d1f607569f939f0e814b201f492667364f849678babc'
rows=[];pages=[]
for n,x in enumerate(prep['entries'],1):
 note=F/f'primary_notes_v1/note_{n:02d}.md';receipt=note.with_suffix('.json');v=json.loads(receipt.read_text())
 assert v['number']==n and v['physical_pages']==x['physical_pages']
 assert v['complete_text_actually_read'] and v['matching_image_actually_viewed']
 assert sha(note)==v['note_SHA256'] and sha(x['text_path'])==v['text_SHA256'] and sha(x['image_path'])==v['image_SHA256']
 assert v['PDF_SHA256']==prep['PDF_SHA256']
 rows.append(dict(number=n,physical_pages=v['physical_pages'],note_SHA256=sha(note),receipt_SHA256=sha(receipt)))
 pages+=v['physical_pages']
assert pages==list(range(1,53)) and len(rows)==26
out=F/'actual_complete_source_checkpoint_v1_20261009.json';assert not out.exists()
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — actual complete source reading; not recursive proof certification',source_version='arXiv:2409.04570v2, submitted 30 August 2026',PDF_path=prep['PDF'],PDF_SHA256=prep['PDF_SHA256'],physical_pages_read=pages,full_source_read=True,fresh_matching_views=26,receipts=rows,whole_book_reading_claim=False,primary_dependency_reading_credit=0,model_companion_status='OPEN — Conjecture 12.7 for every fixed e>=0',ordinary_source_audit_only=True,production_VERIFIED=False,independent_verifier_receipt=False,book_changed=False,original_results_promoted=[],canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
L=sp.Symbol('L',positive=True)
lattice=[]
for n in range(1,65):
 assert min(n,-n)<=0<=max(n,-n)
 assert abs(n-n)==0 and abs(n)+abs(-n)==2*n
 lattice.append(dict(alpha=n,beta=-n,printed_disjoint_condition=True,left_norm=0,right_norm=2*n,standard_disjoint_condition=False))
prime=[]
for d in range(2,34):
 normheight=Fraction(1,d);literal=Fraction(-1)+normheight;correct=Fraction(-1)+d*normheight
 assert literal<0 and correct==0
 prime.append(dict(polynomial=f'z^{d}-2',irreducibility='Eisenstein at 2',normalized_point_height_coefficient_of_log2=str(normheight),finite_Gauss_coefficient=0,negative_circle_integral_coefficient=-1,literal_without_closed_point_degree_coefficient=str(literal),correct_with_degree_coefficient=str(correct)))
roots=[]
for j in range(1,33):
 roots.append(dict(degree=1,a=f'2^-{j}',v_a_coefficient_of_log2=j,left_negative_part=0,printed_rhs_coefficient=-j,correct_positive_part=0))
for j in range(2,22):
 roots.append(dict(degree=2,a=f'sqrt(2)/2^{j}',v_a_coefficient_of_log2=str(Fraction(2*j-1,2)),left_negative_part=0,printed_rhs_coefficient=-(2*j-2),correct_positive_part=0))
mero=[]
for k in range(1,17):
 for m in range(1,17):
  # Exact circle formulas at log r=m^2; the origin is omitted in the literal sum.
  mero.append(dict(power=k,log_radius=m*m,sqrt_eta=m,literal_height_z_power=0,literal_height_inverse_power_sqrt_eta=k*m,literal_height_inverse_power_linear_eta=k,restored_origin_contribution_sqrt_eta=k*m))
assert len(mero)==256
scales=[]
for r in range(1,25):
 base=r*L;printed=r*L*L;correct=sp.simplify((r*L/L)*L)
 assert sp.simplify(correct-base)==0 and sp.simplify(printed-base)!=0
 scales.append(dict(source_scale=r,base_ht2=str(base),printed_target_ht2=str(printed),correct_parameter=r,correct_target_ht2=str(correct),nonzero_gap_reason='0<log(2)<1; L represents the actual natural log(2), not an arbitrary numerical fit'))
repeat=F/'repeat_opening_scope_clarifications_v1_20261009.json';assert not repeat.exists()
repeat.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACTUAL repeat complete opening text/image reviewed',physical_pages=[1,2],source_PDF_SHA256=prep['PDF_SHA256'],selected_text_SHA256=sha(prep['entries'][0]['text_path']),matching_image_SHA256=sha(prep['entries'][0]['image_path']),new_unique_reading_credit=0,clarifications=['Equation (3) requires a finite nonzero origin value; otherwise retain the origin order and leading coefficient.','Equation (4) agrees with normalized Weil point height only after multiplying each closed-point weight by its residue degree; alternatively explicitly define ht(x) as cycle height.','Section 8 identifies the intended Weil-model intersection construction but does not state a normalized-versus-cycle convention resolving the displayed weight.','The real failure of the literal meromorphic field example is separate from the conditional closed-point-height convention issue.']),indent=2)+'\n')
q=F/'literal_exact_calibrations_v1_20261009.json';assert not q.exists()
q.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='PASS — exact diagnostics of stated finite cases plus explicit asymptotic formulas',source_PDF_SHA256=prep['PDF_SHA256'],source_checkpoint_SHA256=sha(out),lattice_disjointness=dict(count=len(lattice),cases=lattice),closed_prime_weight=dict(count=len(prime),cases=prime,qualification='Conditional on normalized absolute Weil point height; cycle-height convention would include this degree.'),root_bound_positive_part=dict(count=len(roots),cases=roots),meromorphic_origin=dict(count=len(mero),cases=mero,general_formulas='For r>1, literal ht(z^k)=0 and ht(z^-k)=k log(r)/eta(r). eta=sqrt(max(1,log r)) tends to infinity but excludes inverses; eta=max(1,log r) gives unequal inverse heights. Include origin order or stronger normalization.',status='Literal example defect; no general GVF theorem refuted.'),ultrapower_scaling=dict(count=len(scales),cases=scales,correct_parameter='ht_K(2)/log(2)'),model_companion='OPEN',finite_checks_are_general_proof=False,production_VERIFIED=False,independent_verifier_receipt=False,original_results_promoted=[],book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(checkpoint_SHA256=sha(out),calibration_SHA256=sha(q),repeat_scope_SHA256=sha(repeat),physical_pages=52,matching_views=26,lattice_cases=64,prime_weight_cases=32,root_bound_cases=52,meromorphic_samples=256,scaling_cases=24)))
