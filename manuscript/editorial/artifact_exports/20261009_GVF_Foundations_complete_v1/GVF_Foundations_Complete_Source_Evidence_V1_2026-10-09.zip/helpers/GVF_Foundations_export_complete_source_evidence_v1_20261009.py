from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile,shutil
R=Path('/workspace/nonarchimedean-pluripotential-theory');E=R/'manuscript/editorial'
F=R/'source_material/Hultberg_GVF_dependency_review_20261009/GVFFoundations26ArxivV2'
G=R/'source_material/Xue_semiabelian_review_20261009/dependencies_v1/Hultberg26GapArxivV1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cp=F/'actual_complete_source_checkpoint_v1_20261009.json';x=json.loads(cp.read_text());assert x['physical_pages_read']==list(range(1,53)) and x['fresh_matching_views']==26 and x['full_source_read']
review=F/'own_complete_source_review_v1_20261009.md';candidate=F/'own_generic_line_scope_reconstruction_v1_20261009.md';assert len(review.read_text())>6000 and len(candidate.read_text())>4000
old=json.loads((G/'source_preparation_v1_20261009.json').read_text());view=json.loads(Path(old['manifest_path']).read_text())[16]
assert sha(view['path'])==view['image_SHA256'] and sha(view['selected_text_path'])==view['selected_text_SHA256']
r=F/'repeat_Hultberg_uniqueness_scope_v1_20261009.json';assert not r.exists()
r.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACTUAL complete repeat text/image reading and original-candidate scope reconstruction',Hultberg_source='arXiv:2601.04972v1',source_PDF_SHA256=view['source_PDF_SHA256'],physical_pages=[33,34],complete_selected_text_actually_read=True,matching_image_actually_displayed=True,selected_text_SHA256=view['selected_text_SHA256'],matching_image_SHA256=view['image_SHA256'],new_unique_primary_reading_credit=0,source_statement='Lemma 5.4.2: algebraically closed geometric GVF K has unique extending height on K(x) with ht(x)=0.',candidate_SHA256=sha(candidate),candidate_status='UNVERIFIED — no independent production-verifier receipt',constant_field_scope='Unique trivial subfield within a fixed height structure is distinct from uniqueness of extended height structures.',algebraic_base_passage='Symmetric extension on each N(x)/L pins the same symmetric N/K0 height before the comparison.',original_results_promoted=[],book_changed=False),ensure_ascii=False,indent=2)+'\n')
sourcezip=F/'GVF_Foundations_Complete_Source_Evidence_V1_2026-10-09.zip';record=F/'complete_evidence_export_v1_20261009.json';dest=E/'artifact_exports/20261009_GVF_Foundations_complete_v1'
paths={k:E/f'GVF_Foundations_complete_source_{k}_v1_20261009.{ext}' for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in [sourcezip,record,dest,*paths.values()])
files={}
for n in ['source_acquisition_v1_20261009.json','scope_preparation_v1_20261009.json','actual_complete_source_checkpoint_v1_20261009.json','literal_exact_calibrations_v1_20261009.json','repeat_opening_scope_clarifications_v1_20261009.json','repeat_Hultberg_uniqueness_scope_v1_20261009.json','own_complete_source_review_v1_20261009.md','own_generic_line_scope_reconstruction_v1_20261009.md']:files['records/'+n]=F/n
notes=[]
for row in x['receipts']:
 n=row['number'];note=F/f'primary_notes_v1/note_{n:02d}.md';receipt=note.with_suffix('.json')
 assert sha(note)==row['note_SHA256'] and sha(receipt)==row['receipt_SHA256']
 files['actual_notes/'+note.name]=note;files['actual_receipts/'+receipt.name]=receipt;notes.append(note.read_text())
for q in ['/tmp/GVF_Foundations_prepare_source_views_v1_20261009.py','/tmp/GVF_Foundations_record_source_note_v1_20261009.py','/tmp/GVF_Foundations_record_complete_source_and_calibrations_v1_20261009.py',__file__]:p=Path(q);files['helpers/'+p.name]=p
assert len(files)==64 and all(p.suffix in ['.md','.json','.py'] for p in files.values())
with zipfile.ZipFile(sourcezip,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,p in sorted(files.items()):z.write(p,n)
with zipfile.ZipFile(sourcezip) as z:
 assert len(z.namelist())==len(set(z.namelist()))==64 and z.testzip() is None
 for n,p in files.items():assert z.read(n)==p.read_bytes()
artifact=dict(path=str(sourcezip),bytes=sourcezip.stat().st_size,SHA256=sha(sourcezip),members=64)
paths['review'].write_text(review.read_text().rstrip()+'\n')
paths['reading_notes'].write_text(('# Actual complete GVF foundations v2 reading\n\nAll 52 physical pages in 26 ordered matching complete-text/image views.\nPreparation flags are historical; these notes and receipts carry actual credit.\n'+''.join('\n---\n\n'+s for s in notes)).rstrip()+'\n')
manifest=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete primary-source reading with exact scope and literal qualifications',source_checkpoint=x,source_checkpoint_SHA256=sha(cp),source_review_SHA256=sha(review),generic_line_candidate=dict(path=str(candidate),SHA256=sha(candidate),status='UNVERIFIED original candidate; outside book theorem typography',independent_verifier_receipt=False),evidence=artifact,primary_full_text_and_images_and_PDFs_excluded=True,book_changed=False,GitHub_published=False,model_companion='OPEN — Conjecture 12.7 for every fixed e>=0',canonical_status_changes=[])
paths['manifest'].write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — byte-verified authored source evidence',evidence=artifact,reading_credit_from_export=0,GitHub_published=False,original_results_promoted=[],canonical_status_changes=[]),indent=2)+'\n')
dest.mkdir(parents=True);shutil.copyfile(sourcezip,dest/sourcezip.name);assert sha(dest/sourcezip.name)==sha(sourcezip)
(dest/'SHA256SUMS').write_text(sha(sourcezip)+'  '+sourcezip.name+'\n')
(dest/'README.md').write_text(('# GVF foundations complete-source authored evidence\n\n'+review.read_text()+'\nThe 64-member archive contains authored notes, actual receipts, exact\ndiagnostics, scope clarifications, the unverified generic-line candidate\nand helpers. It excludes primary PDFs, full source text and primary-source\nimages. Every member was extracted and byte-verified. Export/upload\ngrants no source-reading credit or independent theorem clearance.\n').rstrip()+'\n')
editorial={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in [*paths.values(),*dest.iterdir()]};assert len(editorial)==7
record.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='EXPORTED — authored complete source evidence; remote verification pending',source_checkpoint_SHA256=sha(cp),evidence=artifact,editorial_files=editorial,member_hashes={n:sha(p) for n,p in sorted(files.items())},book_PDF_SHA256=sha(R/'manuscript/book.pdf'),book_pages=4681,actual_primary_pages=52,matching_views=26,model_companion='OPEN',generic_line_candidate='UNVERIFIED',original_results_promoted=[],canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(evidence_members=64,evidence_SHA256=sha(sourcezip),export_SHA256=sha(record),editorial_files=7)))
