# Generic-line extension candidate: exact scope and algebraic base

Status: **UNVERIFIED original adversarial candidate**, outside book theorem
typography. No independent production-verifier receipt is available.
This fresh reconstruction preserves the previously frozen Hultberg audit.
It addresses the literal uniqueness claim of Hultberg arXiv:2601.04972v1,
Lemma 5.4.2, and its local Gauss-support proof; it asserts no refutation
of the intended main Bogomolov or constant-field theorem.

The complete selected text and matching rendered image for Hultberg physical
pages 33–34 were read again. The lemma assumes an algebraically closed
geometric GVF K and claims a unique extending GVF structure on K(x)
with ht(x)=0. This concerns uniqueness of an **extended height structure**.
Within one fixed geometric GVF, the height-zero elements still form its
unique maximal trivial subfield. These two statements must stay distinct.
The latest foundations v2, Proposition 10.5, instead asserts uniqueness
for Aut-invariant finite-Galois extensions and explicitly allows other
extensions in Example 10.6. It does not settle this transcendental claim.

Let k be the countable algebraically closed field Q-bar with trivial
height. Equip K0=k(a,b) with the model height determined by the hyperplane
class on P2_k. For a nonzero polynomial tuple (f0,...,fn) with gcd one,
its projective height is D=max deg(fi). Rational tuples reduce to this
case by clearing common denominators and canceling the common factor.
The homogenized degree-D forms have no common divisorial factor; their
base locus is a finite subscheme of P2. This is the usual model-height
construction, importing divisor intersections on a projective surface.

Use the same underlying field L=k(a,b,x). There are two geometric GVF
structures on it, both ordinary degree heights on a projective line over
a trivially valued constant field:

- Slope structure: constants F1=k(x,y), variable t, with a=t and b=xt+y;
  here y=b-xa and L=F1(t).
- Intercept structure: constants F2=k(s,x), variable t, with a=t and
  b=st+x; here s=(b-x)/a and L=F2(t).

These changes of variables are field isomorphisms: in each case the three
named parameters are algebraically independent over k. Both structures
restrict to the stated K0 height on **every** projective tuple. Indeed,
the generic projective line [1:t:xt+y], or [1:t:st+x], avoids the finite
base locus of the homogenized tuple. Its highest-degree coefficient is
nonzero over the independent slope parameter. Restriction therefore has
no common factor and degree D. This is a general base-height argument;
the earlier finite symbolic tuple checks are merely diagnostics.

In both structures ht(x)=0. However,

    ht_slope(b-xa)=ht_slope(y)=0,
    ht_intercept(b-xa)=ht_intercept((s-x)t+x)=1.

The intercept expression includes the constant term x. Dropping it does
not change its height but is not the actual change-of-variables identity.
Also, in the slope structure, at t=infinity,

    v(x-b/a)=v(-y/t)=1,  v(b/a)=0.

Thus x-b/a has absolute value less than one while b/a has absolute value
one, despite the global identity ht(x+c)=ht(c). The global height equality
alone does not enforce the printed local Gauss condition at every place.

To meet the algebraically closed-base hypothesis, choose a common
algebraic closure Omega of L, and let K be the algebraic closure of K0
inside Omega. Extend each L-height symmetrically to Omega, then restrict
to K(x). The symmetric construction is an imported finite-Galois/norm
argument; foundations v2 has its complete printed proof on pages 38–40,
with its integrability bound's positive-part correction recorded separately.

For each finite Galois N/K0 contained in K, pure transcendence gives
N intersect L=K0 and N(x)/L is Galois with group Gal(N/K0). The symmetric
Omega-height restricts to an invariant height on N(x), hence to an
invariant extension on N of the common K0 height. Uniqueness of the
invariant finite-Galois extension therefore makes both restrictions to
N the same. Taking the directed union gives the same fixed GVF structure
on the algebraically closed, countable geometric field K. Restriction
preserves ht(x)=0 and the two displayed distinct heights of b-xa.
Consequently the two candidate structures on the same K(x) satisfy the
literal hypotheses of Lemma 5.4.2 while disagreeing.

The algebraic-base passage is not justified by comparing two arbitrary
extensions on K. It uses symmetry on each N(x) and finite-Galois
uniqueness to pin the **same** K-height before making the comparison.
No use is made of the disputed transcendental uniqueness lemma itself.
The classical constant-field assertion for one fixed geometric height
remains consistent, with different enlarged constant subfields in the
two different structures on K(x).

Remaining acceptance boundary: an exact-current independent production
verifier must assess this entire statement, the all-tuple generic-line
restriction, and the symmetric-extension/compositum passage before any
original-result promotion. The book's canonical problem inventory,
BJ22 homogeneous Siu/envelopes and LPWZ density statuses are unchanged.
