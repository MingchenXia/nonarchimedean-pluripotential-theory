# Original metric/radial dependency actual view 10

UTC: 2026-10-09T04:00:31.370947+00:00. Source: Finski_PLMS2025. Physical pages: 19, 20.

Read the complete selected text and displayed matching rendered image.

Finski published pages 19–20 complete the displayed downstream classification arguments. Theorem 1.1 uses continuous positive FS limit, the external multiplicative-generation estimate for Hilbert norms, finite-dimensional tensor comparison, and Theorem 3.1. It first controls degrees divisible by a fixed sufficiently large k', then finitely many residue classes using multiplication and comparison constants. That fills a genuine degree-sequence issue rather than silently restricting the claim to a Veronese subsequence.

Remark 3.4 uses a uniform all-products error exp(f(k1)+...+f(kr)+f(sum ki)), where f=o(k), not just an arbitrary pairwise sublinear defect. Theorem 1.3 uses the dyadic subsequence N_(2^k), whose normalized metric lengths decrease, a bounded-limit finite-p convergence step, and continuous finite-degree FS metrics. It does not assert monotonicity of the complete normalized degree sequence. Epsilon constants can be reallocated to accommodate the factor-2 norm-distance convention; this cannot replace any missing external classification proof.

The exact published locator for finite-p FS isometry is Corollary 3.5, physical page 20: two bounded submultiplicative graded complex norms on the ample section ring have dp equal to the Darvas distance of their regularized FS metrics for finite p. The p=infinity extension explicitly requires continuity of both raw FS limits. Together with actual published Lemma 2.6 for the ray comparison, this supplies the version-specific mapping for the RWN25 older locators Lemma 2.8/Corollary 3.6. It is a mapping of substantive statements, not an assertion that those numbers occur in this published edition.

The proof of Corollary 3.5 is a short dependency chain through 1.3, 2.9, 2.13, 2.16, with the endpoint requiring 1.1 and another cited Finski paper. The external quantization and the unselected Section 4 classification argument remain dependencies; this selected reading is not a recursively complete proof audit. The closing paragraph only proposes removing submultiplicativity before giving a counterexample on the next page; no generalized isometry is imported. No open-problem status changes.
