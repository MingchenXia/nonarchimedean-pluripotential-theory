# Original metric/radial dependency actual view 07

UTC: 2026-10-09T03:59:22.182712+00:00. Source: Finski_PLMS2025. Physical pages: 13, 14.

Read the complete selected text and displayed matching rendered image.

Finski published pages 13–14 state the projective/injective tensor comparison with a factor min(dim V1,dim V2); Hermitian tensor norms lie between them. This is a stated external finite-dimensional norm result here, without its proof on these pages.

The pluripotential setting is a compact complex Kähler manifold; the integral Kähler class is identified with an ample Hermitian line bundle, using squared metrics h=e^{-u}h0. Monge–Ampère measure is a probability measure omega_u^n / integral omega^n, and Darvas tangent norms use probability Lp integrals. This explains the earlier factor 2 when logarithms of ordinary norm lengths are compared to metric potentials.

The sentence that finite-energy completions have a vector-space structure cannot mean closure under arbitrary vector addition and scalar multiplication with the fixed omega-psh condition. Equation (2.39), intersection of all finite-p energy spaces equals bounded psh, must not be imported literally: membership in every finite-p energy class alone does not force boundedness. A local test shape u=-log(-log|z|) near a point has unbounded depth but all polynomial energy moments are finite against its local Laplacian density, proportional to dt/t^2 with t=-log|z|; any use as a global counterexample must also supply the compactification and full-mass conditions. These pages do not supply that construction, so record the problematic inference rather than promote a new theorem.

The monotone convergence statement (2.40) names a bounded limit and should not be used to infer a uniformly bounded limit from an arbitrary increasing sequence of individually bounded potentials. Equation (2.43) gives d1=energy difference for ordered finite-energy potentials. The weak geodesic is a distinguished envelope and, for bounded endpoints, solves the homogeneous Bedford–Taylor Monge–Ampère equation on the annulus. The displayed subgeodesic condition (2.45) writes u-hat where the curve is named v; its intended lifted curve is v-hat. These are source-local statements with external Darvas/Berndtsson/Guedj–Zeriahi dependencies not recursively verified here. No non-Archimedean envelope/Siu assertion or whole-primary reading is certified.
