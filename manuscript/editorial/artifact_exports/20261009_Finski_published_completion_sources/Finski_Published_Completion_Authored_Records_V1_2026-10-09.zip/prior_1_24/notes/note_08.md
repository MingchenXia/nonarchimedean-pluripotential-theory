# Original metric/radial dependency actual view 08

UTC: 2026-10-09T03:59:49.083224+00:00. Source: Finski_PLMS2025. Physical pages: 15, 16.

Read the complete selected text and displayed matching rendered image.

Finski published pages 15–16 locate Darvas–Lu unique geodesicity for 1<p<infinity, distinct from d1. The spectral velocity measure is defined here for a smooth positive initial potential and a bounded psh terminal potential, with probability-normalized MA. Nonnegative velocity for ordered endpoints makes ordinary integer moments determine the compactly supported measure; absolute p-moments of unordered signed velocity do not determine its sign distribution.

Theorem 2.9 is a stated external Darvas–Lu–Rubinstein quantization result for bounded psh metrics on an ample complex line bundle, probability volume and finite p. The Hilbert norm formula requires the kth tensor-power metric; its subscript h^K versus h^L is typographical notation rather than a change of scalar normalization. The finite norm distance carries the previously explicit factor 2, matching h=e^{-u}h0. No endpoint p=infinity quantization is stated by this theorem.

Theorem 2.11 explicitly imports BE21 Theorem 7.26/Corollary 7.27 for the pointwise FS envelope Q in multiplicative metric-length notation. Its Q is the infimum of continuous psh majorant lengths, equivalent to the supremum of continuous psh minorant additive weights. Pointwise Q and its semicontinuous regularization are kept separate; no blanket equality with the original metric or non-Archimedean envelope continuity is inferred. The particular complex regularization argument cites Demailly and is not an unrestricted NA descent theorem.

Proposition 2.13 states Hilbert/sup asymptotic finite-p equivalence for bounded psh metrics regularizable from above; the strong endpoint also requires continuity. Its proof begins with a fixed monotone continuous approximation chosen for a Darvas epsilon, and only then a degree threshold for its own Hilbert/sup comparison. The quantifier order is important. The proof continues on page 17, so is not certified complete in this view. The repeated physical page 15 was already selected in the earlier October 5 dependency checkpoint; repeated review is useful but is not new unique source-page credit. No full primary or whole-book claim.
