# Original metric/radial dependency actual view 06

UTC: 2026-10-09T03:58:52.072555+00:00. Source: Finski_PLMS2025. Physical pages: 11, 12.

Read the complete selected text and displayed matching rendered image.

Finski published physical pages 11–12 complete Lemma 2.5: the min–max envelope slopes for a Hermitian reference equal t times the filtration weights; the envelope itself need not be Hermitian. John comparison transfers slope estimates to an arbitrary reference. Keep the factor 2 in d_infinity distinct from the logarithm of a norm comparison: equation (2.24) appears to use half the distance constant, although the stated slope bound by log N is sufficient.

Lemma 2.6 explicitly compares two constructions, the complex sum envelope A_t and the adapted quadratic Hermitian ray H_t. Its claimed d_infinity error log N is consistent with the stronger direct comparison H_t <= A_t <= sqrt(N) H_t, proved using the norm-envelope property and coordinate decomposition. The weaker displayed lower estimate H_t <= N A_t together with (2.30) alone would only give 2 log N in the source's factor-2 distance convention. Thus the estimate has a direct elementary justification, but the two finite-dimensional norms are not equal. The source itself explains that the sum envelope has useful monotonicity and multiplicativity properties while Hermitian-ray multiplicativity is unclear. This qualifies the exact-equality assertion in the separately reviewed RWN25 version without changing any general theorem status.

Equation (2.31) identifies the trivial-valued norm exp(-w_F), with zero treated by w_F(0)=+infinity. The common root limits in (2.32) concern nonzero vectors; zero needs the separate logarithm convention. The page introduces projective tensor norms by infima of sums of costs and injective tensor norms by dual unit-ball suprema; the next tensor comparison proof is outside this view. All these assertions use genuine finite-dimensional complex norms, not nontrivially valued ultrametric norms. This is an ordinary selected-source reading and direct comparison check, not an independent hostile-model receipt or a whole-primary/book pass.
