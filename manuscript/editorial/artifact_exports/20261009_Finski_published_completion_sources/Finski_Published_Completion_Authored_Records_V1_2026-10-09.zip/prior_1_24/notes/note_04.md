# Original metric/radial dependency actual view 04

UTC: 2026-10-09T03:51:33.167011+00:00. Source: Finski_PLMS2025. Physical pages: 7, 8.

Read the complete selected text and displayed matching rendered image.

Finski published PLMS physical pages 7–8 give the exact quotient FS metric on kL and the finite spectral conventions. Equation (2.2) restores the correct target kL, and Lemma 2.1 identifies the fiber quotient norm. For a degree-one positive continuous pseudonorm, double dual is its convex-hull norm, so FS depends on that genuine norm and is psh. Positivity is not ordinary smoothness for arbitrary norms.

The logarithmic relative spectrum is log(N2/N1), with decreasing successive minima. The introductory factor-two definition gives d_p=2 times the probability pth-root moment, corresponding to the pth-root trace of |log A|^p/r for a Hermitian transfer operator A. Literal (2.8) omits the p on |log A| inside the trace. A scalar log A=4 and p=2 gives actual d2=4 but the printed expression 2. Similarly, (2.11)'s equality of the maximum absolute slope with d_infinity omits the factor two: the minimal norm comparison exponent is d_infinity/2. The equivalence relation is unaffected by a fixed factor, but quantitative identities need consistent calibration.

The complex John approximation is N_H<=N<=sqrt(r)N_H. Together with the finite Hermitian triangle inequality, it controls the logarithmic rank losses and proves finite-p asymptotic equivalence is transitive when r_k grows polynomially. This does not claim an exact Hermitian replacement of an arbitrary norm. The primary John locator remains an external source input.

The final sentence identifies all Hermitian norms with SL(r,C)/SU(r); this needs the determinant-normalized slice or the additional scalar real factor. In rank one the SL quotient is a point while the positive norm lengths have a nontrivial logarithmic line. The full space uses GL(r,C)/U(r), with the corresponding normalized metric. The continuation must preserve that scalar direction.

These are actual source checks and direct rank/scalar diagnostics. No original general theorem, independent model receipt or canonical problem change is claimed.
