# Original metric/radial dependency actual view 02

UTC: 2026-10-09T03:49:31.216151+00:00. Source: Finski_PLMS2025. Physical pages: 3, 4.

Read the complete selected text and displayed matching rendered image.

Finski published PLMS physical pages 3–4 explicitly fix the normalization: finite d_p is twice the probability pth-root norm of logarithmic norm-length ratios, and d_infinity is twice their maximum. This factor two is intentional and referred to equation (2.8). It directly addresses the missing factor-two interface in the RWN25 literal formulas; it must not be removed when importing the actual quantization theorem. The boundedness premise is N>=sup norms for some smooth metric; submultiplicativity provides the remaining controlled asymptotics in the later proof.

Theorem 1.3 asserts finite-p asymptotic equivalence for bounded submultiplicative norms, while Remark 1.4 explicitly says infinity equivalence can fail without FS continuity. A continuous FS limit without submultiplicativity also fails to determine the norm class, via Proposition 3.6. These are independent premises, not interchangeable. The proposed big-line-bundle extension is source-era research scope because singular metric extension tools are missing; the present proof does not establish it.

Definition 1.5 uses order of the metric lengths: regularizable from above means a decreasing sequence of continuous psh metric lengths, hence increasing local negative-log weights, converging almost everywhere. The later lsc regularization of metric lengths corresponds to usc regularization of their negative-log weights. The uniqueness assertions are restricted to the stated regularizable class. The tensor/symmetric-algebra and Ohsawa–Takegoshi input is attributed and its core proof lies outside the present selected 24-page prefix; it will remain an explicit external input rather than being declared recursively certified.

The intro's Narasimhan–Simha formula as printed has outer exponent k, giving degree-two scaling under a scalar section multiple; the usual degree-one pseudonorm would have k/2. This application is not imported from the introductory formula. The body definition and Section 5 would need separate review if used. No blanket theorem failure or original result is claimed by that literal scaling observation.

This note records these actual pages only. It supplies no whole-paper/whole-book reading or independent-model receipt, and changes no canonical problem status.
