# Original metric/radial dependency actual view 01

UTC: 2026-10-09T03:48:38.381080+00:00. Source: Finski_PLMS2025. Physical pages: 1, 2.

Read the complete selected text and displayed matching rendered image.

Finski published PLMS 2025, physical pages 1–2. The author-posted controlling PDF is the 47-page published article e70077, DOI 10.1112/plms.70077, received 7 August 2024, revised 22 June 2025 and accepted 17 July 2025. This fresh review uses the existing pinned PDF; it does not claim a new download or replace its previous limited reading receipt. Physical page 1 was already read in the 5 October endpoint checkpoint and receives no new unique-primary-page credit; page 2 is newly in this review's scope.

The setup is complex holomorphic line bundles on compact complex manifolds, with ampleness imposed for the classification theorem. Sup norms of a bounded metric are submultiplicative. Strong asymptotic equivalence means an exp(epsilon k) comparison for every epsilon and all sufficiently large k; it is an asymptotic infinity comparison, not finite-degree exact equality. FS_k is a metric on kL and must be taken to its 1/k root to return to L. Fekete supplies a limit of that root sequence; this does not assert monotonicity over every consecutive degree.

Theorem 1.1 uses continuity of the FS limit to identify the graded norm with sup norms up to the strong subexponential equivalence. Its proof is later in the selected pages and is not accepted from this introductory statement alone. The printed contents distinguishes the quantization/classification sections from the unselected tensor-norm, Narasimhan–Simha and later ray sections. This checkpoint is intentionally partial, not a whole 47-page paper reading or another whole-book pass.
