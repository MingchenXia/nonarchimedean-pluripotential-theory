# Original metric/radial dependency actual view 03

UTC: 2026-10-09T03:50:22.652772+00:00. Source: Finski_PLMS2025. Physical pages: 5, 6.

Read the complete selected text and displayed matching rendered image.

Finski published PLMS physical pages 5–6 complete the introductory scope and start §2.1. The article assumes an ample L and a compact complex manifold throughout the body. Its pseudonorm definition is explicitly continuous, positive away from zero and absolutely homogeneous of degree one, without requiring the triangle inequality. Thus the preceding intro Narasimhan–Simha outer exponent k, rather than k/2, really needs reconciliation with this declared type if that application is used. The convex-hull norm is defined from the convex hull of the unit ball, not by silently treating a squared gauge as a degree-one norm.

The filtration is decreasing, exhaustive/separated degreewise and left-continuous. The printed graded boundedness is the upper weight cutoff F^{Ck}=0; its relation to a two-sided linear bound uses multiplicativity and finite generation of the ample section ring, not a bare equivalence for arbitrary graded sequences. The tensor/functional-analytic theorem needed for classification is explicitly deferred to Section 4, outside this selected prefix. The primary theorem is therefore not recursively certified by reading its announcement.

The abstract regularization definition uses punctured limsup/liminf. For arbitrary functions this is not always the usual majorant/minorant regularization: an isolated upward spike can be discarded by punctured limsup, and at an isolated point the punctured neighborhood is empty. For the actual FS sup/inf classes one must retain the appropriate semicontinuity and zero-dimensional convention. The book's regularization convention includes the point and does not infer a general identity for arbitrary obstacles from that short definition.

Section 2.1 begins the Kodaira quotient construction; the text names the output a metric on L while the quotient naturally lives on kL, so the subsequent root-degree convention must control the type. No application in the unselected NS or tensor sections is imported, no canonical problem is resolved and no independent-model receipt is claimed.
