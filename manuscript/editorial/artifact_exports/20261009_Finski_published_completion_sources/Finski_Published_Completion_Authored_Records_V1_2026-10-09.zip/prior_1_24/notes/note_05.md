# Original metric/radial dependency actual view 05

UTC: 2026-10-09T03:53:10.430575+00:00. Source: Finski_PLMS2025. Physical pages: 9, 10.

Read the complete selected text and displayed matching rendered image.

Finski published PLMS physical pages 9–10 supply the actual limit premise missing from the RWN25 arbitrary-sequence limsup identity. Lemma 2.2 proves finite Hermitian d1 additivity for ordered norms. Section 2.2 defines the pairwise 'same asymptotic class' condition to require a finite d1 distance and an actual limit replacing limsup. Lemma 2.4 uses that premise for the three ordered graded norms, together with Hermitian approximations whose logarithmic rank error is o(k). The needed conclusion is valid under those limits, not for the oscillating arbitrary-sequence diagnostic. A safe rank-error constant can be obtained directly from the chosen scalings; no exact finite equality with a Hermitian approximation is asserted.

Equation (2.15) defines the filtered complex sum-envelope ray. The semigroup identity (2.18) uses nested filtration levels and positive times, not associative multiplication of arbitrary filtration norms. Its restriction-to-high-level decomposition can be justified without a norm-one projection: if f belongs to F^mu, combine all pieces whose filtration levels are below mu. Their sum lies in F^mu because the other pieces and f do; replacing them by this sum at level mu does not increase cost, by the ordinary triangle inequality and exp(-s mu)<=exp(-s mu_i). This supplies the exact restriction step for an arbitrary complex base norm.

The flattened double decomposition then proves the two-stage envelope identity. Approximation errors should be allocated over the finitely many pieces before tending to zero. Lemma 2.5 concerns successive-minimum slopes of the envelope ray. Its stronger Hermitian-base statement need not mean that the envelope itself is Hermitian: the C2 sum-envelope diagnostic shows otherwise. The min-max flag proof begins here and must be completed on the following page. The spectrum convention remains log(second norm/first norm), so the ray direction in (2.23) has the displayed positive t times jump weights.

No book or canonical status is changed; this is a partial primary dependency audit with no independent-model receipt.
