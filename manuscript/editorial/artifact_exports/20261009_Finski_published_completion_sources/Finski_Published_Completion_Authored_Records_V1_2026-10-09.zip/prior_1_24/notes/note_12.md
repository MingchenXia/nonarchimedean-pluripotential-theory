# Original metric/radial dependency actual view 12

UTC: 2026-10-09T04:01:38.526186+00:00. Source: Finski_PLMS2025. Physical pages: 23, 24.

Read the complete selected text and displayed matching rendered image.

Finski published pages 23–24 specify eventual surjectivity of the restriction map for a closed complex submanifold and ample L. Theorem 3.10 is an external semiclassical extension comparison for continuous psh metrics; its exact version is delegated to another Finski paper, with Bost/Zhang/Randriambololona alternatives carrying their own hypotheses. It is an asymptotic norm equivalence, not an exact finite-degree extension equality.

Theorems 3.11–3.12 keep finite-p equivalence distinct from the endpoint. The raw FS-envelope noncontact set E is pluripolar for the regularizable bounded metric, and its pluripolar hull E* governs generic restriction. The dichotomy that Y is contained in E* or Y intersect E* is pluripolar needs Y connected, or application to each connected component; a disconnected Y with one whole component in E* does not satisfy that literal alternative. Under the proper component condition, equality away from a pluripolar set identifies regularized restrictions. The endpoint uses the stronger condition Y intersect E empty, giving continuity of the restricted metric by the matching upper/lower semicontinuity at contact points. No assertion that all submanifolds avoid E* is made.

The converse tests zero-dimensional submanifolds Y={x}, whose quotient norms detect pointwise Q, with generic points outside a pluripolar set. The proof depends on the earlier finite-p classification, Bedford–Taylor/Josefson regularization, and the stated extension inputs. Those original dependencies are not all recursively read by this checkpoint. The final paragraph only begins the symmetric tensor formalism and evaluation norm (3.27); the central Section 4 proof of Theorem 3.1 remains outside pages 1–24.

This closes this checkpoint's selected Finski pages 1–24, not the full 47-page published paper. Earlier October 5 selected pages 1,15,35,36 remain separately frozen; pages 1 and 15 overlap this selection and receive no new unique-page credit. Published Lemma 2.6 and Corollary 3.5 now provide exact version-specific ray-comparison and FS-isometry locators. No homogeneous Siu/general envelope bridge is resolved, and no full-book pass is claimed.
