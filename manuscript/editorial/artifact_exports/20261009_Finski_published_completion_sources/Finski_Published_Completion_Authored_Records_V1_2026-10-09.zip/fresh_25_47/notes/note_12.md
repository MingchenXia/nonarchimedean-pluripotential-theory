# Original Finski published-completion actual view 12

UTC: 2026-10-09T05:06:03.957751+00:00. Source: Finski_PLMS2025. Physical pages: 47.

Read the complete selected text and displayed matching rendered image.

Physical page 47 completes references 46-76. All text and the one-page matching rendered image were inspected. The exact original dependencies are Kollár 1997 for singularities of pairs; Ohsawa-Takegoshi 1987 for L2 extension; Phong-Sturm 2007 for test-configuration rays, their two distinct 2010 papers for degenerate Dirichlet existence and ray regularity/uniqueness; Reboulet Math Z 299 (2021), distinct from the separately audited 2004.11635v1 preprint; Ross-Witt Nystrom 2014 and their separate 2017 prescribed-singularity envelopes; and Székelyhidi Math Ann 362 (2015) for filtrations/test configurations. These bibliographic identifications do not give original-proof reading credit. This completes the new physical 25-47 selection: 23 complete pages in 12 individual matching text/image views with chronological notes. Complete published-PDF coverage 1-47 is to be established by byte-pinned union with the prior actual 1-24 record, not by this preparation or by the bibliography alone. The two freshly repeated pages 35-36 have been marked as older-overlap pages; no whole-book, original-general-result, independent-model or canonical-status claim is made.
