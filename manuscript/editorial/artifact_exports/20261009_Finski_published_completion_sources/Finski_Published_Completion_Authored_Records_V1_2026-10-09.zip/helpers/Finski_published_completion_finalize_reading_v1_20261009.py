from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R / 'source_material/Finski_published_completion_review_20261009'
out = C / 'actual_primary_reading_v1_20261009.json'
assert not out.exists()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
prep_path = C / 'primary_view_preparation_v1_20261009.json'
prep = json.loads(prep_path.read_text())
assert prep['actual_source_reading_credit'] == prep['actually_read_pages'] == 0
assert sha(prep['manifest_path']) == prep['manifest_SHA256']
rows = json.loads(Path(prep['manifest_path']).read_text())
assert len(rows) == 12
source = prep['sources']['Finski_PLMS2025']
assert sha(source['path']) == source['SHA256'] and source['total_physical_pages'] == 47
views = []
last = None
for i, row in enumerate(rows, 1):
    p = C / f'primary_notes_v1/note_{i:02d}_receipt.json'
    a = json.loads(p.read_text())
    assert a['number'] == i and a['source'] == row['source'] == 'Finski_PLMS2025'
    assert a['physical_pages'] == row['physical_pages']
    assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
    assert not row['actually_viewed'] and not row['selected_text_read']
    assert last is None or a['UTC'] > last
    last = a['UTC']
    for key, h in [('image_path','image_SHA256'),('selected_text_path','selected_text_SHA256'),('note_path','note_SHA256')]:
        assert sha(a[key]) == a[h]
    assert a['source_PDF_SHA256'] == row['source_PDF_SHA256'] == source['SHA256']
    views.append(dict(**a, observation_receipt_path=str(p), observation_receipt_SHA256=sha(p)))
new_pages = sorted(p for v in views for p in v['physical_pages'])
assert new_pages == list(range(25,48))
prior_path = R / 'source_material/Metric_radial_dependencies_review_20261009/actual_primary_reading_v1_20261009.json'
prior = json.loads(prior_path.read_text())
old_views = [v for v in prior['views'] if v['source'] == 'Finski_PLMS2025']
assert len(old_views) == 12
old_pages = sorted(p for v in old_views for p in v['physical_pages'])
assert old_pages == list(range(1,25))
assert old_views[-1]['UTC'] < views[0]['UTC']
for a in old_views:
    assert a['source_PDF_SHA256'] == source['SHA256']
    p = Path(a['observation_receipt_path'])
    assert sha(p) == a['observation_receipt_SHA256']
    receipt = json.loads(p.read_text())
    assert receipt['complete_selected_text_actually_read'] and receipt['matching_image_individually_displayed_and_reviewed']
    for key, h in [('image_path','image_SHA256'),('selected_text_path','selected_text_SHA256'),('note_path','note_SHA256')]:
        assert sha(a[key]) == a[h] == receipt[h]
union = sorted(set(old_pages + new_pages))
assert union == list(range(1,48))
endpoint_path = R / 'source_material/finski_endpoint_dependencies_20261005/selective_reading_progress.json'
endpoint = json.loads(endpoint_path.read_text())
earlier = sorted({p for v in endpoint['actual_views'] if v['source_PDF_sha256'] == source['SHA256'] for p in v['physical_pages']})
assert earlier == [1,15,35,36]
old_named_union = set(old_pages + earlier)
assert len(old_named_union) == 26
overlap = sorted(old_named_union.intersection(new_pages))
assert overlap == [35,36]
new_unique = sorted(set(new_pages)-old_named_union)
assert len(new_unique) == 21
diag_path = C / 'exact_diagnostics_v1_20261009.json'
diag = json.loads(diag_path.read_text())
assert len(diag['families']) == 14 and all(x['status'].startswith('PASS') for x in diag['families'])
for n, h in prep['protected_core_inputs'].items():
    assert sha(R / n) == h
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip() == prep['baseline_commit']
obj = dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — published PDF complete by pinned actual 1–24 plus fresh 25–47 reading; no recursive external-proof claim',
    sources=prep['sources'], actual_selected_source_page_pairs=23,
    actual_individually_displayed_matching_views=12, views=views,
    prior_complete_selection_record=dict(path=str(prior_path), SHA256=sha(prior_path), physical_pages=old_pages, views=old_views),
    complete_published_composite=dict(source_PDF_SHA256=source['SHA256'], physical_pages=union, actual_unique_pages=47,
        actual_matching_views_in_two_ordered_checkpoints=24, whole_physical_PDF_read=True,
        unrelated_primary_pages_or_preparation_counted=False),
    named_older_comparison=dict(endpoint_record_path=str(endpoint_path), endpoint_record_SHA256=sha(endpoint_path),
        endpoint_pages=earlier, prior_combined_pages=sorted(old_named_union), prior_combined_count=26,
        freshly_repeated_pages=overlap, new_unique_pages=new_unique, new_unique_count=21),
    preparation_record_SHA256=sha(prep_path), exact_diagnostics_SHA256=sha(diag_path),
    supplemental_reinspection_SHA256=sha(C / 'supplementary_definition_reinspection_v1_20261009.json'),
    complete_selected_text_read=True, preparation_flags_unchanged=True,
    whole_primary_PDF_reading_claim=True, other_source_editions_claimed_read=False,
    published_full_reading_does_not_certify_original_external_dependencies=True,
    original_results_promoted=[], independent_model_receipt=None,
    canonical_status_changes=[], active_book_changed=False, native_editor_changed=False,
    whole_book_new_reading_claim=False, baseline_commit=prep['baseline_commit'],
    BJ22_Theorem_6_21_repaired=False, general_envelope_theorem_admitted=False, helper_source=__file__)
out.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(status='DONE', selected_pages=23, views=12, complete_published_pages=47,
    new_unique_pages_in_named_comparison=21, SHA256=sha(out))))
