from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction as F
from math import comb, floor
import hashlib, json

C = Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Finski_published_completion_review_20261009')
out = C / 'exact_diagnostics_v1_20261009.json'
assert not out.exists()
families = []
def done(name, evidence, scope):
    families.append(dict(name=name, status='PASS — exact elementary diagnostic only', evidence=evidence, scope=scope))

for r in range(1, 7):
    for k in range(1, 15):
        D = comb(r + k - 1, r - 1)
        assert D <= comb(r + k, r)
done('Homogeneous dimension and fixed-r coefficient estimate',
    dict(exact_dimension='binomial(r+k-1,r-1)', printed_dimension='binomial(r+k,r)',
         tested_r=list(range(1,7)), tested_k=list(range(1,15))),
    'The printed value overcounts homogeneous monomials; both grow polynomially for fixed r. No dimension-uniform l1 bound is asserted.')

for k in range(1, 10):
    q = 2*k + 1
    indices = [(j, k-j) for j in range(k+1)]
    assert all(all((a-b) % q == 0 for a,b in zip(x,y)) == (x==y) for x in indices for y in indices)
done('Normalized Haar orthogonality and Parseval',
    dict(identity='integral_T^r |P|^2 = sum |a_alpha|^2',
         bound='sum |a_alpha| <= sqrt(D) sup_polydisc |P|',
         exact_discrete_frequency_separation_degrees=list(range(1,10))),
    'An attributed explanation of Remark 4.3 for fixed finite r; no claim to prove the separate dimension-uniform Bohnenblust-Hille theorem.')

P = lambda x,y: x*y*(x*x-y*y)
assert P(1,1j) == 2j
assert F(1,3)*(1-F(1,3))**2 == F(4,27)
done('Real versus complex polynomial evaluation',
    dict(polynomial='xy(x^2-y^2)', real_maximum_squared='4/27',
         complex_value_at_1_i='2i', projective_l1_coefficient_norm=2),
    'The real rectangle and complex polydisc differ; the power example cannot refute the complex symmetric-tensor theorem.')

tensor = {(0,1): F(3,2), (1,0): F(-1,2)}
mean = (tensor[(0,1)]+tensor[(1,0)])/2
assert 2*abs(mean) <= sum(abs(x) for x in tensor.values())
done('Symmetrization quotient versus restricted l1 norm',
    dict(input_l1='2', averaged_l1='1', projection='normalized permutation average'),
    'A contractive averaging projection explains Lemma 3.16; this is not an exact equality between injective and projective norms.')

def matmul(a,b):
    return [[sum(a[i][h]*b[h][j] for h in range(2)) for j in range(2)] for i in range(2)]
A = [[0,1],[0,0]]; B = [[0,0],[1,0]]; Z = [[0,0],[0,0]]; I = [[1,0],[0,1]]
assert matmul(A,A) == matmul(B,B) == Z
assert matmul([[0,1],[1,0]], [[0,1],[1,0]]) == I
done('Commutativity in the spectral-radius seminorm',
    dict(nilpotent_A=A, nilpotent_B=B, sum_squared=I, radii=[0,0,1]),
    'The section-ring application is commutative; spectral radius is not a seminorm for arbitrary noncommutative Banach algebras.')

assert F(1)-F(1) == 0
done('Klt integrability and bounded-above weights',
    dict(half_boundary_density='|z|^(-1)', radial_integral='integral_0^1 r^(-1)*r dr = 1',
         point_value_at_zero='infinity', psh_weight='log|z| <= 0 on unit disc'),
    'Integrability is not pointwise finiteness on the divisor; quasi-psh upper boundedness does not give a lower bound.')

for k in range(1,9):
    for l in range(1,9):
        assert F(k,k+l)+F(l,k+l) == 1
done('Narasimhan-Simha Hölder exponents',
    dict(reciprocal_exponents=['k/(k+l)','l/(k+l)'], tested_degrees=list(range(1,9))),
    'Submultiplicativity applies before convexification; the convex hull product uses all pairs of decomposition pieces. External uniform convergence remains attributed.')

done('Gauss projection and degree-zero caveats',
    dict(vertical_divisor='ord_(X times {0})', restriction_to_C_X=0, Gauss_tau_value=1,
         section_ring_has_degree_zero=True, unit_weight_after_degree_linear_shift=0),
    'A blanket product-divisorial projection needs the trivial restriction; F^0R=0 after shifting concerns positive-degree pieces, not the unital degree-zero summand.')

a = F(1)
for m in range(1,6):
    for n in range(1,6):
        for vanishing_f in [False,True]:
            for vanishing_g in [False,True]:
                wf = F(0) if vanishing_f else -a*m
                wg = F(0) if vanishing_g else -a*n
                wp = F(0) if vanishing_f or vanishing_g else -a*(m+n)
                assert wp >= wf+wg
for b in [F(1,2),F(1),F(3),F(10)]:
    values = [max(-a,-b/m) for m in range(1,30)]
    assert all(x<=y for x,y in zip(values,values[1:])) and all(-a<=v<=0 for v in values)
done('Raw NA FS versus canonical usc extension',
    dict(P1_O1_weights='-a*m if s(p) != 0, else 0', raw_at_p='-a',
         raw_at_finite_Gauss='sup_m max(-a,-b/m) = 0', usc_regularization=0),
    'A literal all-semivaluation raw (6.15) is not the decreasing-net PSH function. It agrees with the canonical extension on divisorial tests; no counterexample to the intended canonical ray theorem is claimed.')

for k in range(2,9):
    c = F(-1); t = F(3,2)
    native = k*c; normalized = native/k; distance = -2*t*native
    assert normalized == c and distance == 2*t*k
    assert -2*t*k*native == 2*t*k*k != distance
done('Veronese original-degree volume calibration',
    dict(constant_original_slope=-1, native_Veronese_volume='-k', normalized_volume='-1',
         native_doubled_distance='2*t*k', literal_unrenormalized_6_23='2*t*k^2'),
    'Canonical approximation volume must divide native volume by k or rescale filtration weights. This repairs notation rather than refuting intended continuity.')

weights = [F(j,7) for j in range(-13,14)]
for x in weights:
    assert 0 <= x-floor(x) < 1
    for y in weights:
        assert floor(x+y) >= floor(x)+floor(y)
done('Integer rounding and fixed-time errors',
    dict(weight_error='less than 1', ordinary_log_length_error='at most t',
         doubled_normalized_error='at most 2*t/m'),
    'Rounding preserves multiplicativity and asymptotic fixed-time rays, not finite exact norms or uniform bounds for t unbounded.')

assert abs(F(-1)) == abs(F(1))
assert abs(F(-1)-2) != abs(F(1)-2)
done('One-sided compact-support moment determination',
    dict(unshifted_absolute_moments='delta(-1) and delta(1) agree', shifted_support=[-3,-1]),
    'The common sign shift in Theorem 6.4 is essential when recovering a full compactly supported law from absolute moments.')

assert comb(1+2,1) == 3 and comb(1+1,1) == 2
done('Degree-k line-bundle typing',
    dict(P1_degree_two_section_dimension=3, P1_degree_one_section_dimension=2,
         correct_total_bundle='mathcal L^k', pole_clearing_integer='q distinct from degree k'),
    'The test-configuration extension of an L^k section is in mathcal L^k; all-small-degree central-fibre base change remains a separate premise.')

h0,h0i,ht,hti = F(-1),F(0),F(1),F(3)
assert hti-ht == (h0i-h0)-(ht-h0)+(hti-h0i)
done('Ordered energy-distance algebra',
    dict(scalar_data=[str(x) for x in [h0,h0i,ht,hti]], lhs='2', rhs='1-2+3=2'),
    'The source distance subtraction follows two ordered chains; it is not a general triangle-inequality identity or arbitrary limsup subtraction.')

obj = dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — fourteen exact elementary diagnostic families; no general theorem admission',
    families=families, source_PDF_SHA256='1d0c7c19f3d5bf36aada5ac7f2530c9b1bafb8de0264ad1ddad84edd7260b740',
    source_selection='Published physical 25–47, combined later with pinned prior 1–24 actual reading',
    original_results_promoted=[], independent_model_receipt=None, canonical_status_changes=[],
    active_book_changed=False, whole_book_new_reading_claim=False, helper_source=__file__)
assert len(families) == 14
out.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(status='DONE', families=len(families), SHA256=hashlib.sha256(out.read_bytes()).hexdigest())))
