# Fresh published-completion publication helper; frozen source helper SHA256 084d00fa64a350d515e758de20f50b4e7431539dc1e629f57f79709beb752bf2
# Adapted preceding source helper SHA256: a2423cd255fe1aecd956725a94033fa5c2fa4f2d033c4511ea71b7d4a34614e7
# Adapted frozen source publication helper SHA256: cfb5387a5c023bc26f2a83975bfc30d0396dca5d817771850853c71c5e1d1ca4
# Adapted complete CM source helper SHA256: cf9d9d65390ad2d9629d7be70737568fccedfc70b500ae28364945d6161948c4
# Adapted frozen source helper SHA256: 46e43e6f29cdfd9b13a8a98924099c51f726eadd4cff7ddf5efaa051dc625f88
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Finski_published_completion_review_20261009'
out=C/'GitHub_source_publication_v1_20261009.json';assert not out.exists()
repo='MingchenXia/nonarchimedean-pluripotential-theory'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
api=lambda ep:json.loads(subprocess.check_output(['gh','api',ep],cwd=R,text=True))
local=json.loads((C/'local_source_commit_v1_20261009.json').read_text());head=local['commit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==head
assert api(f'repos/{repo}/git/ref/heads/work')['object']['sha']==head
main=api(f'repos/{repo}/git/ref/heads/main')['object']['sha'];assert main==local['author_update_check']['main']
tree=api(f'repos/{repo}/git/trees/{head}?recursive=1');assert not tree['truncated']
mapping={x['path']:x for x in tree['tree'] if x['type']=='blob'};rows=[]
for rel,row in local['files'].items():
    p=R/rel;assert sha(p)==row['SHA256'] and p.stat().st_size==row['bytes']
    blob=subprocess.check_output(['git','hash-object',str(p)],cwd=R,text=True).strip()
    assert mapping[rel]['sha']==blob and mapping[rel]['size']==p.stat().st_size
    rows.append(dict(path=rel,bytes=p.stat().st_size,SHA256=sha(p),local_and_remote_Git_blob_SHA1=blob))
assert len(rows)==9
prep=json.loads((C/'primary_view_preparation_v1_20261009.json').read_text())
for n,h in prep['protected_core_inputs'].items():
    if n not in ['README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']:assert sha(R/n)==h
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).strip()
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — nine authored source/progress/artifact remote blobs verified',
    repository=repo,branch='work',commit=head,main_unchanged=main,files=rows,
    actual_primary_pages=23,actual_matching_images=12,whole_pinned_primary_read=True,complete_unique_primary_pages=47,complete_matching_views_in_two_checkpoints=24,
    active_book_pages=4663,active_book_changed=False,native_editor_changed=False,
    general_local_weak_psh_or_affine_regularization_admitted=False,general_envelope_theorem_admitted=False,
    external_primary_PDF_text_images_uploaded=False,reading_credit_from_upload=0,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',commit=head,files=9,record_SHA256=sha(out))))
