from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile, shutil

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R / 'source_material/Finski_published_completion_review_20261009'
E = R / 'manuscript/editorial'
O = Path('/workspace/book-completion-drafts/research-integration')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
reading = json.loads((C / 'actual_primary_reading_v1_20261009.json').read_text())
diag = json.loads((C / 'exact_diagnostics_v1_20261009.json').read_text())
prep = json.loads((C / 'primary_view_preparation_v1_20261009.json').read_text())
assert reading['actual_selected_source_page_pairs'] == 23 and len(reading['views']) == 12
assert reading['complete_published_composite']['physical_pages'] == list(range(1,48))
assert len(diag['families']) == 14
for n,h in prep['protected_core_inputs'].items():
    assert sha(R / n) == h
paths = {k: E / f'Finski_published_completion_source_{k}_20261009.{ext}' for k,ext in
    [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
record = C / 'source_checkpoint_v1_20261009.json'
draft = Path('/tmp/Finski_published_completion_source_review_draft_v1_20261009.md')
owned = O / 'Finski_Published_Completion_Authored_Records_V1_2026-10-09.zip'
full = O / 'Finski_Published_Completion_Actual_Source_Evidence_V1_2026-10-09.zip'
dest = E / 'artifact_exports/20261009_Finski_published_completion_sources'
assert not any(p.exists() for p in [*paths.values(), record, owned, full, dest])
assert draft.stat().st_size > 15000
paths['review'].write_text(draft.read_text().rstrip() + '\n')
old_views = reading['prior_complete_selection_record']['views']
paths['reading_notes'].write_text(('# Actual complete published Finski notes, 9 October 2026\n\n'
    'Complete 1–47 union: prior 1–24 and fresh 25–47, twenty-four matching views. '
    'This completion freshly reads 23 pages/12 views; it repeats old 35–36 and adds 21 unique pages against the named 26-page prior union. '
    'Original external proofs remain separate.\n\n'
    '# Prior actual 1–24 notes\n' + ''.join('\n---\n\n' + Path(v['note_path']).read_text() for v in old_views) +
    '\n# Fresh actual 25–47 notes\n' + ''.join('\n---\n\n' + Path(v['note_path']).read_text() for v in reading['views'])).rstrip() + '\n')
files = {f'records/{p.name}':p for p in C.glob('*.json')}
prior = Path(reading['prior_complete_selection_record']['path'])
files['prior_records/actual_metric_radial_reading_v1_20261009.json'] = prior
files['manifests/new_prepared_manifest.json'] = Path(prep['manifest_path'])
for folder,views in [('prior_1_24',old_views),('fresh_25_47',reading['views'])]:
    for v in views:
        for key,kind in [('note_path','notes'),('observation_receipt_path','receipts')]:
            p=Path(v[key]); files[f'{folder}/{kind}/{p.name}']=p
for p in sorted(Path('/tmp').glob('Finski_published_completion_*_v*_20261009.py')):
    files[f'helpers/{p.name}']=p
files[f'drafts/{draft.name}']=draft
for key in ['review','reading_notes']:
    files[f'editorial/{paths[key].name}']=paths[key]
def archive(target, entries):
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,p in sorted(entries.items()):
            z.write(p,n)
    with zipfile.ZipFile(target) as z:
        assert len(z.namelist())==len(entries) and z.testzip() is None
        for n,p in entries.items():
            assert z.read(n)==p.read_bytes()
archive(owned,files)
fullfiles=dict(files)
source=reading['sources']['Finski_PLMS2025']
fullfiles['primary/PDF/Finski_PLMS2025.pdf']=Path(source['path'])
for folder,views in [('prior_1_24',old_views),('fresh_25_47',reading['views'])]:
    for v in views:
        for key,kind in [('image_path','images'),('selected_text_path','text')]:
            p=Path(v[key]); fullfiles[f'{folder}/{kind}/{p.name}']=p
archive(full,fullfiles)
artifacts={k:dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p),members=count) for k,p,count in
    [('authored_records_archive',owned,len(files)),('cloud_source_evidence_archive',full,len(fullfiles))]}
paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — complete published Finski actual source audit',actual_reading=reading,exact_diagnostics=diag,
    artifacts=artifacts,active_book_changed=False,native_editor_changed=False,GitHub_published=False,
    canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — every archive member byte-verified',artifacts=artifacts,reading_credit_from_export=0,
    external_primary_PDF_text_images_uploaded=False,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
dest.mkdir(parents=True)
target=dest/owned.name; shutil.copyfile(owned,target); assert sha(target)==sha(owned)
(dest/'SHA256SUMS').write_text(sha(target)+'  '+target.name+'\n')
(dest/'README.md').write_text(f'''# Complete published Finski source checkpoint, 9 October 2026

The forty-seven-page published author PDF is completely read in two pinned
ordered checkpoints: 1–24 in twelve matching views and fresh 25–47 in
twelve more. The new 23-page selection repeats old endpoint pages 35–36
and adds 21 unique pages relative to the specifically named prior 26-page
union. Complete source reading does not certify all original references.

Fourteen elementary diagnostics retain complex symmetric tensor and fixed-r
Parseval conventions, quotient-extension premises, raw/usc FS distinction,
original-degree Veronese volumes, klt integrability, fixed-time rounding,
one-sided spectral moments and degree-k test-configuration typing.
The two dated source research questions are methodological homogenization
and extension to big polarizations; neither becomes a canonical new atom.

The {len(files)}-member authored archive contains full actual notes/receipts,
scope and diagnostic records, helpers and source audit. The {len(fullfiles)}-member
cloud evidence archive additionally retains the controlling primary PDF
and all matching text/images. External primary PDF/text/images stay in the
cloud. Preparation/export/upload give zero reading credit. The 4,663-page
book, both bibliographies, native catalogue/editor and canonical 42 atoms
in twelve formal problems remain unchanged here. General BJ22 critical
Siu/envelopes remain OPEN and LPWZ density UNVERIFIED. Source reference
[16] is the distinct Annales de l'Institut Fourier 2025 metric-geometry
paper, not the BJ22 Siu publication; its proof dependencies still require
original audit. No original general theorem or independent-model receipt
is claimed. Last complete ordered book pass remains 4 October.
'''.rstrip()+'\n')
p=R/'README.md';s=p.read_text();marker='**Latest verified norm-ray/interface GitHub publication, 9 October 2026:**'
assert s.count(marker)==1
intro='''**Latest complete published Finski source checkpoint, 9 October 2026:**
the [complete-source audit](manuscript/editorial/Finski_published_completion_source_review_20261009.md)
combines actual 1–24 and fresh 25–47 reading into all 47 published pages
in 24 matching text/image views. Fourteen elementary diagnostics preserve
symmetric complex tensors, holomorphic quotient premises, raw/usc FS and
Veronese volume conventions. The
[authored evidence](manuscript/editorial/artifact_exports/20261009_Finski_published_completion_sources/README.md)
pins the full scope and repeated old pages. Original cited proofs still
need separate audit. The 4,663-page book, native editor and canonical
statuses are unchanged by this source-only checkpoint.

'''
p.write_text(s.replace(marker,intro+marker,1))
p=E/'second_reading_and_research_programme_20261002.md';s=p.read_text();marker='## Latest norm-ray/interface GitHub publication, 9 October 2026\n'
assert s.count(marker)==1
intro='''## Latest complete published Finski source checkpoint, 9 October 2026

The [full published-source audit](Finski_published_completion_source_review_20261009.md)
combines pinned actual pages 1–24 with the fresh 25–47 selection: all
forty-seven physical pages in twenty-four matching text/image views.
The completion freshly reads twenty-three pages in twelve views, repeats
old endpoint pages 35–36, and adds twenty-one unique pages against the
named prior twenty-six-page union. Preparation and export add no credit.

Fourteen exact elementary diagnostic families cover fixed-variable
Parseval, real/complex and symmetric/full-tensor distinctions, quotient
extension, commutative homogenization, klt integrability, raw NA FS and
canonical usc extension, original-degree Veronese volume, integer rounding,
one-sided moments and correct total-line-bundle powers. The fixed-r
Parseval explanation is attributed to Remark 4.3; the general quotient
argument retains its original holomorphic extension input. Source
questions from Remarks 3.21 and 1.4(c) retain a methodological or big-class
scope and do not change the canonical list.

The [owned archive](artifact_exports/20261009_Finski_published_completion_sources/README.md)
preserves the actual records. Complete Finski reading does not recursively
certify its original references. In particular [16] is the separate
Annales de l'Institut Fourier 2025 metric-geometry paper and [7] is BBJ's
JAMS 2021 variational paper. Next audit their exact maximal-ray/energy
and extension proofs before using further general interfaces. A scoped
book addition can explain fixed-r Parseval and the explicit raw/usc and
Veronese calibration without claiming an original general theorem.

The verified 4,663-page book, both bibliographies and native catalogue
remain unchanged at this source checkpoint. Canonical 42 atoms/twelve
problems retain their statuses; BJ22 critical homogeneous Siu/general
envelopes stay OPEN and LPWZ density UNVERIFIED. The Theorem 6.21 warning
remains binding. No independent-model receipt or new whole-book pass is
claimed; the last complete ordered pass is 4 October. Continue cloud-only,
integrate incoming author research and publish reviewed units regularly.
Xean stays suspended.

'''
p.write_text(s.replace(marker,intro+marker,1))
published=[*paths.values(),*sorted(dest.iterdir()),R/'README.md',p]
assert len(published)==9
for path in [paths['review'],paths['reading_notes'],dest/'README.md']:
    data=path.read_bytes(); assert data.endswith(b'\n') and not data.endswith(b'\n\n')
    assert all(line==line.rstrip() for line in path.read_text().splitlines())
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — complete published source checkpoint and authored artifacts exported',
    editorial_files={str(p.relative_to(R)):dict(SHA256=sha(p),bytes=p.stat().st_size) for p in published},
    artifacts=artifacts,actual_primary_pages=23,actual_matching_views=12,complete_unique_primary_pages=47,
    complete_matching_views_in_two_checkpoints=24,active_book_changed=False,native_editor_changed=False,
    canonical_status_changes=[],GitHub_published=False,helper_source=__file__)
record.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',files=9,owned_members=len(files),cloud_members=len(fullfiles),record_SHA256=sha(record))))
