from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BE21_reduced_fibre_integrability_review_20261009'
out=C/'actual_primary_reading_v1_20261009.json'; assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sets=[('primary_view_preparation_v1_20261009.json',C/'primary_notes_v1'),('supplement_view_preparation_v1_20261009.json',C/'supplement_notes_v1')]
views=[];pages=[];pins={};last=None
for name,N in sets:
    p=C/name;prep=json.loads(p.read_text());pins[name]=sha(p)
    assert prep['actual_source_reading_credit']==prep['actually_read_pages']==0
    assert sha(prep['source_PDF']['path'])==prep['source_PDF']['SHA256']
    mp=Path(prep['manifest_path']);assert sha(mp)==prep['manifest_SHA256']
    rows=json.loads(mp.read_text());assert len(rows)==prep['prepared_views']
    for i,row in enumerate(rows,1):
        receipt=N/f'note_{i:02d}_receipt.json';a=json.loads(receipt.read_text())
        assert a['number']==i and a['physical_pages']==row['physical_pages']
        assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
        assert last is None or a['UTC']>last
        last=a['UTC']
        assert not row['actually_viewed'] and not row['selected_text_read']
        for k,h in [('image_path','image_SHA256'),('selected_text_path','selected_text_SHA256'),('note_path','note_SHA256')]:assert sha(a[k])==a[h]
        assert a['source_PDF_SHA256']==prep['source_PDF']['SHA256']==row['source_PDF_SHA256']
        assert 'Read the complete selected text and displayed matching rendered image.' in Path(a['note_path']).read_text()
        views.append(dict(batch=name,**a,observation_receipt_path=str(receipt),observation_receipt_SHA256=sha(receipt)))
        pages.extend(row['physical_pages'])
    for n,h in prep['protected_core_inputs'].items():assert sha(R/n)==h
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==prep['baseline_commit']
assert len(views)==9 and len(pages)==len(set(pages))==18
previous=R/'source_material/BE21_supnorm_basechange_review_20261009/actual_primary_reading_v1_20261009.json'
prior=json.loads(previous.read_text());old=set(prior['cumulative_distinct_page_list']);new=set(pages)
assert len(old)==38 and old&new=={63,64,78} and len(new-old)==15 and len(old|new)==53
d=C/'exact_diagnostics_v2_20261009.json';diag=json.loads(d.read_text())
assert len(diag['families'])==6 and all(a['status'].startswith('PASS') for a in diag['families'])
failure=C/'failed_exact_diagnostics_v1_20261009.json';assert not json.loads(failure.read_text())['diagnostic_output_created']
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — eighteen selected primary pages freshly read; ordinary source and proof-interface audit',
    source_PDF=prep['source_PDF'],actual_source_unique_pages=18,actual_individually_displayed_matching_views=9,
    selected_physical_pages=sorted(new),views=views,preparation_record_SHA256=pins,
    exact_diagnostics_SHA256=sha(d),failed_diagnostic_parse_record_SHA256=sha(failure),
    previous_partial_reading_record_SHA256=sha(previous),new_unique_pages_relative_to_two_prior_checkpoints=15,
    overlap_pages_freshly_read=[63,64,78],cumulative_distinct_pages_in_three_checkpoints=53,
    cumulative_distinct_page_list=sorted(old|new),remaining_primary_pages_not_read_in_three_checkpoints=72,
    complete_selected_text_read=True,preparation_flags_unchanged=True,whole_primary_PDF_reading_claim=False,
    active_book_changed=False,native_editor_changed=False,book_PDF_SHA256=sha(R/'manuscript/book.pdf'),
    baseline_commit=prep['baseline_commit'],
    primary_attested_inputs=['Full Section 4, including Theorems 4.19–4.20 and Remark 4.21','Global continuous psh-regularizable measure extension and CLN estimate','Theorems 8.12–8.14 with full printed proof seams','Example 7.12 and full Theorem 7.14 regularized-maximum proof'],
    printed_proof_clarifications=['Ordinary log-of-sum-of-squares fails CLD smoothness at a rational zero in Lemma 8.13','Lemma 8.6 expansion requires a minus sign','Theorem 8.12 reference should be chosen as a difference with two explicitly semipositive metrics','Theorem 8.14 approximation variables and targets need the indicated tau corrections'],
    supported_reformulation='Continuous FS maxima psi_j=max(log|s|+psi_prime,theta-j); reference phi=theta-psi_prime; uniform CLN extension; decreasing integral limits anchored at one finite smooth tuple. Existing attributed theorem scope is retained.',
    earlier_inputs_not_recursively_certified=['BGR affinoid strict closedness, integral closure and Grauert–Remmert finiteness','Berkovich/formal Shilov and reduction foundations','CLD smooth integration, local logarithmic integrability, Stokes and Poincare–Lelong foundations','Regularized-maximum CLD positivity source §6.3.2 and previous psh closure inputs','Classical projective very-ampleness and intersection machinery'],
    general_local_weak_psh_or_affine_regularization_admitted=False,general_envelope_theorem_admitted=False,
    canonical_status_changes=[],original_results_promoted=[],independent_model_receipt=None,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],pages=18,views=9,new_distinct_pages=15,cumulative_distinct_pages=53,record_SHA256=sha(out))))
