from pathlib import Path
import hashlib

src=Path('/tmp/BE21_Supnorm_basechange_export_source_v1_20261009.py')
dst=Path('/tmp/BE21_Reduced_fibre_integrability_export_source_v1_20261009.py')
draft=Path('/tmp/BE21_Reduced_fibre_integrability_source_review_draft_v1_20261009.md')
assert not dst.exists() and draft.exists()
s=src.read_text()
replacements={
    'BE21_supnorm_basechange':'BE21_reduced_fibre_integrability',
    'BE21_Supnorm_basechange':'BE21_Reduced_fibre_integrability',
    'BE21_Supnorm_Basechange':'BE21_Reduced_Fibre_Log_Integrability',
    "C/'exact_diagnostics_v1_20261009.json'":"C/'exact_diagnostics_v2_20261009.json'",
    "reading['actual_source_unique_pages']==11":"reading['actual_source_unique_pages']==18",
    "reading['actual_individually_displayed_matching_views']==6":"reading['actual_individually_displayed_matching_views']==9",
    "len(diag['families'])==4":"len(diag['families'])==6",
    'Eleven fresh selected pages in six matching displays; nine new distinct pages relative to the preceding checkpoint.':'Eighteen fresh selected pages in nine matching displays; fifteen new distinct pages relative to the two preceding checkpoints.',
    'Actual BE21 supnorm/base-change source notes':'Actual BE21 reduced-fibre/log-integrability source notes',
    'actual_primary_pages=11,actual_matching_views=6,new_distinct_pages=9':'actual_primary_pages=18,actual_matching_views=9,new_distinct_pages=15',
    'cumulative_distinct_pages_in_two_checkpoints=38':'cumulative_distinct_pages_in_three_checkpoints=53'
}
for a,b in replacements.items():
    assert a in s,a
    s=s.replace(a,b)
a=s.index("paths['review'].write_text(r'''")
b=s.index("paths['reading_notes'].write_text(",a)
s=s[:a]+"draft=Path('/tmp/BE21_Reduced_fibre_integrability_source_review_draft_v1_20261009.md')\npaths['review'].write_bytes(draft.read_bytes())\nassert sha(paths['review'])==sha(draft)\n"+s[b:]
a="for k in ['review','reading_notes']:files[f'editorial/{paths[k].name}']=paths[k]"
assert s.count(a)==1
s=s.replace(a,a+"\nfiles[f'drafts/{draft.name}']=draft",1)
a=s.index("(dest/'README.md').write_text(f'''")
b=s.index("readme=R/'README.md';",a)
s=s[:a]+"""(dest/'README.md').write_text(f'''# Reduced fibres and logarithmic integrability checkpoint, 9 October 2026

The {len(files)}-member authored archive preserves the ordinary source audit,
eighteen-page/nine-view actual notes and receipts, preparation records and
six elementary diagnostic families. Three pages overlap the two earlier
checkpoints: only fifteen are new. These three checkpoints have 53 distinct
pages of the 125-page published PDF, leaving 72 unread in their combined scope.

The reduced-fibre theorem retains discrete or algebraically closed field
hypotheses. A completed Gauss value group Z+sqrt(2)Z gives an explicit
nonfinite relative integral closure outside that scope. The printed
non-Archimedean log-sum construction is not CLD-smooth at a rational zero;
the ordinary audit supplies an explanatory reformulation using continuous
Fubini--Study maxima, two semipositive reference metrics and a finite
logarithmic integral anchor. The CLN expansion sign is corrected without
refuting its final estimate or the intended integrability theorem.

The first diagnostic helper failed Python parsing before any computation or
output; it remains frozen, and the fresh corrected v2 passes six families.
External primary PDF/text/images remain in the separate {len(fullfiles)}-member
cloud archive. SHA256SUMS pins the owned archive. Preparation, export and
upload supply zero extra reading credit.

The 4,657-page book, native catalogue/editor, 42 atoms/twelve problems and
last complete 4 October ordered pass are unchanged. General BJ22 critical
homogeneous Siu/envelopes remain OPEN, LPWZ density UNVERIFIED. No original
general theorem or independent-model receipt is asserted. Remote publication
receives a separate subsequent verification record.
''')
""" + s[b:]
a=s.index("readme=R/'README.md';")
b=s.index("published=[",a)
s=s[:a]+"""readme=R/'README.md';s=readme.read_text()
marker='**Latest section-supnorm field-extension primary checkpoint, 9 October 2026:**'
assert s.count(marker)==1
intro='''**Latest reduced-fibre and logarithmic-integrability primary checkpoint, 9 October 2026:**
the [source audit](manuscript/editorial/BE21_reduced_fibre_integrability_source_review_20261009.md)
reads eighteen selected BE21 pages in nine fresh matching displays.
Six elementary diagnostic families retain the field, model, regular-section
and psh-regularizable hypotheses. The audit clarifies a printed CLN sign,
the non-Archimedean log-sum smoothness issue and an explanatory integrability
reformulation using existing global estimates. The
[authored evidence](manuscript/editorial/artifact_exports/20261009_BE21_reduced_fibre_integrability_sources/README.md)
preserves those observations and the failed first parse preflight.
Only fifteen pages are new relative to the two preceding selections.
The active book, native editor and open-problem statuses are unchanged.

'''
readme.write_text(s.replace(marker,intro+marker,1))
programme=E/'second_reading_and_research_programme_20261002.md';s=programme.read_text()
marker='## Latest section-supnorm base-change source checkpoint, 9 October 2026\\n'
assert s.count(marker)==1
intro='''## Latest reduced-fibre and logarithmic-integrability source checkpoint, 9 October 2026

The [source audit](BE21_reduced_fibre_integrability_source_review_20261009.md)
freshly reads BE21 physical pages 39--47, 63--64 and 72--78: eighteen pages
in nine individually displayed matching views with complete text and sequential
notes/receipts. Three overlap the two previous checkpoints. The combined
three-checkpoint scope has 53 distinct pages, leaving 72 unread; this is
not a whole-paper claim. Six elementary diagnostic families pass in fresh v2.
The first helper's Python parse failure executed no diagnostics and remains frozen.

Theorem 4.19's integral-closure converse requires a dense value group;
Theorem 4.20's finiteness requires the stated discrete or algebraically
closed field hypotheses. The completed Gauss field with value group
Z+sqrt(2)Z illustrates the nonfinite relative integral-closure boundary
already described by Remark 4.21. Generic properness and a model's own
properness are distinct; a generic-only model can have an empty tube.

Theorem 8.12 retains a regular section and continuous global
psh-regularizable factors. The printed non-Archimedean ordinary log-sum
weight is not CLD-smooth at a rational zero. The audit reformulates the
argument using continuous FS maxima, the read smooth-max regularization
input, two semipositive reference metrics and a finite smooth anchor for
the decreasing integrals. The CLN proof needs a minus sign. Neither
observation refutes the intended corrected integrability theorem.
Earlier BGR, Berkovich, CLD and classical projective foundations are
attributed and not recursively certified by this selection.

The [authored archive](artifact_exports/20261009_BE21_reduced_fibre_integrability_sources/README.md)
retains actual observations, diagnostics and helpers. Primary PDF/text/images
remain in the cloud. Export/upload gives zero extra reading credit.
The 4,657-page book, 425 core TeX inputs, bibliographies and native
catalogue/editor are unchanged. All 42 atoms/twelve problems retain their
statuses; general BJ22 critical homogeneous Siu/envelopes remain OPEN and
LPWZ density UNVERIFIED. No original general theorem or independent-model
receipt is claimed. The last complete ordered book pass is 4 October.

Continue cloud-only by integrating the exact norm and reduced-fibre/global
integrability interfaces as attributed material, with these proof clarifications,
through an isolated stage, required build and actual rendered-book gates.
Keep arbitrary local weak-psh and affine regularization comparisons unresolved.
Then continue related primary literature and sequential open problems.
Check incoming author updates and periodically push checked evidence.
Xean remains suspended.

'''
programme.write_text(s.replace(marker,intro+marker,1))
""" + s[b:]
dst.write_text('# Frozen preceding export template SHA256: '+hashlib.sha256(src.read_bytes()).hexdigest()+'\n'+s)
print('Fresh unexecuted reduced-fibre/log-integrability source exporter prepared; zero reading credit.')
