# Pre-execution helper membership includes frozen failed v1 and corrected v2 diagnostics.
# Frozen preceding export template SHA256: bfe8372c93ec6fcec7bc83b95d7e19dc4e12ec574879a8ff358cc6eeb96e9ffa
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, zipfile

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BE21_reduced_fibre_integrability_review_20261009'
E=R/'manuscript/editorial'
O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
reading=json.loads((C/'actual_primary_reading_v1_20261009.json').read_text())
diag=json.loads((C/'exact_diagnostics_v2_20261009.json').read_text())
assert reading['actual_source_unique_pages']==18 and reading['actual_individually_displayed_matching_views']==9
assert len(diag['families'])==6
for name in reading['preparation_record_SHA256']:
    prep=json.loads((C/name).read_text())
    assert sha(C/name)==reading['preparation_record_SHA256'][name]
    for n,h in prep['protected_core_inputs'].items():assert sha(R/n)==h
paths={k:E/f'BE21_reduced_fibre_integrability_source_{k}_20261009.{ext}' for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
record=C/'source_checkpoint_v1_20261009.json'
owned=O/'BE21_Reduced_Fibre_Log_Integrability_Authored_Records_V1_2026-10-09.zip'
full=O/'BE21_Reduced_Fibre_Log_Integrability_Actual_Source_Evidence_V1_2026-10-09.zip'
dest=E/'artifact_exports/20261009_BE21_reduced_fibre_integrability_sources'
assert not any(p.exists() for p in [*paths.values(),record,owned,full,dest])
draft=Path('/tmp/BE21_Reduced_fibre_integrability_source_review_draft_v1_20261009.md')
paths['review'].write_bytes(draft.read_bytes())
assert sha(paths['review'])==sha(draft)
paths['reading_notes'].write_text('# Actual BE21 reduced-fibre/log-integrability source notes, 9 October 2026\n\nEighteen fresh selected pages in nine matching displays; fifteen new distinct pages relative to the two preceding checkpoints.\n'+''.join('\n---\n\n'+Path(v['note_path']).read_text() for v in reading['views']))
files={f'records/{p.name}':p for p in C.glob('*.json')}
for v in reading['views']:
    for k,folder in [('note_path','notes'),('observation_receipt_path','receipts')]:
        p=Path(v[k]);files[f'{v["batch"]}/{folder}/{p.name}']=p
for name in reading['preparation_record_SHA256']:
    p=Path(json.loads((C/name).read_text())['manifest_path']);files[f'manifests/{name}']=p
for p in Path('/tmp').glob('BE21_Reduced_fibre_integrability_*_v*_20261009.py'):files[f'helpers/{p.name}']=p
for k in ['review','reading_notes']:files[f'editorial/{paths[k].name}']=paths[k]
files[f'drafts/{draft.name}']=draft
with zipfile.ZipFile(owned,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,p in sorted(files.items()):z.write(p,n)
with zipfile.ZipFile(owned) as z:
    assert len(z.namelist())==len(files)
    for n,p in files.items():assert z.read(n)==p.read_bytes()
fullfiles=dict(files)
p=Path(reading['source_PDF']['path']);fullfiles['primary/Boucksom_Eriksson_2021_published.pdf']=p
for v in reading['views']:
    for k,folder in [('image_path','images'),('selected_text_path','text')]:
        p=Path(v[k]);fullfiles[f'{v["batch"]}/{folder}/{p.name}']=p
with zipfile.ZipFile(full,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,p in sorted(fullfiles.items()):z.write(p,n)
with zipfile.ZipFile(full) as z:
    assert len(z.namelist())==len(fullfiles)
    for n,p in fullfiles.items():assert z.read(n)==p.read_bytes()
artifacts={k:dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p),members=count) for k,p,count in [('authored_records_archive',owned,len(files)),('cloud_complete_source_evidence_archive',full,len(fullfiles))]}
paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — actual partial primary reading and ordinary source audit',actual_reading=reading,exact_diagnostics=diag,artifacts=artifacts,active_book_changed=False,native_editor_changed=False,GitHub_published=False,canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — byte-verified source exports',artifacts=artifacts,reading_credit_from_export=0,external_primary_PDF_text_images_uploaded=False,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
dest.mkdir(parents=True)
target=dest/owned.name;shutil.copyfile(owned,target);assert sha(target)==sha(owned)
(dest/'SHA256SUMS').write_text(sha(target)+'  '+target.name+'\n')
(dest/'README.md').write_text(f'''# Reduced fibres and logarithmic integrability checkpoint, 9 October 2026

The {len(files)}-member authored archive preserves the ordinary source audit,
eighteen-page/nine-view actual notes and receipts, preparation records and
six elementary diagnostic families. Three pages overlap the two earlier
checkpoints: only fifteen are new. These three checkpoints have 53 distinct
pages of the 125-page published PDF, leaving 72 unread in their combined scope.

The reduced-fibre theorem retains discrete or algebraically closed field
hypotheses. A completed Gauss value group Z+sqrt(2)Z gives an explicit
nonfinite relative integral closure outside that scope. The printed
non-Archimedean log-sum construction is not CLD-smooth at a rational zero;
the ordinary audit supplies an explanatory reformulation using continuous
Fubini--Study maxima, two semipositive reference metrics and a finite
logarithmic integral anchor. The CLN expansion sign is corrected without
refuting its final estimate or the intended integrability theorem.

The first diagnostic helper failed Python parsing before any computation or
output; it remains frozen, and the fresh corrected v2 passes six families.
External primary PDF/text/images remain in the separate {len(fullfiles)}-member
cloud archive. SHA256SUMS pins the owned archive. Preparation, export and
upload supply zero extra reading credit.

The 4,657-page book, native catalogue/editor, 42 atoms/twelve problems and
last complete 4 October ordered pass are unchanged. General BJ22 critical
homogeneous Siu/envelopes remain OPEN, LPWZ density UNVERIFIED. No original
general theorem or independent-model receipt is asserted. Remote publication
receives a separate subsequent verification record.
''')
readme=R/'README.md';s=readme.read_text()
marker='**Latest section-supnorm field-extension primary checkpoint, 9 October 2026:**'
assert s.count(marker)==1
intro='''**Latest reduced-fibre and logarithmic-integrability primary checkpoint, 9 October 2026:**
the [source audit](manuscript/editorial/BE21_reduced_fibre_integrability_source_review_20261009.md)
reads eighteen selected BE21 pages in nine fresh matching displays.
Six elementary diagnostic families retain the field, model, regular-section
and psh-regularizable hypotheses. The audit clarifies a printed CLN sign,
the non-Archimedean log-sum smoothness issue and an explanatory integrability
reformulation using existing global estimates. The
[authored evidence](manuscript/editorial/artifact_exports/20261009_BE21_reduced_fibre_integrability_sources/README.md)
preserves those observations and the failed first parse preflight.
Only fifteen pages are new relative to the two preceding selections.
The active book, native editor and open-problem statuses are unchanged.

'''
readme.write_text(s.replace(marker,intro+marker,1))
programme=E/'second_reading_and_research_programme_20261002.md';s=programme.read_text()
marker='## Latest section-supnorm base-change source checkpoint, 9 October 2026\n'
assert s.count(marker)==1
intro='''## Latest reduced-fibre and logarithmic-integrability source checkpoint, 9 October 2026

The [source audit](BE21_reduced_fibre_integrability_source_review_20261009.md)
freshly reads BE21 physical pages 39--47, 63--64 and 72--78: eighteen pages
in nine individually displayed matching views with complete text and sequential
notes/receipts. Three overlap the two previous checkpoints. The combined
three-checkpoint scope has 53 distinct pages, leaving 72 unread; this is
not a whole-paper claim. Six elementary diagnostic families pass in fresh v2.
The first helper's Python parse failure executed no diagnostics and remains frozen.

Theorem 4.19's integral-closure converse requires a dense value group;
Theorem 4.20's finiteness requires the stated discrete or algebraically
closed field hypotheses. The completed Gauss field with value group
Z+sqrt(2)Z illustrates the nonfinite relative integral-closure boundary
already described by Remark 4.21. Generic properness and a model's own
properness are distinct; a generic-only model can have an empty tube.

Theorem 8.12 retains a regular section and continuous global
psh-regularizable factors. The printed non-Archimedean ordinary log-sum
weight is not CLD-smooth at a rational zero. The audit reformulates the
argument using continuous FS maxima, the read smooth-max regularization
input, two semipositive reference metrics and a finite smooth anchor for
the decreasing integrals. The CLN proof needs a minus sign. Neither
observation refutes the intended corrected integrability theorem.
Earlier BGR, Berkovich, CLD and classical projective foundations are
attributed and not recursively certified by this selection.

The [authored archive](artifact_exports/20261009_BE21_reduced_fibre_integrability_sources/README.md)
retains actual observations, diagnostics and helpers. Primary PDF/text/images
remain in the cloud. Export/upload gives zero extra reading credit.
The 4,657-page book, 425 core TeX inputs, bibliographies and native
catalogue/editor are unchanged. All 42 atoms/twelve problems retain their
statuses; general BJ22 critical homogeneous Siu/envelopes remain OPEN and
LPWZ density UNVERIFIED. No original general theorem or independent-model
receipt is claimed. The last complete ordered book pass is 4 October.

Continue cloud-only by integrating the exact norm and reduced-fibre/global
integrability interfaces as attributed material, with these proof clarifications,
through an isolated stage, required build and actual rendered-book gates.
Keep arbitrary local weak-psh and affine regularization comparisons unresolved.
Then continue related primary literature and sequential open problems.
Check incoming author updates and periodically push checked evidence.
Xean remains suspended.

'''
programme.write_text(s.replace(marker,intro+marker,1))
published=[*paths.values(),*sorted(dest.iterdir()),readme,programme]
assert len(published)==9
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — primary checkpoint and byte-verified authored artifacts exported',
    editorial_files={str(p.relative_to(R)):dict(SHA256=sha(p),bytes=p.stat().st_size) for p in published},
    artifacts=artifacts,actual_primary_pages=18,actual_matching_views=9,new_distinct_pages=15,
    cumulative_distinct_pages_in_three_checkpoints=53,active_book_changed=False,native_editor_changed=False,
    canonical_status_changes=[],GitHub_published=False,helper_source=__file__)
record.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],files=9,owned_members=len(files),cloud_members=len(fullfiles),record_SHA256=sha(record))))
