# Frozen failed v1 helper SHA256: 91dedbdef0fe4d435360170a7e419cbf049454b28a44bc7fcc184ffde3bed2cc
from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction
import hashlib, json
import sympy as sp

C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/BE21_reduced_fibre_integrability_review_20261009')
out=C/'exact_diagnostics_v2_20261009.json';assert not out.exists()
def sign(v):return (v>0)-(v<0)
def gamma_sign(m,n,r=Fraction(0)):
    a=Fraction(m)-r
    if n==0:return sign(a)
    if n>0:
        if a>=0:return 1
        return sign(2*n*n-a*a)
    if a<=0:return -1
    return sign(a*a-2*n*n)
p,q=3,2;cuts=[]
for i in range(7):
    assert p*p-2*q*q==1
    assert gamma_sign(p,-q)>0
    m=(1-p)*p;n=(p-1)*q
    assert gamma_sign(m,n,Fraction(-1,2))>0
    assert gamma_sign(m-p,n+q,Fraction(-1,2))<0
    cuts.append(dict(p=p,q=q,gamma_integer_coefficient=m,gamma_sqrt2_coefficient=n,
        exact_bounds='-1/2 < gamma < -1/2 + (p-q sqrt(2))',epsilon_positive=True))
    p,q=3*p+4*q,2*p+3*q
families=[dict(name='Dense completed-residue field can have a nonfinite relative integral closure',
    status='PASS — worked boundary of attributed BE21 Remark 4.21',
    base='K=Q((pi)), v(pi)=1',H='completed Gauss residue field with v(T)=sqrt(2)',
    value_group='Gamma=Z+sqrt(2)Z; completion preserves values of nonzero elements',
    half_not_in_group='If m+n sqrt(2)=1/2, squaring gives (2m-1)^2=8n^2, impossible modulo 2.',
    extension='L=H(z), z^2=pi; v(z)=1/2, hence degree 2',
    model='A=H^circ[z]/(z^2-pi), finite free rank two, with reduced generic fibre',
    relative_integral_closure='L^circ, by unique extension of the complete-field valuation and integrality of conjugates',
    module_formula='L^circ=H^circ direct sum I z, I={b in H: v(b)>-1/2}',
    valuation_formula='v(a+bz)=min(v(a),v(b)+1/2), because the two nonzero term values lie in disjoint cosets of Gamma',
    nonfiniteness='I has no least value: Gamma is dense and -1/2 is not in Gamma. A finitely generated fractional ideal over a valuation ring is principal and has a least value. Thus L^circ is not finite over H^circ or A.',
    exact_cut_checks=cuts,
    limitation='H is neither discrete nor algebraically closed. This is not a counterexample to Theorem 4.20 or global Theorem 6.6, which can pass to an algebraically closed extension.')]
z=sp.symbols('z');assert sp.rem(z*z,z*z,z)==0 and sp.rem(z,z*z,z)==z
families.append(dict(name='Relative integral closure alone does not force reduced special fibre in the discrete case',
    status='PASS — elementary ramified DVR boundary',
    R='Q[[pi]]',B='Q[[z]] with pi=z^2',generic='Q((z))/Q((pi)), separable degree two',
    total_model='normal regular DVR and relatively integrally closed',special_fibre='Q[z]/(z^2)',
    nonzero_square_zero_class='z mod z^2',supnorm_of_z='2^(-1/2) when |pi|=1/2',
    lattice_norm_of_z='1 in basis 1,z',lattice_norm_of_z_squared='1/2',
    lattice_gauge_power_multiplicative=False,
    limitation='The dense-value-group converse in Theorem 4.19 and reduced-special-fibre equality in Lemma 6.3 do not apply. No tame norm-descent claim is contradicted.'))
families.append(dict(name='A generic-only nonproper model has empty tube and zero completion',
    status='PASS — elementary model/properness boundary',
    K='Q((pi))',R='Q[[pi]]',A='R[1/pi]=K',model_finite_type_flat=True,
    generic_fibre='Spec K, proper over K',model_proper_over_R=False,
    tube_empty_reason='pi^(-1) belongs to A but has absolute value greater than one at the only generic analytic point',
    completion='A/pi^n A=0 for every n, so the pi-adic completion is zero',
    original_lattice_gauge_of_one='0, since 1 belongs to aA for every a in K^times',
    original_algebra_injects_into_completion=False,
    limitation='No norm or full-analytification claim is inferred from a nonproper local tube.'))
values=[]
for n in range(1,13):
    argument=1+Fraction(1,2)**(2*n)
    assert argument>1
    values.append(dict(n=n,T='pi^'+str(n),logarithm_argument=str(argument),weight_strictly_positive=True))
families.append(dict(name='Ordinary log-of-sum-of-squares is not CLD-smooth at a rational zero',
    status='PASS — elementary counterexample to printed non-Archimedean Lemma 8.13 smoothness claim',
    setup='P^1_K, A_prime=O(1), sections X0,X1, chart T=X0/X1',
    displayed_weight='(1/2) log(1+|T|^2)',value_at_zero='0',
    local_smoothness_argument='A CLD-smooth function near the K-rational point 0 depends on finitely many logarithms of analytic units. Every such unit has constant absolute value on a sufficiently small neighbourhood by the ultrametric inequality. Hence the function is locally constant.',
    nonconstant_sequence='T=pi^n tends to zero; displayed weights are positive for every n',
    exact_argument_checks=values,
    supported_replacement='Continuous Fubini--Study psi_j=max(log|s|+psi_prime,theta-j), regularizable by BE21 Example 7.12/Theorem 7.14, with reference phi=theta-psi_prime.',
    limitation='The Archimedean log-sum construction is not refuted. The intended integrability theorem can use the separate regularized-maximum input; no original general theorem is promoted.'))
assert 1-1==0 and 1+1==2
families.append(dict(name='The CLN proof expansion needs a minus sign',status='PASS — exact constant-shift diagnosis',
    setup='P^1_C, L0=L1=O(1), phi0=phi0_prime a smooth semipositive degree-one metric; phi1-phi1_prime=1',
    correct_integral='0 because ddc(phi0-phi0_prime)=0',printed_plus_integral='2 because both positive curvature masses are one',
    correct_expansion='integral of difference times ddc(phi0) minus integral of difference times ddc(phi0_prime)',
    intended_absolute_value_bound_remains_valid=True,
    limitation='This diagnoses a displayed equality in Lemma 8.6, not the final CLN bound.'))
families.append(dict(name='A nonzero global section may still fail logarithmic integrability when it is a zero divisor',
    status='PASS — elementary regular-section hypothesis boundary',
    X='disjoint union of two P^1 components',line_bundle='O(1) on each component',
    section='(0,X1), nonzero globally but identically zero on the first component',
    regular_section=False,model_curvature_mass_on_each_component=1,
    first_component_log_section='-infinity on a component with positive measure mass',
    logarithmic_integral_finite=False,
    limitation='Outside Theorem 8.12 regular-section hypothesis; not a counterexample to that theorem.'))
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — six exact elementary diagnostic families',
    families=families,total_families=6,original_general_results_promoted=[],
    independent_model_receipt=None,canonical_status_changes=[],active_book_changed=False,
    whole_primary_PDF_reading_claim=False,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],families=6,record_SHA256=hashlib.sha256(out.read_bytes()).hexdigest())))
