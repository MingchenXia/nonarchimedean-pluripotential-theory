from pathlib import Path
from datetime import datetime,timezone
import urllib.request,hashlib,json,re
D=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Yuan_Chebyshev_chi_volume_dependency_review_20261009')
assert not D.exists();D.mkdir(parents=True)
url='https://arxiv.org/abs/0909.3680'
with urllib.request.urlopen(url,timeout=40) as r:
 data=r.read(2*1024*1024);status=r.status;resolved=r.geturl();ctype=r.headers.get('Content-Type')
p=D/'Yuan_Current_Metadata_0909.3680.html';p.write_bytes(data)
html=data.decode();versions=sorted(set(re.findall(r'0909\.3680v\d+',html)))
hist=re.search(r'<div class="submission-history">(.*?)</div>',html,re.S)
history=re.sub('<[^>]+>',' ',hist.group(1)) if hist else ''
out=D/'metadata_discovery_v1_20261009.json';out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),URL=url,resolved_URL=resolved,HTTP=status,Content_Type=ctype,versions=versions,submission_history=history,metadata_SHA256=hashlib.sha256(data).hexdigest(),metadata_only=True,full_source_read=False,helper_source=__file__,helper_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(versions=versions,history=history),ensure_ascii=False))
