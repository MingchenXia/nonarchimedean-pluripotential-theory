from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as Q
from math import comb,factorial
import hashlib,json,sympy as sp
R=Path('/workspace/nonarchimedean-pluripotential-theory');D=R/'source_material/Yuan_Chebyshev_chi_volume_dependency_review_20261009/YuanArxivV1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();now=lambda:datetime.now(timezone.utc).isoformat()
prep=json.loads((D/'scope_preparation_v1_20261009.json').read_text());receipts=[];pages=[]
for n,x in enumerate(prep['entries'],1):
 note=D/f'primary_notes_v1/note_{n:02d}.md';p=note.with_suffix('.json');r=json.loads(p.read_text())
 assert r['number']==n and r['physical_pages']==x['physical_pages'] and r['complete_text_actually_read'] and r['matching_image_actually_viewed']
 assert sha(note)==r['note_SHA256'] and sha(x['image_path'])==r['image_SHA256'] and sha(x['text_path'])==r['text_SHA256']
 assert r['PDF_SHA256']==prep['PDF_SHA256']==sha(prep['PDF'])
 assert r['previous_receipt_SHA256']==(receipts[-1]['receipt_SHA256'] if n>1 else None)
 receipts.append(dict(number=n,pages=x['physical_pages'],note_SHA256=sha(note),receipt_SHA256=sha(p)));pages.extend(x['physical_pages'])
assert pages==list(range(1,20)) and len(receipts)==10
book=sha(R/'manuscript/book.pdf');native=sha(R/'output/open_problems_catalogue_2026-10-03.tex')
assert book=='79a07672385e2ace08e064474a0948b8acdaae8ac6b43f94aecbc36afd10e45c'
assert native=='2d55114885d92f1ceacc17e74a2c397d992fb049d0f40810847787bff2f70fe8'
N=sp.symbols('N',positive=True);counts={};limits=[];finite=0;literal_fail=0
for dim in range(1,5):
 for degree in [1,2,3]:
  rank=sp.prod(degree*N+j for j in range(1,dim+1))/sp.Integer(factorial(dim))
  for field_degree in [1,2,4]:
   for a in [Q(-1),Q(-1,4),Q(0),Q(1,4),Q(1)]:
    A=sp.Rational(a.numerator,a.denominator)
    chi=sp.limit(rank*N*field_degree*A*sp.factorial(dim+1)/N**(dim+1),N,sp.oo)
    convex_integral=-field_degree*A*degree**dim/sp.factorial(dim)
    assert convex_integral==-chi/sp.factorial(dim+1)
    if a:assert convex_integral!=-chi/sp.factorial(dim);literal_fail+=1
    limits.append(dict(dim=dim,degree=degree,K_degree=field_degree,shift=str(a),chi_raw=str(chi),convex_integral_raw=str(convex_integral)))
    for m in range(1,9):
     r=comb(degree*m+dim,dim);total=Q(m*r*field_degree)*a;positive=Q(m*r*field_degree)*max(a,Q(0))
     assert positive>=total and positive>=0;finite+=1
counts.update(constant_metric_finite_cases=finite,exact_signed_volume_factorial_limits=len(limits),nonzero_literal_factorial_mismatches=literal_fail)
gram_cases=0
for rank in range(1,5):
 for scale in [2,3,4]:
  gram=sp.eye(rank)*scale**2;det=gram.det()
  assert sp.sqrt(det)**-1==sp.Rational(1,scale**rank)
  assert det**-1==sp.Rational(1,scale**(2*rank))
  assert det!=det**-1
  gram_cases+=1
counts['real_complex_ellipsoid_scaling_cases']=gram_cases
assert Q(2)-Q(1)==1
counts['Q_i_rank_one_basis_change_log2_coefficient_witness']=1
counts['Q_rank_one_real_unit_ball_ratio_witness']=1
model_values=[Q(1,1),Q(1,1),Q(1,2)]
assert min(model_values)==Q(1,2) and min(model_values).denominator==2
counts['two_blowup_special_component_fractional_sup_valuation_table']=1
upper=24/((4*N-4)*(4*N-3)*(4*N-2)*(4*N-1))
assert sp.limit(N**2*upper,N,sp.oo)==0
beta_cases=0
for m in range(2,66):
 exact=sp.Rational(24,(4*m-4)*(4*m-3)*(4*m-2)*(4*m-1))
 assert sp.simplify(4*sp.factorial(3)*sp.factorial(4*m-5)/sp.factorial(4*m-1)-exact)==0
 beta_cases+=1
counts['continuous_metric_beta_integral_exact_bounds']=beta_cases
counts['continuous_metric_m_squared_L2_squared_upper_limit_zero']=1
monomial_cases=0
for m in range(1,33):
 for i in range(m+1):
  for a in [Q(-1),Q(0),Q(1,4),Q(1)]:
   concave_F=Q(m)*a;convex_F=-concave_F
   assert concave_F/m==a and convex_F/m==-a
   assert sp.factorial(2)*a==2*a
   monomial_cases+=1
counts['P1_constant_shift_monic_leaf_cases']=monomial_cases
cal=D/'own_exact_normalization_calibrations_v1_20261009.json';assert not cal.exists()
cal.write_text(json.dumps(dict(UTC=now(),status='EXACT SCOPED DIAGNOSTICS PASSED — no independent promotion receipt',counts=counts,
 constant_metric_limits=limits,continuous_metric_alpha='1/2',continuous_metric_L2_squared_upper_bound=str(upper),
 nonreduced_model_component_multiplicities=[1,1,2],vertical_divisor_coefficients=[1,1,1],fractional_sup_valuation='1/2',
 Q_i_basis_change='finite log4 requires complex log4, not log2',rank_one_Q_unit_ball_volume=2,
 deeper_dependencies_recursively_verified=False,original_results_promoted=[],independent_verifier_receipt=None,
 helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
out=D/'actual_complete_source_checkpoint_v1_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=now(),status='DONE — actual complete pinned source reading and ordinary reconstructed leading-formula audit',
 source_version='arXiv:0909.3680v1, 21 September 2009',internal_title_date='November 21, 2018',PDF=prep['PDF'],PDF_SHA256=prep['PDF_SHA256'],
 physical_pages_read=pages,unique_physical_pages=19,full_source_read=True,fresh_matching_views=10,reused_matching_views=0,receipts=receipts,
 preparation_SHA256=sha(D/'scope_preparation_v1_20261009.json'),acquisition_SHA256=sha(D/'source_acquisition_v1_20261009.json'),
 own_exact_calibrations_SHA256=sha(cal),own_review_SHA256=sha(D/'own_complete_source_review_v1_20261009.md'),
 corrected_formula='concave integral >= normalized signed chi/(n+1)!; equality under uniform all-leaf bound',
 main_results_imported=False,intended_main_results_refuted=False,source_printed_formulas_used_unrepaired=False,
 deeper_dependencies_recursively_verified=False,original_results_promoted=[],canonical_status_changes=[],independent_verifier_receipt=None,
 active_book_changed=False,book_pages=4685,book_PDF_SHA256=book,native_editor_changed=False,native_catalogue_SHA256=native,
 whole_book_reading_claim=False,helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(full_pages=19,fresh_views=10,checkpoint_SHA256=sha(out),calibrations_SHA256=sha(cal),counts=counts)))
