# Reboulet asymptotic FS actual primary view 07

UTC: 2026-10-09T02:11:54.833274+00:00. Physical pages: 13, 14.

Read the complete selected text and displayed matching rendered image.

Remark 1.4.7 correctly distinguishes the ordered case: zeta<=zeta' gives signed volume=d_1, and reversing order gives -volume=d_1. The determinant formula 1.4.8 divides by d; its terminal e_n should use the stated dimension d. The cocycle 1.4.9 follows from differences of log determinant norms. Proposition 1.4.10 explicitly contradicts the unqualified introductory lattice-density sentence: diagonal norms are dense in all norms, but lattice norms over discretely valued K are discrete and closed; lattice density in diagonal norms requires dense value group. A fixed-dimensional discrete lattice need not approximate arbitrary real weights.

Lemma 1.4.11 says the unit ball of an arbitrary diagonal norm is still a lattice over discretely valued K, while over densely valued K a norm has a lattice unit ball exactly when it is a lattice norm. These claims do not identify a norm with the gauge of its unit ball in the discrete case. The scalar-extension norm is the infimum of maxima over representations by vectors in the original V and coefficients in the complete extension field. Proposition 1.4.14 attributes diagonal-basis extension and invariance of normalized signed volume to BE20; no recursive review of all BE20 dependencies is claimed. The normalized volume is 1-Lipschitz in each variable for d_infinity. Later passing to an algebraically closed extension can supply dense valuation for nontrivially valued K, but such a reduction must appear in the actual graded approximation proof before introductory density is admitted.

Section 2.1 uses projective K-varieties, completed residue fields H(x), and additive line-bundle notation. The metric weight on the zero vector is +infinity because exp(-phi) is a norm. The continuity condition concerns analytic points/local analytic evaluations; bare x in X or U in this displayed definition is shorthand for the analytification. No arbitrary singular/local psh or envelope continuity statement follows from these metric definitions.
