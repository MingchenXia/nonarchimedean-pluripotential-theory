# Reboulet asymptotic FS actual primary view 04

UTC: 2026-10-09T02:05:49.199157+00:00. Physical pages: 7, 8.

Read the complete selected text and displayed matching rendered image.

Physical 7–8 completes the plan/notation and begins the field definitions. The article explicitly defines a variety to be geometrically integral, separated and finite type. This stronger hypothesis belongs to its signatures; it is not silently generalized to arbitrary reducible or nonreduced projective schemes. Symmetric, tensor and exterior powers are distinguished, and h0 is a K-dimension. The letter L can denote a field or a line bundle according to context, so type checks remain necessary in later formulas.

The absolute-value axioms imply positivity on nonzero elements through multiplicative inverses. Value-group classifications refer to nonzero absolute values, despite the printed shorthand saying the set of values of the absolute value. “Non-Archimedean field” includes Cauchy completeness in Definition 1.1.2. Trivial, nontrivial discrete and nontrivial dense cases must remain separate. Residue ring, maximal ideal and residue field are defined with the correct <=1 and <1 inequalities. Equal- and mixed-characteristic conventions are explicit. Remark 1.1.4 starts an external embedding/completeness input whose remaining conditions are on the next page. All text and notation are legible; no full reading or theorem clearance is claimed yet.
