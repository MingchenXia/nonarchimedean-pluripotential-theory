# Reboulet asymptotic FS actual primary view 19

UTC: 2026-10-09T02:17:54.093634+00:00. Physical pages: 37, 38.

Read the complete selected text and displayed matching rendered image.

The model-energy comparison reduces O(1) model/supnorm distortion to zero after division by m, then invokes BE20 Theorem 9.15. These external theorems remain dependencies; normalized signs and Hilbert factorial must match note 18.

The arbitrary graded-norm proof of Theorem 5.1.1 calls the generated FS potentials 'decreasing nets' and applies decreasing continuity of E. This is not justified by submultiplicativity. At a one-point variety with zeta_m=exp(-floor(m/2)) and trivial reference, FS_m=floor(m/2)/m: values at m=1,2,3 are 0,1/2,1/3. They are not a decreasing sequence, and along divisibility the product argument gives increasing values. Fekete provides a pointwise limit equal to the supremum (in globally generated degrees), not decreasing regularization. The corrected normalization strategy would compare each generated kL identity after division by k and use a correctly proved normalized volume approximation; it must not be credited as established here while that approximation's external proof remains unaudited.

Continuity of envelopes is explicitly defined for continuous obstacles; Remark 5.2.5 requires it to make usc of the FS supremum global psh. This does not prove the hypothesis. The cited 2020 examples are historical and too loosely phrased as 'any line bundle' or positive-characteristic resolution only: use the book's exact ample/semiample, field-of-definition and resolution-dimensional scopes from the reviewed primary sources, not an updated blanket statement. No current exhaustive state-of-the-art credit follows from those citations.

Definition 5.3.1 is incompatible with the preceding nontrivially valued ground field: a divisor on a K-birational model of X has ord_E(a)=0 for every a in K^*, so exp(-c ord_E) restricts to the trivial absolute value on K. Such horizontal divisorial valuations are not points of X^an over nontrivial K. Its printed claim of density in X^an therefore fails in that scope. Genuine nontrivial-ground divisorial analytic points come from vertical divisors on models over K^circ (with appropriate extension-valuations and normalization), not this definition. This type error will be tracked through the following comparison and injectivity arguments; it is not a counterexample to a correctly formulated correspondence, and is unrelated to repairing BJ22 Siu decomposition.
