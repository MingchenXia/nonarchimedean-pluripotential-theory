# Reboulet asymptotic FS actual primary view 03

UTC: 2026-10-09T02:05:11.736633+00:00. Physical pages: 5, 6.

Read the complete selected text and displayed matching rendered image.

Physical 5–6 states the main introduction and its proof plan. Theorems A and B expressly assume continuity of envelopes for (X,L). The usc-regularized asymptotic FS operator is therefore not an independent proof of that assumption, and cannot repair the current general Siu/envelope boundary. Its target is the bounded global class regularizable from below, with increasing FS approximations; the exact role of usc regularization and possible noncontinuity must be checked in Section 5 before importing the bijection or energy identity.

Theorem C forms norms from degree k on a Veronese ring. Its displayed volume convergence requires careful degree normalization: if the newly generated norm is regarded as degree-one data for kL, its first-moment volume scales by k, so one must identify the original grading or insert normalization. A one-point multiplicative graded norm is a useful diagnostic to check against the later precise formulation. No verdict on the main result is made from an introductory notation shortcut.

The introductory statement that lattice norms are dense in all norms at a fixed degree is literally false over a discretely valued field: in dimension one, lattice norms have weights in the discrete absolute-value group, while a weight halfway between adjacent logarithmic values has positive distance from every lattice norm. Later field extension or divisible-degree approximation may restore the intended argument, and those steps remain to be read. The phrase describing relative energy as between continuous psh functions also cannot be assumed for every asymptotic bounded metric without its later extension. These are typed proof interfaces to audit, not claimed counterexamples to intended corrected Theorems A–C. All printed conditions and volume/energy signs are legible.
