# Reboulet asymptotic FS actual primary view 02

UTC: 2026-10-09T02:04:17.123771+00:00. Physical pages: 3, 4.

Read the complete selected text and displayed matching rendered image.

Physical 3–4 gives the complete first half of the introduction. The standing algebraic domain is a projective variety with ample L. The FS potential uses a fixed reference metric and a minus-log norm weight. The displayed basis form requires a basepoint-free power; arbitrary low tensor powers are not silently assumed globally generated. The discrete-field introductory diagonalization is distinguished from the general dense-field norm operator to be defined later.

Graded norms are submultiplicative on the section ring. Their FS weights have a Fekete-type pointwise asymptotic limit, potentially infinite without the subsequent boundedness premise. Finite generation uses a Veronese section ring generated in degree one. The printed introductory definition says the quotient norm is induced by zeta_m on Sym^m H0(rL); that norm must be induced by zeta_r to type the stated domain. The later precise definition will control this notation. Exponential distortion against a finitely generated reference means linear logarithmic distance in degree, rather than a uniform unnormalized norm bound.

The relative spectrum has sign log(zeta_prime/zeta). Dividing its weights by m and its counting measure by h0(mL) produces a probability measure. The first absolute moment defines the proposed asymptotic d1 quotient; d1 zero and weak convergence to delta_0 are presented as equivalent within bounded graded norms. Existence and support of the spectral limit cite earlier work and are still to be examined in the main proofs. This is an introductory claim, not a new certificate of the final bijection. Formulas and all multiplicity/normalization factors are legible.
