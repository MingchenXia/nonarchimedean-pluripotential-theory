# Reboulet asymptotic FS actual primary view 22

UTC: 2026-10-09T02:19:24.570249+00:00. Physical pages: 43.

Read the complete selected text and displayed matching rendered image.

Read the final bibliography page in full. Hartshorne's Algebraic Geometry is the 1977 Noetherian-oriented reference cited for eventual Proj section comparison, not a direct independent proof over a dense non-Noetherian valuation ring. Jonsson--Mustata (2012), Valuations and asymptotic invariants for sequences of ideals, is the cited valuation-space density reference; its occurrence does not correct the fact that the horizontal c ord_E definition is trivial on K and hence outside X^an for nontrivially valued K. KK12, LM09, KMR19, Nys09 and Okounkov 2003 concern Newton--Okounkov bodies, transforms and multiplicities; those bibliography entries carry zero additional dependency-proof credit. Poineau 2010 is also metadata only.

This completes the actual ordered review of all 43 physical pages of the pinned arXiv:2004.11635v1 PDF, through 22 individually displayed matching sheets, each with complete selected text and sequential authored notes. It is not a new whole-book reading pass. The final source audit will distinguish harmless indexing/sign/formula slips from load-bearing missing scope, Veronese scaling, wrong monotonicity, mistyped nontrivial-ground valuations, and unregularized-versus-usc envelope identities. A--C remain intended source results requiring qualified sources/proof reconstruction; this review alone will not promote a general correspondence, repair envelope continuity or BJ22 Theorem 6.21, or alter the 42-atom/12-problem inventory. No independent model receipt exists.
