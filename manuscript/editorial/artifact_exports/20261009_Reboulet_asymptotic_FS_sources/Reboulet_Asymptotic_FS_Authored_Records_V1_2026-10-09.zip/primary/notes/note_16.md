# Reboulet asymptotic FS actual primary view 16

UTC: 2026-10-09T02:16:00.528551+00:00. Physical pages: 31, 32.

Read the complete selected text and displayed matching rendered image.

Lemma 4.3.2 completes its interior exhaustion argument: embed a compact convex K strictly inside a larger compact convex L in the body's interior; sufficiently fine lattice points in L have convex hull containing K; the degree-one points force that hull into k^(-1)Delta(Gamma^k). This depends on the cited lattice-filling theorem and full-dimensional admissibility, not mere semiampleness.

Threshold semigroups are defined by Phi(n,alpha)>=nt. Hence for l<t the inclusion is Gamma_(>=t) subset Gamma_(>=l), opposite the printed Remark 4.4.2. The Chebyshev transform has domain points of the degree-one body, so its displayed argument (n,alpha) is only notation for a point in that slice, not arbitrary graded degree. Concavity/continuity on the interior is externally attributed to BC11.

Theorem 4.5.1 calls mu^(k)=sum_(alpha in Gamma_k) delta_(Phi(k,alpha)/k) a probability measure but omits division by #Gamma_k. For the P^1,O(1) semigroup with k+1 leaves its literal mass is k+1; insert (#Gamma_k)^(-1) before any probability or moment claim. Also bare superadditivity is insufficient for a compactly supported limit: Phi(n,alpha)=n^2 is superadditive, but the normalized probability measures delta_n escape to infinity. Applicable linear growth/support assumptions must be retained from the bounded-norm context and external theorem.

The printed closed-tail identity for every t<=theta additionally needs endpoint/continuity qualification. On an admissible semigroup set Phi(n,alpha)=cn-sqrt(n) for n>0 and Phi(0)=0. It is superadditive, theta=c, and normalized measures converge to delta_c; Gamma_(>=c) has no positive-degree elements, so its body has volume zero while delta_c([c,infinity))=1. This refutes the literal endpoint tail formula, not the useful weak convergence or almost-everywhere/distribution continuity-point formula. Preserve the distinction when integrating tails for moments. These are concrete formula diagnostics, not independently certified new general results.
