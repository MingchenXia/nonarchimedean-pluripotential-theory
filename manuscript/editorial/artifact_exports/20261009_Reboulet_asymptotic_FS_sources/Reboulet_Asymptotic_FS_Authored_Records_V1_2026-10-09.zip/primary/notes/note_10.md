# Reboulet asymptotic FS actual primary view 10

UTC: 2026-10-09T02:13:15.262015+00:00. Physical pages: 19, 20.

Read the complete selected text and displayed matching rendered image.

Rational model metrics use phi_L=(1/m)phi_(mL), independently of a clearing denominator. Pure FS corresponds to a semiample rational model, attributed to BE20 Theorem 5.14. In Example 2.4.11 the outside factor 1/m is appropriate only if FS there is the unnormalized degree-one operator on mL; the earlier FS_m already includes 1/m. Also the generating power in that model example must generate the model line bundle, not merely its generic fiber. Keep operator domains explicit.

Section 3 says semiample L and integral multisection ring (standing X geometrically integral), temporarily broader than Section 2.4's ample assumption. Graded norms are submultiplicative on products and model-section lattices supply examples. Boundedness Definition 3.1.4 writes a finite limit of m^(-1)d_infinity from a model norm, while its explanatory equivalent is eventual two-sided exp(+-mC) comparison. The latter corresponds to a finite limsup without a separate existence proof; later arguments and any book formulation should use the explicit O(m) condition rather than assume existence of this particular limit. Model/reference independence is attributed to BE20 Theorem 6.4, not recursively verified by these pages. Trivial ground valuation uses the trivial graded reference norm, not arbitrary model gauges.

Theorem 3.1.6 currently states existence of a bounded-support weak limit for rescaled normalized counting spectral measures; its proof is deferred to the next section. H^0(mL)=0 has no probability spectral measure. Under mere semiample L one must at least restrict to degrees with nonzero sections; Okounkov-body proof's later big/ample scope must be checked before importing the printed broader statement. Uniform support comes from O(m) distortion after comparison to a common reference; weak convergence is a separate assertion. No envelope continuity, d_infinity limit, or singular psh correspondence has been admitted yet.
