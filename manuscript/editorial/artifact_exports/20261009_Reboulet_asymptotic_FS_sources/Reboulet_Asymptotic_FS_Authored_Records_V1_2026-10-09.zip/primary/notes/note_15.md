# Reboulet asymptotic FS actual primary view 15

UTC: 2026-10-09T02:15:27.351563+00:00. Physical pages: 29, 30.

Read the complete selected text and displayed matching rendered image.

The spectral-existence reduction needs a uniform lower bound on log quotient norm of leading-one sections, equivalently an upper linear bound on the Chebyshev weight. Linear growth |alpha|<=C'n and O(n) distortion from a bounded-metric supnorm reduce it to a local coefficient estimate. If rescaled distortion tends to D, the eventual comparison must use D+epsilon, not necessarily D exactly as printed. A finite limsup suffices for the same reduction.

At a smooth K-rational point over the algebraically closed complete nontrivial field, one can choose a sufficiently small analytic polydisc and a local frame. The printed maximum-principle inequality r^|alpha|<=|f| 'on U' is not pointwise true: f=z, alpha=1, z=0 gives r<=0. The useful statement is r^|alpha|<=sup_D |f| (or a Gauss seminorm), for a smaller closed polydisc radius r>0; its leading coefficient is one. Bound the reference-frame weight on this compact smaller domain, then the global section supnorm is at least exp(-Cn)r^|alpha|. This supplies the intended elementary coefficient estimate and uses no pointwise positive lower bound at a zero of s. The actual spectral limit still depends on the separately cited Chen--Maclean theorem and big/admissible semigroup hypotheses.

Theorem 4.3.1 is an external interior lattice-filling theorem for admissible semigroups. Lemma 4.3.2 compares the regraded semigroup Gamma^k with degree-one piece Gamma_k and later pieces contained in Gamma_(kr). Its body is scaled by k, so the volume correction is k^(-d), not an unscaled volume equality. Semigroup multiplication forces convex hull of Gamma_k into its degree-one body; compact interior filling supplies the reverse volume limit. The next page completes that argument. No new theorem promotion or envelope-continuity claim follows from this elementary scaling discussion.
