# Reboulet asymptotic FS actual primary view 09

UTC: 2026-10-09T02:12:47.981334+00:00. Physical pages: 17, 18.

Read the complete selected text and displayed matching rendered image.

The graded supnorm map is initially defined on continuous potentials, followed by language about bounded metrics; extending this domain requires making the bounded metric supnorm definition explicit. Section 2.3's constructed mixed Monge-Ampere measures are for continuous global psh metrics and have intersection-number mass; scalar extension is stated via pushforward. Definition 2.3.2 writes phi,phi' in unrestricted PSH even though preceding construction covered continuous metrics; singular or bounded extensions must be justified separately. It normalizes both MA and E by vol(L)=c_1(L)^d for semiample big L, so MA is a probability measure.

Proposition 2.3.4's literal displayed cocycle has wrong orientation: E(phi,phi')=E(phi',phi'')+E(phi'',phi). For phi=phi_ref+1 and phi'=phi''=phi_ref, Definition 2.3.2 gives left side 1 and right side -1. The consistent cocycle is E(phi,phi')=E(phi,phi'')+E(phi'',phi'), or the cyclic sum is zero. This is a source sign diagnostic, not an original general theorem. Later relative-volume/energy identities must be audited against the defining integral rather than this display.

From Section 2.4 onwards L is ample. Models are flat finite-type over K^circ, with generic fiber identified with X; models of (X,L) additionally are projective over K^circ. The assertion Spec K^circ has two points applies to nontrivial rank-one valuations; trivial K^circ=K has one point. Dense value group makes K^circ non-Noetherian; this observation is not a proof or disproof of envelope continuity. The bounded tube X^beth equals X^an only for a proper model. Hence the projectivity in model-line-bundle Definition 2.4.5 is needed before unitary frame metrics are defined globally in 2.4.8. Generic projectivity alone is insufficient for a nonproper chosen model, as already audited in the BE21 reduced-fibre unit. No general envelope repair is claimed.
