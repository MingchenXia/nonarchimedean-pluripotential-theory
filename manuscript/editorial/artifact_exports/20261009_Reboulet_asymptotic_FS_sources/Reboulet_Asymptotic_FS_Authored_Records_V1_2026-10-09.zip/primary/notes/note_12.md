# Reboulet asymptotic FS actual primary view 12

UTC: 2026-10-09T02:13:59.910479+00:00. Physical pages: 23, 24.

Read the complete selected text and displayed matching rendered image.

Degree-one generation is quotient generation from symmetric powers of the degree-one norm along the surjective section multiplication map. Finite generation means generation on a Veronese R(X,rL), whose degree m is the old degree rm. Proposition 3.3.5 explicitly states spectral scaling by r under this regrading. Therefore normalized mean volume and d_1 on rL are r times the original values; any comparison at original degree rm must divide by rm, not m. This is the missing factor flagged in introductory Theorem C and will be checked against its actual proof.

The displayed spectral shift by c, written e^(-c)zeta_bullet, requires the degreewise convention (e^(-cm)zeta_m)_m. Multiplying all degrees by the same e^(-c) only shifts the rescaled spectrum by c/m and may also break submultiplicativity. A book statement must spell out graded scaling rather than copy this ambiguous notation. Exchange of the two norms reverses spectral sign.

Quotient norms contract d_infinity by taking infima of two-sided bounds for every lift. The first sufficient comparison in Proposition 3.3.6 prints the upper bound with the same unprimed quotient norm; it should use the primed norm. Both subsequent lower-bound arguments do prove the correct two-sided assertion. Symmetric/tensor powers enlarge degree-one distance by at most m; after the quotient this gives m^(-1)d_infinity<=degree-one distance, and the m=1 term gives equality for the sup-based graded d_infinity metric. No density of integral weights was needed here. Finite-generation reference independence in Remark 3.3.4 is stated, not independently proved on these two pages.
