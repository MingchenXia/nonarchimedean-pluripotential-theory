# Reboulet asymptotic FS actual primary view 01

UTC: 2026-10-09T02:03:30.959937+00:00. Physical pages: 1, 2.

Read the complete selected text and displayed matching rendered image.

Physical 1–2 are the complete title/abstract and contents. The pinned primary is arXiv:2004.11635v1, submitted 24 April 2020; its title page displays 27 April 2020. The two dates are retained separately rather than inventing a later revision or journal version. The abstract concerns bounded graded norms, an ample polarization and bounded global psh metrics regularizable from below. It does not announce arbitrary local weak-psh regularization. The exact hypotheses and proofs remain to be read before any result is imported.

The contents maps finite-dimensional norms and spectra to metrics/models, bounded graded norms and degree-one generation, Chebyshev/Okounkov transforms and equidistribution, then volumes/energies, envelopes and the asymptotic FS bijection. The second page is intentionally short and completes the contents; its blank remainder contains no unexamined text. All text, dates, page locators and the arXiv margin stamp are legible. Acquiring or preparing all 43 pages did not give proof-reading credit; only these two pages have been read at this note.
