# Reboulet asymptotic FS actual primary view 18

UTC: 2026-10-09T02:17:13.854929+00:00. Physical pages: 35, 36.

Read the complete selected text and displayed matching rendered image.

Theorem 5.1.1 targets lim_m E(FS_m(zeta_m),FS_m(zeta'_m))=normalized signed volume. The introduction explicitly imposed continuity of envelopes on its Theorem B; later section-wide prerequisites and full proof must be read before deleting that qualification. Replacing L by a degree-one-generated Veronese also rescales normalized energies and signed volume by the power of L; the reduction's citation to Remark 4.5.5 is not a license to omit that factor.

Lemma 5.1.2's concluding Theorem A should be Theorem B in this reduction. The equality of FS under scalar extension must be pi_1^*FS_m(zeta_m), not the displayed pi_1* acting on a function on the base. Proposition 1.4.14 addresses norm volumes/diagonalization; exact FS pullback is instead BE21 Proposition 7.20, already directly reviewed in the global-approximation checkpoint. Combined with pushforward invariance of mixed MA measures it gives invariance of the energy integral. Rightmost mixed-measure arguments also have a misplaced prime; the intended pair is FS_m(zeta_m),FS_m(zeta'_m). No analytic measure pushforward is being used as a pullback of functions.

The degree-one-generated case approximates generators by lattice norms after passing to dense valuation. Bounds are eventual in m, not for all m as one line prints. The eventual model FS limit can be identified with FS_1 of the generating lattice norm zeta^epsilon, but not automatically with the model's possibly larger degree-one section lattice. For a genuinely quotient-generated norm, FS_m=FS_1 of its generator follows from product-section lower bounds and evaluation of arbitrary tensor lifts for the upper bound; this is an elementary formal consequence of the quotient construction, not a new original theorem.

Lemma 5.1.4 delegates the model norm/supnorm volume comparison to BE20 Lemma 9.17. The printed asymptotic h^0(mL)/m^n=vol(L) misses 1/n!: for ample L, h^0(mL)~vol(L)m^n/n!. Combined with BE20's n!/m^(n+1) determinant normalization this does yield vol(L) times this paper's normalized signed mean. Energy here is also divided by vol(L); the factorial and positivity hypotheses must be made explicit. This is a normalization audit, not recursive certification of the external model-energy theorem.
