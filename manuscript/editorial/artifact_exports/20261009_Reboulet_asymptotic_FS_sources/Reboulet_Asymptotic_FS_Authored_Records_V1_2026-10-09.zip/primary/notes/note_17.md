# Reboulet asymptotic FS actual primary view 17

UTC: 2026-10-09T02:16:42.624552+00:00. Physical pages: 33, 34.

Read the complete selected text and displayed matching rendered image.

Proposition 4.5.3 and Theorem 4.5.4 mix two degree conventions. The generated norm zeta^(k) is initially a norm on R(X,kL), whose degree r is the original kr. But Gamma(kL) is subsequently represented by old degrees divisible by k, with unscaled cone slice; the printed theta_k divides Phi_k(kn,alpha) by n rather than kn. Under genuine kL regrading its body is k Delta(L) and its probability weights/mean are k times old-degree weights. Under retaining original degrees, the body agrees with Delta(L) and all logarithmic weights must divide by kr. A book statement must select one convention throughout.

A one-point projective variety with multiplicative norm zeta_m=exp(-cm), and reference zeta'_m=1, diagnoses literal Theorem 4.5.4: generation by zeta_k on kL gives degree-r norm exp(-ckr), whose normalized volume is ck, not c. Thus the intended approximation needs k^(-1)vol_(kL) or an expressly old-degree normalization. This does not disprove an appropriately normalized Fujita result.

The printed assertion theta_k is an increasing sequence does not follow from divisibility monotonicity (iii). At original-degree normalization take zeta_m=exp(-floor(m/2)) on the one-point ring. Submultiplicativity follows from superadditivity of floor(m/2), but generated slopes floor(k/2)/k drop from 1/2 at k=2 to 1/3 at k=3. Factorial/divisibility subsequences are increasing; the proof's final factorial notation alone does not automatically establish all-k convergence without an additional interior-filling/common remainder argument. Weak convergence in general gives CDF convergence at continuity points; the printed 'in particular' at every point requires extra justification. Its closed-tail endpoint formulas already fail the cn-sqrt(n) diagnostic recorded in note 16.

The finite moment sum in Theorem 4.5.4 also needs division by #Gamma_m=h^0(mL), as required by this paper's normalized determinant volume. Its recalled limit prints vol(zeta_bullet,zeta'_bullet) inside m^(-1) instead of vol(zeta_m,zeta'_m), an index error. With correctly normalized measures and a common compact support, weak convergence does imply first-moment convergence; bare weak convergence alone is insufficient. Remarks extending to all semiample rational L/any field do not supply the missing positive-volume and normalization checks. Main theorem promotion remains deferred.
