# Reboulet asymptotic FS actual primary view 08

UTC: 2026-10-09T02:12:19.209270+00:00. Physical pages: 15, 16.

Read the complete selected text and displayed matching rendered image.

The fixed reference metric phi_0 makes FS values potentials; on H^0(mL), |s| must use m phi_0. For globally generated mL, FS_m(zeta)=(1/m) log sup_s |s|/zeta(s). On a diagonal basis it is a finite maximum, with a_i=zeta(s_i)^(-1). The m^(-1) factor is essential, including after regrading rL. Pure finite-maximum FS metrics correspond to orthonormal/lattice norms. Arbitrary norms in the image H of FS_m and finite-maximum FS metrics in Definition 2.2.5 should not silently be identified without a diagonalization or an approximation argument over general K.

Definition 2.2.7 uses decreasing nets of global H functions, and only for continuous limits also uniform approximation. This is a projective global psh category, not an arbitrary local current/smooth-regularization category. Constant additions, decreasing nets, and finite maxima are stated stable after adjoining -infinity. The supnorm Nm uses metric m phi; geometric integrality in the standing variety convention excludes nilpotent section seminorm problems. Nm's distance is bounded by m||phi-phi'||_infinity; FS_m's potential difference is bounded by m^(-1)d_infinity(zeta,zeta'). The latter is printed FS without m but the domain dictates FS_m. No envelope continuity, lattice density in the discrete case, or correspondence theorem is inferred from these elementary Lipschitz bounds. The affine metric convention contains a psi where the other named metric is phi'; its intended norm transformation is |.|_phi=|.|_phi' exp(phi'-phi).
