# Reboulet asymptotic FS actual primary view 20

UTC: 2026-10-09T02:18:40.058772+00:00. Physical pages: 39, 40.

Read the complete selected text and displayed matching rendered image.

Theorem 5.3.4's proof invokes continuity of envelopes even though its isolated statement omits the hypothesis. Its PSH-up definition uses the incompatible horizontal Xdiv from note 19 in the nontrivial-ground case, so the claimed extension of BJ18a's trivial-field lemma is not justified as written. A correctly typed dense set of analytic model valuations and a proof of the relevant determination/regularization lemma are separate dependencies. Boundedness of a genuine increasing-from-below global limit follows from any fixed continuous lower approximant together with compact upper boundedness; it must not be claimed from an empty/mistyped Xdiv.

The supnorm/FS identity used here is Q(phi)=lim_m FS_m(Nm(phi)); asymptotic FS includes usc regularization, hence FS(N_bullet(phi))=Q(phi)^usc=Q^*(phi), not necessarily unregularized Q(phi). This distinction is omitted in Lemma 5.4.4, where increasing supremum need not be continuous or usc. The reviewed BE21 source locator is Proposition 7.26 for convergence, 7.27 for equality of section norms of the envelopes. Theorems A and B must not be cited as a proof of envelope continuity.

Theorem 5.4.1 explicitly assumes ample L and continuity of envelopes. Lemma 5.4.2 states zeta>=zeta' but its proof switches to <= and writes d_1=volume rather than -volume. With the stated order the signed-volume orientation is negative; the zero condition survives a sign change, but energy monotonicity/order must stay consistent. The cited BJ18b energy/determination result is not fully audited by this source reading, and the displayed argument only writes one direction; the reverse requires the energy-volume identification as well.

The two-volume identity for d_1 uses the pointwise maximum of norms, which is again submultiplicative; it corresponds to a rooftop/minimum obstacle for metrics. The proof next substitutes a pointwise minimum of two supnorms where a maximum is needed. In fact N_m(min(phi,psi))=max(N_m(phi),N_m(psi)) because sup_x max equals max of the two suprema. Pointwise minimum of arbitrary norms need not be a norm: on two dimensions, weights (1/2,1) and (1,1/2) give minimum 1/2 on e1,e2 but 1 on e1+e2, violating ultrametricity. The remaining page must be checked before admitting a rooftop identity. These are source proof/type qualifications; no corrected general bijection has been promoted.
