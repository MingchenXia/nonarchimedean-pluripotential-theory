# Reboulet asymptotic FS actual primary view 06

UTC: 2026-10-09T02:11:31.954683+00:00. Physical pages: 11, 12.

Read the complete selected text and displayed matching rendered image.

The quotient, tensor, exterior and symmetric-power norm constructions finish the functorial background; apartments fix a basis and logarithmic weights. Relative spectrum Definition 1.4.1 is a minmax multiset of logarithmic ratios on nonzero vectors. For its displayed union of subspaces of dimensions at least i, the values run in decreasing order. Remark 1.4.2 instead orders the diagonal basis ratios increasingly and identifies the same indices. The diagonal ratios exp(-1), exp(1) give minmax lambda_1=1, lambda_2=-1; this exposes an indexing mismatch, without changing the spectral multiset.

Definition 1.4.4 first correctly defines d_p^p as the integral of |lambda|^p against the normalized counting measure. Its displayed d_infinity=max Sp omits absolute values, and its later practical d_1=(dim V)^(-1) sum lambda_i omits absolute values. The latter equals the signed relative volume, not the distance. Already on one dimension with zeta'=exp(-1) zeta, these literal displayed 'distances' are -1; on two dimensions with opposite ratios the signed mean is zero whereas d_1=1. The later supremum absolute log-ratio definition of d_infinity is the usable correct formula.

Remark 1.4.5 prints an upper bound zeta(v)<=exp(C) zeta(v), tautological for C>=0. The two-sided comparison requires zeta(v)<=exp(C) zeta'(v); a one-sided lower bound is insufficient for d_infinity. Definition 1.4.6 deliberately uses the signed mean integral lambda d sigma for relative volume, normalized by dim V, unlike BE20's unnormalized determinant-log convention. Keep the normalization and signed/absolute distinction explicit in later graded limits. These are ordinary source-formula diagnostics; no general new theorem, envelope continuity, main correspondence, or independent model verification is asserted.
