from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,urllib.request,fitz,subprocess

R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Reboulet_asymptotic_FS_review_20261009'
assert not C.exists();C.mkdir()
out=C/'primary_acquisition_v1_20261009.json';pdf=C/'Reboulet_2004.11635v1.pdf';txt=pdf.with_suffix('.txt')
url='https://arxiv.org/pdf/2004.11635v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
stamp=datetime.now(timezone.utc).isoformat()
try:
 with urllib.request.urlopen(url,timeout=45) as r:status=r.status;data=r.read();resolved=r.url
 assert status==200 and data.startswith(b'%PDF-');pdf.write_bytes(data)
 with fitz.open(pdf) as d:
  pages=len(d);assert 'asymptotic' in d[0].get_text().lower() and 'reboulet' in d[0].get_text().lower()
  txt.write_text('\n\n'.join(f'PHYSICAL PAGE {i+1}\n'+p.get_text() for i,p in enumerate(d)))
 core=json.loads((R/'source_material/BE21_reduced_fibre_integrability_review_20261009/staging_preparation_v1_20261009.json').read_text())
 names=sorted(set(core['other_active_TeX_preserved'])|set(core['after']));assert len(names)==425
 protected={n:sha(R/n) for n in names}
 for n in ['manuscript/book.pdf','manuscript/bibliography/ComplexGeometry.bib','manuscript/bibliography/NonArchimedean.bib','output/open_problems_catalogue_2026-10-03.tex','output/open_problems_catalogue_2026-10-03.pdf','README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']:protected[n]=sha(R/n)
 obj=dict(UTC=stamp,status='DONE — pinned arXiv v1 primary acquired; zero reading credit',source_URL=url,resolved_URL=resolved,HTTP_status=status,PDF=dict(path=str(pdf),bytes=pdf.stat().st_size,SHA256=sha(pdf),physical_pages=pages),full_text_extraction=dict(path=str(txt),bytes=txt.stat().st_size,SHA256=sha(txt)),primary_metadata='Reboulet, The asymptotic Fubini-Study operator over general non-Archimedean fields, arXiv:2004.11635v1, 24 April 2020',baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),protected_core_inputs=protected,actual_primary_reading_credit=0,actual_book_reading_credit=0,active_book_changed=False,native_editor_changed=False,canonical_status_changes=[])
except Exception as e:
 obj=dict(UTC=stamp,status='FAILED — primary acquisition/preflight; zero reading credit',source_URL=url,error_type=type(e).__name__,error=str(e),actual_primary_reading_credit=0,active_book_changed=False,native_editor_changed=False)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps({k:v for k,v in obj.items() if k in ['status','PDF','error_type','error','baseline_commit']},ensure_ascii=False))
