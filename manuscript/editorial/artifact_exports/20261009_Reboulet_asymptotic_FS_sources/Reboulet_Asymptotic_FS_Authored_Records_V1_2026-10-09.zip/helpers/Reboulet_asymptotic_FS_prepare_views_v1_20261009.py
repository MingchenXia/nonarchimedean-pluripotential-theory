from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,fitz
from PIL import Image,ImageDraw

R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Reboulet_asymptotic_FS_review_20261009'
W=Path('/tmp/Reboulet_asymptotic_FS_primary_views_v1_20261009');N=C/'primary_notes_v1';out=C/'primary_view_preparation_v1_20261009.json'
assert not any(p.exists() for p in [W,N,out])
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads((C/'primary_acquisition_v1_20261009.json').read_text());assert a['status'].startswith('DONE')
pdf=Path(a['PDF']['path']);assert sha(pdf)==a['PDF']['SHA256']
for n,h in a['protected_core_inputs'].items():assert sha(R/n)==h
W.mkdir();N.mkdir();views=[]
with fitz.open(pdf) as d:
 assert len(d)==43;selected=list(range(1,44))
 for i in range(0,len(selected),2):
  pp=selected[i:i+2];panels=[];texts=[]
  for n in pp:
   pix=d[n-1].get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False);panels.append(Image.frombytes('RGB',[pix.width,pix.height],pix.samples));texts.append(f'REBOULET ASYMPTOTIC FS ARXIV 2004.11635v1 PHYSICAL PAGE {n}\n'+d[n-1].get_text())
  canvas=Image.new('RGB',(sum(p.width for p in panels),max(p.height for p in panels)+28),'white');draw=ImageDraw.Draw(canvas);x=0
  for n,panel in zip(pp,panels):draw.text((x+8,8),f'Reboulet asymptotic FS 2004.11635v1: physical {n}',fill='black');canvas.paste(panel,(x,28));x+=panel.width
  number=i//2+1;ip=W/f'sheet_{number:02d}.png';tp=W/f'sheet_{number:02d}.txt';canvas.save(ip);tp.write_text('\n\n'.join(texts));views.append(dict(number=number,physical_pages=pp,path=str(ip),image_SHA256=sha(ip),selected_text_path=str(tp),selected_text_SHA256=sha(tp),source_PDF_SHA256=sha(pdf),actually_viewed=False,selected_text_read=False))
mp=W/'manifest.json';mp.write_text(json.dumps(views,ensure_ascii=False,indent=2)+'\n')
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete primary view preparation; zero reading credit',source_PDF=a['PDF'],acquisition_SHA256=sha(C/'primary_acquisition_v1_20261009.json'),selected_physical_pages=selected,prepared_pages=43,prepared_views=22,manifest_path=str(mp),manifest_SHA256=sha(mp),protected_core_inputs=a['protected_core_inputs'],baseline_commit=a['baseline_commit'],actual_source_reading_credit=0,actually_read_pages=0,active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='DONE',prepared_pages=43,prepared_views=22,record_SHA256=sha(out))))
