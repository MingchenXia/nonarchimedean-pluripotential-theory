from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction as F
from itertools import product
import hashlib, json

C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Reboulet_asymptotic_FS_review_20261009')
out=C/'exact_diagnostics_v1_20261009.json'
assert not out.exists()
families=[]
def record(name, locator, facts, proof):
    families.append(dict(name=name,source_locator=locator,status='PASS — exact elementary diagnostic',facts=facts,proof=proof))

weights=[F(-1),F(1)]
assert sum(weights)==0 and sum(map(abs,weights))/2==1
assert sorted(weights,reverse=True)==[1,-1]
record('Signed volume, absolute distances and minmax ordering','1.4.1--1.4.6, physical 11--12',
       dict(log_ratios=weights,signed_mean=0,d1=1,minmax_order=[1,-1],one_dimensional_literal_max=-1),
       'In dimension two lambda_1 takes the supremum of all line ratios, and lambda_2 the infimum on the whole plane. In dimension one the signed ratio -1 is volume, while every distance is its absolute value 1.')

E=lambda a,b:F(a)-F(b)
assert E(1,0)==1 and E(0,0)+E(0,1)==-1
record('Energy cocycle orientation','2.3.4, physical 18',dict(left=1,literal_right=-1),
       'For constant metric differences on a positive-volume polarization every mixed normalized measure has mass 1; the defining energy equals a-b.')

half=F(1,2)
assert min(abs(F(n)-half) for n in range(-10,11))==half
record('Discrete lattice obstruction','Introduction physical 6; 1.4.10, physical 13',dict(target_log_weight=half,nearest_integer_gap=half),
       'One-dimensional lattice logarithmic weights lie in the discrete value group Z after fixing its generator. For every integer n, |n-1/2|>=1/2; the finite check contains both minimizers 0 and 1.')

record('Semiample generic Proj and full-dimensional body obstruction','3.3 construction physical 25; 4.1 physical 27',dict(X='P1',L='O',section_ring='K[t]',generic_Proj_dimension=0,X_dimension=1,Gamma='[(m,0)]',body_dimension=0),
       'Every H0(P1,mO) is K and multiplication identifies the entire section ring with K[t]. Its Proj is Spec K, and all section orders are zero. Degree-one generation and semiampleness do not imply X=Proj or bigness.')

assert all(F(i)>1 for i in range(2,12))
record('Cone slice union is unbounded','4.1, physical 27',dict(intended_operation='intersection',literal_union_contains='entire {1} x R^d'),
       'For d>=1 the literal union contains (1,N,0,...,0) for every positive integer N and hence cannot be a compact convex body.')

for m in range(1,65):
    assert len(range(m+1))==m+1
    assert sum(F(1,m+1) for _ in range(m+1))==1
record('Counting measure normalization','4.5.1 physical 32; 4.5.4 physical 34',dict(P1_O1_leaf_count='m+1',literal_mass='m+1',probability_coefficient='1/(m+1)',missing_finite_volume_coefficient='1/h0(mL)'),
       'The monomials X0^(m-i)X1^i, 0<=i<=m, are a basis with distinct valuation leaves. Their unnormalized sum of Dirac measures has mass m+1.')

for c in [F(1),F(3,2),F(-2)]:
    for k in range(1,17):
        assert F(k)*c/F(k)==c
record('Veronese signed-volume normalization','3.3.5 physical 23; 4.5.3--4.5.4 physical 33--34',dict(original_degree_slope='c',regraded_kL_slope='kc',corrected_slope='(1/k) kc = c'),
       'On the one-point ring zeta_m=exp(-cm). Generation by zeta_k on kL gives exp(-ckr) in its degree r. Relative volume against 1 therefore equals kc, and requires division by k to compare with original L.')

for m in range(0,129):
    for n in range(0,129):assert (m+n)//2>=m//2+n//2
a=[F(k//2,k) for k in range(1,65)]
assert a[:3]==[0,F(1,2),F(1,3)] and a[1]>a[2]
record('Fekete averages and divisibility order','4.5.3 physical 33--34; 5.1.1 proof physical 37',dict(first_three_FS_slopes=a[:3],consecutive_monotone=False,divisibility_monotone=True),
       'floor(m/2) is superadditive. Its normalized averages converge to 1/2 with error at most 1/(2m), but alternate. If k divides l, repeated products imply a_l/l>=a_k/k; this is not consecutive monotonicity or a decreasing net.')

assert F(0)>=F(-1) and not F(0)>=F(1)
for q in range(1,33):
    n=q*q
    assert F(n-q,n)==1-F(1,q)<1
record('Threshold inclusion and atom endpoint','4.4.2 and 4.5.1 physical 32',dict(correct_inclusion='Gamma_(>=t) subset Gamma_(>=l) for l<t',Phi='n-sqrt(n)',theta=1,limit_probability='delta_1',Gamma_ge_1_positive_degrees='empty',limit_closed_tail_at_1=1,body_tail_at_1=0),
       'sqrt(m+n)<=sqrt(m)+sqrt(n) follows by squaring nonnegative sides, so n-sqrt(n) is superadditive and linearly bounded. All normalized weights are 1-1/sqrt(n)<1 and tend to 1. Thus the literal all-t closed-tail formula fails at theta. Also Phi=n^2 is superadditive and normalized delta_n is not tight without growth hypotheses.')

assert F(1,2)>0
record('Coefficient maximum principle is a supremum bound','4.2, physical 30',dict(f='z',alpha=1,radius=F(1,2),value_at_zero=0),
       'The leading-one function z vanishes at zero, so r<=|f(z)| cannot hold pointwise. On a smaller closed polydisc its Gauss seminorm is at least the leading coefficient times r^alpha, which is the needed local supnorm bound.')

assert F(1,5)!=1
record('Horizontal valuation is outside nontrivial-ground analytification','5.3.1, physical 38',dict(K='Q5',horizontal_ord_of_5=0,horizontal_absolute_value_of_5=1,required_absolute_value_of_5=F(1,5)),
       'On a K-birational model every nonzero scalar is a unit at any horizontal prime divisor. Thus c ord_E is zero on K*, while a Berkovich point must extend the given nontrivial K absolute value.')

norm=lambda v,w:max(abs(F(v[0]))*w[0],abs(F(v[1]))*w[1])
u=(half,F(1));v=(F(1),half)
mn=lambda x:min(norm(x,u),norm(x,v))
assert mn((1,0))==mn((0,1))==half and mn((1,1))==1
record('Pointwise minimum of norms is not a norm','5.4.1 proof, physical 40--41',dict(min_e1=half,min_e2=half,min_e1_plus_e2=1),
       'The literal minimum violates the ultrametric triangle inequality. The correct section norm identity is N(min(phi,psi))=max(N(phi),N(psi)), by commuting a finite maximum with a supremum.')

def abs5(a):
    if not a:return F(0)
    a=abs(a);q=0
    while a%5==0:q+=1;a//=5
    return F(1,5**q)
def zeta(a):
    m=len(a)-1
    return max([2**m*abs5(a[0])]+[abs5(x) for x in a[1:]])
def mul(a,b):
    c=[0]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):c[i+j]+=x*y
    return c
trials=0
for m,n in [(1,1),(1,2),(2,2)]:
    for a in product([-1,0,1,5],repeat=m+1):
        for b in product([-1,0,1,5],repeat=n+1):
            assert zeta(mul(a,b))<=zeta(a)*zeta(b);trials+=1
for m in range(1,65):
    for q in [F(1,2),F(1),F(5),F(20)]:
        assert max(F(-1),-q/F(m))<=max(F(-1),-q/F(m+1))
    assert F(1,m+1)>0
record('Rare section direction, d1 quotient and usc FS','3.2.2 physical 21; 5.2.4--5.4.5 physical 38--41',dict(X='P1_Q5',L='O1',basis='X0^(m-i)X1^i, 0<=i<=m',basis_norms='(2^m,1,...,1)',product_trials=trials,normalized_spectrum='(delta_(-log 2)+m delta_0)/(m+1)',rescaled_d1='log(2)/(m+1) -> 0',rescaled_dInfinity='log 2',chart_FS='max(-log 2, (log|T|)/m) if |T|<=1; log|T| if |T|>=1',pointwise_limit_at_T0='-log 2',pointwise_limit_elsewhere='standard FS',usc_limit='standard FS'),
       'The Gauss norm of a product is bounded by the product of Gauss norms, and the penalized constant term is multiplicative, proving submultiplicativity in all degrees. The exact finite trials supplement that argument. FS uses a diagonal monomial basis and is an increasing sequence; its raw bounded limit drops at T=0 and is not usc, whereas its usc regularization is the standard FS metric. Since all these FS metrics lie below the raw obstacle, its Q equals that raw obstacle. This provides a concrete worked illustration of d1=0 with positive rescaled operator distance, and of Q versus Q*, not a new general correspondence theorem.')

assert len(families)==13
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — thirteen exact source-formula and type diagnostic families',
         families=families,source_PDF_SHA256=sha(C/'Reboulet_2004.11635v1.pdf'),original_results_promoted=[],
         independent_model_receipt=None,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=str)+'\n')
print(json.dumps(dict(status=obj['status'],families=len(families),product_trials=trials,record_SHA256=sha(out))))
