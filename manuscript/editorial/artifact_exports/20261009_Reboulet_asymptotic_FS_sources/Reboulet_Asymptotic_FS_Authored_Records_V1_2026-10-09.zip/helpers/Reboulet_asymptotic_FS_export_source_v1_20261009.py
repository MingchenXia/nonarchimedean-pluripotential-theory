from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, zipfile

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Reboulet_asymptotic_FS_review_20261009'
E=R/'manuscript/editorial'
O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
reading=json.loads((C/'actual_primary_reading_v1_20261009.json').read_text())
diag=json.loads((C/'exact_diagnostics_v1_20261009.json').read_text())
assert reading['actual_source_unique_pages']==43 and reading['actual_individually_displayed_matching_views']==22
assert len(diag['families'])==13 and reading['whole_primary_PDF_reading_claim']
for name,h in reading['preparation_record_SHA256'].items():
    prep=json.loads((C/name).read_text());assert sha(C/name)==h
    for n,pin in prep['protected_core_inputs'].items():assert sha(R/n)==pin
paths={k:E/f'Reboulet_asymptotic_FS_source_{k}_20261009.{ext}' for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
record=C/'source_checkpoint_v1_20261009.json'
owned=O/'Reboulet_Asymptotic_FS_Authored_Records_V1_2026-10-09.zip'
full=O/'Reboulet_Asymptotic_FS_Actual_Source_Evidence_V1_2026-10-09.zip'
dest=E/'artifact_exports/20261009_Reboulet_asymptotic_FS_sources'
assert not any(p.exists() for p in [*paths.values(),record,owned,full,dest])
draft=Path('/tmp/Reboulet_asymptotic_FS_source_review_draft_v1_20261009.md')
paths['review'].write_bytes(draft.read_bytes());assert sha(paths['review'])==sha(draft)
paths['reading_notes'].write_text('# Actual Reboulet asymptotic FS source notes, 9 October 2026\n\nComplete pinned v1: 43 physical pages in 22 individually displayed matching views.\n'+''.join('\n---\n\n'+Path(v['note_path']).read_text() for v in reading['views']))
files={f'records/{p.name}':p for p in C.glob('*.json')}
for v in reading['views']:
    for k,folder in [('note_path','notes'),('observation_receipt_path','receipts')]:
        p=Path(v[k]);files[f'primary/{folder}/{p.name}']=p
files['manifests/manifest.json']=Path(prep['manifest_path'])
for p in Path('/tmp').glob('Reboulet_asymptotic_FS_*_v1_20261009.py'):files[f'helpers/{p.name}']=p
files[f'drafts/{draft.name}']=draft
for k in ['review','reading_notes']:files[f'editorial/{paths[k].name}']=paths[k]
def archive(target,entries):
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,p in sorted(entries.items()):z.write(p,n)
    with zipfile.ZipFile(target) as z:
        assert len(z.namelist())==len(entries)
        for n,p in entries.items():assert z.read(n)==p.read_bytes()
archive(owned,files)
fullfiles=dict(files)
fullfiles['primary/Reboulet_2004.11635v1.pdf']=Path(reading['source_PDF']['path'])
fullfiles['primary/Reboulet_2004.11635v1.txt']=C/'Reboulet_2004.11635v1.txt'
for v in reading['views']:
    for k,folder in [('image_path','images'),('selected_text_path','text')]:
        p=Path(v[k]);fullfiles[f'primary/{folder}/{p.name}']=p
archive(full,fullfiles)
artifacts={k:dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p),members=count) for k,p,count in [('authored_records_archive',owned,len(files)),('cloud_complete_source_evidence_archive',full,len(fullfiles))]}
paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete pinned primary reading and qualified ordinary source audit',actual_reading=reading,exact_diagnostics=diag,artifacts=artifacts,active_book_changed=False,native_editor_changed=False,GitHub_published=False,canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — byte-verified source exports',artifacts=artifacts,reading_credit_from_export=0,external_primary_PDF_text_images_uploaded=False,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
dest.mkdir(parents=True)
target=dest/owned.name;shutil.copyfile(owned,target);assert sha(target)==sha(owned)
(dest/'SHA256SUMS').write_text(sha(target)+'  '+target.name+'\n')
(dest/'README.md').write_text(f'''# Reboulet asymptotic FS primary checkpoint, 9 October 2026

All 43 physical pages of arXiv:2004.11635v1 were actually read in order,
with complete selected text, 22 individual matching image displays and
sequential notes/receipts. Thirteen exact elementary diagnostic families
check signs, dimension/probability and Veronese normalization, discrete
lattice density, semiample/big scope, Fekete order, threshold atoms,
coefficient suprema, nontrivial-ground valuation typing and Q versus Q-star.
A concrete P1 norm example explains d1 equivalence with positive rescaled
operator distance and the need for usc regularization. No general A--C
proof, envelope theorem or BJ22 6.21 repair is promoted from this v1.

The {len(files)}-member authored archive contains notes, receipts,
diagnostics, immutable source/preparation records and helpers. The separate
{len(fullfiles)}-member cloud evidence archive also contains the pinned
external PDF, extracted text and matching images. Only authored evidence
is included in this repository checkpoint. Export/upload add zero credit.

The 4,659-page book, 425 core TeX inputs, bibliographies, native catalogue
and 42 atoms/twelve problems are unchanged in this source unit. General
BJ22 critical homogeneous Siu/envelopes remain OPEN and LPWZ density
UNVERIFIED. No independent-model receipt or new whole-book pass exists.
Remote publication receives a separate later verification record.
''')
readme=R/'README.md';s=readme.read_text();marker='**Latest global psh approximation primary checkpoint, 9 October 2026:**';assert s.count(marker)==1
intro='''**Latest asymptotic Fubini–Study primary checkpoint, 9 October 2026:**
the [source audit](manuscript/editorial/Reboulet_asymptotic_FS_source_review_20261009.md)
reads all 43 pages of the pinned Reboulet v1 in 22 individual matching
displays. Thirteen exact elementary diagnostic families track signed versus
absolute means, probability/Veronese normalization, semiample/big scope,
Fekete order, valuation typing and usc envelopes. A concrete P1 norm example
explains d1 equivalence without operator-norm equivalence. The
[authored evidence](manuscript/editorial/artifact_exports/20261009_Reboulet_asymptotic_FS_sources/README.md)
retains sequential notes and receipts; preparation/export/upload add zero
credit. The v1 main proofs require qualified dependencies before import.
The 4,659-page book, native editor and canonical statuses are unchanged.

''';readme.write_text(s.replace(marker,intro+marker,1))
programme=E/'second_reading_and_research_programme_20261002.md';s=programme.read_text();marker='## Latest global psh approximation source checkpoint, 9 October 2026\n';assert s.count(marker)==1
intro='''## Latest asymptotic Fubini–Study source checkpoint, 9 October 2026

The [complete primary audit](Reboulet_asymptotic_FS_source_review_20261009.md)
reads all 43 physical pages of arXiv:2004.11635v1 in order, with 22 individual
matching displays, full selected text and sequential notes/receipts. The
2020 dependency is not a newly discovered 2026 paper. Thirteen exact
diagnostic families include 5,376 supplemental rational product checks.

Main A--C are not accepted as independently complete proofs from this v1.
Discrete lattice versus diagonal density, semiample versus big/ample,
probability and original-degree Veronese scaling, Fekete order, horizontal
valuation typing over nontrivial K, Q versus Q-star, energy strictness and
non-Noetherian section comparison retain explicit qualifications. No
intended correctly typed theorem is declared false. The P1 norm example
is an explanatory instance of an already sourced d1/operator distinction,
not a promoted new general result.

The [owned archive](artifact_exports/20261009_Reboulet_asymptotic_FS_sources/README.md)
pins notes, receipts, diagnostics, helpers and records; external source
PDF/text/images stay in the cloud evidence archive. Export/upload add zero
reading credit. The 4,659-page book, all 425 core TeX inputs, bibliographies,
native editor and 42 atoms/twelve problems are unchanged. General BJ22
critical homogeneous Siu/envelopes remain OPEN and LPWZ density UNVERIFIED.
The BJ22 6.21 proof warning remains binding; no independent model receipt
or new whole-book pass is claimed.

Continue with qualified finite/graded and bounded-FS explanations through
isolated build and actual rendered seam gates. Check Chen--Maclean's
primary spectral proof and correctly typed nontrivial-ground energy
strictness before a stronger correspondence import. Periodically check
incoming author updates and push verified evidence. Cloud only; Xean
remains suspended.

''';programme.write_text(s.replace(marker,intro+marker,1))
published=[*paths.values(),*sorted(dest.iterdir()),readme,programme]
assert len(published)==9
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete primary checkpoint and byte-verified authored artifacts exported',editorial_files={str(p.relative_to(R)):dict(SHA256=sha(p),bytes=p.stat().st_size) for p in published},artifacts=artifacts,actual_primary_pages=43,actual_matching_views=22,active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],GitHub_published=False,helper_source=__file__)
record.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],files=9,owned_members=len(files),cloud_members=len(fullfiles),record_SHA256=sha(record))))
