from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/BGPS_Fubini_Study_book_integration_20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
n=int(sys.argv[1]);ch=json.loads((C/'book_release_checks_v2_20261009.json').read_text())
x=json.loads(Path(ch['manifest_path']).read_text())[n-1];assert x['number']==n
assert sha(x['path'])==x['image_SHA256'] and sha(x['selected_text_path'])==x['selected_text_SHA256']
assert sha(ch['PDF']['path'])==x['source_PDF_SHA256']==ch['PDF']['SHA256']
N=C/'book_notes_v2';note=N/f'note_{n:02d}.md';receipt=N/f'note_{n:02d}_receipt.json'
assert note.exists() and not receipt.exists() and len(note.read_text())>300
assert 'Read the complete selected text and displayed matching rendered image' in note.read_text()
previous=N/f'note_{n-1:02d}_receipt.json';now=datetime.now(timezone.utc).isoformat()
if n>1:assert previous.exists() and now>json.loads(previous.read_text())['UTC']
obj=dict(UTC=now,number=n,physical_pages=x['physical_pages'],source_PDF_SHA256=ch['PDF']['SHA256'],complete_selected_text_actually_read=True,matching_image_individually_displayed_and_reviewed=True,note_SHA256=sha(note),image_SHA256=sha(x['path']),selected_text_SHA256=sha(x['selected_text_path']),previous_receipt_SHA256=sha(previous) if n>1 else None,helper_source_SHA256=sha(__file__),whole_book_reading_claim=False,new_primary_source_reading_credit=0)
receipt.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(number=n,pages=x['physical_pages'],receipt_SHA256=sha(receipt))))
