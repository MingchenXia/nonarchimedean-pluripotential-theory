from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,re,subprocess,difflib,fitz

R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/BGPS_Fubini_Study_book_integration_20261009'
S=Path('/workspace/book-completion-drafts/BGPS-Fubini-Study-staging-v2-20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
ch=load('book_release_checks_v3_20261009.json');prep=load('book_staging_preparation_v2_20261009.json')
mp=Path(ch['manifest_path']);assert sha(mp)==ch['manifest_SHA256'];xs=json.loads(mp.read_text())
reading=C/'actual_book_reading_v2_20261009.json';audit=C/'book_mathematical_self_audit_v2_20261009.json';post=C/'book_post_render_checks_v2_20261009.json'
assert not any(p.exists() for p in [reading,audit,post])
views=[];last=None
for x in xs:
    assert not x['actually_viewed'] and not x['selected_text_read']
    n=C/'book_notes_v3'/f"note_{x['number']:02d}.md";rp=n.with_name(n.stem+'_receipt.json');a=json.loads(rp.read_text())
    assert 'Read the complete selected text and displayed matching rendered image' in n.read_text()
    assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
    assert a['number']==x['number'] and a['physical_pages']==x['physical_pages']
    assert a['source_PDF_SHA256']==ch['PDF']['SHA256'] and sha(n)==a['note_SHA256']
    assert sha(x['path'])==a['image_SHA256']==x['image_SHA256']
    assert sha(x['selected_text_path'])==a['selected_text_SHA256']==x['selected_text_SHA256']
    assert last is None or a['UTC']>last;last=a['UTC']
    y={k:v for k,v in x.items() if k not in ['actually_viewed','selected_text_read']}
    y.update(actual_complete_text_read=True,actual_matching_image_freshly_displayed=True,sequential_note_path=str(n),sequential_note_SHA256=sha(n),observation_receipt_path=str(rp),observation_receipt_SHA256=sha(rp));views.append(y)
pages=sorted({p for x in xs for p in x['physical_pages']});assert pages==ch['selected_book_physical_pages']
assert sum(len(x['physical_pages']) for x in xs)==len(pages)==ch['prepared_book_pages'] and len(views)==ch['prepared_views']
validation=load('book_validation_v2_20261009.json');assert validation['status']=='DONE' and validation['returncode']==0
checks=[dict(command=validation['command'],returncode=0,validation_SHA256=sha(C/'book_validation_v2_20261009.json'),note='Required reference/inventory checks and six existing tests already passed in this exact validation; not repeated.')]
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
for n,h in prep['other_active_TeX_preserved'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['unchanged_bibliographies'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
assert sha(ch['PDF']['path'])==ch['PDF']['SHA256']
historical={};whitespace={}
for row in prep['historical_formal_environment_counts_preserved']:
    n=row['path'];before=(R/n).read_text();after=(S/n).read_text()
    for e,count in row['environment_counts'].items():
        pat=r'\\begin\{'+e+r'\}';assert len(re.findall(pat,before))==len(re.findall(pat,after))==count
    assert re.findall(r'\\tag\{([^}]+)\}',after)==re.findall(r'\\tag\{([^}]+)\}',before)
    assert re.findall(r'\\label\{([^}]+)\}',before)==re.findall(r'\\label\{([^}]+)\}',after)
    historical[n]=row
for n in prep['after']:
    before=(R/n).read_text().splitlines();after=(S/n).read_text().splitlines()
    assert Counter(x for x in before if x!=x.rstrip())==Counter(x for x in after if x!=x.rstrip())
    added=[x[2:] for x in difflib.ndiff(before,after) if x.startswith('+ ')];assert all(x==x.rstrip() for x in added)
    run=subprocess.run(['git','diff','--no-index','--check',str(R/n),str(S/n)],text=True,capture_output=True)
    assert run.returncode in [0,1] and not(run.stdout+run.stderr).strip()
    whitespace[n]=dict(added_lines=len(added),added_trailing_whitespace=0)
for p,h in prep['draft_fragments'].items():assert sha(p)==h
under=load('book_underfull_delta_v2_20261009.json')
assert not under['added_blocks'] and not under['removed_blocks']
with fitz.open(ch['PDF']['path']) as doc:blank=[p for p in pages if not doc[p-1].get_text().strip()]
reading.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — all selected final book pages read with matching individual display',PDF=ch['PDF'],actual_unique_book_pages=len(pages),fresh_complete_text_and_individually_displayed_pages=len(pages),substantive_selected_pages=len(pages)-len(blank),explicitly_reviewed_blank_versos=blank,fresh_matching_views=len(views),reused_matching_views=0,views=views,legacy_preparation_flags_rewritten=False,remaining_repairs=[],whole_book_new_reading_claim=False,last_complete_ordered_book_pass='2026-10-04',active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
mathchecks=['The imported worked case is the degree-one Cartier divisor at infinity on P1_Q with ordinary-norm Fubini–Study at infinity and standard canonical finite models. Published Theorem 6.4/Example 6.5 were actually read in the controlling 74-page AJM PDF; no real-divisor or modified-finite-model extension is assumed.', 'The entropy roof is minus one half of x log x+(1−x)log(1−x), continuous with endpoint values zero, strictly concave on the interior and maximal at 1/2 with value log2/2. Its integral is 1/4 and arithmetic self-intersection is 1/2; strict Zhang follows from log2>1/2.', 'The torus lower bound uses all normalized extension-place weights, subtracts half the logarithm locally, and invokes the weighted product formula. Roots of unity attain the bound and give a generic sequence. The boundary points 0 and infinity have height zero, hence the absolute and essential minima are different.', 'The original smooth Chern density uses the squared-norm potential 2g with dd^c=i/(2pi)partial barpartial, giving dxdy/(pi(1+|z|²)^2). Its total mass is one, disc mass 1/2 and circle mass zero. Small generic orbit limits instead have Haar circle mass one and finite Gauss Dirac mass one, by the imported example.', 'The calculation is an explicitly attributed classical explanatory case and direct formal computation, not an original theorem. The suspect exact point-attainment converse of Proposition 5.13 and the separate real-quadratic research candidate are not used in the measure conclusion or promoted.', 'The normalization v1 record contains a mistyped supplemental Theorem 5.2 page locator; the fresh v2 addendum corrects it to physical45–47/article352–354 using earlier actual notes. Both records remain frozen. The book citation itself uses verified Theorem6.4/Example6.5 physical59–60.', 'The first final-render review stopped after twelve actual pages in six views when two provenance lines spilled onto a nearly empty page followed by a blank recto-opening verso. The fresh v2 shortens only the last provenance paragraph, preserves the chapter mathematical fragment and fixes the seam. Final thirteen pages were freshly read in seven displays; no v1 reading credit transfers.', 'All 13,382 old numbered values, 602 cited keys/labels, 2,766 contents titles/hierarchy and 900 index entries are preserved. One new BGPRS19 shorthand gives 603 citations. Two core TeX inputs and the NA bibliography change; the other 423 core TeX inputs and complex bibliography are identical. No formal environment, semantic label or manual tag is introduced.', 'Required validation and six existing tests pass, with zero errors, package/pdfTeX warnings, missing glyphs, overfull boxes, unresolved references/citations or rerun requests. All 955 inherited underfull blocks retain normalized content/multiplicity; every internal PDF destination resolves.', 'The complete 74-page source checkpoint is distinct from recursive clearance and independent-model verification. Canonical 42-atom/twelve-problem inventory and tiers(0,3,7,15,17), BJ22 Siu/envelopes OPEN, LPWZ density UNVERIFIED and the native catalogue/editor are preserved. No new whole-book reading claim is made; the last complete ordered pass remains 4 October.']

audit.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — ordinary scoped mathematical audit and actual final render clearance',checks=mathchecks,actual_final_book_reading_SHA256=sha(reading),source_input_hashes=prep['after'],draft_fragments=prep['draft_fragments'],original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
post.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — post-render references, inventory and input preservation checked',checks=checks,historical_formal_environment_counts_preserved=historical,whitespace_checks=whitespace,underfull_delta_SHA256=sha(C/'book_underfull_delta_v2_20261009.json'),actual_final_reading_SHA256=sha(reading),mathematical_audit_SHA256=sha(audit),release_checks_SHA256=sha(C/'book_release_checks_v3_20261009.json'),active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',pages=len(pages),views=len(views),blank_pages=blank,reading_SHA256=sha(reading),math_SHA256=sha(audit),post_SHA256=sha(post))))
