from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile,shutil,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory');E=R/'manuscript/editorial'
C=R/'source_material/BGPS_Fubini_Study_book_integration_20261009'
K=R/'source_material/Xue_semiabelian_review_20261009/dependencies_v1/BGPS19Published'
S=Path('/workspace/book-completion-drafts/BGPS-Fubini-Study-staging-v2-20261009')
O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
write=lambda p,a:p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
prep=load('book_staging_preparation_v2_20261009.json');release=load('book_release_checks_v3_20261009.json')
reading=load('actual_book_reading_v2_20261009.json');math=load('book_mathematical_self_audit_v2_20261009.json')
post=load('book_post_render_checks_v2_20261009.json');under=load('book_underfull_delta_v2_20261009.json')
assert reading['actual_unique_book_pages']==13 and reading['fresh_matching_views']==7 and reading['reused_matching_views']==0
assert not reading['remaining_repairs'] and reading['explicitly_reviewed_blank_versos']==[]
assert all(x['returncode']==0 for x in post['checks']) and not under['added_blocks'] and not under['removed_blocks']
assert release['PDF']['physical_pages']==4677 and release['PDF']['SHA256']==reading['PDF']['SHA256']
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['before'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
paths={k:E/f'BGPS_Fubini_Study_staged_integration_{k}_v2_20261009.{ext}' for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
full=O/'Non-Archimedean_Pluripotential_Theory_Fubini_Study_V2_2026-10-09.pdf'
review=O/'BGPS_Fubini_Study_Actual_Book_Review_V2_2026-10-09.pdf'
minimal=O/'BGPS_Fubini_Study_Minimal_Source_V2_2026-10-09.zip'
evidence=O/'BGPS_Fubini_Study_Actual_Book_Evidence_V2_2026-10-09.zip'
dest=E/'artifact_exports/20261009_BGPS_Fubini_Study_v2';record=C/'book_export_v2_20261009.json'
assert not any(p.exists() for p in [*paths.values(),full,review,minimal,evidence,dest,record])
shutil.copyfile(release['PDF']['path'],full);assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as source:
    d=fitz.open()
    for n in release['selected_book_physical_pages']:d.insert_pdf(source,from_page=n-1,to_page=n-1)
    assert len(d)==13
    d.set_metadata(dict(title='Fubini-Study curvature and arithmetic small-point limit — actual book review',subject='Thirteen final physical pages actually read in seven fresh matching displays; export grants zero reading credit.'))
    d.save(review,garbage=4,deflate=True);d.close()
summary='''The checked 4,677-page edition adds a classical Fubini–Study worked case
to Chapter 27 and its published-source provenance to Appendix L. It keeps
the standard canonical finite models, ordinary-norm height, entropy roof,
essential minimum log2/2, normalized intersection 1/4 and zero boundary
heights explicit. Complex curvature uses the squared-norm potential 2g.
The original smooth curvature and the Haar/Gauss small-point limit are
different measures. The exact published BGPS source was actually read in
all 74 physical pages and 37 matching displays; deeper imported proofs
remain outside recursive certification. No original result is promoted.

All thirteen selected final pages were actually read in seven fresh
matching displays: the worked case and chapter seams, complete new
provenance and following appendix opening, two contents pages, first/last
index pages and the complete BGPRS19 entry. The middle ten index pages
are mechanically compared, not actually reread. There are no blank versos
in this final selection. This is not a new whole-book pass; the last
complete ordered read remains 4 October. Upload adds zero reading credit.

The first staged PDF passed validation, but its review stopped after
twelve pages in six actual displays when two provenance lines spilled
onto an otherwise empty page followed by a blank verso. Fresh v2 tightens
only that last paragraph and preserves the mathematical chapter fragment.
All final v2 displays are fresh; none of the earlier reading is transferred.
A failed first page-selection helper and a corrected supplemental
Theorem 5.2 locator are preserved as distinct frozen records/addenda.
The actual book citation uses verified Theorem 6.4 and Example 6.5.

Required validation and six existing tests pass. Final output has zero
errors, package/pdfTeX warnings, missing glyphs, overfull boxes, unresolved
references/citations or rerun requests. All 955 inherited underfull blocks
retain normalized content and multiplicities. All 13,382 earlier numbered
values, 602 cited keys/labels, 2,766 contents titles/hierarchy and 900 index
entries remain; one new BGPRS19 shorthand gives 603 cited entries.
All internal destinations resolve. Two core TeX inputs and the NA
bibliography change; the other 423 core TeX inputs and complex bibliography
are identical. No formal result, semantic label or manual tag is added.

The suspect exact point-attainment converse and the separate unverified
real-quadratic candidate are not used to obtain this example's orbit limit.
The source necessity/logarithmic-test questions remain in their scopes.
Canonical inventory stays 42 atoms/twelve problems and tiers(0,3,7,15,17).
BJ22 homogeneous Siu/envelopes stay OPEN and LPWZ density UNVERIFIED.
The native catalogue/editor, current saved source and historical PDF are
preserved; native compilation remains unverified. Activation and remote
publication are separate records. Work continues in the cloud, without Xean.
'''
paths['audit'].write_text('# Fubini–Study arithmetic example integration, 9 October 2026\n\n'+summary+'\nScoped mathematical checks:\n\n'+''.join(f'{i}. {x}\n\n' for i,x in enumerate(math['checks'],1)))
paths['reading_notes'].write_text('# Actual final Fubini–Study book reading\n\nThirteen final selected pages in seven fresh displays; no whole-book credit.\n'+''.join('\n---\n\n'+Path(x['sequential_note_path']).read_text() for x in reading['views']))
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md'
intro='''**Latest checked arithmetic worked example, 9 October 2026:**
the [integration audit](manuscript/editorial/BGPS_Fubini_Study_staged_integration_audit_v2_20261009.md)
records the 4,677-page edition. Chapter 27 computes the standard Fubini–Study
entropy roof and height bound, and distinguishes smooth Chern curvature
from the Haar/Gauss small-point limit. Appendix L pins the published source
and norm conventions. All thirteen selected final pages were read in seven
fresh displays; required checks and compilation pass. Earlier numbering,
citations, contents and index are preserved. The [artifacts](manuscript/editorial/artifact_exports/20261009_BGPS_Fubini_Study_v2/README.md)
contain full PDF, actual review, minimal source and authored evidence.
The attainment candidate remains unverified; general BJ22 Siu/envelopes remain OPEN.

'''
p=S/'README.md';s=p.read_text();marker='**Latest verified adelic-equidistribution GitHub publication, 9 October 2026:**'
assert s.count(marker)==1;p.write_text(s.replace(marker,intro+marker,1))
intro='''## Checked Fubini–Study arithmetic example, 9 October 2026

The [integration audit](BGPS_Fubini_Study_staged_integration_audit_v2_20261009.md)
records the 4,677-page edition. The standard P1_Q example has essential
minimum log2/2, normalized intersection 1/4 and absolute minimum zero at
the boundary. Its original smooth curvature is distinct from the generic
small-point Haar/Gauss limit. The ordinary norm height and squared-norm
Chern convention are explicit and calibrated against the published source.

All thirteen final selected pages were actually read in seven fresh views.
The first staged review stopped after twelve pages when two appendix lines
spilled; the fresh v2 fixes that pagination and transfers no reading credit.
Required validation and six tests pass. All 13,382 old numbered values,
602 cited labels, 2,766 contents titles/hierarchy and 900 index entries remain;
one new BGPRS19 key gives 603 citations. All links resolve and 955 inherited
underfull blocks are unchanged. The last whole-book ordered read is 4 October.

See the [artifacts](artifact_exports/20261009_BGPS_Fubini_Study_v2/README.md).
Complete BGPS source evidence is separately published at
1a16af3ae42dd796d96f6465b82f0af080134777. The point-attainment candidate
has no independent production-verifier receipt and is not a book theorem.
The native catalogue/editor and canonical statuses are preserved; native
compilation remains unverified. No Siu/envelope repair or problem closure.
Continue cloud-only. Hultberg 2412.04169v1 is a related source-reading target;
its main statements are not integrated or cleared by metadata inspection.

'''
p=S/programme;s=p.read_text();first=s.index('\n');p.write_text(s[:first+1]+'\n'+intro+s[first+1:])
with zipfile.ZipFile(prep['baseline_minimal_source']['path']) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    members=old.namelist();assert len(members)==len(set(members))==472
    for n in members:z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
    assert z.testzip() is None
    for n in z.namelist():assert z.read(n)==(S/n).read_bytes()
files={f'records/{q.name}':q for q in C.glob('*.json')}
files['records/current_literature_check_v1_20261009.md']=C/'current_literature_check_v1_20261009.md'
for version,noteversion,viewversion in [(1,2,2),(2,3,3)]:
    q=C/f'book_validation_v{version}_20261009.log';files[f'logs/{q.name}']=q
    stage=Path(f'/workspace/book-completion-drafts/BGPS-Fubini-Study-staging-v{version}-20261009')
    draft=Path(f'/workspace/book-completion-drafts/BGPS-Fubini-Study-integration-v{version}-20261009')
    for rel in prep['after']:files[f'staged_inputs/v{version}/{rel}']=stage/rel
    for q in draft.iterdir():files[f'drafts/v{version}/{q.name}']=q
    for q in (C/f'book_compiled_staged_v{version}').iterdir():
        if q.suffix!='.pdf':files[f'compiled/v{version}/{q.name}']=q
    for rp in (C/f'book_notes_v{noteversion}').glob('*_receipt.json'):
        a=json.loads(rp.read_text());n=a['number'];w=Path(f'/tmp/BGPS_Fubini_Study_staged_book_views_v{viewversion}_20261009')
        for kind,q in [('notes',rp.with_name(rp.name.replace('_receipt.json','.md'))),('receipts',rp),('images',w/f'sheet_{n:02d}.png'),('text',w/f'sheet_{n:02d}.txt')]:files[f'actual_v{version}/{kind}/{q.name}']=q
    files[f'actual_v{version}/prepared_manifest.json']=Path(load(f'book_release_checks_v{viewversion}_20261009.json')['manifest_path'])
for q in Path('/tmp').glob('BGPS_Fubini_Study_*_v*_20261009.py'):files[f'helpers/{q.name}']=q
for q in [paths['audit'],paths['reading_notes'],S/programme,S/'README.md']:files[f'editorial/{q.name}']=q
sourcezip=E/'artifact_exports/20261009_BGPS_toric_complete_v3/BGPS_Toric_Complete_Actual_Reading_Evidence_V3_2026-10-09.zip'
assert sha(sourcezip)=='4e21bd45f950bc794daa17da3ad8cb7b747624ac9853b0eb16e7f934c5d4bf19'
files[f'source_owned_records/{sourcezip.name}']=sourcezip
for n in ['actual_source_checkpoint_v3_20261009.json','GitHub_complete_publication_v3_20261009.json','GitHub_complete_documentation_v3_20261009.json']:files['source_owned_records/'+n]=K/n
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(files) and z.testzip() is None
    for n,q in files.items():assert z.read(n)==q.read_bytes()
artifacts={k:dict(path=str(q),bytes=q.stat().st_size,SHA256=sha(q)) for k,q in [('full_book_PDF',full),('selected_review_PDF',review),('minimal_TeX_source_archive',minimal),('actual_book_evidence_archive',evidence)]}
artifacts['full_book_PDF']['physical_pages']=4677;artifacts['selected_review_PDF']['physical_pages']=13
artifacts['minimal_TeX_source_archive']['members']=472;artifacts['actual_book_evidence_archive']['members']=len(files)
progress={n:sha(S/n) for n in ['README.md',programme]}
write(paths['manifest'],dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — scoped mathematical/mechanical/actual-final-render gate',preparation=prep,release=release,actual_reading=reading,mathematical_audit=math,post_render=post,underfull_comparison=under,artifacts=artifacts,active_book_changed=False,GitHub_published=False))
write(paths['artifacts'],dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — all export members byte-verified',artifacts=artifacts,actual_final_book_pages=13,fresh_matching_views=7,explicitly_reviewed_blank_versos=[],reading_credit_from_export=0,GitHub_published=False))
dest.mkdir(parents=True)
for q in [full,review,minimal,evidence]:shutil.copyfile(q,dest/q.name);assert sha(dest/q.name)==sha(q)
(dest/'SHA256SUMS').write_text(''.join(sha(q)+'  '+q.name+'\n' for q in [full,review,minimal,evidence]))
(dest/'README.md').write_text('# Fubini–Study arithmetic example book artifacts\n\n'+summary+f'\nArtifacts: full 4,677-page PDF, 13-page actual review, 472-member minimal\nsource and {len(files)}-member byte-verified authored evidence. Primary PDFs\nand full primary-source images/text are excluded from redistribution.\n')
editorial={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in paths.values()}
for p in dest.iterdir():editorial[str(p.relative_to(R))]=dict(bytes=p.stat().st_size,SHA256=sha(p))
write(record,dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — final worked-example book/evidence export',artifacts=artifacts,editorial_files=editorial,progress_document_hashes=progress,actual_final_book_pages=13,actual_final_matching_views=7,reused_matching_views=0,explicitly_reviewed_blank_versos=[],active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)))
print(json.dumps(dict(status='EXPORTED',record_SHA256=sha(record),evidence_members=len(files),artifacts=artifacts)))
