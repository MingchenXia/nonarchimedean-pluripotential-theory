from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,shutil,subprocess,zipfile
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BGPS_Fubini_Study_book_integration_20261009'
K=R/'source_material/Xue_semiabelian_review_20261009/dependencies_v1/BGPS19Published'
B=Path('/workspace/book-completion-drafts/Ballay-Sombra-published-staging-v2-20261009')
S=Path('/workspace/book-completion-drafts/BGPS-Fubini-Study-staging-v1-20261009')
D=Path('/workspace/book-completion-drafts/BGPS-Fubini-Study-integration-v1-20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=C/'book_staging_preparation_v1_20261009.json';assert not S.exists() and not out.exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head=='b6185ee826be63d1780aefad782639f544b041c0'
cal=C/'normalization_calibration_v1_20261009.json';add=C/'normalization_calibration_locator_addendum_v2_20261009.json'
assert json.loads(add.read_text())['prior_calibration_SHA256']==sha(cal)
publication=K/'GitHub_complete_documentation_v3_20261009.json'
assert json.loads(publication.read_text())['commit']==head
assert sha(R/'manuscript/book.pdf')==sha(B/'manuscript/book.pdf')=='2c90129c35506ac72005c5189ff235b0e1bd52f5b529ef44e5fc58bf7dbfcfe8'
export=json.loads((R/'source_material/Ballay_Sombra_adelic_equdistribution_published_review_20261009/book_export_v3_20261009.json').read_text())
minimal=export['artifacts']['minimal_TeX_source_archive'];archive=Path(minimal['path'])
assert sha(archive)==minimal['SHA256']
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==472
    for n in z.namelist():assert not Path(n).is_absolute() and '..' not in Path(n).parts
    S.mkdir();z.extractall(S)
for n in ['README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']:shutil.copyfile(R/n,S/n)
alltex={str(p.relative_to(S)):sha(p) for p in (S/'manuscript').rglob('*.tex')}
assert len(alltex)==425
for n,h in alltex.items():assert sha(R/n)==sha(B/n)==h
changed=['manuscript/parts/part3/ch27_differentiability.tex','manuscript/appendices/appL_provenance.tex','manuscript/bibliography/NonArchimedean.bib']
before={n:sha(R/n) for n in changed}
for n in changed:assert sha(S/n)==sha(R/n)==sha(B/n)
for p in D.iterdir():assert all(line==line.rstrip() for line in p.read_text().splitlines())
p=S/changed[0];s=p.read_text();marker='\\paragraph{The remaining directions.}'
assert s.count(marker)==1
p.write_text(s.replace(marker,(D/'ch27_fubini_study_fragment.tex').read_text().rstrip()+'\n\n'+marker,1))
p=S/changed[1];p.write_text(p.read_text().rstrip()+'\n\n'+(D/'appL_fubini_study_fragment.tex').read_text().rstrip()+'\n')
p=S/changed[2];s=p.read_text();assert 'BGPRS19Published' not in s
p.write_text(s.rstrip()+r'''

@article{BGPRS19Published,
  author = {Burgos Gil, Jos{\'e} Ignacio and Philippon, Patrice and Rivera-Letelier, Juan and Sombra, Mart{\'i}n},
  title = {The distribution of {Galois} orbits of points of small height in toric varieties},
  journal = {American Journal of Mathematics},
  volume = {141},
  number = {2},
  pages = {309--381},
  year = {2019},
  doi = {10.1353/ajm.2019.0007},
  url = {https://doi.org/10.1353/ajm.2019.0007},
  shorthand = {BGPRS19}
}
''')
checks=[]
for n in changed[:2]:
    old=(R/n).read_text();new=(S/n).read_text();counts={}
    for e in ['theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important']:
        pattern=r'\\begin\{'+e+r'\}';counts[e]=len(re.findall(pattern,old))
        assert counts[e]==len(re.findall(pattern,new))
    assert re.findall(r'\\tag\{([^}]+)\}',old)==re.findall(r'\\tag\{([^}]+)\}',new)
    assert re.findall(r'\\label\{([^}]+)\}',old)==re.findall(r'\\label\{([^}]+)\}',new)
    checks.append(dict(path=n,environment_counts=counts))
unchanged={n:h for n,h in alltex.items() if n not in changed};assert len(unchanged)==423
for n,h in unchanged.items():assert sha(R/n)==sha(S/n)==h
native={str(p.relative_to(R)):sha(p) for p in [R/'output/open_problems_catalogue_2026-10-03.tex',R/'output/open_problems_catalogue_2026-10-03.pdf']}
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='PREPARED — classical Fubini–Study worked case; active book unchanged',stage_path=str(S),baseline_stage_path=str(B),baseline_compiled_snapshot=str(R/'source_material/Ballay_Sombra_adelic_equdistribution_published_review_20261009/book_compiled_staged_v2'),baseline_commit=head,baseline_minimal_source=minimal,draft_path=str(D),before=before,after={n:sha(S/n) for n in changed},draft_fragments={str(p):sha(p) for p in sorted(D.iterdir())},active_inputs_preserved=before,other_active_TeX_preserved=unchanged,other_active_TeX_count=423,unchanged_bibliographies={'manuscript/bibliography/ComplexGeometry.bib':sha(R/'manuscript/bibliography/ComplexGeometry.bib')},historical_formal_environment_counts_preserved=checks,active_book_PDF_SHA256=sha(R/'manuscript/book.pdf'),native_catalogue_preserved=native,source_checkpoint_SHA256=sha(K/'actual_source_checkpoint_v3_20261009.json'),source_publication_SHA256=sha(K/'GitHub_complete_publication_v3_20261009.json'),normalization_calibration_SHA256=sha(cal),calibration_locator_addendum_SHA256=sha(add),new_bibliographic_keys=['BGPRS19Published'],new_semantic_labels=[],new_toc_titles=[],new_formal_environments=0,original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],active_book_changed=False,GitHub_published=False,actual_book_reading_credit=0,helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='PREPARED',record_SHA256=sha(out),unchanged_TeX=423,changed_files=3)))
