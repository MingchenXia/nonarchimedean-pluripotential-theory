from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BGPS_Fubini_Study_book_integration_20261009'
K=R/'source_material/Xue_semiabelian_review_20261009/dependencies_v1/BGPS19Published'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prior=C/'normalization_calibration_v1_20261009.json'
out=C/'normalization_calibration_locator_addendum_v2_20261009.json';assert not out.exists()
record=dict(UTC=datetime.now(timezone.utc).isoformat(),status='CORRECTED LOCATOR ADDENDUM — earlier calibration record preserved',prior_calibration_SHA256=sha(prior),correction='Theorem 5.2 statement and full printed proof are on physical pages 45–47, article pages 352–354; not physical 44–45 as typed in v1.',controlling_prior_actual_notes=[dict(path=str(K/'primary_notes_v1'/n),SHA256=sha(K/'primary_notes_v1'/n)) for n in ['note_02.md','note_03.md']],corrected_locators=['Theorem 6.4 and full printed proof, physical 59–60 / article 366–367','Example 6.5, physical 60 / article 367','Theorem 5.2 statement and full printed proof, physical 45–47 / article 352–354'],normalization_results_changed=False,new_actual_reading_credit=0,book_changed=False,original_result_promoted=False,independent_verifier_receipt=False,helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='LOCATOR CORRECTED',addendum_SHA256=sha(out))))
