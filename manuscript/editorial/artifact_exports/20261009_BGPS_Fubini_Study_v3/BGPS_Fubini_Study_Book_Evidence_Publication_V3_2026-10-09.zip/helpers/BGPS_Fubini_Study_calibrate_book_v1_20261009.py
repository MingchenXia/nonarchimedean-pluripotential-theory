from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sympy as s
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BGPS_Fubini_Study_book_integration_20261009'
K=R/'source_material/Xue_semiabelian_review_20261009/dependencies_v1/BGPS19Published'
D=Path('/workspace/book-completion-drafts/BGPS-Fubini-Study-integration-v1-20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=C/'normalization_calibration_v1_20261009.json';assert not C.exists();C.mkdir()
x=s.symbols('x',positive=True);r=s.symbols('r',positive=True);z,b=s.symbols('z b')
roof=-(x*s.log(x)+(1-x)*s.log(1-x))/2
integral=s.integrate(roof,(x,0,1));maximum=s.simplify(roof.subs(x,s.Rational(1,2)))
derivative=s.simplify(s.diff(roof,x));hessian=s.simplify(s.diff(roof,x,2))
endpoint0=s.limit(roof,x,0,dir='+');endpoint1=s.limit(roof,x,1,dir='-')
chern=s.simplify(s.diff(s.log(1+z*b),z,b))
disc_mass=s.integrate(2*r/(1+r*r)**2,(r,0,1));total_mass=s.integrate(2*r/(1+r*r)**2,(r,0,s.oo))
height_identity=s.factor((1+r*r)/r-2)
assert integral==s.Rational(1,4) and maximum==s.log(2)/2
assert s.simplify(hessian+1/(2*x*(1-x)))==0
assert endpoint0==endpoint1==0 and chern==1/(1+z*b)**2
assert disc_mass==s.Rational(1,2) and total_mass==1
assert s.simplify(height_identity-(r-1)**2/r)==0
pub=K/'GitHub_complete_publication_v3_20261009.json'
d=json.loads(pub.read_text());assert d['actual_BGPS_pages']==74 and d['BGPS_matching_views']==37 and d['whole_source_read']
cp=K/'actual_source_checkpoint_v3_20261009.json';q=json.loads(cp.read_text())
assert q['actual_pages']==list(range(1,75)) and not q['production_VERIFIED']
record=dict(UTC=datetime.now(timezone.utc).isoformat(),status='PASS — classical explanatory example normalization; no original theorem',source_publication_SHA256=sha(pub),source_checkpoint_SHA256=sha(cp),actual_source_pages=74,actual_matching_views=37,actual_locators=['Theorem 6.4 and full printed proof, physical 59–60','Example 6.5, physical 60','Theorem 5.2 and full printed proof, physical 44–45'],draft_fragments={p.name:sha(p) for p in sorted(D.iterdir())},metric='O(1) on P1_Q, ordinary-norm Fubini–Study at infinity; standard canonical finite models',roof=str(roof),roof_integral=str(integral),roof_maximum=str(maximum),roof_derivative=str(derivative),roof_Hessian=str(hessian),endpoint_values=[str(endpoint0),str(endpoint1)],Chern_complex_coefficient=str(chern),Chern_operator='i/(2 pi) partial barpartial on the squared-norm potential 2g',unit_disc_mass=str(disc_mass),total_Chern_mass=str(total_mass),height_inequality_identity=str(height_identity),strict_Zhang_check='log(2)=integral_1^2 dt/t > 1/2, hence log(2)/2 > 1/4',torus_height_lower_bound='weighted product formula with archimedean g−(1/2)log|alpha|≥(1/2)log2 and finite g−(1/2)log|alpha|≥0',roots_of_unity='height exactly log2/2 and generic on P1',boundary_points='0 and infinity height zero; absolute minimum zero, distinct from essential minimum',full_limit='published Example 6.5: probability unit-circle Haar at infinity and unit-Gauss Dirac at finite places',circle_mass_original_curvature=0,circle_mass_small_point_limit=1,candidate_attainment_clause_used=False,recursive_primary_inputs_certified=False,original_result_promoted=False,independent_verifier_receipt=False,book_changed=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='PASS',calibration_SHA256=sha(out),roof_integral=str(integral),essential_minimum=str(maximum),Chern_total_mass=str(total_mass))))
