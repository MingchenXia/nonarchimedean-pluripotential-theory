# Actual final Fubini–Study book review — view 3

Physical pages 1851–1852. Read the complete selected text and displayed matching rendered image.

The complete new worked case is readable and mathematically consistent. The ordinary-norm Green function has factor 1/2; the entropy roof has endpoints zero and maximum log2/2 at 1/2. Its integral is 1/4, so the Zhang lower bound is strict. The direct height argument subtracts half the local logarithm, uses the weighted product formula and identifies roots-of-unity attainments on the torus; the two compactification boundary heights are explicitly zero and kept separate from the essential minimum.

The all-generic-small limit is explicitly attributed to published Theorem 6.4/Example 6.5 with canonical finite models. Curvature uses the squared-norm potential 2g and the J.4 complex operator, yielding the probability density dx dy/(pi(1+|z|²)²). Its circle mass zero and disc mass 1/2 contrast correctly with Haar circle mass one. All equations, the BGPRS19 reference and J.4 link are visible, without clipping or abnormal spacing.

The continuation preserves Ballaÿ–Sombra's necessity question and extra logarithmic-test equality/stabilization hypotheses. The transition to the original BFJ and complex-source notes is coherent. The scoped example settles neither those questions nor homogeneous Siu. These are four selected chapter pages across views 2–3, not a whole-chapter or whole-book reread.
