# Targeted current-literature check — 9 October 2026

Searches were made through the web research tool, followed by direct inspection of the arXiv abstract/submission-history pages. This is a targeted metadata check, not an exhaustive literature survey or actual PDF-reading credit.

- https://arxiv.org/abs/2608.08262 currently displays Xue's v2, submitted 30 August 2026 at 13:21:05 UTC. No later version appears in that page's submission history. The already audited exact 83-physical-page PDF remains the controlling file; the abstract page's “82 pages” comment is not substituted for its actual PDF count.
- https://arxiv.org/abs/1509.01011 displays only the 3 September 2015 v1. That preprint is not substituted for the fully read 2019 published PDF. Absence of a new arXiv version is not proof of absence of an erratum elsewhere.
- https://arxiv.org/abs/2412.04169 displays Hultberg's *Arakelov geometry of toric bundles: Okounkov bodies and BKK*, v1, 5 December 2024 at 14:05:42 UTC, with a 42-page comment. Its stated intersection/height applications to semiabelian compactifications are directly related to the mixed-degree and toric-bundle inputs in the source audit. It is a next primary-source reading target, not a cleared new book input.

Queries included strict toric/non-Archimedean equidistribution, monocritical metrics, current non-Archimedean pluripotential papers, logarithmic toric equidistribution, and Hultberg's toric-bundle work. The relevant results retrieved in this limited search were BGPS, Xue, Ballaÿ–Sombra and Hultberg. Unrelated uses of “toric” were excluded. This search does not establish that Remark 5.9 of BGPS is still open in 2026, nor does it establish that the point-attainment candidate is novel or verified. Existing canonical statuses are unchanged.

The GitHub publication helper separately checked main at 00957114db21b627e97369563032ceda9cea09c7 during the complete-source push. That head matches the prior check; no new main-branch research increment appeared in this comparison. This is not a claim about all unmerged remote branches or comments.
