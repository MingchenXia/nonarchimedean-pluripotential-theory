from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,zipfile,subprocess
R=Path('/workspace/nonarchimedean-pluripotential-theory');E=R/'manuscript/editorial'
C=R/'source_material/BGPS_Fubini_Study_book_integration_20261009'
S=Path('/workspace/book-completion-drafts/BGPS-Fubini-Study-staging-v2-20261009')
K=R/'source_material/Xue_semiabelian_review_20261009/dependencies_v1/BGPS19Published'
J=E/'BGPS_Fubini_Study_cloud_activation_v2_20261009.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
prep=load('book_staging_preparation_v2_20261009.json');export=load('book_export_v2_20261009.json')
reading=load('actual_book_reading_v2_20261009.json');release=load('book_release_checks_v3_20261009.json')
post=load('book_post_render_checks_v2_20261009.json');math=load('book_mathematical_self_audit_v2_20261009.json')
pins={q.name:sha(q) for q in C.glob('*.json')};assert not J.exists()
assert reading['actual_unique_book_pages']==13 and reading['fresh_matching_views']==7 and reading['reused_matching_views']==0
assert not reading['remaining_repairs'] and not reading['explicitly_reviewed_blank_versos']
assert release['PDF']['SHA256']==reading['PDF']['SHA256']==export['artifacts']['full_book_PDF']['SHA256']
assert math['actual_final_book_reading_SHA256']==sha(C/'actual_book_reading_v2_20261009.json')
assert all(x['returncode']==0 for x in post['checks'])
for n,h in prep['before'].items():assert sha(R/n)==h
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['other_active_TeX_preserved'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['unchanged_bibliographies'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
for n,row in export['editorial_files'].items():assert sha(R/n)==row['SHA256'] and (R/n).stat().st_size==row['bytes']
changes=dict(prep['after'],**export['progress_document_hashes']);assert len(changes)==5
for n,h in changes.items():
    assert sha(S/n)==h
    q=subprocess.run(['git','diff','--no-index','--check',str(R/n),str(S/n)],text=True,capture_output=True)
    assert q.returncode in [0,1] and not(q.stdout+q.stderr).strip()
pdf=Path(reading['PDF']['path']);assert sha(pdf)==reading['PDF']['SHA256']
archive=Path(export['artifacts']['minimal_TeX_source_archive']['path'])
assert sha(archive)==export['artifacts']['minimal_TeX_source_archive']['SHA256']
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==472
    for n in z.namelist():
        assert (S/n).read_bytes()==z.read(n)
        if n not in changes:assert (R/n).read_bytes()==z.read(n)
repo='MingchenXia/nonarchimedean-pluripotential-theory'
api=lambda ep:json.loads(subprocess.check_output(['gh','api',ep],cwd=R,text=True))
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
w=api(f'repos/{repo}/git/ref/heads/work')['object']['sha'];m=api(f'repos/{repo}/git/ref/heads/main')['object']['sha'];pr=api(f'repos/{repo}/pulls/2')
assert head==w==prep['baseline_commit']=='b6185ee826be63d1780aefad782639f544b041c0'
assert m=='00957114db21b627e97369563032ceda9cea09c7'
assert pr['state']=='open' and pr['draft'] and pr['head']['sha']==head
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).strip()
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).strip()
before={n:sha(R/n) for n in changes}
for n,h in changes.items():
    target=R/n;tmp=target.with_name(target.name+'.Fubini-Study-activation-tmp');assert not tmp.exists()
    shutil.copyfile(S/n,tmp);assert sha(tmp)==h;os.replace(tmp,target)
target=R/'manuscript/book.pdf';tmp=target.with_name(target.name+'.Fubini-Study-activation-tmp');assert not tmp.exists()
shutil.copyfile(pdf,tmp);assert sha(tmp)==reading['PDF']['SHA256'];os.replace(tmp,target)
with zipfile.ZipFile(archive) as z:
    for n in z.namelist():assert (R/n).read_bytes()==z.read(n)
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h
for n,h in pins.items():assert sha(C/n)==h
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — checked classical example sources and final PDF activated in cloud',before_source_hashes=before,after_source_hashes={n:sha(R/n) for n in changes},before_book_PDF_SHA256=prep['active_book_PDF_SHA256'],active_PDF=dict(path=str(target),bytes=target.stat().st_size,SHA256=sha(target),physical_pages=4677),validation_record_hashes=pins,minimal_source_members_byte_verified_against_active_tree=472,actual_selected_book_pages=13,fresh_matching_views=7,reused_matching_views=0,selected_blank_versos=[],author_update_check=dict(work=w,main=m,PR2_open_draft=True),validation=release['build_checks'],underfull_diagnostics='All 955 inherited; normalized content/multiplicities identical',bibliography=release['bibliography'],preserved_numbered_values=13382,other_TeX_inputs_preserved=423,historical_formal_counts_and_manual_tags_preserved=prep['historical_formal_environment_counts_preserved'],superseded_versions_and_partial_actual_reading_frozen=True,source_publication_SHA256=sha(K/'GitHub_complete_publication_v3_20261009.json'),source_checkpoint_SHA256=sha(K/'actual_source_checkpoint_v3_20261009.json'),open_problem_inventory='42 atoms, 12 problems, tiers (0,3,7,15,17); unchanged',general_homogeneous_Siu_and_envelopes='OPEN',LPWZ_density='UNVERIFIED',native_catalogue_preserved=prep['native_catalogue_preserved'],native_editor_changed=False,native_compile_success_verified=False,whole_book_new_reading_claim=False,original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],active_book_changed=True,GitHub_published=False,helper_source=__file__,helper_SHA256=sha(__file__))
J.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='ACTIVATED',record_SHA256=sha(J),active_PDF_SHA256=sha(target),pages=4677)))
