from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,subprocess,base64
R=Path('/workspace/nonarchimedean-pluripotential-theory');E=R/'manuscript/editorial'
C=R/'source_material/BGPS_Fubini_Study_book_integration_20261009'
K=R/'source_material/Xue_semiabelian_review_20261009/dependencies_v1/BGPS19Published'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();now=lambda:datetime.now(timezone.utc).isoformat()
repo='repos/MingchenXia/nonarchimedean-pluripotential-theory/'
api=lambda ep:json.loads(subprocess.run(['gh','api',repo+ep],cwd=R,text=True,capture_output=True,check=True).stdout)
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def commit_owned(files,message,parent,record_name):
    paths=[x['path'] for x in files];assert len(paths)==len(set(paths))
    for x in files:assert sha(R/x['path'])==x['SHA256'] and (R/x['path']).stat().st_size==x['bytes']
    assert git('rev-parse','HEAD')==parent and not git('diff','--cached','--name-only')
    subprocess.run(['git','add','--',*paths],cwd=R,check=True)
    assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
    subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
    subprocess.run(['git','commit','-m',message],cwd=R,check=True)
    head=git('rev-parse','HEAD');assert set(git('diff-tree','--no-commit-id','--name-only','-r',head).splitlines())==set(paths)
    out=C/record_name;assert not out.exists()
    out.write_text(json.dumps(dict(UTC=now(),status='COMMITTED LOCALLY — remote verification pending',commit=head,parent=parent,files=files,helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
    return head
def push_verify(head,files):
    subprocess.run(['git','-c','credential.helper=!gh auth git-credential','push','origin','work'],cwd=R,check=True)
    assert api('branches/work')['commit']['sha']==head
    tree=api('git/trees/'+head+'?recursive=1');assert not tree['truncated']
    mapping={x['path']:x for x in tree['tree'] if x['type']=='blob'}
    def check(x):
        p=R/x['path'];blob=mapping[x['path']]['sha']
        assert blob==git('hash-object',str(p)) and mapping[x['path']]['size']==x['bytes']
        d=api('git/blobs/'+blob);assert d['encoding']=='base64'
        payload=base64.b64decode(d['content'])
        assert payload==p.read_bytes() and len(payload)==x['bytes'] and hashlib.sha256(payload).hexdigest()==x['SHA256']
        return dict(**x,remote_Git_blob_SHA1=blob,remote_blob_payload_byte_verified=True)
    with ThreadPoolExecutor(max_workers=4) as pool:return list(pool.map(check,files))

activation=E/'BGPS_Fubini_Study_cloud_activation_v2_20261009.json'
a=json.loads(activation.read_text());e=json.loads((C/'book_export_v2_20261009.json').read_text())
owned=dict(a['after_source_hashes']);owned.update({n:x['SHA256'] for n,x in e['editorial_files'].items()})
owned[str(activation.relative_to(R))]=sha(activation);assert len(owned)==16
assert set(git('diff','--name-only').splitlines())==set(a['after_source_hashes'])
files=[dict(path=n,SHA256=h,bytes=(R/n).stat().st_size) for n,h in owned.items()]
head=commit_owned(files,'Explain Fubini–Study curvature and arithmetic small-point limit',a['author_update_check']['work'],'local_book_commit_v2_20261009.json')
verified=push_verify(head,files);main=api('branches/main')['commit']['sha'];pr=api('pulls/2')
assert pr['state']=='open' and pr['draft'] and pr['head']['sha']==head
oldbody=Path('/tmp/BGPS_complete_PR2_body_v3_20261009.md').read_text();assert pr['body']==oldbody
title='Complete book second reading and checked research integrations through 4,677 pages'
body='''The completed editorial second draft now has **4,677 pages**. The book
keeps the local, global, homogeneous and complex comparison theories'
hypotheses and normalizations explicit. The ordered whole-book reading was
completed on 4 October; later integrations have scoped final-page readings.

### Checked book integrations

Chapter 27 now uses the standard Fubini–Study P1_Q example to distinguish
the arithmetic small-point Haar/Gauss limit from the original smooth
Chern curvature. It computes the entropy roof, essential minimum log2/2,
normalized self-intersection 1/4 and zero boundary heights, with ordinary
norm heights and squared-norm curvature kept separate. Appendix L pins
the published source and canonical finite-model hypothesis.

The same chapter retains the published Ballaÿ–Sombra approximation
criterion and strict-Zhang quadratic roof after reading all 99 source
pages. Necessity and weaker logarithmic-test questions preserve their
additional hypotheses. Other integrations retain Qin's fixed-exponent
loss and open sharp intermediate-degree question, maximal-ray/extension
scope, and distinctions between raw FS, norm and comparison constructions.

The canonical inventory is **42 atoms in twelve formal problems**, tiers
(0,3,7,15,17). BJ22 homogeneous Siu/general envelopes remain OPEN and
LPWZ density UNVERIFIED. The warning about BJ22 Theorem 6.21 is preserved.
No original theorem, new independent-model receipt or general repair is claimed.

### Complete primary-source audits

Read all **74 physical pages** of published BGPS in 37 matching complete-
text/image displays. Its exact point-attainment converse is audited
separately from geometric Bogomolov and equidistribution. A real-quadratic
adversarial candidate remains unverified and outside book theorem
typography; the Fubini–Study example does not use that converse.
The 105-member authored source evidence also preserves weighted-capacity,
neighborhood-estimate and approximation-versus-attainment diagnostics.

Read all **83 physical pages** of Xue arXiv:2608.08262v2 in 42 matching
displays. Three known-model calibrations identify literal auxiliary
inconsistencies; the intended main theorems remain UNVERIFIED and
unintegrated. Separately read all 55 published Kühne pages, all 21 FRSS
arXiv v2 pages and five selected Maillot pages with Theorem 4.6.1's full
proof. Formal base points, period norms, finite stabilizers, common
defining fields, corner domains and genuine multiplication degrees retain
their checked scope. Complete reading does not recursively clear imports.

### Validation and artifacts

Required validation, six existing reference-check tests and final checks
pass. All 13,382 earlier numbered values, 602 earlier cited keys/labels,
2,766 contents titles/hierarchy and 900 index entries remain. The new
BGPRS19 shorthand gives 603 citations. Every internal destination resolves;
all 955 inherited underfull diagnostics are unchanged, with zero errors,
missing glyphs, overfull boxes or unresolved references.

All thirteen selected final pages were actually read in seven fresh
matching displays. Publish the full 4,677-page book, thirteen-page actual
review, 472-member minimal source and 123-member byte-verified book
evidence. Prior source/checkpoint/failed-helper records remain frozen.
Export/upload grants no reading credit or proof clearance.

The existing LaTeX open-problem catalogue contains the full arithmetic
source questions; its twelve original problem bodies and 42 canonical
atoms are preserved. Native compilation is unverified after three calls
returned no diagnostics. The same editor, saved source and historical PDF
remain preserved. This PR stays a draft for continuing source checking,
book polishing and related research.
'''
bp=Path('/tmp/BGPS_Fubini_Study_PR2_body_v2_20261009.md');payload=Path('/tmp/BGPS_Fubini_Study_PR2_payload_v2_20261009.json')
assert not bp.exists() and not payload.exists();bp.write_text(body)
payload.write_text(json.dumps(dict(title=title,body=body),ensure_ascii=False)+'\n')
updated=json.loads(subprocess.run(['gh','api','--method','PATCH',repo+'pulls/2','--input',str(payload)],cwd=R,text=True,capture_output=True,check=True).stdout)
assert updated['body']==body and updated['title']==title and updated['head']['sha']==head and updated['state']=='open' and updated['draft']
obj=dict(UTC=now(),status='REMOTE BYTE VERIFIED — all sixteen book/source/progress/audit/artifact blobs and exact draft PR',commit=head,main_head_at_check=main,files=verified,active_book_PDF=a['active_PDF'],actual_selected_book_pages=13,fresh_matching_views=7,reused_matching_views=0,evidence_members=123,minimal_source_members=472,original_source_publication=dict(path=str(K/'GitHub_complete_publication_v3_20261009.json'),SHA256=sha(K/'GitHub_complete_publication_v3_20261009.json'),commit='1a16af3ae42dd796d96f6465b82f0af080134777'),PR2=dict(URL=pr['html_url'],title=title,body_SHA256=hashlib.sha256(body.encode()).hexdigest(),head=head,open=True,draft=True),user_evidence_upload_authorized=True,original_results_promoted=[],independent_model_receipt=None,general_BJ22_Siu_envelopes='OPEN',LPWZ_density='UNVERIFIED',native_editor_changed=False,native_compile_success_verified=False,native_catalogue_preserved=a['native_catalogue_preserved'],reading_credit_from_upload=0,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__))
out=C/'GitHub_book_publication_v2_20261009.json';pub=E/'BGPS_Fubini_Study_GitHub_publication_v2_20261009.json'
assert not out.exists() and not pub.exists();out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');pub.write_bytes(out.read_bytes())
p=R/'README.md';s=p.read_text();marker='**Latest checked arithmetic worked example, 9 October 2026:**';assert s.count(marker)==1
intro='''**Latest verified arithmetic-example GitHub publication, 9 October 2026:**
the 4,677-page book and [artifacts](manuscript/editorial/artifact_exports/20261009_BGPS_Fubini_Study_v2/README.md)
are published on work at `'''+head+'''`. All sixteen remote blobs were
downloaded and verified byte-for-byte against local hashes and sizes.
The [publication record](manuscript/editorial/BGPS_Fubini_Study_GitHub_publication_v2_20261009.json)
pins the complete published BGPS source checkpoint and thirteen final pages
read in seven fresh views. The attainment candidate remains unverified;
general BJ22 Siu/envelopes stay OPEN and the native editor is preserved.

'''
p.write_text(s.replace(marker,intro+marker,1))
p=E/'second_reading_and_research_programme_20261002.md'
p.write_text(p.read_text().rstrip()+'\n\nThe sixteen checked arithmetic-example book/source/progress/audit/artifact\nblobs were downloaded from GitHub and verified byte-for-byte at `'+head+'`.\nSee the [publication record](BGPS_Fubini_Study_GitHub_publication_v2_20261009.json).\nUpload adds no reading credit or theorem clearance.\n')
docs=[dict(path=str(p.relative_to(R)),SHA256=sha(p),bytes=p.stat().st_size) for p in [pub,R/'README.md',E/'second_reading_and_research_programme_20261002.md']]
dochead=commit_owned(docs,'Document verified Fubini–Study book and evidence publication',head,'local_documentation_commit_v2_20261009.json')
docfiles=push_verify(dochead,docs);latest=api('pulls/2')
assert latest['head']['sha']==dochead and latest['body']==body and latest['title']==title and latest['state']=='open' and latest['draft']
rec=C/'GitHub_documentation_v2_20261009.json';assert not rec.exists()
rec.write_text(json.dumps(dict(UTC=now(),status='REMOTE BYTE VERIFIED — all three documentation files and exact draft PR',commit=dochead,parent=head,files=docfiles,PR2=dict(URL=latest['html_url'],head=dochead,title=title,body_SHA256=hashlib.sha256(body.encode()).hexdigest(),open=True,draft=True),book_PDF_SHA256=a['active_PDF']['SHA256'],book_pages=4677,new_reading_credit=0,original_results_promoted=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(book_commit=head,book_files_byte_verified=16,documentation_commit=dochead,documentation_files_byte_verified=3,main_head=main,publication_SHA256=sha(pub),documentation_record_SHA256=sha(rec))))
