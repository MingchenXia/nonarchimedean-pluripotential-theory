from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,shutil,zipfile
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/BGPS_Fubini_Study_book_integration_20261009';E=R/'manuscript/editorial';O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
stamp=lambda:datetime.now(timezone.utc).isoformat()
write=lambda p,a:p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
oldact=E/'BGPS_Fubini_Study_cloud_activation_v2_20261009.json';a=json.loads(oldact.read_text());oldexp=C/'book_export_v2_20261009.json';x=json.loads(oldexp.read_text())
assert git('rev-parse','HEAD')==a['author_update_check']['work']=='b6185ee826be63d1780aefad782639f544b041c0'
oldfiles=dict(a['after_source_hashes']);oldfiles.update({n:r['SHA256'] for n,r in x['editorial_files'].items()});oldfiles[str(oldact.relative_to(R))]=sha(oldact)
assert len(oldfiles)==16 and sorted(git('diff','--cached','--name-only').splitlines())==sorted(oldfiles)
for n,h in oldfiles.items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==a['active_PDF']['SHA256']
for n,h in a['native_catalogue_preserved'].items():assert sha(R/n)==h
failure=C/'book_v2_precommit_whitespace_failure_v1_20261009.json';assert not failure.exists()
write(failure,dict(UTC=stamp(),status='FAILED before commit; exact owned sixteen-file staging preserved in record',reason='New blank line at EOF in exported audit',files=oldfiles,active_PDF_SHA256=a['active_PDF']['SHA256'],old_export_SHA256=sha(oldexp),old_activation_SHA256=sha(oldact),mathematical_and_compiled_inputs_changed=False,actual_reading_credit=0))
subprocess.run(['git','restore','--staged','--',*oldfiles],cwd=R,check=True);assert not git('diff','--cached','--name-only')
paths={k:E/f'BGPS_Fubini_Study_staged_integration_{k}_v3_20261009.{ext}' for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
dest=E/'artifact_exports/20261009_BGPS_Fubini_Study_v3';out=C/'book_export_v3_20261009.json';act=E/'BGPS_Fubini_Study_cloud_activation_v3_20261009.json'
minimal=O/'BGPS_Fubini_Study_Minimal_Source_Publication_V3_2026-10-09.zip';evidence=O/'BGPS_Fubini_Study_Book_Evidence_Publication_V3_2026-10-09.zip';patch=C/'book_publication_packaging_repair_v3_20261009.json'
assert not any(p.exists() for p in [*paths.values(),dest,out,act,minimal,evidence,patch])
for k in ['audit','reading_notes']:
 p=E/f'BGPS_Fubini_Study_staged_integration_{k}_v2_20261009.md';paths[k].write_text(p.read_text().rstrip()+'\n')
before={n:sha(R/n) for n in a['after_source_hashes']}
for rel in ['README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']:
 p=R/rel;s=p.read_text();s=s.replace('BGPS_Fubini_Study_staged_integration_audit_v2_20261009.md','BGPS_Fubini_Study_staged_integration_audit_v3_20261009.md').replace('artifact_exports/20261009_BGPS_Fubini_Study_v2/','artifact_exports/20261009_BGPS_Fubini_Study_v3/').replace('BGPS_Fubini_Study_cloud_activation_v2_20261009.json','BGPS_Fubini_Study_cloud_activation_v3_20261009.json');p.write_text(s)
after={n:sha(R/n) for n in a['after_source_hashes']}
for n in ['manuscript/parts/part3/ch27_differentiability.tex','manuscript/appendices/appL_provenance.tex','manuscript/bibliography/NonArchimedean.bib']:assert before[n]==after[n]
write(patch,dict(UTC=stamp(),status='DONE — publication formatting repair; mathematical/PDF/reading version remains v2',before=before,after=after,old_export_SHA256=sha(oldexp),old_activation_SHA256=sha(oldact),precommit_failure_SHA256=sha(failure),audit_v2_SHA256=sha(E/'BGPS_Fubini_Study_staged_integration_audit_v2_20261009.md'),audit_v3_SHA256=sha(paths['audit']),only_audit_EOF_whitespace_changed=True,compiled_PDF_unchanged=a['active_PDF'],actual_reading_credit_added=0,prior_receipts_and_archives_rewritten=False,helper_source=__file__,helper_SHA256=sha(__file__)))
with zipfile.ZipFile(x['artifacts']['minimal_TeX_source_archive']['path']) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 names=old.namelist();assert len(names)==len(set(names))==472
 for n in names:z.writestr(n,(R/n).read_bytes())
with zipfile.ZipFile(minimal) as z:
 assert z.testzip() is None
 for n in z.namelist():assert z.read(n)==(R/n).read_bytes()
added={'publication_v3/repair.json':patch,'publication_v3/precommit_failure.json':failure,'publication_v3/prior_cloud_activation_v2.json':oldact,'publication_v3/audit.md':paths['audit'],'publication_v3/reading_notes.md':paths['reading_notes'],'publication_v3/README.md':R/'README.md','publication_v3/programme.md':R/'manuscript/editorial/second_reading_and_research_programme_20261002.md','publication_v3/helper.py':Path(__file__),'publication_v3/failed_publisher_v2.py':Path('/tmp/BGPS_Fubini_Study_publish_book_v2_20261009.py'),'publication_v3/activation_helper_v2.py':Path('/tmp/BGPS_Fubini_Study_activate_book_v2_20261009.py')}
with zipfile.ZipFile(x['artifacts']['actual_book_evidence_archive']['path']) as old,zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 entries={n:old.read(n) for n in old.namelist()};assert len(entries)==123 and not(set(entries)&set(added))
 for n,data in sorted(entries.items()):z.writestr(n,data)
 for n,p in sorted(added.items()):z.write(p,n)
with zipfile.ZipFile(evidence) as z:
 assert len(z.namelist())==133 and z.testzip() is None
 for n,data in entries.items():assert z.read(n)==data
 for n,p in added.items():assert z.read(n)==p.read_bytes()
artifacts=dict(x['artifacts']);artifacts['minimal_TeX_source_archive']=dict(path=str(minimal),bytes=minimal.stat().st_size,SHA256=sha(minimal),members=472);artifacts['actual_book_evidence_archive']=dict(path=str(evidence),bytes=evidence.stat().st_size,SHA256=sha(evidence),members=133)
oldmanifest=E/'BGPS_Fubini_Study_staged_integration_manifest_v2_20261009.json';m=json.loads(oldmanifest.read_text());m.update(status='DONE — published packaging v3; mathematical/compiled/actual-read version v2',artifacts=artifacts,publication_packaging_repair=json.loads(patch.read_text()),parent_manifest_SHA256=sha(oldmanifest));write(paths['manifest'],m)
write(paths['artifacts'],dict(UTC=stamp(),status='DONE — byte-verified publication packaging v3; exact v2 book PDF and actual reading',artifacts=artifacts,actual_final_book_pages=13,fresh_matching_views=7,explicitly_reviewed_blank_versos=[],reading_credit_from_export=0,GitHub_published=False,publication_packaging_repair_SHA256=sha(patch)))
dest.mkdir()
for r in artifacts.values():
 p=Path(r['path']);assert sha(p)==r['SHA256'];q=dest/p.name;shutil.copyfile(p,q);assert sha(q)==sha(p)
(dest/'SHA256SUMS').write_text(''.join(r['SHA256']+'  '+Path(r['path']).name+'\n' for r in artifacts.values()))
(dest/'README.md').write_text('''# Fubini–Study arithmetic-example publication artifacts

Checked 4,677-page mathematical/PDF version v2. All thirteen selected
final pages were read in seven fresh matching displays, with no blank
versos. Publication packaging v3 removes an extra audit EOF blank line
and updates progress links. It changes no mathematical input or rendered
PDF and grants zero reading credit. Earlier exports, receipts, stages
and helpers remain frozen. The 133-member evidence retains all previous
123 members verbatim and adds ten publication-repair records/helpers.
The 472-member minimal source matches the active tree at export.

The classical P1_Q example keeps standard finite models, ordinary-norm
height, entropy roof, essential minimum log2/2, normalized intersection
1/4 and zero boundary heights explicit. The original smooth Chern
curvature uses the squared-norm potential 2g and differs from the
Haar/Gauss small-point limit. Complete published BGPS reading is separate
from recursive proof clearance. No original theorem or independent-model
receipt is claimed; the exact attainment candidate remains unverified.
General BJ22 Siu/envelopes stay OPEN and LPWZ density UNVERIFIED.
Canonical statuses and the native catalogue/editor are preserved.
Export/upload grants no reading credit; publication is recorded separately.
''')
editorial={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in paths.values()}
for p in dest.iterdir():editorial[str(p.relative_to(R))]=dict(bytes=p.stat().st_size,SHA256=sha(p))
write(out,dict(UTC=stamp(),status='DONE — publication packaging v3; exact checked book v2',artifacts=artifacts,editorial_files=editorial,progress_document_hashes={n:after[n] for n in ['README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']},actual_final_book_pages=13,actual_final_matching_views=7,reused_matching_views=0,explicitly_reviewed_blank_versos=[],publication_repair_SHA256=sha(patch),prior_export_SHA256=sha(oldexp),actual_reading_version='v2',active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)))
newact=dict(a);newact.update(UTC=stamp(),status='DONE — publication packaging v3; same validated active book v2',before_source_hashes=before,after_source_hashes=after,prior_activation_SHA256=sha(oldact),publication_repair_SHA256=sha(patch),publication_export_SHA256=sha(out),minimal_source_members_byte_verified_against_active_tree=472,compiled_PDF_changed_by_this_repair=False,reading_credit_added_by_this_repair=0,helper_source=__file__,helper_SHA256=sha(__file__));write(act,newact)
assert sha(R/'manuscript/book.pdf')==a['active_PDF']['SHA256']
for n,h in a['native_catalogue_preserved'].items():assert sha(R/n)==h
for p in paths.values():assert p.read_text().endswith('\n') and not p.read_text().endswith('\n\n')
assert not git('diff','--cached','--name-only')
print(json.dumps(dict(status='DONE',publication_export_SHA256=sha(out),activation_SHA256=sha(act),evidence_members=133,mathematical_PDF_version='v2',book_PDF_unchanged=True)))
