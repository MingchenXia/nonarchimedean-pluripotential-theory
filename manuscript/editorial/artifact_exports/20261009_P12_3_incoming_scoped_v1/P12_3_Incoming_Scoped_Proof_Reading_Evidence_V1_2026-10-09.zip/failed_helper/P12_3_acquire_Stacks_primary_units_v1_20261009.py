from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,urllib.request,concurrent.futures
from bs4 import BeautifulSoup
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/GitHub_incoming_P12_3_continuation302_20261009')
D=C/'primary_Stacks_v1';assert not D.exists();D.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def get(tag):
    url='https://stacks.math.columbia.edu/tag/'+tag
    with urllib.request.urlopen(url,timeout=45) as response:
        raw=response.read();resolved=response.geturl()
    p=D/(tag+'.html');p.write_bytes(raw)
    soup=BeautifulSoup(raw,'html.parser')
    for el in soup(['script','style','nav','header','footer']):el.decompose()
    body=soup.find(id='content') or soup.find('main') or soup.body
    txt=D/(tag+'_preparation.txt');txt.write_text(body.get_text(separator='\n',strip=True)+'\n')
    return dict(tag=tag,URL=url,resolved_URL=resolved,HTML_path=str(p),HTML_SHA256=sha(p),HTML_bytes=len(raw),prepared_text_path=str(txt),prepared_text_SHA256=sha(txt),actual_primary_read=False,reading_credit=0)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:records=list(pool.map(get,['0BGJ','01VG']))
out=C/'Stacks_primary_acquisition_v1_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACQUIRED PRIMARY HTML ONLY — actual reading pending',sources=records,programs_from_incoming_executed=False,book_changed=False,production_VERIFIED=False,helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(sources=[dict(tag=x['tag'],HTML_bytes=x['HTML_bytes']) for x in records],SHA256=sha(out))))
