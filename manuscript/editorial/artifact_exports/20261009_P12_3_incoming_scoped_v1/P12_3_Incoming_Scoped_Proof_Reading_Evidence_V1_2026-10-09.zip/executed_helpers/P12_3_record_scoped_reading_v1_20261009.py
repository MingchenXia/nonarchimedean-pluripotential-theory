from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/GitHub_incoming_P12_3_continuation302_20261009')
P=C/'P12.3-conductor-and-threefold.tex';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prep=json.loads((C/'scope_preparation_v1_20261009.json').read_text());lines=P.read_text().splitlines(keepends=True)
assert sha(P)==prep['source_SHA256']=='47430ddc0d2d5bdecbc313a64a052bbda70c1d13e1c2aa3963befc54581d493a'
ranges=[[1,40],[41,88],[89,123],[124,172],[173,234],[235,279]]
actual=[]
for start,end in ranges:
    data=''.join(lines[start-1:end]).encode()
    actual.append(dict(source_lines=[start,end],SHA256=hashlib.sha256(data).hexdigest(),bytes=len(data),full_bounded_text_actually_read=True))
g=prep['units'][1];assert g['name']=='qualified_G331'
chunks=[]
for x in g['chunks']:
    assert sha(x['path'])==x['SHA256']
    chunks.append(dict(x,actual_read=True,whole_bounded_output_read=True))
data=''.join(lines[279:886]).encode();assert hashlib.sha256(data).hexdigest()==g['scope_SHA256']
primary=[]
acq=json.loads((C/'Stacks_primary_acquisition_v2_20261009.json').read_text())
for x in acq['sources']:
    assert sha(x['HTML_path'])==x['HTML_SHA256'] and sha(x['prepared_text_path'])==x['prepared_text_SHA256']
    primary.append(dict(x,actual_primary_read=True,entire_section_text_and_all_immediate_proofs_read=True,PDF_pages_read=0))
note=C/'own_scoped_proof_reading_notes_v1_20261009.md'
checks=C/'own_exact_adversarial_checks_v1_20261009.json';ck=json.loads(checks.read_text());assert ck['value_checks']==23040
out=C/'actual_scoped_reading_v1_20261009.json';assert not out.exists()
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACTUAL SCOPED SOURCE READING — UNVERIFIED new results',remote_commit=prep['remote_commit'],whole_source_SHA256=sha(P),whole_source_bytes=P.stat().st_size,current_core_ranges=actual,entire_qualified_G331=dict(source_lines=[280,886],scope_SHA256=hashlib.sha256(data).hexdigest(),bytes=len(data),actual_chunks=chunks),fresh_primary_sections=primary,own_notes_SHA256=sha(note),finite_diagnostics_SHA256=sha(checks),own_exact_weight_cases=720,own_finite_value_checks=23040,whole_423961_byte_source_read=False,later_retained_historical_source_read=False,separate_companion_read=False,original_FINAL_carriers_read=False,recursive_primary_proofs_read=False,inherited_reading_claims_transferred=False,independent_verifier_receipt=False,production_VERIFIED=False,new_results_promoted=[],canonical_status_changes=[],book_changed=False,book_pages=4677,rendered_book_or_source_PDF_page_credit=0,native_editor_changed=False,native_compile_success_verified=False,programs_from_incoming_executed=False,Xean_started=False,helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(current_core_lines=[1,279],entire_qualified_G331_lines=[280,886],primary_sections=[x['tag'] for x in primary],whole_source_read=False,SHA256=sha(out))))
