from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from math import comb
import hashlib,json
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/GitHub_incoming_P12_3_continuation302_20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=C/'own_exact_adversarial_checks_v1_20261009.json';assert not out.exists()
# None denotes infinity; all finite arithmetic is exact Fraction/integer.
add=lambda a,b:None if a is None or b is None else a+b
scale=lambda a,n:F(0) if n==0 else (None if a is None else a*n)
def minimum(values):
    finite=[x for x in values if x is not None]
    return min(finite) if finite else None
def coefficient_nonzero(c,p):return c!=0 if p==0 else c%p!=0
weights=[(F(a),F(b)) for a in [F(1,2),F(1),F(2),F(3)] for b in [F(1,2),F(1),F(2),F(3)]]
weights += [(None,F(1)),(F(1),None)]
cases=0;checks=0;maximum_gap=F(0);endpoint_checks=0
for p in [0,2,3,5,7]:
    for chart in ['t_z','t_b']:
        for s,second in weights:
            if chart=='t_z':u=second;B=minimum([s,u])
            else:B=second;u=minimum([s,B])
            for U in [None,F(1,2),F(3,2),F(3)]:
                norm=minimum([scale(s,2),u,U]);assert norm is not None and norm>0
                A=minimum([B,scale(s,2),U]);assert A is not None
                cases+=1
                for m in range(1,33):
                    if chart=='t_z':
                        vals=[]
                        for j in range(m+2):
                            coef=(comb(m,j) if j<=m else 0)-m*(comb(m,j-1) if 1<=j<=m+1 else 0)
                            if coefficient_nonzero(coef,p):vals.append(add(scale(s,j),scale(u,m+1-j)))
                        first=minimum(vals)
                    else:
                        vals=[scale(B,m+1)]
                        if coefficient_nonzero(-(m+1),p):vals.append(add(s,scale(B,m)))
                        first=minimum(vals)
                    value=minimum([first,add(scale(s,2),scale(B,m)),scale(s,2*m+2),scale(U,m)])
                    assert value is not None
                    gap=(value-m*A)/norm
                    assert F(0)<=gap<=F(2)
                    maximum_gap=max(maximum_gap,gap);checks+=1
                    if s is None or second is None or U is None:endpoint_checks+=1
assert maximum_gap==2
cancellation=[dict(m=m,coefficient=comb(m,1)-m*comb(m,0)) for m in range(1,65)]
assert all(x['coefficient']==0 for x in cancellation)
# Standard blowup intersection matrix on Bl_{P,Q} P2, diagonal (1,-1,-1).
restricted=[1,-1,-1];curve=[1,-1,-1];intersection=sum(a*b*q for a,b,q in zip(restricted,curve,[1,-1,-1]))
assert intersection==-1
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='EXACT FINITE ADVERSARIAL DIAGNOSTICS — not universal or independent verification',source_SHA256=sha(C/'P12.3-conductor-and-threefold.tex'),fields_characteristics=[0,2,3,5,7],coordinate_charts=['t_z','t_b'],raw_weight_pairs=[['infinity' if a is None else str(a),'infinity' if b is None else str(b)] for a,b in weights],extra_coordinate_minima=['infinity','1/2','3/2','3'],degrees=[1,32],cases=cases,value_checks=checks,infinite_coordinate_checks=endpoint_checks,largest_normalized_value_gap=str(maximum_gap),all_sampled_errors_at_most_2_over_m=True,linear_cancellation_checks=cancellation,threefold=dict(divisorial_orders=[1,2,2],restriction=restricted,joining_curve=curve,intersection_matrix_diagonal=[1,-1,-1],degree=intersection),programs_from_incoming_executed=False,universal_claim_verified_by_computation=False,production_VERIFIED=False,independent_verifier_receipt=False,book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(cases=cases,value_checks=checks,infinite_coordinate_checks=endpoint_checks,largest_gap=str(maximum_gap),threefold_degree=intersection,SHA256=sha(out))))
