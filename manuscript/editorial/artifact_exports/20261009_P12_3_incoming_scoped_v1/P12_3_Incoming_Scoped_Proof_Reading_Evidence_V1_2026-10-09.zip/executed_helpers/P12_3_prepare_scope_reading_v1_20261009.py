from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/GitHub_incoming_P12_3_continuation302_20261009')
P=C/'P12.3-conductor-and-threefold.tex'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(P)=='47430ddc0d2d5bdecbc313a64a052bbda70c1d13e1c2aa3963befc54581d493a'
lines=P.read_text().splitlines(keepends=True)
W=Path('/tmp/P12_3_incoming_scope_views_v1_20261009');assert not W.exists();W.mkdir()
units=[]
for name,start,end in [('current_core',1,279),('qualified_G331',280,886)]:
    data=''.join(lines[start-1:end])
    offset=0;chunks=[]
    while offset<len(data):
        stop=min(offset+11000,len(data))
        if stop<len(data):
            at=data.rfind('\n',offset,stop)
            if at>offset:stop=at+1
        p=W/(name+'_chunk_%02d.txt'%(len(chunks)+1))
        p.write_text(data[offset:stop])
        chunks.append(dict(number=len(chunks)+1,path=str(p),SHA256=sha(p),characters_start=offset,characters_end_exclusive=stop,actual_read=False))
        offset=stop
    assert ''.join(Path(x['path']).read_text() for x in chunks)==data
    units.append(dict(name=name,source_lines=[start,end],characters=len(data),scope_SHA256=hashlib.sha256(data.encode()).hexdigest(),chunks=chunks))
record=C/'scope_preparation_v1_20261009.json';assert not record.exists()
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='PREPARED ONLY — zero actual reading credit',source_SHA256=sha(P),source_bytes=P.stat().st_size,remote_commit='1aeb16838fc957d36947eb70664cab1ea15335e6',units=units,book_changed=False,programs_from_incoming_executed=False,production_VERIFIED=False,helper_source=__file__,helper_SHA256=sha(__file__))
record.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(scopes=[dict(name=u['name'],characters=u['characters'],chunks=len(u['chunks'])) for u in units],SHA256=sha(record))))
