from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile,subprocess
R=Path('/workspace/nonarchimedean-pluripotential-theory');E=R/'manuscript/editorial'
C=R/'source_material/GitHub_incoming_P12_3_continuation302_20261009'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();now=lambda:datetime.now(timezone.utc).isoformat()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
parent='16f75cdc488c4bff3b2cbd539a212a04af1f1982'
assert git('rev-parse','HEAD')==parent and not git('diff','--name-only') and not git('diff','--cached','--name-only')
rec=C/'actual_scoped_reading_v1_20261009.json';obj=json.loads(rec.read_text())
assert not obj['whole_423961_byte_source_read'] and not obj['production_VERIFIED'] and obj['own_finite_value_checks']==23040
book=R/'manuscript/book.pdf';book_sha='9e01eefb787a201d3cdc1dd8e5c5802f3ca86c3acd88c22c9f28ca3d401d3f9b'
native={'output/open_problems_catalogue_2026-10-03.tex':'ec3a2a9d8c4d713afe2c0ff8dcf17720ef0d77442b6086d515dea382fe7b77ec','output/open_problems_catalogue_2026-10-03.pdf':'65125a7809e34e4dbe2440855df21447f2c38b79dc3dd6f4a46107353dcb53e2'}
assert sha(book)==book_sha
for n,h in native.items():assert sha(R/n)==h
paths={k:E/('P12_3_incoming_continuation302_scoped_'+k+'_v1_20261009.'+ext) for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in paths.values())
review='''# Incoming GitHub P12.3 progress: scoped proof audit

Read the current paper419 core (TeX lines 1–279) and the **entire**
attached qualified G331 (lines 280–886) from pinned research-branch commit
`1aeb16838fc957d36947eb70664cab1ea15335e6`. The whole acquired TeX is
423,961 bytes, SHA256
`47430ddc0d2d5bdecbc313a64a052bbda70c1d13e1c2aa3963befc54581d493a`.
Later embedded 416/413 history and the separate companion are unread in
this audit. **This is a scoped source-text read, not a whole-file, rendered
PDF or whole-book read.** The remote checkpoint explicitly says
UNREVIEWED, accepted=false and original_closed=false; its current scoped
verdict is candidate=false.

## Mathematical scope of the new draft

The normal-surface envelope proof uses excellent normal local domains of
dimension two, every semivaluation support and every contracted curve.
It derives a greatest nef coefficient vector on an actual regular primary
model. The higher-dimensional argument cannot replace curve tests by a
nonzero section on an exceptional divisor.

The conductor theorem requires boundary-bijective normalization, with
primary conductor or finite radicial reduced conductor quotient as
sufficient cases. Infinite-conductor supports are retained. Positive
cone descent is a premise from qualified G331, beyond compact quotient
topology. Canonical ideals contract; equality after extension, automatic
rates and finite generation are separate claims.

Numerical-semigroup cusps have identical reduced conductor quotients.
The claimed all-obstacle result in every dimension uses the exact smooth
algebraically closed characteristic-zero source. Dimension two is the
arbitrary-field scope; the mixed-characteristic cusp is two-dimensional.
A particular cancellation-sensitive cusp obstacle has explicit primary
approximants with claimed every-degree canonical error at most 2/m.
Its characteristic-zero raw-cone separation gives a claimed failure of
canonical finite generation, **not** a failure of continuous envelopes.

The actual threefold calculation uses I=(z)+m squared, blows up the origin
and two rational points of its exceptional P2, and gives divisorial part
E1+2E2+2E3. On the strict transform Bl_{P,Q} P2 its negative has class
H-eP-eQ and degree -1 on the joining line. This is an obstruction to the
surface generic-section-to-all-curve-nef step. Genuine primary profiles
remain positive on their own blowup, and **no CE counterexample** is given.

## Fresh source and adversarial checks

The entire primary Stacks sections [54.14](https://stacks.math.columbia.edu/tag/0BGJ)
and [29.38](https://stacks.math.columbia.edu/tag/01VG) were acquired and
read, including the complete immediate proofs. Theorem 54.14.5 condition
(4) and Lemmas 54.14.3–4 match the proposed excellent normal surface;
composition ampleness 29.38.7–8 matches the specific projective primary
models. Deeper published foundations remain disclosed. BFJ, Swanson–Huneke,
Keeler and other embedded source-reading claims are not transferred to
this audit merely by reading their ledger.

Our separate exact diagnostics use 720 weight/chart/characteristic cases
and 23,040 K_m value checks, including 7,680 infinite-coordinate checks,
plus 64 exact cancellations and the threefold integer degree -1.
Characteristics sampled are 0,2,3,5,7. They compute explicit approximants,
not all canonical ideals or all semivaluations; finite success is not
universal verification. Supplied programs and Xean were not run.

The entire G331 proof chain and every attached qualification were read.
Its caller grant is an assumption of the draft; neither that label nor
earlier candidate/acceptance/compiler records supply this book with an
exact-current independent production-verifier receipt. The new claims
remain **UNVERIFIED**. General normal dimension at least three CE and
nonsingleton-conductor envelope descent remain OPEN. P12.2/P12.3 canonical
T4 status and the 42-atom/twelve-problem inventory are unchanged.

## Authored evidence and preserved documents

The 17-member archive contains this audit's notes and actual scoped
record, acquisition/preparation records, own finite diagnostics,
incoming metadata and frozen executed helpers. It excludes primary
literal bodies/images, the full incoming TeX and the unread companion.
All members are byte-checked. The 4,677-page book and its PDF are unchanged;
BJ22 general homogeneous Siu/envelopes remain OPEN and LPWZ density
UNVERIFIED. The native catalogue source, historical PDF and editor are
preserved; native compilation is unverified. Upload adds zero reading or
proof credit. Continue primary-source clearance and ordinary book
polishing while keeping candidate mathematics outside theorem typography.
'''
paths['review'].write_text(review)
paths['reading_notes'].write_bytes((C/'own_scoped_proof_reading_notes_v1_20261009.md').read_bytes())
paths['manifest'].write_text(json.dumps(dict(obj,actual_scoped_record_SHA256=sha(rec),book_PDF_SHA256=book_sha,native_preserved=native),ensure_ascii=False,indent=2)+'\n')
X=E/'artifact_exports/20261009_P12_3_incoming_scoped_v1';assert not X.exists();X.mkdir()
members={}
for name in ['acquisition_v1_20261009.json','actual_metadata_reading_v1_20261009.json','scope_preparation_v1_20261009.json','actual_scoped_reading_v1_20261009.json','own_exact_adversarial_checks_v1_20261009.json','Stacks_primary_acquisition_v2_20261009.json','Stacks_acquisition_failure_v1_20261009.json']:
    p=C/name;members['records/'+name]=p
members['own_notes/own_scoped_proof_reading_notes_v1_20261009.md']=C/'own_scoped_proof_reading_notes_v1_20261009.md'
for name in ['README.md','current-research-status.json','scoped-verdict.md']:members['incoming_metadata/'+name]=C/name
for name in ['P12_3_prepare_scope_reading_v1_20261009.py','P12_3_acquire_Stacks_primary_units_v1_20261009.py','P12_3_acquire_Stacks_primary_units_v2_20261009.py','P12_3_exact_adversarial_checks_v1_20261009.py','P12_3_record_scoped_reading_v1_20261009.py','P12_3_export_scoped_review_v1_20261009.py']:
    folder='failed_helper' if name=='P12_3_acquire_Stacks_primary_units_v1_20261009.py' else 'executed_helpers'
    members[folder+'/'+name]=Path('/tmp')/name
assert len(members)==17 and all(p.exists() for p in members.values())
archive=X/'P12_3_Incoming_Scoped_Proof_Reading_Evidence_V1_2026-10-09.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(members.items()):z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==17
    for name,p in members.items():assert z.read(name)==p.read_bytes()
(X/'README.md').write_text('''# Incoming P12.3 scoped proof-reading evidence

The current core and entire qualified G331 were actually read from the
pinned research commit; later retained history and companion are unread.
The 17-member archive preserves authored notes/records, own exact finite
diagnostics, incoming metadata and executed helpers, including one failed
dependency-import attempt. No supplied program or Xean was executed.
Primary literal bodies/images and the full incoming TeX are excluded.
No independent VERIFIED receipt, new book theorem or canonical closure
is claimed. The book and native catalogue/editor are preserved.
''')
(X/'SHA256SUMS').write_text(sha(archive)+'  '+archive.name+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=now(),status='EXPORTED — scoped incoming source review, new mathematics UNVERIFIED',archive=str(archive.relative_to(R)),SHA256=sha(archive),bytes=archive.stat().st_size,members=17,current_core_lines=[1,279],entire_qualified_G331_lines=[280,886],whole_incoming_source_read=False,primary_sections_read=['0BGJ','01VG'],own_finite_cases=720,own_finite_value_checks=23040,independent_verifier_receipt=False,production_VERIFIED=False,book_changed=False,canonical_status_changes=[],reading_credit_for_upload=0),indent=2)+'\n')
update='''
## Incoming GitHub P12.3 proof audit, 9 October 2026

At research commit `1aeb16838fc957d36947eb70664cab1ea15335e6`, read
paper419's current core and the entire qualified G331 with all attached
scope/reader annotations. Later retained historical source and companion
are unread. Freshly read complete Stacks sections 54.14 and 29.38. Own
exact diagnostics cover 720 cases and 23,040 explicit-ideal values.

See [scoped incoming-proof review](manuscript/editorial/P12_3_incoming_continuation302_scoped_review_v1_20261009.md)
and [17-member authored evidence](manuscript/editorial/artifact_exports/20261009_P12_3_incoming_scoped_v1/README.md).
The conductor/cusp deductions are UNVERIFIED; the threefold degree -1
obstructs a proof strategy and is not a continuous-envelope counterexample.
No exact-current independent production-verifier receipt is present.
General higher-dimensional and nonsingleton-conductor questions remain
OPEN. The book, native catalogue/editor and canonical statuses are unchanged.
'''
readme=R/'README.md';progress=E/'second_reading_and_research_programme_20261002.md'
readme.write_text(readme.read_text().rstrip()+'\n'+update)
progress.write_text(progress.read_text().rstrip()+'\n'+update.replace('(manuscript/editorial/','('))
owned=[*paths.values(),*sorted(X.iterdir()),readme,progress];assert len(owned)==9
for p in owned:
    if p.suffix in ['.md','.json']:assert p.read_bytes().endswith(b'\n') and not p.read_bytes().endswith(b'\n\n')
assert sha(book)==book_sha
for n,h in native.items():assert sha(R/n)==h
out=C/'scoped_evidence_export_v1_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=now(),status='READY FOR EXPLICIT NINE-FILE PUBLICATION',parent=parent,owned_files=[dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,SHA256=sha(p)) for p in owned],archive_members=17,whole_incoming_source_read=False,book_changed=False,canonical_status_changes=[],independent_verifier_receipt=False,production_VERIFIED=False,helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
print(json.dumps(dict(owned_files=9,archive_members=17,archive_SHA256=sha(archive),export_SHA256=sha(out))))
