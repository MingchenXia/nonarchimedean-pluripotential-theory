from pathlib import Path
from datetime import datetime,timezone
from html.parser import HTMLParser
import hashlib,json,urllib.request,concurrent.futures,re
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/GitHub_incoming_P12_3_continuation302_20261009')
D=C/'primary_Stacks_v2';assert not D.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
class Text(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True);self.body=False;self.skip=0;self.parts=[]
    def handle_starttag(self,tag,attrs):
        if tag=='body':self.body=True
        if tag in ['script','style','nav','header','footer']:self.skip+=1
        if self.body and self.skip==0 and tag in ['p','div','li','tr','br','h1','h2','h3','h4']:self.parts.append('\n')
    def handle_endtag(self,tag):
        if tag in ['script','style','nav','header','footer']:self.skip-=1
        if tag=='body':self.body=False
        if self.body and self.skip==0 and tag in ['p','div','li','tr','h1','h2','h3','h4']:self.parts.append('\n')
    def handle_data(self,data):
        if self.body and self.skip==0:self.parts.append(data)
def get(tag):
    url='https://stacks.math.columbia.edu/tag/'+tag
    with urllib.request.urlopen(url,timeout=45) as response:return tag,url,response.geturl(),response.read()
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:acquired=list(pool.map(get,['0BGJ','01VG']))
D.mkdir();records=[]
for tag,url,resolved,raw in acquired:
    p=D/(tag+'.html');p.write_bytes(raw)
    parser=Text();parser.feed(raw.decode('utf-8'));assert parser.skip==0
    prepared=re.sub(r'\n[ \t]*\n(?:[ \t]*\n)+','\n\n',''.join(parser.parts)).strip()+'\n'
    txt=D/(tag+'_preparation.txt');txt.write_text(prepared)
    records.append(dict(tag=tag,URL=url,resolved_URL=resolved,HTML_path=str(p),HTML_SHA256=sha(p),HTML_bytes=len(raw),prepared_text_path=str(txt),prepared_text_SHA256=sha(txt),actual_primary_read=False,reading_credit=0))
out=C/'Stacks_primary_acquisition_v2_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACQUIRED PRIMARY HTML ONLY — actual reading pending',sources=records,programs_from_incoming_executed=False,book_changed=False,production_VERIFIED=False,helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(sources=[dict(tag=x['tag'],HTML_bytes=x['HTML_bytes']) for x in records],SHA256=sha(out))))
