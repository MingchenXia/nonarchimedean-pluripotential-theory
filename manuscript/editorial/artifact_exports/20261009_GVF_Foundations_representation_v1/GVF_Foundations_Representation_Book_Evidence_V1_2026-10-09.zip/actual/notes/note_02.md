Read the complete selected text and displayed matching rendered image for
physical pages1854–1855. The preceding Luo–Yu surface example remains
legible and retains complex constants, non-torsion Picard data, degree2n,
height a/n and the difference between dense small points and height-zero
points. Its conclusion leads directly into the new representation paragraph.
The proper-adelic integrals are clear; scalar invariance follows from the
product formula. The explicit countability hypothesis concerns F, not a
discrete set of places, and the uncountable geometric models keep their
own specified intersection heights. The finite-Galois uniqueness qualifier
is visibly italicized and Example10.6 makes its role explicit. The source
normalization is correctly cited as Lemma10.2, followed by Definition11.8's
upper bound and the open model-companion question. Its final sentence
continues on the next page. Formula/citation typography is clean, with no
clipping or required repair. No new theorem or canonical problem closure.
