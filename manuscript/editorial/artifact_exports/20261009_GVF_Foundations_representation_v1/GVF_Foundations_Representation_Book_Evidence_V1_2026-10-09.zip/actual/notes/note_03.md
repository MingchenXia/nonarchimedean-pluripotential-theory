Read the complete selected text and displayed matching rendered image for
physical pages1856–1857. The new model-companion paragraph finishes with
the conditional/up-to-scaling qualification and separates the height-
structure question from envelope regularity and equidistribution. The
following paragraph explicitly returns to number fields, preserving the
Ballay–Sombra source Question6.21 and logarithmic Remark7.16 as open
directions. The arithmetic section then joins the existing chapter notes
without a broken heading or new numbered result. The notes retain the
algebraizability/residue-characteristic source boundaries, energy variation
and net/sequence distinction. Citation links, displayed inradius condition
and blue cross-references are readable and within margins. No repair is
needed, no original theorem is promoted, and this is a scoped adjacency
review rather than a whole-chapter or whole-book rereading.
