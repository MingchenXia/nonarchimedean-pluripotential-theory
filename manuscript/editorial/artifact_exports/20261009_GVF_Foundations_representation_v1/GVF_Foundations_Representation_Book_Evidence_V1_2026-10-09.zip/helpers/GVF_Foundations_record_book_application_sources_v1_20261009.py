from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

R = Path('/workspace/nonarchimedean-pluripotential-theory')
F = R/'source_material/Hultberg_GVF_dependency_review_20261009/GVFFoundations26ArxivV2'
C = R/'source_material/GVF_Foundations_representation_book_integration_20261009'
C.mkdir(exist_ok=False)
sha = lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prep = json.loads((F/'scope_preparation_v1_20261009.json').read_text())
assert sha(prep['PDF'])==prep['PDF_SHA256']=='b22a534273148c226bd1d1f607569f939f0e814b201f492667364f849678babc'
views = []
for n in [16,17,19,20,21,22,24]:
    row = dict(prep['entries'][n-1])
    assert row['number']==n
    assert sha(row['image_path'])==row['image_SHA256']
    assert sha(row['text_path'])==row['text_SHA256']
    row.update(actual_image_viewed=True,actual_complete_text_read=True,
               current_reading_scope='fresh repeat for book application; no new unique primary-page credit')
    views.append(row)
source_checkpoint = F/'actual_complete_source_checkpoint_v1_20261009.json'
assert json.loads(source_checkpoint.read_text())['full_source_read']
obj = dict(UTC=datetime.now(timezone.utc).isoformat(),
           status='ACTUAL source repeat and book-application primary locator review',
           source_version='arXiv:2409.04570v2, 30 August2026',PDF_path=prep['PDF'],PDF_SHA256=prep['PDF_SHA256'],
           current_repeat_views=views,current_repeat_physical_pages=14,new_unique_primary_page_credit=0,
           prior_full52_page_checkpoint_SHA256=sha(source_checkpoint),
           prior_complete_source_publication_SHA256=sha(F/'GVF_Foundations_complete_source_GitHub_publication_v1_20261009.json')
           if (F/'GVF_Foundations_complete_source_GitHub_publication_v1_20261009.json').exists()
           else sha(R/'manuscript/editorial/GVF_Foundations_complete_source_GitHub_publication_v1_20261009.json'),
           exact_book_locators={'height_measure_dictionary':'Theorem7.7 pp32–33',
                'ordinary_adelic_presentation':'Definition7.10 and Corollary7.11 p33; countable F',
                'finite_Galois_uniqueness':'Proposition10.5 p40, Lemmas10.3–10.4 pp38–39; invariant category',
                'nonsymmetric_extensions':'Example10.6 p40',
                'number_field_scale':'LEMMA10.2 p38, not Definition10.2',
                'height_gauge':'Example11.4 p41',
                'fixed_error_bound':'Definition11.8 p43, ht(2)≤e',
                'model_companion_problem':'Conjecture12.7 p48; OPEN, classification conditional'},
           locator_addendum_path=str(F/'book_application_locator_addendum_v1_20261009.md'),
           locator_addendum_SHA256=sha(F/'book_application_locator_addendum_v1_20261009.md'),
           independent_original_verifier_receipt=None,original_results_promoted=[],
           recursive_primary_audit_complete=False,book_changed=False,native_editor_changed=False,
           helper_source=__file__,helper_SHA256=sha(__file__))
p = C/'actual_book_application_source_repeat_v1_20261009.json'
with p.open('x') as f:f.write(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(repeated_actual_pages=14,fresh_matching_views=7,new_unique_pages=0,
                      locator_correction='Lemma10.2',record_SHA256=sha(p))))
