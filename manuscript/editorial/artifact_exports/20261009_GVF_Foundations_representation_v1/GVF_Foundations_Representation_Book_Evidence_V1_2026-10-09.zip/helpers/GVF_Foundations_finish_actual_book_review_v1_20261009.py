from pathlib import Path
from datetime import datetime, timezone
import hashlib,json
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/GVF_Foundations_representation_book_integration_20261009'
F=R/'source_material/Hultberg_GVF_dependency_review_20261009/GVFFoundations26ArxivV2'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
prep=load('book_staging_preparation_v1_20261009.json');release=load('book_release_checks_v1_20261009.json')
validation=load('book_validation_v1_20261009.json');under=load('book_underfull_delta_v1_20261009.json')
manifest=json.loads(Path(release['manifest_path']).read_text())
assert validation['returncode']==0 and under['all_normalized_blocks_and_multiplicities_identical']
assert sha(release['PDF']['path'])==release['PDF']['SHA256'] and release['PDF']['physical_pages']==4685
receipts=[]
for n,item in enumerate(manifest,1):
 p=C/f'book_notes_v1/note_{n:02d}_receipt.json';note=C/f'book_notes_v1/note_{n:02d}.md';x=json.loads(p.read_text())
 assert x['number']==n and x['physical_pages']==item['physical_pages']
 assert x['complete_selected_text_actually_read'] and x['matching_image_individually_displayed_and_reviewed']
 assert x['source_PDF_SHA256']==release['PDF']['SHA256']
 assert sha(note)==x['note_SHA256'] and sha(item['path'])==x['image_SHA256'] and sha(item['selected_text_path'])==x['selected_text_SHA256']
 assert x['previous_receipt_SHA256']==(receipts[-1]['receipt_SHA256'] if n>1 else None)
 receipts.append(dict(number=n,physical_pages=x['physical_pages'],note_SHA256=sha(note),receipt_SHA256=sha(p)))
pages=[p for x in receipts for p in x['physical_pages']]
assert pages==release['selected_book_physical_pages'] and len(set(pages))==14 and len(receipts)==7
source=json.loads((F/'actual_complete_source_checkpoint_v1_20261009.json').read_text())
assert source['full_source_read'] and source['physical_pages_read']==list(range(1,53)) and source['fresh_matching_views']==26
for name,key in [('actual_complete_source_checkpoint_v1_20261009.json','source_checkpoint_SHA256'),('literal_exact_calibrations_v1_20261009.json','normalization_calibration_SHA256'),('GitHub_complete_source_publication_v1_20261009.json','source_publication_SHA256'),('book_application_locator_addendum_v1_20261009.md','source_locator_addendum_SHA256')]:assert sha(F/name)==prep[key]
assert sha(C/'actual_book_application_source_repeat_v1_20261009.json')==prep['book_application_source_repeat_SHA256']
assert 'GVF FOUNDATIONS REPRESENTATION STAGED BOOK V1 PHYSICAL PAGE 4434' in Path(manifest[4]['selected_text_path']).read_text()
assert not Path(manifest[4]['selected_text_path']).read_text().split('PHYSICAL PAGE 4434',1)[1].strip()
reading=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — actual scoped final V1 book reading',PDF=release['PDF'],actual_book_physical_pages=pages,actual_unique_book_pages=14,fresh_matching_views=7,reused_matching_views=0,receipts=receipts,explicitly_reviewed_blank_versos=[4434],blank_justification='Physical page 4434 was actually displayed and inspected as a blank verso between Appendix L and Appendix M; selected text contains no body.',remaining_repairs=[],actual_primary_source_reading_credit=0,whole_book_new_reading_claim=False,whole_chapter_reading_claim=False,index_actual_pages=[4643,4654],middle_index_pages_mechanical_only=True,release_checks_SHA256=sha(C/'book_release_checks_v1_20261009.json'),validation_SHA256=sha(C/'book_validation_v1_20261009.json'),underfull_comparison_SHA256=sha(C/'book_underfull_delta_v1_20261009.json'),active_book_changed=False,canonical_status_changes=[],original_results_promoted=[],helper_source=__file__,helper_SHA256=sha(__file__))
p=C/'actual_book_reading_v1_20261009.json';assert not p.exists();p.write_text(json.dumps(reading,ensure_ascii=False,indent=2)+'\n')
checks=[
'Controlling source arXiv:2409.04570v2, 30 August 2026, has all 52 physical pages actually read in 26 ordered matching text/image views; book application freshly repeats 14 source pages without new unique-page credit.',
'Corollary 7.11 uses COUNTABLE F; this concerns the field and does not assert a discrete countable place space. Do not silently apply it to preceding uncountable C(E) examples.',
'The integral formula is for a nonzero projective tuple; integrability follows from the finite maximum of log absolute values and one nonzero coordinate. The product formula makes multiplication of all coordinates by a nonzero scalar invisible to the height.',
'Theorem 7.7 retains pseudo-valuations, compatible local measures and homogeneous renormalization classes for arbitrary cardinality. The book states the countable sufficient scope rather than denying possible ordinary representations for other fields.',
'Proposition 10.5 gives existence and uniqueness for finite Galois L/F AMONG Aut(L/F)-invariant structures; Example 10.6 compares unequal x,y heights with the symmetric extension from Q(x+y,xy).',
'The finite Galois root bound uses max(0,-v(a)) bounded by max(0,-min over nonzero coefficients v(b_j)+log[n]); it extends the source conditional negative-value bound and handles archimedean log[n]. Apply also to the inverse for absolute integrability and use group averaging and the norm identity for the product formula.',
'Number-field scale is LEMMA 10.2, physical page 38: h_Q[r]([1:2])=r log 2. A fresh locator addendum corrects the older Definition 10.2 typo without changing frozen source notes.',
'Example 11.4 identifies ht(x)=h([1:x]). Definition 11.8 defines GVF_e by h([1:2])<=e, not equality.',
'Conjecture 12.7 remains OPEN for EACH FIXED e>=0. A model companion is model complete with the stated mutual embedding of model classes in continuous logic; the subsequent existential-closure classification is conditional and up to scaling.',
'The literal Corollary 12.8 scale assignment is excluded; the number-field-compatible scale for a given height of 2 is h([1:2])/log 2.',
'The standard L1 disjointness |alpha| wedge |beta|=0 is used. The literal Definition 4.11 signed condition includes beta=-alpha and is diagnosed separately; it is not copied into the representation statement.',
'Valuation conjugacy, residue-field Galois theory, lattice/measure representation and deeper arithmetic and existential-closure dependencies remain primary imports, not recursively independently certified.',
'The chapter does not use the separate meromorphic example, an arbitrary transcendental-extension uniqueness claim, the generic-line original candidate, or a predicted existentially closed classification in its height calculations.',
'The preceding Guo/Luo geometric examples retain models and base polarizations; the following paragraph explicitly returns to number fields, with Ballay--Sombra Question 6.21 and logarithmic Remark 7.16 left open at their respective scopes.',
'No original result, production-verifier receipt, homogeneous Siu repair, density theorem, canonical problem atom or problem closure is promoted.'
]
math=dict(UTC=datetime.now(timezone.utc).isoformat(),status='PASS — ordinary primary-source and mathematical audit of imported GVF presentation and stated open question',actual_final_book_reading_SHA256=sha(p),current_source_hashes=prep['after'],source_checkpoint_SHA256=prep['source_checkpoint_SHA256'],source_publication_SHA256=prep['source_publication_SHA256'],normalization_calibration_SHA256=prep['normalization_calibration_SHA256'],book_application_source_repeat_SHA256=prep['book_application_source_repeat_SHA256'],source_locator_addendum_SHA256=prep['source_locator_addendum_SHA256'],signature='Countable F for ordinary proper adelic representation; finite Galois symmetric extension; h_Q[r](2)=r log 2; fixed GVF_e upper bound and OPEN model-companion conjecture.',scope_checks=checks,deeper_imports_recursively_verified=False,production_VERIFIED=False,independent_verifier_receipt=False,original_result_promoted=False,canonical_status_changes=[],native_editor_changed=False,native_compile_success_verified=False,helper_source=__file__,helper_SHA256=sha(__file__))
q=C/'book_mathematical_self_audit_v1_20261009.json';assert not q.exists();q.write_text(json.dumps(math,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(reading_SHA256=sha(p),mathematical_audit_SHA256=sha(q),actual_pages=14,fresh_views=7,blank_verso=4434)))
