from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile,shutil,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory');E=R/'manuscript/editorial'
C=R/'source_material/GVF_Foundations_representation_book_integration_20261009'
F=R/'source_material/Hultberg_GVF_dependency_review_20261009/GVFFoundations26ArxivV2'
S=Path('/workspace/book-completion-drafts/GVF-Foundations-representation-staging-v1-20261009')
D=Path('/workspace/book-completion-drafts/GVF-Foundations-representation-integration-v1-20261009')
W=Path('/tmp/GVF_Foundations_representation_staged_book_views_v1_20261009')
O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda n:json.loads((C/n).read_text())
def write(p,obj):
 assert not p.exists();p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def markdown(p,s):p.write_text(s.rstrip()+'\n')
prep=load('book_staging_preparation_v1_20261009.json');release=load('book_release_checks_v1_20261009.json')
reading=load('actual_book_reading_v1_20261009.json');math=load('book_mathematical_self_audit_v1_20261009.json')
validation=load('book_validation_v1_20261009.json');under=load('book_underfull_delta_v1_20261009.json')
assert validation['returncode']==0 and under['all_normalized_blocks_and_multiplicities_identical']
assert reading['actual_unique_book_pages']==14 and reading['fresh_matching_views']==7 and reading['reused_matching_views']==0
assert not reading['remaining_repairs'] and reading['explicitly_reviewed_blank_versos']==[4434]
assert release['PDF']['physical_pages']==4685 and release['PDF']['SHA256']==reading['PDF']['SHA256']
assert math['actual_final_book_reading_SHA256']==sha(C/'actual_book_reading_v1_20261009.json')
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['before'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
paths={k:E/f'GVF_Foundations_representation_staged_integration_{k}_v1_20261009.{ext}' for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
full=O/'Non-Archimedean_Pluripotential_Theory_GVF_Representation_V1_2026-10-09.pdf'
review=O/'GVF_Foundations_Representation_Actual_Book_Review_V1_2026-10-09.pdf'
minimal=O/'GVF_Foundations_Representation_Minimal_Source_V1_2026-10-09.zip'
evidence=O/'GVF_Foundations_Representation_Book_Evidence_V1_2026-10-09.zip'
dest=E/'artifact_exports/20261009_GVF_Foundations_representation_v1';record=C/'book_export_v1_20261009.json'
assert not any(p.exists() for p in [*paths.values(),full,review,minimal,evidence,dest,record])
shutil.copyfile(release['PDF']['path'],full);assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as source:
 doc=fitz.open()
 for n in reading['actual_book_physical_pages']:doc.insert_pdf(source,from_page=n-1,to_page=n-1)
 assert len(doc)==14
 doc.set_metadata(dict(title='GVF representation — actual final book review',subject='Fourteen selected physical pages actually read in seven fresh matching views; physical page 4434 is an inspected blank verso. Export adds no reading credit.'))
 doc.save(review,garbage=4,deflate=True);doc.close()
summary='''The checked 4,685-page edition adds a globally valued fields comparison
to Chapter 27 and exact-version provenance to Appendix L. Corollary 7.11
of arXiv:2409.04570v2 represents a height by a proper adelic structure
when F is countable. The product formula makes the integral projective
height invariant under multiplying all coordinates by a nonzero scalar.
Countability concerns the field, not a discrete set of places. General
cardinality retains the pseudo-valuation/local-measure framework of
Theorem 7.7. The preceding geometric models, including C(E), keep their
own intersection presentations and base polarizations.

Finite Galois extension uniqueness is among Aut(L/F)-invariant structures.
Example 10.6 shows why symmetry matters. Lemma 10.2 uses h_Q[r](2)=r log2;
Definition 11.8 defines GVF_e with h(2)<=e, not equality. Conjecture 12.7
remains OPEN for each fixed e>=0. The prospective existential-closure
classification is conditional and up to scaling. It does not assert
envelope regularity, equidistribution or an arbitrary transcendental
extension's uniqueness. The following discussion explicitly returns to
number fields and the separate Ballaÿ–Sombra open questions.

All 52 physical primary pages were actually read in 26 ordered matching
text/image displays before the import. Fourteen source pages were freshly
repeated for the book's exact locators, without additional unique-page
credit. The fresh locator addendum corrects an older Definition 10.2 typo
to Lemma 10.2 while preserving frozen notes. The root estimate uses a
positive part and nonzero coefficients. The lattice comparison retains
standard absolute-value disjointness. The literal ultrapower scale
assignment and separate meromorphic example are excluded. Measure/lattice
representation, valuation conjugacy, residue-field Galois theory and the
deeper arithmetic/model-theoretic arguments remain disclosed primary
imports, not recursively independently certified. The generic-line
original candidate remains UNVERIFIED and outside the chapter.

Fourteen selected final book pages were actually read in seven fresh
matching displays: contents, preceding/new examples and adjacent discussion,
complete provenance, Appendix M opening, index boundaries and the BDHS26
bibliography entry. Physical page 4434 was actually inspected as a blank
verso. This is a scoped final-page reading. The last ordered whole-book
reading remains 4 October; no entire index/chapter/book reread is claimed.
Export and upload add no reading credit.

Required manuscript validation and six existing reference-check tests pass.
The PDF has zero errors, missing glyphs, overfull boxes, unresolved
references/citations, package/pdfTeX warnings or rerun requests. All 955
inherited underfull blocks retain their normalized contents and
multiplicities. All 13,382 numbered values, 606 prior cited keys/labels,
2,766 contents titles/hierarchy and 900 index terms remain; BDHS26 adds
the 607th citation. Every internal destination resolves. Only two of the
425 core TeX inputs and the NA bibliography change; the remaining 423
inputs and the complex bibliography are preserved. No formal environment,
semantic label, manual tag or contents title is added.

Canonical 42 atoms/twelve problems and tiers (0,3,7,15,17) remain unchanged.
BJ22 general homogeneous Siu/envelopes stay OPEN; LPWZ density UNVERIFIED.
Incoming continuation309 has its complete current 429 core, 430 ROOT
reader, five actual native296 annotations/all fields and five distinct
formal proofs actually read at the pinned research commit. Its conditional
normalization, finite-group and nonnormal separable/wild conductor
candidates remain UNVERIFIED. General normal higher-dimensional and
positive/mixed-characteristic source CE remain OPEN. Current G331 literal
body, retained companions and active298 packets have no fresh reading
credit. No supplied program, external native engine or Xean was executed.
The native catalogue/editor and historical PDF remain preserved; native
compilation remains unverified. Work continues cloud-only.
'''
markdown(paths['audit'],'# GVF representation book integration, 9 October 2026\n\n'+summary+'\nScoped mathematical checks:\n\n'+''.join(f'{i}. {x}\n\n' for i,x in enumerate(math['scope_checks'],1)))
notes=[]
for item in reading['receipts']:
 n=item['number'];note=C/f'book_notes_v1/note_{n:02d}.md';receipt=C/f'book_notes_v1/note_{n:02d}_receipt.json'
 assert sha(note)==item['note_SHA256'] and sha(receipt)==item['receipt_SHA256'];notes.append(note.read_text())
markdown(paths['reading_notes'],'# Actual final GVF representation book reading\n\nFourteen selected final pages in seven fresh displays; physical page 4434 is an inspected blank verso.\n'+''.join('\n---\n\n'+x for x in notes))
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md'
intro='''**Current checked GVF representation edition: 4,685 pages, 9 October 2026.**
The [integration audit](manuscript/editorial/GVF_Foundations_representation_staged_integration_audit_v1_20261009.md)
adds the countable-field proper adelic presentation of heights, symmetric
finite-Galois extension scope and the open fixed-GVF_e model-companion
question to Chapter 27. Appendix L pins the primary locators and scale.
All 52 primary pages and fourteen selected final book pages were actually
read with matching text/images. The [artifacts](manuscript/editorial/artifact_exports/20261009_GVF_Foundations_representation_v1/README.md)
contain the full book, actual review, minimal source and authored evidence.
Required checks pass; all prior numbered values, contents and index terms
remain, with 607 cited entries. The last ordered whole-book reading remains
4 October. Continuation309's current scoped proofs were separately read;
original candidates and canonical statuses remain unchanged. Cloud only,
Xean suspended. Earlier checkpoints below retain their dated reading scopes.

'''
p=S/'README.md';s=p.read_text();first=s.index('\n');markdown(p,s[:first+1]+'\n'+intro+s[first+1:])
intro='''## Current checked GVF representation edition: 4,685 pages, 9 October 2026

The [integration audit](GVF_Foundations_representation_staged_integration_audit_v1_20261009.md)
imports the countable-field proper adelic representation, product-formula
coordinate invariance, symmetric finite-Galois uniqueness and the open
fixed-GVF_e model-companion question. Lemma 10.2 gives r log2; the bound
in Definition 11.8 is an upper bound. The general-cardinality framework
and uncountable geometric examples retain their separate presentations.
The number-field transition and Ballaÿ–Sombra residuals remain explicit.

All 52 primary pages were previously read in 26 ordered matching views;
fourteen were repeated for exact book locators without new unique credit.
Fourteen selected final book pages were read in seven fresh matching views,
including blank physical page 4434. Required validation and six existing
tests pass. All 13,382 numbered values, 606 prior cited labels, 2,766 contents
titles/hierarchy and 900 index terms remain; BDHS26 gives 607 citations.
All destinations resolve and all 955 underfull blocks match the preceding
edition. Other 423 core TeX inputs and the complex bibliography are unchanged.
See the [artifacts](artifact_exports/20261009_GVF_Foundations_representation_v1/README.md).

The last ordered whole-book reading remains 4 October. Continuation309's
current 429/430, all five actual native296 annotations and formal proofs
were separately read at the pinned research commit. These original
candidates and the generic-line GVF candidate remain UNVERIFIED. Canonical
42 atoms/twelve problems and tiers (0,3,7,15,17) stay unchanged; P12.2/P12.3
and BJ22 general homogeneous Siu/envelopes remain OPEN, LPWZ density
UNVERIFIED. No independent production receipt or original theorem is
promoted. Native catalogue/editor and historical PDF are preserved; native
compilation is unverified. Continue cloud-only with Xean suspended.
Earlier checkpoints below remain dated historical evidence.

'''
p=S/programme;s=p.read_text();first=s.index('\n');markdown(p,s[:first+1]+'\n'+intro+s[first+1:])
with zipfile.ZipFile(prep['baseline_minimal_source']['path']) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 members=old.namelist();assert len(members)==len(set(members))==472
 for n in members:z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
 assert z.testzip() is None
 for n in z.namelist():assert z.read(n)==(S/n).read_bytes()
files={f'records/{q.name}':q for q in C.glob('*.json')}
for q in C.glob('book_validation_*_20261009.log'):files[f'logs/{q.name}']=q
for n in prep['after']:files['staged_inputs/'+n]=S/n
for q in D.iterdir():
 assert q.suffix in ['.tex','.bib'];files['drafts/'+q.name]=q
for q in (C/'book_compiled_staged_v1').iterdir():
 if q.suffix!='.pdf':files['compiled/'+q.name]=q
for item in reading['receipts']:
 n=item['number']
 for kind,q in [('notes',C/f'book_notes_v1/note_{n:02d}.md'),('receipts',C/f'book_notes_v1/note_{n:02d}_receipt.json'),('images',W/f'sheet_{n:02d}.png'),('text',W/f'sheet_{n:02d}.txt')]:files[f'actual/{kind}/{q.name}']=q
files['actual/prepared_manifest.json']=W/'manifest.json'
for q in Path('/tmp').glob('GVF_Foundations_*_book_*_20261009.py'):files['helpers/'+q.name]=q
for q in Path('/tmp').glob('GVF_Foundations_underfull_delta_*_20261009.py'):files['helpers/'+q.name]=q
for q in [paths['audit'],paths['reading_notes'],S/programme,S/'README.md']:files['editorial/'+q.name]=q
sourcezip=F/'GVF_Foundations_Complete_Source_Evidence_V1_2026-10-09.zip'
assert sha(sourcezip)=='5229d412499a2fc7d5037fcd21675c9374075388d1550d366bab9b45580fa491'
files['source_owned_records/'+sourcezip.name]=sourcezip
for n in ['actual_complete_source_checkpoint_v1_20261009.json','complete_evidence_export_v1_20261009.json','literal_exact_calibrations_v1_20261009.json','own_complete_source_review_v1_20261009.md','GitHub_complete_source_publication_v1_20261009.json','book_application_locator_addendum_v1_20261009.md']:files['source_owned_records/'+n]=F/n
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
 assert len(z.namelist())==len(set(z.namelist()))==len(files) and z.testzip() is None
 for n,q in files.items():assert z.read(n)==q.read_bytes()
artifacts={k:dict(path=str(q),bytes=q.stat().st_size,SHA256=sha(q)) for k,q in [('full_book_PDF',full),('selected_review_PDF',review),('minimal_TeX_source_archive',minimal),('actual_book_evidence_archive',evidence)]}
artifacts['full_book_PDF']['physical_pages']=4685;artifacts['selected_review_PDF']['physical_pages']=14
artifacts['minimal_TeX_source_archive']['members']=472;artifacts['actual_book_evidence_archive']['members']=len(files)
progress={n:sha(S/n) for n in ['README.md',programme]}
write(paths['manifest'],dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — scoped source/math/mechanical/actual-render gate',preparation=prep,release=release,validation=validation,actual_reading=reading,mathematical_audit=math,underfull_comparison=under,artifacts=artifacts,active_book_changed=False,GitHub_published=False))
write(paths['artifacts'],dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — all export members byte-verified',artifacts=artifacts,actual_final_book_pages=14,fresh_matching_views=7,explicitly_reviewed_blank_versos=[4434],reading_credit_from_export=0,GitHub_published=False))
dest.mkdir(parents=True)
for q in [full,review,minimal,evidence]:shutil.copyfile(q,dest/q.name);assert sha(dest/q.name)==sha(q)
(dest/'SHA256SUMS').write_text(''.join(sha(q)+'  '+q.name+'\n' for q in [full,review,minimal,evidence]))
markdown(dest/'README.md','# GVF representation book artifacts\n\n'+summary+f'\nArtifacts: full 4,685-page PDF, fourteen-page actual review, 472-member minimal\nsource and {len(files)}-member byte-verified authored book evidence. The nested\n64-member source evidence excludes primary PDFs, literal source text and\nprimary-source images. Rendered images in this package are our book pages.\n')
editorial={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in paths.values()}
for p in dest.iterdir():editorial[str(p.relative_to(R))]=dict(bytes=p.stat().st_size,SHA256=sha(p))
write(record,dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — final GVF representation book/evidence export',artifacts=artifacts,editorial_files=editorial,progress_document_hashes=progress,actual_final_book_pages=14,actual_final_matching_views=7,reused_matching_views=0,explicitly_reviewed_blank_versos=[4434],source_evidence_SHA256=sha(sourcezip),source_checkpoint_SHA256=prep['source_checkpoint_SHA256'],source_publication_SHA256=prep['source_publication_SHA256'],book_application_source_repeat_SHA256=prep['book_application_source_repeat_SHA256'],source_locator_addendum_SHA256=prep['source_locator_addendum_SHA256'],active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)))
print(json.dumps(dict(status='EXPORTED',record_SHA256=sha(record),evidence_members=len(files),artifacts=artifacts)))
