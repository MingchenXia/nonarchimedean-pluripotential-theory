# Current book-application locator correction

The number-field normalization statement is **Lemma10.2**, on physical
page38 of arXiv:2409.04570v2, not Definition10.2. The fresh complete
pages37–40 text/image reading confirms the heading, full proof and
normalization ht_Q[r](2)=r log2. Earlier frozen complete-source review,
repeat-source note and scale-diagnostic labels that say Definition10.2
have a locator typo; the scale comparison itself is unchanged. Their
bytes and historical receipts are preserved. The new chapter and provenance
use Lemma10.2. Definition11.8, on physical page43, fixes GVF_e by ht(2)≤e.
The height gauge is ht(x)=h([1:x]), Example11.4 on page41.

The book application's fresh source repeats cover pages31–34,37–44 and
47–48 in seven matching complete-text/image views. They add no new unique
primary-page credit beyond the complete52-page reading. Corollary7.11
retains countable F; Proposition10.5 retains finite-Galois invariance and
the positive-part integrability qualification; Conjecture12.7 remains
OPEN in the cited version. No original-result or current independent
verifier receipt is claimed.
