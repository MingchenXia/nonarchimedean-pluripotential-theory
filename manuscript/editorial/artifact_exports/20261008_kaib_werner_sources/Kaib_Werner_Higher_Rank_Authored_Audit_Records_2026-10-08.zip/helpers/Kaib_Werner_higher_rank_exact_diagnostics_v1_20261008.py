from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction
import hashlib,json,sympy as sp
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Kaib_Werner_higher_rank_review_20261008';out=C/'exact_diagnostics_v1_20261008.json';assert not out.exists()
def vp(a,p):
 a=Fraction(a);assert a
 def k(z):
  z=abs(z);n=0
  while z%p==0:n+=1;z//=p
  return n
 return k(a.numerator)-k(a.denominator)
def val(f,p):
 f={i:Fraction(a) for i,a in f.items() if a};assert f;i=min(f);return (i,vp(f[i],p))
def add(f,g):
 h=f.copy()
 for i,a in g.items():h[i]=h.get(i,Fraction(0))+a
 return {i:a for i,a in h.items() if a}
def mul(f,g):
 h={}
 for i,a in f.items():
  for j,b in g.items():h[i+j]=h.get(i+j,Fraction(0))+a*b
 return {i:a for i,a in h.items() if a}
rows=[]
for p in [5,7,11,13]:
 fs=[{0:Fraction(p)},{0:Fraction(1,p)},{1:Fraction(1,p**8)},{0:Fraction(1),1:Fraction(1,p**3)},{-1:Fraction(p**2),0:Fraction(1)},{0:Fraction(-p),2:Fraction(1)},{2:Fraction(p**4)}]
 checks=0;zeros=0
 for f in fs:
  for g in fs:
   a=val(f,p);b=val(g,p);c=val(mul(f,g),p);assert c==(a[0]+b[0],a[1]+b[1]);h=add(f,g)
   if h:assert val(h,p)>=min(a,b)
   else:zeros+=1
   checks+=1
 rows.append({'prime':p,'Laurent_pair_checks':checks,'zero_sums_handled':zeros,'values':{'p':val({0:Fraction(p)},p),'inverse_p':val({0:Fraction(1,p)},p),'t_over_p_to_8':val({1:Fraction(1,p**8)},p)},'integral_membership_rule':'first coordinate >0, or first=0 and second>=0','K_circ_membership_rule':'first coordinate>=0','scope':'Finite worked arithmetic fixtures, not a proof for all Laurent series.'})
p=sp.symbols('p',positive=True);a=1/(1728*p-1);A=3*a;B=2*a;Delta=sp.factor(-16*(4*A**3+27*B**2));j=sp.factor(1728*4*A**3/(4*A**3+27*B**2));assert sp.simplify(j-1/p)==0 and sp.simplify(Delta+1728**2*p/(1728*p-1)**3)==0
z=sp.symbols('z');residual=sp.expand((z-1)**3-3*(z-1)-2);assert residual==z**3-3*z**2
elliptic={'field':'Q_p((t)), with t-adic real norm, prime p>=5','integral_ring':'Z_p+t Q_p[[t]]','a':str(a),'Weierstrass_A':str(A),'Weierstrass_B':str(B),'Delta':str(Delta),'j':str(j),'zero_symbolic_j_residual':str(sp.simplify(j-1/p)),'t_adic_Delta_valuation':0,'composed_j_value':[0,-1],'p_adic_Delta_valuation':1,'residual_equation':'y^2=(x+1)^2(x-2); at z=x+1 tangent y^2=-3z^2','split_residual_node_for_p_7':True,'t_adic_good_model_reason':'The nonzero constant discriminant is a unit in Q_p[[t]].','failure_of_good_K_plus_reduction_input':'Only the standard necessary integrality of j for good reduction is used, as an attributed elliptic-model criterion. The worked curve alone is not a proof of every abstract reduction criterion.','source_example_scope':'Source Example 6.14 assumes algebraically closed K for the full iff and component-group classifications; no such full classification is claimed over Q_p((t)).'}
obj={'UTC':datetime.now(timezone.utc).isoformat(),'status':'DONE — composed-value and elliptic worked diagnostics','source':'2610.01354v1, Examples 2.1 and 6.14','valuation_fixtures':rows,'elliptic_fixture':elliptic,'valuation_ring_structure':{'rank':'2','prime_chain':'(0) < t Q_p[[t]] < p Z_p+t Q_p[[t]]','rank_one_coarsening':'Q_p[[t]]','residual_valuation_ring':'Z_p','Spa_points':2,'Spec_points':3,'nonfinite_generation_argument':'For any finite nonzero generators of t Q_p[[t]], choose t/p^N with smaller lexicographic value than the minimum generator value.'},'no_real_order_embedding_argument':'If the lexicographic (0,1) has positive real image b, the image of (1,0) would exceed nb for every n, which is impossible. The rank-one coarsening sends the second direction to zero.','source_hypothesis_boundary':'The worked ring has a DVR residual valuation ring, allowing the source strong-marked-model alternative after its required finite extension, but its closed residue F_p is not algebraically closed, so Theorem 5.7 is not applied unchanged.','original_general_results_promoted':[],'independent_model_receipt':None,'book_changed':False,'canonical_status_changes':[],'helper_source':__file__};out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':obj['status'],'SHA256':hashlib.sha256(out.read_bytes()).hexdigest(),'elliptic':elliptic,'finite_pair_checks':sum(x['Laurent_pair_checks'] for x in rows)},ensure_ascii=False))
