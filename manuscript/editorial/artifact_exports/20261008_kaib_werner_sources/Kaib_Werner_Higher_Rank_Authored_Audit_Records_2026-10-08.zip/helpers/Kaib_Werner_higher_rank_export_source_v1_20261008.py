# Frozen adapted template SHA256: 2f6270556aed1b0bcbfcea89c5d63428dccd30fe867d8b231274db36c46351ea
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,zipfile,shutil
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Kaib_Werner_higher_rank_review_20261008';S=R/'source_material/Kaib_Werner_higher_rank_sources_20261008';E=R/'manuscript/editorial';W=Path('/tmp/Kaib_Werner_higher_rank_primary_views_v1_20261008');O=Path('/workspace/book-completion-drafts/research-integration');out=C/'source_export_v1_20261008.json';assert not out.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
cp=C/'source_checkpoint_v2_20261008.json';assert sha(cp)=='195fd00f450477cf5eeecd9f6b399133e54241d04441872257bba724e557f131';obj=json.loads(cp.read_text())
for p,h in obj['protected_core_inputs'].items():assert sha(Path(p))==h
editorial=[Path(p) for p,h in obj['editorial_files'].items()];assert all(sha(p)==obj['editorial_files'][str(p)] for p in editorial)
cache=[p for p in C.rglob('*') if p.is_file()];helpers=sorted(Path('/tmp').glob('Kaib_Werner_higher_rank_*_20261008.py'))
full={f'primary/{p.name}':p for p in S.iterdir() if p.is_file()}
full.update({f'actual_views/{p.name}':p for p in W.iterdir() if p.is_file()})
full.update({f'authored_records/{p.relative_to(C)}':p for p in cache});full.update({f'editorial/{p.name}':p for p in editorial});full.update({f'helpers/{p.name}':p for p in helpers})
authored={f'authored_records/{p.relative_to(C)}':p for p in cache};authored.update({f'editorial/{p.name}':p for p in editorial});authored.update({f'helpers/{p.name}':p for p in helpers})
def export(path,items):
 assert not path.exists()
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,p in sorted(items.items()):z.write(p,name)
 with zipfile.ZipFile(path) as z:
  assert sorted(z.namelist())==sorted(items)
  for name,p in items.items():assert z.read(name)==p.read_bytes(),name
 return dict(path=str(path),bytes=path.stat().st_size,SHA256=sha(path),members=len(items),members_byte_verified=True)
fullzip=export(O/'Kaib_Werner_Higher_Rank_Actual_Source_Evidence_2026-10-08.zip',full)
authzip=export(O/'Kaib_Werner_Higher_Rank_Authored_Audit_Records_2026-10-08.zip',authored)
review=O/'Kaib_Werner_Higher_Rank_Actual_Source_Review_2026-10-08.pdf';assert not review.exists();shutil.copy2(S/'Kaib_Werner_abeloid_higher_rank_arxiv_v1.pdf',review)
D=E/'artifact_exports/20261008_kaib_werner_sources';assert not D.exists();D.mkdir()
p=D/Path(authzip['path']).name;shutil.copy2(authzip['path'],p);assert sha(p)==authzip['SHA256']
(D/'SHA256SUMS').write_text(sha(p)+'  '+p.name+'\n')
(D/'README.md').write_text('''# Kaib–Werner higher-rank integral-data source audit, 8 October 2026

The authored archive records the complete 24-page arXiv:2610.01354v1 reading in twelve individually displayed matching views and twelve sequential notes. The pinned primary source was posted 1 October 2026: https://arxiv.org/abs/2610.01354v1.

The archive contains authored notes, receipts, actual-reading/hash records, four editorial audit files and acquisition/diagnostic helpers. The original primary PDF, extracted full text, matching images and complete source evidence archive remain in the cloud cache. They are not included in this repository upload.

The source keeps a complete real-valued rank-one topology and adds a possibly higher-rank integral valuation ring. The notes distinguish proper analytic recovery, compatible formal-model gluing, generically good versus good reduction, and full algebraic/marked formal/strong marked Neron mapping domains. The exact composed-value and elliptic diagnostics preserve every source hypothesis. External foundation proofs are not recursively certified, and no new original general theorem or independent-model receipt is claimed.

The text-extraction font mismatch warning is preserved. All actual displayed sheets were readable and matched their selected text; the algebraic/calligraphic formal component groups were distinguished visually. A failed initial checkpoint assertion used a mistyped baseline hash and is retained with zero extra reading credit; the corrected v2 checkpoint preserves the exact preceding validated PDF.

The active validated book remains the 4,634-page edition at this source checkpoint. SHA256SUMS pins the archive; every member was byte-verified. Export/upload gives zero extra reading credit. The 42 atoms/twelve formal problems are unchanged; general BJ22 critical homogeneous Siu division/envelopes remain OPEN and LPWZ density remains UNVERIFIED. This is not a new whole-book pass.
''')
record=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — source archives byte-verified; repository upload still pending at this export',full_source_evidence=fullzip,authored_source_evidence=authzip,source_review_PDF=dict(path=str(review),bytes=review.stat().st_size,SHA256=sha(review),physical_pages=24),repository_artifact_directory=str(D.relative_to(R)),repository_artifact_files={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in sorted(D.iterdir())},external_primary_artifact_upload=False,actual_source_pages=24,actual_images=12,external_foundation_proofs_recursively_certified=False,export_reading_credit=0,canonical_status_changes=[],GitHub_published=False,helper_source=__file__)
out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
for p,h in obj['protected_core_inputs'].items():assert sha(Path(p))==h
print(json.dumps(dict(status=record['status'],record_SHA256=sha(out),full_source_evidence=fullzip,authored_source_evidence=authzip,repository_artifact_directory=record['repository_artifact_directory'])))
