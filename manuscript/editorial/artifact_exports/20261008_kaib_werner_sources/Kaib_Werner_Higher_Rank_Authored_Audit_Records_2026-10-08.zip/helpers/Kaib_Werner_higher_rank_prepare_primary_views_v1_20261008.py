# Frozen full-primary-view template SHA256: 5fa950bd537666b1f8e13e7350f8fac63eb6a5c574c548cdf4bdbc08683168d6
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,fitz
from PIL import Image,ImageDraw
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Kaib_Werner_higher_rank_review_20261008';S=R/'source_material/Kaib_Werner_higher_rank_sources_20261008';W=Path('/tmp/Kaib_Werner_higher_rank_primary_views_v1_20261008');notes=C/'primary_notes_v1';out=C/'primary_view_preparation_v1_20261008.json'
assert not any(p.exists() for p in [W,notes,out]);W.mkdir();notes.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pdf=S/'Kaib_Werner_abeloid_higher_rank_arxiv_v1.pdf';assert sha(pdf)=='9ae097d31c49941e5a80b6f7631163bfb24e9d83a6c11be7838bb60363ee89ec';doc=fitz.open(pdf);assert len(doc)==24
views=[]
for i in range(0,len(doc),2):
 pages=list(range(i+1,min(i+3,len(doc)+1)));panels=[];texts=[]
 for n in pages:
  pix=doc[n-1].get_pixmap(matrix=fitz.Matrix(1.45,1.45),alpha=False);panels.append(Image.frombytes('RGB',[pix.width,pix.height],pix.samples));texts.append(f'KAIB WERNER HIGHER RANK ABELOIDS 2610.01354v1 PHYSICAL PAGE {n}\n'+doc[n-1].get_text())
 canvas=Image.new('RGB',(sum(p.width for p in panels),max(p.height for p in panels)+28),'white');draw=ImageDraw.Draw(canvas);x=0
 for n,p in zip(pages,panels):draw.text((x+8,8),f'Kaib--Werner 2610.01354v1 physical page {n}',fill='black');canvas.paste(p,(x,28));x+=p.width
 number=i//2+1;ip=W/f'sheet_{number:02d}.png';tp=W/f'sheet_{number:02d}.txt';canvas.save(ip);tp.write_text('\n\n'.join(texts))
 views.append(dict(number=number,physical_pages=pages,path=str(ip),image_SHA256=sha(ip),selected_text_path=str(tp),selected_text_SHA256=sha(tp),source_PDF_SHA256=sha(pdf),actually_viewed=False,selected_text_read=False))
mp=W/'manifest.json';mp.write_text(json.dumps(views,indent=2)+'\n');obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete-primary view preparation; zero reading credit',source_PDF=dict(path=str(pdf),SHA256=sha(pdf),physical_pages=24),prepared_pages=24,prepared_views=12,manifest_path=str(mp),manifest_SHA256=sha(mp),actual_source_reading_credit=0,actually_read_pages=0,active_book_changed=False,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status=obj['status'],pages=24,views=12,record_SHA256=sha(out))))
