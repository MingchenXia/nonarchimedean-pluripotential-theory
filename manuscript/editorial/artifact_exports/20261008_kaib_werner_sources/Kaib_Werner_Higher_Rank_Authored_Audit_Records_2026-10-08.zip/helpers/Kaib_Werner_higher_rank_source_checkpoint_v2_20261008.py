# Failed v1 helper frozen SHA256: 422bb99965531c3c38fcc3f79fe8ceaf737b9419255c6621fa0a3bf5ef545dff
# Frozen adapted template SHA256: 7b451181943516e238bb2d54d67ab5e7045652d2bbc4b8ba2d7c300c9874120c
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
R=Path('/workspace/nonarchimedean-pluripotential-theory');M=R/'manuscript';E=M/'editorial';C=R/'source_material/Kaib_Werner_higher_rank_review_20261008';out=C/'source_checkpoint_v2_20261008.json';assert not out.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths={k:E/f'Kaib_Werner_higher_rank_{k}_20261008.{ext}' for k,ext in [('source_review','md'),('source_reading_notes','md'),('source_reading_manifest','json'),('source_artifacts','json')]};assert paths['source_review'].exists() and paths['source_reading_notes'].exists() and not any(paths[k].exists() for k in ['source_reading_manifest','source_artifacts'])
actual=C/'actual_primary_reading_v1_20261008.json';a=json.loads(actual.read_text());assert sha(actual)=='61bfc6372821e5b6d83e2a3e01776e5f2c242e25128beda580d577de982d931e' and a['actual_distinct_source_page_pairs']==24
prep=C/'primary_view_preparation_v1_20261008.json';assert sha(prep)=='552262e6ac6c9945c3d432e8e0fb4e3a26bbe8c533192e4a10212a5986c856a7'
diag=C/'exact_diagnostics_v1_20261008.json';assert sha(diag)=='3f0768f67482d6c1ab95dd62a355c6168266b32782292a2a7e8f073b69eead23'
notes='# Actual sequential Kaib–Werner arXiv v1 source notes, 8 October 2026\n\nAll 24 pages in twelve individually displayed matching views. The controlling source is arXiv:2610.01354v1, 1 October 2026. External foundation proofs are not recursively certified. The extraction font warning is preserved; algebraic and calligraphic formal component-group notation was distinguished on the displayed images.\n'
for n in a['actual_observations']:notes+='\n---\n\n'+Path(n['note_path']).read_text()
assert paths['source_reading_notes'].read_text()==notes
core=set()
for line in (M/'book.fls').read_text().splitlines():
 if line.startswith('INPUT '):
  p=Path(line[6:]);p=(p if p.is_absolute() else M/p).resolve()
  if p.is_relative_to(M) and p.suffix=='.tex':core.add(p)
assert len(core)==425;core.update((M/'bibliography').glob('*.bib'));assert len(core)==427
core.update([M/'book.pdf',R/'output/open_problems_catalogue_2026-10-03.tex',R/'output/open_problems_catalogue_2026-10-03.pdf']);protected={str(p):sha(p) for p in sorted(core)}
assert sha(M/'book.pdf')=='1289dc2e1bbab09036b0d14f98cb2be2cf35a38d5a0a7e3397e8e536a5636964'
manifest=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete primary reading and exact scoped diagnostics; source theorem hypotheses retained',actual_ledger_path=str(actual),actual_ledger_SHA256=sha(actual),actual_record=a,source_audit_SHA256=sha(paths['source_review']),exact_diagnostic_path=str(diag),exact_diagnostic_SHA256=sha(diag),extraction_warning='Syntax Warning: Mismatch between font type and embedded font file',all_actual_views_readable_and_matching=True,external_foundation_proofs_recursively_certified=False,whole_book_new_reading_claim=False,active_book_changed=False,canonical_status_changes=[],GitHub_published=False)
paths['source_reading_manifest'].write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
helpers=[p for p in Path('/tmp').glob('Kaib_Werner_higher_rank_*_20261008.py') if p.name!='Kaib_Werner_higher_rank_source_checkpoint_v1_20261008.py']+[Path(__file__)]
files=[p for name in ['Kaib_Werner_higher_rank_sources_20261008','Kaib_Werner_higher_rank_review_20261008'] for p in (R/'source_material'/name).rglob('*') if p.is_file()]
artifacts=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — cloud source checkpoint before authorized publication',files=[dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p)) for p in sorted(files)],helpers={str(p):sha(p) for p in sorted(helpers)},editorial_files={str(p):sha(p) for k,p in paths.items() if k!='source_artifacts'},protected_core_inputs=protected,active_TeX_inputs_preserved=425,bibliographies_preserved=2,native_catalogue_preserved=True,book_PDF_preserved=True,external_foundation_proofs_recursively_certified=False,reading_credit_from_exports=0,GitHub_published=False)
paths['source_artifacts'].write_text(json.dumps(artifacts,ensure_ascii=False,indent=2)+'\n')
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — cloud source checkpoint; subsequent publication must have its own record',baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),editorial_files={str(p):sha(p) for p in paths.values()},protected_core_inputs=protected,actual_source_pages=24,actual_images=12,actual_primary_reading_SHA256=sha(actual),exact_diagnostics_SHA256=sha(diag),unqualified_general_uniformization_or_Neron_theorem_admitted=False,active_book_changed=False,GitHub_published=False,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
for p,h in protected.items():assert sha(Path(p))==h
print(json.dumps(dict(status=obj['status'],checkpoint_SHA256=sha(out),editorial_files=len(paths),protected_inputs=len(protected))))
