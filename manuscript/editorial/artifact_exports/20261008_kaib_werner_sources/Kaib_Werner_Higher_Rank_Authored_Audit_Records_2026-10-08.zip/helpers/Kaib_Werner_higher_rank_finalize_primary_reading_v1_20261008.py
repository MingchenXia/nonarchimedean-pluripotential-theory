# Frozen primary-finalization template SHA256: 9375c46156c8b1d57e701d8af2eb811267727bd920786a9dc68231246a07b8cc
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Kaib_Werner_higher_rank_review_20261008';W=Path('/tmp/Kaib_Werner_higher_rank_primary_views_v1_20261008');out=C/'actual_primary_reading_v1_20261008.json';assert not out.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
prep=C/'primary_view_preparation_v1_20261008.json';expected='552262e6ac6c9945c3d432e8e0fb4e3a26bbe8c533192e4a10212a5986c856a7';assert sha(prep)==expected
prepared=json.loads(prep.read_text());assert prepared['actually_read_pages']==0 and prepared['actual_source_reading_credit']==0
manifest=json.loads((W/'manifest.json').read_text());assert len(manifest)==12 and all(x['actually_viewed'] is False and x['selected_text_read'] is False for x in manifest)
notes=[];pages=[]
for i,row in enumerate(manifest,1):
 p=C/'primary_notes_v1'/f'note_{i:02d}_receipt.json';note=json.loads(p.read_text());assert note['number']==i and note['physical_pages']==row['physical_pages'] and note['source_PDF_SHA256']==prepared['source_PDF']['SHA256'];assert note['complete_selected_text_actually_read'] and note['matching_image_individually_displayed_and_reviewed'];assert sha(Path(note['note_path']))==note['note_SHA256'];assert sha(Path(note['image_path']))==note['image_SHA256'];assert sha(Path(note['selected_text_path']))==note['selected_text_SHA256']
 notes.append(dict(receipt_path=str(p),receipt_SHA256=sha(p),**note));pages.extend(note['physical_pages'])
assert pages==list(range(1,25));assert sha(R/'manuscript/book.pdf')=='1289dc2e1bbab09036b0d14f98cb2be2cf35a38d5a0a7e3397e8e536a5636964'
obj=dict(status='DONE — complete pinned 24-page primary read in 12 matching individual views and sequential notes',UTC=datetime.now(timezone.utc).isoformat(),source_PDF=prepared['source_PDF'],actual_distinct_source_page_pairs=24,actual_matching_images=12,actual_sequential_notes=12,actual_read_pages=pages,actual_observations=notes,prepared_flags_preserved=False if sha(prep)!=expected else True,preparation_record_SHA256=sha(prep),general_uniformization_Neron_theorems_recursively_certified=False,extraction_warning_preserved=True,all_image_text_pairs_readable_with_no_detected_content_loss=True,independent_model_receipt_claimed=False,canonical_status_changes=[],active_book_changed=False,last_whole_book_pass='2026-10-04',reading_credit_from_exports_or_uploads=0,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status=obj['status'],record_SHA256=sha(out),pages=24,images=12)))
