# Precision addendum to frozen source notes, 9 October 2026

Note 12's description of the Luo citation is corrected as explained in note 13: on page 23, [19, Remark 5.7] supports the preceding birational-bigness clause. It is not a citation for the subsequent small-section implication. The small-section claim needs its own justification, and is not attributed to Luo's remark without reading that primary text.

Reference [19] is Wenbin Luo, Continuous extension and birational invariance of chi-volume over an adelic curve, European Journal of Mathematics 11 (2025), Paper 33, 28 pages. It is distinct from the metadata-only relative-bigness lead arXiv:2112.13206. Neither full primary has been read in this audit. No reading credit is inferred from the bibliography.

The source's all-places small-section failure in Example 4.4 is distinguished from its subsequent nonexistence of an ample/small-residual decomposition. The finite norm calculation supports the former. The latter uses a stronger all-places norm condition that is not the arithmetic ampleness definition on page 11. The separate reconstruction keeps this difference explicit.

The page-27 internal date 27 January 2026 is distinct from the controlling v4 metadata date 25 January 2026. No later journal full text or earlier arXiv version is read or diagnosed by this review. Frozen notes and receipts are preserved unchanged.
