from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as Q
from math import comb,factorial
import hashlib,json,sympy as sp
D=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Arithmetic_Fujita_adelic_curves_review_20261009/LiuArxivV4')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prep=json.loads((D/'scope_preparation_v1_20261009.json').read_text());receipts=[];pages=[]
for n,x in enumerate(prep['entries'],1):
 note=D/f'primary_notes_v1/note_{n:02d}.md';p=note.with_suffix('.json');r=json.loads(p.read_text())
 assert r['number']==n and r['physical_pages']==x['physical_pages'] and r['complete_text_actually_read'] and r['matching_image_actually_viewed']
 assert sha(note)==r['note_SHA256'] and sha(x['image_path'])==r['image_SHA256'] and sha(x['text_path'])==r['text_SHA256']
 assert r['PDF_SHA256']==prep['PDF_SHA256']==sha(prep['PDF'])
 assert r['previous_receipt_SHA256']==(receipts[-1]['receipt_SHA256'] if n>1 else None)
 receipts.append(dict(number=n,pages=x['physical_pages'],note_SHA256=sha(note),receipt_SHA256=sha(p)));pages.extend(x['physical_pages'])
assert pages==list(range(1,28)) and len(receipts)==14
counters={};witnesses=[]
for r in range(1,65):
 degree=Q(r);moment=Q(1);correct=Q(r)*moment
 assert degree==correct
 if r>1:assert degree-moment>0
counters['constant_weight_rank_tests']=64;counters['literal_missing_rank_failures']=63
witnesses.append(dict(locator='Proposition3.6 p13',rank=2,positive_degree='2',probability_positive_moment='1',archimedean_error='0',literal_difference='1',corrected_difference='0'))
N=sp.symbols('N',positive=True);cs=[Q(1,4),Q(1,2),Q(1),Q(3,2),Q(2)]
finite_count=0;limit_count=0
for d in range(7):
 rankpoly=sp.prod(N+j for j in range(1,d+1))/factorial(d)
 for c in cs:
  C=sp.Rational(c.numerator,c.denominator)
  correct=sp.cancel(factorial(d+1)*rankpoly*N*C/N**(d+1))
  printed=sp.cancel((d+1)*factorial(d+1)*rankpoly*C/N**(d+1))
  assert sp.limit(correct,N,sp.oo)==(d+1)*C and sp.limit(printed,N,sp.oo)==0;limit_count+=1
  for n in range(1,65):
   rank=comb(n+d,d);total=rank*n*c;rescaled=c
   assert Q(total*factorial(d+1),n**(d+1))==Q(n*rank*factorial(d+1),n**(d+1))*rescaled;finite_count+=1
counters['exact_finite_degree_factorial_checks']=finite_count;counters['symbolic_correct_vs_printed_limits']=limit_count
witnesses.append(dict(locator='Proposition4.5 StepIII p20',model='P1 with constant positive weight c=1',rank='N+1',rescaled_positive_moment='1',printed_limit='0',corrected_arithmetic_volume='2',consistent_finite_expression='N rank moment / (N^(d+1)/(d+1)!)'))
vc=0;vf=0
for d in range(7):
 for c in cs:
  base=(d+1)*c
  for p in range(1,13):
   G=base*p**(d+1);veronese=G;normalized=G/Q(p**(d+1))
   assert normalized==base and veronese/Q(p**(d+1))==base
   if p>1:assert normalized<veronese;vf+=1
   vc+=1
counters['Veronese_scaling_cases']=vc;counters['mixed_convention_inequality_failures']=vf
weights=[Q(1,2),Q(1,2),Q(-3,4)];C=sum(weights);assert C==Q(1,4)
for n in range(1,65):
 assert (n+1)*n*C==Q(n*(n+1),4)
 assert -n*weights[2]>0
counters['three_place_positive_degree_and_no_small_power_cases']=64
ampcases=[]
for p in range(2,66):
 a_degree=p-1;a_constants=[p*x for x in weights];m_degree=1;m_constants=[Q(0)]*3
 assert a_degree+m_degree==p and all(a+b==p*x for a,b,x in zip(a_constants,m_constants,weights))
 aC=sum(a_constants);assert aC>0
 volumeA=2*a_degree*aC;volumeLpower=2*p*p*C
 assert volumeA==Q(p*(p-1),2) and volumeLpower==Q(p*p,2)
 normalized=volumeA/Q(p*p);error=2*C-normalized;assert error==Q(1,2*p)>0
 amp_cases_row=dict(p=p,A_underlying_degree=a_degree,A_total_metric_shift=str(aC),M_underlying_degree=1,M_total_metric_shift='0',M_small_section='x0; every-place norm1',normalized_ample_volume=str(normalized),error=str(error));ampcases.append(amp_cases_row)
counters['explicit_nontrivial_ample_small_residual_decompositions']=len(ampcases)
witnesses.append(dict(locator='Example4.4 p18',field='Q with three unit-weight trivial places',constants=list(map(str,weights)),total_shift='1/4',arithmetic_volume='1/2',asymptotic_minimal_slope='1/4',no_nonzero_positive_power_small_at_all_places=True,nonexistence_inference_correct=False,nontrivial_p2_decomposition=ampcases[0],normalized_volume_error_sequence='1/(2p)'))
tails=0
for r in range(1,65):
 S=sorted([Q((j*7)%29-12,4) for j in range(r)],reverse=True);T=S[::2]
 cuts=[Q(0)]+[Q(2*j+1,8) for j in range(1,17)]
 def h(x):return sum((cuts[i]-cuts[i-1]) for i in range(1,len(cuts)) if x>=cuts[i])
 for t in cuts:assert sum(x>=t for x in T)>=Q(1,2)*sum(x>=t for x in S)
 assert sum(max(x,Q(0)) for x in T)>=Q(1,2)*sum(h(x) for x in S)
 tails+=1
counters['finite_rank_tail_and_Abel_lower_step_checks']=tails
p=D/'literal_exact_calibrations_v1_20261009.json';assert not p.exists()
p.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='PASS — own exact finite diagnostics and symbolic normalization limits; not a universal theorem verifier',source_version='2401.15271v4',PDF_SHA256=prep['PDF_SHA256'],counts=counters,witnesses=witnesses,explicit_decompositions=ampcases,main_Fujita_independently_verified=False,main_result_refuted=False,independent_original_receipt=False,book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
q=D/'actual_complete_source_checkpoint_v1_20261009.json';assert not q.exists()
q.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — actual full pinned primary-source reading, ordinary scoped proof audit still requires reconstruction',source_version='arXiv:2401.15271v4, 25 January2026',internal_footer_date='27 January2026',PDF=prep['PDF'],PDF_SHA256=prep['PDF_SHA256'],physical_pages_read=pages,unique_physical_pages=27,full_source_read=True,fresh_matching_views=14,reused_matching_views=0,receipts=receipts,preparation_SHA256=sha(D/'scope_preparation_v1_20261009.json'),acquisition_SHA256=sha(D/'source_acquisition_v1_20261009.json'),normalization_calibration_SHA256=sha(p),frozen_note_precision_addendum_SHA256=sha(D/'own_reading_note_precision_addendum_v1_20261009.md'),main_Fujita_status='UNVERIFIED FOR BOOK IMPORT — norm/slope, analytic-point, degree and approximation reconstruction required',main_result_refuted=False,deeper_primary_dependencies_recursively_verified=False,other_arxiv_versions_or_later_journal_read=False,source_upload_primary_text_images=False,active_book_changed=False,native_editor_changed=False,original_results_promoted=[],canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(full_pages=27,fresh_views=14,checkpoint_SHA256=sha(q),calibrations_SHA256=sha(p),counts=counters)))
