from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,fitz
from PIL import Image
D=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Arithmetic_Fujita_adelic_curves_review_20261009/LiuArxivV4')
W=Path('/tmp/Liu_adelic_Fujita_primary_views_v1_20261009');assert not W.exists();W.mkdir()
pdf=D/'Liu_Arithmetic_Fujita_2401.15271v4.pdf';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
entries=[]
with fitz.open(pdf) as doc:
    for start in range(0,len(doc),2):
        numbers=list(range(start,min(start+2,len(doc))));panels=[];texts=[]
        for n in numbers:
            pix=doc[n].get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False)
            panels.append(Image.frombytes('RGB',(pix.width,pix.height),pix.samples))
            texts.append('PHYSICAL PAGE '+str(n+1)+'\n'+doc[n].get_text())
        canvas=Image.new('RGB',(sum(x.width for x in panels),max(x.height for x in panels)),'white')
        offset=0
        for im in panels:canvas.paste(im,(offset,0));offset+=im.width
        k=start//2+1;p=W/('sheet_'+str(k).zfill(2)+'.png');t=p.with_suffix('.txt')
        canvas.save(p);t.write_text('\n\f\n'.join(texts))
        entries.append(dict(number=k,physical_pages=[n+1 for n in numbers],image_path=str(p),image_SHA256=sha(p),text_path=str(t),text_SHA256=sha(t),actual_image_viewed=False,actual_complete_text_read=False))
out=D/'scope_preparation_v1_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='MECHANICAL PREPARATION — no reading credit',PDF=str(pdf),PDF_SHA256=sha(pdf),physical_pages=27,entries=entries,helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
print(json.dumps(dict(prepared_views=len(entries),physical_pages=27,manifest_SHA256=sha(out))))
