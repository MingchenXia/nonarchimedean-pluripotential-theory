from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile,shutil
R=Path('/workspace/nonarchimedean-pluripotential-theory');E=R/'manuscript/editorial'
D=R/'source_material/Arithmetic_Fujita_adelic_curves_review_20261009/LiuArxivV4'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cp=json.loads((D/'actual_complete_source_checkpoint_v1_20261009.json').read_text())
assert cp['full_source_read'] and cp['physical_pages_read']==list(range(1,28)) and cp['fresh_matching_views']==14
assert sha(cp['PDF'])==cp['PDF_SHA256'] and cp['main_result_refuted']==False
files={}
for n in range(1,15):
 for ext in ['md','json']:
  p=D/f'primary_notes_v1/note_{n:02d}.{ext}';files[f'actual_notes/{p.name}']=p
for n in ['source_acquisition_v1_20261009.json','scope_preparation_v1_20261009.json','literal_exact_calibrations_v1_20261009.json','actual_complete_source_checkpoint_v1_20261009.json','calibration_helper_failure_v1_20261009.json']:
 files['owned_records/'+n]=D/n
for n in ['own_reading_note_precision_addendum_v1_20261009.md','own_complete_source_review_v1_20261009.md','own_three_place_model_reconstruction_v1_20261009.md']:
 files['owned_reviews/'+n]=D/n
for n in ['Liu_adelic_Fujita_acquire_v1_20261009.py','Liu_adelic_Fujita_prepare_source_views_v1_20261009.py','Liu_adelic_Fujita_record_source_note_v1_20261009.py','Liu_adelic_Fujita_record_complete_source_and_calibrations_v1_20261009.py','Liu_adelic_Fujita_record_complete_source_and_calibrations_v2_20261009.py',Path(__file__).name]:files['frozen_owned_helpers/'+n]=Path('/tmp')/n
p=Path('/workspace/book-completion-drafts/GVF_related_source_metadata_v1_20261009.json');files['owned_records/'+p.name]=p
assert len(files)==43 and all(p.exists() for p in files.values())
archive=D/'Liu_Adelic_Fujita_Complete_Source_Evidence_V1_2026-10-09.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,p in sorted(files.items()):z.write(p,n)
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==len(set(z.namelist()))==43 and z.testzip() is None
 for n,p in files.items():assert z.read(n)==p.read_bytes()
paths={k:E/f'Liu_adelic_Fujita_complete_source_{k}_v1_20261009.{ext}' for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
dest=E/'artifact_exports/20261009_Liu_adelic_Fujita_complete_v1';record=D/'complete_evidence_export_v1_20261009.json'
assert not any(p.exists() for p in [*paths.values(),dest,record])
paths['review'].write_bytes((D/'own_complete_source_review_v1_20261009.md').read_bytes())
paths['reading_notes'].write_text('# Actual full Liu adelic Fujita v4 reading\n\nAll 27 physical pages in fourteen ordered complete-text/image views.\n\n'+ '\n\n---\n\n'.join((D/f'primary_notes_v1/note_{n:02d}.md').read_text() for n in range(1,15))+'\n\n---\n\n'+(D/'own_reading_note_precision_addendum_v1_20261009.md').read_text())
rows={n:dict(bytes=p.stat().st_size,SHA256=sha(p)) for n,p in files.items()}
common=dict(UTC=datetime.now(timezone.utc).isoformat(),status='EXPORTED — 43 author-owned members individually byte-verified',archive=dict(path=str(archive),bytes=archive.stat().st_size,SHA256=sha(archive),members=43),actual_source_checkpoint_SHA256=sha(D/'actual_complete_source_checkpoint_v1_20261009.json'),actual_unique_primary_pages=27,actual_matching_views=14,source_PDF_SHA256=cp['PDF_SHA256'],calibration_SHA256=sha(D/'literal_exact_calibrations_v1_20261009.json'),direct_classical_model_reconstruction_SHA256=sha(D/'own_three_place_model_reconstruction_v1_20261009.md'),source_proof_main_status=cp['main_Fujita_status'],main_result_refuted=False,original_results_promoted=[],independent_production_receipt=None,deeper_imports_recursively_verified=False,canonical_status_changes=[],active_book_changed=False,native_editor_changed=False,primary_PDF_text_images_excluded=True,reading_credit_from_export=0,GitHub_published=False,helper_source=__file__,helper_SHA256=sha(__file__))
paths['manifest'].write_text(json.dumps(dict(**common,members=rows,complete_actual_reading=cp),ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(common,ensure_ascii=False,indent=2)+'\n')
dest.mkdir(parents=True);shutil.copyfile(archive,dest/archive.name);assert sha(dest/archive.name)==sha(archive)
(dest/'SHA256SUMS').write_text(sha(archive)+'  '+archive.name+'\n')
(dest/'README.md').write_text('''# Complete Liu adelic Fujita v4 source evidence

All 27 physical pages of arXiv:2401.15271v4, 25 January 2026, were
actually read in fourteen ordered matching complete-text/image displays.
The last internal footer says 27 January and is kept separate. The
43-member archive contains our reading notes, receipts, source/scope
records, exact finite/symbolic diagnostics, complete authored review,
direct three-place projective model reconstruction and frozen helpers.
Every member was compared byte-for-byte. Primary PDF, literal full text,
source pixels and supplied executable material are excluded.

The general main statement is UNVERIFIED FOR BOOK IMPORT, pending
original-versus-spectral norm, analytic-point, Veronese normalization and
approximation reconstruction. Its intended conclusion is not refuted by
this audit. The three-place model separates global positive arithmetic
volume from existence of simultaneously small sections and has explicit
nontrivial ample/small-residual decompositions. The zero-dimensional
floating-point helper failure and corrected exact helper remain frozen.
No deeper recursive primary verification or original production receipt
is claimed. Other versions and later journal full text remain unread.

The active 4,685-page book, native catalogue/editor and all canonical
42-atom/twelve-problem statuses are unchanged by this source-only audit.
BJ22 general homogeneous Siu/envelopes remain OPEN, LPWZ density
UNVERIFIED. Export/upload adds no reading credit or theorem clearance.
Work remains cloud-only with Xean suspended.
''')
owned=[*paths.values(),*dest.iterdir()]
editorial={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in owned};assert len(editorial)==7
record.write_text(json.dumps(dict(**common,editorial_files=editorial,members=rows),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(evidence_members=43,evidence_SHA256=sha(archive),export_SHA256=sha(record),editorial_files=7)))
