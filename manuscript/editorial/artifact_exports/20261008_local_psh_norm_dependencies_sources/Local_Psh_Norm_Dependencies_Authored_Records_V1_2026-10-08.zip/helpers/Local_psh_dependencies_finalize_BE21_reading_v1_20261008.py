from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/local_psh_dependencies_review_20261008'
out=C/'actual_BE21_selected_reading_v1_20261008.json';assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sets=[('BE21_view_preparation_v2_20261008.json',C/'BE21_primary_notes_v2'),('BE21_supplement_view_preparation_v1_20261008.json',C/'BE21_supplement_notes_v1')]
views=[];pages=[];pins={}
for label,N in sets:
 p=C/label;prep=json.loads(p.read_text());pins[label]=sha(p)
 assert prep['actual_source_reading_credit']==0 and prep['actually_read_pages']==0
 assert sha(prep['source_PDF']['path'])==prep['source_PDF']['SHA256']
 manifest=Path(prep['manifest_path']);assert sha(manifest)==prep['manifest_SHA256']
 rows=json.loads(manifest.read_text());assert len(rows)==prep['prepared_views']
 for n,row in enumerate(rows,1):
  receipt=N/f'note_{n:02d}_receipt.json';a=json.loads(receipt.read_text())
  assert a['number']==n and a['physical_pages']==row['physical_pages']
  assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
  for pathkey,hashkey in [('image_path','image_SHA256'),('selected_text_path','selected_text_SHA256'),('note_path','note_SHA256')]:assert sha(a[pathkey])==a[hashkey]
  assert a['source_PDF_SHA256']==prep['source_PDF']['SHA256']==row['source_PDF_SHA256']
  assert not row['actually_viewed'] and not row['selected_text_read']
  note=Path(a['note_path']).read_text();assert 'Read the complete selected text and displayed matching rendered image.' in note
  views.append(dict(batch=label,**a,observation_receipt_path=str(receipt),observation_receipt_SHA256=sha(receipt)))
  pages.extend(row['physical_pages'])
 for n,h in prep['protected_core_inputs'].items():assert sha(R/n)==h
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==prep['baseline_commit']
assert len(views)==15 and len(pages)==len(set(pages))==29
d=C/'exact_norm_diagnostics_v1_20261008.json';diag=json.loads(d.read_text())
assert diag['status'].startswith('DONE') and len(diag['checks'])==5 and all(x['status']=='PASS' for x in diag['checks'])
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — twenty-nine actual selected published-source pages; partial PDF reading',source_PDF=json.loads((C/sets[0][0]).read_text())['source_PDF'],actual_source_unique_pages=29,actual_individually_displayed_matching_views=15,selected_physical_pages=sorted(pages),views=views,preparation_record_SHA256=pins,exact_diagnostics_SHA256=sha(d),failed_v1_preflight_SHA256=sha(C/'failed_BE21_view_preflight_v1_20261008.json'),complete_selected_text_read=True,preparation_flags_unchanged=True,whole_primary_PDF_reading_claim=False,remaining_primary_pages_not_read_in_this_scope=96,active_book_changed=False,native_editor_changed=False,book_PDF_SHA256=sha(R/'manuscript/book.pdf'),baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),essential_earlier_inputs_not_recursively_verified=['Theorem 6.6 supnorm/base-change estimate','Theorem 8.12 logarithmic integrability','complete Proposition 1.25(v)','Raynaud–Gruson flattening and classical relative ampleness','Ducrot higher-dimensional determinant polynomial structure'],general_weak_local_global_comparison_admitted=False,general_envelope_theorem_admitted=False,canonical_status_changes=[],original_results_promoted=[],independent_model_receipt=None,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],pages=29,views=15,record_SHA256=sha(out))))
