from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
import sympy as s,json,hashlib
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/local_psh_dependencies_review_20261008')
out=C/'exact_norm_diagnostics_v1_20261008.json';assert not out.exists()
rows=[]
t=s.symbols('t');M=s.Matrix([[0,0,0,t**2],[1,0,0,0],[0,1,0,0],[0,0,1,0]])
mod2=lambda z:s.Poly(s.expand(z),t,modulus=2).as_expr()
assert mod2(M.det())==t**2
epsilon=M**2-t*s.eye(4)
assert any(mod2(z)!=0 for z in epsilon) and all(mod2(z)==0 for z in epsilon**2)
rows.append(dict(name='Nilpotent length and determinant norm over K=F2((t))',status='PASS',algebra='A=K[z]/((z²−t)²)',rank=4,residue_degree=2,Artinian_length=2,determinant_norm_of_z='t²',nilpotent='epsilon=z²−t is nonzero and epsilon²=0',weighted_valuation='v(N(z))=2=4*(1/2)',coefficient_field_caution='No compatible K-embedding K[sqrt(t)]→A: coefficient of epsilon in a square forces a1=t*a3, so a0+t*a2 would square to t in K; impossible since its square has even t-adic valuation. Intrinsic Artinian length remains valid.'))
for weights in [(4,),(2,3,1),(3,1)]:
 degree=sum(weights);g=F(7,3);eta=F(2,9)
 assert sum(w*g for w in weights)==degree*g
 a=[F(i-2,5) for i in range(len(weights))]
 b=[x+eta for x in a]
 assert abs(sum(w*(y-x) for w,x,y in zip(weights,a,b)))==degree*eta
rows.append(dict(name='Positive weighted fibre rank and uniform norm estimate',status='PASS',formula='sum n_y=d; N(f* g)=d*g; |N(u)−N(v)|≤d*||u−v||∞',weights_checked=[[4],[2,3,1],[3,1]],nilpotent_and_residue_multiplicity_kept=True))
weights=[3,1];degree=4;original=[F(-3),F(7)];values=list(original);maximum=max(values);initial_gap=max(maximum-x for x in values);trace=[]
for k in range(1,13):
 average=sum(w*x for w,x in zip(weights,values))/degree
 values=[max(average,x) for x in original]
 gap=max(maximum-x for x in values)
 assert gap<=initial_gap*F(degree-1,degree)**k
 assert max(values)==maximum
 trace.append(dict(k=k,gap=str(gap),bound=str(initial_gap*F(3,4)**k)))
rows.append(dict(name='Multiplicity-weighted maximum iteration',status='PASS',degree=4,weights=weights,initial_values=list(map(str,original)),contraction='M_k≤(1−1/e)^k M_0 for e>1; e=1 is the identity case',trace=trace))
for n in [1,2,5,10,30]:
 a=lambda i:F((-1)**i,i)
 lhs=sum(abs(a(i)-a(i+1)) for i in range(1,n+1))
 h=sum(F(1,i) for i in range(1,n+1))
 assert lhs==2*h+F(1,n+1)-1
rows.append(dict(name='Arbitrary uniform sequence cannot always be shifted decreasing',status='PASS',metrics='phi_i=((-1)^i/i,−(-1)^i/i) on two reduced projective points',necessary_shift_difference='c_i−c_{i+1}≥1/i+1/(i+1)',partial_sum='2H_N+1/(N+1)−1→∞',conclusion='No constants tending to zero make the entire sequence decreasing; this diagnoses the proof step, not uniform-closure membership.'))
for k in range(1,20):
 assert 3*F(1,2**k)-3*F(1,2**(k+1))==F(1,2**k)+F(1,2**(k+1))
rows.append(dict(name='Fast subsequence repair for uniform closure',status='PASS',scope='Choose a subsequence with ||phi_k−phi||∞≤2^−k; shift by c_k=3*2^−k',inequality='c_k−c_{k+1}=2^−k+2^−(k+1) bounds all positive pointwise increments',conclusion='The shifted subsequence decreases to the same limit; this elementary repair does not prove an arbitrary local weak-psh comparison.'))
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — five exact elementary norm/sequence diagnostic families',checks=rows,arithmetic='Exact rational and symbolic arithmetic; polynomial coefficients reduced modulo 2',original_general_theorems_promoted=[],independent_model_receipt=None,book_changed=False,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],families=len(rows),record_SHA256=hashlib.sha256(out.read_bytes()).hexdigest())))
