# Frozen failed v1 helper SHA256: abd5f54a1bc0c49d284d1baa9dfa8141ed11127ec9f1ae434a5452a0c2eef00e
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,fitz,subprocess
from PIL import Image,ImageDraw
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/local_psh_dependencies_review_20261008'
W=Path('/tmp/Local_psh_dependencies_BE21_views_v2_20261008')
N=C/'BE21_primary_notes_v2';out=C/'BE21_view_preparation_v2_20261008.json'
assert not any(p.exists() for p in [W,N,out]);W.mkdir();N.mkdir()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
pdf=R/'source_material/Ben_Bassat_harmonic_quiver_dependencies_20261008/Boucksom_Eriksson_2021_published.pdf'
assert sha(pdf)=='f9b8d54cfb2733486f35d450f5f763acf81a51816368ccd2c24c0663845d84f9'
doc=fitz.open(pdf);assert len(doc)==125
selected=[1,2,*range(78,89),*range(119,124)];assert len(selected)==18
core=json.loads((R/'source_material/Wu_local_NA_psh_review_20261008/staging_preparation_v3_20261008.json').read_text())
core_names=sorted(set(core['other_active_TeX_preserved'])|{n for n in core['after'] if n.endswith('.tex')})
protected={n:sha(R/n) for n in core_names}
assert len(protected)==425
for n in ['manuscript/bibliography/ComplexGeometry.bib','manuscript/bibliography/NonArchimedean.bib','manuscript/book.pdf','output/open_problems_catalogue_2026-10-03.tex','output/open_problems_catalogue_2026-10-03.pdf','README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']:
 protected[n]=sha(R/n)
views=[]
for i in range(0,len(selected),2):
 pages=selected[i:i+2];panels=[];texts=[]
 for n in pages:
  pix=doc[n-1].get_pixmap(matrix=fitz.Matrix(1.45,1.45),alpha=False)
  panels.append(Image.frombytes('RGB',[pix.width,pix.height],pix.samples))
  texts.append(f'BOUCKSOM–ERIKSSON 2021 PUBLISHED PDF PHYSICAL PAGE {n}\n'+doc[n-1].get_text())
 canvas=Image.new('RGB',(sum(p.width for p in panels),max(p.height for p in panels)+28),'white');draw=ImageDraw.Draw(canvas);x=0
 for n,p in zip(pages,panels):
  draw.text((x+8,8),f'BE21 published PDF physical page {n}',fill='black');canvas.paste(p,(x,28));x+=p.width
 number=i//2+1;ip=W/f'sheet_{number:02d}.png';tp=W/f'sheet_{number:02d}.txt';canvas.save(ip);tp.write_text('\n\n'.join(texts))
 views.append(dict(number=number,physical_pages=pages,path=str(ip),image_SHA256=sha(ip),selected_text_path=str(tp),selected_text_SHA256=sha(tp),source_PDF_SHA256=sha(pdf),actually_viewed=False,selected_text_read=False))
mp=W/'manifest.json';mp.write_text(json.dumps(views,ensure_ascii=False,indent=2)+'\n')
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — cached published-primary selected view preparation; zero reading credit',source_PDF=dict(path=str(pdf),bytes=pdf.stat().st_size,SHA256=sha(pdf),physical_pages=125,printed_article_pages=124,source_reused=True,new_acquisition=False),scope='Cover/identity, Chapter 8 Deligne/norm metrics and seams, Appendix norm functor and Deligne-pairing foundations A.21 and seams; partial source selection only',selected_physical_pages=selected,prepared_pages=18,prepared_views=9,manifest_path=str(mp),manifest_SHA256=sha(mp),protected_core_inputs=protected,baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),actual_source_reading_credit=0,actually_read_pages=0,active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],pages=18,views=9,record_SHA256=sha(out))))
