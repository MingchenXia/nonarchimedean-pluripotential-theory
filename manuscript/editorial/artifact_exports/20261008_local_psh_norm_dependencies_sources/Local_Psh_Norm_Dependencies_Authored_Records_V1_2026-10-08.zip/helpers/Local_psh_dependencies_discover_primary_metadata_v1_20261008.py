from pathlib import Path
from datetime import datetime,timezone
import urllib.request,urllib.parse,xml.etree.ElementTree as ET,json,hashlib,traceback
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/local_psh_dependencies_review_20261008')
C.mkdir(exist_ok=True)
out=C/'APW_author_metadata_discovery_v1_20261008.json';rawfile=C/'APW_author_metadata_response_v1_20261008.xml'
assert not out.exists() and not rawfile.exists()
q='au:Piquerez OR (au:Amini AND au:Wu)'
url='https://export.arxiv.org/api/query?'+urllib.parse.urlencode(dict(search_query=q,start=0,max_results=40,sortBy='submittedDate',sortOrder='descending'))
obj=dict(start_UTC=datetime.now(timezone.utc).isoformat(),query=q,request_URL=url,actual_primary_pages_read=0,matching_source_images_displayed=0,book_changed=False,canonical_status_changes=[],helper_source=__file__)
try:
 req=urllib.request.Request(url,headers={'User-Agent':'book-source-audit/1.0'})
 with urllib.request.urlopen(req,timeout=35) as r:
  raw=r.read();obj.update(HTTP_status=r.status,final_URL=r.url)
 rawfile.write_bytes(raw);root=ET.fromstring(raw);ns={'a':'http://www.w3.org/2005/Atom'}
 rows=[]
 for e in root.findall('a:entry',ns):
  rows.append(dict(id=e.findtext('a:id',namespaces=ns),title=' '.join((e.findtext('a:title',namespaces=ns) or '').split()),published=e.findtext('a:published',namespaces=ns),updated=e.findtext('a:updated',namespaces=ns),authors=[x.findtext('a:name',namespaces=ns) for x in e.findall('a:author',ns)],abstract=' '.join((e.findtext('a:summary',namespaces=ns) or '').split()),links=[x.attrib for x in e.findall('a:link',ns)]))
 obj.update(status='DONE — author metadata search only; zero proof-reading credit',response_SHA256=hashlib.sha256(raw).hexdigest(),entries=rows)
except Exception as e:
 obj.update(status='FAILED — metadata discovery; zero proof-reading credit',error=repr(e),traceback=traceback.format_exc())
obj['end_UTC']=datetime.now(timezone.utc).isoformat();out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],entries=[{k:r[k] for k in ['id','title','published','updated','authors']} for r in obj.get('entries',[])],error=obj.get('error')),ensure_ascii=False))
raise SystemExit(0 if obj['status'].startswith('DONE') else 1)
