from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
R=Path('/workspace/nonarchimedean-pluripotential-theory');E=R/'manuscript/editorial'
C=R/'source_material/Xue_semiabelian_review_20261009';K=C/'dependencies_v1/Kuhne22Published'
W=Path('/tmp/Xue_semiabelian_dependency_views_v1_20261009/Kuhne22Published')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();now=lambda:datetime.now(timezone.utc).isoformat()
prep=json.loads((K/'source_preparation_v1_20261009.json').read_text())
assert sha(prep['source']['path'])==prep['source']['SHA256'] and sha(W/'manifest.json')==prep['manifest_SHA256']
receipts=[];pages=[];previous=None
for i in range(1,29):
 n=K/'primary_notes_v1'/('note_%02d.md'%i);p=n.with_name('note_%02d_receipt.json'%i);d=json.loads(p.read_text())
 assert d['view_number']==i and d['note_SHA256']==sha(n) and d['previous_receipt_SHA256']==previous
 assert d['source_PDF_SHA256']==prep['source']['SHA256'] and d['full_selected_text_read'] and d['matching_rendered_image_displayed_and_read']
 assert sha(d['image_path'])==d['image_SHA256'] and sha(d['selected_text_path'])==d['selected_text_SHA256']
 pages+=d['physical_pages'];previous=sha(p)
 receipts.append(dict(view=i,pages=d['physical_pages'],note_path=str(n),note_SHA256=sha(n),receipt_path=str(p),receipt_SHA256=sha(p)))
assert pages==list(range(1,56))
findings=[
 dict(locator='§3.2–3.5, pp. 2098–2104; §4 ends p. 2113',kind='ATTRIBUTION CLEARANCE',detail='Published sections concern compactifications, canonical metrics, heights and ARCHIMEDEAN local charts; no §3.6, Theorem 3.6, Proposition 3.13 or Theorem 4.7 supplies Xue’s stated Raynaud/theta chain.'),
 dict(locator='§2.2, p. 2086',kind='UPSTREAM LITERAL TYPO',detail='The extra dd^c applied to c1 in the Archimedean semipositivity sentence is visible in the published source; actual positive-current construction uses c1 itself.'),
 dict(locator='§2.5–2.9 and Lemmas 4.2–4.6',kind='NORMALIZATION/POSITIVITY SCOPE',detail='Retain finite exceptional-place set, field/local degrees, binomial leading term, mixed probability denominator, geometric nefness versus global semipositivity; χ-Hilbert–Samuel and global difference-bigness are distinct inputs.'),
 dict(locator='Lemma 4.4 and final (4.13), pp. 2106–2113',kind='CHECKED PARAMETER STRUCTURE',detail='|λ|≤n^{-1}; error after dividing by |λ| is O(n^{-2}|λ|^{-1}+n|λ|+κ_n n²|λ|), κ_n=O(n^{-2}); λ=n^{-3/2} gives O(n^{-1/2}).'),
 dict(locator='Lemma 4.5, p. 2108',kind='IMPORTED ADAPTATION',detail='Rank-one horizontal lower bound is imported from Chambert-Loir; general-rank compactification adjustment is left to the reader. No recursive proof clearance.'),
 dict(locator='Lemma 4.6, pp. 2109–2110',kind='SIGN/HYPOTHESIS SCOPE',detail='For negative λ swap semipositive summands; vanishing excess arithmetic abelian factors uses zero canonical height of π(X), furnished by generic small points.'),
 dict(locator='Proposition 4.1 proof, p. 2111',kind='OMITTED DENSITY STEP',detail='Arbitrary continuous complex test need not define an integrable trivial metric; reduce to smooth dense tests before applying the perturbation argument.'),
 dict(locator='Lemma 5.2, pp. 2113–2116',kind='COMBINATORIAL SCOPE',detail='Printed t′! requires increasing/unordered distinct index tuples, not all ordered tuples; split (Gm)^2 mass calibration gives 8 versus literal ordered-tuple 16.'),
 dict(locator='(5.8), p. 2117',kind='METRIC SCALE SCOPE',detail='For a bilinear metric in real dimension 2d′, volume scales by a^{d′}; equality needs (d′!)^{1/d′}, not printed exponent 2/d′; larger printed factor still dominates. Treat d′=0 separately.'),
 dict(locator='(6.2)–(6.5), pp. 2119–2120',kind='TOPOLOGY/MASS SCOPE',detail='Nonproper composition needs tightness/bounded-test extension; product Chern measure needs mixed-degree normalization; support comparisons use closures/strata and zero-mass exceptional sets.'),
 dict(locator='Appendix A, Lemma A.1(a), pp. 2122–2126',kind='LOAD-BEARING LITERAL PROOF INPUT NOT CLEARED',detail='Smooth curvature cannot dominate a positive multiple of the singular circle Chern measure. A.2’s printed proof uses this false positivity assertion in T_l; ordinary weak smoothing does not repair logarithmic convergence. Local potential signs also reverse the source’s stated Chern convention.'),
 dict(locator='Appendix B, pp. 2126–2127',kind='CHECKED ELEMENTARY CALIBRATION',detail='dd^c|log|z|| equals dθ/π on the unit circle, total mass two. Its integration-by-parts proof was read and algebraically checked. No intended-main-theorem refutation.')]
cp=K/'actual_source_checkpoint_v1_20261009.json';assert not cp.exists()
checkpoint=dict(UTC=now(),status='COMPLETE ACTUAL PUBLISHED-SOURCE READING — 55 pages, 28 views; flagged proof inputs retained',DOI='10.4171/JEMS/1125',edition='JEMS 24 (2022), 2077–2131',source_SHA256=prep['source']['SHA256'],actual_pages=pages,actual_matching_views=28,receipts=receipts,findings=findings,
 all_recursive_inputs_verified=False,printed_regularization_proof_cleared=False,intended_main_theorem_counterexample=False,
 actual_Xue_pages=list(range(1,21)),new_Xue_page_credit=0,FRSS_arxiv_actual_pages=21,FRSS_journal_locators_authenticated=False,
 book_changed=False,canonical_status_changes=[],independent_verifier_receipt=False,helper_source=__file__,helper_SHA256=sha(__file__))
cp.write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2)+'\n')
X=E/'artifact_exports/20261009_Kuhne_semiabelian_dependency_v1';assert not X.exists();X.mkdir()
prefix='Kuhne_semiabelian_dependency_source_'
paths={k:E/(prefix+k+'_v1_20261009.'+ext) for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in paths.values())
review='''# Kühne published semiabelian source: complete actual reading

Lars Kühne, *Points of small height on semiabelian varieties*, JEMS 24
(2022), 2077–2131, DOI **10.4171/JEMS/1125**. Exact publisher PDF SHA256:
`c4a7ad1ed068745438d357d62f32164c3eb1366d85a90914d796de13680134c9`.
All **55 physical pages** were read in twenty-eight ordered complete-text
and matching-image displays, including appendices and references.
Complete reading is not recursive verification of every imported input.

## Classical theorem scope and usable structure

The standard compactification is the (P1)^t bundle of a number-field
semiabelian variety, with its canonical toric boundary metric and a
symmetric ample canonical abelian factor. Theorem 1.1 is classical strong
equidistribution for strict canonically small sequences; Proposition 4.1
provides the leading **mixed, normalized** subvariety measure for generic
canonically small points. EC/BC/SEC are already established results, not
newly solved questions in this book. General toric monocritical metrics
and arbitrary fans are not the source's stated extension.

The two-parameter estimate retains |λ|≤n^{-1}, the positive upward
constant shift κ_n=O(n^{-2}), field/local-degree normalization and the
zero height of the abelian image. After division by |λ| its error is
O(n^{-2}|λ|^{-1}+n|λ|+κ_n n²|λ|); λ=n^{-3/2} makes it vanish. Leading
binomial coefficients cancel between matching numerator and denominator,
rather than disappearing from full top intersections. χ-volume
Hilbert–Samuel equality and the globally semipositive DIFFERENCE bigness
inequality are distinct imported inputs.

## Xue attribution check

The actual published §3.2–3.5 discusses compactifications, canonical
metrics, height comparisons and **Archimedean** local charts. It has no
§3.6, Theorem 3.6 or Proposition 3.13 supplying a Raynaud/Fourier/theta
classification. Section 4 ends with Proposition 4.1, without the alleged
Theorem 4.7 global theta-height comparison. Xue's citations to those
Kühne locators therefore do not supply their claimed inputs. The FRSS
arXiv version has now been fully read separately, but its journal
numbering differs and is not authenticated by that reading.

Complex unitary charts use an imported Vojta Weil-function result. They
cannot by themselves prove a non-Archimedean period-transition assertion.
The introduction also explicitly leaves a full non-Archimedean
semiabelian canonical-measure description to the interested reader.

## Printed proof inputs and normalization cautions

The full notes preserve upstream literal definition/index slips and
important import boundaries. Among them: semipositivity tests c1 itself,
not the printed extra dd^c; negative perturbations exchange the two nef
summands; continuous complex tests need smooth-density reduction;
nonproper test compositions need tightness; slice sums need an explicit
increasing-index convention; and probability products keep mixed degree
denominators. Riemannian volume scaling uses real dimension and must
also separate zero abelian dimension.

**Appendix A.1(a) is not a usable regularization input as printed.** It
requires smooth curvature to dominate a positive multiple of the original
possibly singular curvature. The source's own P1 boundary metric has
circle-supported curvature (Appendix B, mass two), which a smooth measure
cannot dominate. Narrow circle neighborhoods supply the elementary
calibration. Appendix A.2 explicitly uses that asserted positivity in
T_l to pass unbounded logarithmic integrals to the limit. Replacing it
with ordinary weak smoothing does not justify that passage; correct
local-height continuity or logarithmic tail control is still needed.
The appendix also reverses signs of local Chern potentials.

This flags a literal load-bearing proof input. It is **not** a
counterexample to classical semiabelian EC/BC/SEC or to the established
existence of local heights, which have separate imported source inputs.
No claim of a new theorem, full repair or independent verifier receipt
is made. The rank-one-to-general-rank horizontal-bound adaptation left
to the reader is also retained as an imported obligation.

## Evidence and current book scope

The archive preserves 63 authored note/receipt/record/helper members.
It excludes paper PDF, extracted full text and rendered pages; the
controlling publisher source is linked in its manifest. Acquisition and
preparation flags stay at zero credit; chronological receipts establish
actual reading separately. The original cloud evidence remains intact.

Xue itself remains **20/83** actually read pages; its main proofs are
unverified and not integrated. The active book remains **4,675 pages**,
and its 42 canonical atoms/twelve formal problems are unchanged. General
BJ22 homogeneous Siu/envelopes remain OPEN. The native catalogue's
separate arithmetic supplement remains local with source audit complete
and native compiler diagnostics unavailable so far; this source checkpoint
does not replace or compile a separate catalogue PDF.
'''
paths['review'].write_text(review)
paths['reading_notes'].write_text('# Complete actual Kühne published-source reading\n\n'+'\n\n---\n\n'.join((K/'primary_notes_v1'/('note_%02d.md'%i)).read_text().rstrip() for i in range(1,29))+'\n')
paths['manifest'].write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2)+'\n')
members={}
for i in range(1,29):
 for suffix in ['.md','_receipt.json']:
  p=K/'primary_notes_v1'/('note_%02d'%i+suffix);members['primary_notes_v1/'+p.name]=p
for name in ['source_acquisition_v1_20261009.json','source_preparation_v1_20261009.json','actual_source_checkpoint_v1_20261009.json']:
 members['records/'+name]=K/name
members['records/prepared_view_manifest.json']=W/'manifest.json'
for name in ['Xue_semiabelian_acquire_dependency_v1_20261009.py','Xue_semiabelian_record_dependency_reading_v1_20261009.py','Xue_semiabelian_export_Kuhne_dependency_v1_20261009.py']:
 members['executed_helpers/'+name]=Path('/tmp')/name
assert len(members)==63
archive=X/'Kuhne_Semiabelian_Dependency_Actual_Reading_Evidence_V1_2026-10-09.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==63 and len(set(z.namelist()))==63
 for name,p in members.items():assert z.read(name)==p.read_bytes()
(X/'README.md').write_text('# Complete published-source actual-reading evidence\n\nKühne JEMS 24 (2022), 2077–2131: all 55 physical pages, 28 matching\ndisplays. Full reading is distinct from proof-input clearance; the audit\npreserves the Appendix A.1 literal regularization issue. Xue remains\n20/83, with main claims unverified and unintegrated.\n\nThe ZIP contains 63 authored evidence/helper/receipt members. No primary\npaper PDF, full extracted text or rendered page is redistributed. Exact\nsource: https://ems.press/content/serial-article-files/32695?nt=1.\n')
(X/'SHA256SUMS').write_text(sha(archive)+'  '+archive.name+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=now(),status='EXPORTED — complete actual published-source evidence, cautions retained',archive=str(archive.relative_to(R)),SHA256=sha(archive),bytes=archive.stat().st_size,members=63,actual_pages=55,matching_views=28,printed_regularization_proof_cleared=False,book_changed=False,no_reading_credit_for_upload=True),ensure_ascii=False,indent=2)+'\n')
update='''
## Kühne published source: complete dependency read, 9 October 2026

All **55 published pages** were read in twenty-eight ordered matching
text/image displays. The audit retains canonical-metric theorem scope,
field and mixed-mass normalization, two-parameter estimates and explicit
source-input cautions. Xue's attributed Raynaud/theta locators do not
match the published edition. Appendix A's printed smooth-domination
input is not cleared; no main-theorem refutation or repair is claimed.
Xue remains **20/83**, with main proofs unverified and unintegrated.
The book remains **4,675 pages**, with canonical statuses unchanged.

See [source audit](manuscript/editorial/Kuhne_semiabelian_dependency_source_review_v1_20261009.md)
and [authored evidence](manuscript/editorial/artifact_exports/20261009_Kuhne_semiabelian_dependency_v1/).
'''
readme=R/'README.md';readme.write_text(readme.read_text().rstrip()+'\n'+update)
progress=E/'second_reading_and_research_programme_20261002.md';progress.write_text(progress.read_text().rstrip()+'\n'+update.replace('manuscript/editorial/',''))
owned=list(paths.values())+sorted(X.iterdir())+[readme,progress];assert len(owned)==9
assert sha(R/'manuscript/book.pdf')=='2c90129c35506ac72005c5189ff235b0e1bd52f5b529ef44e5fc58bf7dbfcfe8'
assert sha(R/'output/open_problems_catalogue_2026-10-03.tex')=='ec3a2a9d8c4d713afe2c0ff8dcf17720ef0d77442b6086d515dea382fe7b77ec'
out=C/'Kuhne_dependency_export_v1_20261009.json';assert not out.exists()
obj=dict(UTC=now(),status='READY FOR EXPLICIT NINE-FILE PUBLISHED-SOURCE EVIDENCE PUBLICATION',owned_files=[dict(path=str(p.relative_to(R)),SHA256=sha(p),bytes=p.stat().st_size) for p in owned],archive_members=63,actual_Kuhne_pages=55,actual_Xue_pages=20,book_changed=False,native_catalogue_changed=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],archive_SHA256=sha(archive),record_SHA256=sha(out),owned_files=[str(p.relative_to(R)) for p in owned])))
