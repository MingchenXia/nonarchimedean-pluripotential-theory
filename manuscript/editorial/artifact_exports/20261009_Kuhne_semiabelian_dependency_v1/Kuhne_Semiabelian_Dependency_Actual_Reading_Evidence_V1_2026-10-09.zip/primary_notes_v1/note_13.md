# Actual ordered reading 13 — Kühne JEMS, physical pages 25–26 (2101–2102)

Read complete text and matching image. Actual coverage 1–26 only, no Xue or later-proof reading credit and no independent original-result verdict.

The canonical-metric rescaling indeterminacy is a simultaneous K-scalar adjustment, harmless to global intersections by the product formula. Symmetric ample N has nonnegative Néron–Tate point heights and vertically semipositive model approximation. The toric boundary bundles are merely geometrically nef; their vertical semipositivity is an explicitly imported Chambert-Loir/Künnemann construction, not an automatic consequence of nefness.

Lemma 3.2 controls canonical heights under homomorphisms, removing bounded Weil-height error by Tate iteration. The abelian source bundle N1 is ample; the text only calls N2 symmetric, so the explanatory claim that all four terms are nonnegative requires N2 nef/ample (a negative symmetric ample dual is a counterexample to that explanatory sign claim). The upper comparison bound itself does not require a positive target height, so this is not a counterexample to its intended inequality or the main equidistribution theorem. Toric height nonnegativity is asserted on G points, not all compactification boundary points.

Published §3.5 is ARCHIMEDEAN Local trivializations. Lemma 3.3 produces finite holomorphic P1-product charts with the canonical boundary metrics and locally constant S1 transition values, as well as invariant vertical kernel distributions. This is not a non-Archimedean Raynaud chart result. The proof begins with sections of Q_i-dual whose divisors avoid the identity and the rational function divisor div f_i=D_i^0−D_i^∞+π*div s_i. This exact dual/sign choice must be retained in comparison with Xue.

The complete theta/Weil-function proof continues on pp. 27–28; no norm cancellation has yet been cleared merely from the statement here.
