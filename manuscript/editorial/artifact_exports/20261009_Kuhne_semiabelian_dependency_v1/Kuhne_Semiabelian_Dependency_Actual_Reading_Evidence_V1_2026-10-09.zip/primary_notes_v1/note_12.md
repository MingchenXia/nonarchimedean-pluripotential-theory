# Actual ordered reading 12 — Kühne JEMS, physical pages 23–24 (2099–2100)

Read full text and matching image. Actual coverage 1–24 only; no Xue credit, independent original-result verdict or full recursive clearance of cited Zhang/Kühne inputs.

The standard compactification boundary has zero and infinity divisors for each coordinate, with M_G their sum. Nefness of an individual boundary bundle is deduced from M_i^n⊗M_G⊗π*N being ample for EVERY positive n, not from only one fixed ample sum. After dividing by n, the fixed positive part tends to zero in the numerical class. This is the missing variable-coefficient pattern identified in the earlier Xue note. A toric-[n] homomorphism extends via contracted products and pulls each boundary divisor back by n.

Published §3.3 is Canonical metrics and heights. Lemma 3.1 starts with a fixed algebraic isomorphism φ:L^d→f*L, integer d>1, and surjective f. It uniquely defines the local metric making THAT φ an isometry; replacing φ by cφ rescales the metric by |c|^{1/(d−1)}. Uniqueness under this prescribed dynamical isometry does not independently identify an arbitrary raw theta representative's norm.

The proof constructs a model of L as a difference of two projective-embedding bundles, then uses graph closures of f^n and d^n-th root metrics. All iterates and isomorphisms extend over ONE arithmetic open set, proving adelic coherence outside a fixed finite exceptional set. Pullback of relatively nef model bundles preserves vertical positivity, giving (d). This only gives vertical semipositivity here, not nonnegative point heights on the entire compactification. Canonical toric boundary bundles have eigenweight n while N has n^2. The rescaling discussion continues next page.

Neither §3.2 nor §3.3 is the Raynaud uniformization/triple classification attributed to these sections in some Xue citations; this is now verified by actual reading, not only prepared-text search.
