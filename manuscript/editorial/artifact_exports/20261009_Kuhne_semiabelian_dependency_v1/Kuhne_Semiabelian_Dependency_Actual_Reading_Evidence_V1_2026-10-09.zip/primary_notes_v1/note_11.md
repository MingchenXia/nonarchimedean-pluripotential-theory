# Actual ordered reading 11 — Kühne JEMS, physical pages 21–22 (2097–2098)

Complete text and matching image read. Coverage 1–22 only; no Xue credit, recursive source clearance or independent-verifier receipt.

The Minkowski proof uses a normalized adelic Haar measure and a one-place inflated unit ball, with inflation exp(-χ_sup/r_N + log(2)[K:Q]). It obtains a nonzero global section satisfying the chosen-place estimate and all other-place bounds. The factor N^d/d! divided by r_N tends to 1/L^d for geometrically nef big L; the limsup χ-volume permits suitable large powers, rather than all powers. Finite-place norm discreteness and adelic Minkowski details are imported from the cited theorem.

Section 3.1 defines the exact extension 0→T→G→A→0 and its functorial pushout/pullback. Weil–Barsotti identifies split-torus extension classes with tuples in A-dual(k), i.e. Pic^0 classes on A, and the integer character matrix acts on those tuples. A toric/abelian pair determines a unique G-homomorphism exactly when the pushed/pulled extension classes agree. The printed Ext^1(Gm^{t'},A) at the end of that sentence reverses the arguments; the class comparison belongs to Ext^1(A,Gm^{t'}).

The actual published §3.2 is titled Homomorphisms and compactifications and builds the contracted product (G×(P1)^t)/T using (tg,t^{-1}x), together with its projective-bundle description via Q_i in Pic^0(A). It is not a Raynaud uniformization section as some Xue citations describe. The signs in the sheaf dual in (3.3) need comparison with the later chosen local trivialization. The prose on strictly negative whole-space height is read under the introduction's non-almost-split hypothesis; the almost-split case has zero height.
