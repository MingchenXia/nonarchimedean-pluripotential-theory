# Actual ordered reading 03 — Kühne JEMS, physical pages 5–6 (2081–2082)

Read full text and matching displayed image. Actual coverage pages 1–6 only; no extra Xue coverage or independent-verifier receipt.

Page 5 completes the introduction: λ lies in (0,n^{-1}], n is chosen a square, and λ=n^{-3/2} gives the displayed O(n^{-1/2}) convergence. The Taylor remainder must retain its n-dependence, obtained through the projection formula for the rank-one degree-n isogeny; the height deficit decays quadratically. The underlying source proof, not the sketch alone, must control the other error terms. SEC also supplies an alternative already unconditional MLBC deduction with the known Mordell–Lang theorem; this is not presented as a newly open problem. Almost-division equidistribution is another announced consequence.

Page 6 fixes conventions that cannot be silently transferred to Ballaÿ–Sombra or Xue. For a finite place, |p_v|_v=p_v^{-[K_v:Q_p]}; usual real/complex absolute values are used at infinity with δ_v=2 for complex places, 1 otherwise. Local degree factors are therefore already included differently from a standard absolute value with explicit n_v weights. The later global [K:Q] normalization must be retained. Formal completions, reduced finite-type varieties, reduced closed subvarieties, cycle coefficients, tangent spaces, and generic sequences are defined. Intersection numbers on a proper d-dimensional variety are the unnormalized geometric products of d line bundles, not divided by d!.

The formalism uses the sheaf of sections F(L), so signs of line-bundle duals must be compared explicitly with FRSS's geometric convention. These pages contain no Raynaud theta line-bundle-triple theorem and do not authenticate the erroneous-looking Xue citation chain by themselves.
