# Actual ordered reading 27 — Kühne JEMS, physical pages 53–54 (2129–2130)

Read the complete bibliography text and matching displayed image. Actual coverage 1–54 only; no reading credit for the cited papers themselves, Xue, or an independent verifier.

These reference pages identify Gubler's 1997/1998/2003 local-height papers, his 2007 tropical varieties paper and 2010 canonical abelian measures paper; the latter is the introduction's Example 7.2 input. Ikoma 2013 is the arithmetic bigness input [40]. Kühne 2020's bounded-height paper is [44], supplying compactification/homomorphism constructions. Maillot's Mém. SMF 80 (2000), 1–129, is [52], the regularization source cited by Appendix A. Its theorem has not been read here, so no exact comparison to its actual formulation is claimed; the published A.1 literal singular-measure diagnostic remains valid without that recursive reading.

Lang's theta/Weil references are [46] Introduction to Algebraic and Abelian Functions, [47] Fundamentals of Diophantine Geometry and [48] Introduction to Arakelov Theory. Poonen, Rémond, McQuillan and the classical Manin–Mumford references locate already established diophantine results. No FRSS Raynaud/theta classification reference occurs in this bibliography segment. The remaining [68]–[80] list is on page 55 and still needs the last display before complete-source credit.
