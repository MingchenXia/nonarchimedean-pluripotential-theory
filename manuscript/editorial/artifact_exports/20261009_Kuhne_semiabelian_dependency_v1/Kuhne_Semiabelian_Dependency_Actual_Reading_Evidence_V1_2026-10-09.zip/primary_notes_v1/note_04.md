# Actual ordered reading 04 — Kühne JEMS, physical pages 7–8 (2083–2084)

Complete text and matching image read. Coverage 1–8 only, no extra page credit or independent-verifier verdict.

The geometric volume convention is h^0(X,L^N) divided by N^d/d!, while deg_L is the ordinary top intersection; additive notation for Picard groups does not remove binomial factors from powers of sums. Repeated-factor intersection notation extends to Chern measures and arithmetic intersections. C_c^0 and C^0 are explicitly distinguished.

For reduced complex spaces, smooth functions/forms extend from local ambient smooth charts; psh functions are restrictions of ambient psh functions and currents are defined by duality. The Chern current is dd^c(-log ||s||) in a local trivializing section, with d^c=i/(2π)(bar∂−∂). The footnote warns that some Arakelov references instead use i/(4π), so squared-norm conventions must be reconciled rather than copied unchanged. Positivity is tested on the (1,1) current itself. This supports the already noted defect in Xue's Definition 3.20, which prints an additional dd^c applied to that closed current.

Strict current positivity is domination of a continuous Hermitian background form; ordinary semipositivity is weak positivity in Demailly's convention. Nondegenerate Riemannian metrics and real versus complex tangent bundles are kept distinct for the later Haar/rank arguments. Section 2 begins arithmetic intersection theory for integrable adelic bundles on projective varieties; the earlier nonproper G is handled via compactification, not by forming arbitrary unnormalized intersections there.
