# Actual ordered reading 07 — Kühne JEMS, physical pages 13–14 (2089–2090)

Read complete text and matching image. Actual coverage 1–14 only; no extra source pages or independent-verifier receipt.

Lemma 2.2's NA proof imports Gubler's Corollary 3.9 and Proposition 3.12. Integrable rational metrized bundles are tensor-power differences of semipositive bundles; multilinearity extends the measures as signed measures, whose positivity must not be assumed.

A Hermitian bundle on a projective arithmetic model is vertically semipositive when the underlying bundle is relatively nef and Archimedean Chern metrics are semipositive. The coherence condition for an adelic metric is equality with one model/root metric outside finitely many finite places. Uniform adelic convergence requires ONE finite set of places containing all changing metrics for every index. Pointwise place-by-place convergence without such a uniform finite set is a different notion.

Base change raises finite-place norms by the local extension degree; the real-to-complex case retains the metric and uses the separately changed δ_v. Galois invariance makes the identification of completed algebraic closures harmless. These conventions must be accounted for in global height comparison. O_X(f) again uses exp(-f) at only the selected place; all other places retain the standard trivial metric. Vertical integrability alone is not global adelic nefness.

Section 2.6 starts arithmetic intersections with d'+1 factors on a d'-cycle, using rational sections whose simultaneous divisor supports avoid the cycle. The existence and choice-independence are grounded in the imported local-height theory. The global pairing definition and its normalization continue on the next page and are not yet credited.
