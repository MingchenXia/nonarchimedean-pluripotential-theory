# Actual ordered reading 08 — Kühne JEMS, physical pages 15–16 (2091–2092)

Read complete text and matching image. Actual coverage 1–16 only. External local-height proofs and Appendix A remain imported/unread, with no Xue reading credit or independent original-result verdict.

The local-height induction formula (2.1) is divisor height minus the integral of log section norm against the mixed Chern measure. Its finiteness is imported from Chambert-Loir–Thuillier. Global intersections (2.2) sum δ_v local heights, with finite support and section-independence from coherent models and the product formula. They are not divided by [K:Q] at this stage.

Lemma 2.3 gives multilinearity, symmetry, generically finite projection formula, uniform semipositive limits, simultaneous scalar rescaling invariance by the product formula, and global base-change multiplication by [K':K]. These are precisely the normalization factors needed before defining field-independent heights. The index range in the uniform-limit line is inconsistent with the d+1 displayed factors, an editorial index issue rather than a new mathematical assertion.

Literal source caution in Lemma 2.4: the displayed statement defines d=dim X and d'=dim Y for a proper surjection Y→X, yet uses d-d' relative factors and a generic-fiber symbol η_Y. The meaningful relative projection formula instead has dim Y minus dim X relative factors and the generic fiber over η_X. The printed dimensions/generic-point labels must be corrected when importing the formula. The proof describes adaptation of a standard local-height projection argument; no claim is made that its intended formula or main theorem is false. Sections 2.6's overarching integrability assumptions remain necessary even where its final quantifier abbreviates Pic(Y), Pic(X).

The last paragraph begins test-function intersection variations for integrable O_X(f); their identities continue on the next page, not yet credited here.
