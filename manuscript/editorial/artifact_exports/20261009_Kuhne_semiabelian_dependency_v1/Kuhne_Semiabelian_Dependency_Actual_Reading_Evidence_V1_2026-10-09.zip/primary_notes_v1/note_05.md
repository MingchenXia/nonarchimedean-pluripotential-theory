# Actual ordered reading 05 — Kühne JEMS, physical pages 9–10 (2085–2086)

Read full text and matching image. Coverage 1–10 only. No later-page or Xue credit, no independent original-result verdict.

The setup is irreducible projective X of pure dimension d, hence compact analytic spaces. Formal and global models may carry positive tensor powers, and root metrics must divide logarithmic weights by those exponents. Metric continuity, nonvanishing local frames, scalar homogeneity, Galois invariance, uniform convergence and isometry classes are defined separately from positivity.

A literal source caution on p. 2086: the printed Archimedean semipositivity sentence itself says dd^c c1(L,||·||)≥0 (and similarly >0), visible in the published image. This has the same extra differentiation as Xue Definition 3.20; it appears to have been inherited. The proper condition is positivity of c1 itself, as the preceding p. 2084 current discussion and the subsequent positive Chern-measure construction require. Since Chern currents are closed, this literal extra derivative does not express semipositivity. Record the upstream literal typo without claiming that the intended published equidistribution theorem is false.

The non-Archimedean model-metric gluing argument here is substantive and correctly scoped: transition functions and their inverses are both FORMAL units, so their pointwise absolute values are ≤1 in both directions and hence equal to one. Arbitrary analytic units or arbitrary period descent factors do not satisfy that formal-unit argument automatically. Formal semipositivity means special-fiber nefness; general semipositivity is uniform approximation by those metrics.

O_X(g) has ||1||=exp(-g), confirmed in the image. This sign controls later height derivatives. The source's pseudo-divisor consists of a metrized bundle, support subvariety, and a nowhere vanishing section off that support. Section 2.3 starts mixed positive Chern measures on compact X_an; the continuous/NA cases require the referenced constructions rather than a smooth wedge alone.
