# Actual ordered reading 09 — Kühne JEMS, physical pages 17–18 (2093–2094)

Complete text and matching image read. Actual coverage 1–18 only, no additional Xue pages or independent-verifier receipt.

Equation (2.3) gives test-function intersection powers as δ_v times an integral with i−1 curvature factors of O_X(f). Its left side as printed lists d other factors independent of i, whereas the right side correctly requires d+1−i such factors; importing the variation identity requires the latter degree count. For a constant κ the curvature vanishes, leaving only the linear term δ_v κ(d+1)L^d. If L is geometrically nef, L^d=vol(L). This is geometric nefness, not an identification of χ-volume and arithmetic intersection under merely local curvature positivity.

The variety height (2.5) divides the arithmetic top intersection by [K:Q](dim Y+1)deg_L(Y), with L ample so the denominator is positive. The subsequent explanatory point-height sentence omits [K:Q], but the displayed point formula (2.6), confirmed in the image, is -1/[K(x):Q] times the sum of δ_v log norms over the local orbit. Preserve the displayed field-independent formula and flag that explanatory normalization slip. Base change is compatible with the earlier degree multiplication and denominator.

The positivity terminology is crucial: algebraic global semipositivity requires both vertical semipositivity and nonnegative heights of ALL closed points; global semipositive/integrable adelic bundles are limits/differences of those. This is stronger than vertical semipositivity/integrability, which only tests placewise Chern/model positivity. Xue's negative whole-variety height obstruction makes the distinction load-bearing.

Arithmetic χ-volume begins with sup norms at all places and an adelic Haar measure normalized so V_N\V_{N,A} has covolume one. χ_sup is log volume of the adelic unit ball, zero when there are no sections. This is not the logarithm of a number of globally small sections; the later limiting normalization remains to be read.
