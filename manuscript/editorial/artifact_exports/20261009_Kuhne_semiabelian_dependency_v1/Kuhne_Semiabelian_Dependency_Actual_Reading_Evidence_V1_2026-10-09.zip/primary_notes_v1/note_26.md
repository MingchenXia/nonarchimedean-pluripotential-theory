# Actual ordered reading 26 — Kühne JEMS, physical pages 51–52 (2127–2128)

Read complete text and matching displayed image. Actual coverage 1–52 only; no Xue or independent original-verifier credit.

Appendix B completes the distributional circle computation. Split the radial integral at r=1 into the increasing integral 1→∞ and reversed integral 1→0 corresponding to |log r|. Integration by parts gives the boundary jump 2h(1,θ); the g/r terms from r log r g'' and log r g' cancel, and periodic angular derivatives integrate to zero. The result is ∫h(e^{iθ})dθ/π, with mass two. This is a direct elementary imported calculation read in full and independently checked algebraically; it also supplies the exact singular-curvature calibration showing why literal Appendix A.1(a) cannot be a smooth-current domination assertion.

Acknowledgments and funding complete the article text. References begin with classical equidistribution and intersection sources. Page 52 identifies Chambert-Loir–Thuillier, Mesures de Mahler et équidistribution logarithmique, AIF 59 (2009), 977–1014, as [15], the logarithmic-integrability input used throughout; its proof has not been read in this dependency checkpoint. BE21 is [8]; Chambert-Loir's 1999 canonical-height and 2000 small-point papers are [11],[12]. Demailly's 1986/1993 current papers are [19],[20]. These are imported bibliography identities, not recursively audited mathematical results.

No FRSS theta-classification paper occurs in these initial references, and the published §3/§4 numbering previously read is already sufficient to reject the Xue locator attribution to those nonexistent Kühne statements. The remaining bibliography still needs views 27–28 for complete physical-page coverage.
