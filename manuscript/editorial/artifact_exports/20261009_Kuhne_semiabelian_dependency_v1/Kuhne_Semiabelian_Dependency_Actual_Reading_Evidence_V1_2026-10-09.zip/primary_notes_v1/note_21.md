# Actual ordered reading 21 — Kühne JEMS, physical pages 41–42 (2117–2118)

Read complete text and matching displayed image. Actual coverage 1–42 only; no new Xue or independent-verifier credit.

Lemma 5.3 completes the Riemannian domination construction: the toric metric and pulled-back abelian metric complement each other on the two tangent-kernel summands of the regular Haar slice. A sum over the finite I_X gives one dominating ambient metric. Domination, not an exactly normalized ambient metric, is all the later small-box contradiction needs.

Literal normalization caution in (5.8): for a bilinear Riemannian metric on real dimension 2d', scaling g by a scales its volume form by a^{d'}. Thus the printed a=(d'!)^{2/d'} gives (d'!)² rather than d'!; the equality with d'! vol(g'') requires a=(d'!)^{1/d'}. The printed larger factor still supplies domination for d'≥1, so the essential inequality survives. d'=0 must be treated by omitting the abelian metric instead of dividing by zero in that expression. Retain these conventions when quoting an equality, without presenting them as a main-theorem counterexample.

Section 6 Proposition 6.1 proves classical BC. Lemma 6.2 imports the difference-map argument from Zhang: trivial stabilizer yields a generically degree-one map X^m→G^{m−1} for sufficiently large m. The main proof quotients by the full stabilizer after finite field extension; the quotient remains semiabelian, and canonical-height comparison transports a positive threshold. Pullbacks of the chosen abelian bundles are implicit in the abbreviated L=M_G⊗N notation.

For the contradiction, generic small points must be selected (a merely Zariski-dense sequence can still contain a nongeneric subsequence). The source starts with a dense small sequence and a bijection N→N^m; the precise generic-product sequence/subsequence step continues next page. A product enumeration alone does not make every coordinate tend to infinity, so this point must be checked before applying Proposition 4.1.
