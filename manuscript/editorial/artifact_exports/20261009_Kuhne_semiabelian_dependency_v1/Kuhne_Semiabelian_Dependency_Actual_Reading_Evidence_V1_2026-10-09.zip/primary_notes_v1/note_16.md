# Actual ordered reading 16 — Kühne JEMS, physical pages 31–32 (2107–2108)

Read complete text and matching displayed image. Actual coverage 1–32 only; no new Xue credit or independent-verifier verdict.

Lemma 4.4's Taylor proof expands the arithmetic (d+1)-power. Base change and the projection formula produce δ(Y)[Kn:K]n^{-d+i+j−1} for each higher term. Integrable O_X(f)=P1−P2 controls absolute integrals by sums of nonnegative geometric intersections; base dimension kills j>d'. Dividing by the geometric degree lower bound gives O(|λ|^i n^{i−1}), and |λ|n≤1 bounds all i≥2 by O(λ²n). This verifies both the parameter domain and field-degree cancellation; neither may be omitted when generalizing.

Lemma 4.5 introduces a POSITIVE Archimedean constant κ_n=O_G(n^{-2}) to make L_n horizontally semipositive. It preserves vertical curvature positivity; shifting downward would not supply global semipositivity. The height shift is κ_n/[K:Q] in the source's convention as printed; a complex chosen place would carry the δ factor from (2.4), so κ_n may be correspondingly absorbed/renormalized in this existential bound. If X has generic canonically small points, the normalized Y height lies between -O(n^{-2}) and zero, and the abelian image has canonical height zero.

The first horizontal-bound step is imported from Chambert-Loir Lemma 4.5 in toric rank one. The source explicitly leaves the compactification adjustment for general rank to the reader; complete reading does not recursively verify that adjustment. Zhang's fundamental lower-bound inequality gives the lower height estimate. The upper and abelian-image arguments continue next page. The footnote chooses an Archimedean shifting place because arbitrary NA real constant perturbations need an additional integrability argument.
