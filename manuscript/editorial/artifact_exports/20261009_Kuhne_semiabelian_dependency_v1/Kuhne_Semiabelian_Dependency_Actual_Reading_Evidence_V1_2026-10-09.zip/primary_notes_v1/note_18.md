# Actual ordered reading 18 — Kühne JEMS, physical pages 35–36 (2111–2112)

Read complete text and matching image. Actual coverage 1–36 only; no Xue credit, independent original-verifier verdict or recursive clearance of external density theorems.

Proposition 4.1's proof reduces NA tests by Stone–Weierstrass/model-function approximation, potentially after finite field extension. Its opening Archimedean sentence claims O_X(f) integrable for the continuous f in the proposition. That unrestricted claim is too strong: the valid reduction is first to smooth tests (uniformly dense on the compact complex space), for which a sufficiently positive fixed bundle absorbs the bounded Hessian, and then extend the measure convergence by uniform approximation. An arbitrary continuous function need not be a difference of continuous psh weights. This is an omitted test-density step, not a counterexample to the intended equidistribution theorem. The source does give the NA approximation step explicitly.

For fixed n and nonzero |λ|≤n^{-1}, add κ_n=O(n^{-2}) and use Minkowski on the perturbed bundle. Lemmas 4.2/4.6 divide the arithmetic defect by [Kn:Q](d+1)deg_{L_n}(Y), giving an O(λ²n(1+κ_n n)) height error; Lemma 4.4 and the negative-height bound yield (4.11) outside the small-section divisor. Genericity eventually avoids the finitely many relevant divisor images for that fixed n.

The perturbation point height (p. 36) equals λδ_v/[K:Q] times the normalized local orbit average of the pulled-back f. The factor [Kn:K] cancels against [Kn(x):Q]; this field cancellation and the exact orbit weights are retained. Lifted canonical heights tend uniformly to zero along fibers by (4.9). Averaging all finite-preimage components and using both signs of λ bounds liminf and limsup. The second displayed source expression contains a sign-format/index typo in the OCR, so the matching image controls the intended upper bound.

The resulting error before dividing by |λ| is O(n^{-2}+λ²n+κ_n λ²n²)+ε. The final parameter choice and normalized limit continue next page; no full completion credit yet.
