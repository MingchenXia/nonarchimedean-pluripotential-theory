# Actual ordered reading 19 — Kühne JEMS, physical pages 37–38 (2113–2114)

Complete text and matching image read. Actual coverage 1–38 only; no Xue or later-source credit, no independent original-result verdict.

The proof of Proposition 4.1 finishes with the error after division by |λ|: O(n^{-2}|λ|^{-1}+|λ|n+κ_n|λ|n²)+ε/|λ|. Choosing λ=n^{-3/2} and ε=n^{-1/2}|λ| makes all terms O(n^{-1/2}), since κ_n=O(n^{-2}); Lemma 4.3 then identifies the leading mixed limit. Interpret the bound as a limsup bound before knowing convergence; the printed display abbreviates it as a limit. Section 4 ends here, so no published Theorem 4.7 occurs in this section. The Xue attribution of a global theta-height comparison to that locator cannot be authenticated from this published source.

Section 5 is exclusively ARCHIMEDEAN. For X of dimensions d and abelian-image d', t'=d−d', the positive relative-intersection tuples I_X select toric coordinates. Their unit-modulus loci X_i are compact real-analytic subsets of the projective closure. E_i removes rank defects, singular loci, singular image fibers and compactification boundary; the rank condition glues by the invariant vertical distributions of Lemma 3.3.

Lemma 5.1 proves E_i is proper by a positive fiber intersection forcing a toric-coordinate map of generic full rank. Outside E_i, π×ψ_i is a local biholomorphism to the base image times (Gm)^{t'}, and the unit-modulus slice is locally the corresponding product with (S1)^{t'}. Its REAL dimension is 2d'+t'=d+d', not d. The finite real-analytic stratification and compactness argument are imported from the cited analytic theorem. Later Haar-density formulas must distinguish this real slice dimension from complex dimension and retain any finite covering/lattice index.
