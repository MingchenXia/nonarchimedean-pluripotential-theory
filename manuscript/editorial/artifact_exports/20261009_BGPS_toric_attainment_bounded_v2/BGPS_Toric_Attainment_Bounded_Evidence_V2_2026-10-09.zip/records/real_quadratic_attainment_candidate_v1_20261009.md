# Real-quadratic adversarial candidate for separate-place attainment

Status: **RESEARCH CANDIDATE — exact direct calculation, awaiting independent verification**.
This is a source-audit dossier, not a book theorem or a production VERIFIED
receipt. It tests the literal converse of published BGPS Proposition 5.13,
physical 51–52 / printed 358–359, DOI 10.1353/ajm.2019.0007.
The exact source PDF is SHA256
`d8b3f9c9b12d0151502dc5b112b0b57689cce16fbeb34793e8b747d80f66a75e`.
The statement and entire printed proof, place weights, point-height definition
and monocritical criterion have been actually read in the matching page views.

## Signature and metric

Let K=Q(sqrt(2)), with real embeddings sigma_+(sqrt(2))=sqrt(2) and
sigma_-(sqrt(2))=-sqrt(2). Use standard absolute values and weights
n_+=n_-=1/2, with the usual weighted finite places. Let T=Gm and
X=P1_K, with ample degree-one toric Cartier divisor D=[infinity].
Set a=log(2), u_+=-a, u_-=a, u_v=0 at every finite place. Thus
sum_v n_v u_v=0. In the affine coordinate z and frame nonvanishing away
from infinity, give D the continuous metric with psh potential

    g_v(z)=log max(1, exp(u_v)*|z|_v).

Equivalently its concave metric function is
psi_v(t)=min(0,t-u_v), for t=-log|z|_v. At finite places use the
canonical model metric. At real places these are translated canonical
continuous positive toric metrics; their local curvature is Haar measure
of mass one on radius exp(-u_v). They are invariant under complex
conjugation and extend continuously as line-bundle metrics at zero and
infinity. This is a finite-support adelic semipositive metric, with ample
underlying divisor; it is not restricted to smooth archimedean metrics.

The local roof on Delta=[0,1] is theta_v(x)=u_v*x, so the global roof is
identically zero. At an interior x, each local sup-differential is the
singleton {u_v} and the global one is {0}. This meets the actually read
monocritical criterion in Proposition 4.16. A direct alternative is that
for any centered probability family the energy
sum_v n_v integral max(0,u_v-t) has minimum zero only when each measure
is supported on t=u_v: all nonnegative terms must vanish, and weighted
centering then forces the remaining nonnegative deviations to vanish.

## The displayed separate-place condition holds

At sigma_+, u_+=val_+(2)=-log 2. At sigma_-,
u_-=val_-(1/2)=log 2. At every finite place the zero vector is a
valuation. Consequently u_v belongs to val_v(T(K)) already, with no
tensoring by Q needed, separately for every place. The witness is allowed
to differ with v in the printed condition (5.4). Neither 2 nor 1/2 is a
unit at the finite places over 2; that is precisely why these separate
witnesses are not one simultaneous global realization.

## Direct height formula and nonattainment in the torus

For alpha in T(Kbar) and any finite defining extension F/K, the actual
height convention gives

    h_D(alpha)=sum_{w in M_F} n_w max(0, log|alpha|_w+u_{v(w)}).

This is nonnegative. The weighted sum of the arguments of max is zero,
by the product formula and centering. Hence height zero forces

    |alpha|_w=2  for every w above sigma_+,
    |alpha|_w=1/2  for every w above sigma_-,
    |alpha|_w=1  for every finite w.

Let d=[F:K] and q=N_{F/K}(alpha) in K*. The norm identity at a real
place, including every conjugate with multiplicity, then gives
|sigma_+(q)|=2^d and |sigma_-(q)|=2^(-d).
Since q lies in the real quadratic field, the first equality implies
sigma_+(q)=2^d or -2^d. Injectivity of sigma_+ and its identity on Q
then force q=2^d or -2^d as an element of K. Its other embedding has
the same absolute value 2^d, contradicting 2^(-d) for d>=1.

Thus the direct calculation gives no height-zero **torus** point, even
over a finite extension. It does not claim the boundary has no
height-zero points; for this metric the boundary point zero does have
height zero. BGPS special points in Definition 5.10 and the proof of
5.13 are points in the principal torus.

## Essential minimum zero without attainment in the torus

Let epsilon=1+sqrt(2), a unit of norm -1. Its two absolute values are
epsilon and epsilon^(-1), and all finite absolute values are one.
For a positive integer ell, choose k_ell nearest to
ell*log(2)/log(epsilon), and choose any ell-th root alpha_ell of
epsilon^(k_ell) over K. Every conjugate over the first real place has
modulus epsilon^(k_ell/ell), and over the second has reciprocal modulus.
Finite moduli are one. Therefore

    h_D(alpha_ell)=1/2 * |(k_ell/ell)*log(epsilon)-log(2)|
                 <= log(epsilon)/(4*ell).

The ratio log(2)/log(epsilon) is irrational: an integer relation would
make a nonzero power of epsilon equal to a power of 2, contradicted by
its two real absolute values. The rational exponents thus supply
infinitely many distinct points approaching height zero. Extract a
distinct subsequence; on P1 it is generic. The direct nonnegative height
formula and the definition of essential minimum prove mu_ess=0, with
no torus point attaining it.

## Diagnosis, scope and further verification

The candidate targets the claimed commensurability of

    H_K,S intersect direct_sum_v val_v(T(K))

with the image of one simultaneous S-unit valuation map. Dirichlet's
unit theorem gives a lattice for the latter map. It does not give the
claimed equality with the product of independently selected values.
Replacing the printed condition by membership of the full centered
vector in the rational span of the simultaneous global valuation image
would retain the norm/root construction. This is a conditional repair
direction, not a proved replacement theorem here.

The dossier does not refute the geometric translated-subtorus clause
of BGPS Theorem 5.12, its generic or strict equidistribution theorems,
or the classical canonical Bogomolov theorem. Its additional
special-point clause and Corollary 5.15 use the flagged 5.13 converse.
The subsequent Xue criterion also cites it and must preserve this issue.
No current publication priority or formal erratum is claimed. A
targeted primary-source search found the same printed condition in the
author-hosted preprint; this is not an exhaustive errata search or an
actual full read of that preprint.

Before promotion, verify the exact signature, metric admissibility,
all-place norm argument and nonattainment against an independent
production verifier. The active book, canonical 42-atom inventory,
native catalogue source and mathematical statuses are unchanged.
