# Actual BGPS published reading 9 — physical pages 41–42 / printed 348–349

Complete selected text and matching displayed image read. Actual distinct selected coverage: physical 11–14 and 41–54, eighteen of 74 pages.

Definition 4.14 and Proposition 4.16's full statement and proof through its concluding paragraph on already-read page 43 are now actually read. Monocriticality is uniqueness of the minimizing centered adelic measure, attained by a centered family of Dirac masses. Equivalent conditions retain vertex conditions in the local sup-differentials, uniqueness of the centered intersection, a vertex at zero in the global sup-differential at a roof maximum, and singleton local faces. Merely writing a unique vector without the vertex condition would not exclude non-Dirac minimizing measures.

For a translated canonical degree-one P1 metric with local roofs x*u_v and weighted sum u_v=0, the global roof is zero on [0,1]. At its interior point the global sup-differential is {0} and every local one is {u_v}; this is the precise source criterion relevant to the proposed real-quadratic test. Positivity and bigness remain assumptions, and the normal translated canonical metrics satisfy them. The source's proof imports Lemma 4.8 and the convex sum/vertex Lemma 3.15; they are not recursively cleared by this selected reading.

The argument distinguishing two equal-energy centered measures when a local coordinate is not a vertex is conceptually clear. The printed phrase placing the measure nu2 in the vector set (4.18) is a type mismatch; the relevant property is that nu2 is a centered admissible measure supported on the local sup-differentials. This does not affect the explicit interior-singleton calibration or justify a global source verdict.

The formal monocritical signature is now checked for the calibration, but the original height formula still needs the next supplementary pages. No book insertion or independent production-verifier verdict is claimed.
