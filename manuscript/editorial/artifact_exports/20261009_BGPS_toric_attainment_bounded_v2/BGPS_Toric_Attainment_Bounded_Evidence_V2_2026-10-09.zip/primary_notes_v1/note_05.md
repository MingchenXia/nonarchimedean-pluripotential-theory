# Actual BGPS published reading 5 — physical pages 51–52 / printed 358–359

Complete selected text and matching displayed image read. Actual selected coverage: physical 43–52, ten of 74 pages.

Proposition 5.13's entire statement and printed proof are read. The matching image uses ground-field T(K) in (5.4) and in the root q in T(K), whereas the special point p is allowed over the algebraic closure. Necessity is proved using the field norm and equal valuations at every conjugate, supplied by Corollary 4.9 and finite-extension compatibility. Every special point is asserted to have a positive power in T(K), using Kronecker's theorem after comparing with the constructed special point.

The converse introduces Gamma=H_K,S intersect direct_sum_v val_v(T(K)) and asserts that the image Lambda of the simultaneous S-unit valuation map is a sublattice commensurable with Gamma. This assertion must be checked: the separate groups val_v(K*) include values of elements that are not S-units and independently selecting such values need not yield one simultaneous global element. For a real quadratic field with S consisting of its two real places, the separate-choice pair (log 2,-log 2) is centered and belongs to the displayed product of local valuation groups. It is not evidently a rational multiple of the simultaneous unit logarithm. A precise Q(sqrt(2)) model, together with the original place-weight conventions and a field-norm argument, is being prepared as an adversarial source calibration. No repaired criterion or independently verified original-source counterexample is claimed by this note.

Thus the exact simultaneous construction has been found, but its commensurability input is not cleared merely by the Dirichlet citation. The distinction flagged in the Xue notes between separate-place membership and simultaneous attainment remains substantive. It must not be erased from the book or source review by a reference to Proposition 5.13.

Proposition 5.14 gives the translated-subtorus criterion over a number field: all places w of the common finite defining extension must satisfy u_v(w) in val_w(p)+Q_R. If special, the restricted divisor is monocritical with critical vector u_v(w)-val_w(p), viewed in the subtorus lattice. The proof begins by passing to that common defining field; it continues on page 53. This explicitly supports the defining-field caution in Xue's restriction audit, rather than using only one chosen original-field place.

No new book theorem or production verifier receipt is claimed.
