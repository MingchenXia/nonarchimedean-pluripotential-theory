# Actual BGPS published reading 3 — physical pages 47–48 / printed 354–355

Complete selected text and matching displayed image read. Actual selected coverage: physical 43–48, six of 74 pages.

Theorem 5.2's proof finishes through the ample normal-fan model, classical generic small-point equidistribution (Theorem 2.11) and the explicit real Monge–Ampere mass vol_M(Delta)=deg(E)/n!. The normalized complex/non-archimedean measure is the Haar/Gauss probability of Definition 5.1. The toric source locators and classical general equidistribution inputs are visible imported dependencies, not recursively cleared in this bounded reading. The torus is common to the two models; any reuse of convergence across compactifications must retain this common-open/support justification.

The remainder of Section 5 explicitly switches to number fields, archimedean places and sequences, using an earlier countability reduction rather than silently replacing arbitrary nets. Definition 5.6's strictness excludes every proper translated subtorus. This is stronger than avoiding only torsion translates and stronger than genericity in an arbitrary fixed subvariety; the source explains the difference next.

Theorem 5.7 permits a monocritical toric metrized R-divisor and gives strict archimedean equidistribution. Its proof maps by each nonzero character m to Gm in P1, equips the latter with the translated degree-one canonical metric centered at <m,u_v>, and uses global KR convergence plus height-functional continuity to obtain generic smallness of every character image. A character-image sequence is generic precisely because strictness excludes all its point fibers. The proof continues on page 49 with its Fourier argument.

This exact monomial argument works on the ambient torus with the actual character as the quotient coordinate; it does not support replacing an inactive coordinate on a nonlinear subvariety by an assumed monomial in that subvariety's selected active coordinates. Thus it does not clear the unrelated printed Xue Proposition 9.6.

No new book theorem, whole-source coverage or independent-model verdict is claimed.
