# Actual BGPS published reading 7 — physical pages 11–12 / printed 318–319

Complete selected text and matching displayed image read. Actual coverage is the fourteen distinct selected pages 11–12 and 43–54 of 74. This supplementary reading is chronological after note 6, although its physical pages precede the initial bounded selection.

The end of the introduction describes historical questions about smooth non-toric archimedean metrics, essential-minimum formulae and generalizing monocriticality. They are historical source proposals, not a current October 2026 open-problem inventory. Ballaÿ–Sombra's published arithmetic differentiability/equidistribution criterion was separately read and already distinguishes the pertinent necessity problem.

Section 2's original number-field normalization is now checked: usual absolute values extending Q's usual absolute values, with n_v=[K_v:Q_v]/[K:Q]. For K=Q(sqrt(2)), the two real places therefore each have weight 1/2. The full finite-extension places satisfy the sum-of-weights rule and the weighted product formula (Proposition 2.1). Thus a pair (-log 2,+log 2), zero at finite places, is centered with the source's actual conventions. The example does not incorrectly use squared complex absolute values or leave out place weights.

The function-field portion distinguishes structures coming from different base curves and explicitly renormalizes absolute values and weights to preserve extension compatibility. Its inseparability/local-degree details are irrelevant to the real-quadratic candidate and are not generalized from that candidate.

The definition of point height begins later; it has not yet been read by this note. No special-point counterexample, current open status or book result is independently VERIFIED.
