# Actual BGPS published reading 4 — physical pages 49–50 / printed 356–357

Complete selected text and matching displayed image read. Actual selected coverage: physical 43–50, eight of 74 pages.

Theorem 5.7's Fourier proof is now completely read. The character image has one-dimensional translated Haar limit. Any ambient cluster probability is supported on the compact valuation fiber by KR concentration; its nonconstant character moments vanish and Fourier uniqueness gives translated Haar. Compact complex analytification is metrizable, so sequential compactness is appropriate in this number-field archimedean setting. When writing the proof on a general compactification, rational character maps must be localized to the common torus: use a continuous ambient cutoff equal to one near the compact limiting support and vanishing off a torus neighborhood. Concentration makes the omitted probability vanish. One should not assume an arbitrary rational-character pullback is globally continuous across an indeterminacy locus. This is a standard explanatory completion, not a new theorem or a source-specific global repair.

Remark 5.8 explicitly distinguishes strictness from Bilu's convention and explains why small canonical-height sequences recover the torsion-translate formulation. Remark 5.9 states a historical 2019 unresolved non-archimedean strict-equidistribution question, even for the canonical metric. It is not treated as a verified October 2026 open problem without a current primary-literature search.

Definition 5.10 calls a torus subvariety D-special when its essential minimum equals the ambient essential minimum. The equal ambient essential/torus absolute minima are imported from BPS15 Lemma 3.9(2). Thus the toric source's D-special terminology is an equality of minima; Xue's geometric subgroup-translate terminology must be compared rather than silently substituted.

Theorem 5.12's full statement is read: number field, proper toric variety, monocritical metrized R-divisor; every D-special subvariety is a translated subtorus. If each critical coordinate belongs to val_v(T(K)) tensor Q, the translate can be chosen through a D-special point. In the matching image, the K in this last valuation condition is the ground field K without an algebraic-closure bar. This distinction is important for the simultaneous point-attainment criterion and will be checked against Proposition 5.13 on the next page. No statement/proof is inferred from a search snippet.

No new book content, non-archimedean strict theorem or recursive dependency clearance is claimed.
