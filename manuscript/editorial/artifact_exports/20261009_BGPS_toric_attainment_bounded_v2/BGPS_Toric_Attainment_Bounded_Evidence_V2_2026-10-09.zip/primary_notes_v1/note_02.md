# Actual BGPS published reading 2 — physical pages 45–46 / printed 352–353

Complete selected text and matching displayed image read. Actual selected coverage: physical 43–46, four of 74 pages.

Definition 5.1 fixes probability normalization: at an archimedean place the limit is translated compact-torus Haar probability; at a non-archimedean place it is a Dirac mass at the weighted Laurent Gauss seminorm max_m |a_m| exp(-<m,u>). Modulus concentration alone does not generally imply phase Haar distribution without the arithmetic generic-small-sequence theorem.

Theorem 5.2 explicitly restricts full equidistribution to a semipositive toric metrized divisor, rather than an arbitrary R-divisor, with big geometry on a proper toric variety over a global field. Every generic small net and every place occur in its equivalence with monocriticality. That visible coefficient restriction must not disappear when quoting the theorem. The proof begins here and continues on page 47.

Proposition 5.3 is exactly the normal-form locator used by Xue. For a semipositive big toric R-divisor, quasi-canonicity, constancy of the global roof and the form psi_v(z)=Psi_D(z-u_v)-gamma_v are equivalent, with centered adelic u and finite-support real constants gamma. Its proof explicitly imports BPS15 Corollary 4.7 and Proposition 4.6; those recursive proofs have not been read in this bounded audit. It is not a statement about arbitrary continuous toric metrics without semipositivity/bigness.

Proposition 5.4's complete proof is read. The replacement psi'_v(z)=Psi_D(z-u_v) has global roof zero, and every original small net is replacement-small by global adelic KR convergence and continuity of the height functional. The roof's local linear functions sum to zero by centering. This is the original toric source behind the analogous quasi-canonical replacement, rather than a justification of semiabelian gluing identities.

Theorem 5.2's proof uses the normal fan of the full-dimensional polytope to pass to an ample toric model and retain the same local metric functions. That is a geometric modification argument, not an assumption that every proper fan is projective. No new book content or Xue theorem clearance is claimed.
