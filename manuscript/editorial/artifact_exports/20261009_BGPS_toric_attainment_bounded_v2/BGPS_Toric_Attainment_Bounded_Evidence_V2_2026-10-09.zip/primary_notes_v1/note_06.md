# Actual BGPS published reading 6 — physical pages 53–54 / printed 360–361

Complete selected text and matching displayed image read. Actual selected coverage: physical 43–54, twelve of 74 pages. This completes the initially bounded six-view preparation, not the whole paper.

Proposition 5.14's complete proof is read. Concavity and a full-dimensional underlying polytope give strict support-function coercivity; restriction to the saturated subtorus retains bigness and semipositivity. The restricted metric functions are psi_v(val_v(p)+iota(z)). The essential-minimum minimization is over centered affine-position vectors; monocriticality isolates the original critical vector. The proof imports Corollary 4.10 and BPS14 Proposition 4.3.19. The defining-field reduction and all-place affine conditions remain explicit. In contrast with the semiabelian case, the subtorus is genuinely the dense torus of its normalization.

Corollary 5.15's special-point conclusion directly uses Proposition 5.13's separate-place-to-simultaneous construction. It therefore inherits the unchecked commensurability step isolated in note 5. Theorem 5.12's final additional special-point clause also uses that corollary. This source audit does not clear those statements by transitive citation.

The main geometric translated-subtorus assertion of Theorem 5.12 has a distinct proof, now completely read: pass to the minimal translated-subtorus envelope, restrict the monocritical metric by Proposition 5.14, choose a generic small sequence in V, obtain strictness from minimality, and apply archimedean Theorem 5.7. The limiting translated compact torus is Zariski dense, whereas the terms lie in the closed V, forcing V to equal its envelope. This geometric clause does not use the problematic point-attainment converse. Example 5.16's zero critical vector and canonical torsion criterion also have the usual direct Kronecker argument; no failure of the classical canonical Bogomolov theorem is inferred.

When transferring the proof to a common complex analytification, define V over a common finite extension before asserting its orbit measures stay in one V, and use probability/tightness on the open torus. The published Proposition 5.14 supplies the finite-field framework rather than ignoring it.

Next checks will read the original place-weight/height conventions and the full monocritical criterion before evaluating the real-quadratic special-point calibration. No original-source counterexample is promoted to book typography or independent VERIFIED status.
