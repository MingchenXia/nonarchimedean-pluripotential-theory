# Actual BGPS published reading 1 — physical pages 43–44 / printed 350–351

Complete selected text and matching displayed image read. This is two selected pages of a 74-page published PDF, not a whole-source read. The controlling edition is AJM 141 (2019), 309–381, DOI 10.1353/ajm.2019.0007, SHA256 d8b3f9c9b12d0151502dc5b112b0b57689cce16fbeb34793e8b747d80f66a75e.

Proposition 4.17 is the exact finite-extension compatibility cited by Xue: the pulled-back divisor is monocritical and every place w over v has the same critical coordinate u_v. Its explanation imports BPS14 Proposition 4.3.8. This verifies the published locator and statement, not that unread recursive toric-metric source.

Theorem 4.18 is stated for every small net in the principal torus, without a genericity condition, and characterizes modulus concentration at all places by monocriticality. Its proof imports Corollary 4.13 and Proposition 4.16; the latter's concluding paragraph is visible here, but its full statement/proof lies on earlier unread pages.

The complete printed proof of Theorem 4.19 is read. It upgrades one-place weak concentration to global adelic KR convergence using the global small-height budget and centering. The bounded functions f_v=psi_v-Psi_D(.-u_v) vanish outside finitely many places. Weak convergence controls those corrections; the adjusted energy tends to zero. For an interior polytope point x, the correct coercivity is norm(z)<=c*(<x,z>-Psi_D(z)). The weighted product formulas remove the linear term after integration and yield global KR distance <= c times adjusted energy. Neither local weak convergence by itself nor an uncentered family gives this argument. Nets are retained.

Section 5 begins with a proper toric variety over a global field and a big underlying R-divisor. This two-page reading supplies no positive-characteristic or semiabelian extension beyond the actual source statements, and no new Xue-page credit or book theorem.
