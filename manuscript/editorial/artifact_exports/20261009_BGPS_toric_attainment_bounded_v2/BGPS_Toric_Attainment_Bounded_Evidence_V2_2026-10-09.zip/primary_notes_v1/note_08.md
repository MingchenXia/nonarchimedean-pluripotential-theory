# Actual BGPS published reading 8 — physical pages 13–14 / printed 320–321

Complete selected text and matching displayed image read. Actual coverage is sixteen distinct selected pages: 11–14 and 43–54 of 74.

The source distinguishes the fixed ground field K from its algebraic closure and defines algebraic points and their full ground-field Galois orbits accordingly. Each place has a chosen embedding into its completed algebraic closure; the orbit probability in (2.4) is uniform on the finite orbit. The local metric is the pullback of a metric over K_v and is invariant under local Galois action. Thus a field-norm argument for an algebraic point may not check only one embedding: it needs all conjugates over the relevant real place, exactly as the candidate calibration will require.

Metrized R-divisors carry quasi-algebraic families of continuous metrics. Canonical finite-place metrics plus two real-place continuous toric metrics meet the relevant finite-support adelic pattern; no arbitrary infinitely supported metric family is being substituted. A real-place metric depending on modulus is conjugation-invariant.

The point-height definition chooses a rational section nonvanishing at the point, a finite defining field and compatible local embeddings. Its summation formula continues on page 15 and is not yet included in this reading. Preparing the additional page later will not rewrite the frozen supplementary manifest or grant mechanical reading credit.

This page read confirms the ground-field/algebraic-closure distinction used in the literal Proposition 5.13. It neither authenticates every recursive BMPS16 metric input nor supplies a production-verifier verdict. No book change is claimed.
