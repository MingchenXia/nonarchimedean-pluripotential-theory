from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile
R=Path('/workspace/nonarchimedean-pluripotential-theory');E=R/'manuscript/editorial'
C=R/'source_material/Xue_semiabelian_review_20261009/dependencies_v1/BGPS19Published'
W=Path('/tmp/Xue_semiabelian_dependency_views_v1_20261009/BGPS19Published')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();now=lambda:datetime.now(timezone.utc).isoformat()
src=json.loads((C/'source_acquisition_v1_20261009.json').read_text())['source'];assert sha(src['path'])==src['SHA256']
views=[]
for version,name in [('v1','manifest.json'),('v2','manifest_supplement_v2.json'),('v3','manifest_height_v3.json')]:
    prep=json.loads((C/('source_preparation_'+version+'_20261009.json')).read_text())
    assert sha(W/name)==prep['manifest_SHA256'];views+=json.loads((W/name).read_text())
assert [v['number'] for v in views]==list(range(1,11))
receipts=[];pages=[];previous=None
for i,v in enumerate(views,1):
    p=C/'primary_notes_v1'/('note_%02d.md'%i);r=p.with_name('note_%02d_receipt.json'%i);d=json.loads(r.read_text())
    assert d['view_number']==i and d['physical_pages']==v['physical_pages']
    assert d['source_PDF_SHA256']==src['SHA256'] and d['note_SHA256']==sha(p) and d['previous_receipt_SHA256']==previous
    assert d['full_selected_text_read'] and d['matching_rendered_image_displayed_and_read']
    assert sha(d['image_path'])==d['image_SHA256']==v['image_SHA256']
    assert sha(d['selected_text_path'])==d['selected_text_SHA256']==v['selected_text_SHA256']
    pages+=d['physical_pages'];previous=sha(r)
    receipts.append(dict(view_number=i,physical_pages=d['physical_pages'],note_path=str(p),note_SHA256=sha(p),receipt_path=str(r),receipt_SHA256=sha(r)))
assert len(pages)==len(set(pages))==20 and sorted(pages)==list(range(11,17))+list(range(41,55))
candidate=C/'real_quadratic_attainment_candidate_v1_20261009.md';cal=C/'real_quadratic_attainment_calibration_v1_20261009.json'
dc=json.loads(cal.read_text());assert dc['full_candidate_SHA256']==sha(candidate) and not dc['production_VERIFIED']
cp=C/'actual_source_checkpoint_v1_20261009.json';assert not cp.exists()
obj=dict(UTC=now(),status='COMPLETE BOUNDED ACTUAL READING — twenty selected published pages; adversarial attainment candidate awaiting independent verification',DOI='10.1353/ajm.2019.0007',edition='AJM 141(2), April 2019, 309–381',source_PDF_SHA256=src['SHA256'],source_total_physical_pages=74,actual_pages=sorted(pages),actual_matching_views=10,receipts=receipts,other_page_credit=0,whole_source_read=False,locators_actually_read=['2.1–2.5 and full place/height definitions','Definition 4.14 and Proposition 4.16','Proposition 4.17 and Theorems 4.18–4.19','Definition 5.1 and Theorem 5.2','Propositions 5.3–5.4 and Definition 5.6','Theorem 5.7 with full printed proof','Theorem 5.12 and Propositions 5.13–5.14 with full printed proofs','Corollary 5.15 and Example 5.16'],recursive_inputs_verified=False,candidate_path=str(candidate),candidate_SHA256=sha(candidate),calibration_path=str(cal),calibration_SHA256=sha(cal),candidate_status='RESEARCH CANDIDATE — not production VERIFIED',candidate_scope='Printed separate-place attainment converse and its special-point consequences; not geometric Bogomolov or equidistribution',independent_verifier_receipt=False,intended_geometric_Bogomolov_counterexample=False,Xue_main_theorem_counterexample=False,book_changed=False,canonical_status_changes=[],native_compile_success_verified=False,helper_source=__file__,helper_SHA256=sha(__file__))
cp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
prefix='BGPS_toric_attainment_bounded_source_'
paths={k:E/(prefix+k+'_v1_20261009.'+ext) for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]};assert not any(p.exists() for p in paths.values())
review='''# Published toric attainment input: bounded source audit

BGPS, *The distribution of Galois orbits of points of small height in
toric varieties*, AJM 141(2) (2019), 309–381, DOI 10.1353/ajm.2019.0007.
The repository's exact published PDF has SHA256
`d8b3f9c9b12d0151502dc5b112b0b57689cce16fbeb34793e8b747d80f66a75e`.
**Actual selected reading: physical 11–16 and 41–54, twenty of 74
pages, in ten complete-text and matching-image displays.** Other pages
and recursive BPS/convex inputs are not credited.

## Original theorem boundaries

The actual published source separates global adelic KR concentration,
generic all-place equidistribution, strict archimedean equidistribution,
geometric translated-subtorus Bogomolov, and special-point attainment.
Theorem 5.2 uses a semipositive big toric metrized divisor, rather than
an arbitrary R-divisor. Theorem 5.7 permits monocritical R-divisors but
restricts to number fields and archimedean places. Strictness avoids
every proper translated subtorus; it is not arbitrary subvariety genericity.
Proposition 5.14 uses all places of one common defining extension.
Theorem 4.19 upgrades local convergence using the global height budget
and weighted product formula; it does not follow from local weak limits
alone. Full printed proofs in the selected range were actually read.

## Separate-place versus simultaneous attainment

Proposition 5.13's literal condition uses **ground-field** T(K), with
u_v in val_v(T(K)) tensor Q separately at every place. Its proof claims
commensurability of a product of independently selected valuation groups
with the image of one simultaneous S-unit valuation map. This is a
substantive unresolved input in the source audit, not cleared by a
reference to Dirichlet's unit theorem.

A complete **adversarial research candidate** tests that converse over
K=Q(sqrt(2)), with P1 and the degree-one translated canonical metric.
Set u_+=-log 2, u_-=log 2, and finite coordinates zero, with real weights
1/2. The roof is zero and its interior sup-differentials meet the exact
monocritical criterion. The separate-place condition has witnesses 2
and 1/2. The direct height formula is nonnegative and would force a
height-zero torus point alpha to have modulus 2 at every conjugate over
the first real place and 1/2 over the second. Its field norm q in K would
then have moduli 2^d and 2^-d. The first forces q=±2^d in K, contradicting
the second. Roots of powers of the unit 1+sqrt(2) have heights tending
to zero, so the candidate separates essential minimum zero from torus
point attainment. Boundary point zero is excluded from the target
special-point notion and is not claimed to have positive height.

The dossier records the metric, normalization, all-place norm argument,
generic approximants, candidate repair direction and seven illustrative
numeric checks. Numerics are not the nonattainment proof. **The candidate
has no independent production-verifier receipt and is not promoted to a
book theorem or VERIFIED result.** The geometric clause of Theorem 5.12
and its equidistribution inputs have different proofs; they are not
refuted by this candidate. Its extra special-point clause and Corollary
5.15 depend on the flagged converse. Xue's cited simultaneous criterion
must retain this issue.

## Current book and evidence

The active 4,675-page book and the 42-atom/twelve-problem inventory are
unchanged. The existing arithmetic integration does not import this
special-point criterion; a scoped source search/read of Chapter 27 and
its provenance does not justify a new whole-book read claim. BJ22 general
Siu/envelopes and LPWZ density retain their existing statuses. Native
catalogue compilation remains unverified; its editor/source and historical
PDF remain preserved. No newer arXiv source is integrated by this audit.

The ZIP has 59 authored notes, receipts, preparation/acquisition records,
candidate/calculation files and executed helpers. It excludes primary
PDFs, complete extracted text and page images. Earlier Xue and dependency
records remain frozen. Upload adds no reading credit or theorem clearance.
'''
paths['review'].write_text(review)
notes='# Actual bounded published toric-source notes\n\nTwenty selected pages in ten matching views; no whole-source reading.\n\n'
notes+='\n\n---\n\n'.join((C/'primary_notes_v1'/('note_%02d.md'%i)).read_text().rstrip() for i in range(1,11))
notes+='\n\n---\n\n'+candidate.read_text();paths['reading_notes'].write_text(notes)
paths['manifest'].write_text(json.dumps(dict(obj,source_URL='https://diposit.ub.edu/bitstreams/bb1dde47-73f3-4929-a6c1-e1de5b00d650/download',checkpoint_SHA256=sha(cp),Xue_complete_publication='manuscript/editorial/Xue_semiabelian_complete_GitHub_publication_v3_20261009.json'),ensure_ascii=False,indent=2)+'\n')
X=E/'artifact_exports/20261009_BGPS_toric_attainment_bounded_v1';assert not X.exists();X.mkdir();members={}
for i in range(1,11):
    for suffix in ['.md','_receipt.json']:
        p=C/'primary_notes_v1'/('note_%02d'%i+suffix);members['primary_notes_v1/'+p.name]=p
for name in ['source_acquisition_v1_20261009.json','source_preparation_v1_20261009.json','source_preparation_v2_20261009.json','source_preparation_v3_20261009.json','actual_source_checkpoint_v1_20261009.json','real_quadratic_attainment_candidate_v1_20261009.md','real_quadratic_attainment_calibration_v1_20261009.json']:
    members['records/'+name]=C/name
for name in ['manifest.json','manifest_supplement_v2.json','manifest_height_v3.json']:members['records/'+name]=W/name
for name in ['Xue_semiabelian_acquire_BGPS_published_v1_20261009.py','Xue_semiabelian_prepare_BGPS_bounded_v1_20261009.py','Xue_semiabelian_prepare_BGPS_supplement_v2_20261009.py','Xue_semiabelian_prepare_BGPS_height_v3_20261009.py','Xue_semiabelian_record_dependency_reading_v1_20261009.py','Xue_semiabelian_record_BGPS_supplement_v2_20261009.py','Xue_semiabelian_record_BGPS_height_v3_20261009.py','Xue_semiabelian_BGPS_real_quadratic_calibration_v1_20261009.py','Xue_semiabelian_export_BGPS_bounded_v1_20261009.py']:
    members['executed_helpers/'+name]=Path('/tmp')/name
assert len(members)==59
archive=X/'BGPS_Toric_Attainment_Bounded_Evidence_V1_2026-10-09.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(members.items()):z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==59
    for name,p in members.items():assert z.read(name)==p.read_bytes()
(X/'README.md').write_text('''# Bounded published toric-source audit and attainment candidate

Actual reading covers physical 11–16 and 41–54, twenty of 74 pages,
in ten matching views. The 59-member ZIP preserves authored notes,
receipts, records, a real-quadratic adversarial candidate and helpers.
No primary PDFs, full text or rendered images are redistributed. The
candidate has no independent production-verifier receipt and is not
promoted to a book theorem. The geometric Bogomolov and equidistribution
clauses are not refuted. Book and canonical statuses are unchanged.
''')
(X/'SHA256SUMS').write_text(sha(archive)+'  '+archive.name+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=now(),status='EXPORTED — bounded original-source audit and unverified research candidate',archive=str(archive.relative_to(R)),bytes=archive.stat().st_size,SHA256=sha(archive),members=59,actual_BGPS_pages=20,total_BGPS_pages=74,BGPS_views=10,book_changed=False,independent_verifier_receipt=False,production_VERIFIED=False,new_reading_credit_for_upload=0),indent=2)+'\n')
update='''
## Original toric attainment input, 9 October 2026

Read **twenty selected pages of 74** from published BGPS 2019, in ten
matching displays, including the full special-point and translated-subtorus
proofs and controlling place/height conventions. A real-quadratic adversarial
candidate tests the printed separate-place-to-simultaneous attainment
converse. It has **no independent production-verifier receipt**, remains
a research candidate and is not promoted to book typography. The geometric
Bogomolov and equidistribution clauses are not refuted by the candidate.

See [bounded original-source audit](manuscript/editorial/BGPS_toric_attainment_bounded_source_review_v1_20261009.md)
and [59-member authored evidence](manuscript/editorial/artifact_exports/20261009_BGPS_toric_attainment_bounded_v1/).
The **4,675-page book**, canonical statuses, catalogue source and historical
PDF remain unchanged. Native catalogue compilation is still unverified.
'''
readme=R/'README.md';readme.write_text(readme.read_text().rstrip()+'\n'+update)
progress=E/'second_reading_and_research_programme_20261002.md';progress.write_text(progress.read_text().rstrip()+'\n'+update.replace('(manuscript/editorial/','('))
owned=[*paths.values(),*sorted(X.iterdir()),readme,progress];assert len(owned)==9
out=C/'bounded_evidence_export_v1_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=now(),status='READY FOR EXPLICIT NINE-FILE PUBLICATION — bounded source audit and candidate',owned_files=[dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,SHA256=sha(p)) for p in owned],archive_members=59,actual_BGPS_pages=20,total_BGPS_pages=74,book_changed=False,independent_verifier_receipt=False,production_VERIFIED=False,helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
print(json.dumps(dict(status='EXPORTED',owned_files=9,archive_members=59,BGPS_pages=20,archive_SHA256=sha(archive),export_SHA256=sha(out))))
