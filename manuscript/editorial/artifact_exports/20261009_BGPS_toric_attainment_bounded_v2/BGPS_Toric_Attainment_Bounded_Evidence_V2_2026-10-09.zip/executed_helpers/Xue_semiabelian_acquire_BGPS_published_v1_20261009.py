from pathlib import Path
from datetime import datetime, timezone
import urllib.request, hashlib, json
import fitz
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009/dependencies_v1/BGPS19Published')
assert not C.exists();C.mkdir()
url='https://diposit.ub.edu/bitstreams/bb1dde47-73f3-4929-a6c1-e1de5b00d650/download'
req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (mathematical source audit)'})
with urllib.request.urlopen(req,timeout=60) as r:
    payload=r.read();resolved=r.geturl();content_type=r.headers.get('Content-Type')
assert payload.startswith(b'%PDF-')
p=C/'BGPS_Distribution_Galois_orbits_2019_published.pdf';p.write_bytes(payload)
doc=fitz.open(p)
t=C/'BGPS_2019_published_preparation_text.txt'
t.write_text('\n\n'.join('PHYSICAL PAGE %d\n%s'%(i+1,doc[i].get_text()) for i in range(len(doc))))
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=C/'source_acquisition_v1_20261009.json'
out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACQUIRED AND MECHANICALLY EXTRACTED — zero actual reading credit',title='The distribution of Galois orbits of points of small height in toric varieties',authors=['José Ignacio Burgos Gil','Patrice Philippon','Juan Rivera-Letelier','Martín Sombra'],DOI='10.1353/ajm.2019.0007',edition='American Journal of Mathematics 141 (2), April 2019, 309–381',source_URL=url,resolved_URL=resolved,content_type=content_type,source=dict(path=str(p),SHA256=sha(p),bytes=len(payload),physical_pages=len(doc)),prepared_text=dict(path=str(t),SHA256=sha(t)),actual_pages=[],actual_primary_reading_credit=0,book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='ACQUIRED — no actual reading credit',physical_pages=len(doc),bytes=len(payload),SHA256=sha(p))))
