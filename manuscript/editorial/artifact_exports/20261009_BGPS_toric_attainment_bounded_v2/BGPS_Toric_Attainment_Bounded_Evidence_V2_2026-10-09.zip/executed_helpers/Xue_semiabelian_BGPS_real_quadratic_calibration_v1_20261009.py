from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction
from decimal import Decimal, localcontext, ROUND_HALF_EVEN
import hashlib, json
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009/dependencies_v1/BGPS19Published')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
src=json.loads((C/'source_acquisition_v1_20261009.json').read_text())['source']
assert sha(src['path'])==src['SHA256']
candidate=C/'real_quadratic_attainment_candidate_v1_20261009.md'
assert candidate.exists() and (C/'primary_notes_v1/note_10_receipt.json').exists()
weights=[Fraction(1,2),Fraction(1,2)];coefficients=[-1,1]
assert sum(w*c for w,c in zip(weights,coefficients))==0
def mul(a,b):return (a[0]*b[0]+2*a[1]*b[1],a[0]*b[1]+a[1]*b[0])
assert mul((1,1),(1,-1))==(-1,0)
assert all(2**d != Fraction(1,2**d) for d in range(1,21))
numeric=[]
with localcontext() as ctx:
    ctx.prec=70
    a=Decimal(2).ln();b=(Decimal(1)+Decimal(2).sqrt()).ln()
    for ell in [1,2,10,100,1000,10000,1000000]:
        k=int((Decimal(ell)*a/b).to_integral_value(rounding=ROUND_HALF_EVEN))
        height=abs(Decimal(k)/Decimal(ell)*b-a)/Decimal(2)
        bound=b/(Decimal(4)*Decimal(ell))
        assert height>0 and height<=bound
        numeric.append(dict(ell=ell,k=k,height=str(height),bound=str(bound)))
out=C/'real_quadratic_attainment_calibration_v1_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='ADVERSARIAL RESEARCH CANDIDATE — exact algebraic/weight checks and illustrative numerical approximants; independent verification pending',source_PDF_SHA256=src['SHA256'],source_locator='BGPS Proposition 5.13, physical 51–52 / printed 358–359',field='Q(sqrt(2))',variety='P1, principal torus Gm',divisor='[infinity], degree one ample Cartier',critical_vector={'real_plus':'-log(2)','real_minus':'log(2)','finite':'0'},real_place_weights=['1/2','1/2'],centered_exactly=True,global_roof='0 on [0,1]',separate_place_condition_satisfied=True,local_potential='log max(1, exp(u_v)*|z|_v)',height='sum_w n_w max(0, log|alpha|_w+u_v(w))',norm_obstruction='Height zero requires norm q in K with first real absolute value 2^d and second 2^-d. The first forces q=±2^d in K, contradicting the second.',essential_minimum='0, by roots of powers of 1+sqrt(2)',unit_norm_exact='-1',numeric_approximants=numeric,numerics_prove_nonattainment=False,full_candidate_path=str(candidate),full_candidate_SHA256=sha(candidate),independent_verifier_receipt=False,production_VERIFIED=False,book_changed=False,canonical_status_changes=[],intended_geometric_Bogomolov_counterexample=False,Xue_main_theorem_counterexample=False,helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='CANDIDATE CALIBRATION SAVED — no independent VERIFIED verdict',numerical_examples=len(numeric),SHA256=sha(out))))
