from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, fitz
from PIL import Image, ImageDraw
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009/dependencies_v1/BGPS19Published')
W=Path('/tmp/Xue_semiabelian_dependency_views_v1_20261009/BGPS19Published')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
src=json.loads((C/'source_acquisition_v1_20261009.json').read_text())['source']
assert sha(src['path'])==src['SHA256'];doc=fitz.open(src['path']);views=[]
assert (C/'primary_notes_v1/note_06_receipt.json').exists()
for n,pages in enumerate([[11,12],[13,14],[41,42]],7):
    imgs=[]
    for p in pages:
        pix=doc[p-1].get_pixmap(matrix=fitz.Matrix(1.3,1.3),alpha=False)
        imgs.append(Image.frombytes('RGB',[pix.width,pix.height],pix.samples))
    canvas=Image.new('RGB',(sum(i.width for i in imgs),max(i.height for i in imgs)+35),'white')
    draw=ImageDraw.Draw(canvas);offset=0
    for p,img in zip(pages,imgs):
        canvas.paste(img,(offset,35));draw.text((offset+8,8),'BGPS published 2019: physical page %d / printed %d'%(p,p+307),fill='black');offset+=img.width
    ip=W/('sheet_%02d.png'%n);tp=W/('sheet_%02d.txt'%n);assert not ip.exists() and not tp.exists()
    canvas.save(ip);tp.write_text('\n\n'.join('BGPS PUBLISHED PHYSICAL PAGE %d / PRINTED %d\n%s'%(p,p+307,doc[p-1].get_text(sort=True)) for p in pages))
    views.append(dict(number=n,physical_pages=pages,path=str(ip),image_SHA256=sha(ip),selected_text_path=str(tp),selected_text_SHA256=sha(tp),source_PDF_SHA256=src['SHA256'],actually_viewed=False,selected_text_read=False))
m=W/'manifest_supplement_v2.json';assert not m.exists();m.write_text(json.dumps(views,indent=2)+'\n')
out=C/'source_preparation_v2_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='SUPPLEMENTARY VIEWS PREPARED — zero actual reading credit',source=src,prepared_physical_pages=[11,12,13,14,41,42],prepared_views=3,view_numbers=[7,8,9],manifest_path=str(m),manifest_SHA256=sha(m),prior_preparation_SHA256=sha(C/'source_preparation_v1_20261009.json'),actual_primary_reading_credit=0,book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
print('Prepared six supplementary pages; no actual reading credit.')
