from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, fitz
from PIL import Image, ImageDraw
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009/dependencies_v1/BGPS19Published')
W=Path('/tmp/Xue_semiabelian_dependency_views_v1_20261009/BGPS19Published')
assert not W.exists();W.mkdir();(C/'primary_notes_v1').mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
acq=json.loads((C/'source_acquisition_v1_20261009.json').read_text());src=acq['source']
assert sha(src['path'])==src['SHA256'];doc=fitz.open(src['path'])
groups=[[43,44],[45,46],[47,48],[49,50],[51,52],[53,54]]
views=[]
for n,pages in enumerate(groups,1):
    imgs=[]
    for p in pages:
        pix=doc[p-1].get_pixmap(matrix=fitz.Matrix(1.3,1.3),alpha=False)
        imgs.append(Image.frombytes('RGB',[pix.width,pix.height],pix.samples))
    canvas=Image.new('RGB',(sum(i.width for i in imgs),max(i.height for i in imgs)+35),'white')
    draw=ImageDraw.Draw(canvas);offset=0
    for p,img in zip(pages,imgs):
        canvas.paste(img,(offset,35));draw.text((offset+8,8),'BGPS published 2019: physical page %d / printed %d'%(p,p+307),fill='black');offset+=img.width
    ip=W/('sheet_%02d.png'%n);canvas.save(ip)
    tp=W/('sheet_%02d.txt'%n);tp.write_text('\n\n'.join('BGPS PUBLISHED PHYSICAL PAGE %d / PRINTED %d\n%s'%(p,p+307,doc[p-1].get_text(sort=True)) for p in pages))
    views.append(dict(number=n,physical_pages=pages,path=str(ip),image_SHA256=sha(ip),selected_text_path=str(tp),selected_text_SHA256=sha(tp),source_PDF_SHA256=src['SHA256'],actually_viewed=False,selected_text_read=False))
m=W/'manifest.json';m.write_text(json.dumps(views,ensure_ascii=False,indent=2)+'\n')
out=C/'source_preparation_v1_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='BOUNDED VIEWS PREPARED — zero actual reading credit',source=src,prepared_physical_pages=list(range(43,55)),prepared_views=6,source_total_physical_pages=74,manifest_path=str(m),manifest_SHA256=sha(m),actual_primary_reading_credit=0,book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
print(json.dumps(dict(status='PREPARED — no reading credit',pages=12,views=6)))
