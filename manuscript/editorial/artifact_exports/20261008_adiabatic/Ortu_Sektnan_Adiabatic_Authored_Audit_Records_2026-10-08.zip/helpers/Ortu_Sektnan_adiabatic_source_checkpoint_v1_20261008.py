from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,fitz,subprocess
R=Path('/workspace/nonarchimedean-pluripotential-theory');M=R/'manuscript';E=M/'editorial';C=R/'source_material/Ortu_Sektnan_adiabatic_review_20261008'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
actual=C/'actual_primary_full_reading_v1_20261008.json';out=C/'source_checkpoint_v1_20261008.json'
paths={k:E/f'Ortu_Sektnan_adiabatic_{k}_20261008.{ext}' for k,ext in [('source_review','md'),('source_reading_notes','md'),('source_reading_manifest','json'),('source_artifacts','json')]}
assert paths['source_review'].exists() and not actual.exists() and not out.exists()
assert not any(p.exists() for k,p in paths.items() if k!='source_review')
prep=C/'primary_view_preparation_v1_20261008.json';p=json.loads(prep.read_text())
assert sha(prep)=='839c1346a6c7fc516d2e0d0020d9746294dce5041596e1e20867a7d5db507b2d'
manifest=Path('/tmp/Ortu_Sektnan_adiabatic_primary_views_v1_20261008/manifest.json')
pdf=R/'source_material/Ortu_Sektnan_adiabatic_sources_20261008/Ortu_Sektnan_adiabatic_arxiv_v2.pdf'
assert sha(pdf)=='88a20d51645c922416f45a5715bfe8fa8f6f635843daee7fc742d0b7cd9a534c'
with fitz.open(pdf) as doc: assert len(doc)==45
views=[]
for v in json.loads(manifest.read_text()):
    assert v['actually_viewed'] is False and v['selected_text_read'] is False
    assert sha(v['path'])==v['image_SHA256'] and sha(v['selected_text_path'])==v['selected_text_SHA256']
    note=C/'primary_notes_v1'/f'{v["number"]:02d}.md';assert note.exists()
    v={k:x for k,x in v.items() if k not in ['actually_viewed','selected_text_read']}
    v.update(actual_complete_text_read=True,actual_matching_image_individually_displayed=True,sequential_note_path=str(note),sequential_note_SHA256=sha(note));views.append(v)
assert len(views)==23 and [n for v in views for n in v['physical_pages']]==list(range(1,46))
diag=C/'exact_diagnostics_v1_20261008.json';assert sha(diag)=='c6c3f31894ccc386219d79c1540e831ea110d8a83100797b6406731cad0911bd'
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete actual reading; analytic main theorem remains qualified',source_PDF=dict(path=str(pdf),SHA256=sha(pdf),physical_pages=45),preparation_path=str(prep),preparation_SHA256=sha(prep),manifest_path=str(manifest),manifest_SHA256=sha(manifest),views=views,actual_source_pages=45,actual_matching_images=23,complete_source_reading=True,preparation_flags_rewritten=False,recursive_external_source_verification=False,exact_diagnostic_record=dict(path=str(diag),SHA256=sha(diag)),main_theorem_certified=False,independent_model_receipt=None,original_results_promoted=[],canonical_status_changes=[],GitHub_published=False)
actual.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
notes='# Actual sequential primary notes, 8 October 2026\n\nAll 45 pages, 23 individually displayed matching images. Later sign resolutions remain in their actual sequential note; earlier pending notes are not silently overwritten.\n'
for v in views:notes+='\n---\n\n'+Path(v['sequential_note_path']).read_text()
paths['source_reading_notes'].write_text(notes)
paths['source_reading_manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status=obj['status'],actual_ledger_path=str(actual),actual_ledger_SHA256=sha(actual),record=obj,source_audit_SHA256=sha(paths['source_review']),whole_book_new_reading_claim=False,active_book_changed=False,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
core=set()
for line in (M/'book.fls').read_text().splitlines():
    if line.startswith('INPUT '):
        z=Path(line[6:]);z=(z if z.is_absolute() else M/z).resolve()
        if z.is_relative_to(M) and z.suffix=='.tex':core.add(z)
assert len(core)==425
core.update((M/'bibliography').glob('*.bib'));assert len(core)==427
core.update([M/'book.pdf',R/'output/open_problems_catalogue_2026-10-03.tex',R/'output/open_problems_catalogue_2026-10-03.pdf'])
protected={str(z):sha(z) for z in sorted(core)}
assert sha(M/'book.pdf')=='118cd7f387a21ed485694ba2f791f8f4c9ad60a45401f19693daab24cd1d9e78'
helpers=[Path('/tmp/Ortu_Sektnan_adiabatic_'+n+'_v1_20261008.py') for n in ['acquire','prepare_primary_views','exact_diagnostics','source_checkpoint']]
files=[z for name in ['Ortu_Sektnan_adiabatic_sources_20261008','Ortu_Sektnan_adiabatic_review_20261008'] for z in (R/'source_material'/name).rglob('*') if z.is_file()]
paths['source_artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — cloud source checkpoint; no upload',files=[dict(path=str(z),bytes=z.stat().st_size,SHA256=sha(z)) for z in sorted(files)],helpers={str(z):sha(z) for z in helpers},editorial_files={str(z):sha(z) for key,z in paths.items() if key!='source_artifacts'},protected_core_inputs=protected,active_TeX_inputs_preserved=425,bibliographies_preserved=2,native_catalogue_preserved=True,book_PDF_preserved=True,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE',baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),editorial_files={str(z):sha(z) for z in paths.values()},protected_core_inputs=protected,actual_source_pages=45,actual_images=23,active_book_changed=False,GitHub_published=False,helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
for z,h in protected.items():assert sha(z)==h
print(json.dumps(dict(status='DONE',checkpoint_SHA256=sha(out),actual_reading_SHA256=sha(actual),protected_inputs=len(protected))))
