from pathlib import Path
from datetime import datetime, timezone
import shutil,hashlib,json,re
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Ortu_Sektnan_adiabatic_review_20261008'
B=Path('/workspace/book-completion-drafts/transcendental-ytd-staging-v3-20261008')
S=Path('/workspace/book-completion-drafts/adiabatic-bundles-staging-v1-20261008');D=Path('/workspace/book-completion-drafts/adiabatic-bundles-integration-v1-20261008');out=C/'staging_preparation_v1_20261008.json'
assert not S.exists() and not out.exists()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
cp=json.loads((C/'source_checkpoint_v1_20261008.json').read_text())
for n,h in cp['protected_core_inputs'].items():assert sha(n)==h
assert sha(B/'manuscript/book.pdf')==sha(R/'manuscript/book.pdf')
shutil.copytree(B,S,ignore=shutil.ignore_patterns('*.pdf','*.aux','*.log','*.fls','*.fdb_latexmk','*.bbl','*.blg','*.toc','*.out','*.idx','*.ind','*.ilg','__pycache__'))
changed=[Path('manuscript/parts/part5/ch62_k_stability_kahler.tex'),Path('manuscript/appendices/appL_provenance.tex'),Path('manuscript/bibliography/ComplexGeometry.bib')]
before={str(n):sha(S/n) for n in changed}
assert all(sha(R/n)==h for n,h in before.items())
z=S/changed[0];t=z.read_text();marker='\\section{Completion from models to all finite energy}\n';assert t.count(marker)==1;z.write_text(t.replace(marker,(D/'ch62_adiabatic_fragment.tex').read_text()+marker))
z=S/changed[1];z.write_text(z.read_text()+(D/'appL_adiabatic_fragment.tex').read_text())
z=S/changed[2];fragment=(D/'adiabatic_bibliography_fragment.bib').read_text();keys=re.findall(r'@\w+\{([^,]+),',fragment);assert keys==['OrtuSektnan24AdiabaticV2']
assert all(keys[0] not in (R/'manuscript/bibliography'/name).read_text() for name in ['ComplexGeometry.bib','NonArchimedean.bib']);z.write_text(z.read_text()+fragment)
tex={str(Path(n).relative_to(R)):h for n,h in cp['protected_core_inputs'].items() if Path(n).is_relative_to(R/'manuscript') and Path(n).suffix=='.tex'};assert len(tex)==425
unchanged={n:h for n,h in tex.items() if Path(n) not in changed}
for n,h in unchanged.items():assert sha(S/n)==sha(R/n)==h
assert sha(S/'manuscript/bibliography/NonArchimedean.bib')==sha(R/'manuscript/bibliography/NonArchimedean.bib')
formal=[]
for n in changed[:2]:
    old=(R/n).read_text();new=(S/n).read_text();starts=re.findall(r'\\begin\{(theorem|proposition|lemma|corollary|definition|example|remark|warning|proof|important)\}',old)
    assert starts==re.findall(r'\\begin\{(theorem|proposition|lemma|corollary|definition|example|remark|warning|proof|important)\}',new)
    tags=re.findall(r'\\tag\{([^}]+)\}',old);newtags=re.findall(r'\\tag\{([^}]+)\}',new);assert all(tag in newtags for tag in tags)
    for env in ['theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important']:
        assert all(block in new for block in re.findall(r'\\begin\{'+env+r'\}.*?\\end\{'+env+r'\}',old,re.S))
    formal.append(dict(path=str(n),historical_formal_starts=len(starts),historical_proofs=starts.count('proof'),historical_manual_tags=len(tags),new_manual_tags=[tag for tag in newtags if tag not in tags]))
assert formal[0]['new_manual_tags']==['62.14e'] and not formal[1]['new_manual_tags']
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — isolated qualified adiabatic integration preparation',stage_path=str(S),baseline_stage_path=str(B),draft_path=str(D),before=before,after={str(n):sha(S/n) for n in changed},draft_fragments={str(z):sha(z) for z in sorted(D.iterdir())},active_inputs_preserved={str(n):sha(R/n) for n in changed},other_active_TeX_preserved=unchanged,unchanged_bibliography=dict(path='manuscript/bibliography/NonArchimedean.bib',SHA256=sha(R/'manuscript/bibliography/NonArchimedean.bib')),historical_formal_blocks_preserved=formal,active_book_PDF_SHA256=sha(R/'manuscript/book.pdf'),native_catalogue_preserved={str(Path(n).relative_to(R)):h for n,h in cp['protected_core_inputs'].items() if Path(n).is_relative_to(R/'output')},source_checkpoint_SHA256=sha(C/'source_checkpoint_v1_20261008.json'),actual_primary_reading_SHA256=sha(C/'actual_primary_full_reading_v1_20261008.json'),exact_diagnostics_SHA256=sha(C/'exact_diagnostics_v1_20261008.json'),new_bibliographic_keys=keys,new_formal_environments=0,original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],active_book_changed=False,GitHub_published=False,actual_book_reading_credit=0,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
template=Path('/tmp/Trusiani_transcendental_validate_staged_book_v3_20261008.py');dst=Path('/tmp/Ortu_Sektnan_adiabatic_validate_staged_book_v1_20261008.py');assert not dst.exists()
t=template.read_text().replace('Trusiani_transcendental_review_20261008','Ortu_Sektnan_adiabatic_review_20261008').replace('transcendental-ytd-staging-v3-20261008','adiabatic-bundles-staging-v1-20261008').replace('v3_20261008','v1_20261008').replace('compiled_staged_v3','compiled_staged_v1')
dst.write_text('# Frozen template SHA256: '+sha(template)+'\n'+t)
print(json.dumps(dict(status='DONE',record_SHA256=sha(out),changed_inputs=list(obj['after']),other_active_TeX=len(unchanged),historical=formal)))
