from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Ortu_Sektnan_adiabatic_review_20261008';E=R/'manuscript/editorial';O=Path('/workspace/book-completion-drafts/research-integration')
out=C/'authored_source_records_export_v1_20261008.json';archive=O/'Ortu_Sektnan_Adiabatic_Authored_Audit_Records_2026-10-08.zip';assert not out.exists() and not archive.exists()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
ledger=C/'actual_primary_full_reading_v1_20261008.json';assert sha(ledger)=='5feb3ef86d4cffd37e0b63e774871f45171a78bc12f5e9a3d9bc8596fd1e4222'
members={}
for p in C.glob('*.json'):members['records/'+p.name]=p
for p in (C/'primary_notes_v1').glob('*.md'):members['authored_primary_notes/'+p.name]=p
for p in E.glob('Ortu_Sektnan_adiabatic_source_*_20261008.*'):members['editorial/'+p.name]=p
for p in Path('/tmp').glob('Ortu_Sektnan_adiabatic_*_20261008.py'):members['helpers/'+p.name]=p
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for n,p in sorted(members.items()):z.write(p,n)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(members)
    for n,p in members.items():assert hashlib.sha256(z.read(n)).hexdigest()==sha(p)
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — authored audit-record export for upload',artifact=dict(path=str(archive),bytes=archive.stat().st_size,SHA256=sha(archive),members=len(members),all_members_byte_verified=True),primary_source=dict(authors=['Annamaria Ortu','Lars Martin Sektnan'],title='Constant scalar curvature Kähler metrics and semistable vector bundles',URL='https://arxiv.org/abs/2406.08284v2',PDF_SHA256='88a20d51645c922416f45a5715bfe8fa8f6f635843daee7fc742d0b7cd9a534c',observed_license_URL='http://arxiv.org/licenses/nonexclusive-distrib/1.0/',license_metadata_HTML_SHA256=sha(R/'source_material/Ortu_Sektnan_adiabatic_sources_20261008/Ortu_Sektnan_adiabatic_current_abs.html')),scope='Authored reading notes, provenance and hash ledgers, exact diagnostic code and audit records. Primary PDF/full text/rendered page cache remains in the cloud source workspace.',primary_original_PDF_text_and_screenshots_included=False,actual_primary_reading_pages=45,actual_primary_reading_views=23,extra_reading_credit_from_export=0,GitHub_uploaded=False,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='DONE',record_SHA256=sha(out),artifact=obj['artifact'])))
