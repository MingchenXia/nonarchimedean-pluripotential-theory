from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,zipfile,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Ortu_Sektnan_adiabatic_review_20261008';S=Path('/workspace/book-completion-drafts/adiabatic-bundles-staging-v2-20261008');E=R/'manuscript/editorial';O=Path('/workspace/book-completion-drafts/research-integration')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(n):return json.loads((C/n).read_text())
prep=load('staging_preparation_v2_20261008.json');release=load('staged_book_release_checks_v2_20261008.json');reading=load('actual_staged_book_reading_v2_20261008.json');post=load('post_render_checks_v2_20261008.json');math=load('staged_mathematical_self_audit_v2_20261008.json');source=load('source_export_v1_20261008.json');underfull=load('staged_underfull_delta_v2_20261008.json')
assert reading['status'].startswith('DONE') and not reading['remaining_repairs'] and underfull['added_blocks']==[]
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
np=release['PDF']['physical_pages'];nb=reading['actual_unique_book_pages'];fresh=reading['fresh_complete_text_and_individually_displayed_pages'];nv=reading['fresh_matching_views'];reused=reading['reused_exact_complete_text_and_rendered_pixel_pages']
assert (np,nb,fresh,nv,reused)==(4632,25,17,9,8)
full=O/'Non-Archimedean_Pluripotential_Theory_Adiabatic_Bundles_Staged_Preview_2026-10-08.pdf';review=O/'Adiabatic_Bundles_Staged_Book_Review_2026-10-08.pdf';minimal=O/'Adiabatic_Bundles_Staged_Minimal_Source_2026-10-08.zip';evidence=O/'Adiabatic_Bundles_Actual_Book_Evidence_2026-10-08.zip';record=C/'staged_export_v2_20261008.json'
paths={k:E/f'Ortu_Sektnan_adiabatic_staged_integration_{k}_20261008.{ext}' for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in [full,review,minimal,evidence,record,*paths.values()])
shutil.copy2(release['PDF']['path'],full);assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as book:
    doc=fitz.open()
    for n in release['selected_book_physical_pages']:doc.insert_pdf(book,from_page=n-1,to_page=n-1)
    assert len(doc)==nb
    doc.set_metadata({'title':'Adiabatic projective bundles — selected book review, 8 October 2026','subject':'Final v2: qualified source claim, corrected coefficients and bundle-existence diagnostic. Export adds no reading credit.'});doc.save(review,garbage=4,deflate=True);doc.close()
paths['audit'].write_text(f'''# Adiabatic projective bundles: final integration audit, 8 October 2026

The validated staged edition has {np:,} pages. Section 62.3.4 and L.91 distinguish fixed-class stability from stability along adiabatic classes, per-subbundle eventual positivity from a common threshold, and positivity from a quantitative margin. The conditional ratio calculation assumes compatible volume-unnormalized invariants and a positive leading norm; it imports no unsupported norm formula or uniform stability theorem. The Ortu--Sektnan analytical cscK equivalence remains a qualified source claim under all of its projective/simple/sufficiently-smooth/base-automorphism hypotheses.

The complete primary arXiv:2406.08284v2 has forty-five actually read pages in twenty-three individually displayed matching views, with twenty-three sequential notes. Its delta2 table discrepancy is corrected by direct Segre expansion and a separate Hilbert/weight Riemann--Roch sum; all four exact coefficient residuals vanish. The chosen action lift is +1 on S and 0 on Q, so section weights are -a and P=-48(A1B0-A0B1). Under equal slopes, the mixed/e² coefficients become 12 and 26. The blowup a2 becomes (36d-416)/15, a correction of 16 which does not change its eventual sign for d=1 or 2. The d=1 stable rank-two P2 bundle does not exist by stability, Serre duality and Riemann--Roch. Neither a replacement bundle nor a cscK base is constructed. A direct conditional Hom/extension-class proof explains simplicity for an actual nonzero extension. External moment-map, elliptic, stability-flow and blowup inputs remain attributed and qualified; no general theorem is refuted by the worked diagnostics.

The first rendered reading covered ten v1 pages in five actual views and detected a notation clash on physical page 4381. Final v2 defines h as the base hyperplane pullback, retaining H for projective O(1). The final scoped gate covers {nb} book pages in thirteen views: {fresh} fresh pages in {nv} individually displayed matching views, plus {reused} previously actually read pages in four views, reused only after exact complete-PDF-text and full-page rendered-RGB identity. These include both new contents rows, all new text and neighboring seams, the complete index, and the complete new bibliography entry. No preparation flags or historical notes are overwritten. This is not a new whole-book pass; 4 October remains the last complete ordered reading.

Required validation, all six reference-checker regression tests, the reference closure and exact canonical inventory pass. Post-render reference/inventory checks pass. Logs have zero errors, LaTeX/package/pdfTeX warnings, missing glyphs, overfull boxes, undefined references/citations or rerun requests. All 955 underfull diagnostics are identical to the preceding edition after source-line-range normalization, with no added or removed case. All {release['all_prior_numbered_label_values_preserved']:,} prior number values and {release['bibliography']['prior_labels_preserved']} prior citation labels are preserved. Three semantic labels, one cited reference [OS24A], two contents rows and two index terms are added. The index accepts {release['index']['accepted']} entries, rejects none and has no warnings. All {release['navigation']['internal_links']:,} internal links pass; external URL health is not claimed. The other 423 TeX inputs, the unchanged NA bibliography, all historical formal/proof/warning/important blocks and manual equation tags are byte-preserved. One supplementary 62.14e tag shifts no existing numbers. The unavailable legacy writing-audit command is replaced by recorded direct semantic, notation, source, whitespace and rendered checks.

The forty-two canonical atoms and twelve formal problems retain their statuses. General BJ22 critical homogeneous Siu division and envelopes remain OPEN; LPWZ density remains UNVERIFIED. No independent gpt-6.1-sol xhigh receipt or original general result is claimed. The native catalogue/editor are preserved. Exports give zero extra reading credit. This frozen staging record does not claim active-cloud or GitHub publication; a separate activation record controls the cloud update. User evidence-upload authorization persists, while the specific automatic-review ownership block still prevents the earlier rejected write; no blocked upload is retried.
''')
paths['reading_notes'].write_text('# Final scoped rendered-book notes, 8 October 2026\n\nSeventeen fresh pages in nine displays; eight exact-identity reused pages in four prior actual displays. Frozen partial v1 and preparation records remain unchanged.\n'+''.join('\n---\n\n'+Path(v['sequential_note_path']).read_text() for v in reading['views']))
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md';prog=(R/programme).read_text();marker='## Latest adiabatic-bundle source checkpoint, 8 October 2026\n';assert prog.count(marker)==1
header=f'''## Latest adiabatic-bundle cloud integration checkpoint, 8 October 2026

The current validated cloud edition has {np:,} pages. The
[integration audit](Ortu_Sektnan_adiabatic_staged_integration_audit_20261008.md)
records Section 62.3.4 and L.91: adiabatic stability quantifiers,
an explicitly conditional ratio estimate and a reproducible surface
coefficient/existence diagnostic. The general source cscK equivalence
remains qualified. Direct Segre and Hilbert/weight Riemann--Roch
calculations agree exactly; the correction leaves the eventual sign
unchanged, while the originally chosen stable c2=1 P2 bundle is impossible.
The projective O(1) class H and base hyperplane pullback h are distinct.

The complete primary v2 reading has 45 actual pages in 23 individually
displayed matching images. The final scoped book gate has {nb} pages:
{fresh} fresh in {nv} displayed views and {reused} reused in four views after exact
complete-text/full-page-RGB identity with prior actual receipts. Partial
v1 notes and all preparation flags remain unchanged. Both contents rows,
all added text and seams, the complete index and new bibliography entry
are reviewed. Required validation and post-render checks pass with no
errors, warnings, missing glyphs, overfull boxes or unresolved links.
All 955 underfull cases are inherited with identical normalized text;
no case is added or removed. All 13,366 prior number values and 589
citation labels are preserved; three labels, one cited reference and
two index terms are added. Other 423 TeX inputs and the NA bibliography,
historical formal/proof/warning/important blocks and tags are unchanged.

The 42 atoms and twelve formal problems keep their statuses. General BJ22
critical homogeneous Siu division and envelopes remain OPEN; LPWZ density
remains UNVERIFIED. No original general result or independent-model receipt
is claimed. This is not a new whole-book reading; the ordered 4 October
pass remains the last complete pass. Evidence and minimal-source exports
are byte-verified and give no reading credit. The
[activation record](Ortu_Sektnan_adiabatic_cloud_activation_20261008.json)
controls the cloud update; the native catalogue/editor remain preserved.
GitHub publication remains blocked by the recorded automatic-review
ownership requirement; no rejected write is retried. Continue read-only
author updates and the next relevant primary-source audit.

'''
(S/programme).write_text(prog.replace(marker,header+marker))
readme=(R/'README.md').read_text();assert readme.count('**4,628 pages**')==1;readme=readme.replace('**4,628 pages**',f'**{np:,} pages**');marker='The current cloud research-integration build has ';assert readme.count(marker)==1
intro=f'''The checked [adiabatic projective-bundle account](manuscript/editorial/Ortu_Sektnan_adiabatic_staged_integration_audit_20261008.md)
adds Section 62.3.4 and L.91. It distinguishes stability quantifiers and records
a corrected surface coefficient plus the Riemann--Roch obstruction to the
source's c2=1 stable bundle. The general analytic equivalence remains qualified.
The complete primary v2 has 45 actual pages in 23 displays; final book review
covers {nb} pages ({fresh} fresh, {reused} exact-identity reused). Existing number and
citation values are preserved. The [cloud activation record](manuscript/editorial/Ortu_Sektnan_adiabatic_cloud_activation_20261008.json)
controls the source/PDF update. No whole-book new reading, original general
result or canonical status change is claimed. GitHub publication remains pending.

'''
(S/'README.md').write_text(readme.replace(marker,intro+marker))
oldzip=O/'Transcendental_YTD_Staged_Minimal_Source_2026-10-08.zip'
with zipfile.ZipFile(oldzip) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as new:
    assert len(old.namelist())==472
    for n in old.namelist():assert (S/n).is_file();new.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
    for n in z.namelist():assert hashlib.sha256(z.read(n)).hexdigest()==sha(S/n)
paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — final staged source/proof/rendered gates',staging_preparation_SHA256=sha(C/'staging_preparation_v2_20261008.json'),validation_SHA256=sha(C/'staged_book_validation_v2_20261008.json'),release_checks=release,actual_reading=reading,post_render_checks=post,mathematical_self_audit=math,underfull_delta=underfull,source_input_hashes=prep['after'],progress_document_hashes={n:sha(S/n) for n in ['README.md',programme]},active_book_changed=False,GitHub_published=False,canonical_status_changes=[],original_results_promoted=[],independent_model_receipt=None),ensure_ascii=False,indent=2)+'\n')
files={}
for q in C.glob('*.json'):
    if q.name.startswith(('staged_','staging_','actual_staged_','post_render_','exact_reused_')):files['records/'+q.name]=q
for q in [C/'staged_book_validation_v1_20261008.log',C/'staged_book_validation_v2_20261008.log',review,Path(release['manifest_path'])]:files['records/'+q.name]=q
for v in reading['views']:
    for key,folder in [('path','v2_images'),('selected_text_path','v2_text'),('sequential_note_path','v2_notes')]:q=Path(v[key]);files[folder+'/'+q.name]=q
for v in load('actual_staged_book_reading_v1_before_notation_repair_20261008.json')['views']:
    for key,folder in [('path','v1_actual_images'),('selected_text_path','v1_actual_text'),('sequential_note_path','v1_actual_notes')]:q=Path(v[key]);files[folder+'/'+q.name]=q
for key in ['audit','reading_notes','manifest']:q=paths[key];files['editorial/'+q.name]=q
for q in sorted(Path('/tmp').glob('Ortu_Sektnan_adiabatic_*_20261008.py')):files['helpers/'+q.name]=q
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
    assert len(z.namelist())==len(files)
    for n,q in files.items():assert hashlib.sha256(z.read(n)).hexdigest()==sha(q)
artifacts=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — byte-verified staged exports',full_book_PDF=dict(path=str(full),bytes=full.stat().st_size,SHA256=sha(full),physical_pages=np),actual_book_review_PDF=dict(path=str(review),bytes=review.stat().st_size,SHA256=sha(review),physical_pages=nb),minimal_TeX_source_archive=dict(path=str(minimal),bytes=minimal.stat().st_size,SHA256=sha(minimal),members=472,all_members_byte_verified=True),actual_book_evidence_archive=dict(path=str(evidence),bytes=evidence.stat().st_size,SHA256=sha(evidence),members=len(files),all_members_byte_verified=True),actual_source_export=source,actual_reading_credit_from_export=0,active_book_changed=False,native_editor_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__)
paths['artifacts'].write_text(json.dumps(artifacts,ensure_ascii=False,indent=2)+'\n');record.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — frozen staged checkpoint and exports',editorial_files={str(q):sha(q) for q in paths.values()},artifacts=artifacts,progress_document_hashes={n:sha(S/n) for n in ['README.md',programme]},active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',record_SHA256=sha(record),artifacts=artifacts)))
