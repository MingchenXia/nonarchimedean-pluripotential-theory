from pathlib import Path
from datetime import datetime, timezone
import hashlib, json
import sympy as S

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Ortu_Sektnan_adiabatic_review_20261008'
PDF=R/'source_material/Ortu_Sektnan_adiabatic_sources_20261008/Ortu_Sektnan_adiabatic_arxiv_v2.pdf'
out=C/'exact_diagnostics_v1_20261008.json'
assert not out.exists()
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(PDF)=='88a20d51645c922416f45a5715bfe8fa8f6f635843daee7fc742d0b7cd9a534c'
a,j,k=S.symbols('a j k',integer=True,nonnegative=True)
v,sl,ql,bl,ss,sq,qq,d,bs,bq,chi=S.symbols('v sl ql bl ss sq qq d bs bq chi')
h,q,t,b,s,e,z=S.symbols('h q t b s e z')
coeff3=S.expand(S.series((1+3*t*h)*(1+t*h)**4/(1+t*(h+q)),t,0,4).removeO()).coeff(t,3)
coeff2=S.expand(S.series((1+t*h)**4/(1+t*(h+q)),t,0,3).removeO()).coeff(t,2)
assert S.expand(coeff3-(10*h**3-7*h**2*q+4*h*q**2-q**3))==0
assert S.expand(coeff2-(3*h**2-2*h*q+q**2))==0
rank=a+1
T2=k*k*j*j*v-2*k*j*(j-a)*ql+(j-a)**2*qq
sT=k*j*sl-(j-a)*sq
bT=k*j*bl-(j-a)*bq
ch2=a*rank*(2*a+1)*ss/12-a*rank*(a+2)*d/6-a*rank*sT/2+rank*T2/2
RR=S.expand(ch2-a*rank*bs/4+rank*bT/2+rank*chi)
# E has rank 3, S rank 2, Q rank 1, and the base is a surface.
# The chosen lift has S weight +1, Q weight 0; section weights are -a.
Hilbert=S.Poly(S.expand(S.summation(RR,(a,0,j))),j)
weight=S.Poly(S.expand(S.summation(-a*RR,(a,0,j))),j)
a0=Hilbert.coeff_monomial(j**4);a1=Hilbert.coeff_monomial(j**3)
b0=weight.coeff_monomial(j**5);b1=weight.coeff_monomial(j**4)
alpha=6*v*k*k-4*(sl+ql)*k+ss+sq+qq-d
beta=9*v*k*k+3*(bl-2*sl-2*ql)*k-bs-bq+2*ss+sq+2*qq-3*d
gamma=20*v*k*k-5*(3*sl+2*ql)*k+4*ss-4*d+3*sq+2*qq
delta=24*v*k*k+(8*bl-20*sl-8*ql)*k+7*ss-10*d+2*sq+2*qq-3*bs-2*bq
residuals={'24a0-alpha':S.expand(24*a0-alpha),'12a1-beta':S.expand(12*a1-beta),'120b0+gamma':S.expand(120*b0+gamma),'48b1+delta':S.expand(48*b1+delta)}
assert all(x==0 for x in residuals.values())
P=S.expand((S.Rational(4,5)*beta*gamma-alpha*delta)/24)
DFnumerator=S.expand(a1*b0-a0*b1)
assert S.expand(P+48*DFnumerator)==0
printed_delta=delta-sq-qq
Pprinted=S.expand((S.Rational(4,5)*beta*gamma-alpha*printed_delta)/24)
assert S.expand(P-Pprinted+alpha*(sq+qq)/24)==0
N=S.expand(S.Rational(4,5)*(9*(4*(s*s-d)+3*s*q+2*q*q)+20*(-b*(s+q)+2*(s+q)**2-3*z))-6*(10*(s*s-d)+7*s*q+4*q*q-(3*s+2*q)*(b+s+q))-24*((s+q)**2-z))
assert S.expand(N.subs(q,e-s)-(-4*b*e+6*b*s+S.Rational(2,5)*(-51*s*s+78*d+12*s*e+26*e*e-60*z)))==0
cross=S.expand((S.Rational(4,5)*beta.coeff(k,1)*gamma.coeff(k,1)-alpha.coeff(k,1)*delta.coeff(k,1)).subs(ql,sl/2))
assert cross==0
example={v:8,sl:0,ql:0,bl:8,ss:0,sq:0,qq:-8,bs:0,bq:0}
pex=S.factor(P.subs(example));a2=S.expand(pex).coeff(k,2)
assert S.expand(a2-(36*d-416)/15)==0
assert S.expand(S.expand(Pprinted.subs(example)).coeff(k,2)-(36*d-656)/15)==0
assert S.expand(P.subs(example)-Pprinted.subs(example)-alpha.subs(example)/3)==0
scale=S.symbols('scale',positive=True)
aa0,aa1,bb0,bb1=S.symbols('aa0 aa1 bb0 bb1')
normalized=(aa1*bb0-aa0*bb1)/aa0**2
scaled=normalized.subs({aa0:scale**4*aa0,aa1:scale**3*aa1,bb0:scale**5*bb0,bb1:scale**4*bb1},simultaneous=True)
assert S.simplify(scaled-normalized)==0
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — exact worked diagnostics, not an independent model proof certificate',source_PDF=dict(path=str(PDF),SHA256=sha(PDF)),source_locations={'coefficient_table':38,'equal_slope_simplification':39,'bundle_choice':39,'extension_and_example':40,'uniform_scaling_claim':43},symbols={'v':'L^2','sl':'c1(S).L','ql':'c1(Q).L','bl':'c1(B).L','ss':'c1(S)^2','sq':'c1(S).c1(Q)','qq':'c1(Q)^2','d':'c2(S)','bs':'c1(B).c1(S)','bq':'c1(B).c1(Q)'},assumptions=['smooth surface base','rank(E)=3, rank(S)=2, rank(Q)=1','lines projectivisation with H=O(1)','central fibre P(S direct sum Q)','section weights -a for lift of weight +1 on S and 0 on Q','Riemann--Roch characteristic polynomial; higher-cohomology vanishing when interpreted as Hilbert coefficients','ampleness for sufficiently large k','no construction of a stable c2=1 bundle'],expansion_coefficients={'degree3':str(coeff3),'degree2':str(coeff2)},RR_leading_coefficients={x:str(y) for x,y in [('a0',a0),('a1',a1),('b0',b0),('b1',b1)]},localization_polynomials={x:str(y) for x,y in [('alpha',alpha),('beta',beta),('gamma',gamma),('delta_corrected',delta),('delta_printed',printed_delta)]},exact_residuals={x:str(y) for x,y in residuals.items()},RR_localization_identity='P=-48*(a1*b0-a0*b1)',equal_slope_cross_residual=str(cross),equal_slope_N_in_s_e=str(S.expand(N.subs(q,e-s))),example={'intersection_values':{str(x):str(y) for x,y in example.items()},'corrected_P':str(pex),'corrected_a2':str(a2),'printed_a2':str(S.expand(Pprinted.subs(example)).coeff(k,2)),'correction_to_a2':'16','d1_P':str(S.factor(pex.subs(d,1))),'d2_P':str(S.factor(pex.subs(d,2))),'eventual_sign_d1_and_d2':'negative P, hence positive DF for the explicitly chosen lift','d1_bundle_existence':'impossible: stability gives h0=h2=0 on P2, while RR gives chi=2-d=1','d2_bundle_existence':'not certified by this computation'},polarization_tensor_power_scaling={'fixed_generator':True,'displayed_a0_squared_DF':'invariant','exact_residual':str(S.simplify(scaled-normalized))},proof_dependencies=['standard symmetric-power Chern character via splitting principle','Hirzebruch--Riemann--Roch','Serre duality and stability Hom vanishing for the P2 obstruction'],independent_model_receipt=None,main_theorem_certified=False,canonical_status_changes=[],helper_source=dict(path=__file__,SHA256=sha(__file__)),reading_note_hashes={str(C/'primary_notes_v1'/f'{i:02d}.md'):sha(C/'primary_notes_v1'/f'{i:02d}.md') for i in range(19,24)})
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',record_SHA256=sha(out),RR_localization_residual=0,corrected_example_a2=str(a2))))
