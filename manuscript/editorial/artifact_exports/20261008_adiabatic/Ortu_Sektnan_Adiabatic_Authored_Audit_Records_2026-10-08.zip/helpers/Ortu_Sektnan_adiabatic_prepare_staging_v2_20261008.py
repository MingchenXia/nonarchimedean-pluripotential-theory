from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Ortu_Sektnan_adiabatic_review_20261008'
old=Path('/workspace/book-completion-drafts/adiabatic-bundles-staging-v1-20261008');new=Path('/workspace/book-completion-drafts/adiabatic-bundles-staging-v2-20261008')
od=Path('/workspace/book-completion-drafts/adiabatic-bundles-integration-v1-20261008');nd=Path('/workspace/book-completion-drafts/adiabatic-bundles-integration-v2-20261008')
partial=C/'actual_staged_book_reading_v1_before_notation_repair_20261008.json';out=C/'staging_preparation_v2_20261008.json'
assert not any(z.exists() for z in [new,nd,partial,out])
def sha(z):return hashlib.sha256(Path(z).read_bytes()).hexdigest()
release=C/'staged_book_release_checks_v1_20261008.json';r=json.loads(release.read_text());manifest=Path(r['manifest_path']);assert sha(manifest)==r['manifest_SHA256'];xs=json.loads(manifest.read_text());views=[]
for v in xs[:5]:
    assert not v['actually_viewed'] and not v['selected_text_read']
    note=C/'staged_book_notes_v1'/f'{v["number"]:02d}.md';assert note.exists()
    assert sha(v['path'])==v['image_SHA256'] and sha(v['selected_text_path'])==v['selected_text_SHA256']
    y={k:x for k,x in v.items() if k not in ['actually_viewed','selected_text_read']};y.update(actual_complete_text_read=True,actual_matching_image_individually_displayed=True,sequential_note_path=str(note),sequential_note_SHA256=sha(note));views.append(y)
assert not any((C/'staged_book_notes_v1'/f'{i:02d}.md').exists() for i in range(6,14))
partial.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — partial actual v1 reading before required notation repair; not a full clearance',PDF=r['PDF'],actual_unique_book_pages=10,actual_matching_views=5,views=views,remaining_repairs=['Distinguish the projective O(1) class H from the base hyperplane pullback h in the blowup example on physical page 4381'],preparation_flags_rewritten=False,whole_book_new_reading_claim=False,active_book_changed=False,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
pin=C/'staging_preparation_v1_20261008.json';p=json.loads(pin.read_text());vp=C/'staged_book_validation_v1_20261008.json';v=json.loads(vp.read_text());assert v['status']=='DONE'
for n,h in p['after'].items():assert sha(old/n)==h
shutil.copytree(old,new,ignore=shutil.ignore_patterns('*.pdf','*.aux','*.log','*.fls','*.fdb_latexmk','*.bbl','*.blg','*.toc','*.out','*.idx','*.ind','*.ilg','__pycache__'))
shutil.copytree(od,nd)
before='''For the one-point blowup of $\\mathbf P^2$, with exceptional
divisor $D$, take $L=b=3H-D$, $s=0$, $q=H-3D$ and $z=d$.'''
after='''For the one-point blowup of $\\mathbf P^2$, let $h$ denote
the pulled-back hyperplane class and $D$ the exceptional divisor.
Take $L=b=3h-D$, $s=0$, $q=h-3D$ and $z=d$.'''
for z in [new/'manuscript/appendices/appL_provenance.tex',nd/'appL_adiabatic_fragment.tex']:
    t=z.read_text();assert t.count(before)==1;z.write_text(t.replace(before,after))
for n,h in p['active_inputs_preserved'].items():assert sha(R/n)==h
for n,h in p['other_active_TeX_preserved'].items():assert sha(R/n)==sha(new/n)==h
assert sha(R/'manuscript/book.pdf')==p['active_book_PDF_SHA256']
p.update(UTC=datetime.now(timezone.utc).isoformat(),stage_path=str(new),draft_path=str(nd),after={n:sha(new/n) for n in p['after']},draft_fragments={str(z):sha(z) for z in sorted(nd.iterdir())},previous_preparation_SHA256=sha(pin),previous_validation_SHA256=sha(vp),partial_previous_actual_reading_SHA256=sha(partial),repairs=['Use h for the base hyperplane pullback; retain H for the projective O(1) class'],mathematical_result_changed=False,previous_versions_preserved=True,helper_source=__file__)
out.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
for stem in ['validate_staged_book','prepare_staged_book_views','finalize_staged_reading']:
    src=Path('/tmp')/f'Ortu_Sektnan_adiabatic_{stem}_v1_20261008.py';dst=Path('/tmp')/f'Ortu_Sektnan_adiabatic_{stem}_v2_20261008.py';assert not dst.exists()
    t=src.read_text()
    for a,b in [('v1_20261008','v2_20261008'),('staging-v1-20261008','staging-v2-20261008'),('integration-v1-20261008','integration-v2-20261008'),('compiled_staged_v1','compiled_staged_v2'),('staged_book_notes_v1','staged_book_notes_v2'),('STAGED BOOK V1','STAGED BOOK V2'),('staged v1:','staged v2:')]:t=t.replace(a,b)
    dst.write_text('# Frozen v1 template SHA256: '+sha(src)+'\n'+t)
print(json.dumps(dict(status='DONE',preparation_SHA256=sha(out),partial_actual_reading_SHA256=sha(partial),after=p['after'])))
