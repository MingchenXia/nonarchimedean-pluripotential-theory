from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import re,hashlib,json
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Ortu_Sektnan_adiabatic_review_20261008')
old=Path('/workspace/book-completion-drafts/transcendental-ytd-staging-v3-20261008/manuscript/book.log');new=C/'compiled_staged_v1/book.log';out=C/'staged_underfull_delta_v1_20261008.json'
assert not out.exists()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def blocks(t):
    rows=t.splitlines();ans=[]
    for i,x in enumerate(rows):
        if not re.match(r'Underfull \\[hv]box',x):continue
        a=[re.sub(r'at lines \d+(?:--\d+)?','at lines <range>',x)]
        for y in rows[i+1:]:
            if not y.strip():break
            a.append(y)
        ans.append('\n'.join(a))
    return Counter(ans)
a=blocks(old.read_text(errors='replace'));b=blocks(new.read_text(errors='replace'))
assert sum(a.values())==sum(b.values())==955 and a==b
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — all 955 underfull diagnostics inherited; none added or removed',baseline_log=dict(path=str(old),SHA256=sha(old)),staged_log=dict(path=str(new),SHA256=sha(new)),normalization='Only TeX paragraph source line ranges are replaced; all diagnostic text and font/content lines remain compared with multiplicity',prior_blocks=955,current_blocks=955,added_blocks=[],removed_blocks=[],all_normalized_blocks_and_multiplicities_identical=True,visual_reading_credit=0,helper_source=dict(path=__file__,SHA256=sha(__file__)))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='DONE',record_SHA256=sha(out),new_underfull_blocks=0)))
