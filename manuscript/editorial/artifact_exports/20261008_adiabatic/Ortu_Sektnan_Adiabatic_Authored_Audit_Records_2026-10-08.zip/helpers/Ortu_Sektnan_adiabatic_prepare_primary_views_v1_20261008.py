from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, fitz, xml.etree.ElementTree as ET
from PIL import Image, ImageDraw

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R / 'source_material/Ortu_Sektnan_adiabatic_review_20261008'
S = R / 'source_material/Ortu_Sektnan_adiabatic_sources_20261008'
W = Path('/tmp/Ortu_Sektnan_adiabatic_primary_views_v1_20261008')
out = C / 'primary_view_preparation_v1_20261008.json'
notes = C / 'primary_notes_v1'
assert not any(q.exists() for q in (W, out, notes))
def sha(q):
    return hashlib.sha256(Path(q).read_bytes()).hexdigest()
pdf = S / 'Ortu_Sektnan_adiabatic_arxiv_v2.pdf'
assert sha(pdf) == '88a20d51645c922416f45a5715bfe8fa8f6f635843daee7fc742d0b7cd9a534c'
doc = fitz.open(pdf)
assert len(doc) == 45
ns = {'a': 'http://www.w3.org/2005/Atom'}
entry = ET.parse(S / 'Ortu_Sektnan_adiabatic_API.xml').getroot().find('a:entry', ns)
assert entry.findtext('a:id', namespaces=ns).endswith('2406.08284v2')
assert entry.findtext('a:updated', namespaces=ns) == '2026-10-03T12:12:40Z'
W.mkdir()
notes.mkdir()
views = []
for i in range(0, len(doc), 2):
    pp = list(range(i+1, min(i+3, len(doc)+1)))
    panels = []
    texts = []
    for n in pp:
        pix = doc[n-1].get_pixmap(matrix=fitz.Matrix(1.45, 1.45), alpha=False)
        panels.append(Image.frombytes('RGB', [pix.width, pix.height], pix.samples))
        texts.append(f'ORTU--SEKTNAN ADIABATIC V2 PHYSICAL PAGE {n}\n' + doc[n-1].get_text())
    canvas = Image.new('RGB', (sum(p.width for p in panels), max(p.height for p in panels)+28), 'white')
    draw = ImageDraw.Draw(canvas)
    x = 0
    for n, panel in zip(pp, panels):
        draw.text((x+8, 8), f'Ortu--Sektnan 2406.08284v2 physical page {n}', fill='black')
        canvas.paste(panel, (x, 28))
        x += panel.width
    number = i//2 + 1
    ip = W / f'sheet_{number:02d}.png'
    tp = W / f'sheet_{number:02d}.txt'
    canvas.save(ip)
    tp.write_text('\n\n'.join(texts))
    views.append(dict(number=number, physical_pages=pp, path=str(ip), image_SHA256=sha(ip), selected_text_path=str(tp), selected_text_SHA256=sha(tp), source_PDF_SHA256=sha(pdf), actually_viewed=False, selected_text_read=False))
mp = W / 'manifest.json'
mp.write_text(json.dumps(views, ensure_ascii=False, indent=2) + '\n')
obj = dict(UTC=datetime.now(timezone.utc).isoformat(), status='DONE — full-source view preparation; zero reading credit', source_PDF=dict(path=str(pdf), SHA256=sha(pdf), physical_pages=45), source_metadata=dict(title=entry.findtext('a:title', namespaces=ns), authors=[x.findtext('a:name', namespaces=ns) for x in entry.findall('a:author', ns)], published=entry.findtext('a:published', namespaces=ns), updated=entry.findtext('a:updated', namespaces=ns)), prepared_pages=45, prepared_views=23, manifest_path=str(mp), manifest_SHA256=sha(mp), actually_read_pages=0, actual_source_reading_credit=0, text_extraction_warning='pdftotext reports a font-type/embedded-font mismatch; mathematical glyphs require the individually displayed matching PDF images.', active_book_PDF_SHA256=sha(R / 'manuscript/book.pdf'), native_catalogue_preserved={str(q.relative_to(R)): sha(q) for q in [R / 'output/open_problems_catalogue_2026-10-03.tex', R / 'output/open_problems_catalogue_2026-10-03.pdf']}, active_book_changed=False, GitHub_published=False, canonical_status_changes=[], helper_source=__file__)
out.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(status='DONE', record_SHA256=sha(out), pages=45, views=23, metadata=obj['source_metadata'])))
