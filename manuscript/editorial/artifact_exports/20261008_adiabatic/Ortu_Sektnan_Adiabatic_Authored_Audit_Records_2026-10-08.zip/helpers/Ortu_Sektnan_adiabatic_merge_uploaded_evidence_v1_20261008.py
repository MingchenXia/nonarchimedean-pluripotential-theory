from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json,zipfile
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Ortu_Sektnan_adiabatic_review_20261008';out=C/'merge_uploaded_evidence_v1_20261008.json'
assert not out.exists()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
before=git('rev-parse','HEAD');remote=git('rev-parse','FETCH_HEAD');assert before=='703a8c10a5ff937728cec80edce7d23158777606' and remote=='7fd3d92cea0eb02b8a8da75f8d9eca9f67a53690'
assert git('diff','--name-only')==git('diff','--cached','--name-only')==''
path='manuscript/editorial/Ortu_Sektnan_adiabatic_source_review_20261008.md';assert git('diff-tree','--no-commit-id','--name-only','-r',remote)==path
assert subprocess.check_output(['git','show',remote+':'+path],cwd=R)==(R/path).read_bytes()
old_tree=git('rev-parse','HEAD^{tree}')
ex=json.loads((C/'staged_export_v2_20261008.json').read_text());archive=Path(ex['artifacts']['minimal_TeX_source_archive']['path']);a=json.loads((R/'manuscript/editorial/Ortu_Sektnan_adiabatic_cloud_activation_20261008.json').read_text())
with zipfile.ZipFile(archive) as z:
    for n in z.namelist():assert (R/n).read_bytes()==z.read(n),n
run=subprocess.run(['git','merge','--no-edit',remote],cwd=R,check=True,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
after=git('rev-parse','HEAD');assert git('rev-parse','HEAD^{tree}')==old_tree
with zipfile.ZipFile(archive) as z:
    for n in z.namelist():assert (R/n).read_bytes()==z.read(n),n
assert sha(R/'manuscript/book.pdf')==a['active_PDF']['SHA256']
for n,h in a['native_catalogue_preserved'].items():assert sha(R/n)==h
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — merge the independently uploaded identical source audit; validated source tree unchanged',before_local_commit=before,uploaded_evidence_commit=remote,merge_commit=after,source_tree_SHA=old_tree,source_tree_byte_identical=True,merge_output=run.stdout,minimal_source_members_byte_verified=472,active_book_PDF_SHA256=a['active_PDF']['SHA256'],native_catalogue_preserved=True,full_branch_pushed=False,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='DONE',merge_commit=after,record_SHA256=sha(out),source_tree_unchanged=True)))
