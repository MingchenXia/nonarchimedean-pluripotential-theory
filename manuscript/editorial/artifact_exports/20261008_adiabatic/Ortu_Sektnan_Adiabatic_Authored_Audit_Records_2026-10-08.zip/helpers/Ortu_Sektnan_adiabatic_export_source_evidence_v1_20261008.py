from pathlib import Path
from datetime import datetime, timezone
import hashlib,json,zipfile,shutil
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Ortu_Sektnan_adiabatic_review_20261008';E=R/'manuscript/editorial'
O=Path('/workspace/book-completion-drafts/research-integration');O.mkdir(exist_ok=True)
archive=O/'Ortu_Sektnan_Adiabatic_Actual_Source_Evidence_2026-10-08.zip';review=O/'Ortu_Sektnan_Adiabatic_Actual_Source_Review_2026-10-08.pdf';out=C/'source_export_v1_20261008.json'
assert not any(p.exists() for p in [archive,review,out])
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
cp=C/'source_checkpoint_v1_20261008.json';assert sha(cp)=='dd232d12d44b615e5b5b384d4c664cda35e6c0bbcfdf65cf117f9118c035eabd'
p=json.loads(cp.read_text())
for n,h in p['protected_core_inputs'].items():assert sha(n)==h
actual=C/'actual_primary_full_reading_v1_20261008.json';a=json.loads(actual.read_text());members={}
for name in ['Ortu_Sektnan_adiabatic_sources_20261008','Ortu_Sektnan_adiabatic_review_20261008']:
    for q in (R/'source_material'/name).rglob('*'):
        if q.is_file():members[str(q.relative_to(R))]=q
for v in a['views']:
    for key in ['path','selected_text_path']:
        q=Path(v[key]);members['actual_views/'+q.name]=q
for n in p['editorial_files']:q=Path(n);members['editorial/'+q.name]=q
for stem in ['acquire','prepare_primary_views','exact_diagnostics','source_checkpoint','export_source_evidence']:
    q=Path('/tmp')/f'Ortu_Sektnan_adiabatic_{stem}_v1_20261008.py';members['helpers/'+q.name]=q
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,q in sorted(members.items()):z.write(q,name)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(members)
    for name,q in members.items():assert hashlib.sha256(z.read(name)).hexdigest()==sha(q)
shutil.copy2(a['source_PDF']['path'],review);assert sha(review)==a['source_PDF']['SHA256']
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — byte-verified export; no upload',actual_source_pages=45,actual_images=23,export_reading_credit=0,artifacts={str(q):dict(bytes=q.stat().st_size,SHA256=sha(q)) for q in [archive,review]},archive_members=len(members),all_archive_members_byte_verified=True,source_checkpoint_SHA256=sha(cp),actual_ledger_SHA256=sha(actual),user_authorized_evidence_upload=True,GitHub_published=False,blocked_upload_not_retried=True,protected_inputs_preserved=True,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
for n,h in p['protected_core_inputs'].items():assert sha(n)==h
print(json.dumps(dict(status='DONE',record_SHA256=sha(out),archive_members=len(members),artifacts=obj['artifacts'])))
