from pathlib import Path
from datetime import datetime,timezone
import subprocess,hashlib,json
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Ortu_Sektnan_adiabatic_review_20261008';out=C/'local_integration_commit_v1_20261008.json';activation=R/'manuscript/editorial/Ortu_Sektnan_adiabatic_cloud_activation_20261008.json'
assert not out.exists()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(activation)=='d0259ad990e77227a83f79e2b77094feae06d35c1a3249b1c8a461b7956d6822'
a=json.loads(activation.read_text());export=json.loads((C/'staged_export_v2_20261008.json').read_text());files=list(a['after_source_hashes'])+[str(Path(n).relative_to(R)) for n in export['editorial_files']]+[str(activation.relative_to(R))];assert len(files)==10
for n,h in a['after_source_hashes'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==a['active_PDF']['SHA256']
for n,h in a['native_catalogue_preserved'].items():assert sha(R/n)==h
assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True)==''
before=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert before=='2000a11d872b92210a8b15428477761d7cfd3da2'
subprocess.run(['git','add','--']+files,cwd=R,check=True);assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).splitlines())==set(files)
subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
run=subprocess.run(['git','commit','-m','Explain adiabatic stability quantifiers and correct surface diagnostics'],cwd=R,check=True,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
after=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — validated integration committed locally',parent=before,commit=after,files={n:sha(R/n) for n in files},commit_output=run.stdout,activation_SHA256=sha(activation),active_PDF=a['active_PDF'],native_catalogue_preserved=True,GitHub_published=False,helper_source=__file__),ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='DONE',commit=after,files=10,record_SHA256=sha(out))))
