from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,zipfile
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Ortu_Sektnan_adiabatic_review_20261008';S=Path('/workspace/book-completion-drafts/adiabatic-bundles-staging-v2-20261008');J=R/'manuscript/editorial/Ortu_Sektnan_adiabatic_cloud_activation_20261008.json'
assert not J.exists()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(n):return json.loads((C/n).read_text())
pins={'staging_preparation_v2_20261008.json':'b8c0d79fc22aaf259e4bd55acc31fd64736b535e1ffbbe3a2b48527b45d90cbf','staged_export_v2_20261008.json':'238755591d6280da429061395ac2d7ee25f78e6bf3a742a3a24a119195ee37b3','actual_staged_book_reading_v2_20261008.json':'1d1f415dce9a4582cf0d8421bc8f0f0a4ab3812b950090387cb31cbafca1794d','staged_book_release_checks_v2_20261008.json':'0aba27048d061748b768d7822379fdfa5a5b8765ddbd4acd9841d92907488773','post_render_checks_v2_20261008.json':'6610aad4aabe5c3841ae02f215bff601fcb5cbfcfbd21fb3f0e23e01dea3211e','staged_mathematical_self_audit_v2_20261008.json':'eaaa0fa3def14318d99430b9ee780c4b36ea352f4cc4c38f8fff81e29148706b','staged_book_validation_v2_20261008.json':'14036fe232ec4d8f9898c6398f87eded583122a1bcee3a05e8abbae8b2f43461','staged_underfull_delta_v2_20261008.json':'6c0bf1a6a1ab51a64d4d78b0831681994cc6808d43bacbbfdde19fc634fdf9a2','exact_reused_book_views_v2_20261008.json':'06f9af3c0f8dbef17b091f8a5602a3b7c377bf36489c9a9a5ba75820d9f2c738'}
for n,h in pins.items():assert sha(C/n)==h,n
prep=load('staging_preparation_v2_20261008.json');export=load('staged_export_v2_20261008.json');reading=load('actual_staged_book_reading_v2_20261008.json');release=load('staged_book_release_checks_v2_20261008.json');post=load('post_render_checks_v2_20261008.json')
assert reading['status'].startswith('DONE') and not reading['remaining_repairs']
assert (reading['actual_unique_book_pages'],reading['fresh_complete_text_and_individually_displayed_pages'],reading['fresh_matching_views'],reading['reused_exact_complete_text_and_rendered_pixel_pages'])==(25,17,9,8)
assert release['PDF']['SHA256']==reading['PDF']['SHA256'] and all(c['returncode']==0 for c in post['checks'])
for n,h in prep['before'].items():assert sha(R/n)==h,n
for n,h in prep['other_active_TeX_preserved'].items():assert sha(R/n)==sha(S/n)==h,n
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h,n
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
for n,h in export['editorial_files'].items():assert sha(n)==h,n
changes=dict(prep['after'],**export['progress_document_hashes']);assert len(changes)==5
for n,h in changes.items():assert sha(S/n)==h,n
pdf=Path(reading['PDF']['path']);assert sha(pdf)==reading['PDF']['SHA256']
archive=Path(export['artifacts']['minimal_TeX_source_archive']['path']);assert sha(archive)==export['artifacts']['minimal_TeX_source_archive']['SHA256']
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==472
    for n in z.namelist():
        assert (S/n).read_bytes()==z.read(n)
        if n not in changes:assert (R/n).read_bytes()==z.read(n),n
before={n:sha(R/n) for n in changes}
for n in changes:
    target=R/n;tmp=target.with_name(target.name+'.adiabatic-activation-tmp');assert not tmp.exists();shutil.copyfile(S/n,tmp);assert sha(tmp)==changes[n];os.replace(tmp,target)
target=R/'manuscript/book.pdf';tmp=target.with_name(target.name+'.adiabatic-activation-tmp');assert not tmp.exists();shutil.copyfile(pdf,tmp);assert sha(tmp)==reading['PDF']['SHA256'];os.replace(tmp,target)
with zipfile.ZipFile(archive) as z:
    for n in z.namelist():assert (R/n).read_bytes()==z.read(n),n
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h,n
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — exact validated source and PDF activated in cloud workspace',before_source_hashes=before,after_source_hashes={n:sha(R/n) for n in changes},before_book_PDF_SHA256=prep['active_book_PDF_SHA256'],active_PDF=dict(path=str(target),bytes=target.stat().st_size,SHA256=sha(target),physical_pages=4632),validation_record_hashes=pins,minimal_source_archive_members_byte_verified_against_active_tree=472,actual_selected_book_pages=25,fresh_complete_text_and_individually_displayed_book_pages=17,fresh_book_matching_views=9,exact_reused_actual_book_pages=8,exact_reused_book_views=4,actual_source_pages=45,actual_source_matching_images=23,source_scope='Ortu--Sektnan 2406.08284v2 complete primary reading; cited external analytic and blowup inputs remain qualified',validation=release['build_checks'],underfull_diagnostics='All 955 inherited; normalized full text and multiplicities identical, zero added or removed',preserved_numbered_labels=13366,preserved_citation_labels=589,new_labels=release['new_semantic_labels'],new_bibliography_labels=release['bibliography']['new_labels'],open_problem_inventory='42 atoms, 12 formal problems, no status changes',critical_homogeneous_Siu_and_general_envelopes='OPEN',LPWZ_density='UNVERIFIED',native_catalogue_preserved=prep['native_catalogue_preserved'],native_editor_changed=False,whole_book_new_reading_claim=False,original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],active_book_changed=True,local_Git_commit_created_at_activation=False,GitHub_published=False,helper_source=__file__)
J.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status=obj['status'],record_SHA256=sha(J),active_PDF_SHA256=sha(target),physical_pages=4632)))
