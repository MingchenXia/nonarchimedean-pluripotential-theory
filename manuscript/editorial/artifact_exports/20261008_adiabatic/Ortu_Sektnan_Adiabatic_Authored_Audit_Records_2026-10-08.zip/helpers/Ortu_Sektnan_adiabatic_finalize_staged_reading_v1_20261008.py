# Frozen template SHA256: 407959e7c269041bdaeba67737c6f1443c46b359efe416196d628c36effef4dd
# Frozen failed-v3 helper SHA256: b6dd929391b1d90a1e44697adcf83297d830215da28211cd0feed324e4ddfa43
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, subprocess, difflib
from collections import Counter

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R / 'source_material/Ortu_Sektnan_adiabatic_review_20261008'
S = Path('/workspace/book-completion-drafts/adiabatic-bundles-staging-v1-20261008')
D = Path('/workspace/book-completion-drafts/adiabatic-bundles-integration-v1-20261008')
def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
release = C / 'staged_book_release_checks_v1_20261008.json'
ch = json.loads(release.read_text())
manifest = Path(ch['manifest_path'])
assert sha(manifest) == ch['manifest_SHA256']
xs = json.loads(manifest.read_text())
views = []
for x in xs:
    assert not x['actually_viewed'] and not x['selected_text_read']
    n = C / 'staged_book_notes_v1' / f"{x['number']:02d}.md"
    t = n.read_text()
    assert 'Read the complete selected text and displayed matching rendered image' in t
    assert sha(x['path']) == x['image_SHA256']
    assert sha(x['selected_text_path']) == x['selected_text_SHA256']
    y = {k: v for k, v in x.items() if k not in ['actually_viewed', 'selected_text_read']}
    y.update(inspection_mode='Fresh complete-text read and individual matching-image display', actual_complete_text_read=True, actual_matching_image_freshly_displayed=True, sequential_note_path=str(n), sequential_note_SHA256=sha(n))
    views.append(y)
pages = sorted({p for x in xs for p in x['physical_pages']})
assert pages == ch['selected_book_physical_pages']
assert sum(len(x['physical_pages']) for x in xs) == len(pages)
reading = C / 'actual_staged_book_reading_v1_20261008.json'
audit = C / 'staged_mathematical_self_audit_v1_20261008.json'
post = C / 'post_render_checks_v1_20261008.json'
assert not any(q.exists() for q in (reading, audit, post))
prep = json.loads((C / 'staging_preparation_v1_20261008.json').read_text())
checks = []
for command in (['python3', 'editorial/tools/refcheck.py'], ['python3', 'editorial/tools/check_open_problem_inventory.py']):
    run = subprocess.run(command, cwd=S / 'manuscript', text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    assert run.returncode == 0, run.stdout
    checks.append(dict(command=command, returncode=run.returncode, output=run.stdout))
for n, h in prep['after'].items():
    assert sha(S / n) == h, n
for n, h in prep['other_active_TeX_preserved'].items():
    assert sha(R / n) == sha(S / n) == h, n
for n, h in prep['active_inputs_preserved'].items():
    assert sha(R / n) == h, n
assert sha(R / 'manuscript/book.pdf') == prep['active_book_PDF_SHA256']
for n, h in prep['native_catalogue_preserved'].items():
    assert sha(R / n) == h, n
historical = {}
for n in ('manuscript/parts/part5/ch62_k_stability_kahler.tex', 'manuscript/appendices/appL_provenance.tex'):
    before = (R / n).read_text()
    after = (S / n).read_text()
    counts = {}
    for env in ('theorem', 'proposition', 'lemma', 'corollary', 'definition', 'example', 'remark', 'warning', 'proof', 'important'):
        patt = r'\\begin\{' + env + r'\}.*?\\end\{' + env + r'\}'
        blocks = re.findall(patt, before, re.S)
        assert all(b in after for b in blocks), (n, env)
        assert len(blocks) == len(re.findall(patt, after, re.S)), (n, env)
        counts[env] = len(blocks)
    tags = re.findall(r'\\tag\{([^}]+)\}', before)
    aftertags = re.findall(r'\\tag\{([^}]+)\}', after)
    assert all(aftertags.count(t) >= tags.count(t) for t in tags)
    historical[n] = dict(byte_preserved_environment_blocks=counts, prior_manual_equation_tags=tags)
whitespace = {}
for n in prep['after']:
    before = (R / n).read_text().splitlines()
    after = (S / n).read_text().splitlines()
    wb = Counter(x for x in before if x != x.rstrip())
    wa = Counter(x for x in after if x != x.rstrip())
    assert wb == wa, n
    added = [x[2:] for x in difflib.ndiff(before, after) if x.startswith('+ ')]
    assert all(x == x.rstrip() for x in added), n
    whitespace[n] = dict(historical_whitespace_lines_preserved=sum(wb.values()),added_lines_checked=len(added),added_trailing_whitespace_lines=0)
for q in D.iterdir():
    assert all(line == line.rstrip() for line in q.read_text().splitlines()), str(q)
reading.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(), status='DONE — final selected rendered gate; no remaining repairs', PDF=ch['PDF'], actual_unique_book_pages=len(pages), fresh_complete_text_and_individually_displayed_pages=len(pages), fresh_matching_views=len(views), reused_exact_complete_text_and_rendered_pixel_pages=0, reused_matching_views=0, views=views, legacy_preparation_flags_rewritten=False, remaining_repairs=[], whole_book_new_reading_claim=False, active_book_changed=False, GitHub_published=False, canonical_status_changes=[]), ensure_ascii=False, indent=2) + '\n')
mathchecks = [
    "The source claim retains smooth projective cscK base, discrete polarized automorphisms, a simple strictly slope-semistable bundle and locally free stable equal-slope Jordan--Holder quotients. It is qualified rather than promoted as an established theorem.",
    "Adiabatic alpha_k changes the generic polarization, unlike the preceding special approximation with one fixed alpha. A stability constant for one class is not a common family constant.",
    "Proper nonzero smooth subbundle tests, saturated sheaf tests, and all test configurations are different quantifier domains. The O(-D) subsheaf of one O summand is reflexive and nonsaturated.",
    "The eventual positivity quantifier for every S with a threshold K_S is separated from a common threshold and from a quantitative lower bound. No uniform-threshold theorem is inferred.",
    "The conditional ratio estimate assumes compatible unnormalized D_k=O(k^(n-2)) and N_k=c k^n+O(k^(n-1)) with c>0. Division gives O(k^-2), ruling out delta/k for one positive delta. Norm positivity and asymptotics are explicit inputs.",
    "Dividing both D and N by the same generic volume leaves their ratio unchanged. No unsupported norm-scaling or uniform stability statement is copied from Remark 6.10.",
    "The numerical example uses a surface base, rank(E)=3, rank(S)=2, rank(Q)=1, and lines projectivisation H=O(1). Products of base classes are intersection numbers and c2(E)=c2(S)+c1(S)c1(Q).",
    "Segre pushforwards pi_*H=1, pi_*H^2=-s, pi_*H^3=s^2-d, applied to the displayed degree-three expansion, give delta2 with 7sq+4q^2, differing by qe from the source table.",
    "The four corrected localization polynomials are independently checked by the Hilbert/weight Riemann--Roch sum. All exact residuals vanish in exact_diagnostics_v1_20261008.json.",
    "Equal slope sL/2=eL/3 cancels the first-order coefficient product. Corrected 24a2/V has mixed/e^2 coefficients 12 and 26 and differs from the printed coefficient by -6qe.",
    "The splitting-principle Chern character has rank a+1, linear term -a(a+1)s/2, quadratic coefficients a(a+1)(2a+1)s^2/12 and -a(a+1)(a+2)d/6.",
    "The weight lift is explicitly +1 on S and 0 on Q, so section weights are -a. Leading coefficients 24A0=alpha, 12A1=beta, 120B0=-gamma, 48B1=-delta imply P=-48(A1B0-A0B1).",
    "Serre vanishing for the ample fixed adiabatic polarization permits Euler characteristics to compute leading Hilbert/weight coefficients. Tensoring with fixed generator leaves the displayed A0-squared DF invariant.",
    "On the one-point blowup L=b=3H-D, q=H-3D, s=0, V=8, qL=bq=0, q^2=-8, z=d. The corrected a2=(36d-416)/15 differs by 16 and does not change the eventual sign for d=1 or d=2.",
    "The rank-two stable P2 bundle with c1=0,c2=1 cannot exist: h0=h2=0 by stability, Serre duality and negative slope, whereas chi=2-c2=1. This does not construct a c2=2 replacement.",
    "For actual nonzero extensions of nonisomorphic stable equal-slope factors, cross Hom vanishing and compatibility with the nonzero extension class force all endomorphisms to be scalars. This conditional explanation does not repair bundle or base existence.",
    "The source universal almost-complex moment map and Mabuchi transgression address separate issues. They do not alone settle the linear projection gain or positivity after scalar projective deformation directions.",
    "The exact primary v2 was fully read: 45 actual pages, 23 individually displayed matching images, 23 sequential notes. External moment-map, elliptic, stability-flow, blowup and bundle-existence sources remain attributed and qualified.",
    "No original general result, independent model certificate, whole-book new reading or canonical status change is claimed. The 42 atoms in 12 formal problems retain status; general BJ22 critical homogeneous Siu and envelopes remain OPEN and LPWZ density UNVERIFIED.",
    "All previous formal assertions, proofs, warnings, important boxes and manual equation tags are byte preserved. One supplementary tag 62.14e adds no formal environment or shift of old number values.",
    "The new bibliography explicitly prints arXiv:2406.08284v2 and its accepted October update, distinct from the original 2024 date."
]
audit.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(), status='DONE — ordinary mathematical self-audit and final scoped rendered clearance', checks=mathchecks, draft_fragments={str(q): sha(q) for q in sorted(D.iterdir())}, source_input_hashes=prep['after'], actual_final_book_reading_SHA256=sha(reading), actual_final_book_reading_credit=len(pages), whole_book_new_reading_claim=False, source_scope='Ortu--Sektnan 2406.08284v2: 45 actual complete primary pages in 23 individually displayed matching images with 23 sequential notes; external proof dependencies remain qualified', original_results_promoted=[], independent_model_receipt=None, canonical_status_changes=[], helper_source=__file__), ensure_ascii=False, indent=2) + '\n')
post.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(), status='DONE', checks=checks, source_input_hashes=prep['after'], rendered_gate_SHA256=sha(reading), historical_formal_proof_warning_important_blocks_byte_preserved=historical, other_active_TeX_inputs_byte_preserved=423, whitespace_gate='PASS — added lines clean and historical whitespace multiplicities preserved', whitespace_details=whitespace, legacy_writing_audit_unavailable=True, manual_semantic_delimiter_source_and_rendered_audits_used=True, active_book_changed=False, GitHub_published=False, canonical_status_changes=[]), ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(status='DONE', actual_reading_SHA256=sha(reading), final_math_audit_SHA256=sha(audit), post_render_checks_SHA256=sha(post), unique_pages=len(pages), fresh_views=len(views))))
