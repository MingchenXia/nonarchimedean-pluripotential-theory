from pathlib import Path
from datetime import datetime, timezone
import subprocess,hashlib,json
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Ortu_Sektnan_adiabatic_review_20261008';out=C/'local_source_commit_v1_20261008.json'
assert not out.exists()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
cp=C/'source_checkpoint_v1_20261008.json';p=json.loads(cp.read_text())
for n,h in p['protected_core_inputs'].items():assert sha(n)==h
files=[str(Path(n).relative_to(R)) for n in p['editorial_files']]+['manuscript/editorial/second_reading_and_research_programme_20261002.md']
assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True)==''
before=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
subprocess.run(['git','add','--']+files,cwd=R,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).splitlines())==set(files)
subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
run=subprocess.run(['git','commit','-m','Audit adiabatic bundle source and verify surface coefficient diagnostics'],cwd=R,check=True,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
after=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
for n,h in p['protected_core_inputs'].items():assert sha(n)==h
out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — local source checkpoint only',parent=before,commit=after,files={n:sha(R/n) for n in files},commit_output=run.stdout,source_checkpoint_SHA256=sha(cp),source_export_SHA256=sha(C/'source_export_v1_20261008.json'),protected_inputs_preserved=True,active_book_changed=False,GitHub_published=False,blocked_upload_not_retried=True,helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',commit=after,files=len(files),record_SHA256=sha(out))))
