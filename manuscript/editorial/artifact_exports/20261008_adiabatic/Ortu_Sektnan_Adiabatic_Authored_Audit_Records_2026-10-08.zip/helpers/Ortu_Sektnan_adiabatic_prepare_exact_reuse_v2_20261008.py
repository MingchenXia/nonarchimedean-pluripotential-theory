from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,fitz
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Ortu_Sektnan_adiabatic_review_20261008')
prior=C/'actual_staged_book_reading_v1_before_notation_repair_20261008.json';release=C/'staged_book_release_checks_v2_20261008.json';out=C/'exact_reused_book_views_v2_20261008.json'
assert not out.exists()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(prior)=='8ccbe6d985bed33999099baaeac4bd88f32ff9c6ba223b75b299709e3e789bf7'
p=json.loads(prior.read_text());r=json.loads(release.read_text());new=json.loads(Path(r['manifest_path']).read_text())
assert sha(p['PDF']['path'])==p['PDF']['SHA256'] and sha(r['PDF']['path'])==r['PDF']['SHA256']
rows=[]
with fitz.open(p['PDF']['path']) as a,fitz.open(r['PDF']['path']) as b:
    for old,v in zip(p['views'][:4],new[:4]):
        assert old['physical_pages']==v['physical_pages'] and old['actual_complete_text_read'] and old['actual_matching_image_individually_displayed']
        for key,hkey in [('path','image_SHA256'),('selected_text_path','selected_text_SHA256'),('sequential_note_path','sequential_note_SHA256')]:assert sha(old[key])==old[hkey]
        proofs=[]
        for n in v['physical_pages']:
            ta=a[n-1].get_text();tb=b[n-1].get_text();assert ta==tb
            pa=a[n-1].get_pixmap(matrix=fitz.Matrix(1.4,1.4),alpha=False);pb=b[n-1].get_pixmap(matrix=fitz.Matrix(1.4,1.4),alpha=False)
            assert (pa.width,pa.height,pa.n,pa.samples)==(pb.width,pb.height,pb.n,pb.samples)
            proofs.append(dict(physical_page=n,complete_PDF_text_SHA256=hashlib.sha256(tb.encode()).hexdigest(),rendered_RGB_SHA256=hashlib.sha256(pb.samples).hexdigest(),width=pb.width,height=pb.height,channels=pb.n,complete_text_identical=True,full_page_RGB_identical=True))
        note=C/'staged_book_notes_v2'/f'{v["number"]:02d}.md';assert not note.exists()
        note.write_text(f'# Exact reused actual staged-book view {v["number"]:02d}: physical pages {v["physical_pages"]}\n\nThe complete PDF text and full-page rendered RGB are identical to the actually read v1 pages. The frozen v1 complete-text, individually displayed image and sequential-note receipts are hash-verified. No fresh v2 image display or extra distinct-page reading credit is claimed. The v1 notation repair lies outside these pages.\n\nPrior actual note follows verbatim:\n\n'+Path(old['sequential_note_path']).read_text())
        rows.append(dict(number=v['number'],physical_pages=v['physical_pages'],prior_actual_view=old,page_identity=proofs,current_sequential_note_path=str(note),current_sequential_note_SHA256=sha(note),fresh_complete_text_and_display_credit=0))
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — exact reuse of eight previously actually read pages in four views',prior_actual_reading_path=str(prior),prior_actual_reading_SHA256=sha(prior),current_release_SHA256=sha(release),current_PDF=r['PDF'],reused_actual_pages=8,reused_views=4,views=rows,new_reading_credit=0,preparation_flags_rewritten=False,whole_book_new_reading_claim=False,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='DONE',record_SHA256=sha(out),reused_actual_pages=8,reused_views=4)))
