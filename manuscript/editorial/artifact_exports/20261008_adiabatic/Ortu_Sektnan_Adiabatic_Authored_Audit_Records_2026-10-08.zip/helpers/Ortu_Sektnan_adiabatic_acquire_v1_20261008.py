# Frozen acquisition template SHA256: 0b29476f689a04d3b0049412daed820f0a20780327c527bd26d40cf206bab6e4
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,urllib.request,subprocess,concurrent.futures,xml.etree.ElementTree as ET,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Ortu_Sektnan_adiabatic_review_20261008';S=R/'source_material/Ortu_Sektnan_adiabatic_sources_20261008'
out=C/'primary_acquisition_v1_20261008.json';assert not out.exists();C.mkdir(exist_ok=True);S.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def get(item):
    name,url=item;p=S/name;assert not p.exists()
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Scholarly-source-review/1.0'}),timeout=30) as r:data=r.read();status=r.status;resolved=r.url
        p.write_bytes(data);return dict(path=str(p),requested_URL=url,resolved_URL=resolved,HTTP_status=status,bytes=len(data),SHA256=sha(p),actual_proof_reading_credit=0)
    except Exception as e:return dict(requested_URL=url,error_type=type(e).__name__,error=str(e),actual_proof_reading_credit=0)
items=[('Ortu_Sektnan_adiabatic_arxiv_v2.pdf','https://arxiv.org/pdf/2406.08284v2'),('Ortu_Sektnan_adiabatic_current_abs.html','https://arxiv.org/abs/2406.08284'),('Ortu_Sektnan_adiabatic_API.xml','https://export.arxiv.org/api/query?id_list=2406.08284')]
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(get,items))
for r in rows:
    if r.get('path','').endswith('.pdf'):
        pdf=Path(r['path']);assert pdf.read_bytes().startswith(b'%PDF')
        with fitz.open(pdf) as d:r['physical_pages']=len(d)
        txt=pdf.with_suffix('.txt');assert not txt.exists();subprocess.run(['pdftotext','-layout',str(pdf),str(txt)],check=True)
        r['text_path']=str(txt);r['text_bytes']=txt.stat().st_size;r['text_SHA256']=sha(txt)
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — acquisition only; zero proof-reading credit' if all('path' in x for x in rows) else 'PARTIAL — acquisition only',baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),active_book_PDF_SHA256=sha(R/'manuscript/book.pdf'),native_catalogue_source_SHA256=sha(R/'output/open_problems_catalogue_2026-10-03.tex'),sources=rows,active_book_changed=False,canonical_status_changes=[],actual_proof_reading_credit=0,GitHub_published=False,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status=obj['status'],record_SHA256=sha(out),sources=rows)))
