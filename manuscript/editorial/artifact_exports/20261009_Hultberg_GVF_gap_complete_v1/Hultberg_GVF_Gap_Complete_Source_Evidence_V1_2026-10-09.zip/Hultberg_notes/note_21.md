# Actual primary reading 21: physical pages 41–42

Read both complete reference pages and matching image. All listed titles,
authors, versions and primary identifiers are read as bibliography, not
recursive proof verification. Important further audit targets are DHS24
arXiv2412.15988 (continuity/heights), foundations2409.04570, GY25 2511.12509
(naive minima example), LY25 2505.07193 (relative-power/multisection
reductions), Sed23 2303.03377 Proposition5.5 (exact mixed-height formula),
Sed25 2503.20156, Liu24 2404.13200 and Stacks0BF4.

GGK21 is listed as the old arXiv2105.15085 source, not authentication of
its published edition or every imported lemma. Hul24 refers to the literal
2024 arXiv already completely read; its later IMRN journal text remains
unread. Gub10 skeleton measures and de Jong–Shokrieh local Bernoulli
formulas provide precise primary locators; no source inheritance from
this bibliography alone. MY25 2512.07655 is the distinct quantitative
DYNAMICAL Zhang inequality and cannot be substituted for the broad
semipositive-family Corollary2.6.11 with its negative-height defect.
MV25 and JX22 must retain characteristic hypotheses before Ueno base-
extension conclusions are used. Yamaki reference continues on p43.
No new theorem, independent-model receipt or other page credit.
