# Actual primary reading 07: physical pages 13–14

Read both entire texts and matching image. Remark 2.3.3 CONFIRMS the exact
mass scaling raised in note06: K(X,H1,...,Hd)|K=K[H1...Hd], and a
zero-dimensional extension gives Fsym[[F:K]]. Thus Proposition/definition
2.3.5 with scale 1/((d+1)L^d) restricts to K[1/(d+1)], not to K, for d>0
and nontrivial K. Its printed assertion that it is a GVF extension needs
correction. The print calls (X,L,f) a polarized abelian variety; retain the
literal wording rather than silently replacing it by a dynamical system.

Theorem 2.3.6 literally lacks genericity of its height-zero net and prints
limit h_M(x_i)=(L^d M)/((d+1)deg_L X). Even a generic net fails the constant
metric-shift calibration: for M pulled back from a base line of height c,
all point heights are c and the projection formula gives mixed intersection
c deg_L X, hence the printed right side c/(d+1). Taking an elliptic curve
with canonical L and a generic torsion net gives d=1, c versus c/2.
The usual differentiability/normalized-height derivative would remove that
factor when h_L(X)=0. This is a literal exact normalization diagnosis;
Sed23 Proposition5.5 must be acquired/read before attributing any defect
to that primary source. The proof of 2.3.5 also treats a difference of two
positive GVF functionals as positive without justification; equality on
some bundles alone does not give this cone property. Intended canonical
construction is not independently certified by the printed proof.

Filters, ultrafilter lemma and Stone–Cech universal property fully read.
The bounded-height ultraproduct M0 is a field only with UNIFORM triangle
errors/ht(2) bounds; Definition2.4.3 has no such bound in its stated family.
The following pages may add it. Coordinate heights for finite affine
cover are used to build ultraproduct points. No theorem import, no
independent verdict and no page credit beyond these two pages.
