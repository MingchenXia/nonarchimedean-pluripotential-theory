# Actual primary reading 18: physical pages 35–36

Read both whole texts and matching image. Complete Lemma5.4.4 uses a
positive-measure ARCHIMEDEAN subset whose conditional curvature measures
have FULL analytic support, then positivity of the Green function near an
effective nontrivial geometric divisor. In its 'in particular' line,
printed div(s)∧0 is nonpositive; use its negative (or the positive part)
for an effective test. This sign typo does not itself refute the full-
support argument. Corollary5.4.5 uses the original Haar curvature, with
canonical-GVF normalization prerequisite still needing correction.

Full Lemma5.4.6 relies on abelian BC, finite-stabilizer/translation
reductions, canonical generic fibres and the constant-field statements.
The notation X_K(eta) must mean the GENERIC FIBRE over A, living in Y,
not scalar extension of the whole X⊂Y×A. Otherwise its claimed constant
components and dimension reduction are unjustified. Geometric proof
imports Lemma5.4.3 and therefore the flagged zero-height uniqueness
lemma; archimedean proof imports toric BC and full-support Corollary5.4.5.

Relative Faltings–Zhang construction, Lemmas5.5.2–3 and first reduction
paragraph fully read. Lemma5.5.2 claims one irreducible Zn has image equal
to alpha_n of the ENTIRE relative power. That whole-image formulation
needs the primary LY25 Proposition5.8: relative powers may have several
components with different toric difference images (e.g. a generically
finite double cover u^2=f(a), with diagonal and ratio -1 tuples). A
generically finite chosen component is distinct from covering a reducible
whole image. Lemma5.5.3 claims smallness of each relative-power component
by projection formula. The ensuing proof chooses one component, small
image in torus×abelian quotient, and quasi-split classification; further
normalizations and torsor constraints continue p37. No import or verdict.
