# Actual primary reading 14: physical pages 27–28

Read whole texts and matching image. Universal split torsor uses rigidified
extension points. The semiabelian Hilbert-space display literally repeats
Hilb(A/A), whereas its intended family is the compactified universal G;
this is a moduli locator typo, not a new geometry theorem. Fixed polytope,
polarization and invertible level remain part of the family construction.
Hodge line controls stable Faltings height; over a nonarchimedean GVF the
text explicitly says hFal>=0 and zero iff the abelian variety is constant.
It explicitly says max{ht(2),h(G)}=0 iff G is isotrivial. Thus the zero-
height case flagged in Theorem4 is genuinely included: on a trivial-height
algebraically closed characteristic-zero field a constant genus-two curve
in its Jacobian has finite stabilizer and generates the Jacobian by X-X,
while all point heights and h(G) vanish. The printed <=0 subset is then
all X(K), dense, so cannot lie in a proper closed subset. The general
Conjecture4.2.3 uses STRICT <, whose zero threshold is empty and avoids
this issue; Proposition1 only claims that strict form. Do not conflate
the endpoint defect with a refutation of BCSA or the strict gap principle.

The deduction proof is read through its partial end on p28. Polarization
bounds use geometric nefness and deg_rho(X_eta)>=1, then imported GGK
Lemma2.5. Appropriate characteristic-coprime level can be chosen from
finitely many levels. Passing from Faltings/extension height to an
arithmetically ample parameter height strengthens the desired gap on
bounded families. Noetherian induction on a closed irreducible Hilbert
locus follows next page. Arbitrary ultraproducts still need uniform error
control; normalization and the strict threshold are essential. No book
import or independent production verdict.
