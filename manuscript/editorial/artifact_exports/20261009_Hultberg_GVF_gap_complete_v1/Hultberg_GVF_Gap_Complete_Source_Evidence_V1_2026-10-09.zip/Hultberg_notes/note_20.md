# Actual primary reading 20: physical pages 39–40

Read complete texts and matching image. Lemma5.5.7 ends with a generic
sequence [n]Q of hypothetical zero-height nontorsion points on E; it uses
the corrected small-point equidistribution theorem to contradict retraction
zero versus Haar circle. This is a dependence on the proper variational
formula, not a Northcott argument. Lemma5.5.8's complete proof reduces via
simple factors and trace base change, then uses BC for zero-height divisors;
its statement omits that BC hypothesis although the proof invokes it.
Under the main theorem's assumption this dependency must be explicitly
carried across the function-field extensions. Product canonical-GVF
transitivity is asserted; the printed extra dimension normalization in
2.3.5 would scale the original base by 1/(d1+d2+1) directly versus
1/((d1+1)(d2+1)) iteratively. Corrected unit mass is needed first.

Full final Theorems1–2 and proofs read. They are short consequences of
traceless BC, quasi-split classification and Lemma5.5.1. They do not repair
any flagged earlier normalization/uniqueness/proof-scope issue. Arbitrary
positive-characteristic abelian input remains open; elliptic quotient is
claimed because elliptic BC itself is elementary. No main theorem is
refuted solely by the literal auxiliary diagnoses, and no theorem is
imported into the book without resolving dependencies.

Every reference on p40 read. In particular Che11 is Chen's differentiability
of arithmetic volume (JLMS2011), so section5.2's citation to Che11 for
archimedean adelic-curve Bogomolov is a mismatched locator; CM22 is the
relevant listed equidistribution source. CM21/22 are explicitly arXiv
versions, not authentication of their later publication. Cha00 is the
published source already completely read. No recursive proof credit.
