# Actual primary reading 17: physical pages 33–34

Read both full texts and matching image. Complete Lemma5.3.1 proves
traceless char0 BC by reducing to a minimal finite-type moduli field,
GGK Lemma3.4 potential nondegeneracy, and bigness of the Deligne pairing.
The positivity functional plus big pairing killed by hhat(X)=0 is the
contradiction. Tracelessness, generation, finite stabilizer, generic
finiteness of the moduli map and characteristic-zero inputs are essential.
Proposition5.4.1 descends a small subvariety of a constant projective
variety after extension by identifying zero-height points with constants;
this uses the ample constant polarization and the new extension minima.

Full Lemma5.4.2 proof makes an unjustified LOCAL leap: global
ht(x+a)=ht(a) does not itself force |x+a|=1 at every place with |a|<=1.
An adversarial polarized-model construction to check explicitly: base
K0=k(a,b) with the P2 hyperplane height (total-degree height), k trivial.
F_slope=k(x,y)(t), a=t, b=xt+y, constants x,y; F_intercept=k(s,x)(t),
a=t, b=st+x, constants s,x. Both generic lines restrict to the same
P2 hyperplane height on K0, and ht(x)=0 in each, but ht(b-xa)=0 in
F_slope and 1 in F_intercept. Symmetric algebraic extensions/composita
should allow the algebraically closed-base hypothesis to be checked.
This is a candidate exact construction requiring a fresh full derivation;
no accepted counterexample or independent production-verifier verdict.
In the slope model, at the base hyperplane-at-infinity place x-b/a=-y/a
has positive order even though |b/a|=1, pinpointing the local leap.

Lemma5.4.3's entire proof reduces via simple factors and BC zero-height
divisors to elliptic curves, then assumes Lemma5.4.2 to force Gauss
support and uses positive bad-reduction skeleton measure to contradict
it. That Gauss-support dependency must be cleared or replaced; the
normalization defect in 2.3.5 is another prerequisite. No refutation of
the intended constant-field statement is claimed. Lemma5.4.4 starts
its positive-measure FULL analytic support hypothesis and continues p35.
