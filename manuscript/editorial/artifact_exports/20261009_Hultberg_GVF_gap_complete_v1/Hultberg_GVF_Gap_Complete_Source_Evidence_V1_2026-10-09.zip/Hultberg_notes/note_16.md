# Actual primary reading 16: physical pages 31–32

Read complete texts and matching image. Ueno/Kawamata locus is the union
of positive-dimensional subgroup translates and its closedness imports
Abramovich. Groupless-modulo and its base-extension invariance are quoted
in CHARACTERISTIC ZERO in Proposition5.1.4; Corollary5.1.6 omits that
qualification while being presented as a consequence. Its all-characteristic
use needs a separate primary argument, not this char0 implication alone.
Lemma5.2.1 uses the NON-Ueno open locus X^circ, despite calling it the
Ueno locus in the text. A countable distinct small sequence there has a
positive-dimensional closure component outside Ueno, yielding the intended
countable reduction. Retain density on that component, not every chosen
sequence dense in the original X.

Proposition5.2.2's complete toric proof is read. For all nontrivial character
images to be Gm, reduction must include zero-height translation/difference
generation, not just X generating the group (a translated kernel may
itself generate). Character Fourier tests over each measurable U in the
archimedean place space require the JOINT local-place measure, not marginal
Haar distributions. It cites the defective printed Theorem2.3.6; a corrected
primary small-point variational theorem with genericity, proper normalization
and admissible measurable tests is needed to substantiate that step. The
intended toric BC is not refuted by the normalization diagnostic.

Geometric traceless-abelian Lemma5.3.1 starts, explicitly restricted to
char0 and finite stabilizer/generation; Betti nondegeneracy and bigness
are imported next. A fresh arXiv primary metadata check has now verified
only v1 (8 January 2026), 43 pages, no later listed revision or journal
reference. This is metadata evidence, not additional full-proof credit.
No theorem import or independent verdict.
