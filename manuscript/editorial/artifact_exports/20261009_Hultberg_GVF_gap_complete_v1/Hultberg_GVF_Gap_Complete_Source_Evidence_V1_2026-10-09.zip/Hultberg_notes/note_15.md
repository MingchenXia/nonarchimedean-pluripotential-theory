# Actual primary reading 15: physical pages 29–30

Read both full texts and matching image. Statement4.2.4 literally puts
x in G_t rather than X_t, but proof uses X_t. Even with that corrected,
the non-strict threshold <=epsilon h_L(t) needs a nonzero-height exception
or a strict threshold: constant nonarchimedean parameters have h_L(t)=0
and all constant small points are dense. Its proof rescales by 1/h_L(t)
without excluding zero. Arithmetic ampleness DOES give the uniform bound
ht(2)/h_L(t), when positive, needed for the ensuing scaled ultraproduct;
thus the earlier unrestricted-definition defect is avoidable in that
specific positive-height argument. Height one on the Hilbert parameter
shows the PAIR is not constant; it need not imply G itself nonisotrivial,
since X can vary on a constant ambient group. The intended nonspecialness
argument must use that pair distinction and zero-height translations.

Complete Lemmas5.0.2–6 read. Zero-height translation preserves smallness
by a nonnegative height triangle bound, without invoking Northcott.
Isogeny/specialness and smallness comparisons use actual finite surjective
maps, compatible character-polytopes and canonical metrics. Quotient by
the connected stabilizer reduces to finite stabilizer; abelian lifting
uses Poincare reducibility. Generating reduction chooses a height-zero
point only AFTER allowing a GVF extension. Quasi-split means constant
semiabelian factor times traceless abelian factor, not a split-torus or
reductive-group condition. Main positive-characteristic arbitrary abelian
GVF BC remains explicitly open. No book import or independent verifier.
