# Actual primary reading 12: physical pages 23–24

Read entire texts and matching image. Canonical-height comparability on G
uses inclusions and dilation of polytopes with zero INTERIOR, while toric
heights on boundary can remain negative. Chow trace definition is over
algebraically closed fields and its existence/kernel claim imports Liu24;
any scheme-theoretic inseparable-kernel qualification in characteristic p
needs the primary source, not just abelian-point intuition.

Abelian specialness includes a zero-height translation, abelian subvariety
and trace subvariety. Conjecture3.2.1's equivalence to hhat(X)=0 uses the
new extension minima. Example3.2.2 applies the canonical function-field
construction already flagged for normalization. Example3.2.3 uses a
non-isotrivial elliptic surface, a nontorsion section, a big geometric
bundle and infinitely many torsion specializations to produce a GVF
height-zero nontorsion point; dependencies Gao/DeMarco are not proof-cleared.
Semiabelian specialness permits a translation over a further extension;
Remark3.2.4 explicitly records uncertainty about choosing it over K itself.

Conjecture3.2.5 uses TWO leading arithmetic intersections: M^(a+1) on
pi(X), and rho^(dimX+1-a) pi*M^a on the compactified closure. It does
NOT require the entire arithmetic height of rho+pi*M to vanish. The
linear/quadratic [n] eigenspaces explain this distinction and compatibility
with negative full heights already read in Cha00. Remark3.2.6 has a minor
printed expansion exponent dimX rather than dimX+1 for arithmetic powers.
Lemma3.2.7's printed set switches g/x/G instead of X; intended density in
X is used in proof. First equality follows by projection/dense small image;
second proof begins with a binomial expansion and continues next page.
No import or independent verdict.
