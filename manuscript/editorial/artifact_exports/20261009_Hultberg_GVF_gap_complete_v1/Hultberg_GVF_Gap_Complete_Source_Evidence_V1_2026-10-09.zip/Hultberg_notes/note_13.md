# Actual primary reading 13: physical pages 25–26

Read full texts and matching image, completing Lemmas3.2.7–8. The second
half of 3.2.7 compares RAW arithmetic powers with point minima while the
Zhang bounds apply to NORMALIZED height. The omitted denominator
(dimX+1)deg(rho+N pi*M)^dimX grows like N^a, a=dim pi(X). A uniform lower
bound on absolute minimum therefore only bounds the leading raw coefficient
below by a possibly negative constant; it does not force >=0 as printed.
The first sign <=0 uses essential minimum zero, so positive denominator
can be restored there. This is a proof gap in the reverse sign step,
not a demonstrated counterexample to the intended mixed-vanishing lemma.

Lemma3.2.8's arithmetic numerator, after killing its first two coefficients,
is O(n^(dimX+a)); its denominator including the extra n has order
n^(dimX+a+1). The second occurrence of 'numerator' is a printed typo for
denominator. Here normalization is explicitly present. The lower bound
for the absolute minimum comes from [n] extending to the proper
compactification and pulling back the fixed bundle; its global absolute
minimum bounds every image point uniformly. Together with nonnegative
essential minimum and the normalized lower Zhang bound this can control
both terms after division by n. Do not mistake negative boundary heights
for an automatic counterexample to that correctly normalized asymptotic.
Remark3.2.9 retains GVF extensions and only predicts an alternate sectional-
minimum approach might avoid them.

Moduli section requires polarization degree, sufficiently large invertible
level N, split torus identification, dual-abelian extension points and
restricted integral Hilbert loci. Twice-polarization bundle and canonical
metrics are imports. Finite-family reduction must bound these parameters,
not the entire disjoint union of all moduli. No new theorem or verdict.
