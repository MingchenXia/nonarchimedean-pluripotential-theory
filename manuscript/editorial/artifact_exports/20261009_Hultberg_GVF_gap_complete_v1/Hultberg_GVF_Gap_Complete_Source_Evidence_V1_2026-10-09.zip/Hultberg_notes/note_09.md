# Actual primary reading 09: physical pages 17–18

Read both full texts and matching image. Complete end of Proposition2.5.5
uses DHS continuity, classical Qbar/k(t) compatibility and existential
closedness. Those original sources remain imported, not recursively read.
Conjecture2.5.6 is explicitly OPEN in this version: a GVF model companion,
or closure of existentially closed models under appropriate ultraproducts.
The following discussion of simplifying Lemma3.2.8 is conditional on it,
not an unconditional replacement proof.

Theorem2.6.1's full short proof cites Grothendieck limited families for
FIXED dimension d and degree r, with reduced pure-dimensional geometric
fibre subvarieties. Do not silently include arbitrary embedded/nilpotent
structures. Relative Hilbert functor/projectivity and geometrically
integral open locus are read. Definition2.6.2 changes minima by infimum over
ALL GVF extensions. Essential minimum excludes every proper closed subset
over the EXTENSION field, not only the original base. Example2.6.4's
transcendental zero-height point on the translated graph curve explains
why this distinction matters; zero-height genericity over the original
field alone does not ensure essential minimum zero. Its positive essential
minimum imports later toric BC Proposition5.2.2.

Remark2.6.3 claims attainment of the extension infimum and a dense exact-
minimum set using ultraproducts; retain arbitrary-extension scope, not
finite algebraic-point attainment or a repair of the BGPS candidate.
Hilbert parametrization chooses a compactification and arithmetically
ample M. Definition2.6.5 literally has dim Z < d-1, degree<=N, parameter
height<=C, with d,N,C>0; exact conventions continue next page. No new
book theorem or independent verifier verdict.
