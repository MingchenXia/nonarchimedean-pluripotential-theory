# Actual primary reading 10: physical pages 19–20

Read entire texts and matching image. Complete Lemma2.6.6 proof has literal
quantifier/boundary problems: I was defined with parameter height <=C,
but proof asserts <C for a chosen witness; closed cutoff need not be
stable under representing factors approaching C from above. Reverse
inequality chooses ri with lim ri<r and then concludes outside infimum
>r, which does not follow (a corrected intermediate lower threshold would
have to exceed r). Removal dimension is still <d-1. These are exact printed
proof diagnoses; intended semicontinuity with relaxed bounds is distinct
from the claimed exact hard-cutoff equality. Absolute minimum and essential
minimum use arbitrary extensions, and the stated essential inequality is
upper-to-limit >=. Do not import a continuity theorem from this proof.

Proposition2.6.8's full proof descends to classical Zhang, relying on the
unverified preceding ultraproduct behavior and imported sources. Remark
2.6.9 explains why extension minima differ from GY25's naive point minima.
Proposition2.6.10's full partial CM account involves asymptotic slopes,
but prints degree(V)<=zeta_ess+epsilon rather than degree(V)/rank(V).
Evaluation at rank(V) points naturally bounds degree by rank times the
threshold; that normalization must be retained in a complete proof.

Corollary2.6.11's exact statement again lacks positivity of fibre height
or an additive constant, and its proof divides by h_L(X(s_i)). A simple
classical test is the product E×P1 with canonical ample L_E plus the
pullback of O(1) on P1 shifted by a negative constant -c. The geometric
Deligne pairing is 2 deg(L_E) O(1), hence big. On every root-of-unity base
point, fibre height is -c and all torsion points have height -c. For
0<epsilon<1 these points are below (1-epsilon)(-c) and are dense; infinitely
many such base points cannot be removed by a proper closed subset of P1.
This is a candidate exact known-model calibration, pending completion of
the proof and explicit record; no accepted original result or independent
receipt. Rescaling by a negative height is not a GVF scaling. Proof continues
at p21, which has not yet been credited.
