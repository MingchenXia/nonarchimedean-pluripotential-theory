# Actual primary reading 02: physical pages 3–4

Read both complete prepared texts and their matching rendered image. The
semiabelian height is an abelian degree-two and toric degree-one sum; the
polytope contains zero in its interior, with the explicit anticanonical
cube model. Specialness is stated after quotient by the full stabilizer
and permits a zero-height translation over a GVF extension together with
a Chow-trace subvariety. Such a translation must not be replaced by torsion.
Theorem 2 reduces BCSA to BC on the abelian quotient. The height h(G) uses
Faltings height plus all extension-point Néron–Tate heights after choosing
a torus identification; degree and symmetric polarization are part of scope.

The general gap statement has STRICT < and max{ht(2),h(G)}. Theorem 3
uses <= and max{1,h(G)} over algebraic numbers. Theorem 4 uses <= c1 h(G)
in characteristic zero or above c3 with dimension/degree constants; Theorem
5 claims all characteristics for elliptic quotient. Preserve finite
stabilizer and X-X generating G. The zero-height endpoint of Theorem 4
needs an explicit check against constant/trivially valued GVFs, since its
non-strict threshold could include every point when h(G)=0. This is a
question for the unread exact proof/definitions, not an accepted refutation.
Quasi-split reduction and existence of zero-height nontorsion points are
announced, with proof continuing on the next page. No theorem imported,
no independent-model verdict, and no page credit beyond these two pages.
