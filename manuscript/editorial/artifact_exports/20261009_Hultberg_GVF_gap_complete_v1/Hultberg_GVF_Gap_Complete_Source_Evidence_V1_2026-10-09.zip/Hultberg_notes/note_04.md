# Actual primary reading 04: physical pages 7–8

Read both complete texts and matching rendered image, including all height
axioms, definitions and Lemma 2.1.2's complete proof. GVF height is
projective, tensor-additive, monotone and has a fixed archimedean error;
PF kills one-coordinate principal heights. The linear-functional approach
uses positive lattice Q-divisors and their effective-cone completion. The
adelic-divisor colimit statements import Ben+24/Szachniewicz/Yuan–Zhang
and contain an editorial variable mismatch near the end of p7; these deeper
sources are not recursively verified here.

Lemma 2.1.2 assumes finitely generated field extension and an arithmetically
big adelic bundle killed by the functional. Domination of both L' and -L'
by multiples of that big bundle forces the WHOLE functional to vanish;
retain all these hypotheses and possible dominating models. Proper adelic
curve representation requires countability, unlike topological adelic curves.
Integrability plus PF are explicit in Definition 2.1.3. The text explicitly
allows the trivial height on ANY field and height rescaling lambda=0.
Thus the zero-height endpoint concern in Theorem 4 is within the printed
GVF class, not excluded by its definition. The value of h(G) still needs
its exact Faltings definition before a final source diagnosis. Symmetric
algebraic extension is canonical/Galois invariant; arbitrary GVF extension
need not be the symmetric one. Constant field only applies to the strong-
triangle/nonarchimedean case. No theorem imported or verdict promoted.
