# Hultberg GVF gap principle arXiv v1 — actual source reading 1

Physical pages 1–2 were read completely in selected text and matching displayed image. The controlling source is arXiv:2601.04972v1, 8 January 2026, 43 pages. Only these two pages are credited so far.

The abstract distinguishes three claims: the characteristic-zero new gap principle for semiabelian varieties; a reduction to the abelian Bogomolov input valid also in positive characteristic, where that general input is unknown; and an unconditional positive-characteristic case with elliptic abelian quotient. These are introductory claims, not proof clearance.

For an algebraically closed underlying GVF, the abelian special subvarieties use the height-zero constant field in the non-Archimedean case, the Chow trace, an abelian subvariety and a height-zero translating point. Height zero over a general GVF is not automatically torsion as it is for a number-field canonical ample symmetric height. The Bogomolov statement is Zariski density of arbitrarily small points implying specialness, with an asserted normalized-height equivalent formulation. Theorem 1 claims it for characteristic-zero GVFs. Its proof is later, and the definition in the Archimedean case needs the later exact formulation.

The introduction explains the ultraproduct route between uniform gap principles and arbitrary GVF Bogomolov. It explicitly uses Gao–Ge–Kuhne potential non-degeneracy results for its non-Archimedean geometric abelian case, so it is not an independent proof of those results. Claims of other independent work in progress are not a source for a priority statement. GVF structure, proper adelic curve representation, Archimedean mass and field/constant-field hypotheses must be retained in later imports.

No whole-source or proof-reading claim, book change, independent verifier receipt, current published-version verdict or new theorem promotion.
