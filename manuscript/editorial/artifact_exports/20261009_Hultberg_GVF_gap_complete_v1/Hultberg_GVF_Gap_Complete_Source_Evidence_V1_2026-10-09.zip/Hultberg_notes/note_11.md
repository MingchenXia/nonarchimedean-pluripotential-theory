# Actual primary reading 11: physical pages 21–22

Read both complete texts and matching image. Corollary2.6.11 ends by
claiming density via Lemma2.6.6 and contradicting zeta_ess>=normalized
height after rescaling height to one. No additional positive-height,
large-height or additive-error hypothesis appears at its end. The
negative constant-shift candidate from note10 therefore remains a literal
statement concern, not resolved by a hidden final qualification. The
ordinary product-family degree and canonical torsion heights supply its
calibration; no production-verifier verdict is claimed.

Section3 historical Bogomolov references fully read as references, not
proof-cleared dependencies. Definition3.1.1 requires an fppf exact extension
and later restricts to split torus; arithmetic torsors carry compatible
multiplicative isometries, not an arbitrary collection of characters.
The lattice maximum divisor construction and full-dimensional polytope
compactification are read, including canonical metric and effective divisor
when zero belongs to the polytope. In Example3.1.3 the last product exponent
is literally n-1 instead of n-i; the intended anticanonical cube construction
is clear from the surrounding quotient, but retain this as a minor locator
rather than a geometric counterclaim. Canonical toric height is nonnegative
on G, not necessarily its boundary, and scales linearly under [n]; the
abelian component scales quadratically. Flat character metrics make the
max-divisor semipositive, while integrability uses the separate lattice
and Picard-zero lemma. Canonical sum and comparability continue at p23.
No theorem import or independent receipt.
