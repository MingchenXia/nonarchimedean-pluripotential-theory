# Actual primary reading 05: physical pages 9–10

Read entire prepared texts and matching image. Rendered bars are important:
Lemma 2.1.4 says the symmetric algebraic closure Kbar has constant field
kbar, not unchanged k. Full proof uses symmetric conjugates and a bounded
finite-dimensional constant-field span versus powers. The inseparable
step only needs x^p in K; its printed stronger L^p=K description is not
needed for the argument and must not be treated as a general p-extension
identity over an arbitrary imperfect field.

The boundary completion, strongly nef/nef/integrable distinctions and
fibre semipositivity definitions are fully read. A literal definition issue:
the text calls X quasi-projective but asks its model to be flat PROJECTIVE
over the base with generic fibre X. This only models proper/projective X;
nonproper X needs the usual quasi-projective/compactification variant.
The projective intersection applications on these pages are within the
printed scope. Definition 2.2.1 uses integrable bundles and a flat projective
model with integral total space/normal base; the arithmetic intersection
is the GVF functional of the geometric Deligne pairing. Base-change
independence imports YZ24 Theorem 4.1.3. Height normalization is explicitly
(L|Z)^(dimZ+1)/[(dimZ+1)(L|Z)^dimZ] for underlying ample L.
Yuan–Zhang adelic bundles and Chen–Moriwaki measurable-metric bundles are
kept distinct. No imported recursive proof clearance or original verdict.
