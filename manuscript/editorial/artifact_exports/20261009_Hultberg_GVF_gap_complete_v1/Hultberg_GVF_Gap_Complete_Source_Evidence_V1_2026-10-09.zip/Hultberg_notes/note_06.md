# Actual primary reading 06: physical pages 11–12

Read both entire texts and matching image, including full Lemmas 2.2.3–4.
The comparison of YZ and C-M intersections imports later Proposition 2.5.5;
Remark 2.2.2 explicitly acknowledges the absolute positivity restriction
and possible GVF-dependent completion. Lattice maximum arguments use the
translation identity (D1+E)∨(D2+E)=(D1∨D2)+E and semiample metric/model
approximation. The reduction from arbitrary semipositive bundles to
semiample ones and nef versus strongly-nef integrability requires the
stated limiting/positivity framework, not pointwise flatness alone.

Lemma 2.2.4's fibre constant is exactly the correction already read in
Cha00 and used in the book. But a polarization is an isogeny A→Adual;
it does not automatically lift an arbitrary base section Q to a section
sigma:S→A. A finite base change/isogeny lift and rational descent can
complete such an argument, or Q must already have a specified lift.
The printed proof omits that choice. M also needs the canonical metric
and relative rigidification rather than an arbitrary ample representative.
No claim that the intended integrability lemma is false is made here.

Polarized functionals use H1...Hd·D over a d-dimensional normal projective
model. Preserve the geometric total mass H1...Hd: restriction to the
original K scales its height by that mass unless normalized to one, a
point to check on following pages. The global adelic space uses measurable
families and countability, with local curvature-product measures. Proper
closed subvarieties have zero mass for these products; countability makes
the union of all such loci null. No import or independent verdict.
