# Actual primary reading 08: physical pages 15–16

Read both whole texts and matching image. Lemma 2.4.4's entire proof uses
uniform boundary-norm approximation and a bounded boundary height to
exchange ultralimit and completion. The preceding claim that any geometric
ample adelic bundle on a QUASIPROJECTIVE X characterizes bounded coordinate
height needs a compactification/positive-boundary assumption: on affine
Gm the trivial bundle is geometrically ample, with constant metric height
zero, while coordinates can have unbounded Weil height. Projective bounded-
height applications do not have that defect.

The unrestricted Definition2.4.3 still has no uniform error bound. Exact
simple test: Mi=Q with heights scaled by i, the sequences 1 and 1 are
bounded-height but their sum 2 has height i log2, so M0 is not closed under
addition. A family of GVF extensions of a COMMON base fixes ht(2) and
avoids this particular error. Such a common-base family is used in the
analytification paragraph; retain it in applications rather than treating
all arbitrary GVF families as valid bounded-height ultraproducts.

GVF analytification uses the constructible topology plus tuple heights,
height-bounded compact subsets and residue fields extending the given base
height. Existential closedness means K-points dense there, not merely
algebraic closure. Lemma2.5.4's full proof proceeds through generic GVF
points and ultrapowers, then finite-type subfields. Qbar[1] and algebraic
closure of k(t)[1] are the printed examples (bars verified visually).
Proposition2.5.5 comparison proof begins and is unfinished at p16; its
countable statement reduces to finite-type data on the available models.
No new verdict, import or page credit beyond pp15–16.
