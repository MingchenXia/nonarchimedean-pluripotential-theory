# Actual primary reading 03: physical pages 5–6

Read both entire texts and the matching image. The announced gap argument
uses ultrafilter/continuous-model-theory compactness, not effective bounds.
The abelian nonarchimedean input explicitly depends on GGK potential
nondegeneracy and geometric GVF specialness; Mavraki–Yap is a separate
comparison using a uniform dynamical Zhang inequality. Neither dependency
is independently proof-cleared by this introduction.

Proposition 2 uses a NEW definition of successive minima, not automatically
the ordinary number-field point minima: d/(d+1) zeta_abs + 1/(d+1) zeta_ess
<= normalized self-height <= zeta_ess for geometrically ample semipositive
L. Preserve division by (d+1)(L^d) and the corrected field-extension
quantifiers to be read in section 2.6. Theorem 6 advertises any epsilon>0,
fibre semipositivity and big GEOMETRIC Deligne pairing, with an exceptional
closed subset of the base and bounded-degree/height proper fibre locus.
Its exact hypotheses and negative-height/epsilon endpoints need the full
Corollary 2.6.11 proof; the introduction alone is not a book-import basis.
The author emphasizes arbitrary adelic-curve structures, not just polarized
ones, and describes existential closedness of Qbar and k(t). Section map
and acknowledgments fully read; preliminaries begin at the bottom of p6.
No result imported, no independent verdict and no further page credit.
