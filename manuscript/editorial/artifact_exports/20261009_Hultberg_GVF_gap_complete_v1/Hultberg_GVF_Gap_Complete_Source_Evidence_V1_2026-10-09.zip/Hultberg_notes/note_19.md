# Actual primary reading 19: physical pages 37–38

Read both full texts and matching image. The generically finite torsor
multisection argument imports LY25 Theorem5.6 and compares absolute
adelic divisor norm with a polarized function-field height. Finite-cover
norms retain degree [K(X):K(Y)] and only give a multiple of Q; removing
that multiple requires torsion/isogeny, not equality of integral bundles.
The Albanese descent needs numerically trivial/Picard-zero pullback,
surjective Alb(W)→A0 and injective dual map to descend a CONSTANT image
back to k. All these hypotheses are used.

Full Lemma5.5.4's product Pic0 proof is read. Its 'in other words any
numerically trivial' wording is broader than algebraically trivial Pic0
when Neron–Severi has torsion; taking a suitable power/rational coefficients
or working with Pic^tau can handle the distinction, but the printed
Pic0 universal family alone does not cover all integral numerically trivial
bundles. It imports Stacks0BF4 theorem of cube, whose precise scheme/proper
hypotheses are not recursively checked here. Lemma5.5.5 separates two
factors, then uses the flagged canonical-GVF/constant-field lemmas and
Lemma5.5.8 to force torsion on the traceless factor.

Complete Lemma5.5.6 skeleton calculation read: g=(l/2)B2(nu/l)-l/12,
derivative (2nu/l-1)/2, slope jump -1 at zero. Constant sum of shifted
potentials forces equality of retracted point multisets and r(Q)=0.
This derivative is correct in the rendered fraction. Lemma5.5.7 begins
and computes nonnegative prime-divisor weights plus local |g_D| integrals;
zero functional gives zero support-point heights and zero skeleton function
a.e. The displayed isolated integral after 'conclude' lacks its =0 in
print, but the surrounding nonnegativity supplies it. Further torsion
argument is unread until p39. No theorem import or independent verdict.
