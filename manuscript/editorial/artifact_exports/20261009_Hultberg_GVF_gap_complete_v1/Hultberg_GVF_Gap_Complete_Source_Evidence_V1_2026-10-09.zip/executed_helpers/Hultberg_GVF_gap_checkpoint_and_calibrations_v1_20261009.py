from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction
import hashlib,json,sympy as sp
G=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009/dependencies_v1/Hultberg26GapArxivV1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prep=json.loads((G/'source_preparation_v1_20261009.json').read_text())
checkpoint=G/'actual_source_checkpoint_v1_20261009.json'; calibration=G/'literal_exact_calibrations_v1_20261009.json'
assert not checkpoint.exists() and not calibration.exists()
pages=[];receipts=[];previous=None
for n in range(1,23):
    p=G/f'primary_notes_v1/note_{n:02d}_receipt.json';r=json.loads(p.read_text())
    assert r['view_number']==n and r['source_PDF_SHA256']==prep['source']['SHA256']
    assert r['full_selected_text_read'] and r['matching_rendered_image_displayed_and_read']
    assert sha(r['image_path'])==r['image_SHA256'] and sha(r['selected_text_path'])==r['selected_text_SHA256']
    assert sha(r['note_path'])==r['note_SHA256'] and r['previous_receipt_SHA256']==previous
    previous=sha(p);pages.extend(r['physical_pages']);receipts.append(dict(number=n,physical_pages=r['physical_pages'],receipt_SHA256=previous,note_SHA256=r['note_SHA256']))
assert pages==list(range(1,44)) and sha(prep['source']['path'])==prep['source']['SHA256']
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACTUALLY READ — all 43 physical pages in 22 sequential complete-text/image displays',source=prep['source'],arXiv='2601.04972v1',version='8 January 2026',physical_pages=pages,actual_pages=43,matching_displays=22,receipts=receipts,current_primary_metadata_SHA256=sha(G/'current_arXiv_metadata_v1_20261009.json'),whole_primary_text_read=True,recursive_imported_proofs_cleared=False,main_results_for_book_import='UNVERIFIED',original_results_promoted=[],independent_production_verifier_receipt=None,book_changed=False,native_editor_changed=False,canonical_status_changes=[],whole_book_new_reading_claim=False,helper_source=__file__,helper_SHA256=sha(__file__))
checkpoint.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
shift=[];mass=[];negative=[]
for d in range(1,9):
    for c in range(1,6):
        actual=Fraction(c);printed=Fraction(c,d+1)
        assert actual!=printed
        shift.append(dict(d=d,c=c,point_height=str(actual),mixed_over_degree=str(actual),printed_mixed_over_dimension_degree=str(printed)))
    mass.append(dict(d=d,restriction_to_original_base=str(Fraction(1,d+1)),correct_unit_mass=str(Fraction(1))))
for c in range(1,6):
    for eps in [Fraction(1,4),Fraction(1,2),Fraction(3,4)]:
        fibre_height=-Fraction(c);cutoff=(1-eps)*fibre_height
        assert fibre_height<cutoff
        negative.append(dict(c=c,epsilon=str(eps),fibre_height=str(fibre_height),torsion_height=str(fibre_height),printed_strict_cutoff=str(cutoff),dense_torsion_included=True))
a,b,t,x,y,s=sp.symbols('a b t x y s')
tuples=[[a,b],[a,b,a+b],[a*b,a+b,1],[a*a+b+1,a+b*b-1],[a-1,b-1],[a*a+b*b,a*b+1]]
for n in range(1,5):
    tuples.extend([[a**n+b**n,1],[a**n,b**n],[a**n+b,a+b**n+1],[(a+b)*(a**n+1),(a+b)*(b**n+1)]])
samples=[]
for polynomials in tuples:
    polys=[sp.Poly(p,a,b,domain=sp.QQ) for p in polynomials]
    common=polys[0]
    for p in polys[1:]:common=sp.gcd(common,p)
    expected=max(p.total_degree() for p in polys)-common.total_degree()
    heights=[]
    for subs,domain in [({a:t,b:x*t+y},sp.QQ.frac_field(x,y)),({a:t,b:s*t+x},sp.QQ.frac_field(s,x))]:
        line=[sp.Poly(sp.expand(p.as_expr().subs(subs)),t,domain=domain) for p in polys]
        gcd=line[0]
        for p in line[1:]:gcd=sp.gcd(gcd,p)
        height=int(max(p.degree() for p in line)-gcd.degree());assert height==expected
        heights.append(height)
    samples.append(dict(tuple=[str(p) for p in polynomials],base_P2_hyperplane_height=int(expected),slope_extension_height=heights[0],intercept_extension_height=heights[1]))
discriminant_slope=sp.expand((b-x*a).subs({a:t,b:x*t+y}))
discriminant_intercept=sp.expand((b-x*a).subs({a:t,b:s*t+x}))
assert discriminant_slope==y and discriminant_intercept==(s-x)*t+x
assert sp.Poly(discriminant_slope,t).degree()==0 and sp.Poly(discriminant_intercept,t).degree()==1
data=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — exact classical-model and symbolic calibration; not an independent theorem verdict',source_checkpoint_SHA256=sha(checkpoint),source_PDF_SHA256=prep['source']['SHA256'],constant_shift=dict(locator='Theorem 2.3.6, pp13–14',test='M pulled back from a base line of height c; h_L(X)=0; projection formula gives L^d M=c deg_L X',samples=shift,scope='Generic canonical torsion net supplies hypotheses; no diagnosis attributed to unread Sedillot source'),canonical_GVF_mass=dict(locator='Remark2.3.3 and Definition2.3.5, p13',samples=mass,direct_d1_plus_d2_equal_2_base_scale='1/3',iterated_d1_d2_equal_1_base_scale='1/4',corrected_both='1'),negative_fibre_height=dict(locator='Corollary2.6.11/Theorem6, pp5,20–21',model='E times P1; canonical L_E plus pulled-back canonical O(1) shifted by -c; pairing is 2 deg(L_E) O(1), big; infinitely many root-of-unity base points have fibre height -c',samples=negative,proper_closed_base_cannot_remove_all_roots_of_unity=True),zero_endpoint=dict(locator='Theorem4 p4 versus strict Conjecture4.2.3 pp27–28',model='Constant genus-two curve in its Jacobian over a trivial-height algebraically closed characteristic-zero GVF',finite_stabilizer=True,difference_generates_Jacobian=True,h_G=0,all_point_heights=0,printed_le_cutoff_includes_dense_all_points=True,strict_lt_cutoff_includes_no_points=True,BCSA_refutation_claim=False),unrestricted_ultraproduct=dict(locator='Definition2.4.3 p14',model='Mi=Q with height i times ordinary height',height_of_one=0,height_of_one_plus_one='i log(2), unbounded',bounded_height_sequences_not_closed_under_addition=True,common_base_uniform_error_condition_avoids_test=True),zero_height_uniqueness=dict(locator='Lemma5.4.2 pp33–34',status='UNVERIFIED adversarial construction with exact finite symbolic checks',base='K0=k(a,b), k=Qbar with trivial height; hyperplane P2 height',slope_field='k(x,y)(t); a=t, b=xt+y; x,y constant',intercept_field='k(s,x)(t); a=t, b=st+x; s,x constant',same_abstract_extension='K0(x)',all_tuple_derivation='Cancel the common divisor; a generic line avoids the remaining finite base locus, including infinity, and has the same maximum total degree. Hence restrictions equal on every projective tuple, beyond the finite diagnostics.',samples=samples,discriminator='b-xa',slope_discriminator=str(discriminant_slope),slope_height=0,intercept_discriminator=str(discriminant_intercept),intercept_height=1,height_of_x_both=0,algebraically_closed_base_derivation='Pure transcendental extension is linearly disjoint from K0alg. Symmetric height on its compositum restricts Galois-invariantly to K0alg, hence agrees with the symmetric base height. Algebraic extensions preserve the displayed heights.',local_Gauss_leap_test='In slope model x-b/a=-y/a has order 1 at a=infinity while b/a has order 0.',accepted_counterexample=False,independent_verifier_receipt=None),finite_symbolic_checks_do_not_prove_universal_theorems=True,main_BCSA_and_strict_gap_results='UNVERIFIED for book import',original_results_promoted=[],canonical_status_changes=[],book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__))
calibration.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(actual_pages=43,actual_views=22,checkpoint_SHA256=sha(checkpoint),calibration_SHA256=sha(calibration),constant_shift_samples=len(shift),negative_height_samples=len(negative),generic_line_tuple_samples=len(samples))))
