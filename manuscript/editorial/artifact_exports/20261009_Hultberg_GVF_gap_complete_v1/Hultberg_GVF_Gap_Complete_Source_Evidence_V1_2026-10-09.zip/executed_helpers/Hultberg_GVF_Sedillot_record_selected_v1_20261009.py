from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sys
D=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Hultberg_GVF_dependency_review_20261009/Sedillot23ArxivV2')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prep=json.loads((D/'scope_preparation_v1_20261009.json').read_text());n=int(sys.argv[1]);v=prep['views'][n-1]
assert v['number']==n and sha(D/'Sedillot_relative_chi_volume_2303_03377v2.pdf')==prep['source_PDF_SHA256']
assert sha(v['image_path'])==v['image_SHA256'] and sha(v['selected_text_path'])==v['selected_text_SHA256']
note=D/f'selected_notes_v1/note_{n:02d}.md';out=note.with_name(f'note_{n:02d}_receipt.json')
assert note.exists() and len(note.read_text())>300 and not out.exists()
previous=note.with_name(f'note_{n-1:02d}_receipt.json') if n>1 else None
if previous:assert previous.exists()
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACTUALLY READ — complete selected text and displayed matching image',source_PDF_SHA256=prep['source_PDF_SHA256'],number=n,physical_pages=v['physical_pages'],note_SHA256=sha(note),image_SHA256=v['image_SHA256'],selected_text_SHA256=v['selected_text_SHA256'],previous_receipt_SHA256=sha(previous) if previous else None,whole_source_read=False,recursive_proofs_verified=False,independent_production_receipt=None,book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(obj,indent=2)+'\n');print(json.dumps(dict(number=n,physical_pages=v['physical_pages'],receipt_SHA256=sha(out))))
