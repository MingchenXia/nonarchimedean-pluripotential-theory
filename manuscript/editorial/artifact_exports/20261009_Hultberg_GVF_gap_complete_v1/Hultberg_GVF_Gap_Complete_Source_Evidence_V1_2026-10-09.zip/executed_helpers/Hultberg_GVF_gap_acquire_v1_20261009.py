from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,urllib.request,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Xue_semiabelian_review_20261009/dependencies_v1/Hultberg26GapArxivV1'
assert not C.exists();C.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
url='https://arxiv.org/pdf/2601.04972v1'
req=urllib.request.Request(url,headers={'User-Agent':'Book primary-source audit/1.0'})
with urllib.request.urlopen(req,timeout=60) as response:
    payload=response.read();resolved=response.url;ctype=response.headers.get('Content-Type')
assert payload.startswith(b'%PDF')
pdf=C/'Hultberg_GVF_gap_principle_2601_04972v1.pdf';pdf.write_bytes(payload)
with fitz.open(pdf) as doc:
    count=len(doc);text='\n\n'.join('HULTBERG GVF GAP ARXIV V1 PHYSICAL PAGE '+str(i+1)+'\n'+page.get_text() for i,page in enumerate(doc))
tp=C/'Hultberg_GVF_gap_v1_preparation_text.txt';tp.write_text(text)
out=C/'source_acquisition_v1_20261009.json'
out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACQUIRED AND MECHANICALLY EXTRACTED — zero actual reading credit',title='New gap principle for semiabelian varieties using globally valued fields',author='Nuno Hultberg',arXiv='2601.04972v1',version='8 January 2026',source_URL=url,resolved_URL=resolved,content_type=ctype,source=dict(path=str(pdf),SHA256=sha(pdf),bytes=pdf.stat().st_size,physical_pages=count),prepared_text=dict(path=str(tp),SHA256=sha(tp)),actual_pages=[],actual_primary_reading_credit=0,book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='ACQUIRED',pages=count,bytes=pdf.stat().st_size,SHA256=sha(pdf),record_SHA256=sha(out))))
