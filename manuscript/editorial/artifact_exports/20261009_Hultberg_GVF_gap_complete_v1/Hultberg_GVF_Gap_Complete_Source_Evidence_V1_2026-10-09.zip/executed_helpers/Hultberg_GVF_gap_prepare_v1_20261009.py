from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,fitz
from PIL import Image,ImageDraw
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Xue_semiabelian_review_20261009/dependencies_v1/Hultberg26GapArxivV1'
W=Path('/tmp/Xue_semiabelian_dependency_views_v1_20261009/Hultberg26GapArxivV1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
acq=json.loads((C/'source_acquisition_v1_20261009.json').read_text());src=acq['source']
assert sha(src['path'])==src['SHA256']
out=C/'source_preparation_v1_20261009.json';notes=C/'primary_notes_v1'
assert not any(p.exists() for p in [out,W,notes]);W.mkdir();notes.mkdir();views=[]
with fitz.open(src['path']) as doc:
    assert len(doc)==src['physical_pages']==43
    for i in range(0,len(doc),2):
        pages=list(range(i+1,min(i+3,len(doc)+1)));panels=[];texts=[]
        for n in pages:
            pix=doc[n-1].get_pixmap(matrix=fitz.Matrix(1.2,1.2),alpha=False)
            panels.append(Image.frombytes('RGB',[pix.width,pix.height],pix.samples))
            texts.append(f'HULTBERG ARXIV 2601.04972v1 PHYSICAL PAGE {n}\n'+doc[n-1].get_text())
        canvas=Image.new('RGB',(sum(p.width for p in panels),max(p.height for p in panels)+28),'white')
        draw=ImageDraw.Draw(canvas);left=0
        for n,p in zip(pages,panels):
            draw.text((left+8,8),f'Hultberg GVF gap v1: physical {n}',fill='black');canvas.paste(p,(left,28));left+=p.width
        number=i//2+1;ip=W/f'sheet_{number:02d}.png';tp=W/f'sheet_{number:02d}.txt'
        canvas.save(ip);tp.write_text('\n\n'.join(texts))
        views.append(dict(number=number,physical_pages=pages,path=str(ip),image_SHA256=sha(ip),selected_text_path=str(tp),selected_text_SHA256=sha(tp),source_PDF_SHA256=src['SHA256'],actually_viewed=False,selected_text_read=False))
mp=W/'manifest.json';mp.write_text(json.dumps(views,ensure_ascii=False,indent=2)+'\n')
out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='PREPARED — zero actual reading credit',source=src,prepared_views=len(views),prepared_physical_pages=list(range(1,44)),manifest_path=str(mp),manifest_SHA256=sha(mp),actual_primary_reading_credit=0,book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='PREPARED',pages=43,views=22,record_SHA256=sha(out))))
