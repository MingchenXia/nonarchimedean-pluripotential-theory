from pathlib import Path
from urllib.request import Request,urlopen
from datetime import datetime,timezone
from html.parser import HTMLParser
import hashlib,json,fitz
D=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Hultberg_GVF_dependency_review_20261009/Sedillot23ArxivV2')
assert not D.exists(); D.mkdir(parents=True)
sources=[]
for name,url in [('Sedillot_relative_chi_volume_2303_03377v2.pdf','https://arxiv.org/pdf/2303.03377v2'),('arXiv_current_metadata_v1_20261009.html','https://arxiv.org/abs/2303.03377')]:
    with urlopen(Request(url,headers={'User-Agent':'book-source-check/1.0'}),timeout=45) as r:b=r.read();resolved=r.url;ct=r.headers.get('Content-Type')
    p=D/name; p.write_bytes(b);sources.append(dict(path=str(p),URL=url,resolved_URL=resolved,content_type=ct,bytes=len(b),SHA256=hashlib.sha256(b).hexdigest()))
    if name.endswith('.pdf'):
        assert b.startswith(b'%PDF')
        with fitz.open(p) as doc:
            pages=len(doc);texts=[page.get_text() for page in doc]
        q=D/'source_preparation_text_v1_20261009.txt';q.write_text('\n\f\n'.join(texts))
        sources[-1]['physical_pages']=pages
        matches=[dict(physical_page=i+1,near_proposition5_5=text[max(0,text.find('Proposition 5.5')-600):text.find('Proposition 5.5')+2300]) for i,text in enumerate(texts) if 'Proposition 5.5' in text]
    else:
        class Parser(HTMLParser):
            def __init__(self):super().__init__();self.items=[]
            def handle_data(self,s):
                if s.strip():self.items.append(s.strip())
        parser=Parser();parser.feed(b.decode('utf-8'));metadata='\n'.join(parser.items)
        q=D/'current_metadata_preparation_text_v1_20261009.txt';q.write_text(metadata)
record=dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACQUIRED AND MECHANICALLY PREPARED — no actual full-proof reading',sources=sources,source_version_pinned='2303.03377v2',prepared_locator_hits=matches,actual_primary_pages=[],book_changed=False,helper_source=__file__,helper_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
p=D/'source_acquisition_v1_20261009.json';p.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(sources=sources,mechanical_locator_hits=matches),ensure_ascii=False))
start=metadata.find('Title:');end=metadata.find('Submission history');print(metadata[start:end+900])
