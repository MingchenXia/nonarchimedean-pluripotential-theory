# Actual selected Sedillot v2 reading 03: physical p41

Read the entire page text and matching single-page image, including the
complete endings of Lemma5.7/Theorem5.3 and all beginning bibliography
entries. Lemma5.7 shifts only ARCHIMEDEAN metrics and divides by nu(Omega_ar).
That specific proof requires positive archimedean mass; if it vanishes,
normalization needs a different integrable constant-metric family of nonzero
mean, if permitted, rather than this division by zero. This is a separate
literal proof qualification, not a defect in Proposition5.5's coefficient.
Theorem5.3's ending uses the correct mixed formula and truncated log lower
bound. The earlier beginnings of the differentiation theorem and deeper
CM/BB proofs remain unread in this selected audit.

Selected scope now totals exactly physical pages37–41, five of43 v2 pages,
in three actual complete-text/image displays. Entire Proposition5.5 and
section5's generic-small/normal/perfect/countable hypotheses are read.
The 38-page March v1 was acquired but has ZERO actual page credit; current
primary metadata lists November2023 v2 as latest, and that v2 matches the
Proposition5.5 locator. No whole-source claim, publication-edition claim,
independent production verdict or book modification.
