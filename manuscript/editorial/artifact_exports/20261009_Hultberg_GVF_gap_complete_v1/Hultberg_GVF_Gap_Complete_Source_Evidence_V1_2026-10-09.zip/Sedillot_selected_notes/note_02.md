# Actual selected Sedillot v2 reading 02: physical pp39–40

Read both complete texts and matching image, including Proposition5.5's
ENTIRE statement and proof across these two pages. With the previously
read generic-small sequence and normal/perfect/countable hypotheses,
lim h_M(x_n)=(L^d M)/vol(L) - d h_L(X)(L^(d-1) M)/vol(L).
When h_L(X)=0 this is (L^d M)/deg_L X, with NO extra d+1 factor.
The proof differentiates chi-volume divided by (d+1)vol, so the
chi-volume derivative's d+1 cancels. This confirms that the Hultberg
Theorem2.3.6 transcription loses genericity and adds the wrong factor;
the factor error is not present in this primary Proposition5.5.

The proof uses maximal-slope lower bounds, concave envelope contact,
Corollary4.8 and imported BB08 differentiation lemma; those deeper proofs
are not recursively verified by reading this proposition. Probability
measures are normalized by geometric volume. Proposition5.6's complete
truncation proof on measurable place subsets is read, retaining the
separate log-integrability and weak/truncated convergence assumptions.
Theorem5.3 and Lemma5.7 begin; their proof continues p41. No full-source
43-page claim, independent receipt or original result promotion.
