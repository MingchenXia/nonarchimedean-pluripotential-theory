# Actual selected Sedillot v2 reading 01: physical pp37–38

Read both complete texts and matching rendered image. End of Theorem4.5
proof is present, but its beginning/deeper domination lemmas are outside
this selected scope. Corollary4.8 and its entire proof are read: the
chi-volume derivative equals (d+1)(L^d M), using relatively ample /
semipositive L and multilinearity. Section5 explicitly fixes a proper
adelic curve, PERFECT COUNTABLE K, geometrically integral NORMAL projective
X, and a GENERIC SMALL sequence of closed points, with normalized point
heights converging to h_L(X). Genericity is not absent in this primary
source. Lemma5.1 and Proposition5.2 give slopes/concave transform comparisons
and homogeneous/superadditive maximal asymptotic slope, with their cited
CM dependencies retained. These are the exact hypotheses carried into
Proposition5.5, whose full statement/proof begins p39. Only pp37–38 are
credited, not whole 43-page v2 or its 38-page v1. No independent verdict.
