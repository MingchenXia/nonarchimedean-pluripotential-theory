from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,re,subprocess,difflib
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Hattori_CY_fibrations_review_20261008';S=Path('/workspace/book-completion-drafts/adiabatic-normalization-staging-v2-20261008');D=Path('/workspace/book-completion-drafts/adiabatic-normalization-integration-v2-20261008')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
release=C/'staged_book_release_checks_v2_20261008.json';ch=json.loads(release.read_text());manifest=Path(ch['manifest_path']);assert sha(manifest)==ch['manifest_SHA256'];xs=json.loads(manifest.read_text());views=[]
last=None
for x in xs:
 assert not x['actually_viewed'] and not x['selected_text_read']
 n=C/'staged_book_notes_v2'/f"note_{x['number']:02d}.md";r=n.with_name(n.stem+'_receipt.json');receipt=json.loads(r.read_text());assert 'Read the complete selected text and displayed matching rendered image' in n.read_text()
 assert receipt['complete_selected_text_actually_read'] and receipt['matching_image_individually_displayed_and_reviewed'] and receipt['number']==x['number'] and receipt['physical_pages']==x['physical_pages']
 assert sha(n)==receipt['note_SHA256'] and sha(x['path'])==receipt['image_SHA256']==x['image_SHA256'] and sha(x['selected_text_path'])==receipt['selected_text_SHA256']==x['selected_text_SHA256']
 assert last is None or receipt['UTC']>last;last=receipt['UTC'];y={k:v for k,v in x.items() if k not in ['actually_viewed','selected_text_read']};y.update(inspection_mode='Fresh complete-text read and individual matching-image display',actual_complete_text_read=True,actual_matching_image_freshly_displayed=True,sequential_note_path=str(n),sequential_note_SHA256=sha(n),observation_receipt_path=str(r),observation_receipt_SHA256=sha(r));views.append(y)
pages=sorted({p for x in xs for p in x['physical_pages']});assert pages==ch['selected_book_physical_pages'] and sum(len(x['physical_pages']) for x in xs)==len(pages)
reading=C/'actual_staged_book_reading_v2_20261008.json';audit=C/'staged_mathematical_self_audit_v2_20261008.json';post=C/'post_render_checks_v2_20261008.json';assert not any(q.exists() for q in (reading,audit,post))
prep=json.loads((C/'staging_preparation_v2_20261008.json').read_text());checks=[]
for command in (['python3','editorial/tools/refcheck.py'],['python3','editorial/tools/check_open_problem_inventory.py']):
 run=subprocess.run(command,cwd=S/'manuscript',text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);assert run.returncode==0,run.stdout;checks.append({'command':command,'returncode':run.returncode,'output':run.stdout})
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['other_active_TeX_preserved'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h
historical={};whitespace={}
for n in ('manuscript/parts/part5/ch62_k_stability_kahler.tex','manuscript/appendices/appL_provenance.tex'):
 before=(R/n).read_text();after=(S/n).read_text();counts={}
 for env in ('theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important'):
  patt=r'\\begin\{'+env+r'\}.*?\\end\{'+env+r'\}';blocks=re.findall(patt,before,re.S);assert all(b in after for b in blocks) and len(blocks)==len(re.findall(patt,after,re.S));counts[env]=len(blocks)
 tags=re.findall(r'\\tag\{([^}]+)\}',before);ntags=re.findall(r'\\tag\{([^}]+)\}',after);assert all(ntags.count(t)>=tags.count(t) for t in tags);historical[n]={'byte_preserved_environment_blocks':counts,'prior_manual_equation_tags':tags}
for n in prep['after']:
 before=(R/n).read_text().splitlines();after=(S/n).read_text().splitlines();wb=Counter(x for x in before if x!=x.rstrip());wa=Counter(x for x in after if x!=x.rstrip());assert wb==wa
 added=[x[2:] for x in difflib.ndiff(before,after) if x.startswith('+ ')];assert all(x==x.rstrip() for x in added);whitespace[n]={'historical_whitespace_lines_preserved':sum(wb.values()),'added_lines_checked':len(added),'added_trailing_whitespace_lines':0}
for q,h in prep['draft_fragments'].items():assert sha(q)==h and all(x==x.rstrip() for x in Path(q).read_text().splitlines())
reading.write_text(json.dumps({'UTC':datetime.now(timezone.utc).isoformat(),'status':'DONE — all selected pages freshly read and individually displayed; no remaining repairs','PDF':ch['PDF'],'actual_unique_book_pages':len(pages),'fresh_complete_text_and_individually_displayed_pages':len(pages),'fresh_matching_views':len(views),'reused_exact_complete_text_and_rendered_pixel_pages':0,'reused_matching_views':0,'views':views,'legacy_preparation_flags_rewritten':False,'remaining_repairs':[],'whole_book_new_reading_claim':False,'active_book_changed':False,'GitHub_published':False,'canonical_status_changes':[]},ensure_ascii=False,indent=2)+'\n')
mathchecks=[
 'Hats distinguish source probability/volume normalization from the chapter model DF and J, which retain V. Raw DF scales by lambda^d and raw J by lambda^(d+1); normalized DF is invariant and normalized J linear. Six exact dimensional checks vanish.',
 'The comparison is restricted to normal semiample projective configurations with a base twist making the compactification nef. Ordinary intersections therefore agree with the chapter positive products. This imports no invariance for arbitrary big nonnef classes.',
 'Boundary zero is explicit for comparison with chapter raw DF; the appendix source entropy may use a fixed klt boundary. Polarization rescaling holds the pair fixed and is distinct from normalized base change, where Mabuchi scales exactly while DF can decrease.',
 'A_epsilon=epsilon P_(1/epsilon) gives DF_hat(P_k)>=delta/k J_hat(P_k). Multiplying both sides by the same V(P_k) gives the raw inequality. One positive constant and one threshold precede both universal quantifiers; comparing norms requires constants independent of k.',
 'The projective tautological class need only be relatively ample. A fixed large shift k0 makes A globally ample and replaces the large parameter by k+k0.',
 'The source main equivalence requires a klt-trivial fibration over a smooth curve. A positive-dimensional projective-space fiber with boundary zero has O(-r) canonical bundle and fails that hypothesis; no CY-fibration existence theorem is applied to the projective bundles.',
 'The source arXiv v2 was fully read in 44 actual pages, 22 individually displayed matching images and sequential notes. Journal metadata is checked, but the publisher-linked PDF returned HTML. Defect observations are explicitly confined to v2, not unread journal text.',
 'The entropy/threshold argument assumes the external criterion. delta(rP)=delta(P)/r gives H_hat(P)>=r N_hat(P) for rational r below delta(P); taking its limit gives the intended coefficient without the printed inconsistent normalization.',
 'On a curve base F^2=0 yields the exact d(1-x) epsilon^(d-1)a+epsilon^d b polynomial and its d/2 integral. The source tail bound remains assumed; correcting the factor recovers the local ratio limit but is not a proof of general alpha/delta convergence.',
 'The finite-basis factor correction is an algebraic implication diagnostic. Its exact numeric fixture is not claimed to arise from an actual valuation or variety.',
 'The blowup intersection matrix has S^2=F^2=0, SF=1, E0^2=-1, F=E0+Gamma. A=2S+2F-E0 has square 7 and positive intersection with every curve via m<=u+v; Nakai-Moishezon is an attributed foundation.',
 'The two chosen horizontal curves pass transversely through P on Gamma away from E0 and avoid the blowup center. D_hor+D_vert is Q-linearly equivalent to F+epsilon A. Its Gamma intersections are 2epsilon and -epsilon, whereas epsilon A.Gamma=epsilon. It refutes one discarded-vertical equality, not the lemma or main theorem; the complete-fiber budget remains 2epsilon.',
 'Canonical bundle/moduli, MMP, singularity, filtered section algebra, and analytic existence imports remain attributed and not recursively certified. No original general result, independent-model receipt or whole-book new reading is claimed.',
 'All prior formal assertions, proofs, warnings, important blocks and manual tags are byte-preserved. Only supplementary tag 62.14f and a final provenance section are added. All preceding number/citation values and 423 other TeX inputs are preserved.',
 'The 42 atoms and 12 formal problems retain their status; general BJ22 critical homogeneous Siu and envelopes remain OPEN, and LPWZ density UNVERIFIED. The native editor/catalogue remain unchanged.'
]
audit.write_text(json.dumps({'UTC':datetime.now(timezone.utc).isoformat(),'status':'DONE — ordinary mathematical self-audit and final scoped rendered clearance','checks':mathchecks,'source_input_hashes':prep['after'],'draft_fragments':prep['draft_fragments'],'actual_final_book_reading_SHA256':sha(reading),'actual_final_book_reading_credit':len(pages),'whole_book_new_reading_claim':False,'source_scope':'Hattori 2203.11460v2, all 44 actual primary pages in 22 individual matching images; journal proof text unread and recursive external proofs qualified','exact_diagnostics_SHA256':sha(C/'exact_diagnostics_v1_20261008.json'),'normalization_diagnostic_v2_SHA256':sha(C/'normalization_diagnostic_v2_20261008.json'),'original_results_promoted':[],'independent_model_receipt':None,'canonical_status_changes':[],'helper_source':__file__},ensure_ascii=False,indent=2)+'\n')
post.write_text(json.dumps({'UTC':datetime.now(timezone.utc).isoformat(),'status':'DONE','checks':checks,'source_input_hashes':prep['after'],'rendered_gate_SHA256':sha(reading),'historical_formal_proof_warning_important_blocks_byte_preserved':historical,'other_active_TeX_inputs_byte_preserved':423,'whitespace_gate':'PASS — added lines clean and historical whitespace multiplicities preserved','whitespace_details':whitespace,'legacy_writing_audit_unavailable':True,'manual_semantic_delimiter_source_and_rendered_audits_used':True,'active_book_changed':False,'GitHub_published':False,'canonical_status_changes':[]},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'DONE','actual_reading_SHA256':sha(reading),'math_audit_SHA256':sha(audit),'post_render_SHA256':sha(post),'actual_pages':len(pages),'fresh_views':len(views)}))
