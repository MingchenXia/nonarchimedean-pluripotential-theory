from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,re,subprocess
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Hattori_CY_fibrations_review_20261008';B=Path('/workspace/book-completion-drafts/adiabatic-bundles-staging-v2-20261008');S=Path('/workspace/book-completion-drafts/adiabatic-normalization-staging-v2-20261008');D=Path('/workspace/book-completion-drafts/adiabatic-normalization-integration-v2-20261008');out=C/'staging_preparation_v2_20261008.json'
assert not out.exists() and not S.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cp=C/'source_checkpoint_v1_20261008.json';p=json.loads(cp.read_text());assert sha(cp)=='aeb449585ea3126087f3eb4584485106d6c24c2426d48072b9d96c8bad1d1375'
for n,h in p['protected_core_inputs'].items():assert sha(Path(n))==h
v1=C/'staged_book_validation_v1_20261008.json';assert sha(v1)=='04b73f4a4f604fd6d3b0aa3a3dbc1a7c212e4d509d1d53955ff76376861786d3'
frozen=json.loads((C/'staging_preparation_v1_20261008.json').read_text())
for n,h in frozen['after'].items():assert sha(Path(frozen['stage_path'])/n)==h
for n,h in frozen['draft_fragments'].items():assert sha(Path(n))==h
shutil.copytree(B,S,ignore=shutil.ignore_patterns('*.pdf','*.aux','*.log','*.fls','*.fdb_latexmk','*.bbl','*.blg','*.toc','*.out','*.idx','*.ind','*.ilg','__pycache__'))
changed=[Path('manuscript/parts/part5/ch62_k_stability_kahler.tex'),Path('manuscript/appendices/appL_provenance.tex'),Path('manuscript/bibliography/ComplexGeometry.bib')];before={str(n):sha(S/n) for n in changed};assert all(sha(R/n)==h for n,h in before.items())
z=S/changed[0];t=z.read_text();marker='The surface calculation in\n\\Cref{sec:appL-adiabatic-bundles-boundary}';assert t.count(marker)==1;z.write_text(t.replace(marker,(D/'ch62_normalization_fragment.tex').read_text()+marker,1))
z=S/changed[1];z.write_text(z.read_text()+(D/'appL_normalization_fragment.tex').read_text())
z=S/changed[2];z.write_text(z.read_text()+(D/'normalization_bibliography_fragment.bib').read_text());keys=['Hattori23CalabiYauV2'];assert z.read_text().count('@misc{'+keys[0]+',')==1
tex={str(Path(n).relative_to(R)):h for n,h in p['protected_core_inputs'].items() if Path(n).is_relative_to(R/'manuscript') and Path(n).suffix=='.tex'};assert len(tex)==425;unchanged={n:h for n,h in tex.items() if Path(n) not in changed}
for n,h in unchanged.items():assert sha(R/n)==sha(S/n)==h
assert sha(S/'manuscript/bibliography/NonArchimedean.bib')==sha(R/'manuscript/bibliography/NonArchimedean.bib')
formal=[]
for n in changed[:2]:
 old=(R/n).read_text();new=(S/n).read_text();envs=['theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important'];starts=re.findall(r'\\begin\{('+('|'.join(envs))+r')\}',old);assert starts==re.findall(r'\\begin\{('+('|'.join(envs))+r')\}',new)
 for env in envs:assert all(block in new for block in re.findall(r'\\begin\{'+env+r'\}.*?\\end\{'+env+r'\}',old,re.S))
 tags=re.findall(r'\\tag\{([^}]+)\}',old);newtags=re.findall(r'\\tag\{([^}]+)\}',new);assert all(x in newtags for x in tags);formal.append({'path':str(n),'historical_formal_starts':len(starts),'historical_proofs':starts.count('proof'),'historical_manual_tags':len(tags),'new_manual_tags':[x for x in newtags if x not in tags]})
assert formal[0]['new_manual_tags']==['62.14f'] and not formal[1]['new_manual_tags']
for rel in ['README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']:
 shutil.copy2(R/rel,S/rel)
for rel in p['editorial_files']:
 q=Path(rel);target=S/q.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(q,target)
obj={'UTC':datetime.now(timezone.utc).isoformat(),'status':'DONE — explicit raw/source-normalized notation repair in isolated v2','stage_path':str(S),'baseline_stage_path':str(B),'baseline_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'draft_path':str(D),'before':before,'after':{str(n):sha(S/n) for n in changed},'draft_fragments':{str(z):sha(z) for z in sorted(D.iterdir())},'active_inputs_preserved':{str(n):sha(R/n) for n in changed},'other_active_TeX_preserved':unchanged,'unchanged_bibliography':{'path':'manuscript/bibliography/NonArchimedean.bib','SHA256':sha(R/'manuscript/bibliography/NonArchimedean.bib')},'historical_formal_blocks_preserved':formal,'active_book_PDF_SHA256':sha(R/'manuscript/book.pdf'),'native_catalogue_preserved':{str(Path(n).relative_to(R)):h for n,h in p['protected_core_inputs'].items() if Path(n).is_relative_to(R/'output')},'source_checkpoint_SHA256':sha(cp),'actual_primary_reading_SHA256':sha(C/'actual_primary_reading_v1_20261008.json'),'exact_diagnostics_SHA256':sha(C/'exact_diagnostics_v1_20261008.json'),'normalization_diagnostic_v2_SHA256':sha(C/'normalization_diagnostic_v2_20261008.json'),'frozen_v1_validation_SHA256':sha(v1),'repair_reason':'Chapter model DF and J retain V, whereas source functionals divide by V; hats and nef compactification specify the comparison.','new_bibliographic_keys':keys,'new_formal_environments':0,'original_results_promoted':[],'independent_model_receipt':None,'canonical_status_changes':[],'active_book_changed':False,'GitHub_published':False,'actual_book_reading_credit':0,'helper_source':__file__}
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
template=Path('/tmp/Hattori_CY_fibrations_validate_staged_book_v1_20261008.py');dst=Path('/tmp/Hattori_CY_fibrations_validate_staged_book_v2_20261008.py');assert not dst.exists();t=template.read_text().replace('adiabatic-normalization-staging-v1-20261008','adiabatic-normalization-staging-v2-20261008').replace('v1_20261008','v2_20261008').replace('compiled_staged_v1','compiled_staged_v2');dst.write_text('# Frozen preceding template SHA256: '+sha(template)+'\n'+t)
print(json.dumps({'status':obj['status'],'SHA256':sha(out),'other_TeX':len(unchanged),'historical':formal}))
