from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,zipfile,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Hattori_CY_fibrations_review_20261008';S=Path('/workspace/book-completion-drafts/adiabatic-normalization-staging-v2-20261008');E=R/'manuscript/editorial';O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
prep=load('staging_preparation_v2_20261008.json');release=load('staged_book_release_checks_v2_20261008.json');reading=load('actual_staged_book_reading_v2_20261008.json');post=load('post_render_checks_v2_20261008.json');math=load('staged_mathematical_self_audit_v2_20261008.json');underfull=load('staged_underfull_delta_v2_20261008.json')
assert reading['status'].startswith('DONE') and not reading['remaining_repairs'] and not underfull['added_blocks']
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
np=release['PDF']['physical_pages'];nb=reading['actual_unique_book_pages'];nv=reading['fresh_matching_views'];assert (np,nb,nv)==(4634,24,12)
full=O/'Non-Archimedean_Pluripotential_Theory_Hattori_Normalization_Staged_Preview_2026-10-08.pdf';review=O/'Hattori_Normalization_Staged_Book_Review_2026-10-08.pdf';minimal=O/'Hattori_Normalization_Staged_Minimal_Source_2026-10-08.zip';evidence=O/'Hattori_Normalization_Actual_Book_Evidence_2026-10-08.zip';record=C/'staged_export_v2_20261008.json'
paths={k:E/f'Hattori_CY_fibrations_staged_integration_{k}_20261008.{ext}' for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]};assert not any(p.exists() for p in [full,review,minimal,evidence,record,*paths.values()])
shutil.copy2(release['PDF']['path'],full);assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as book:
 doc=fitz.open()
 for n in release['selected_book_physical_pages']:doc.insert_pdf(book,from_page=n-1,to_page=n-1)
 assert len(doc)==nb;doc.set_metadata({'title':'Adiabatic normalization and horizontal divisors — book review, 8 October 2026','subject':'24 actually reviewed pages; export adds no reading credit.'});doc.save(review,garbage=4,deflate=True);doc.close()
paths['audit'].write_text(f'''# Adiabatic normalization and horizontal divisors: integration audit, 8 October 2026

The validated staged edition has {np:,} pages. Section 62.3.4 and new L.92 distinguish Hattori's volume-normalized functionals, denoted with hats, from the chapter's model invariants retaining V. On normal semiample projective configurations with a nef compactification, raw DF scales by lambda^d and raw J by lambda^(d+1), while normalized DF is invariant and normalized J linear. Exact checks in dimensions one through six have zero residuals. A_epsilon=epsilon P_(1/epsilon) makes the uniform adiabatic inequality exactly DF_hat(P_k)>=delta/k J_hat(P_k), with one constant and threshold before both universal quantifiers. Dividing or multiplying both sides by the same generic volume preserves that inequality. The fixed ample shift and k-independent norm comparisons remain explicit. The preceding conditional O(k^-2) ratio argument is unchanged.

The source main equivalence concerns klt-trivial fibrations over smooth curves. Boundary-zero positive-dimensional projective-space fibers fail that canonical-bundle hypothesis; no CY-fibration cscK theorem is applied to projective bundles. All 44 pages of arXiv:2203.11460v2, updated 9 August 2023, were actually read in 22 individually displayed matching images with sequential notes. Journal metadata is verified, but the publisher-linked PDF returned HTML, so no journal proof text was read. Defect observations apply only to the pinned v2; the general stability/cscK equivalence and recursive external proof dependencies remain qualified.

L.92 records a conditional entropy/threshold scaling argument with the correct normalized units, the corrected d/2 curve-volume integral and the finite-basis reciprocal-factor boundary. The tail and threshold criteria remain assumptions. A worked blowup of P1 x P1 has A=2S+2F-E0, A²=7, F=E0+Gamma, D_hor=epsilon(C1+C2) and D_vert=F+epsilon Gamma. Their Gamma intersections are 2epsilon and -epsilon, while epsilon A.Gamma=epsilon. This refutes the discarded-vertical equality in one printed proof; it is not a counterexample to Lemma 4.8 or the main theorem. The complete-fiber horizontal budget is still 2epsilon. Nakai–Moishezon and the source's canonical-bundle/moduli, MMP, singularity, section-algebra and analytic inputs remain attributed foundations rather than recursively certified proofs.

The v1 mechanical build is preserved without book-reading clearance. The raw/normalized notation clash was repaired in an isolated v2. The final scoped gate freshly reads all {nb} selected pages in {nv} individually displayed matching images, including the new contents row, full new text and neighboring seams, complete index, intentional blank versos and complete Hat23A entry. Every display has a sequential note and observation receipt; preparation flags stay false. This is not a new whole-book reading; the complete ordered 4 October pass remains the latest.

Required validation, the six existing reference-checker regression tests, full reference closure and canonical inventory pass. Post-render reference/inventory and whitespace checks pass. Final logs have zero errors, LaTeX/package/pdfTeX warnings, missing glyphs, overfull boxes, undefined references/citations or rerun requests. All 955 underfull diagnostic blocks are inherited with identical normalized text and multiplicities. All {release['all_prior_numbered_label_values_preserved']:,} prior number values and {release['bibliography']['prior_labels_preserved']} prior citation labels are preserved. Two semantic labels, supplementary tag 62.14f, one L.92 contents row, one cited reference [Hat23A] and two index terms are added. The index accepts {release['index']['accepted']} entries without rejections or warnings. All {release['navigation']['internal_links']:,} internal links pass; external URL health is not claimed. The other 423 TeX inputs, NA bibliography, historical formal/proof/warning/important blocks and equation tags are byte-preserved. The legacy writing-audit command is unavailable; direct semantic, notation, delimiter, source, whitespace and rendered checks are recorded.

The 42 canonical atoms and twelve formal problems retain their statuses. General BJ22 critical homogeneous Siu division and envelopes remain OPEN, and LPWZ density UNVERIFIED. No original general theorem or independent-model receipt is introduced. The native catalogue/editor stay preserved. User authorization for GitHub evidence uploads persists; the source/audit checkpoint was uploaded in commit 4763902f77d284ccdf9b81dd0205be5e9945be26 and its remote blobs verified. These frozen staging records claim neither activation nor publication of the new book unit; separate records control those steps. Export gives zero additional reading credit.
''')
paths['reading_notes'].write_text('# Final scoped rendered-book notes, 8 October 2026\n\n24 fresh pages in twelve individually displayed matching images. Frozen v1 build and preparation flags remain unchanged.\n'+''.join('\n---\n\n'+Path(v['sequential_note_path']).read_text() for v in reading['views']))
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md';prog=(R/programme).read_text();marker='## Latest Hattori primary-source checkpoint, 8 October 2026\n';assert prog.count(marker)==1
header=f'''## Latest Hattori normalization cloud integration checkpoint, 8 October 2026

The current validated cloud edition has {np:,} pages. The
[integration audit](Hattori_CY_fibrations_staged_integration_audit_20261008.md)
records the added dictionary in 62.3.4 and new L.92. Hats distinguish
volume-normalized source functions from chapter model invariants retaining V;
a nef compactification specifies their intersection comparison. The common
adiabatic delta/k condition, fixed ample shift and norm-comparison quantifiers
are explicit. The klt-trivial curve theorem does not apply to boundary-zero
positive-dimensional projective-space fibers.

The complete arXiv v2 has 44 actual pages in 22 individual matching displays.
The journal proof text remains unread and the source equivalence qualified.
Local entropy/volume corrections and the reducible-fiber example target
specific printed proof steps; no lemma/main-theorem counterexample or new
original general theorem is claimed. All 24 selected book pages were freshly
read in twelve individual matching displays with sequential notes/receipts.
The full added text, seams, contents row, index and Hat23A entry pass.
Required mechanical and post-render checks pass: no errors, warnings, missing
glyphs, overfull boxes or unresolved references/links. All 955 underfull cases
are inherited identically. All 13,369 prior number values and 590 citation
labels remain; two labels, one citation, one contents row and two index terms
are added. Other 423 TeX inputs and historical formal/proof blocks stay intact.

The 42 atoms/twelve formal problems retain status: general BJ22 critical
homogeneous Siu/envelopes OPEN; LPWZ density UNVERIFIED. The native editor
and catalogue are unchanged. The 4 October ordered pass remains the latest
complete whole-book reading. Source records are already uploaded and remotely
verified. New book exports are byte-verified; the
[activation record](Hattori_CY_fibrations_cloud_activation_20261008.json)
controls their cloud update. Publication of this book unit is recorded
separately after its authorized GitHub upload. Continue related primary
research and regular author-update checks.

''';(S/programme).write_text(prog.replace(marker,header+marker))
readme=(R/'README.md').read_text();assert readme.count('**4,632 pages**')==1;readme=readme.replace('**4,632 pages**','**4,634 pages**');marker='**Latest primary-source continuation, 8 October 2026:**';assert readme.count(marker)==1
intro=f'''**Latest checked book integration, 8 October 2026:** the
[Hattori normalization audit](manuscript/editorial/Hattori_CY_fibrations_staged_integration_audit_20261008.md)
adds the explicit raw/volume-normalized dictionary in 62.3.4 and L.92.
The delta/k condition retains common quantifiers; the reducible-fiber example
identifies one incorrect printed intersection equality without refuting the
lemma or main equivalence. Journal proof text remains unread. All 24 selected
book pages were freshly read in twelve matching displays; mechanical and
post-render checks pass. The [activation record](manuscript/editorial/Hattori_CY_fibrations_cloud_activation_20261008.json)
controls the new 4,634-page cloud edition. Upload of this book unit is recorded
separately. No original general theorem or canonical status change is claimed.

''';(S/'README.md').write_text(readme.replace(marker,intro+marker))
oldzip=O/'Adiabatic_Bundles_Staged_Minimal_Source_2026-10-08.zip'
with zipfile.ZipFile(oldzip) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 assert len(old.namelist())==472
 for n in old.namelist():assert (S/n).is_file();z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
 for n in z.namelist():assert hashlib.sha256(z.read(n)).hexdigest()==sha(S/n)
paths['manifest'].write_text(json.dumps({'UTC':datetime.now(timezone.utc).isoformat(),'status':'DONE — source/math/rendered staged gates','staging_preparation_SHA256':sha(C/'staging_preparation_v2_20261008.json'),'validation_SHA256':sha(C/'staged_book_validation_v2_20261008.json'),'release_checks':release,'actual_reading':reading,'post_render_checks':post,'mathematical_self_audit':math,'underfull_delta':underfull,'source_input_hashes':prep['after'],'progress_document_hashes':{n:sha(S/n) for n in ['README.md',programme]},'active_book_changed':False,'GitHub_published':False,'canonical_status_changes':[],'original_results_promoted':[],'independent_model_receipt':None},ensure_ascii=False,indent=2)+'\n')
files={}
for q in C.glob('*.json'):
 if q.name.startswith(('staged_','staging_','actual_staged_','post_render_','normalization_diagnostic_')):files['records/'+q.name]=q
for q in [C/'staged_book_validation_v1_20261008.log',C/'staged_book_validation_v2_20261008.log',review,Path(release['manifest_path'])]:files['records/'+q.name]=q
for v in reading['views']:
 for key,folder in [('path','images'),('selected_text_path','text'),('sequential_note_path','notes'),('observation_receipt_path','receipts')]:q=Path(v[key]);files[folder+'/'+q.name]=q
for key in ['audit','reading_notes','manifest']:q=paths[key];files['editorial/'+q.name]=q
for q in sorted(Path('/tmp').glob('Hattori_CY_fibrations_*_20261008.py')):
 if any(x in q.name for x in ['staged','staging','book_note','normalization_diagnostic','underfull']):files['helpers/'+q.name]=q
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
 assert len(z.namelist())==len(files)
 for n,q in files.items():assert hashlib.sha256(z.read(n)).hexdigest()==sha(q)
artifacts={'UTC':datetime.now(timezone.utc).isoformat(),'status':'DONE — byte-verified staged book exports','full_book_PDF':{'path':str(full),'bytes':full.stat().st_size,'SHA256':sha(full),'physical_pages':np},'actual_book_review_PDF':{'path':str(review),'bytes':review.stat().st_size,'SHA256':sha(review),'physical_pages':nb},'minimal_TeX_source_archive':{'path':str(minimal),'bytes':minimal.stat().st_size,'SHA256':sha(minimal),'members':472,'all_members_byte_verified':True},'actual_book_evidence_archive':{'path':str(evidence),'bytes':evidence.stat().st_size,'SHA256':sha(evidence),'members':len(files),'all_members_byte_verified':True},'actual_source_export_record_SHA256':sha(C/'source_export_v1_20261008.json'),'source_publication_record_SHA256':sha(C/'GitHub_source_publication_v1_20261008.json'),'external_primary_files_uploaded_in_book_exports':False,'actual_reading_credit_from_export':0,'active_book_changed':False,'native_editor_changed':False,'GitHub_published':False,'canonical_status_changes':[],'helper_source':__file__};paths['artifacts'].write_text(json.dumps(artifacts,ensure_ascii=False,indent=2)+'\n');record.write_text(json.dumps({'UTC':datetime.now(timezone.utc).isoformat(),'status':'DONE — frozen staged checkpoint and exports','editorial_files':{str(q):sha(q) for q in paths.values()},'artifacts':artifacts,'progress_document_hashes':{n:sha(S/n) for n in ['README.md',programme]},'active_book_changed':False,'GitHub_published':False,'canonical_status_changes':[],'helper_source':__file__},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'DONE','record_SHA256':sha(record),'artifacts':artifacts}))
