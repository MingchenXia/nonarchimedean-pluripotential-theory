from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sympy as sp
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Hattori_CY_fibrations_review_20261008';out=C/'normalization_diagnostic_v2_20261008.json';assert not out.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=C/'exact_diagnostics_v1_20261008.json';assert sha(old)=='24ee27a0ac98d8a01cb332636b6128bcbdac8476a25b310738b5ff39b449ac4b'
l,V,Q,T,Kmod,Kref=sp.symbols('lambda V Q T Kmod Kref',positive=True);rows=[]
for d in range(1,7):
 DF=Kmod-d*Kref*T/((d+1)*V);J=Q-T/(d+1)
 Vscaled=l**d*V;DFscaled=l**d*Kmod-d*l**(d-1)*Kref*l**(d+1)*T/((d+1)*Vscaled);Jscaled=l**(d+1)*Q-l**(d+1)*T/(d+1)
 res={'raw_DF_degree_d':sp.simplify(DFscaled-l**d*DF),'raw_J_degree_d_plus_one':sp.simplify(Jscaled-l**(d+1)*J),'normalized_DF_invariant':sp.simplify(DFscaled/Vscaled-DF/V),'normalized_J_linear':sp.simplify(Jscaled/Vscaled-l*J/V),'raw_normalized_ratio_agreement':sp.simplify(DF/J-(DF/V)/(J/V))}
 assert all(x==0 for x in res.values());rows.append({'dimension':d,'zero_residuals':{k:str(x) for k,x in res.items()}})
obj={'UTC':datetime.now(timezone.utc).isoformat(),'status':'DONE — chapter raw/source-normalized dictionary checked','prior_exact_diagnostics_SHA256':sha(old),'checks':rows,'notation':'Hats distinguish source volume-normalized functionals from chapter 62 volume-unnormalized model invariants.','scope':'Normal semiample projective configurations; a base twist makes the compactification nef, so positive products agree with ordinary intersections. Boundary zero for comparison with chapter raw DF.','adiabatic_scale':'DF_hat(P_k)>=delta/k J_hat(P_k); multiplying by V(P_k) gives the same raw inequality. Constants must be independent of k and the test configuration.','frozen_v1_build_is_not_a_reading_gate':True,'active_book_changed':False,'original_results_promoted':[],'canonical_status_changes':[],'independent_model_receipt':None,'helper_source':__file__}
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':obj['status'],'SHA256':sha(out),'dimensions':len(rows)}))
