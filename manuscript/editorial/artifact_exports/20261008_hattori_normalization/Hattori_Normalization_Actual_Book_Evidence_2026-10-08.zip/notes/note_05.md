# Hattori normalization actual book view 05

UTC: 2026-10-08T19:40:32.705275+00:00. Physical pages: 4383, 4384.

Read the complete selected text and displayed matching rendered image. The corrected curve-volume integral visibly includes d/2; the tail estimate stays a stated input and the half-limit is not promoted to a convergence theorem. The surface intersection matrix, ample class proof and transverse horizontal-curve construction give D_hor.Gamma=2epsilon, D_vert.Gamma=-epsilon and epsilon A.Gamma=epsilon, with the complete-fiber budget 2epsilon. The conclusion targets the dropped-vertical equality and explicitly does not refute Lemma 4.8 or the main equivalence. External proof dependencies and unchanged open-problem statuses remain visible. The following blank verso is intentional before Appendix M; all formulas and text are clear with no repair needed.
