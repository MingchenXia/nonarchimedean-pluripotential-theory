# Hattori normalization actual book view 09

UTC: 2026-10-08T19:41:20.162479+00:00. Physical pages: 4598, 4599.

Read the complete selected text and displayed matching rendered image. The complete Legendre-through-piecewise-linear continuation has clear M/N/O/P headers, consistent subentry indentation and readable long page lists. The Monge–Ampere measure entry continues across the page break without losing its mixed and probability-normalization distinctions. Open-problem and envelope-dependency references remain separate from theorem entries. No clipped links, overlapping columns or footer collisions appear, and no repair is needed.
