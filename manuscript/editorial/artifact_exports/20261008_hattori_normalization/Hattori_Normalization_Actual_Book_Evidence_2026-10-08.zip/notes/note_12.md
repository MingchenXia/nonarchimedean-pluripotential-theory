# Hattori normalization actual book view 12

UTC: 2026-10-08T19:41:55.917214+00:00. Physical pages: 4604, 4622.

Read the complete selected text and displayed matching rendered image. The blank index verso is intentional before the references. The complete new Hat23A entry names Masafumi Hattori, the Calabi–Yau-fibration title, arXiv:2203.11460v2, the 2023 source year and the 9 August 2023 revision. It does not substitute the unread 2025 journal edition for the pinned proof text. Neighboring Gupta/Guedj/Hartshorne/He/Hironaka/Hisamoto entries and their edition notes fit with aligned bibliography labels and no collisions or clipping. This completes all twelve fresh matching displays and twenty-four selected pages; no remaining repair is identified.
