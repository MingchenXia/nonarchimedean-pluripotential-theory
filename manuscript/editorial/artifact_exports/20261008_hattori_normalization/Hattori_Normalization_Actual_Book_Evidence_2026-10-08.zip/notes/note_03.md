# Hattori normalization actual book view 03

UTC: 2026-10-08T19:40:01.226334+00:00. Physical pages: 3396, 3397.

Read the complete selected text and displayed matching rendered image. The adjoining 62.4 pages preserve the fixed-class finite-energy coercivity definition and the finite-support continuity proof, including zero masses and M=0. The beginning of Theorem 62.4.1 keeps one delta across its five domains, the normalized-model qualification and the separate entropy convergence obligation. The rational-simplex approximation is nonnegative and mass one, including boundary masses. This is a neighboring-page seam review, not fresh credit for the rest of that theorem's proof or for its imported prerequisites. Displayed equations, theorem/proof typography and links remain clear; no repair is needed.
