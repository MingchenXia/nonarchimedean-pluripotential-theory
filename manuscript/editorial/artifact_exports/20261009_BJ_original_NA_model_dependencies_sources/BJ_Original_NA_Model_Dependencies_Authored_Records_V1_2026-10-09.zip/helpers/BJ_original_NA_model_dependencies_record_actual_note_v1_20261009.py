from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, sys

C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/BJ_original_NA_model_dependencies_review_20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.load(sys.stdin);number=a['number'];assert isinstance(number,int) and 1<=number<=29
prep=json.loads((C/'primary_view_preparation_v1_20261009.json').read_text())
mp=Path(prep['manifest_path']);assert sha(mp)==prep['manifest_SHA256']
xs=json.loads(mp.read_text());x=xs[number-1];assert x['number']==number
assert not x['actually_viewed'] and not x['selected_text_read']
assert sha(x['path'])==x['image_SHA256'] and sha(x['selected_text_path'])==x['selected_text_SHA256']
source=prep['sources'][x['source']];assert sha(source['path'])==x['source_PDF_SHA256']==source['SHA256']
N=C/'primary_notes_v1';n=N/f'note_{number:02d}.md';r=N/f'note_{number:02d}_receipt.json'
assert not n.exists() and not r.exists();now=datetime.now(timezone.utc).isoformat()
if number>1:
    prev=json.loads((N/f'note_{number-1:02d}_receipt.json').read_text());assert now>prev['UTC']
assert a['observations'].strip()
n.write_text(f"# Original NA/model dependency review — view {number}\n\nSource: {x['source']}. Physical pages: {x['physical_pages']}.\n\nRead the complete selected text and individually displayed the matching rendered image.\n\n"+a['observations'].strip()+"\n\nScope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.\n")
obj=dict(UTC=now,number=number,source=x['source'],physical_pages=x['physical_pages'],
    source_PDF_SHA256=x['source_PDF_SHA256'],complete_selected_text_actually_read=True,
    matching_image_individually_displayed_and_reviewed=True,note_path=str(n),note_SHA256=sha(n),
    image_SHA256=sha(x['path']),selected_text_SHA256=sha(x['selected_text_path']),
    helper_source_SHA256=sha(__file__))
r.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(number=number,source=x['source'],physical_pages=x['physical_pages'],note_SHA256=sha(n),receipt_SHA256=sha(r))))
