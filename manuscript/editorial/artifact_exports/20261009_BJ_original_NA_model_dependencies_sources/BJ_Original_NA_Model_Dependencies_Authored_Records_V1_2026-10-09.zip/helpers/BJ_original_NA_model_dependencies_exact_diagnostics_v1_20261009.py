from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction as F
import hashlib, json

C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/BJ_original_NA_model_dependencies_review_20261009')
out=C/'exact_diagnostics_v1_20261009.json';assert not out.exists()
families=[]
def add(name, rows, interpretation):
    families.append(dict(name=name,exact_cases=rows,interpretation=interpretation))
rows=[]
for c in [F(1,3),F(2),F(-7,4)]:
    correct=c-c;printed=c+c
    assert correct==0 and printed!=0
    rows.append(dict(c=str(c),correct_sup_normalized=str(correct),printed_plus_normalized=str(printed),I=0,J=0))
add('Constant shifts and quotient centering',rows,'BoJ18a Lemma 6.24 needs a common shift/reference bound; the quotient normalization uses minus the supremum. I and J alone do not control constants.')
rows=[]
for c in [F(1,3),F(2),F(-7,4)]:
    for V in [F(1),F(7,3)]:
        energy_shift=V*c;mu_shift=c
        assert energy_shift/V-mu_shift==0
        rows.append(dict(c=str(c),mass=str(V),unnormalized_energy_shift=str(energy_shift),normalized_variational_shift='0',belongs_to_phi_le_reference=c<=0))
add('Mass and the variational quotient',rows,'Berman uses mass-V energy; the NA source uses normalized energy. Probability F_mu is invariant under constants, whereas literal E1_C additionally requires a reference upper bound.')
rows=[]
for j in [4,9,16,25]:
    root=int(j**0.5);good=F(1,root);bad=F(root)
    assert good*root==1 and good*good*j==1 and bad*bad*j==j*j
    rows.append(dict(J=j,correct_t=str(good),printed_t=str(bad),correct_t_squared_J='1',printed_t_squared_J=j*j))
add('Coercivity rescaling',rows,'The J-to-infinity proof of BoJ18a Proposition 7.8 uses J^(-1/2), not J^(1/2). These values test the scaling arithmetic only.')
rows=[]
for root in [1,2,3,7]:
    for B in [F(1),F(3,2),F(4)]:
        j=F(root*root);lhs=-j+B*root;rhs=-j/2+B*B/2
        assert lhs<=rhs
        rows.append(dict(J=str(j),B=str(B),correct_bound=str(lhs),absorbed_bound=str(rhs)))
add('The sign and absorption of a square-root term',rows,'An integral lower bound gives F<=A-J+B sqrt(J). The plus term can be absorbed to obtain A+B^2/2-J/2; the printed minus term does not follow.')
rows=[]
for n in [1,2,3,5]:
    for t in [F(1,2),F(1,3),F(3,4),F(1)]:
        j=t*t
        assert j**n<=t**(n+1)
        rows.append(dict(dimension=n,t=str(t),quadratic_J=str(j),J_power_n=str(j**n),scaling_bound_power_n=str(t**(n+1))))
add('J scaling exponent',rows,'The exact rational quadratic test satisfies Lemma 6.17. The actual proof uses derivative J=t^(-1) I and I>=(n+1)/n J; these algebraic cases do not prove the general estimate.')
rows=[]
for f,t in [(F(2),F(1)),(F(-2),F(1)),(F(2),F(-1))]:
    actual=t*f;printed=-t*f;safe=-abs(t)*abs(f)
    assert safe<=actual
    rows.append(dict(constant_f=str(f),t=str(t),exact_envelope_shift=str(actual),printed_lower_shift=str(printed),safe_lower_shift=str(safe),printed_lower_valid=printed<=actual))
add('Envelope directional lower bound',rows,'Corollary 6.32 needs phi+inf(tf), or phi-|t| norm(f)_infinity. For positive constant f and negative t the printed phi-t inf(f) exceeds the obstacle.')
rows=[]
for c in [F(1,2),F(2),F(-3)]:
    printed=-c-c;correct=-c+c
    assert printed==-2*c and correct==0
    rows.append(dict(c=str(c),printed_Ding_shift=str(printed),correct_Ding_shift=str(correct)))
add('Berman squared-weight Ding sign',rows,'Literal Berman v3 (3.1) has a positive logarithm. The constant-shift test forces a negative logarithm with -E/V under the displayed KE convention; no main theorem counterexample is claimed.')
rows=[]
for n in [1,2,4]:
    for V in [F(1),F(7,3)]:
        coefficient=(n+1)*V
        assert coefficient/((n+1)*V)==1
        rows.append(dict(relative_dimension=n,required_curvature_factors=n+1,printed_factors=n,fibre_coefficient_for_spatial_constant=str(coefficient),normalized_energy_coefficient='1'))
add('Deligne fibre degree and normalized energy',rows,'Berman (2.4) needs n+1 curvatures; normalized energy differentiation needs 1/((n+1)V). The test concerns formal degree and constant-potential calibration.')
rows=[]
for w in [-3,0,2]:
    for lelong in [F(0),F(1,2),F(4)]:
        log_norm_derivative=-w+lelong;recovered=-log_norm_derivative+lelong
        assert recovered==w
        rows.append(dict(weight=w,Lelong=str(lelong),log_squared_norm_derivative=str(log_norm_derivative),recovered_weight=str(recovered),orbit_section_trivializes_at_zero=w==0))
add('Singular Kempf–Ness local weight',rows,'For Phi=-l t and t=-log|tau|^2 the direct frame calculation verifies Lemma 2.6. An orbit section with nonzero weight has a zero or pole at zero.')
rows=[]
for A,S in [(F(2),F(1)),(F(1),F(1)),(F(1),F(2))]:
    mad=A-S;semistable=A>=S
    assert (mad>=0)==semistable
    rows.append(dict(A=str(A),S=str(S),M_ad=str(mad),semistable_inequality=semistable,printed_reversed_formula=str(S-A)))
add('Adjoint stability signs',rows,'BoJ18b Corollary 5.17 uses A-S. The next semistability paragraph reverses both its inequality and formula. The zero-over-zero trivial valuation is excluded from ratios.')
rows=[]
for m in [2,8,32,128]:
    for p in [1,2,3]:
        a=F(3,2);moment=a**p/F(m+1)
        assert moment>0
        rows.append(dict(degree=m,p=p,normalized_moment_power_p=str(moment),normalized_infinity_distance=str(a)))
add('A rare linear weight and the FS regularization gate',rows,'One linear weight among m+1 basis weights disappears in every fixed finite-p moment and remains in infinity distance. BoJ18b FS and Q explicitly include usc, so the raw point-jump example does not refute its Theorem 4.16.')
rows=[]
for k in [1,2,3,5,10]:
    even_degree=2*k;dim=k+1;ambient_leading=F(dim,even_degree)
    rows.append(dict(degree=even_degree,even_subalgebra_dimension=dim,dimension_over_ambient_degree=str(ambient_leading),odd_degree_dimension=0,intrinsic_lattice_index=2))
add('Subalgebra degree period and lattice index',rows,'For k[x^2,y^2] inside k[x,y], an ordinary all-degree volume limit fails and the ambient lattice gives the wrong leading coefficient on even degrees. Lemma 4.15 needs the applicable semigroup lattice and admissible degrees; no full replacement theorem is promoted.')
assert len(families)==12
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — twelve scoped elementary normalization/proof diagnostics',families=families,primary_reading_credit=0,book_reading_credit=0,original_formal_results_promoted=[],independent_model_receipt=None,BJ22_Theorem_6_21_repaired=False,helper_source=__file__,helper_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',families=len(families),SHA256=hashlib.sha256(out.read_bytes()).hexdigest())))
