from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile, shutil, subprocess

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BJ_original_NA_model_dependencies_review_20261009'
E=R/'manuscript/editorial';O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
stamp=lambda:datetime.now(timezone.utc).isoformat()
actual=C/'actual_primary_reading_v1_20261009.json'
checkpoint=C/'source_checkpoint_v1_20261009.json'
paths={k:E/f'BJ_original_NA_model_dependencies_source_{k}_20261009.{ext}' for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
dest=E/'artifact_exports/20261009_BJ_original_NA_model_dependencies_sources'
owned=O/'BJ_Original_NA_Model_Dependencies_Authored_Records_V1_2026-10-09.zip'
full=O/'BJ_Original_NA_Model_Dependencies_Actual_Source_Evidence_V1_2026-10-09.zip'
assert not any(p.exists() for p in [actual,checkpoint,*paths.values(),dest,owned,full])
preps=[];views=[];sources={};last=None
for prefix,count in [('primary',29),('supplemental',7)]:
    pp=C/f'{prefix}_view_preparation_v1_20261009.json';prep=json.loads(pp.read_text());preps.append((pp,prep))
    assert prep['actual_source_reading_credit']==prep['actually_read_pages']==0
    assert sha(prep['manifest_path'])==prep['manifest_SHA256']
    rows=json.loads(Path(prep['manifest_path']).read_text());assert len(rows)==count
    for i,x in enumerate(rows,1):
        rp=C/f'{prefix}_notes_v1/note_{i:02d}_receipt.json';a=json.loads(rp.read_text())
        assert a['number']==i and a['source']==x['source'] and a['physical_pages']==x['physical_pages']
        assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
        assert last is None or a['UTC']>last;last=a['UTC']
        assert not x['actually_viewed'] and not x['selected_text_read']
        for key,h in [('path','image_SHA256'),('selected_text_path','selected_text_SHA256')]:assert sha(x[key])==x[h]==a[h]
        assert sha(a['note_path'])==a['note_SHA256']
        assert sha(prep['sources'][x['source']]['path'])==a['source_PDF_SHA256']==x['source_PDF_SHA256']
        views.append(dict(**a,pass_name=prefix,image_path=x['path'],selected_text_path=x['selected_text_path'],observation_receipt_path=str(rp),observation_receipt_SHA256=sha(rp)))
    for key,src in prep['sources'].items():
        if key not in sources:sources[key]=dict(src)
        else:assert sources[key]['SHA256']==src['SHA256']
    for n,h in prep['protected_core_inputs'].items():assert sha(R/n)==h
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==prep['baseline_commit']
for key,src in sources.items():
    selected=[p for v in views if v['source']==key for p in v['physical_pages']]
    assert len(selected)==len(set(selected));selected.sort()
    src.update(actually_read_physical_pages=selected,selected_physical_pages=selected,whole_physical_PDF_actually_read=False,unread_physical_pages=sorted(set(range(1,src['total_physical_pages']+1))-set(selected)))
assert [len(sources[k]['actually_read_physical_pages']) for k in ['BoJ18a_arxiv_v1','BoJ18b_arxiv_v1','Berman_KE_polystability_arxiv_v3']]==[35,20,13]
assert len(views)==36 and sum(len(v['physical_pages']) for v in views)==68
dp=C/'exact_diagnostics_v1_20261009.json';diag=json.loads(dp.read_text());assert len(diag['families'])==12
reading=dict(UTC=stamp(),status='DONE — selected original NA energy and bounded model-ray dependencies',sources=sources,actual_selected_source_page_pairs=68,actual_individually_displayed_matching_views=36,views=views,preparations=[dict(path=str(p),SHA256=sha(p)) for p,_ in preps],preparation_flags_unchanged=True,diagnostics_SHA256=sha(dp),actual_book_reading_credit=0,whole_book_new_reading_claim=False,whole_primary_PDF_reading_claim=False,recursive_original_dependency_certification=False,original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],active_book_changed=False,native_editor_changed=False,BJ22_Theorem_6_21_repaired=False,general_envelopes_proved=False,baseline_commit=preps[0][1]['baseline_commit'],protected_core_inputs_unchanged=True,helper_source=__file__,helper_SHA256=sha(__file__))
actual.write_text(json.dumps(reading,ensure_ascii=False,indent=2)+'\n')
draft=Path('/tmp/BJ_original_NA_model_dependencies_source_review_draft_v1_20261009.md')
assert draft.stat().st_size>9000 and 'strictness,+the' not in draft.read_text()
paths['review'].write_text(draft.read_text().rstrip()+'\n')
paths['reading_notes'].write_text(('# Actual selected original NA/model source notes\n\n68 unique source/page pairs, 36 individually displayed matching views. BoJ18a 35/79; BoJ18b 20/39; Berman v3 13/41. Every source remains partial. Supplemental notes 6–7 resolve the provisional 2018 FS terminology without changing frozen first-pass notes. No new book pass or recursive proof certification.\n'+''.join('\n---\n\n'+Path(v['note_path']).read_text() for v in views)).rstrip()+'\n')
files={f'records/{p.name}':p for p in C.glob('*.json')}
for p,prep in preps:files[f'manifests/{p.stem}_views.json']=Path(prep['manifest_path'])
for v in views:
    for key,kind in [('note_path','notes'),('observation_receipt_path','receipts')]:
        p=Path(v[key]);files[f'{kind}/{v["pass_name"]}/{p.name}']=p
for p in sorted(Path('/tmp').glob('BJ_original_NA_model_dependencies_*_v1_20261009.py')):files[f'helpers/{p.name}']=p
for p in (R/'source_material/research_discovery_20261009_round1').glob('BJ_original_NA_model_dependencies_metadata_v1_20261009.json'):files[f'discovery/{p.name}']=p
files[f'drafts/{draft.name}']=draft
for k in ['review','reading_notes']:files[f'editorial/{paths[k].name}']=paths[k]
def archive(target, entries):
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,p in sorted(entries.items()):z.write(p,n)
    with zipfile.ZipFile(target) as z:
        assert len(z.namelist())==len(entries) and z.testzip() is None
        for n,p in entries.items():assert z.read(n)==p.read_bytes()
archive(owned,files)
fullfiles=dict(files)
for key,src in sources.items():fullfiles[f'primary/PDF/{key}.pdf']=Path(src['path'])
for v in views:
    for key,kind in [('image_path','images'),('selected_text_path','text')]:
        p=Path(v[key]);fullfiles[f'primary/{kind}/{v["pass_name"]}/{p.name}']=p
archive(full,fullfiles)
artifacts={k:dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p),members=count) for k,p,count in [('authored_records_archive',owned,len(files)),('cloud_source_evidence_archive',full,len(fullfiles))]}
paths['manifest'].write_text(json.dumps(dict(UTC=stamp(),status='DONE — three partial primary-source audits',actual_reading=reading,exact_diagnostics=diag,artifacts=artifacts,active_book_changed=False,native_editor_changed=False,GitHub_published=False,canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=stamp(),status='DONE — every archive member byte-verified',artifacts=artifacts,reading_credit_from_export=0,external_primary_PDF_text_images_uploaded=False,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
dest.mkdir(parents=True);target=dest/owned.name;shutil.copyfile(owned,target);assert sha(target)==sha(owned)
(dest/'SHA256SUMS').write_text(sha(target)+'  '+target.name+'\n')
(dest/'README.md').write_text(f'''# Selected original NA/model dependency evidence, 9 October 2026

Actual scope: 68 unique physical source/page pairs, 36 matching individual
text/image displays. BoJ18a v1: 35/79 pages; BoJ18b v1: 20/39;
Berman v3: 13/41. All three sources remain partial. The 29-view initial
pass and seven-view supplement have separate immutable preparations and
actual notes; the supplement resolves provisional raw/usc terminology.

The {len(files)}-member authored archive contains reading notes, receipts,
acquisition/preparation/actual records, twelve elementary diagnostics,
helpers and the source audit. The {len(fullfiles)}-member cloud source
archive adds three controlling PDFs and all selected text/images. Every
member was byte-verified; preparation and upload add zero reading credit.
External source PDFs/text/images remain in the cloud evidence archive.

Original NA results retain smooth ample characteristic-zero hypotheses,
normalization modulo constants and the discrete envelope dependencies.
BoJ18b's FS and Q definitions explicitly include upper regularization.
Berman's original input is the locally bounded normal-configuration
envelope construction; the main Ding-slope proof remains unread here.

The current 4,667-page book, both bibliographies, open native LaTeX editor
and canonical 42 atoms/twelve problems are unchanged. General BJ22 Siu
and envelopes remain OPEN, LPWZ density UNVERIFIED. No independent-model
receipt or repair of Theorem 6.21 is claimed. Last complete ordered
whole-book read: 4 October. Continue in the cloud and publish checked work.
'''.rstrip()+'\n')
p=R/'README.md';s=p.read_text();marker='**Latest original maximal-ray/extension source checkpoint, 9 October 2026:**';assert s.count(marker)==1
intro='''**Latest original NA/model dependency source checkpoint, 9 October 2026:**
the [source audit](manuscript/editorial/BJ_original_NA_model_dependencies_source_review_20261009.md)
records 68 actually read source/page pairs in 36 matching displays:
BoJ18a 35/79, BoJ18b 20/39 and Berman v3 13/41, all partial.
Twelve elementary diagnostics preserve constants, energy and Ding signs,
original field hypotheses and the explicitly upper-regularized 2018
FS/Q definitions. The [authored evidence](manuscript/editorial/artifact_exports/20261009_BJ_original_NA_model_dependencies_sources/README.md)
pins initial and supplemental scope. The 4,667-page book/native editor
are unchanged; general BJ22 Siu/envelopes remain OPEN.

''';p.write_text(s.replace(marker,intro+marker,1))
p=E/'second_reading_and_research_programme_20261002.md';s=p.read_text();marker='## Latest original maximal-ray/extension source checkpoint, 9 October 2026\n';assert s.count(marker)==1
intro='''## Latest original NA/model dependency source checkpoint, 9 October 2026

The [source audit](BJ_original_NA_model_dependencies_source_review_20261009.md)
records actual selected text and 36 individual matching displays:
68 distinct source/page pairs. BoJ18a v1 has 35/79 read pages;
BoJ18b v1 20/39; Berman v3 13/41. Every source remains partial.
The original 55-page/29-view selection and additional 13-page/seven-view
definition/proof selection retain separate immutable preparation records.
The supplement explicitly resolves the provisional raw/usc concern:
the exact 2018 FS and Q definitions both include upper regularization.

Twelve exact elementary families calibrate constants, mass, coercivity,
directional envelopes, Ding/Deligne factors, local weights, adjoint signs,
rare weights and semigroup periods. Original NA countable regularization,
mixed-MA continuity, orthogonality and duality retain smooth projective,
ample, trivially/discretely valued characteristic-zero premises. Berman
Proposition 2.7 supplies the bounded model-ray construction, with external
compactness/Bedford–Taylor inputs; its full main proof is unread here.
Printed defects and additional proof steps do not disprove the intended
main theorems. The [authored evidence](artifact_exports/20261009_BJ_original_NA_model_dependencies_sources/README.md)
preserves notes and calculations; external PDF/text/images remain cloud.

Next return to a scoped book unit: published BBJ21 maximal-ray anchors,
quotient normalization and Finski Corollary 2.12's exact holomorphic
input. Check incoming GitHub author changes before integrating them.
The 4,667-page book and native catalogue/editor are unchanged here.
Canonical inventory remains 42 atoms/twelve formal problems and tiers
(0,3,7,15,17). BJ22 homogeneous Siu/general envelopes remain OPEN,
LPWZ density UNVERIFIED, and the user's Theorem 6.21 warning binding.
No new general result, independent-model receipt or complete book pass.
Last complete ordered whole-book read remains 4 October. Continue cloud
only, keep Xean suspended and publish checked units regularly.

''';p.write_text(s.replace(marker,intro+marker,1))
editorial=[*paths.values(),target,dest/'README.md',dest/'SHA256SUMS',R/'README.md',E/'second_reading_and_research_programme_20261002.md'];assert len(editorial)==9
for n,h in preps[0][1]['protected_core_inputs'].items():
    if n not in {str(p.relative_to(R)) for p in editorial}:assert sha(R/n)==h
rec=dict(UTC=stamp(),status='DONE — exact nine-file selected source checkpoint prepared',actual_reading_SHA256=sha(actual),diagnostics_SHA256=sha(dp),artifacts=artifacts,editorial_files={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in editorial},active_book_changed=False,native_editor_changed=False,GitHub_published=False,baseline_commit=preps[0][1]['baseline_commit'],helper_source=__file__,helper_SHA256=sha(__file__))
checkpoint.write_text(json.dumps(rec,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',source_pages=68,views=36,editorial_files=9,authored_members=len(files),cloud_members=len(fullfiles),reading_SHA256=sha(actual),checkpoint_SHA256=sha(checkpoint),artifacts=artifacts)))
