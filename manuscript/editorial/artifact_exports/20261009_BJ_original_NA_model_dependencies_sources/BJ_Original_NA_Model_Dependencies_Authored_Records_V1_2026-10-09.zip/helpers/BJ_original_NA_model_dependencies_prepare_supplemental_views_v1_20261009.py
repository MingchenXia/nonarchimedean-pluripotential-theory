from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, fitz, subprocess
from PIL import Image, ImageDraw

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BJ_original_NA_model_dependencies_review_20261009'
W=Path('/tmp/BJ_original_NA_model_dependencies_supplemental_views_v1_20261009')
N=C/'supplemental_notes_v1';out=C/'supplemental_view_preparation_v1_20261009.json'
assert C.exists() and not any(p.exists() for p in [W,N,out])
W.mkdir();N.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
bookprep=json.loads((R/'source_material/BJKS1_Finski_dependencies_review_20261009/staging_preparation_v2_20261009.json').read_text())
names=sorted(set(bookprep['other_active_TeX_preserved'])|{n for n in bookprep['after'] if n.endswith('.tex')})
assert len(names)==425
names+=['manuscript/book.pdf','manuscript/bibliography/ComplexGeometry.bib','manuscript/bibliography/NonArchimedean.bib',
        'output/open_problems_catalogue_2026-10-03.tex','output/open_problems_catalogue_2026-10-03.pdf',
        'README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']
protected={n:sha(R/n) for n in names}
assert protected['manuscript/book.pdf']=='60e0e21a5a966a3a954c171aedd13e6cd623261b01e448db6b67febab253efcf'
sources=[('BoJ18a_arxiv_v1','BoJ18a_arxiv_v1.pdf','6ee47fae26082ead2beb6375448c0ba0b9d95ab80439753d2b28a76421ebf5d0',79,list(range(59,65))+list(range(73,77))),
         ('BoJ18b_arxiv_v1','BoJ18b_arxiv_v1.pdf','fa108da4e3f443258662f6615e3b598bb07df946908fda069383b36ec10bde6d',39,list(range(22,25)))]
views=[];pdfs={}
for key,name,pin,total,selected in sources:
    pdf=C/name;assert sha(pdf)==pin
    pdfs[key]=dict(path=str(pdf),bytes=pdf.stat().st_size,SHA256=pin,total_physical_pages=total,
        selected_physical_pages=selected,whole_PDF_selected=len(selected)==total)
    with fitz.open(pdf) as d:
        assert len(d)==total
        for i in range(0,len(selected),2):
            pp=selected[i:i+2];panels=[];texts=[]
            for n in pp:
                pix=d[n-1].get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False)
                panels.append(Image.frombytes('RGB',[pix.width,pix.height],pix.samples))
                texts.append(f'{key} SELECTED PRIMARY PHYSICAL PAGE {n}\n'+d[n-1].get_text())
            canvas=Image.new('RGB',(sum(p.width for p in panels),max(p.height for p in panels)+28),'white')
            draw=ImageDraw.Draw(canvas);x=0
            for n,panel in zip(pp,panels):
                draw.text((x+8,8),f'{key} physical {n}',fill='black');canvas.paste(panel,(x,28));x+=panel.width
            number=len(views)+1;ip=W/f'sheet_{number:02d}.png';tp=W/f'sheet_{number:02d}.txt'
            canvas.save(ip);tp.write_text('\n\n'.join(texts))
            views.append(dict(number=number,source=key,physical_pages=pp,path=str(ip),image_SHA256=sha(ip),
                selected_text_path=str(tp),selected_text_SHA256=sha(tp),source_PDF_SHA256=pin,
                actually_viewed=False,selected_text_read=False))
assert len(views)==7 and sum(len(v['physical_pages']) for v in views)==13
mp=W/'manifest.json';mp.write_text(json.dumps(views,ensure_ascii=False,indent=2)+'\n')
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — supplemental original NA definition/proof views prepared; zero reading credit',
    sources=pdfs,prepared_source_page_pairs=13,prepared_views=7,manifest_path=str(mp),manifest_SHA256=sha(mp),
    protected_core_inputs=protected,baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    actual_source_reading_credit=0,actually_read_pages=0,whole_primary_PDF_reading_claim=False,
    whole_book_new_reading_claim=False,active_book_changed=False,native_editor_changed=False,
    canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',prepared_source_page_pairs=13,prepared_views=7,record_SHA256=sha(out))))
