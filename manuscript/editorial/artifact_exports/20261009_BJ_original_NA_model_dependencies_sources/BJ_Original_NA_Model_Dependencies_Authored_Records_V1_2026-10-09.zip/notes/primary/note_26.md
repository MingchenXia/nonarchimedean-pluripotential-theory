# Original NA/model dependency review — view 26

Source: Berman_KE_polystability_arxiv_v3. Physical pages: [13, 14].

Read the complete selected text and individually displayed the matching rendered image.

The compactification is normalized so the lifted action on the fiber at infinity is trivial, giving weight at zero equal to degree. Proposition 2.5's literal integral prints an extra outer mu multiplying an integrand that already contains mu; the correct expression follows from (2.10) and the definition of eta. Lemma 2.6 fixes t=-log|tau|^2 and the Lelong convention ddc log|tau|^2=delta_0. In an equivariant frame with weight w and local potential Phi, log squared norm of the orbit section is -wt-Phi, so the printed slope formula w=-lim derivative(log squared norm)+l_0 has the correct sign. The alternative proof's assertion that the orbit section trivializes the compactified line holomorphically at zero needs care: a nonzero weight orbit section has a zero or pole there. The direct local-weight calculation supplies the elementary check, without certifying the whole highbrow extension argument. The ray envelope is taken over locally bounded positive metrics with boundary limsup inequalities on the normal total space over a disc; invariance identifies its slices with a ray using the squared logarithmic time. Proposition 2.7 continues on the next page and is not yet fully read.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
