# Original NA/model dependency review — view 8

Source: BoJ18a_arxiv_v1. Physical pages: [65, 66].

Read the complete selected text and individually displayed the matching rendered image.

BoJ18a physical 65–66 gives Theorem 7.3 with the exact restricted MA bijection and variational characterization; injectivity traces to 6.28, while surjectivity is still to be read. Proposition 7.5 dualizes E by choosing MA(phi), without claiming arbitrary-field surjectivity. The text changes E1_C from the earlier phi<=phi_ref definition to sup(phi-phi_ref)=0; these related but different sublevels need deliberate normalization. Proposition 7.8's infinite convex sum argument gives finite-energy integrability characterization, using decreasing stability and energy concavity. The second contradiction paragraph prints t_j=J(phi_j)^{1/2}->0 and simultaneously uses t_j^2 I(phi_j) bounded. The intended rescaling is the reciprocal square root along a sequence with J tending to infinity; the printed exponent cannot produce that bound. Corollary 7.9 displays F_mu<=A-J-B sqrt(J), but the preceding integrability lower bound gives A-J+B sqrt(J). A minus square-root term is not obtained by the printed deduction; any coercivity repair must state its constants and linear coefficient explicitly. This observation does not assert an independently proved counterexample to every possible alternative estimate. Corollary 7.10 concerns finite-energy measure classes, and its proof's 'every L-psh function' phrase must retain the E1 requirement from 7.8, rather than all singular psh metrics.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
