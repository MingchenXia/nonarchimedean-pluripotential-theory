# Original NA/model dependency review — view 29

Source: Berman_KE_polystability_arxiv_v3. Physical pages: [41].

Read the complete selected text and individually displayed the matching rendered image.

The final references identify Phong–Ross–Sturm, JDG 78 (2008), for Deligne pairings and Knudsen–Mumford expansion; Phong–Sturm, PAMS 138 (2010), for regularity of rays; and Zhang, Compositio 104 (1996), for intersection-metric constructions. Their proofs have not been recursively read. This concludes the actual initial selection of 13 of 41 physical pages of Berman arXiv v3: 1–2, 9–16 and 39–41. Pages 3–8 and 17–38 remain unread, including the main Ding-slope correction and polystability proof. The examined original dependency is Proposition 2.7's bounded geodesic-envelope construction, not a certification of the whole article or the published Inventiones edition. Across the three source PDFs the first-pass reading covers 55 physical source-page pairs in 29 individually displayed views; every source remains partial.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
