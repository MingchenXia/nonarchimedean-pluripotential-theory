# Original NA/model dependency review — view 2

Source: BoJ18a_arxiv_v1. Physical pages: [3, 4].

Read the complete selected text and individually displayed the matching rendered image.

BoJ18a physical 3–4 supplies the precise constant quotient absent from the abstract: MA:E1(L)/R -> M1(X) is a bijection. MA is divided by V=(L^n); E has 1/(n+1), is measured relative to the canonical trivial metric and extends by an infimum of dominating FS metrics. The weak topology is pointwise on quasimonomial points. Theorem A regularizes by decreasing nets; Theorem B asserts increasing/decreasing continuity only in the finite-energy domain. The source explicitly says it cannot prove A and B for every ground field and variety, even though the definitions make sense there. The proofs use smooth projective/trivial or discrete residue-characteristic-zero assumptions, SNC models, Hironaka and vanishing. Trivial valuation is reduced to k((varpi)) via invariant points/test configurations. MA uniqueness and model-supported solvability are imported from BFJ15 and related work, then general finite-energy measures require a separate SNC regularization. This dependency architecture is not an automatic general envelope result.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
