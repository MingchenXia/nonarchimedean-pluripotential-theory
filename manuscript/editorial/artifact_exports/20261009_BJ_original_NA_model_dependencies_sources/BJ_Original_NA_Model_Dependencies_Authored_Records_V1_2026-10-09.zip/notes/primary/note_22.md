# Original NA/model dependency review — view 22

Source: BoJ18b_arxiv_v1. Physical pages: [39].

Read the complete selected text and individually displayed the matching rendered image.

The final bibliography supplies the original Li–Xu special-test-configuration source, Kuronya's irrational-volume example behind the nondreaminess warning, and the arithmetic Hodge-index source used for uniqueness comparisons. Labels such as Jon12 refer to a printed 2015 book publication and to-appear records remain historical. The bibliography alone does not certify those external proofs. This completes only the selected 17 of the 39 physical pages of BoJ18b v1: pages 1–4, 25–34 and 37–39. Pages 5–24 and 35–36 remain unread in this initial pass, including the actual general FS/Q definitions; a separate supplemental read is required before classifying raw versus upper-regularized transforms in Section 4.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
