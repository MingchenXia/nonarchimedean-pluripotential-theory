# Original NA/model dependency review — view 10

Source: BoJ18a_arxiv_v1. Physical pages: [69, 70].

Read the complete selected text and individually displayed the matching rendered image.

BoJ18a physical 69–70 solves dual-complex-supported measures by normalized compactness, equicontinuity of restrictions and envelope differentiability; continuity of the resulting solution is imported from BFJ15 capacity theory plus Gauss reduction. The general proof retracts Radon measures to SNC dual complexes; their energy increases to E*(mu). It selects a sequence of models by convergence of this one real energy value and obtains I-Cauchy metrics via I(phi_j,phi_l)<=(n+1)(E*(mu_l)-E*(mu_j)), then strong completeness. The selected sequence is not automatically cofinal in all SNC models. Proposition 7.24's last equality, passing all fixed FS integrals from mu_j to mu, therefore needs either additional weak-convergence selection or a proof that energy approximation plus this retraction order enforces it; the full-net Lemma 7.19 alone does not immediately provide that equality for the selected sequence. This is an explicit proof obligation, not a claim that the intended solvability theorem is false. Lemma 7.23's last display uses mu_l after taking l to infinity where the claimed bound needs mu_j, a local index typo. The source notes the discrete algebraicity assumption was removed by BGJKM16. The strong topology on measures is weak plus dual energy, and Theorem 7.25's homeomorphism proof begins with uniform approximation of pairings on normalized energy sublevels.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
