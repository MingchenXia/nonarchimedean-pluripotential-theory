# Original NA/model dependency review — view 21

Source: BoJ18b_arxiv_v1. Physical pages: [37, 38].

Read the complete selected text and individually displayed the matching rendered image.

The selected page contains the end of the discrepancy comparison under the Gauss extension. It first compares the lower semicontinuous extensions on divisorial points, then uses continuity on an SNC simplex and finally the directed retraction net on valuations; replacing that net by an arbitrary sequence is not justified here. The literal intermediate symbol A instead of A-prime is a notational slip. The statement and preceding hypotheses of Lemma A.1 on page 36 have not been read in this selection, so no whole-lemma proof certification is recorded. The bibliography identifies the Berman 2016 published Inventiones source, the 2018 BoJ semipositive-metric preprint as 1801.08229, and the 1608.01919 differentiability source including Lazarsfeld's appendix. The entries BBJ18 in preparation and several to-appear labels are historical metadata, not current 2026 publication status. The BKMS label's 2016 tag differs from the printed Math. Ann. 361 (2015) publication year, which should not be silently used as a revised theorem version.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
