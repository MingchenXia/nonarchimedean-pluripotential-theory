# Original NA/model dependency review — view 7

Source: BoJ18a_arxiv_v1. Physical pages: [57, 58].

Read the complete selected text and individually displayed the matching rendered image.

BoJ18a physical 57–58 proves the strong/I/J equivalence via actual sup or reference-mean normalization, Izumi bounds, Tychonoff subnets on Shilov points, finite atomic model-MA testing, and Proposition 3.8's nondegeneracy. This is a net argument, not sequential compactness. The reference-mean-normalized family is not literally in E1_C (which requires pointwise phi<=phi_ref) without a further common shift; that bookkeeping defect reappears in the proof. Corollary 6.28's cited 'Proposition 6.18 applied to a constant net' should be Proposition 6.26 plus Hausdorffness to infer I=0 implies equality modulo constants. Its intended uniqueness chain is thereby identifiable, but the preceding Izumi/nondegeneracy estimates remain section dependencies. Proposition 6.29 obtains a finite-energy accumulation point from normalized energy bounds, then uses upper semicontinuity and weak integral continuity to prove strong completeness; only a tail of a Cauchy net need be bounded, not all early incomparable indices. Theorem 6.30 requires smooth X and trivial/discrete residue-characteristic-zero k and continuous envelopes. Orthogonality is imported from BFJ15 with an original technical condition, then BGJKM16 Theorem 6.3.2 removes that condition; differentiability imports BFJ15 Theorem 7.2. The trivial-field proof continues beyond this selected page. No general-field envelope theorem or BJ22 homogeneous Siu repair follows.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
