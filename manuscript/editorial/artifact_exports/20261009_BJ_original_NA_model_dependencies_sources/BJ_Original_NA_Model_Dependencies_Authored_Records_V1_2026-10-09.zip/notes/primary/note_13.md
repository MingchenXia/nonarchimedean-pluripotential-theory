# Original NA/model dependency review — view 13

Source: BoJ18a_arxiv_v1. Physical pages: [79].

Read the complete selected text and individually displayed the matching rendered image.

BoJ18a physical 79 finishes the bibliography and author details. The distinct Hodge-index input is Yuan–Zhang's arithmetic Hodge theorem for adelic line bundles, while psh singularities/Izumi and Berkovich compactness have separate original references. Kontsevich–Tschinkel is explicitly unpublished and is mentioned only as a Dirac-case sketch, not a controlling verified general proof. This completes the prepared BoJ18a selection of 25 physical pages in 13 displays: 1–6, 51–58, 65–72 and 77–79. It is partial (54 of 79 pages not freshly read here); especially 59–64 and 73–76 contain proof dependencies still missing from this round. No complete BoJ18a proof audit or generic-field MA/envelope certification is claimed.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
