# Original NA/model dependency review — view 4

Source: BoJ18a_arxiv_v1. Physical pages: [51, 52].

Read the complete selected text and individually displayed the matching rendered image.

BoJ18a physical 51–52 begins finite energy for arbitrary non-Archimedean k and geometrically integral X with ample L, then explicitly restricts the compactness claim to smooth X and trivial/discrete residue-characteristic-zero k. Proposition 6.2 extends E by dominating FS infima, proves upper semicontinuity using sup(phi-psi0) continuity, and deduces decreasing-net continuity. Its concavity proof has local variable slips: E(phi_j) should be E(psi_j), and the limiting second E(phi) should be E(psi). The intended concavity follows after this correction. Corollary 6.4's E sublevels are weakly closed, while compactness in 6.5 uses the restricted psh compactness theorem. Proposition 6.6 extends the fixed-degree energy polynomial along affine metric segments; its claim of decreasing corrections for an arbitrary convergent rational parameter sequence needs a controlled subsequence or the bounded-metric sup-norm continuity argument. The polynomial-net passage can instead be justified by interpolation at n+2 points, not an illicit assertion that every net is a sequence. Proposition 6.7 preserves E under field extension and gives the one-sided Gauss-restriction inequality E(phi' composed sigma)>=E(phi'), using the invariant domination property and decreasing nets. Earlier psh regularization, sup continuity and Gauss domination remain imported section dependencies.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
