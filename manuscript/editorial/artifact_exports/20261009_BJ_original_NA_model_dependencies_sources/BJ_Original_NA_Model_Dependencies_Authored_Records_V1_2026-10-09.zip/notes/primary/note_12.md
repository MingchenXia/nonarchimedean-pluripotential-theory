# Original NA/model dependency review — view 12

Source: BoJ18a_arxiv_v1. Physical pages: [77, 78].

Read the complete selected text and individually displayed the matching rendered image.

BoJ18a physical 77–78 bibliography authenticates the original dependency identities, not their proofs. BFJ15 is JAMS 28 (2015), 617–667 and BFJ16a JAG 25 (2016), 77–139. BGJKM16 is arXiv:1608.01919 with Lazarsfeld appendix and is the cited removal of the technical algebraicity condition in orthogonality/solvability; GJKM17 is arXiv:1712.00980 and the test-ideal envelope work under stated additional assumptions. Folland second edition is the Radon/monotone-integral reference. The bibliography's in-preparation BoJ17 and BBJ17 entries are historical and identify the old citation chain; they do not authenticate current publication versions or a current general-envelope result. Physical 73–76, including most estimate proofs and Lemma 6.17, remain unread in the main selected scope.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
