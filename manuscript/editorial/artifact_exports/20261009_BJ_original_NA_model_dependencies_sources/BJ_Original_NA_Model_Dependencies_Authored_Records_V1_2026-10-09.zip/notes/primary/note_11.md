# Original NA/model dependency review — view 11

Source: BoJ18a_arxiv_v1. Physical pages: [71, 72].

Read the complete selected text and individually displayed the matching rendered image.

BoJ18a physical 71–72 finishes the strong MA homeomorphism: uniform pairing estimates on energy-bounded sets and the identities E*=I-J recover I-convergence from weak-plus-dual-energy convergence. Representative metrics still require constants to be fixed, since only the quotient is controlled. Proposition 7.27's printed proof obtains a weak maximizing accumulation point but stops before the claimed strong convergence: one must use continuity of the mu pairing on E1_C to get E(phi_j)=F_mu(phi_j)+integral(phi_j-phi_ref)mu along each subnet, then uniqueness and weak compactness to conclude weak-plus-energy convergence of the full net. This is a fillable proof step using already stated results, not a claim of an original theorem. Remark 7.28 gives a P1 example where equal positive-energy Dirac masses escape weakly to the trivial point while energy drops to zero; to ensure identical local energy over a nonclosed ground field one can choose distinct rational points, retaining degree normalization. This rules out reading weak compactness as strong compactness. Appendix A starts with the finite atomic Izumi/reference bound and proves I(t phi+(1-t)psi,psi)<=n t^2 I(phi,psi) by the binomial bound 1-(1-t)^n<=nt. The subsequent mixed-energy proof continues outside this selected page, and Lemma 6.17's proof at physical 76 remains unread.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
