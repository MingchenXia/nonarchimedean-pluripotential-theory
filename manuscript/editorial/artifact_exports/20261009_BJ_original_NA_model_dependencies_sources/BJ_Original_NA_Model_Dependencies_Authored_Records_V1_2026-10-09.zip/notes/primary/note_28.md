# Original NA/model dependency review — view 28

Source: Berman_KE_polystability_arxiv_v3. Physical pages: [39, 40].

Read the complete selected text and individually displayed the matching rendered image.

The selected final discussion uses openness of the continuity-method parameter and a lower bound for a neighboring Ding functional to deduce properness; its preceding theorem and parameter definitions have not been selected, so this tail is not a full proof audit. The assertion klt surfaces are quotient singularities concerns normal Q-Gorenstein surfaces and does not make arbitrary Fano surfaces smooth. The bibliography identifies the external quasi-PSH compactness input as Guedj–Zeriahi, Intrinsic capacities on compact Kahler manifolds, JGA 15 (2005), and the singular KE/full-mass input as the log-Fano variational paper 1111.7158. It also identifies the Deligne metric sources Elkik and Moriwaki, the inversion-of-adjunction sources, and Chen–Tang for rays. Historical in-preparation and to-appear records do not establish current source status. No recursive certification of these imported arguments is recorded.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
