# Original NA/model dependency review — view 25

Source: Berman_KE_polystability_arxiv_v3. Physical pages: [11, 12].

Read the complete selected text and individually displayed the matching rendered image.

The completed special-configuration definition requires reduced irreducible klt Fano central fiber and Q-Gorenstein total space. Lemma 2.2 imports normality of a flat family with normal fibers and inversion of adjunction; its intermediate multiples m of the Q-line bundles must be kept consistent. The Deligne curvature formula (2.4) literally omits the phi_0 factor: a relative n-dimensional family requires the product of n+1 curvatures before fiber integration. The preceding Chern-class formula and the next change-of-metric identity show the intended convention. Berman's energy in (2.5) contains 1/(n+1) but no 1/V, hence E(phi+c)-E(phi)=Vc. The normalized book energy is E/V. The Deligne weight difference is (n+1)E in this unnormalized convention, and the energy derivative integrates against the mass-V Monge–Ampere measure. Extension to finite energy is cited externally in Remark 2.3; the argument used for the ensuing ray construction remains in the locally bounded setting. These elementary normalization checks do not certify the imported singular Deligne-pairing or inversion-of-adjunction theorems.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
