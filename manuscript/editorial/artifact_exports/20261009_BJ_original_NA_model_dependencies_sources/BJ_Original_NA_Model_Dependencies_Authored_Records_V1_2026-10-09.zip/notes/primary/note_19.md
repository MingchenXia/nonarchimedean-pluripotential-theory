# Original NA/model dependency review — view 19

Source: BoJ18b_arxiv_v1. Physical pages: [31, 32].

Read the complete selected text and individually displayed the matching rendered image.

The valuation norm is initially defined on function-field valuations. The printed claim that the minimum jumping number is zero for every degree needs eventual global generation (and nonempty degree pieces); small ample powers can have a basepoint at the valuation center. Theorem 5.13 claims a continuous Dirac-mass potential for every nonpluripolar point. For the quasimonomial case one must choose an SNC model containing the point and refine so it becomes a vertex; the inverse-limit description alone does not supply that particular model. The barrier proof invokes the continuous envelope theorem and orthogonality from BoJ18a. Its comparison at the intermediate step is with the constructed piecewise affine barrier, rather than with the yet unidentified extremal metric. The displayed energy arithmetic is reversed: E equals the supremum minus J, hence phi_x(x_generic) minus J equals S, not J minus phi_x(x_generic). For a general nonpluripolar point the retraction net, finite S and T, monotone Monge–Ampere continuity, and the maximum argument identify a finite-energy solution with the raw extremal supremum. Continuity of the general limit remains to be checked on the next page: bounded increasing continuous metrics do not alone imply continuity. The generic point has S=T=0 and zero potential. These are scoped proof-reading observations, not a counterexample to the intended theorem or a resolution of BJ22 Siu decomposition.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
