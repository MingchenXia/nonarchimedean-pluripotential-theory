# Original NA/model dependency review — view 18

Source: BoJ18b_arxiv_v1. Physical pages: [29, 30].

Read the complete selected text and individually displayed the matching rendered image.

BoJ18b physical 29–30 defines T(x)=sup(sup phi-phi(x)) and pluripolarity using psh metrics. Points with proper algebraic support are pluripolar by a vanishing section; infinite T is realized by a normalized decreasing convex-sum construction whose generic-point value stays finite. The polarization-independence proof correctly chooses L'-epsilon L ample but then prints the resulting metric in PSH(L'') rather than PSH(L'); the background is L'. S(x)=E*(delta_x) has finite energy exactly when T is finite, with a later sharper S/T comparison pending. Proposition 5.5 E*(mu)<=integral S dmu is a one-sided convex-dual bound, not equality for arbitrary mixtures. Proposition 5.6 proves quasimonomial points nonpluripolar and S/T continuity on each SNC dual complex using BoJ18a Theorem 5.29's restricted equicontinuity. It does not identify every nonpluripolar point as quasimonomial. Retraction approximation is a directed SNC net, and lower semicontinuity is global rather than uniform continuity over all of X. Scaling homogeneity of S/T uses the valuation dilation with the associated metric action, not a naive scalar multiplication of a fixed metric. These are the actual inputs behind BBJ21 Lemma 7.4's finite-energy Dirac masses.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
