# Original NA/model dependency review — view 3

Source: BoJ18a_arxiv_v1. Physical pages: [5, 6].

Read the complete selected text and individually displayed the matching rendered image.

BoJ18a physical 5–6 frames the Legendre/MA route to K/Ding stability and valuations as applications, not independent proofs at introduction level. Stability functionals are translation invariant, so introductory equality phrases must be interpreted modulo constants or with a normalization; the same page correctly writes J=0 iff phi=phi_triv+c. The generalization paragraph explicitly leaves arbitrary valued fields, big line bundles, singular bases and pairs outside its established scope. Its positive-characteristic discussion cites test-ideal envelope results under resolution and descent from a perfect-field family; this dated source description is not a current 2026 survey or a universal envelope theorem. Compactness relies on dual complexes and the discrete/trivial characteristic-zero hypotheses. The proof estimates are deferred to Appendix A, which is not fully included in the present selected reading.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
