# Original NA/model dependency review — view 17

Source: BoJ18b_arxiv_v1. Physical pages: [27, 28].

Read the complete selected text and individually displayed the matching rendered image.

BoJ18b physical 27–28 makes the Okounkov lattice issue explicit: the claimed r^{-1}Z^n intersection equals r^{-1}Gamma_r in compact interiors cannot hold for k[x^2,y^2] in the ambient full lattice. The referenced Bou14 Lemma 1.13 needs its original saturation/index assumptions. Lemma 4.17's relative-energy proof prints (phi'-phi) although it assumes phi>=phi' and later E(phi,phi')=c>=0; the displayed nonnegative inequality requires (phi-phi') and consistent mixed background. The intended ordered strictness uses I=0 implies equality modulo constants, then E removes the constant. Theorem 4.16 and the rooftop distance use exactly the source's asymptotic-FS/Q conventions; the definition pages must be read before claiming equality of raw metrics. Lemma 4.19 establishes equivalence to the supremum norm, but its asserted smallest representative among all equivalent norms is not separately proved in the displayed paragraph until the later injectivity conclusion is available. Conjecture 4.22 explicitly asks P(rooftop)=Q(rooftop) for the regularizable-from-below class; its 2018 conjectural status is historical, and it is not automatically a new canonical open atom in 2026. The final filtration stability argument assumes the stronger Mabuchi inequality on all E1, retains lsc entropy and the divisibility-directed net, and uses centered moments rather than uncentered norm weights.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
