# Original NA/model dependency review — view 5

Source: BoJ18a_arxiv_v1. Physical pages: [53, 54].

Read the complete selected text and individually displayed the matching rendered image.

BoJ18a physical 53–54 separates the trivial-field scaling action (E(phi_t)=t E(phi)) from ordinary scalar interpolation. Theorems 6.9/6.11 assert mixed-MA and energy-integral continuity for finite-energy decreasing/increasing nets; increasing limits need not converge pointwise at every analytic point. Their proofs are deferred to section 6.8, outside physical 51–58. Continuous test functions are handled through uniform density of DFS functions. Corollary 6.14's proof claims arbitrary uniformly converging nets can be made decreasing by adding small constants; this needs justification and is not immediate for arbitrary oscillating nets. The intended uniform continuity can instead be approached through the energy estimates; no complete repair is certified here. Lemma 6.17 is exactly the Ding scaling estimate J_psi(t phi+(1-t)psi)<=t^{1+1/n}J_psi(phi), with proof deferred to Appendix A (physical 76) and not yet read in this selection. Proposition 6.18 is weak continuity of integration against MA(psi) only on normalized energy-bounded E1_C sublevels; it is not integration against every Radon measure. Rigid Dirac masses are explicitly given as a failure boundary.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
