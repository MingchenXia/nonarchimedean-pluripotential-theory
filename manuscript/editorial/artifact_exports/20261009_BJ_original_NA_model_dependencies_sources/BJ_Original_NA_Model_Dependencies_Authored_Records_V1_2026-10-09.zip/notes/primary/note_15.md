# Original NA/model dependency review — view 15

Source: BoJ18b_arxiv_v1. Physical pages: [3, 4].

Read the complete selected text and individually displayed the matching rendered image.

BoJ18b physical 3–4 distinguishes adjoint K-stability defined on E1 from the test-configuration notion, with a stated entropy approximation conjecture 2.5 outside the Fano special case. Adjoint Ding inequalities extend by decreasing continuity; the corresponding Mabuchi assertion is not obtained from the same argument. Its graded norms are exponentially bounded in original degree and submultiplicative on products. Theorem B speaks about psh metrics regularizable from below, and Theorem C uses canonical psh asymptotic FS; it must not be transplanted to raw lower-semicontinuous FS without inspecting the operator definition, given the later published raw/usc distinction. Finite-p equivalence concerns all p in [1,infinity), not normalized operator distance at infinity. Relative volume is a signed barycenter, while d1 involves both rooftop energies. The variance of the filtration measure measures the centered L2 norm and vanishes for a constant metric; it is not the uncentered second moment. The exact asymptotic-FS construction follows in the selected physical 25 onward.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
