# Original NA/model dependency review — view 24

Source: Berman_KE_polystability_arxiv_v3. Physical pages: [9, 10].

Read the complete selected text and individually displayed the matching rendered image.

The KE equation has total Monge–Ampere mass V=c1(-K_X)^n; the right side is V times a probability measure. The metric is locally bounded, indeed continuous by the imported singular KE regularity result. Relative canonical measures are described using a local trivialization of the base canonical bundle, and normal test configurations may have nonreduced central fiber. Relatively semiample configurations are explicitly distinguished from relatively ample ones. The Donaldson–Futaki invariant uses the determinant weight's subleading coefficient with a factor 1/2 in this source, so later comparisons must preserve the logarithmic time and squared-metric conventions. In Example 2.1 the literal Futaki identity F(X,V)=-F(X,V) omits the sign change on V; the intended identity compares V with -V. Product configurations can carry nontrivial actions, and equality in polystability must not be confused with trivial action. This selection begins but does not finish the definition of a special configuration.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
