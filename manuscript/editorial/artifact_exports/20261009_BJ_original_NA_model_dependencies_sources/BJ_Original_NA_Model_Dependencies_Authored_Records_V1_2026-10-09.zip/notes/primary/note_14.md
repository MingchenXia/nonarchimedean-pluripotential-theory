# Original NA/model dependency review — view 14

Source: BoJ18b_arxiv_v1. Physical pages: [1, 2].

Read the complete selected text and individually displayed the matching rendered image.

BoJ18b physical 1–2 pins arXiv:1805.11160v1 with margin 28 May 2018 and internal date 30 May 2018. Its exact category is a smooth projective polarized variety in characteristic zero, trivially valued. The positive/continuous/bounded/E1 metric classes are distinct; J=sup-E is nonnegative and vanishes for all constants. MA is probability-normalized and is bijective only modulo constants, imported from BoJ18a/BFJ15. In the Fano case M=Ent(MA)-E*(MA), with NA entropy integral of log discrepancy; D=L-E, L=inf(phi+A). M may be +infinity, while E* is finite on the finite-energy measure domain. The introduction's K/Ding criteria are on ample test-configuration metrics before extension to E1, and use exactly this characteristic-zero smooth framework. It does not supply a proof independent of BoJ18a's original compactness/envelope/MA inputs.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
