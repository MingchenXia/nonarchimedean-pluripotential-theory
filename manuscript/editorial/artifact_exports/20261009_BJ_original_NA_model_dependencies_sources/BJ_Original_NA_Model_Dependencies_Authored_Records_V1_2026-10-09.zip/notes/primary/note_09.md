# Original NA/model dependency review — view 9

Source: BoJ18a_arxiv_v1. Physical pages: [67, 68].

Read the complete selected text and individually displayed the matching rendered image.

BoJ18a physical 67–68 completes Corollary 7.10 with a reversed background comparison: CL2-L1 ample does not imply C*varphi2 is L1-psh. A valid direction uses CL1-L2 ample and varphi2/C with a compatible bounded reference, retaining finite energy. Proposition 7.11 has correct one-sided dual-energy field pushforward and equality for the Gauss pushforward using pi_*sigma_*=id. Proposition 7.12's scaling proof cites nonexistent Proposition 6.7(iii); the relevant metric scaling is 6.8/6.20. The proof of Theorem 7.3 explicitly maximizes F_mu, despite stray 'minimizer' words in section 7.3 and Corollary 7.17. Lemma 7.13 uses the envelope differentiability Corollary 6.32 to test every continuous f and identify MA(phi)=mu; that finite-energy envelope differentiability is a substantial original dependency not fully read in physical 51–58. Corollary 7.14 passes discrete solutions back through Gauss invariance using equality of MA and normalized suprema; a subscript F_mu is printed where F_mu' is needed. Corollary 7.15 uses compact normalized E1_C and the corrected coercive localization estimate. Model dual-complex measures have finite energy because psh restrictions there are finite and continuous; the existence argument continues next.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
