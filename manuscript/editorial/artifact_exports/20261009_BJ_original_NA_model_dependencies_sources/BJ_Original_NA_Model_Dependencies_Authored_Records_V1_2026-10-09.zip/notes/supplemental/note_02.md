# Supplemental original NA/model dependency review — view 2

Source: BoJ18a_arxiv_v1. Physical pages: [61, 62].

Read the complete selected text and individually displayed the matching rendered image.

The proof of Theorem 6.9 uses Radon monotone convergence for decreasing upper semicontinuous nets, rather than a sequence-only dominated convergence theorem on an arbitrary Berkovich space. Its limiting lower bound at the end of (ii) should be B-prime, not the earlier nonnegative B. The weak upper pairing bound is combined with approximate monotonicity, Lemma 6.33; this lemma telescopes positive mixed MA terms after integration by parts. Any ordered FS regularization used there must preserve chi_i>=phi_i, for instance with compatible maxima. These steps extend the mixed measure and finite-energy pairings simultaneously, not merely ordinary weak convergence against continuous tests. The increasing-net proof begins by uniformly replacing finite-energy mixed measures with FS mixed measures using Corollary 3.19, then uses finite atomic support at quasimonomial points where the relevant increasing convergence is available. It does not assert convergence at every analytic point. Subsequent induction on the number of moving factors remains to be read.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
