# Supplemental original NA/model dependency review — view 3

Source: BoJ18a_arxiv_v1. Physical pages: [63, 64].

Read the complete selected text and individually displayed the matching rendered image.

The increasing mixed-MA proof completes the induction by integration by parts and a two-index squeeze. The moving factors are replaced one at a time; finite-energy test-potential pairing convergence is stronger than continuous-test weak convergence. The source explicitly limits Calabi–Yau existence to smooth projective X, ample L and trivially or discretely valued k of residue characteristic zero, despite defining the variational problem in broader settings. Probability normalization makes F_mu invariant under constant shifts of the potential. Proposition 7.2's proof literally prints E(psi)-E(phi)-integral(psi-phi)MA(phi)=J_phi(psi)>=0; concavity makes this -J_phi(psi)<=0, which is the inequality needed to take a supremum at phi. The intended dual identity E*(MA(phi))=(I-J)(phi) has the correct value and is consistent with the corrected sign. Atomic quasimonomial measures have finite dual energy through Izumi; the passage does not assert this for arbitrary point masses.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
