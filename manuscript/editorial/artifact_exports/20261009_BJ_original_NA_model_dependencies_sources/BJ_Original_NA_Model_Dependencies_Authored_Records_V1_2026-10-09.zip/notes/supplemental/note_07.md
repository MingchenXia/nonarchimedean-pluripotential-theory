# Supplemental original NA/model dependency review — view 7

Source: BoJ18b_arxiv_v1. Physical pages: [24].

Read the complete selected text and individually displayed the matching rendered image.

The exact general asymptotic definition on page 24 is FS(norm_bullet)=usc lim_m phi_m=usc sup_m phi_m. Thus first-pass Theorem 4.16 concerns upper-regularized metrics, and the previously recorded raw-FS point-jump example is not a counterexample to that intended equivalence theorem. Small nonglobally-generated degrees are excluded by the eventual large-degree premise; common multiples give an increasing divisibility net and factorial degrees provide a countable cofinal subsequence of that integer divisibility index. Proposition 4.8 confirms a degree-linear scalar norm shift produces the opposite metric shift, and a Veronese restriction requires division by r to recover the original polarization. Formula (4.4) repeats phi in its two left inputs while its right side uses phi and phi-prime; the second norm should be phi-prime. Proposition 4.9 identifies the upper-regularized positive-metric envelope with the upper-regularized FS of its supremum norm; its remaining proof was already selected on page 25. The completed supplemental reading covers 13 additional source-page pairs in seven views, bringing the fresh combined scope to 68 unique source-page pairs in 36 individually reviewed views: BoJ18a 35/79, BoJ18b 20/39 and Berman v3 13/41. Each source remains partial. No general BJ22 envelope or homogeneous Siu statement is certified by these restricted older imports.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
