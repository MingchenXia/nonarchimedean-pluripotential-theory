# Supplemental original NA/model dependency review — view 5

Source: BoJ18a_arxiv_v1. Physical pages: [75, 76].

Read the complete selected text and individually displayed the matching rendered image.

The appendix finishes the mixed-measure pairing estimates with the square-root exponents 1/2^n and a common J bound. Lemma 3.22 first normalizes maxima and uses the reference discrepancy constant D_ref plus concavity; it then expands the average curvature and keeps the sign of the nonpositive potential when comparing mixed terms. Lemma 3.23 controls integration against a signed difference of MA measures, again preserving cancellation of constants. The complete proof of Lemma 6.17 is now read: for phi_t=t phi+(1-t)psi, the derivative of J_psi(phi_t) is t^{-1} I(phi_t,psi), and I >= (n+1)/n J makes J_psi(phi_t)/t^{1+1/n} nondecreasing on (0,1]. Hence J_psi(phi_t)<=t^{1+1/n}J_psi(phi). This is the quantitative scaling used by the dual-energy coercivity argument; it is not the degree-weight scaling of a graded norm. The extra selected pages bring BoJ18a to 35 of 79 physical pages, with 44 still unread. No whole-source or whole-book reading is claimed.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
