# Supplemental original NA/model dependency review — view 4

Source: BoJ18a_arxiv_v1. Physical pages: [73, 74].

Read the complete selected text and individually displayed the matching rendered image.

The appendix estimates derive iterated square-root exponents 1/2^(n-1) from the Cauchy–Schwarz recurrence b_{p+1}<=b_p+4 sqrt((n+1)B b_p); n-dependent constants are obtained by an explicit induction. The seminorm proof of the quasi-triangle inequality for I must use max_i norm(phi_i-phi_3), not the repeated phi_1-phi_3 in the printed intermediate display. Corollary 3.17's substitution likewise needs phi_3=psi rather than phi_3=phi. The mixed-measure estimate pairs a potential difference with a signed difference of equal-mass measures, so additive constants cancel; it does not assert that an absolute potential integral is controlled by a constant-invariant I seminorm. This distinguishes it from the literal constant-shift counterexample already recorded for published BBJ Lemma A.2. Corollary 3.18's averaging formula divides by n-1 and therefore needs the one-dimensional case treated separately. These readings concern the finite FS estimates and their explicit dimensional constants, with the opening setup already present on the previously read page 72.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
