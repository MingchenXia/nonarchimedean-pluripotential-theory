from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction as F
from itertools import product
import hashlib, json, math, platform, subprocess, zipfile

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/GitHub_incoming_P12_3_continuation306_20261009'
E=R/'manuscript/editorial'
sha=lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda: datetime.now(timezone.utc).isoformat()
def fresh(p, value):
    assert not p.exists(), str(p)
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(value.rstrip()+'\n')
def record(p,v): fresh(p,json.dumps(v,ensure_ascii=False,indent=2))
def item(p): return dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p))

acq=json.loads((C/'acquisition_v1_20261009.json').read_text())
for a in acq['files']:
    assert sha(a['local_path'])==a['SHA256']
    assert Path(a['local_path']).stat().st_size==a['bytes']
old=R/'source_material/GitHub_incoming_P12_3_continuation302_20261009'
old_bytes=(old/'P12.3-conductor-and-threefold.tex').read_bytes()
old_grant=old_bytes.split(b'\\begin{EntireQualifiedG331}\n',1)[1].split(b'\\end{EntireQualifiedG331}',1)[0]
new_grant=(C/'qualified-G331.txt').read_bytes()
assert old_grant==new_grant+b'\n'
assert json.loads((C/'qualified-G331.json').read_text())['text'].encode()==new_grant
old_receipt=old/'actual_scoped_reading_v1_20261009.json'
prior=json.loads(old_receipt.read_text())
assert all(x['actual_read'] for x in prior['entire_qualified_G331']['actual_chunks'])
assert prior['whole_source_SHA256']==sha(old/'P12.3-conductor-and-threefold.tex')
native=json.loads((C/'native294-actual-FINAL-all-five-fields.json').read_text())
assert len(native['notes'])==5 and native['candidate'] is False
assert all(set(n)=={'id','summary','detailedSummary','text','support'} for n in native['notes'])

weights=[F(1),F(5,4),F(3,2),F(2),F(3),F(7),F(20),math.inf]
pairs=[(s,z) for s,z in product(weights,repeat=2) if min(s,z)==1]
canonical=competitors=membership=gaps=0
for m in range(1,65):
    cm=(3*m+1)//2
    expected=F(cm,m)-1
    assert expected==F(1,2)+(F(1,2*m) if m%2 else 0)
    s=F(cm-m+1);z=F(1)
    assert F(cm,m)-1==min(cm*z,s+m-1)/m-1
    gaps+=1
    for s,z in pairs:
        hp=-min(cm*z,s+m-1)/m
        pp=F(-3,2) if math.isinf(s) else F(-1)
        hm=-min(cm*z,s+cm-1)/m
        obstacle_minus=min(s,2)/2-2
        assert hp<=-1 and hm==F(-cm,m) and hm<=obstacle_minus
        assert 0<=pp-hp<=expected and 0<=F(-3,2)-hm<=expected
        canonical+=2
        qp=max(F(-3,2),-1-s/F(2*m))
        qm=-min(3*m,m*s+2*m)/F(2*m)
        assert qp<=-1 and qm==F(-3,2) and qm<=obstacle_minus
        competitors+=2
    for i,j,k in product(range(7),repeat=3):
        order_test=(1+i+k>=m and 1+j+k>=cm)
        ideal_test=(i+k>=m-1 and j+k>=cm-1)
        assert order_test==ideal_test
        membership+=1

power=0; limits=0
ys=[F(1),F(3,2),F(2),F(4),F(20),math.inf]
az=[F(0),F(1,3),F(1,2),F(1),F(2),F(5),F(20),math.inf]
ns=[1,2,3,5,11,64]
for L,Y,a,n in product(range(3,17),ys,az,ns):
    obstacle=-1-(min(Y+a,L)-min(Y,L))
    q=-1-min(Y/n+a,L)
    assert -L<=obstacle<=-1 and q<=obstacle
    if math.isinf(Y): assert obstacle==-1
    power+=1
for L,r in product(range(3,17),[F(1),F(2),F(3),F(9),F(100)]):
    N=math.ceil(r*100)
    val=-1-min(r/N+1,L)
    assert -F(201,100)<=val<=-2
    assert -L<=-2 and L-2>0
    limits+=1

# Verify the downstairs membership y(t-s)^n without importing supplied code.
# A monomial y*t^a*s^b becomes (y*t^(a mod e))*u^(a//e)*s^b.
downstairs=0
for e,n in product(range(2,13),range(1,33)):
    original={(i,n-i):math.comb(n,i)*(-1)**(n-i) for i in range(n+1)}
    grouped={(i//e,i%e,j):a for (i,j),a in original.items()}
    reconstructed={(q*e+r,j):a for (q,r,j),a in grouped.items()}
    assert reconstructed==original
    assert all(0<=r<e for q,r,j in grouped)
    downstairs+=1
counts=dict(self_crossing_canonical_profiles=canonical,self_crossing_primary_competitor_profiles=competitors,
    self_crossing_exact_gap_witnesses=gaps,self_crossing_conductor_monomial_membership=membership,
    power_cover_truncation_inequalities=power,power_cover_path_limit_samples=limits,
    power_cover_downstairs_polynomial_identities=downstairs)
checks=C/'own_exact_adversarial_checks_v1_20261009.json'
record(checks,dict(UTC=now(),status='PASS — finite exact observations only',counts=counts,
    rational_weights=[str(x) for x in weights],normalized_pairs=[[str(s),str(z)] for s,z in pairs],
    degrees=[1,64],membership_box=[0,6],power_parameters=dict(L=[3,16],Y=[str(x) for x in ys],a=[str(x) for x in az],n=ns),
    limits=dict(r=['1','2','3','9','100'],N='ceil(100r)',max_error='1/100'),
    identities=dict(exponents=[2,12],degrees=[1,32],coefficient_domain='integers; no source characteristic extension inferred'),
    proof_certification=False,universal_all_support_proof_verified=False,source_programs_executed=False,
    Python=platform.python_version(),helper_source=__file__,helper_SHA256=sha(__file__)))

reading=C/'actual_scoped_reading_v1_20261009.json'
lines=(C/'P12.3-marked-centres.tex').read_bytes().splitlines(keepends=True)
core=b''.join(lines[:313])
record(reading,dict(UTC=now(),status='ACTUAL SCOPED SOURCE READING — UNVERIFIED original deductions',
    remote_commit=acq['remote_commit'],source_files=acq['files'],
    paper426=dict(whole_source=item(C/'P12.3-marked-centres.tex'),actual_core_lines=[1,313],
        core_bytes=len(core),core_SHA256=hashlib.sha256(core).hexdigest(),all_five_current_expanded_proofs_read=True,
        truncated_181_313_ledger_display_repaired_by_complete_241_313=True,
        later_lines_from_314_read=False,whole_5030_line_source_read=False),
    paper425=dict(source=item(C/'P12.3-continuation425-working-paper.tex'),whole_current_working_paper_read=True,
        source_lines=[1,374],complete_bounded_reads=[[1,150],[151,374]],read_as='inert mathematical text'),
    actual_native294_FINAL=dict(source=item(C/'native294-actual-FINAL-all-five-fields.json'),
        all_five_fields_of_all_five_notes_read=True,bounded_output_chunk_ids=['6a193f','ded773','107a36','8fdf93','c6cd03'],
        independently_attested_model_settings=False,independent_production_verifier_receipt=False),
    full_metadata_records_read=['README.md','current-research-status.json','scoped-verdict.md','original-residual.md','source-application-reading-ledger.md'],
    G331=dict(current=item(C/'qualified-G331.txt'),JSON_text_byte_identical=True,
        prior_reading_receipt=item(old_receipt),prior_complete_scope_read_carried_by_exact_byte_identity=True,
        prior_wrapper_separator_difference='one final LF outside the grant',
        current_grant_plus_single_LF_SHA256=hashlib.sha256(new_grant+b'\n').hexdigest(),
        new_full_body_read=False,new_primary_PDF_reading_credit=0,
        accepted_in_book=False,status='conditional supplied research grant; not independent acceptance'),
    unacquired_unread_companion=True,new_immediate_primary_carriers_read=False,
    supplied_programs_executed=False,active_native296_math_read=False,book_changed=False,native_editor_changed=False,
    original_results_promoted=[],canonical_status_changes=[],independent_production_verifier_receipt=None))

note='''# Own scoped continuation306 proof reading, 9 October 2026

Status: UNVERIFIED original deductions, conditional on the entire supplied G331 comparison and transport result. No exact-current independent production-verifier receipt is present. This is an editorial proof audit, not a verified closure of ORIGINAL P12.2 or P12.3.

The fixed research snapshot is `47246110a56af214776920dc8d4822bed2b38c83`. Read the complete current core of paper426, lines1–313, all five actual native294 FINAL objects including each summary/detailedSummary/text/support/id, the complete 374-line working paper425, and the separate source ledger/current metadata/verdict/residual. The later retained body of the 5,030-line paper426 is unread; the companion was neither acquired nor read. Incoming assertions of fourteen primary readings describe another research audit and do not become this audit's physical-reading credit. One combined output truncated the ledger; the complete lines241–313 were subsequently displayed and read. Failed initial path lookups supplied no reading.

The current 93,375-byte full qualified G331 text is exactly the previously completely read continuation302 grant, except that the old TeX wrapper supplies one extra final LF. The nine prior full-chunk reading records remain controlling; no fresh whole-source credit is claimed. Its JSON text field has exactly the same bytes. All real-Cartier, actual-primary-model, all-contracted-curve, all-support, full-conductor-fibre, BFJ, gauge/completion, source and historical-audit qualifications remain attached. The source's `verified:true`/`imported:true` fields are research data; `accepted:false` and the absent exact-current book production receipt prevent book acceptance. Full recursive primary-source clearance remains incomplete.

## Canonical calculation and distinct-centre obstruction

Paper426 reconstructs the obstacle ideals A_m by tests on every normalized support. Primary inclusion bounds finite profiles; multiplication gives a grading. Proper/unit cases, integral closure and quotient-support values are kept separate. The directed compact-open argument comparing decreasing C-nets with continuous minorants uses one common index from a finite cover, and does not flatten arbitrary nets. Rational-primary approximation identifies the raw supremum with sup_m h_m; finite generation implies continuity, while non-finite-generation alone gives no failure. Gauge transport divides every defining inequality by the same positive bounded continuous factor and leaves the ideals unchanged.

The marked-centre construction requires one full normalization fibre connecting two distinct closed normal local centres. A domain normalization can still be semilocal. Actual CRT elements replace nonexistent algebraic component idempotents. Multiplication by a regular conductor element makes their powers actual R-elements. The normal-centre order comparison is used only in the second normal local ring, with a fixed generic divisorial valuation and a constant uniform over all supports. Negative profile inequalities then extend through the qualified geometric comparison and decreasing infima. Finite-conductor first-centre competitors approach -1 along a dense net; the shared conductor value is forced below -D0/K. The contradiction concerns USC, and the perturbation bound is (D0-K)/(K+1). Having several centres without a common fibre does not suffice.

## Irreducible self-crossing and the surface criterion

For char(k) different from2, R=k[u,v,z]_(u,v,z)/(v^2-u^2(1+u)) is a domain, and t=v/u gives its finite semilocal domain normalization, with centres t=1 and t=-1. The conductor is uS=(u,v)R; the conductor quotient has two copies of the same z-ring. The normalization itself is not a product. The signed primary obstacle F=(1/2)v((v-u)+m^2)-2 has value -1 on the plus centre and values between -3/2 and -1 on the minus centre. The generic minus ordinary-order valuation bounds every negative geometric competitor by -3/2 on the whole minus image, including all conductor supports.

The actual conductor elements u(t+1)^(n-1) give primary competitors with plus profile max(-3/2,-1-s/(2n)) and constant minus profile -3/2. Thus the conditional raw envelope is -1 on the plus finite-conductor locus and -3/2 on the minus/conductor image. A monomial net with plus parameter weight tending to infinity witnesses the half-unit USC jump. Ordinary-order tests at both regular centres yield, in every degree,

    c_m=ceil(3m/2),
    A_m=(z)^(c_m)R+u(t-1,z)^(m-1)(t+1,z)^(c_m-1),
    ||p-h_m||=c_m/m-1.

The two semilocal primary powers are comaximal, so their product equals their intersection. Reducing modulo u forces the residue z-part into degree c_m; dividing the remainder by u lowers both order requirements by one. This checks the ideal identity with cancellation and local denominators, rather than deriving it from weight samples. Even-degree error is1/2; odd-degree error is1/2+1/(2m). The genuinely mixed-characteristic surface version needs an excellent DVR with2 invertible. Characteristic2 is not covered by this self-crossing calculation.

On the self-crossing surface the only nontrivial conductor fibre consists of two DVR quotient points. Conditional normal-surface envelopes H_+,H_- descend to a greatest minorant exactly when their conductor values agree. The lower-bound construction first obtains barriers B_i with the common value a=min H_i(o_i), then uses max(B_i,H_i-w((u)+a_i^N)/n). This is a primary truncation in C before the pointwise limit, with all-fibre positive descent; the fibrewise minimum alone is not asserted psh. The zero case uses the normal zero dichotomy. Unequal values force the explicit non-USC raw supremum. Source normal-surface CE remains dependent on the stated excellent-surface resolution and actual-model argument; the incoming audit's fresh primary-source claims are not independently reproduced here.

## Entire working paper425: a same-centre obstruction

Let e>=2 and d>=3, A=k[u,y,s,Z]_0 with u=t^e, S=k[t,y,s,Z]_0, and R=A plus the direct sum of y t^i A for1<=i<e. Polynomial grouping modulo e proves the finite module decompositions and uniqueness of the closed centre. These are excellent domains with the same fraction field, since t=(yt)/y. Multiplication by t tests the constant coefficient of an R-element, giving precisely conductor yS. The conductor quotient map is k[u,s,Z]_0 into k[t,s,Z]_0, and mS=(t^e,y,s,Z).

If char(k)=0, or if the prime-to-characteristic part of e exceeds1, a nontrivial e-th root of unity zeta exists in a finite residue extension kappa. The two source maps t=s and t=zeta*s, with y=Z=0 and s-order1, restrict to exactly the same target semivaluation o. This does not base-change the target problem or require zeta in k. Generic monomial y=r,s=1 after the second substitution gives v_r tending to o on every polynomial and on localized unit denominators. Completion convergence is checked by the leading finite s-order and the eventual weight bound r, without resolution.

Fix integer L>2. The actual continuous signed primary obstacle is

    F=-v(m)-v((y(t-s))+m^L)+v((y)+m^L).

For any normalized source lift, Y=w(y)>=1 and a=w(t-s)>=0 (possibly infinity), it is -1-[min(Y+a,L)-min(Y,L)], between -L and -1. Only finite truncations are subtracted. The conductor-infinite value is -1. The element y(t-s)^n lies in the actual conductor and hence in R. The primary ideal m^n(m^(Ln)+(y(t-s)^n)) gives

    q_n=-1-min(Y/n+a,L)<=F.

Its primary blowup has negative effective relatively ample Cartier divisor and positive degree on every contracted proper integral curve. At v_r the supremum of these competitors is -2. A fixed generic monomial valuation nu in regular coordinates s,z=t-s,y,Z, with z-weight L and all other weights1, is normalized and has F(nu)=-L.

For every target primary ideal I, choose a generator attaining finite o(I). Specialization z=y=Z=0 leaves a nonzero pure s^(o(I)) term; a generic weighted monomial valuation cannot cancel it. Unit denominators have value0. Consequently nu(I)<=o(I). Negation, the full geometric comparison and actual decreasing infima imply g(o)<=g(nu) for every C/D competitor. Any minorant of F therefore has g(o)<=-L, contradicting USC if it dominates every q_n along v_r. The compact directed-open argument identifies the C/D raw suprema. Continuity of each canonical primary profile gives an every-degree uniform error at least L-2. Uniform perturbations with2epsilon<L-2 retain failure.

An additional immediate conditional calibration: the constant -L is itself a core minorant since F>=-L. Together with the upper bound it gives p(o)=-L exactly. This sharpens a lower barrier in the working paper; it supplies no new independent verification or book theorem.

This does not contradict paper426's same-centre coercivity barrier. Here the divisorial valuation has z-weight L; its comparison constant can depend on L. Competitors approach -2, not an impossible dense -1 plateau at a fixed divisor with depth greater than its uniform order constant. The earlier CRT method remains unavailable within one centre, while this signed obstacle uses a different method.

If e is a p-power in characteristic p, every source conductor-quotient polynomial has its e-th power in the target ring, including coefficients over imperfect k. The extension formula w(f)=v(f^e)/e respects all supports and localizations. The full boundary is bijective and CE transports conditionally to the normal source. This is not an arbitrary positive-characteristic normal-source CE theorem. For the surface with s,Z omitted, the conductor DVR boundary has exactly one normalized lift for every e and every characteristic, even for separable algebraic covers. Thus the supplied normal-surface CE would transport to every such surface. Adding one coordinate gives the proposed nonnormal failure when e has nontrivial separable part; take e=2 except in characteristic2, where e=3 works.

## Independent finite observations and limits of the audit

The own standard-library helper uses exact Fractions for finite data, and infinity only for disclosed truncations. It checks canonical profiles, explicit-competitor inequalities, integer parity/gap witnesses, bounded conductor monomial membership, power-cover obstacle/competitor truncations, path approximations and the polynomial grouping of y(t-s)^n downstairs. It neither imports nor runs supplied native programs. The machine-readable output gives all counts and grids. Finite observations are not all-support proofs, geometric positivity certification, a characteristic-uniform resolution argument, or an independent verifier receipt.

The canonical42 atoms, twelve formal problems and tiers(0,3,7,15,17) remain unchanged. P12.2/P12.3 remain T4 OPEN; general excellent normal dimension>=3 CE, arbitrary finite conductor-cover classification, products, energy and full operators remain unresolved. The specific same-centre power-cover failure is an UNVERIFIED conditional candidate, not a closure of every same-centre case. BJ22 Theorem6.21 and its general homogeneous Siu/envelope issues receive no repair from these local computations. No whole-book rereading, native catalogue compilation, primary PDF reading, model-setting attestation, engine execution or original-result promotion is added by acquisition, arithmetic or upload.
'''
notes=C/'own_scoped_proof_reading_notes_v1_20261009.md'
fresh(notes,note)
base='P12_3_incoming_continuation306'
review=E/(base+'_scoped_review_v1_20261009.md')
fresh(review,note)
public_reading=E/(base+'_scoped_reading_notes_v1_20261009.md')
fresh(public_reading,'# Actual scoped reading record\n\nStatus: UNVERIFIED. Full current paper425, paper426 lines1–313, all five actual native294 FINAL objects and the separately pinned scope records were read. The entire current G331 body carries prior reading by exact byte identity with the fully read continuation302 grant; this is not fresh whole-grant reading. The later retained paper426 body and unacquired companion remain unread. No new primary PDF page or recursively complete source audit is claimed.\n\n```json\n'+json.dumps(json.loads(reading.read_text()),ensure_ascii=False,indent=2)+'\n```')
manifest=E/(base+'_scoped_manifest_v1_20261009.json')
record(manifest,dict(UTC=now(),status='SCOPED AUDIT — UNVERIFIED original claims',
    remote_commit=acq['remote_commit'],sources=acq['files'],reading_receipt=item(reading),own_notes=item(notes),checks=item(checks),
    full_book_PDF_SHA256=sha(R/'manuscript/book.pdf'),book_pages=4679,book_changed=False,
    native_catalogue_SHA256=sha(R/'output/open_problems_catalogue_2026-10-03.tex'),native_editor_changed=False,
    production_verifier_receipt=None,original_results_promoted=[],canonical_status_changes=[],
    new_primary_PDF_reading_credit=0,supplied_programs_executed=False))

dest=E/'artifact_exports/20261009_P12_3_incoming_continuation306_v1'
dest.mkdir(parents=True,exist_ok=False)
archive=dest/'P12_3_Continuation306_Scoped_Evidence_V1_2026-10-09.zip'
members=[(reading,'actual_scoped_reading_v1_20261009.json'),(notes,'own_scoped_proof_reading_notes_v1_20261009.md'),
    (checks,'own_exact_adversarial_checks_v1_20261009.json'),(C/'acquisition_v1_20261009.json','acquisition_v1_20261009.json'),
    (manifest,'public_scoped_manifest_v1_20261009.json'),
    (Path(__file__),'helpers/'+Path(__file__).name),
    (Path('/tmp/P12_3_acquire_continuation306_v1_20261009.py'),'helpers/P12_3_acquire_continuation306_v1_20261009.py'),
    (old_receipt,'prior_reading/continuation302_actual_scoped_reading_v1_20261009.json')]
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p,name in members:z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for p,name in members:assert z.read(name)==p.read_bytes()
fresh(dest/'README.md','''# continuation306 authored scoped audit evidence

The eight-member ZIP contains own reading notes, exact finite observations,
source/acquisition hashes, frozen own helpers and the previous full-G331
reading receipt. Every member was extracted and compared byte-for-byte.
Incoming research sources and native records, literal primary-source bodies,
pixels, whole book and unacquired companion are excluded. The incoming
sources already exist on the fixed research snapshot; only authored evidence
is republished. Original claims remain UNVERIFIED, with no independent
production-verifier receipt or canonical status change. Upload adds no
physical-reading or mathematical-verification credit.
''')
fresh(dest/'SHA256SUMS',sha(archive)+'  '+archive.name)
artifacts=E/(base+'_scoped_artifacts_v1_20261009.md')
fresh(artifacts,'# continuation306 scoped artifacts\n\nStatus: UNVERIFIED conditional original deductions.\n\n[Eight-member authored evidence](artifact_exports/20261009_P12_3_incoming_continuation306_v1/'+archive.name+')\n\nThe complete book remains4,679 pages and is unchanged. The native catalogue/editor remains unchanged. No primary full text or incoming source is added to the public ZIP.\n\nEvidence SHA256: `'+sha(archive)+'`.')
summary='''
## Incoming GitHub continuation306 audit, 9 October 2026

Read the complete conductor-power-cover working paper425, current paper426
lines1–313 and all five actual native294 FINAL objects at research commit
`47246110a56af214776920dc8d4822bed2b38c83`. The full qualified G331
carries previous complete reading by exact byte identity; no new recursive
primary audit is claimed. The later paper426 retained body and companion
remain unread. Distinct-centre self-crossing and same-centre nonradicial
power-cover failures remain UNVERIFIED conditional deductions. Radicial
higher-dimensional cases transport the unresolved normal-source problem;
surface conclusions retain the qualified excellent-normal-surface input.

See [scoped proof review](REVIEW) and [authored evidence](EVIDENCE).
Own exact finite checks include both canonical parity formulas and signed
power-cover inequalities. The4,679-page book, native catalogue/editor and
canonical42-atom problem statuses remain unchanged. No independent
production receipt is present; upload adds no proof or reading credit.
'''
for p,prefix in [(R/'README.md','manuscript/editorial/'),(E/'second_reading_and_research_programme_20261002.md','')]:
    text=summary.replace('REVIEW',prefix+review.name).replace('EVIDENCE',prefix+'artifact_exports/20261009_P12_3_incoming_continuation306_v1/README.md')
    p.write_text(p.read_text().rstrip()+'\n\n'+text.strip()+'\n')
files=[review,public_reading,manifest,artifacts,archive,dest/'README.md',dest/'SHA256SUMS',R/'README.md',E/'second_reading_and_research_programme_20261002.md']
record(C/'scoped_evidence_export_v1_20261009.json',dict(UTC=now(),status='LOCAL EXPORT BYTE VERIFIED — publication pending',
    parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    owned_files=[dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,SHA256=sha(p)) for p in files],
    archive_members=[dict(member=name,**item(p)) for p,name in members],
    archive_SHA256=sha(archive),counts=counts,book_PDF_SHA256=sha(R/'manuscript/book.pdf'),
    original_claims_status='UNVERIFIED',original_results_promoted=[],helper_source=__file__,helper_SHA256=sha(__file__)))
print(json.dumps(dict(status='PASS',counts=counts,archive_members=len(members),archive_SHA256=sha(archive),owned_files=len(files))))
