from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,base64
R=Path('/workspace/nonarchimedean-pluripotential-theory')
D=R/'source_material/GitHub_incoming_P12_3_continuation306_20261009';assert not D.exists();D.mkdir()
repo='repos/MingchenXia/nonarchimedean-pluripotential-theory/';head='47246110a56af214776920dc8d4822bed2b38c83'
api=lambda ep:json.loads(subprocess.check_output(['gh','api',repo+ep],cwd=R,text=True))
tree=api('git/trees/'+head+'?recursive=1');assert not tree['truncated'];mapping={r['path']:r for r in tree['tree'] if r['type']=='blob'}
base='research-checkpoints/continuation306/'
public=base+'frozen-files/root-checks/public-P12.3-continuation426-irreducible-centres-exact-filtration-and-surface-criterion-unreviewed/'
paths={
'README.md':base+'README.md',
'current-research-status.json':base+'current-research-status.json',
'scoped-verdict.md':public+'scoped-verdict.md',
'original-residual.md':public+'original-residual.md',
'native294-actual-FINAL-all-five-fields.json':public+'native294-actual-FINAL-all-five-fields.json',
'P12.3-marked-centres.tex':public+'P12.3-marked-centres.tex',
'P12.3-continuation425-working-paper.tex':base+'frozen-files/root-checks/P12.3-continuation425-conductor-power-cover-dichotomy-working-paper-20261009.tex',
'qualified-G331.json':public+'qualified-G331.json',
'qualified-G331.txt':public+'qualified-G331.txt',
'source-application-reading-ledger.md':public+'source-application-reading-ledger.md'}
files=[]
for name,path in paths.items():
    row=mapping[path];blob=api('git/blobs/'+row['sha']);assert blob['encoding']=='base64';b=base64.b64decode(blob['content'])
    assert len(b)==row['size'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['sha']
    p=D/name;p.write_bytes(b);files.append(dict(remote_path=path,local_path=str(p),remote_commit=head,Git_blob_SHA1=row['sha'],SHA256=hashlib.sha256(b).hexdigest(),bytes=len(b),actual_content_read=False))
out=D/'acquisition_v1_20261009.json';out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACQUIRED REMOTE DATA — content/proof reading pending',branch='codex/xean-research-20261003',remote_commit=head,files=files,programs_executed=False,book_changed=False,original_results_promoted=[],helper_source=__file__,helper_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),indent=2)+'\n')
print(json.dumps(dict(commit=head,files=[dict(name=Path(r['local_path']).name,bytes=r['bytes'],SHA256=r['SHA256']) for r in files])))
