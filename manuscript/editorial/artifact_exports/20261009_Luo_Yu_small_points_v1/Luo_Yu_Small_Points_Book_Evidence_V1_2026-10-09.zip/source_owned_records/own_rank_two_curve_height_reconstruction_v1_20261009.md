# A classical model reconstruction of Luo–Yu Example 1.2

This is an explanatory reconstruction of the imported example on physical
page 3 of arXiv:2505.07193v3, not a new mathematical result. It uses the
ordinary theory of line bundles on a curve, projective bundles, norms,
Riemann–Roch and Bertini. Those classical dependencies are explicitly
imported; this note does not claim a new recursive primary-source audit.

Let E be a smooth elliptic curve over C and Q a non-torsion line bundle
in Pic^0(E). Put K=C(E), let f:S=P_E(O_E plus Q)->E use the quotient
convention, and denote its tautological line bundle by xi=O_S(1).
The two quotient sections form the boundary of the open multiplicative
torsor. The model bundle is M=2xi-f*Q. Its generic fibre has degree 2.
Heights use the ordinary model intersection divided by the point degree:
for a closed point x of the generic fibre, with closure D in S,
h_M(x)=(M.D)/[K(x):K]. The base is a curve over C, so its divisorial
weights are the residue degrees, all one. The normalized curve height is
(M^2)/(2 deg(M_K)). The abelian contribution on the constant y in the
source example is zero, so this is also its stated canonical fibre height.

After normalizing D, its map g:C'->E is finite, of degree [K(x):K].
The point gives a quotient O_C' plus g*Q -> R to a line bundle R.
Thus h_M(x)=(2 deg R-deg g*Q)/deg g=2 deg R/deg g. At least one
of the two maps to R is nonzero, so deg R>=0: either source line has
degree zero. This proves nonnegative point heights, and also nefness
of M on every horizontal curve. On a vertical curve its degree is 2,
so M is nef on the entire surface.

If x is in the open torsor, both maps to R are generically nonzero.
If its height were zero, deg R=0, and both maps between degree-zero
line bundles would be isomorphisms. It follows that g*Q is trivial.
Norm along the finite map of smooth curves gives
Norm_g(g*Q)=Q^(deg g), so Q would be torsion, a contradiction.
This covers every algebraic point, including those on arbitrary finite
extensions; non-triviality of Q alone would not suffice. The two boundary
sections have height zero. A nonzero torsion Q provides the sharp boundary
of the argument: multiplication by its order trivializes its pullback
and can produce open height-zero points after a finite extension.

The projective-bundle relation gives xi^2=xi.f*Q and the latter has
degree deg Q=0. Hence M^2=0 and normalized curve height is zero.
For a fibre F, M.F=2.

One can see arbitrarily small points without invoking the paper's main
Bogomolov theorem. Fix a line bundle A on E of degree a>=3. For n>=1
consider D_n in |nM+f*A|. Its pushforward splits as the direct sum of
A+(j-n)Q for 0<=j<=2n. Each summand has degree a and is globally
generated on the elliptic curve. Therefore nM+f*A is basepoint-free.
It is ample by the surface Nakai criterion: every vertical curve has
positive nM degree, every horizontal curve has positive f*A degree,
and its square is 4na>0. In characteristic zero, Bertini supplies a
smooth member; ampleness supplies connectedness, so that member is
integral. It cannot be vertical, since its degree on the generic fibre
is 2n. It gives a closed point x_n of degree 2n. Direct intersection gives
M.D_n=2a and h_M(x_n)=a/n. Thus these positive heights tend to zero.

The unbounded degrees force the closed points to be distinct from every
fixed finite set eventually, so they form a generic sequence on the curve.
For every epsilon>0 the open torsor therefore has a Zariski dense set
of points of height below epsilon, yet it has no point of height exactly
zero. The compactified curve has essential and absolute minimum zero
and normalized height zero; its zero-height locus consists of only the
two boundary points. Equality in the fundamental height comparison does
not turn an infimum into point attainment in the open torsor.

This conclusion concerns a curve function field with non-torsion Picard
data over C. It makes no claim about arbitrary semiabelian Bogomolov,
the number-field toric point-attainment clause, a general equidistribution
measure, positive-characteristic constants, BJ22 homogeneous Siu, or a
canonical numbered problem closure. The explicit general-proof issues
in the source remain separate from this model computation.
