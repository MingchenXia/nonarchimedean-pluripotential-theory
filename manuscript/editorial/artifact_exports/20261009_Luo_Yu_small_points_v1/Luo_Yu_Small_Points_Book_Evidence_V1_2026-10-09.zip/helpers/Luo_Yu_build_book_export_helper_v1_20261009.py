from pathlib import Path
import ast
s=Path('/tmp/Guo_Yuan_export_book_v2_20261009.py').read_text()
for a,b in [('Guo_Yuan_relative_minima','Luo_Yu_small_points'),('GuoYuan26ArxivV2','LuoYu25ArxivV3'),('Guo-Yuan-relative-minima','Luo-Yu-small-points'),('Guo_Yuan_Relative_Minima','Luo_Yu_Small_Points'),('Guo_Yuan','Luo_Yu'),('Relative_Minima','Small_Points'),('_v2_','_v1_'),('-v2-','-v1-'),('book_notes_v2','book_notes_v1'),('book_compiled_staged_v2','book_compiled_staged_v1'),('_V2_','_V1_')]:s=s.replace(a,b)
s=s.replace('==14','==13').replace('==[4430]','==[]').replace("'physical_pages']=14","'physical_pages']=13").replace('actual_final_book_pages=14','actual_final_book_pages=13').replace('explicitly_reviewed_blank_versos=[4430]','explicitly_reviewed_blank_versos=[]')
s=s.replace("title='Relative successive minima — actual book review'", "title='Small points without zero-height points — actual book review'")
s=s.replace("title='Relative successive minima — actual book review'", "title='Small points without zero-height points — actual book review'")
s=s.replace("title='Relative successive minima — actual book review'", "title='Small points — actual book review'")
s=s.replace("title='Relative successive minima — actual book review'", "title='Small points — actual book review'")
s=s.replace("title='Relative successive minima — actual book review'", "title='Small points — actual book review'")
s=s.replace('Relative successive minima','Small points without zero-height points').replace('Relative successive-minima','Small-points').replace('relative-minima book','small-points book')
s=s.replace('Fourteen final physical pages actually read in seven fresh displays, including intentional blank verso 4430. Export grants no reading credit.', 'Thirteen final physical pages actually read in seven fresh displays. Page 4430 contains the provenance continuation. Export grants no reading credit.')
summary='''The checked 4,681-page edition adds Luo–Yu Example 1.2 to Chapter 27
and its exact-source provenance to Appendix L. Fix an elliptic curve E/C,
a non-torsion Q in Pic0(E), K=C(E), the quotient projective bundle
S=P_E(O plus Q), and M=2xi-f*Q. Heights divide intersections by the
point degree. The norm argument excludes zero-height points in the open
torsor over every finite extension. Its two boundary points have height
zero. Smooth integral divisors in |nM+f*A|, deg A=a>=3, give degree-2n
points of positive height a/n tending to zero. The compactified curve's
normalized height and both minima are zero. The open essential minimum
is zero but unattained: arbitrarily small points must be distinguished
from exact zero-height points, even in an equality case. Nefness is
asserted only for this surface model. The following paragraph explicitly
returns to number fields and the separate Ballay–Sombra open questions.

All 31 physical pages of arXiv:2505.07193v3 were actually read in sixteen
ordered complete-text/image views. The source checkpoint and its separately
published 43-member authored evidence are pinned. The direct classical
rank-two reconstruction uses quotient bundles, finite-map norms, the
projective-bundle relation, Riemann–Roch, the surface ample criterion,
Bertini over C and connectedness of ample divisors. These dependencies
are imported, not newly recursively certified. The worked case does not
use the general geometric/number-field Bogomolov proofs, whose quasi-split,
relative-component and model steps still require separate reconstruction.
Exact normalization and matrix diagnostics do not certify those proofs.
No original theorem or independent production-verifier receipt is claimed.

Thirteen selected final pages were actually read in seven fresh matching
views: contents, the previous/new examples and adjoining discussion,
complete new provenance, Appendix M opening, index boundaries and LY25
bibliography. Page 4430 is occupied by the provenance continuation; no
selected page is blank. This is a scoped final-page read. The last ordered
whole-book reading remains 4 October; export/upload adds no reading credit.
A failed checkpoint helper used the wrong publication-record directory;
it wrote no checkpoint, and its fresh corrected helper is preserved.

Required manuscript validation and six existing reference-check tests pass.
The final PDF has zero errors, missing glyphs, overfull boxes, unresolved
references/citations, package/pdfTeX warnings or rerun requests. All 955
inherited underfull blocks retain normalized content and multiplicities.
All 13,382 prior numbered values, 605 cited keys/labels, 2,766 contents
titles/hierarchy and 900 index terms remain; LY25 gives 606 citations.
All internal destinations resolve. Two core TeX files and the NA bibliography
change; the other 423 core TeX files and complex bibliography are identical.
No formal environment, semantic label, manual tag or contents title is added.

Canonical 42 atoms/twelve problems and tiers (0,3,7,15,17) remain unchanged.
BJ22 general homogeneous Siu/envelopes stay OPEN; LPWZ density UNVERIFIED.
Incoming conductor/power-cover, generic-line GVF and toric-attainment
original candidates remain unverified outside theorem typography. The
native catalogue/editor and historical PDF are preserved; native compilation
is unverified. Work continues cloud-only with Xean suspended. GVF foundations
arXiv:2409.04570v2 has eight of 52 pages actually read; its later proofs are
unread. Incoming continuation307 is metadata-only, with no proof credit.
'''
a=s.index("summary='''");b=s.index("\nmarkdown(paths['audit']",a);s=s[:a]+'summary='+repr(summary)+s[b:]
s=s.replace("'# Relative successive-minima book integration, 9 October 2026", "'# Small-points book integration, 9 October 2026")
s=s.replace('Fourteen selected final V2 pages in seven fresh displays; intentional verso 4430 included.', 'Thirteen selected final pages in seven fresh displays; page 4430 contains provenance, not a blank.')
a=s.index("intro='''",s.index("programme="));b=s.index("p=S/'README.md'",a)
intro='''**Current checked small-points edition: 4,681 pages, 9 October 2026.**
The [integration audit](manuscript/editorial/Luo_Yu_small_points_staged_integration_audit_v1_20261009.md)
adds the Luo–Yu example over C(E): non-torsion Picard data excludes
height-zero points in the open torsor, while explicit integral curves
supply positive heights tending to zero. The compactified height and
minima are zero, with exactly two zero-height boundary points. Chapter 27
contains the direct model proof; Appendix L pins the source and imported
dependencies. All 31 source pages and thirteen selected final book pages
were actually read with matching text/images. The [artifacts](manuscript/editorial/artifact_exports/20261009_Luo_Yu_small_points_v1/README.md)
contain the full book, actual review, minimal source and authored evidence.
Required checks pass and all prior numbered values, contents and index
terms remain; the bibliography now has 606 cited entries. The last ordered
whole-book read remains 4 October. GVF foundations has eight of 52 pages
read; continuation307 remains metadata-only. Original candidates and
canonical statuses are unchanged. Continue cloud-only, Xean suspended.

'''
s=s[:a]+'intro='+repr(intro)+'\n'+s[b:]
s=s.replace("marker='**Latest verified translated-abelian GitHub publication, 9 October 2026:**'", "marker='**Latest verified related-source audit, 9 October 2026:**'")
a=s.index("intro='''",s.index("p=S/'README.md'"));b=s.index('p=S/programme',a)
intro='''## Current checked small-points edition: 4,681 pages, 9 October 2026

The [integration audit](Luo_Yu_small_points_staged_integration_audit_v1_20261009.md)
imports Luo–Yu Example 1.2 with a direct rank-two model reconstruction.
Over K=C(E), non-torsion Q in Pic0(E) excludes zero-height points in the
open torsor over every finite extension. Ample integral divisors give
positive heights a/n tending to zero; the compactification has normalized
height and both minima zero, but only its two boundary points have exact
zero height. This is an imported classical worked case, with disclosed
norm, projective-bundle, Riemann–Roch and Bertini dependencies. The general
geometric and number-field Bogomolov proofs remain pending reconstruction.

All 31 primary pages were read in sixteen ordered matching displays.
All thirteen selected final book pages were read in seven fresh matching
views. Page 4430 now contains the complete provenance continuation; no
selected page is blank. Required validation and six existing tests pass.
All 13,382 numbered values, 605 cited labels, 2,766 contents titles/hierarchy
and 900 index terms remain; LY25 gives 606 citations. All destinations
resolve and the 955 underfull blocks are identical to the preceding edition.
Other 423 core TeX inputs and the complex bibliography are unchanged.
See the [artifacts](artifact_exports/20261009_Luo_Yu_small_points_v1/README.md).

The last ordered whole-book read remains 4 October. GVF foundations v2
has eight of 52 pages actually read; later proof sections are unread.
Continuation307 is metadata-only. Canonical 42-atom/twelve-problem tiers
remain (0,3,7,15,17), P12.2/P12.3 and BJ22 general homogeneous Siu/envelopes
remain OPEN, and LPWZ density remains UNVERIFIED. No original result or
independent production-verifier receipt is promoted. The native catalogue,
editor and historical PDF are preserved; native compilation is unverified.
Work continues in the cloud with Xean suspended. Earlier entries below
are dated historical checkpoints and retain their original reading scopes.

'''
s=s[:a]+'intro='+repr(intro)+'\n'+s[b:]
s=s.replace("Luo_Yu_Complete_Source_Evidence_V1_2026-10-09.zip'", "Luo_Yu_Complete_Source_Evidence_V1_2026-10-09.zip'")
s=s.replace('8b41bae3d121bb0838fbec2c9604c2852fbeddaf434911da786aa7625a1b52c8','88009956d0c0512c70823485f821dc085871247afd14776ae2921778f5ad2016')
s=s.replace("'own_complete_source_review_v1_20261009.md']", "'own_complete_source_review_v1_20261009.md','own_rank_two_curve_height_reconstruction_v1_20261009.md','GitHub_complete_source_publication_v1_20261009.json']")
s=s.replace('14-page actual review','13-page actual review').replace('27-member source evidence','43-member source evidence')
s=s.replace('source_checkpoint_SHA256=prep[\'source_checkpoint_SHA256\'],active_book_changed=False', "source_checkpoint_SHA256=prep['source_checkpoint_SHA256'],source_publication_SHA256=prep['source_publication_SHA256'],classical_model_reconstruction_SHA256=prep['classical_model_reconstruction_SHA256'],active_book_changed=False")
p=Path('/tmp/Luo_Yu_export_book_v1_20261009.py');assert not p.exists();ast.parse(s);p.write_text(s)
print('Prepared fresh export helper; no exports created yet.')
