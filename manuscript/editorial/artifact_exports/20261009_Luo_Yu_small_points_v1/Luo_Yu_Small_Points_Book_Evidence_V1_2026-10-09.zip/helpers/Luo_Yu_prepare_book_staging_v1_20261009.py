from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,shutil,subprocess,zipfile
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Luo_Yu_small_points_book_integration_20261009';C.mkdir(exist_ok=True)
K=R/'source_material/Hultberg_GVF_dependency_review_20261009/LuoYu25ArxivV3'
B=Path('/workspace/book-completion-drafts/Guo-Yuan-relative-minima-staging-v2-20261009')
S=Path('/workspace/book-completion-drafts/Luo-Yu-small-points-staging-v1-20261009')
D=Path('/workspace/book-completion-drafts/Luo-Yu-small-points-integration-v1-20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=C/'book_staging_preparation_v1_20261009.json';assert not S.exists() and not out.exists()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head=='d3e9dc80721cfd86b45ba5b8e75a9cf93aed6b5c'
assert sha(R/'manuscript/book.pdf')==sha(B/'manuscript/book.pdf')=='50b24f4e074c8f62238fcf0cb71f610705c7688479d0662101d58e3b23bfd43a'
cal=K/'literal_exact_calibrations_v1_20261009.json';assert json.loads(cal.read_text())['status'].startswith('PASS')
export=json.loads((R/'source_material/Guo_Yuan_relative_minima_book_integration_20261009/book_export_v2_20261009.json').read_text())
minimal=export['artifacts']['minimal_TeX_source_archive'];archive=Path(minimal['path']);assert sha(archive)==minimal['SHA256']
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==472
    for n in z.namelist():assert not Path(n).is_absolute() and '..' not in Path(n).parts
    S.mkdir();z.extractall(S)
for n in ['README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']:shutil.copyfile(R/n,S/n)
alltex={str(p.relative_to(S)):sha(p) for p in (S/'manuscript').rglob('*.tex')};assert len(alltex)==425
for n,h in alltex.items():assert sha(R/n)==sha(B/n)==h
changed=['manuscript/parts/part3/ch27_differentiability.tex','manuscript/appendices/appL_provenance.tex','manuscript/bibliography/NonArchimedean.bib']
before={n:sha(R/n) for n in changed}
for n in changed:assert sha(S/n)==sha(R/n)==sha(B/n)
for p in D.iterdir():assert all(line==line.rstrip() for line in p.read_text().splitlines())
p=S/changed[0];text=p.read_text();marker='\\paragraph{The remaining directions.}';assert text.count(marker)==1
p.write_text(text.replace(marker,(D/'ch27_small_points_fragment.tex').read_text().rstrip()+'\n\n'+marker,1))
p=S/changed[1];p.write_text(p.read_text().rstrip()+'\n\n'+(D/'appL_small_points_fragment.tex').read_text().rstrip()+'\n')
p=S/changed[2];text=p.read_text();assert 'LY25SemiabelianV3' not in text
p.write_text(text.rstrip()+r'''

@misc{LY25SemiabelianV3,
  author = {Luo, Wenbin and Yu, Jiawei},
  title = {Geometric Bogomolov conjecture for semiabelian varieties},
  year = {2025},
  eprint = {2505.07193},
  eprinttype = {arxiv},
  url = {https://arxiv.org/abs/2505.07193v3},
  note = {Version 3, 28 August 2025},
  shorthand = {LY25}
}
''')

checks=[]
for n in changed[:2]:
    old=(R/n).read_text();new=(S/n).read_text();counts={}
    for e in ['theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important']:
        pat=r'\\begin\{'+e+r'\}';counts[e]=len(re.findall(pat,old));assert counts[e]==len(re.findall(pat,new))
    assert re.findall(r'\\tag\{([^}]+)\}',old)==re.findall(r'\\tag\{([^}]+)\}',new)
    assert re.findall(r'\\label\{([^}]+)\}',old)==re.findall(r'\\label\{([^}]+)\}',new)
    checks.append(dict(path=n,environment_counts=counts))
unchanged={n:h for n,h in alltex.items() if n not in changed};assert len(unchanged)==423
for n,h in unchanged.items():assert sha(R/n)==sha(S/n)==h
native={str(p.relative_to(R)):sha(p) for p in [R/'output/open_problems_catalogue_2026-10-03.tex',R/'output/open_problems_catalogue_2026-10-03.pdf']}
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='PREPARED — imported small-points example with complete rank-two model reconstruction; active book unchanged',stage_path=str(S),baseline_stage_path=str(B),baseline_compiled_snapshot=str(R/'source_material/Guo_Yuan_relative_minima_book_integration_20261009/book_compiled_staged_v2'),baseline_commit=head,baseline_minimal_source=minimal,draft_path=str(D),before=before,after={n:sha(S/n) for n in changed},draft_fragments={str(p):sha(p) for p in sorted(D.iterdir())},active_inputs_preserved=before,other_active_TeX_preserved=unchanged,other_active_TeX_count=423,unchanged_bibliographies={'manuscript/bibliography/ComplexGeometry.bib':sha(R/'manuscript/bibliography/ComplexGeometry.bib')},historical_formal_environment_counts_preserved=checks,active_book_PDF_SHA256=sha(R/'manuscript/book.pdf'),native_catalogue_preserved=native,source_checkpoint_SHA256=sha(K/'actual_complete_source_checkpoint_v1_20261009.json'),source_publication_SHA256=sha(K/'GitHub_complete_source_publication_v1_20261009.json'),classical_model_reconstruction_SHA256=sha(K/'own_rank_two_curve_height_reconstruction_v1_20261009.md'),normalization_calibration_SHA256=sha(cal),new_bibliographic_keys=['LY25SemiabelianV3'],new_semantic_labels=[],new_toc_titles=[],new_formal_environments=0,original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],active_book_changed=False,GitHub_published=False,actual_book_reading_credit=0,helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='PREPARED',record_SHA256=sha(out),unchanged_TeX=423,changed_files=3)))
