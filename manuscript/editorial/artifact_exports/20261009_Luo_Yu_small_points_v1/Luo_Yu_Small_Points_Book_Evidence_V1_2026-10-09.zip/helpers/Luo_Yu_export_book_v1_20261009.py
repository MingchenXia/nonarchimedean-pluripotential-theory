from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile, shutil, fitz

R=Path('/workspace/nonarchimedean-pluripotential-theory'); E=R/'manuscript/editorial'
C=R/'source_material/Luo_Yu_small_points_book_integration_20261009'
K=R/'source_material/Hultberg_GVF_dependency_review_20261009/LuoYu25ArxivV3'
S=Path('/workspace/book-completion-drafts/Luo-Yu-small-points-staging-v1-20261009')
D=Path('/workspace/book-completion-drafts/Luo-Yu-small-points-integration-v1-20261009')
W=Path('/tmp/Luo_Yu_small_points_staged_book_views_v1_20261009')
O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
def write(p,a):
    assert not p.exists()
    p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
def markdown(p,s):
    p.write_text(s.rstrip()+'\n')
prep=load('book_staging_preparation_v1_20261009.json'); release=load('book_release_checks_v1_20261009.json')
reading=load('actual_book_reading_v1_20261009.json'); math=load('book_mathematical_self_audit_v1_20261009.json')
validation=load('book_validation_v1_20261009.json'); under=load('book_underfull_delta_v1_20261009.json')
assert validation['returncode']==0 and under['all_normalized_blocks_and_multiplicities_identical']
assert reading['actual_unique_book_pages']==13 and reading['fresh_matching_views']==7 and reading['reused_matching_views']==0
assert not reading['remaining_repairs'] and reading['explicitly_reviewed_blank_versos']==[]
assert release['PDF']['physical_pages']==4681 and release['PDF']['SHA256']==reading['PDF']['SHA256']
assert math['actual_final_book_reading_SHA256']==sha(C/'actual_book_reading_v1_20261009.json')
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['before'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
paths={k:E/f'Luo_Yu_small_points_staged_integration_{k}_v1_20261009.{ext}' for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
full=O/'Non-Archimedean_Pluripotential_Theory_Small_Points_V1_2026-10-09.pdf'
review=O/'Luo_Yu_Small_Points_Actual_Book_Review_V1_2026-10-09.pdf'
minimal=O/'Luo_Yu_Small_Points_Minimal_Source_V1_2026-10-09.zip'
evidence=O/'Luo_Yu_Small_Points_Book_Evidence_V1_2026-10-09.zip'
dest=E/'artifact_exports/20261009_Luo_Yu_small_points_v1'; record=C/'book_export_v1_20261009.json'
assert not any(p.exists() for p in [*paths.values(),full,review,minimal,evidence,dest,record])
shutil.copyfile(release['PDF']['path'],full); assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as source:
    doc=fitz.open()
    for n in reading['actual_book_physical_pages']:doc.insert_pdf(source,from_page=n-1,to_page=n-1)
    assert len(doc)==13
    doc.set_metadata(dict(title='Small points without zero-height points — actual book review',subject='Thirteen final physical pages actually read in seven fresh displays. Page 4430 contains the provenance continuation. Export grants no reading credit.'))
    doc.save(review,garbage=4,deflate=True); doc.close()
summary="The checked 4,681-page edition adds Luo–Yu Example 1.2 to Chapter 27\nand its exact-source provenance to Appendix L. Fix an elliptic curve E/C,\na non-torsion Q in Pic0(E), K=C(E), the quotient projective bundle\nS=P_E(O plus Q), and M=2xi-f*Q. Heights divide intersections by the\npoint degree. The norm argument excludes zero-height points in the open\ntorsor over every finite extension. Its two boundary points have height\nzero. Smooth integral divisors in |nM+f*A|, deg A=a>=3, give degree-2n\npoints of positive height a/n tending to zero. The compactified curve's\nnormalized height and both minima are zero. The open essential minimum\nis zero but unattained: arbitrarily small points must be distinguished\nfrom exact zero-height points, even in an equality case. Nefness is\nasserted only for this surface model. The following paragraph explicitly\nreturns to number fields and the separate Ballay–Sombra open questions.\n\nAll 31 physical pages of arXiv:2505.07193v3 were actually read in sixteen\nordered complete-text/image views. The source checkpoint and its separately\npublished 43-member authored evidence are pinned. The direct classical\nrank-two reconstruction uses quotient bundles, finite-map norms, the\nprojective-bundle relation, Riemann–Roch, the surface ample criterion,\nBertini over C and connectedness of ample divisors. These dependencies\nare imported, not newly recursively certified. The worked case does not\nuse the general geometric/number-field Bogomolov proofs, whose quasi-split,\nrelative-component and model steps still require separate reconstruction.\nExact normalization and matrix diagnostics do not certify those proofs.\nNo original theorem or independent production-verifier receipt is claimed.\n\nThirteen selected final pages were actually read in seven fresh matching\nviews: contents, the previous/new examples and adjoining discussion,\ncomplete new provenance, Appendix M opening, index boundaries and LY25\nbibliography. Page 4430 is occupied by the provenance continuation; no\nselected page is blank. This is a scoped final-page read. The last ordered\nwhole-book reading remains 4 October; export/upload adds no reading credit.\nA failed checkpoint helper used the wrong publication-record directory;\nit wrote no checkpoint, and its fresh corrected helper is preserved.\n\nRequired manuscript validation and six existing reference-check tests pass.\nThe final PDF has zero errors, missing glyphs, overfull boxes, unresolved\nreferences/citations, package/pdfTeX warnings or rerun requests. All 955\ninherited underfull blocks retain normalized content and multiplicities.\nAll 13,382 prior numbered values, 605 cited keys/labels, 2,766 contents\ntitles/hierarchy and 900 index terms remain; LY25 gives 606 citations.\nAll internal destinations resolve. Two core TeX files and the NA bibliography\nchange; the other 423 core TeX files and complex bibliography are identical.\nNo formal environment, semantic label, manual tag or contents title is added.\n\nCanonical 42 atoms/twelve problems and tiers (0,3,7,15,17) remain unchanged.\nBJ22 general homogeneous Siu/envelopes stay OPEN; LPWZ density UNVERIFIED.\nIncoming conductor/power-cover, generic-line GVF and toric-attainment\noriginal candidates remain unverified outside theorem typography. The\nnative catalogue/editor and historical PDF are preserved; native compilation\nis unverified. Work continues cloud-only with Xean suspended. GVF foundations\narXiv:2409.04570v2 has eight of 52 pages actually read; its later proofs are\nunread. Incoming continuation307 is metadata-only, with no proof credit.\n"
markdown(paths['audit'],'# Small-points book integration, 9 October 2026\n\n'+summary+'\nScoped mathematical checks:\n\n'+''.join(f'{i}. {x}\n\n' for i,x in enumerate(math['scope_checks'],1)))
notes=[]
for item in reading['receipts']:
    n=item['number']; note=C/f'book_notes_v1/note_{n:02d}.md'; receipt=C/f'book_notes_v1/note_{n:02d}_receipt.json'
    assert sha(note)==item['note_SHA256'] and sha(receipt)==item['receipt_SHA256']
    notes.append(note.read_text())
markdown(paths['reading_notes'],'# Actual final small-points book reading\n\nThirteen selected final pages in seven fresh displays; page 4430 contains provenance, not a blank.\n'+''.join('\n---\n\n'+x for x in notes))
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md'
intro='**Current checked small-points edition: 4,681 pages, 9 October 2026.**\nThe [integration audit](manuscript/editorial/Luo_Yu_small_points_staged_integration_audit_v1_20261009.md)\nadds the Luo–Yu example over C(E): non-torsion Picard data excludes\nheight-zero points in the open torsor, while explicit integral curves\nsupply positive heights tending to zero. The compactified height and\nminima are zero, with exactly two zero-height boundary points. Chapter 27\ncontains the direct model proof; Appendix L pins the source and imported\ndependencies. All 31 source pages and thirteen selected final book pages\nwere actually read with matching text/images. The [artifacts](manuscript/editorial/artifact_exports/20261009_Luo_Yu_small_points_v1/README.md)\ncontain the full book, actual review, minimal source and authored evidence.\nRequired checks pass and all prior numbered values, contents and index\nterms remain; the bibliography now has 606 cited entries. The last ordered\nwhole-book read remains 4 October. GVF foundations has eight of 52 pages\nread; continuation307 remains metadata-only. Original candidates and\ncanonical statuses are unchanged. Continue cloud-only, Xean suspended.\n\n'
p=S/'README.md'; s=p.read_text(); marker='**Latest verified related-source audit, 9 October 2026:**'
assert s.count(marker)==1; markdown(p,s.replace(marker,intro+marker,1))
intro='## Current checked small-points edition: 4,681 pages, 9 October 2026\n\nThe [integration audit](Luo_Yu_small_points_staged_integration_audit_v1_20261009.md)\nimports Luo–Yu Example 1.2 with a direct rank-two model reconstruction.\nOver K=C(E), non-torsion Q in Pic0(E) excludes zero-height points in the\nopen torsor over every finite extension. Ample integral divisors give\npositive heights a/n tending to zero; the compactification has normalized\nheight and both minima zero, but only its two boundary points have exact\nzero height. This is an imported classical worked case, with disclosed\nnorm, projective-bundle, Riemann–Roch and Bertini dependencies. The general\ngeometric and number-field Bogomolov proofs remain pending reconstruction.\n\nAll 31 primary pages were read in sixteen ordered matching displays.\nAll thirteen selected final book pages were read in seven fresh matching\nviews. Page 4430 now contains the complete provenance continuation; no\nselected page is blank. Required validation and six existing tests pass.\nAll 13,382 numbered values, 605 cited labels, 2,766 contents titles/hierarchy\nand 900 index terms remain; LY25 gives 606 citations. All destinations\nresolve and the 955 underfull blocks are identical to the preceding edition.\nOther 423 core TeX inputs and the complex bibliography are unchanged.\nSee the [artifacts](artifact_exports/20261009_Luo_Yu_small_points_v1/README.md).\n\nThe last ordered whole-book read remains 4 October. GVF foundations v2\nhas eight of 52 pages actually read; later proof sections are unread.\nContinuation307 is metadata-only. Canonical 42-atom/twelve-problem tiers\nremain (0,3,7,15,17), P12.2/P12.3 and BJ22 general homogeneous Siu/envelopes\nremain OPEN, and LPWZ density remains UNVERIFIED. No original result or\nindependent production-verifier receipt is promoted. The native catalogue,\neditor and historical PDF are preserved; native compilation is unverified.\nWork continues in the cloud with Xean suspended. Earlier entries below\nare dated historical checkpoints and retain their original reading scopes.\n\n'
p=S/programme; s=p.read_text(); first=s.index('\n'); markdown(p,s[:first+1]+'\n'+intro+s[first+1:])
with zipfile.ZipFile(prep['baseline_minimal_source']['path']) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    members=old.namelist(); assert len(members)==len(set(members))==472
    for n in members:z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
    assert z.testzip() is None
    for n in z.namelist():assert z.read(n)==(S/n).read_bytes()
files={f'records/{q.name}':q for q in C.glob('*.json')}
for q in C.glob('book_validation_*_20261009.log'):files[f'logs/{q.name}']=q
for n in prep['after']:files['staged_inputs/'+n]=S/n
for q in D.iterdir():
    assert q.suffix=='.tex'; files['drafts/'+q.name]=q
for q in (C/'book_compiled_staged_v1').iterdir():
    if q.suffix!='.pdf':files['compiled/'+q.name]=q
for item in reading['receipts']:
    n=item['number']
    for kind,q in [('notes',C/f'book_notes_v1/note_{n:02d}.md'),('receipts',C/f'book_notes_v1/note_{n:02d}_receipt.json'),('images',W/f'sheet_{n:02d}.png'),('text',W/f'sheet_{n:02d}.txt')]:files[f'actual/{kind}/{q.name}']=q
files['actual/prepared_manifest.json']=W/'manifest.json'
for q in Path('/tmp').glob('Luo_Yu_*_book_*_20261009.py'):files['helpers/'+q.name]=q
for q in Path('/tmp').glob('Luo_Yu_underfull_delta_*_20261009.py'):files['helpers/'+q.name]=q
for q in [paths['audit'],paths['reading_notes'],S/programme,S/'README.md']:files['editorial/'+q.name]=q
sourcezip=K/'Luo_Yu_Complete_Source_Evidence_V1_2026-10-09.zip'
assert sha(sourcezip)=='88009956d0c0512c70823485f821dc085871247afd14776ae2921778f5ad2016'
files['source_owned_records/'+sourcezip.name]=sourcezip
for n in ['actual_complete_source_checkpoint_v1_20261009.json','complete_evidence_export_v1_20261009.json','literal_exact_calibrations_v1_20261009.json','own_complete_source_review_v1_20261009.md','own_rank_two_curve_height_reconstruction_v1_20261009.md','GitHub_complete_source_publication_v1_20261009.json']:files['source_owned_records/'+n]=K/n
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(files) and z.testzip() is None
    for n,q in files.items():assert z.read(n)==q.read_bytes()
artifacts={k:dict(path=str(q),bytes=q.stat().st_size,SHA256=sha(q)) for k,q in [('full_book_PDF',full),('selected_review_PDF',review),('minimal_TeX_source_archive',minimal),('actual_book_evidence_archive',evidence)]}
artifacts['full_book_PDF']['physical_pages']=4681; artifacts['selected_review_PDF']['physical_pages']=13
artifacts['minimal_TeX_source_archive']['members']=472; artifacts['actual_book_evidence_archive']['members']=len(files)
progress={n:sha(S/n) for n in ['README.md',programme]}
write(paths['manifest'],dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — scoped source/math/mechanical/actual-render gate',preparation=prep,release=release,validation=validation,actual_reading=reading,mathematical_audit=math,underfull_comparison=under,artifacts=artifacts,active_book_changed=False,GitHub_published=False))
write(paths['artifacts'],dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — all export members byte-verified',artifacts=artifacts,actual_final_book_pages=13,fresh_matching_views=7,explicitly_reviewed_blank_versos=[],reading_credit_from_export=0,GitHub_published=False))
dest.mkdir(parents=True)
for q in [full,review,minimal,evidence]:shutil.copyfile(q,dest/q.name); assert sha(dest/q.name)==sha(q)
(dest/'SHA256SUMS').write_text(''.join(sha(q)+'  '+q.name+'\n' for q in [full,review,minimal,evidence]))
markdown(dest/'README.md','# Small-points book artifacts\n\n'+summary+f'\nArtifacts: full 4,681-page PDF, 13-page actual review, 472-member minimal\nsource and {len(files)}-member byte-verified authored book evidence. The nested\n43-member source evidence excludes primary PDFs, literal source text and\nprimary-source images. Rendered images in this package are our book pages.\n')
editorial={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in paths.values()}
for p in dest.iterdir():editorial[str(p.relative_to(R))]=dict(bytes=p.stat().st_size,SHA256=sha(p))
write(record,dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — final small-points book/evidence export',artifacts=artifacts,editorial_files=editorial,progress_document_hashes=progress,actual_final_book_pages=13,actual_final_matching_views=7,reused_matching_views=0,explicitly_reviewed_blank_versos=[],source_evidence_SHA256=sha(sourcezip),source_checkpoint_SHA256=prep['source_checkpoint_SHA256'],source_publication_SHA256=prep['source_publication_SHA256'],classical_model_reconstruction_SHA256=prep['classical_model_reconstruction_SHA256'],active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)))
print(json.dumps(dict(status='EXPORTED',record_SHA256=sha(record),evidence_members=len(files),artifacts=artifacts)))
