from pathlib import Path
from datetime import datetime, timezone
import hashlib, json
import fitz
from PIL import Image, ImageDraw

C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009/dependencies_v1/Maillot00Published')
W=Path('/tmp/Xue_semiabelian_dependency_views_v1_20261009/Maillot00Published')
assert not W.exists()
W.mkdir()
(C/'primary_notes_v1').mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
src=json.loads((C/'source_acquisition_v2_20261009.json').read_text())
assert sha(src['path'])==src['SHA256']
doc=fitz.open(src['path']);views=[]
for n,pages in enumerate([[60,61],[62,63],[64]],1):
    imgs=[]
    for page in pages:
        pix=doc[page-1].get_pixmap(matrix=fitz.Matrix(1.3,1.3),alpha=False)
        imgs.append(Image.frombytes('RGB',[pix.width,pix.height],pix.samples))
    canvas=Image.new('RGB',(sum(i.width for i in imgs),max(i.height for i in imgs)+35),'white')
    draw=ImageDraw.Draw(canvas);offset=0
    for page,img in zip(pages,imgs):
        canvas.paste(img,(offset,35));draw.text((offset+8,8),'Maillot 2000: physical page %d (printed %d)'%(page,page-5),fill='black');offset+=img.width
    image_path=W/('sheet_%02d.png'%n);canvas.save(image_path)
    text_path=W/('sheet_%02d.txt'%n)
    text_path.write_text('\n\n'.join('MAILLOT PHYSICAL PAGE %d\n%s'%(page,doc[page-1].get_text(sort=True)) for page in pages))
    views.append(dict(number=n,physical_pages=pages,path=str(image_path),image_SHA256=sha(image_path),selected_text_path=str(text_path),selected_text_SHA256=sha(text_path),source_PDF_SHA256=src['SHA256'],actually_viewed=False,selected_text_read=False))
manifest=W/'manifest.json';manifest.write_text(json.dumps(views,ensure_ascii=False,indent=2)+'\n')
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='BOUNDED VIEWS PREPARED — zero actual-reading credit',source=src,prepared_pages=5,prepared_physical_pages=[60,61,62,63,64],prepared_views=3,source_total_physical_pages=130,manifest_path=str(manifest),manifest_SHA256=sha(manifest),actual_primary_reading_credit=0,mathematical_clearance=False,book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__))
(C/'source_preparation_v1_20261009.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],views=3,pages=5,manifest_SHA256=sha(manifest))))
