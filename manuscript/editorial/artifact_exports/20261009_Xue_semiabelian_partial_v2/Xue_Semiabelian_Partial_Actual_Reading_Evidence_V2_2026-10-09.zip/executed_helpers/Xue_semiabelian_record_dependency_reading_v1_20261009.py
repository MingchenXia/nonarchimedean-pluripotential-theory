from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, sys

key=sys.argv[1];n=int(sys.argv[2])
root=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009/dependencies_v1')
C=root/key;W=Path('/tmp/Xue_semiabelian_dependency_views_v1_20261009')/key
version='v2' if key=='FRSS18ArxivV2' else 'v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prep=json.loads((C/('source_preparation_'+version+'_20261009.json')).read_text())
views=json.loads((W/'manifest.json').read_text());v=views[n-1]
assert v['number']==n and sha(W/'manifest.json')==prep['manifest_SHA256']
assert sha(prep['source']['path'])==v['source_PDF_SHA256']==prep['source']['SHA256']
assert sha(v['path'])==v['image_SHA256'] and sha(v['selected_text_path'])==v['selected_text_SHA256']
note=C/('primary_notes_'+version)/('note_%02d.md'%n)
receipt=note.with_name('note_%02d_receipt.json'%n)
assert note.exists() and len(note.read_text())>300 and not receipt.exists()
previous=note.with_name('note_%02d_receipt.json'%(n-1)) if n>1 else None
if previous:assert previous.exists() and json.loads(previous.read_text())['view_number']==n-1
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACTUALLY READ — complete selected text and matching displayed image',
 source_key=key,source_PDF_SHA256=v['source_PDF_SHA256'],view_number=n,physical_pages=v['physical_pages'],
 full_selected_text_read=True,matching_rendered_image_displayed_and_read=True,
 image_path=v['path'],image_SHA256=v['image_SHA256'],selected_text_path=v['selected_text_path'],
 selected_text_SHA256=v['selected_text_SHA256'],note_path=str(note),note_SHA256=sha(note),
 previous_receipt_SHA256=sha(previous) if previous else None,
 actual_dependency_reading_credit=len(v['physical_pages']),no_other_page_credit=True,
 no_Xue_page_reading_credit=True,independent_model_verdict=False,book_changed=False,
 journal_locators_authenticated_by_this_reading=False if key=='FRSS18ArxivV2' else None,
 helper_source=__file__,helper_SHA256=sha(__file__))
receipt.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(source=key,view=n,pages=v['physical_pages'],receipt_SHA256=sha(receipt))))
