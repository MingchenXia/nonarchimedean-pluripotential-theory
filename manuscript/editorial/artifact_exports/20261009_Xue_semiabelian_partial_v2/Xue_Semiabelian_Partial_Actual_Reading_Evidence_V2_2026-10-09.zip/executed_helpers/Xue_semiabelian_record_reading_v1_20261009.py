from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, sys

C = Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009')
W = Path('/tmp/Xue_semiabelian_primary_views_v1_20261009')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
number = int(sys.argv[1])
manifest = json.loads((W/'manifest.json').read_text())
view = manifest[number-1]
assert view['number'] == number
prep = json.loads((C/'source_preparation_v1_20261009.json').read_text())
assert sha(W/'manifest.json') == prep['manifest_SHA256']
assert sha(prep['source']['path']) == view['source_PDF_SHA256'] == prep['source']['SHA256']
assert sha(view['path']) == view['image_SHA256']
assert sha(view['selected_text_path']) == view['selected_text_SHA256']
note = C/'primary_notes_v1'/('note_%02d.md' % number)
receipt = note.with_name('note_%02d_receipt.json' % number)
assert note.exists() and not receipt.exists()
assert len(note.read_text()) > 300
previous = None
if number > 1:
    previous = C/'primary_notes_v1'/('note_%02d_receipt.json' % (number-1))
    assert previous.exists()
    assert json.loads(previous.read_text())['view_number'] == number-1
obj = dict(UTC=datetime.now(timezone.utc).isoformat(), status='ACTUALLY READ — complete selected text and matching displayed image',
    exact_version='arXiv:2608.08262v2', source_PDF_SHA256=view['source_PDF_SHA256'],
    view_number=number, physical_pages=view['physical_pages'],
    full_selected_text_read=True, matching_rendered_image_displayed_and_read=True,
    image_path=view['path'], image_SHA256=view['image_SHA256'],
    selected_text_path=view['selected_text_path'], selected_text_SHA256=view['selected_text_SHA256'],
    note_path=str(note), note_SHA256=sha(note),
    previous_receipt_SHA256=sha(previous) if previous else None,
    actual_primary_reading_credit=len(view['physical_pages']), no_other_page_credit=True,
    recursive_dependency_clearance=False, independent_model_verdict=False, book_changed=False,
    helper_source=__file__, helper_SHA256=sha(__file__))
receipt.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(dict(view=number, actual_pages=view['physical_pages'], receipt_SHA256=sha(receipt))))
