from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,requests,fitz
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009/dependencies_v1/Maillot00Published')
assert not C.exists();C.mkdir()
url='https://smf.emath.fr/system/files/filepdf/MSMF_2000_2_80__R3_0.pdf'
r=requests.get(url,timeout=30);r.raise_for_status();assert r.content.startswith(b'%PDF-')
p=C/'Maillot_Arakelov_toric_integrable_2000_published.pdf';p.write_bytes(r.content)
sha=lambda x:hashlib.sha256(Path(x).read_bytes()).hexdigest()
doc=fitz.open(p);texts=[page.get_text(sort=True) for page in doc]
t=C/'Maillot_preparation_text.txt';t.write_text('\n\f\n'.join('PHYSICAL PAGE %d\n%s'%(i+1,s) for i,s in enumerate(texts)))
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACQUIRED AND TEXT PREPARED — zero actual-reading credit',title="Géométrie d’Arakelov des variétés toriques et fibrés en droites intégrables",author='Vincent Maillot',DOI='10.24033/msmf.393',edition='Mémoires SMF 80 (2000)',requested_URL=url,resolved_URL=r.url,content_type=r.headers.get('content-type'),path=str(p),bytes=p.stat().st_size,SHA256=sha(p),physical_pages=len(doc),preparation_text_path=str(t),preparation_text_SHA256=sha(t),metadata_sources=['https://smf.emath.fr/publications/geometrie-darakelov-des-varietes-toriques-et-fibres-en-droites-integrables','https://www.numdam.org/item/MSMF_2000_2_80__R3_0/'],actual_primary_reading_credit=0,mathematical_clearance=False,book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__))
(C/'source_acquisition_v1_20261009.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
hits=[]
for i,s in enumerate(texts):
 if re.search(r'4\s*\.\s*6\s*\.\s*1',s):hits.append(dict(physical_page=i+1,matched_lines=[line for line in s.splitlines() if re.search(r'4\s*\.\s*6\s*\.\s*1',line)]))
print(json.dumps(dict(status=obj['status'],pages=len(doc),SHA256=sha(p),search_hits=hits),ensure_ascii=False))
