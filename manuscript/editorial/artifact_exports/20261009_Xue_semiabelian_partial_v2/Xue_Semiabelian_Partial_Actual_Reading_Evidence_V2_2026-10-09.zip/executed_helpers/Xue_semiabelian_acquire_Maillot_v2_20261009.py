from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, urllib.request
import fitz

C = Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009/dependencies_v1/Maillot00Published')
assert not C.exists(), 'Preserve existing evidence; use a fresh acquisition version.'
url = 'https://smf.emath.fr/system/files/filepdf/MSMF_2000_2_80__R3_0.pdf'
with urllib.request.urlopen(url, timeout=30) as response:
    payload = response.read()
    resolved_url = response.geturl()
    content_type = response.headers.get('Content-Type')
assert payload.startswith(b'%PDF-'), 'Response is not a PDF.'
C.mkdir()
p = C / 'Maillot_Arakelov_toric_integrable_2000_published.pdf'
p.write_bytes(payload)
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
doc = fitz.open(p)
texts = [page.get_text(sort=True) for page in doc]
t = C / 'Maillot_preparation_text.txt'
t.write_text('\n\f\n'.join('PHYSICAL PAGE %d\n%s' % (i + 1, text) for i, text in enumerate(texts)))
obj = dict(UTC=datetime.now(timezone.utc).isoformat(), status='ACQUIRED AND TEXT PREPARED — zero actual-reading credit', title='Géométrie d’Arakelov des variétés toriques et fibrés en droites intégrables', author='Vincent Maillot', DOI='10.24033/msmf.393', edition='Mémoires SMF 80 (2000)', requested_URL=url, resolved_URL=resolved_url, content_type=content_type, path=str(p), bytes=p.stat().st_size, SHA256=sha(p), physical_pages=len(doc), preparation_text_path=str(t), preparation_text_SHA256=sha(t), metadata_sources=['https://smf.emath.fr/publications/geometrie-darakelov-des-varietes-toriques-et-fibres-en-droites-integrables', 'https://www.numdam.org/item/MSMF_2000_2_80__R3_0/'], actual_primary_reading_credit=0, mathematical_clearance=False, book_changed=False, helper_source=__file__, helper_SHA256=sha(__file__), prior_helper='Xue_semiabelian_acquire_Maillot_v1_20261009.py', prior_failure='ModuleNotFoundError: requests, before acquisition or evidence-directory creation')
(C / 'source_acquisition_v2_20261009.json').write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
hits = []
for i, page_text in enumerate(texts):
    matched = [line for line in page_text.splitlines() if re.search(r'4\s*\.\s*6\s*\.\s*1', line)]
    if matched:
        hits.append(dict(physical_page=i + 1, matched_lines=matched))
print(json.dumps(dict(status=obj['status'], pages=len(doc), SHA256=sha(p), search_hits=hits), ensure_ascii=False))
