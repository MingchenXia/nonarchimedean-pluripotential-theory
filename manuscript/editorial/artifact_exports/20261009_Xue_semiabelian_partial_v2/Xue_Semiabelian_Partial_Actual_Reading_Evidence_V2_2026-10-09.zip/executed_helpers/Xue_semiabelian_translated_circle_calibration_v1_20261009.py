from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction
import hashlib,json
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009')
p=C/'translated_circle_calibration_v1_20261009.json';assert not p.exists()
rows=[]
for n in [1,2,3,4,8,16]:
    source=Fraction(4**n,1+4**n);target=Fraction(4,5)
    rows.append(dict(n=n,source_integral=str(source),target_integral=str(target),difference=str(source-target)))
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='EXACT ELEMENTARY TORIC CALIBRATION — printed auxiliary estimates 54–56 fail',source_version='arXiv:2608.08262v2',source_PDF_SHA256='fc81cd8cb291fac389bc0bab50e96711240249498bec0ac4be3a90578edd12d5',actual_source_locator='pp. 34, 38–39; family definition, Lemma 54, Proposition 55, Lemma 56, Remark 57',category='K=Q, A=0, G=Gm, compactification P1, D=[0]+[infinity]',metric='Canonical boundary metric translated by a=2, with local critical vectors val_v(2), weighted sum zero; quasi-canonical semipositive and arithmetic T-effective, global roof zero',compressed_reference='D_m=m^{-1}[m]^*Dbar; archimedean probability Haar on radius 2^{1/m}',tower='Gn=G; phi_n(z)=z^n',test='f(z)=|z|^2/(1+|z|^2), smooth continuous on P1 with f(infinity)=1',source_test='f_{m,n}(z)=f(z^{mn})',source_integral='4^n/(1+4^n)',target_integral='4/5',normalized_limit_difference='1/5',unnormalized_limit_difference='2/5',predicted_normalized_error='O(1/n)',independent_of_positive_m=True,works_for_m_le_n=True,correct_metric_identity='(1/n)phi_n^*D_m=D_{mn}',intended_main_theorem_counterexample=False,complete_proof_repair=False,new_book_theorem=False,independent_verifier_receipt=False,book_changed=False,rows=rows,helper_source=__file__,helper_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],normalized_limit_difference='1/5',calibration_SHA256=hashlib.sha256(p.read_bytes()).hexdigest())))
