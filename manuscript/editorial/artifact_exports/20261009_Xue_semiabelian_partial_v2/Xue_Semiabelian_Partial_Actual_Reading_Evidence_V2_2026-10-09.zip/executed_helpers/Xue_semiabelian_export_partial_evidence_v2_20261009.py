from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile

R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Xue_semiabelian_review_20261009';E=R/'manuscript/editorial'
K=C/'dependencies_v1/Maillot00Published'
W=Path('/tmp/Xue_semiabelian_primary_views_v1_20261009');WK=Path('/tmp/Xue_semiabelian_dependency_views_v1_20261009/Maillot00Published')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();now=lambda:datetime.now(timezone.utc).isoformat()
def check_chain(folder,prep_path,view_path,count):
    prep=json.loads(prep_path.read_text());assert sha(prep['source']['path'])==prep['source']['SHA256']
    assert sha(view_path/'manifest.json')==prep['manifest_SHA256']
    out=[];pages=[];previous=None
    for i in range(1,count+1):
        note=folder/('note_%02d.md'%i);receipt=folder/('note_%02d_receipt.json'%i);d=json.loads(receipt.read_text())
        assert d['view_number']==i and d['source_PDF_SHA256']==prep['source']['SHA256'] and d['note_SHA256']==sha(note) and d['previous_receipt_SHA256']==previous
        assert d['full_selected_text_read'] and d['matching_rendered_image_displayed_and_read']
        assert sha(d['image_path'])==d['image_SHA256'] and sha(d['selected_text_path'])==d['selected_text_SHA256']
        pages+=d['physical_pages'];previous=sha(receipt)
        out.append(dict(view_number=i,physical_pages=d['physical_pages'],note_path=str(note),note_SHA256=sha(note),receipt_path=str(receipt),receipt_SHA256=sha(receipt)))
    return prep,out,pages

prep,receipts,pages=check_chain(C/'primary_notes_v1',C/'source_preparation_v1_20261009.json',W,20)
assert pages==list(range(1,41))
kp,kr,kpages=check_chain(K/'primary_notes_v1',K/'source_preparation_v1_20261009.json',WK,3)
assert kpages==[60,61,62,63,64] and kp['source']['physical_pages']==130
cal=C/'translated_circle_calibration_v1_20261009.json';dc=json.loads(cal.read_text())
assert dc['normalized_limit_difference']=='1/5' and not dc['intended_main_theorem_counterexample']
kc=K/'actual_source_checkpoint_v1_20261009.json';assert not kc.exists()
kd=dict(UTC=now(),status='COMPLETE BOUNDED ACTUAL READING — Maillot Theorem 4.6.1 and full printed proof, five selected pages only',DOI='10.24033/msmf.393',edition='Mémoires SMF 80 (2000)',source_PDF_SHA256=kp['source']['SHA256'],source_total_physical_pages=130,actual_pages=kpages,actual_matching_views=3,receipts=kr,other_page_credit=0,statement_and_complete_printed_proof_read=True,exact_theorem_locator='Theorem 4.6.1, physical page 61 / printed page 56; proof through physical 64 / printed 59',conclusion='Uniform smooth positive approximation of a continuous positive metric on an ample bundle; proof lower bound is relative to smooth Kähler alpha',strong_singular_current_domination_not_supplied=True,all_recursive_inputs_verified=False,Kuhne_A1a_cleared=False,Kuhne_A2_repaired=False,intended_main_theorem_counterexample=False,book_changed=False,new_original_result=False,independent_verifier_receipt=False,helper_source=__file__,helper_SHA256=sha(__file__))
kc.write_text(json.dumps(kd,ensure_ascii=False,indent=2)+'\n')
old=C/'source_checkpoint_v1_20261009.json';od=json.loads(old.read_text());assert od['actual_unique_pages']==list(range(1,21))
cp=C/'source_checkpoint_v2_20261009.json';assert not cp.exists()
findings=[
 dict(locator='Definition 4.21, p. 19; FRSS arXiv v2 Lemma 4.2, p. 15',kind='CONDITIONAL OBJECTION CLEARED IN INTENDED FORMAL-MODEL SCOPE',detail='Canonical unique-Shilov base norm is multiplicative. Arbitrary-affinoid calibration is not an actual counterexample to this intended scope; old notes stay frozen.'),
 dict(locator='pp. 21–22; Kühne published §3–4',kind='PUBLISHED LOCATOR FAILURE',detail='The alleged Raynaud/theta Theorem 3.6, §3.6, Proposition 3.13 and Theorem 4.7 are absent in the controlling published Kühne source.'),
 dict(locator='pp. 21–25',kind='CONDITIONAL HEIGHT REDUCTIONS',detail='Canonical Picard-zero bilinear heights and torsion lifting are valid formal ingredients; raw theta, all-chart norms and period transition identifications remain unverified.'),
 dict(locator='Lemma 34, p. 29',kind='COMPRESSED DEGREE/ABELIAN FACTOR OMISSION',detail='Genuine [m]_G has degree m^{t+2g} and multiplies N by m². The printed separate m exponent is incorrect; a joint n,m calculation may retain intended bound for m<=n with compatible reference metrics.'),
 dict(locator='Proposition 37; Lemmas 39–43, pp. 30–33',kind='VOLUME/SIGN/HYPOTHESIS SCOPE',detail='Retain vertical as well as horizontal semipositivity, both signs of constant-shift estimate, real source numbering, and a genuine chi-volume base-extension input.'),
 dict(locator='Lemma 41, pp. 31–32',kind='MIXED MASS NORMALIZATION',detail='Nonleading positive measures of zero mass vanish, but full Chern power requires binomial(d,t); alternatively divide mixed measure by its mixed degree.'),
 dict(locator='Proposition 45, p. 34',kind='CONVERSE INPUT NOT CLEARED',detail='Pushforward measure identity alone does not prove finite-pullback equidistribution converse; smallness needs abelian-height vanishing.'),
 dict(locator='Proposition 46 and Lemmas 47–49, pp. 34–36',kind='PICARD CLASS CONSTRUCTION NOT CLEARED',detail='A metric tropical shift does not automatically define a new algebraic Picard class or its n-division. Direct section norms give a separate conditional calibration with weighted constants.'),
 dict(locator='L(m,n) definition p. 34; Lemma 54, Proposition 55, Lemma 56, Remark 57 pp. 38–39',kind='LITERAL AUXILIARY ESTIMATES FAIL ELEMENTARY TORIC CALIBRATION',detail='Translated P1 boundary metric a=2: normalized source test integral 4^n/(1+4^n), target 4/5, limit difference 1/5. Correct pullback uses D_mn; same underlying algebraic degree cannot remove the metric mismatch.'),
 dict(locator='Maillot Theorem 4.6.1, printed pp. 56–59',kind='ORIGINAL REGULARIZATION INPUT CHECKED',detail='Uniform positive smooth approximation and smooth Kähler lower bound do not give the singular-current domination in Kühne A.1(a). No Appendix A.2 logarithmic proof repair.')]
checkpoint=dict(UTC=now(),status='PARTIAL ACTUAL PRIMARY READING — 40 of 83 pages; printed auxiliary measure estimates fail; main proof unverified',exact_version='arXiv:2608.08262v2',source_PDF_SHA256=prep['source']['SHA256'],source_bytes=prep['source']['bytes'],total_physical_pages=83,metadata_pages=82,actual_unique_pages=pages,actual_matching_views=20,unread_pages=list(range(41,84)),receipts=receipts,prior_checkpoint_SHA256=sha(old),prior_checkpoint_preserved=True,findings=findings,earlier_findings_reference='source_checkpoint_v1_20261009.json',mathematical_clearance=False,independent_verifier_receipt=False,intended_main_theorem_counterexample=False,literal_auxiliary_estimates_54_56_cleared=False,complete_proof_repair=False,book_changed=False,canonical_status_changes=[],FRSS_arxiv_actual_pages=21,FRSS_journal_locators_authenticated=False,Kuhne_published_actual_pages=55,Maillot_bounded_actual_pages=5,Maillot_total_physical_pages=130,Maillot_checkpoint_SHA256=sha(kc),translated_circle_calibration_SHA256=sha(cal),native_catalogue_source_published=True,native_catalogue_compile_success_verified=False,helper_source=__file__,helper_SHA256=sha(__file__))
cp.write_text(json.dumps(checkpoint,ensure_ascii=False,indent=2)+'\n')
prefix='Xue_semiabelian_partial_source_'
paths={key:E/(prefix+key+'_v2_20261009.'+ext) for key,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in paths.values())
review='''# Xue semiabelian source: forty-page checkpoint and original-input addendum

Wei Xue, *Equidistribution for semiabelian varieties over number fields*,
arXiv:2608.08262v2, revised 30 August 2026. Exact PDF SHA256:
`fc81cd8cb291fac389bc0bab50e96711240249498bec0ac4be3a90578edd12d5`.
**Actual reading: pages 1–40 of 83, twenty complete-text and matching-image
displays. Pages 41–83 remain unread at this checkpoint.** The earlier
twenty-page checkpoint and exports remain frozen. The main theorem proofs
are unverified and have not been integrated into the book.

## A concrete failure of the printed compression estimates

Pages 34 and 38–39 define L(m,n)=Gn(D_m)+pi_n^*N and compare source and
target with the same horizontal index m. For a translated quasi-canonical
toric metric, the metrized n-pullback instead has horizontal index mn.
Remark 57 explicitly records (1/n)phi_n^*D_m=D_mn, but still claims that
the geometric degree/local-intersection comparison bypasses this change.

The simplest source-permitted case tests that claim exactly. Set K=Q,
A=0, G=Gm, X=P1 and D=[0]+[infinity]. Translate its canonical boundary
metric by a=2. The critical vectors val_v(2) have weighted sum zero;
the metric is semipositive, quasi-canonical and arithmetically T-effective,
with global roof zero. D_m has complex probability measure on the circle
of radius 2^(1/m), Gn=G and phi_n(z)=z^n. For the smooth projective test
f(z)=|z|²/(1+|z|²), the printed source integral of f(z^(mn)) is
4^n/(1+4^n), while its target integral is 4/5. The difference tends to
**1/5**, rather than O(1/n). Unnormalized mass-two measures give 2/5.
The discrepancy is independent of positive m, including m<=n.

This disproves the literal auxiliary measure comparison in Lemma 54,
Proposition 55 and Lemma 56. It **does not refute the intended main
equidistribution theorem**: translated toric equidistribution is a known
case. Changing the family index would alter the rest of the proof, which
has not been repaired or completely read. No new book theorem or
independent verifier receipt is claimed.

## Other proof obligations and a direct scaling check

Genuine group multiplication also acts on the abelian quotient: its total
degree is m^(t+2g), and the symmetric canonical abelian factor scales by
m². The separately asserted m exponent in Lemma 34 omits that effect.
A compatible joint n,m projection calculation gives a factor
(nm)^(r-1)*(m/n)^(g-j), which can retain the desired upper bound for
j<=g and m<=n. This conditional formal calculation does not fix the
noncanonical metric mismatch just exhibited.

The source's theta/canonical norm and unit-period identifications remain
unverified. The alleged published Kühne theta locators do not exist.
The FRSS arXiv full read clears the earlier arbitrary-affinoid objection
in the intended canonical formal-model base-point scope; it does not
authenticate differing journal numbering or remove period multipliers.
The new Picard-zero class attributed to a toric metric shift is not
constructed, and its claimed n-division is not automatic. Volume estimates
retain vertical positivity, field weights, constant-shift signs and a
genuine chi-volume normalization input. Full Chern powers retain the
leading binomial; mixed probabilities use their own mixed degree.

## Maillot's controlling regularization theorem

The original public Maillot PDF has SHA256
`f0914fea5aa08980632f4180b192c1feb0d98462456508c655d5ca19b210e4e1`.
Only physical pages **60–64 of 130** were actually read, in three matching
displays. They include the exact Theorem 4.6.1 statement (printed p. 56)
and its complete proof through printed p. 59. It proves uniform smooth
positive approximation of a positive continuous metric on an ample
bundle. The gluing proof retains a lower bound relative to a **smooth
Kähler form**, not a fixed positive multiple of the original singular
Chern current. Thus this original citation does not clear the printed
stronger inequality in Kühne Appendix A.1(a) or its logarithmic-limit use
in A.2. Richberg/Demailly inputs remain imported; no full repair is claimed.

## Current book and evidence scope

The active book remains **4,675 pages**. Its 42 canonical atoms, twelve
formal problems and tiers are unchanged. BJ22 general homogeneous Siu
and envelopes remain OPEN. The separately uploaded catalogue supplement
has a completed source audit, but native compilation remains unverified
after three diagnostic calls returned no result; the historical PDF is
not certified current. The same editor remains open.

The archive has 63 authored note, receipt, acquisition/preparation,
checkpoint, calculation and executed-helper members. It excludes primary
paper PDFs, full extracted text and rendered page images. Earlier records
are preserved, and uploading adds no actual reading credit.
'''
paths['review'].write_text(review)
notes='# Actual Xue partial reading and Maillot bounded input check\n\nXue 1–40/83 in twenty views; Maillot 60–64/130 in three views.\n\n'
notes+='\n\n---\n\n'.join((C/'primary_notes_v1'/('note_%02d.md'%i)).read_text().rstrip() for i in range(1,21))
notes+='\n\n# Maillot bounded source notes\n\n'+'\n\n---\n\n'.join((K/'primary_notes_v1'/('note_%02d.md'%i)).read_text().rstrip() for i in range(1,4))+'\n'
paths['reading_notes'].write_text(notes)
manifest=dict(checkpoint,controlling_source_URL='https://arxiv.org/pdf/2608.08262v2',checkpoint_SHA256=sha(cp),Maillot_source_URL='https://smf.emath.fr/system/files/filepdf/MSMF_2000_2_80__R3_0.pdf',Maillot_PDF_SHA256=kp['source']['SHA256'],Maillot_actual_pages=kpages,Maillot_receipts=kr,prior_publication_record='manuscript/editorial/Xue_semiabelian_partial_GitHub_publication_v1_20261009.json',FRSS_publication_record='manuscript/editorial/Xue_theta_dependency_GitHub_publication_v1_20261009.json',Kuhne_publication_record='manuscript/editorial/Kuhne_semiabelian_dependency_GitHub_publication_v1_20261009.json')
paths['manifest'].write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
X=E/'artifact_exports/20261009_Xue_semiabelian_partial_v2';assert not X.exists();X.mkdir()
members={}
for folder,count,prefix0 in [(C/'primary_notes_v1',20,'Xue/primary_notes_v1/'),(K/'primary_notes_v1',3,'Maillot/primary_notes_v1/')]:
    for i in range(1,count+1):
        for suffix in ['.md','_receipt.json']:
            p=folder/('note_%02d'%i+suffix);members[prefix0+p.name]=p
for name in ['source_acquisition_v1_20261009.json','source_preparation_v1_20261009.json','source_checkpoint_v1_20261009.json','source_checkpoint_v2_20261009.json','translated_circle_calibration_v1_20261009.json']:
    members['Xue/records/'+name]=C/name
members['Xue/records/prepared_view_manifest.json']=W/'manifest.json'
for name in ['source_acquisition_v2_20261009.json','source_preparation_v1_20261009.json','actual_source_checkpoint_v1_20261009.json']:
    members['Maillot/records/'+name]=K/name
members['Maillot/records/prepared_view_manifest.json']=WK/'manifest.json'
for name in ['Xue_semiabelian_acquire_Maillot_v1_20261009.py','Xue_semiabelian_acquire_Maillot_v2_20261009.py','Xue_semiabelian_prepare_Maillot_bounded_v1_20261009.py','Xue_semiabelian_record_dependency_reading_v1_20261009.py','Xue_semiabelian_record_reading_v1_20261009.py','Xue_semiabelian_translated_circle_calibration_v1_20261009.py','Xue_semiabelian_export_partial_evidence_v2_20261009.py']:
    members['executed_helpers/'+name]=Path('/tmp')/name
assert len(members)==63
archive=X/'Xue_Semiabelian_Partial_Actual_Reading_Evidence_V2_2026-10-09.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(members.items()):z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==63
    for name,p in members.items():assert z.read(name)==p.read_bytes()
(X/'README.md').write_text('''# Forty-page Xue checkpoint and bounded Maillot evidence

Xue arXiv v2: physical 1–40/83 in twenty matching text/image views.
Maillot 2000: physical 60–64/130 in three matching displays, including
Theorem 4.6.1 and its complete proof. No other page credit is claimed.

The ZIP has 63 authored note/receipt/record/calculation/helper members.
Primary PDFs, full text and images are not redistributed. The explicit
translated-circle calculation flags printed auxiliary estimates 54–56;
it does not refute the intended main theorem. Main proofs are unverified
and unintegrated. The active 4,675-page book is unchanged.
''')
(X/'SHA256SUMS').write_text(sha(archive)+'  '+archive.name+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=now(),status='EXPORTED — partial source evidence and bounded original-input addendum',archive=str(archive.relative_to(R)),bytes=archive.stat().st_size,SHA256=sha(archive),members=63,actual_Xue_pages=40,total_Xue_pages=83,Xue_views=20,actual_Maillot_pages=5,total_Maillot_pages=130,Maillot_views=3,book_changed=False,intended_main_theorem_counterexample=False,independent_verifier_receipt=False,new_reading_credit_for_upload=0),indent=2)+'\n')
update='''
## Xue forty-page source checkpoint and Maillot input, 9 October 2026

Xue arXiv:2608.08262v2 is now actually read on **1–40/83 pages**, in
twenty matching views. A translated P1 boundary metric makes the printed
auxiliary compression comparisons 54–56 fail: the normalized test-integral
gap tends to 1/5. This is not a counterexample to the intended main theorem;
the main proofs remain unverified and unintegrated. Five selected Maillot
pages contain Theorem 4.6.1 and its full proof, which does not give Kühne's
printed singular-current domination. Earlier checkpoints remain frozen.

See [source addendum](manuscript/editorial/Xue_semiabelian_partial_source_review_v2_20261009.md)
and [authored evidence](manuscript/editorial/artifact_exports/20261009_Xue_semiabelian_partial_v2/).
The active **4,675-page book** and canonical statuses are unchanged.
The catalogue's supplementary source upload is separately verified;
native compilation remains unverified and its historical PDF is unchanged.
'''
readme=R/'README.md';readme.write_text(readme.read_text().rstrip()+'\n'+update)
progress=E/'second_reading_and_research_programme_20261002.md';progress.write_text(progress.read_text().rstrip()+'\n'+update.replace('(manuscript/editorial/','('))
owned=[*paths.values(),*sorted(X.iterdir()),readme,progress];assert len(owned)==9
out=C/'partial_evidence_export_v2_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=now(),status='READY FOR EXPLICIT NINE-FILE PUBLICATION — forty-page partial evidence',owned_files=[dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,SHA256=sha(p)) for p in owned],archive_members=63,actual_Xue_pages=40,actual_Maillot_pages=5,book_changed=False,native_catalogue_changed_by_this_helper=False,helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
print(json.dumps(dict(status='EXPORTED',owned_files=9,archive_members=63,Xue_pages=40,Maillot_pages=5,archive_SHA256=sha(archive),export_SHA256=sha(out))))
