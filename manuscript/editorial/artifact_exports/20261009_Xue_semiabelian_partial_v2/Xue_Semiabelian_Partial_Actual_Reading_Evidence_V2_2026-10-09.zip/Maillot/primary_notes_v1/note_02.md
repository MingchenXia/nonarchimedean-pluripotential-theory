# Actual bounded reading 2 — Maillot 2000, physical pages 62–63 (printed 57–58)

Complete selected text and matching displayed image read. Actual bounded coverage is pages 60–63 only so far.

Lemma 4.6.2 gives the smooth convex regularized maximum: it is increasing in each coordinate, lies between the ordinary maximum and the maximum with its smoothing margins, ignores a coordinate sufficiently below another, and commutes with adding a common constant. Its curvature assertion assumes a common lower bound alpha in A^{1,1}(X), a smooth form in this notation. The lemma's proof is imported from Demailly, rather than established recursively by this reading.

Theorem 4.6.1's proof reduces by tensor power to a very ample bundle. In the strictly positive case it chooses a smooth Kähler form alpha with c_1(L,||.||)>=alpha. Nonvanishing global sections provide local potentials u_i=-log||s_i||^2. On finitely many nested coordinate balls, smooth psh regularizations are uniformly close, and small negative-quadratic corrections create the strict separation needed to glue on the inner balls. The corrected smooth potentials have dd^c lower bound (1-lambda) alpha, not (1-lambda)c_1 of the original metric.

Adding the logarithm of the section transition function transports each corrected potential into a chosen frame. The regularized maximum preserves the smooth common lower bound and the transition relation, producing global smooth positive metric weights with u_i<tilde u_i<=u_i+lambda. Since alpha is smooth, this argument is consistent with approximating singular positive curvature; it does not establish a smooth-current domination bound by a positive multiple of singular curvature.

This exact source distinction confirms that the Maillot citation cannot clear the literal stronger inequality in Kühne Appendix A.1(a). It does not refute the intended equidistribution theorem or supply the missing logarithmic-tail estimate.
