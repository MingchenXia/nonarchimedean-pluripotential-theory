# Actual bounded reading 1 — Maillot 2000, physical pages 60–61 (printed 55–56)

Complete selected text and matching displayed image read. This is bounded reading of pages 60–64, not a complete reading of the 130-page physical PDF.

Proposition 4.5.3 uses dd^c(-log ||s||^2)+delta_div(s)=c_1(L). Definition 4.5.4 calls a metric positive when its Chern current is nonnegative; strict positivity means local domination of a positive multiple of a smooth Kähler form. Definition 4.5.5 defines an admissible metric to be continuous positive and uniformly approximable by smooth positive metrics. Proposition 4.5.6 asserts well-defined logarithmic products for admissible bundles and meromorphic sections with proper intersection; its proof imports the generalized Poincaré–Lelong/current framework, which has not been recursively audited in this bounded reading.

Proposition 4.5.7 constructs a monotone increasing subsequence of smooth positive approximating norms by constant rescalings. Constants preserve curvature. The tensor-dynamical example 4.5.8 assumes a globally generated bundle and a specified pullback isomorphism with exponent k>1; pullback/rescaling iterates give smooth positive approximations to the Zhang metric. Neither statement says that a smooth approximating Chern current dominates a fixed positive fraction of the original possibly singular Chern current.

Theorem 4.6.1, printed page 56, concerns a complex projective variety and an ample line bundle: positive metrics are admissible. Its asserted conclusion is uniform approximation by smooth positive metrics in the preceding definition. The proof begins a Richberg regularization and gluing argument using a regularized maximum. The full proof continues through physical page 64 and must be read before interpreting the lower bounds.

No Xue page credit, no book edit, no independent original-result receipt, and no clearance of Kühne Appendix A.1(a) is claimed.
