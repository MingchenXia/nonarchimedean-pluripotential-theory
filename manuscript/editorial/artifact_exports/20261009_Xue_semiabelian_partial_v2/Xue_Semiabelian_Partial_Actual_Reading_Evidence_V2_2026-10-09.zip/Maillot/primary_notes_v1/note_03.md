# Actual bounded reading 3 — Maillot 2000, physical page 64 (printed 59)

Complete selected text and matching displayed image read. Bounded reading is complete for physical pages 60–64: five pages in three views, with no other page credit.

The glued smooth norm satisfies exp(-lambda/2)<=||.||_lambda/||.||<=1 because the smooth weight differs from the original by a quantity in [0,lambda]. Letting lambda tend to zero gives uniform approximation in the strictly positive case; the source also chooses an increasing approximating sequence. For a merely positive metric it interpolates with a smooth strictly positive metric on the same ample bundle, with powers 1-1/n and 1/n. These strictly positive continuous metrics converge uniformly to the given metric; a diagonal choice of their smooth positive approximations proves admissibility.

The conclusion is positive smooth uniform approximation. The proof's smooth-form lower bound remains distinct from domination of the original Chern current. In particular, on the boundary metric of P^1 actually computed in Kühne Appendix B, the original curvature is supported on the unit circle. A smooth positive measure cannot dominate a fixed positive multiple of that singular measure: a thin neighborhood of the circle has smooth mass tending to zero and fixed positive original mass. This elementary calibration addresses the literal inequality only; it is not a new theorem or a counterexample to the intended main result.

Definition 4.7.1 defines an integrable bundle as the tensor difference of two admissible bundles. Its examples include arbitrary smooth metrics after an ample twist and canonical toric metrics. Proposition 4.7.3's statement begins at the end of the selected page, but its proof on the following page was not read and receives no proof-clearance credit.

Theorem 4.6.1's statement and complete printed proof have now been read. Its Demailly/Richberg regularization inputs and preceding general current calculus remain imported rather than recursively verified. No repaired proof of Kühne Appendix A.2, no main-theorem counterexample, no Xue page credit, and no book integration are claimed.
