# Xue v2 actual primary reading — view 8

Physical pages 15–16; exact PDF SHA256 fc81cd8cb291fac389bc0bab50e96711240249498bec0ac4be3a90578edd12d5.

Complete selected text and matching image read. The local product
construction uses g_i divided by a theta function evaluated at a chosen
Raynaud lift; the numerator has the character boundary divisor plus the
pulled-back divisor of a section of H_i-dual. The denominator removes
base zeros and poles. The affine-chart character calculation supplies
regular extension over the toric boundary and its inverse. Varying
rational sections on sufficiently small opens addresses the previous
finite-cover concern; this part should not be listed as an uncorrected
gap merely because one fixed section fails to cover its own divisor.

The proof's load-bearing overlap assertion is that a period-lattice
theta automorphy factor also occurs in the semiabelian descent cocycle
and cancels in g_i/f_i, yielding absolute-value-one transitions. The
displayed section-change identities establish cancellation when local
lifts agree. For different lattice lifts, the proof supplies only the
verbal cancellation claim, without the period/character formula or an
absolute-value calculation. A global rational numerator, a chosen
lift-dependent theta denominator, and the lifted fiber coordinate must
be distinguished here. Normalizing one value at the identity does not
control automorphy factors at all periods. The universal unit-norm
transition and canonical metric isometry remain a flagged source input;
no counterexample or final verdict is claimed before checking the
controlling theta/uniformization source and the later metric class.

Proposition 4.17 uses exactly this overlap assertion to glue arbitrary
toric metrics and finite continuous perturbations of the induced
canonical metric. Lemma 10 gives a good-place model explanation for
adelicity outside finitely many places; it does not settle bad-place
period compatibility. Linearity/uniform approximation extends the metric
construction to real divisors. The vertical semipositivity claim begins
at the foot of p. 16 and continues on p. 17. The denominator uses
sections of H_i-dual in this proof, so its relation to the first-page
H_m convention still needs explicit sign tracking.

Actual reading now covers pages 1–16. The new induced-metric construction
is not cleared for book integration.
