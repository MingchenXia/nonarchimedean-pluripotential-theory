# Xue v2 actual primary reading — view 6

Physical pages 11–12; exact PDF SHA256 fc81cd8cb291fac389bc0bab50e96711240249498bec0ac4be3a90578edd12d5.

Complete selected text and matching image read. The local metric definition
retains continuity, homogeneity, nonvanishing on a local frame and Galois
invariance. A literal error appears in Definition 3.20: Archimedean
semipositivity is printed as ddc c1(L,metric) >= 0. The correct standard
condition is positivity of the Chern current c1(L,metric) itself, or ddc
of a local metric potential. The Chern current is closed, so applying
ddc to it is not that positivity test; on a complex curve the extra
derivative even has degree exceeding the dimension. The toric concavity
criterion read earlier supplies the correct metric test in its proper
category. This printed definition is quarantined, not used to broaden
the main theorem's signature or called a counterexample to it.

Heights of subvarieties are normalized by (dimension+1) times geometric
degree, point heights by field degree. The first ratio requires nonzero
geometric degree, although the general introductory Definition 3.21
does not impose it before writing the quotient. Later quasi-canonical
and measure definitions explicitly require positive degree. These
normalizations must not be applied to a zero-degree restricted cycle.
Quasi-canonical means normalized variety height equals essential minimum,
with positive geometric degree. Convergence of all generic small orbit
measures supplies a unique probability limit; uniqueness uses interleaving
generic sequences and is not a separate mass-normalization assertion.

The projective ample quasi-canonical and Yuan–Zhang nef quasi-canonical
examples are cited inputs. The toric monocritical equivalence is stated
on the principal orbit, where smallness is governed by the essential
minimum; it does not identify the absolute minimum on boundary strata.
Kühne's semiabelian example and its claimed normalized Monge–Ampère
description need the later compression/mixed-measure argument and the
controlling original source. Neither the displayed general example nor
this reading resolves Ballaÿ–Sombra's explicit non-Archimedean measure
direction. Their exact relation remains pending.

Actual reading covers pages 1–12; no mathematical result has been promoted
or integrated from this candidate.
