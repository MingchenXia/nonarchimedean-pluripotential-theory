# Actual ordered reading 14 — Xue arXiv v2, physical pages 27–28

Complete selected text and matching displayed image read. Actual coverage now 1–28 of 83.

Lemma 28 completes the square: h_N(y)-(2/a)<y,qj,n> >= -a^{-2}h_N(qj,n), and n qj,n=qj gives the n^{-2} height decay. The printed equality phi_N(qj,n)=a H_mj^(n) requires compatible division choices; with arbitrary choices its difference is n-torsion. Canonical Picard-zero heights annihilate that torsion, so the height computation survives without asserting equality of arbitrary raw bundle representatives. Remark 30 correctly separates isogeny surjectivity on algebraic-closure points from surjectivity on K-rational points.

Proposition 29 combines the ample toric-section package with this bound. Its upper cycle-height bound uses essential minimum at most zero from dense torsion/zero-toric-height points and the imported fundamental inequality. The real ample divisor extension must preserve the T-effectivity and distribute positive base coefficients when summing constituent estimates. Arithmetic T-effectivity holds for the canonical metric of a T-effective divisor, but the torsion-lift norm comparison is still a source obligation in the present proof.

Remark 31 now uses genuine published Kühne Lemmas 4.4, 4.6, 2.5 and 2.6, unlike the nonexistent theta locators earlier. The volume input is the globally semipositive difference bigness inequality, not an unconditional equality between arithmetic volume and top self-intersection for arbitrary integrable differences. The source explicitly acknowledges that its standard (P1)^t compactification differs from the new general fan/divisor.

Lemma 32 is only a geometric numerical top-intersection statement: Picard-zero character bundles are numerically trivial, so top degrees with excess toric or excess abelian factors vanish. A smooth toric refinement and the projection formula handle normal fans. The controlling relative toric Chow-ring source is imported and has not been read in this checkpoint. Remark 33 appropriately disclaims general Chow-class or adelic-intersection vanishing. Those disclaimers mean that arithmetic perturbation powers still need independent bounds; numerical top-degree vanishing cannot justify them by itself.

Lemma 34 starts a restricted normalized quadratic scaling assertion for Fn=phi_n^*O_G(f), with f integrable and algebraically trivial. Its precise formula and proof continue on page 29, which is unread at this point. No promotion of this bridge estimate, no full proof clearance, and no book change are claimed.
