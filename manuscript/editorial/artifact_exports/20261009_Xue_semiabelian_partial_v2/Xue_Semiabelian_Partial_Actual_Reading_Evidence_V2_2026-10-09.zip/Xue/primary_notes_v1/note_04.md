# Xue v2 actual primary reading — view 4

Physical pages 7–8; exact PDF SHA256 fc81cd8cb291fac389bc0bab50e96711240249498bec0ac4be3a90578edd12d5.

Complete selected text and matching image read. Toric divisor positivity is
expressed by the support function and stability polytope; T-effectivity
means origin containment. Continuous toric metrics correspond to weights
whose difference from the reference support function extends to the
extended fan, and quasi-algebraicity means canonical weights outside
finitely many places. Local concave Legendre roofs are weighted to form
the global roof. Arithmetic nefness uses local concavity and nonnegative
global roof, while arithmetic effectivity uses the local values at zero.
The essential minimum equals the maximum roof, and the absolute minimum
on the open torus is the same quantity; this is not the absolute minimum
on the whole compactification, which can be smaller.

Three literal scope cautions are retained for the later audit. Definition
3.3 uses integral defining slopes in M, whereas real Cartier divisors
require the real extension M_R; a fractional multiple of O(1) already
has fractional support slopes. Proposition 3.6 says a section of the
quotient map has image in the compact unit torus S_v. Taken on the whole
extended fan, this cannot be literal: on the open torus S_v has valuation
zero, but a section over N_R must realize arbitrary valuations. The
usual Gauss/positive-real section ranges over the full toric skeleton,
with its valuation-zero fiber distinguished separately. This diagnoses
the printed image claim, not the later equidistribution theorem.
Proposition 3.11 needs nonempty stability set to speak of a maximum;
the main big-divisor setup has that condition, but the displayed
unrestricted preliminary statement does not say it.

The corner-complex paragraph correctly retains higher-codimension dual
cell volumes and reserves independent wall-current decompositions for
the extra product-corner condition. A critical vector is a tropical
translation, rather than a corner cell. General curvature formulas and
their application to subvarieties remain to be read.

Actual reading now covers pages 1–8. No deep cited toric result has been
recursively checked and no book statement has been changed from these
preliminary observations.
