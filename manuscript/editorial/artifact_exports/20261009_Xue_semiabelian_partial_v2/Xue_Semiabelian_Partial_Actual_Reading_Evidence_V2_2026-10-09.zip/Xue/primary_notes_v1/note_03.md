# Xue v2 actual primary reading — view 3

Physical pages 5–6; exact PDF SHA256 fc81cd8cb291fac389bc0bab50e96711240249498bec0ac4be3a90578edd12d5.

Complete selected text and matching image read. Theorem 1.4 concludes its
second part: the special-point hypothesis is needed for the equivalence
between a subvariety attaining the ambient essential minimum and being
L-special. The introduction separates Yuan–Zhang's quasi-canonical
equidistribution, Kühne's canonical semiabelian argument, BGPS toric
monocritical data, Ballaÿ–Sombra approximation and Hultberg toric-bundle
height/intersection calculations. It does not claim the latter height
formulas alone give the strict Bogomolov bridge. The stated new scope
remains the specified metric class with the general-fan Haar-slice input.

The proof roadmap is big-to-ample birational reduction, canonical
estimates for ample toric divisors, explicit quasi-canonical compression,
and monocritical tropical concentration under arithmetic T-effectivity.
The big-to-ample reduction and the transport assembly (called Proposition
100 here) remain to be inspected, rather than accepted from this roadmap.

Genericity means no subsequence contained in a proper algebraic subvariety,
equivalent to eventual avoidance. Smallness means convergence to the
essential minimum, not the normalized variety height. Normalized place
weights n_v=N_v/[K:K0] are used in heights, intersections and measures;
raw local degrees are divided out first. The product formula and
extension-weight sums match the earlier book conventions. The valuation
preliminary discussion includes function fields, but the paper's main
theorems are over number fields. The O_v/p_v/k_v integer-residue notation
in the number-field paragraph is meaningful at non-Archimedean places;
no Archimedean residue-ring construction is imported.

The toric notation uses N cocharacters, M its dual, and complete finite
strongly convex fans for proper toric varieties. No projectivity of an
arbitrary proper fan or positivity of a divisor has been inferred here.
Actual reading now covers pages 1–6 only; proof clearance is still pending.
