# Xue v2 actual primary reading — view 10

Physical pages 19–20; exact PDF SHA256 fc81cd8cb291fac389bc0bab50e96711240249498bec0ac4be3a90578edd12d5.

Complete selected text and matching image read. The local Fourier formula
defines a proposed skeleton point by max_u |a_u|_sup exp(-<u,v>).
Calling this a multiplicative seminorm requires the base sup-norm to be
multiplicative, for example through a specified unique Shilov/canonical
generic-reduction point. It is not true for an arbitrary affinoid base:
on a closed annulus rho<=|z|<=1, sup|z|=1, sup|z^-1|=rho^-1, but
sup|zz^-1|=1. The source's formal-chart meaning and controlling reference
must be checked before this proposed point is used. This is a scope
diagnostic, not a final counterexample to its intended canonical section.

Proposition 4.23 gives the theta cocycle identities with lambda and c_trop.
Proposition 4.24 claims the raw theta expression equals the canonical
Picard-zero local norm for every lift. Its proof first subtracts the
section's tropicalization to obtain a lift-invariant expression, then
asserts that lambda=0 makes that tropical correction constant. The
previous displayed identity does not support that inference: with
lambda=0 it still allows f_trop(v+u')=f_trop(v)-c_trop(u'), and c_trop
can be a nonzero additive character. The elementary data f_trop(v)=a*v,
c_trop(u')=-a*u' satisfy these displayed equations with nonconstant
f_trop when a!=0. This algebraic diagnostic is not asserted to be a
fully constructed adelic counterexample. Rigidification fixes a constant
and does not by itself kill such period slopes.

The principal-divisor passage also needs checking: substituting a pulled-
back rational function into the displayed W formula still leaves its
tropical correction unless that correction is separately constant.
Canonical Picard-zero metric uniqueness is a valid cited framework but
does not prove the raw-theta identification without those checks.
Remark 15 names primary uniformization/theta references and locators;
their identities and hypotheses are pending recursive inspection.
Proposition 4.25 starts a global-height formula using ordinary theta
absolute values and continues on p. 21. Its use in the lower bound cannot
be accepted from a verbal metric normalization alone.

Actual reading covers pages 1–20 in ten ordered matching displays.
The local metric construction and theta-height comparison are flagged
load-bearing inputs. No main equidistribution/Bogomolov theorem has been
cleared or inserted in the book.
