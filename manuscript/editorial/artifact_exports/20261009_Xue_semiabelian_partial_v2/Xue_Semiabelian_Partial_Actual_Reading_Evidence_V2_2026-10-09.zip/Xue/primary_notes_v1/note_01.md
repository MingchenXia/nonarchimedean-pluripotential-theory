# Xue v2 actual primary reading — view 1

Physical pages 1–2; exact PDF SHA256 fc81cd8cb291fac389bc0bab50e96711240249498bec0ac4be3a90578edd12d5.

Read the complete selected text and the displayed matching two-page image.
The PDF abstract states generic equidistribution for monocritical,
arithmetically T-effective toric metrics. Its Bogomolov conclusion is
unconditional for Kühne's standard product-of-P1 compactification and
conditional for a general fan on an independently established
curvature–Haar slice formula, with lattice-index normalization and absence
of extra boundary mass. This restriction is more explicit than the
abstract-page metadata and must control any eventual import.

The theta convention attaches H_G,m in Pic0(A_G) to the pushout by the
character m, writes the local toric coordinate as g_m/f_m composed with
the abelian projection, and introduces the dual only for the actual
negative character. Canonical flat metrics do not change the local
curvature statement; the convention fixes signs in local formulas.

The contents locate arithmetic T-effectivity at pp. 17–25, canonical
estimates at pp. 25–33, compression at pp. 33–41, monocritical extension
at pp. 42–47, and the long conditional/general-fan Bogomolov assembly
at pp. 47–81. Appendix A and references start at p. 82. Metadata says
82 pages, but the acquired exact-version PDF has 83 physical pages;
the internal date is September 1 while the arXiv margin is v2, 30 August.
These are recorded identity differences, not extra reading credit.

This is actual reading of these two pages only. Main proof claims and
their cited dependencies have not yet been cleared or integrated.
