# Xue v2 actual primary reading — view 7

Physical pages 13–14; exact PDF SHA256 fc81cd8cb291fac389bc0bab50e96711240249498bec0ac4be3a90578edd12d5.

Complete selected text and matching image read. Theorem 4.1 claims a finite
ordinary analytic open cover of the abelian quotient, product
trivializations of the associated compactification, an isometry for every
canonical toric Cartier divisor, and identical tropical valuations on
every overlap. The last two assertions are stronger than algebraic or
analytic local triviality alone: they require control of the absolute
values of the transition factors, not just their zero/pole divisors.
They remain unverified while the proof continues on pages 15–16.

The Raynaud uniformization inputs distinguish the auxiliary Raynaud torus
and good-reduction abelian quotient from the original semiabelian torus.
They give an analytic lattice covering, Fourier/theta expansions, descent
triples, and the zero/pole pullback equality for a rational section.
The skeleton is a real torus and the proof uses small contractible opens
with a covering section. Merely avoiding the divisor of one fixed
rational section does not cover points of that divisor; a full-cover
construction has to vary sections or frames, a point to check in the
continuation.

Proposition 9 lists analytic uniformization, theta divisor pullback and
the toric affine-chart extension criterion. The latter controls analytic
regularity/zero poles; it does not by itself establish metric isometry
or unit-norm transitions. The proof begins with character-basis extension
classes H_i and boundary divisor relations, then chooses an open avoiding
divisors of rational sections of H_i-dual. This must be reconciled with
the first-page denominator convention for H_m itself. No sign repair is
assumed before the following formulas have been read.

Actual reading covers pages 1–14. The local-isometry claim and its use in
arithmetic T-effectivity are still pending; no theorem import or
counterexample verdict has been made.
