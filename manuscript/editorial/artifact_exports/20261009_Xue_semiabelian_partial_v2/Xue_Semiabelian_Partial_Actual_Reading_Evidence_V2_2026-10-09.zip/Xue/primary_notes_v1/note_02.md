# Xue v2 actual primary reading — view 2

Physical pages 3–4; exact PDF SHA256 fc81cd8cb291fac389bc0bab50e96711240249498bec0ac4be3a90578edd12d5.

Read the complete selected text and matching displayed image. The
introduction defines the essential minimum through nonempty Zariski open
sets and recalls the classical torsion-subvariety formulation. Questions
1.1 and 1.2 are motivating relative programmes: the first asks for special
subvarieties/positive minima under relative dynamical hypotheses, and the
second asks when fiber and Deligne-pairing equidistribution yield total
equidistribution. These introductory descriptions do not supply a precise
general definition of specialness or an independently proved relative
theorem. Relative ampleness alone should not be imported as giving a
globally nef adelic metric with zero essential minimum.

The exact main setup uses a semiabelian variety with split toric rank t,
abelian quotient dimension g, a normal proper toric compactification,
a big T-effective geometric toric R-divisor, and a semipositive,
monocritical, arithmetically T-effective toric metric. The abelian factor
is symmetric ample with its canonical metric. Theorem 1.3 asserts generic
small-sequence equidistribution at every place in this class; its displayed
mixed measure is asserted in the additionally quasi-canonical case and
has denominator G(D)^t times (pi*N)^g, not the full (t+g)-fold volume
without its binomial coefficient.

Theorem 1.4 adds geometric ampleness and, at every Archimedean place,
either the standard product-of-P1 compactification or an independently
established general-fan curvature–Haar slice formula for all subvarieties
used in the difference-map argument. Lattice-index and no-extra-boundary-
mass assertions are explicit. The theorem's first conclusion begins on
p. 4 and continues on p. 5; no whole theorem proof clearance is claimed.
These four actually read pages do not yet clear Section 9 or its inputs.
