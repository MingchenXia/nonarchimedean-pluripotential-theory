# Xue v2 actual primary reading — view 9

Physical pages 17–18; exact PDF SHA256 fc81cd8cb291fac389bc0bab50e96711240249498bec0ac4be3a90578edd12d5.

Complete selected text and matching image read. Arithmetic T-effectivity
is a threshold-attainment property of the distinguished zero-character
section, with finitely supported local constants and their normalized
weighted sum equal to the open-torus absolute minimum. The local sup-norm
identity gives theta_v(0); hence the condition is exactly that the global
roof attain its maximum at zero. It is not implied by semipositivity or
bigness. A shifted quadratic roof demonstrates failure. The origin condition
must be retained, rather than replacing it by existence of some eigenline.
For genuinely integral eigensections the maximum-locus/lattice-point test
is meaningful; for R-divisors, ordinary line bundles/sections and formal
real scalar extensions must not be conflated.

Two geometric proof cautions are separate from that valid roof
calculation. Proposition 4.18's inference that G(D) is nef from the
ampleness of G(D)+pi*N needs letting the coefficient of the ample base
factor tend to zero, not just one fixed N. Its nef-to-ample approximation
also chooses an ample toric divisor on the original fan, which requires
projectivity and is not automatic for every proper fan in the main setup.
These are missing stated steps/scope conditions, not a claim that the
intended nefness conclusion is false.

Corollary 4.19 prints L^(g+t)=G(D)^t*(pi*N)^g. Even on the split product
with t=g=1, the left side is 2 D*N while the right side is D*N. The
binomial coefficient (g+t choose t) is missing when identifying the full
top self-intersection with the leading mixed term. Positivity and thus the
displayed bigness goal survive a positive coefficient; probability
normalizations cannot silently discard it. The mixed denominator in
Theorem 1.3 was read correctly as a mixed mass, not this erroneous full
volume identity.

The later theta calculation starts with a local split Raynaud extension
and Laurent expansion on a fixed tropical fiber. Its coefficient/norm
identities and whether they supply the missing period-norm compatibility
remain to be read. Arithmetic T-effectivity is stated as necessary only
for this distinguished-section proof mechanism, not as a proved necessary
condition for equidistribution or Bogomolov.

Actual reading covers pages 1–18. No new theorem or general-fan measure
formula has been accepted for the book.
