# Xue v2 actual primary reading — view 5

Physical pages 9–10; exact PDF SHA256 fc81cd8cb291fac389bc0bab50e96711240249498bec0ac4be3a90578edd12d5.

Complete selected text and matching image read. Monocritical means the
origin is a vertex of the concave roof's differential at every maximum
point; the balanced local critical vectors sum to zero with normalized
place weights and are independent of the maximum point. This matches the
correct zero-is-a-vertex convention in the Ballaÿ–Sombra appendix, rather
than its contrary literal remark. The definition alone is not a new
monocritical equivalence proved by this reading.

Semiabelian groups are connected smooth commutative extensions of an
abelian variety by a torus. The Weil–Barsotti class belongs to Pic0/Adual;
a homomorphism is determined by its toric and abelian maps with the
pushout/pullback compatibility of extension classes. The contracted
product construction associates a compactification and a line bundle to
a T-linearized toric line bundle. Properness uses the surrounding proper
toric convention. The smooth-fan Picard decomposition is recalled through
seesaw and linearizations. A splitting requires compatible choices of
linearizations: forgetting a linearization is not enough to define a
canonical associated line bundle, since characters change it by Pic0
factors. No canonical Picard splitting is inferred here.

The adelic preliminary material distinguishes the Yuan–Zhang Cauchy
completion over quasi-projective Z-models from a single projective model,
uses Hermitian Q-line bundles with identifications, and states the
arithmetic intersection arity as absolute model dimension. Thus over a
number field the arithmetic arity is one greater than relative geometric
dimension. The reified analytification functor and its essential-image
claim are cited inputs, not rederived in this reading. The main use is
the induced local metrized bundle at each place.

Actual reading covers pages 1–10 only. The canonical/compression estimates
and general-fan Bogomolov transport are still unreviewed.
