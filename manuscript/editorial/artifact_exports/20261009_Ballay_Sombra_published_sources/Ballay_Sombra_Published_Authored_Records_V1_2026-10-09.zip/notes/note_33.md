# Ballay–Sombra published source review — view 33

Physical pages: [65, 66].

Read the complete selected text and displayed matching rendered image.

Physical 65 completes the toric derivative squeeze: each n_v kappa_v<=mu-t, total affine error is at most #S(mu-t), and mixed-volume monotonicity bounds the normalized error by a fixed constant times (mu-t)/r(S_t;Delta_D). Wideness makes this vanish even when the maximizer set is lower dimensional. The formula then extends by DSP decomposition/density and torification; it applies to arbitrary continuous adelic metrics over a toric underlying E. Physical 66 defines generalized logarithmic Gauss–Mahler measure m_D(f). Monomials have zero global value by product formula and balanced u_v, whereas arbitrary nonzero Laurent polynomials have nonnegative value using a Newton vertex coefficient and the external Mahler lower bound. For chi^m-gamma the local integral is log max(exp(-<u_v,m>),|gamma|_v); its global value is sum_v n_v max(0,<u_v,m>+log|gamma|_v). Thus vanishing requires |gamma|_v=exp(-<u_v,m>) for every place, since the untruncated arguments sum to zero. This matches the negative-log valuation sign; changing the sign would pick the wrong translated torus. The Archimedean calculation uses Haar/Jensen, the non-Archimedean one uses Gauss norm; no unproved equality between these analytic constructions is assumed. All complete pages/render read, no blank; exact logarithmic-divisor application and converse follow next.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
