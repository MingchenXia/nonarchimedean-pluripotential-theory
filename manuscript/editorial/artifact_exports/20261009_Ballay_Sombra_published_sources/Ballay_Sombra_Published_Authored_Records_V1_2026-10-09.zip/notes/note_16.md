# Ballay–Sombra published source review — view 16

Physical pages: [31, 32].

Read the complete selected text and displayed matching rendered image.

Physical 31 completes Proposition 5.6 by the threshold-volume tail argument: a persistent bound mu_ess(Pbar_n)<=gamma<mu_ess(Dbar) would lose a fixed positive arithmetic-volume tail. The pullback remainder must be interpreted on X_n as phi_n*Dbar-Pbar_n; the printed shorthand involving Dbar and a transported Pbar_n cannot be used as an unrestricted Cartier pushforward on non-Q-factorial X. Threshold-series volume comparison is an imported monotonicity step, not a new cofinal-model statement. Definition 5.7 identifies the arithmetic positive intersection with (d+1)^(-1) times the derivative, while Remark 5.9 is a separate geometric positive-intersection analogue. Equations (5.2) normalize the arithmetic functional by vol(R^0), strictly positive for arithmetically big Dbar. Physical 32 gives Omega_Dbar as a limit of arithmetic mixed intersections divided by geometric P_n^d. It is positive on pseudo-effective inputs, kills principal data and sends [infinity] to one. It bounds mu_ess from above, not below. For each place its insertion into 0bar^phi represents n_v times a probability measure, whose mass and weak limit follow from normalized approximation measures and Lemma 4.23. These arithmetic Fujita measures are not automatically Galois-small-point limits without the additional Section 6 criterion. Section 6 reverts to geometric bigness only, explicitly distinguishing its domain from Section 5's arithmetic big cone. Both pages/readable renders complete, no blank.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
