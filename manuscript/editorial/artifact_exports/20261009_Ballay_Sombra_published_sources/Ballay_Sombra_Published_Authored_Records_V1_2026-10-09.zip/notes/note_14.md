# Ballay–Sombra published source review — view 14

Physical pages: [27, 28].

Read the complete selected text and displayed matching rendered image.

Physical 27 confirms the local test insertion phi->0bar^phi has arithmetic intersection (Dbar^d.0bar^phi)=n_v integral phi c1(Dbar_v)^d; a single-place perturbation keeps n_v, which must be divided out to recover a probability measure derivative. Section 5 uses the topology whose restrictions to finite-dimensional affine subspaces are Euclidean open. Definition 5.1 means finite one-sided directional derivatives whose map is linear on the chosen subspace, not Frechet differentiability in an unstated Banach norm. Physical 28 Lemma 5.2 proves concave directional existence and the inequality d_z<=-d_-z; oddness on the subspace plus superadditivity forces linearity. Finite slopes are bounded using values on a two-sided interior line interval. Definition 5.3's Fujita approximation is for arithmetically big Dbar, with adelically nef Pbar_n, pseudo-effective pullback remainder, and top arithmetic intersections converging to arithmetic volume. This is distinct from the main theorem's semipositive approximations controlled by minima/inradius. These sequences are selected scalar approximation sequences, not cofinality assertions over all modifications. Both pages and renders completely read; no blank. The Chen derivative realization is stated on the next page, not yet cleared.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
