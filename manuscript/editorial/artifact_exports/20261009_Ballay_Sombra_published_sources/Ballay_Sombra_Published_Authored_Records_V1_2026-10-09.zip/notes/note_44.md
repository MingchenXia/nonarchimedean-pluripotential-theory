# Ballay–Sombra published source review — view 44

Physical pages: [87, 88].

Read the complete selected text and displayed matching rendered image.

Physical 87: Lemma10.7 extends essential-minimum continuity to boundary Cauchy sequences using multiplicative height control after domination of Bbar. Its printed reduction Bbar<=k Dbar_i+t[infinity] cannot follow from arithmetic bigness for the literal fixed representative with negative horizontal coefficients; an effective linearly equivalent representative and its principal correction/dense-open height interpretation are needed. This is a representative-level caveat, not a counterexample to continuity. Discard indices with epsilon_i>=1 before multiplying essential minima. Lemma10.8 transfers pseudoeffective monotonicity using epsilon_i Bbar corrections and projective continuity. Physical88: Proposition10.9 is the completed-space quadratic estimate, requiring nef Pbar and Abar plus BOTH Abar+Ebar and Abar-Ebar nef, and geometric P,A big; model sequences chosen simultaneously as M_i,N_i give A_i=(M_i+N_i)/2 and E_i=(M_i-N_i)/2. Passing to limits uses essential minimum/intersection/volume/inradius continuity, not formal convergence alone. The zero-geometric-divisor specialization keeps constant denominator P^d. Definition10.10 uses birational arithmetic morphisms, semipositive big Q, and pseudoeffective remainder; these are quasi-projective adelic completed divisors, not all continuous projective adelic metrics.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
