# Ballay–Sombra published source review — view 23

Physical pages: [45, 46].

Read the complete selected text and displayed matching rendered image.

Physical 45 completes Proposition 7.1 by keeping the exact constant and linear Ebar terms, dropping nonnegative higher Pbar/Abar terms, and bounding Bbar=Abar-Ebar by 2Abar pseudo-effectively. Lemma 7.2 then bounds the finite expansion by lambda^2/r times max(1,(lambda/r)^(d-1)); an explicit adequate constant is 2(d+1)(3^d-1), so no n-dependent expansion constant is hidden. Corollary 7.3 restricts lambda<r/2 and applies Zhang's chi-volume lower bound on a still-geometrically-big perturbation. Physical 46 compares the denominator vol(P+lambda E) to P^d and handles the linear term's sign by a=sign(Pbar^d.Ebar), obtaining an additional O(lambda^2/r) error through |Pbar^d.Ebar|<=Pbar^d.Abar. For zero underlying E the volume denominator is exactly P^d. The main proof changes any fixed big reference by Lemma 3.2 and normalizes each Qbar_n by subtracting its absolute minimum, making tilde Qbar_n adelically nef with absolute minimum zero while leaving geometric rank, volume and inradius intact. This requires finite mu_abs for the retained approximants; (6.3) permits discarding any initial terms without that property. The displayed target group should be Div(X_n), not Div(X), for nonidentity modifications. No BJ22 critical Siu division is invoked. Both pages/render read fully, no blank; uniform mixed-term bounds and the final asymptotic scale continue.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
