# Ballay–Sombra published source review — view 5

Physical pages: [9, 10].

Read the complete selected text and displayed matching rendered image.

Physical 9 completes the genuine open direction: necessity of Theorem 2's approximation criterion on general varieties is Question 6.21, with only a technical-condition converse in Proposition 7.17. This is a different paper and problem from BJ22 Theorem 6.21. The proof uses arithmetic Siu inequality and Yuan–Zhang arithmetic Hodge index, not the critical homogeneous Siu division whose proof gap is recorded in the book. On a smooth projective curve, normal modifications are isomorphisms and r(Q_n;D)=deg(Q_n)/deg(D), so the hypothesis is delta_n/deg(Q_n)->0. Physical 10 derives the SUZ lower variational inequality from genericity, adelic pseudo-effectivity and chi-volume, eventually nef Qbar_n after a common height shift, and an O(lambda^2) error independent of n. The scale must satisfy delta_n/lambda_n->0 and lambda_n/deg(Q_n)->0 simultaneously; delta_n/deg(Q_n)->0 allows lambda_n=sqrt(delta_n deg(Q_n)) when delta_n>0, with a smaller chosen scale in the zero-defect case. Applying both Ebar and -Ebar squeezes liminf/limsup and establishes existence of both height and intersection limits. The text explicitly says the coarse quadratic estimate is insufficient in higher dimensions, requiring Corollary 7.3's inradius estimate. These are a proof overview, not yet the detailed theorem proof. Both full pages/render read, no blank.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
