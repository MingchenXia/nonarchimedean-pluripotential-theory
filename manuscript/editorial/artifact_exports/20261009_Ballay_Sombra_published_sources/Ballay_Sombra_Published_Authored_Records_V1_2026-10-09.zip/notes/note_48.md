# Ballay–Sombra published source review — view 48

Physical pages: [95, 96].

Read the complete selected text and displayed matching rendered image.

Physical95 completes A.3: failure of width ratio->0 gives uniform c>0 by monotonicity; minimum-width unit directions have a convergent subsequence; A.5 passes to a nonzero limiting Canadian-tent slope outside Cmax, and continuity extends over lower-dimensional Cmax. This confirms continuity/closed-concave regularity is needed in the Appendix setup. DefinitionA.6 is wide at the maximum. DefinitionA.7 balanced sup-gradients sum weighted to0 at one common maximizing point. PropositionA.8 obtains existence from sup-differential Minkowski sum (Burgos-Philippon-Sombra [11, Pr2.3.9]); uniqueness under wideness imports [14,Pr3.15], not recursively checked here. Dimensional n instead of d in A.7 is harmless notation typo. Physical96: mixed volume and mixed integral are alternating sums with factorial-normalized convention; identical mixed volumes give d! times Euclidean volume, identical d+1 mixed integrals give (d+1)! times integral. A.9 continuity is for uniformly inside approximating convex bodies; no arbitrary discontinuous concave endpoint assertion is imported. LemmaA.10 for affine f=<u,x>+c: MI(f repeated d,g)=MI(u|C repeated d,u|B)+c*d*MV(C repeated d-1,B)-d!vol(C)*g^vee(u). Lattice-polytope proof begins from Gualdi [24,Cor1.10,Pr1.5] and point-mass mixed real MA at slope u; remainder follows next physicalpage. These deep convex/mixed-intersection inputs remain explicit imports, not an original proof certificate.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
