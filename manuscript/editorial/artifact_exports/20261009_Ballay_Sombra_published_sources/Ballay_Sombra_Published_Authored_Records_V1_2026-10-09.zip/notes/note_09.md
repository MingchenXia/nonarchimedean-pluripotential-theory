# Ballay–Sombra published source review — view 9

Physical pages: [17, 18].

Read the complete selected text and displayed matching rendered image.

Physical 17 defines global semipositive/DSP data and gives the exact point-height formula sum_v n_v times the average of g over the finite Galois orbit, with R-linear-equivalent representative avoiding the point. Product formula makes this independent of representative. The local signed intersection measure has geometric total mass (D1...Dr.Z); it is positive for semipositive local Green functions. Cycle-height recursion uses r DSP factors but allows a further arbitrary continuous adelic R-divisor in the final factor. Physical 18 states integrability via external Chambert–Loir–Thuillier [17, Theorem 4.1], multilinearity, and symmetry only when the final factor is also DSP. Thus the stronger height formula can admit non-DSP Ebar as its last factor without pretending the whole mixed measure is defined for arbitrary singular metrics. Equation (4.4) for a zero-divisor test gives sum_v n_v integral(phi_v) against the local mixed measure, and (4.5) evaluates [infinity] as the geometric intersection. The section norm is exp(-g), again not exp(-g/2); (4.6) bounds heights below by -1/m sum_v n_v log supnorm outside the section's divisor. These fix sign, mass and local-weight diagnostics for possible integration. Both complete rendered pages read, no blank; the external integrability theorem is not recursively certified.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
