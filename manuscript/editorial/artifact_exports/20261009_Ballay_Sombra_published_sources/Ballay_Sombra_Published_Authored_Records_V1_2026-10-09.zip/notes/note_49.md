# Ballay–Sombra published source review — view 49

Physical pages: [97, 98].

Read the complete selected text and displayed matching rendered image.

Physical97 concludes LemmaA.10: recursive mixed-integral formula evaluates the point-mass mixed MA at u and (u|B)^vee(u)=0; general convex bodies follow by homothety plus uniform approximation. RemarkA.11 same-slope affine sup-convolution agrees with that slope on the Minkowski sum, so the affine mixed-integral term is linear in u; the balanced weighted slopes cancel this term in the toric theorem. Published article explicitly CC BY4.0, requiring authors/source credit, licence link, and indication of changes; original PDF unchanged and owned diagnostics are separate. Physical97-98 bibliography identifies exact external load-bearing sources: arithmetic-volume Chen2011, Fujita Chen2010, Ikoma2015 concavity, Moriwaki2016 adelic divisors, Gualdi-Martinez2022 DSP/cycle approximation, Burgos-Philippon-Sombra Asterisque360 2014 convex/toric metrics, Burgos-Philippon-Rivera-Letelier-Sombra AJM141 2019 equidistribution, CL-Thuillier AIF59 2009 logtests, Gualdi ANT12 2018 mixed integrals, and Yuan-Zhang book [40] on following page. These references are provenance only; their original proofs were not recursively read in this unit. Biswas is cited specifically arXiv2312.12084v3 (2024), Burgos-Kramer2403.11745v2 (2025), not automatically current published editions.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
