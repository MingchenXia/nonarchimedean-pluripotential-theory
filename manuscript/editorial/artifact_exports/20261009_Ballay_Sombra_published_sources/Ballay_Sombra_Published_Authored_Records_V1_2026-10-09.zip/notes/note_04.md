# Ballay–Sombra published source review — view 4

Physical pages: [7, 8].

Read the complete selected text and displayed matching rendered image.

Physical 7 separates a toric converse (semipositive only) from dynamical applications. A surjective endomorphism of normal projective X is finite; divisors D_i are R-linearly eigen-equivalent with q_i>1, and the introductory statement assumes each D_i effective and their sum ample. The local equilibrium limit is the normalized pullback of any semipositive measure over the sum, divided by deg(phi)^n, not a normalized pushforward. It equals the sum's own Monge–Ampere measure only when all canonical summands are semipositive. Physical 8 gives Qbar_n=q_max^(-n) phi^(n)*Dbar in the semipositive case; normalization removes its scalar, and the decay comparison is a forthcoming proof obligation. Logarithmic tests along preperiodic components require semipositive canonical summands (introductory Theorem 6). Section 1.5 announces an intrinsic positive-intersection formulation and a quasi-projective extension. The arithmetic Okounkov-body formulation is expressly deferred to a subsequent manuscript; this source does not supply that result or settle it for the book. The necessity question for arbitrary varieties begins at the page seam and must be completed before reporting. Fully read both pages and renders, no blank.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
