# Ballay–Sombra published source review — view 11

Physical pages: [21, 22].

Read the complete selected text and displayed matching rendered image.

Physical 21 states arithmetic Fujita (Theorem 4.9) only for arithmetically big Dbar, with a nef approximation and arithmetic volume accuracy; underlying bigness alone is not its premise. Theorem 4.10's arithmetic Siu inequality requires both adelic inputs nef and bounds chi-volume(P1bar-P2bar) below by P1bar^(d+1)-(d+1)P1bar^d.P2bar. Lemma 4.11 distinguishes geometric big plus a positive small-section threshold from plain existence of a section; multiplying small sections gives pseudo-effectivity. Physical 22 Lemma 4.12 shifts a geometrically big divisor by a sufficiently large positive Archimedean constant to make it arithmetically big. Lemma 4.13 proves one-direction closure of adelic pseudo-effectivity by volume continuity and adding a fixed big test divisor, not arbitrary sequence convergence in an unstated topology. Lemma 4.14 approximates any continuous adelic Ebar from below by DSP Ebar' over the same geometric divisor, with Ebar-Ebar' effective and Ebar'+epsilon[infinity]-Ebar pseudo-effective. The second comparison is adelic pseudo-effectivity, not pointwise effectiveness: finite-place errors are absorbed through a small-section/number-field argument. Its Moriwaki [30, Theorem 4.1.3] and [13, Lemma 1.11] remain external dependencies. Lemma 4.15's mixed monotonicity requires d adelically nef factors, with arbitrary continuous last factors and pseudo-effective difference. Its proof continues. Both pages fully read/displayed, no blank.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
