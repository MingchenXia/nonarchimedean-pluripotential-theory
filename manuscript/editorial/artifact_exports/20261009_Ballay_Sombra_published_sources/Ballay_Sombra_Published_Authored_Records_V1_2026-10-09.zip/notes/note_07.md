# Ballay–Sombra published source review — view 7

Physical pages: [13, 14].

Read the complete selected text and displayed matching rendered image.

Physical 13 defines r(P;A) for big underlying R-Cartier divisors, proves 0<r<infinity using ample intersections and volume continuity, and identifies the supremum with the attained pseudo-effective threshold. Scaling is r(delta P;A)=delta r(P;A), r(P;delta A)=delta^(-1)r(P;A); birational pullback invariance and Lemma 3.2 compare two fixed big references by constants independent of P. This makes the main condition insensitive to a fixed reference change but not to shrinking approximants. Physical 14 Lemma 3.3 requires both P,A big and nef and gives vol(P)/(d P^(d-1).A)<=r<=vol(P)/(P^(d-1).A), with the lower bound from geometric Siu, not arithmetic Siu or homogeneous Siu division. Lemma 3.4 also requires A-P pseudo-effective and bounds r>=vol(P)/(d vol(A)). Lemma 3.5 needs only P,A big plus A+/-E pseudo-effective and controls vol(P+lambda E) between (1-lambda/r)^d and (1+lambda/r)^d times vol(P), for 0<=lambda<=r. The proof rewrites P/r +/- E as pseudo-effective combinations; no nef E or pointwise positivity follows. The lower-bound proof continues on physical 15. P=tA supplies the elementary calibration r=t, bounding ratios t/d<=t<=t; d=1 is exact. All text and render read, no blank.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
