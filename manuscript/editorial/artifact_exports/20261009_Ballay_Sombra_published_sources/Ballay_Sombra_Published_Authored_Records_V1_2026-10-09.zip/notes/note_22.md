# Ballay–Sombra published source review — view 22

Physical pages: [43, 44].

Read the complete selected text and displayed matching rendered image.

Physical 43 states the general open Question 6.21 precisely: does full differentiability of mu_ess force liminf defect-threshold/rho=0; more strongly, does equidistribution at every place suffice? Full adelic-direction differentiability is stronger than differentiability in each zero-geometric test subspace, so these are two formulations, not automatically equivalent. Proposition 7.1 assumes nef Pbar with big underlying P and nef Abar with big underlying A, Abar+Ebar pseudo-effective and Abar-Ebar nef. Its chi-volume lower error is c_d max(1,(lambda/r)^(d-1)) (Pbar^d.Abar) lambda^2/r, with the arithmetic mixed term, not a fixed geometric error. Physical 44 proves Lemma 7.2's mixed estimate using geometric alpha=(P^(d-i).A^i)/(P^(d+1-i).A^(i-1)), whose denominator is positive by big-nef mixed intersections. The Hodge inequality is for the arithmetic square of Abar-alpha Pbar against d-1 remaining nef factors; discarding the nonnegative arithmetic alpha^2 term yields the factor 2. Induction and geometric pseudo-effective r-threshold produce (Pbar^(d-i).Abar^(i+1)) <=(2/r)^i(Pbar^d.Abar). Model approximation from above preserves adelic nefness. Original Moriwaki [30], Lazarsfeld [29] and Ikoma [27, Theorem 2.7] are explicit dependencies, not recursively certified. Proposition 7.1 begins applying arithmetic Siu to Pbar+lambda Abar and lambda(Abar-Ebar); the expansion continues. Both rendered pages read fully, no blank.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
