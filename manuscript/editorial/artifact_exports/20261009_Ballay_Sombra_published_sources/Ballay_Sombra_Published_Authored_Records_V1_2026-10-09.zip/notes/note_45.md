# Ballay–Sombra published source review — view 45

Physical pages: [89, 90].

Read the complete selected text and displayed matching rendered image.

Physical89-90: Theorem10.11 quasi-projective equidistribution uses two conditions: normalized Zhang gap divided by geometric inradius tends to zero, AND absolute-minimum defect divided by that inradius is uniformly bounded. This is weaker/different than insisting the latter tends to zero. Conclusions are weak convergence of normalized approximant MA and all generic small-point orbit measures to a probability measure on noncompact U. Initial tests are compactly supported; DSP approximation uses Gubler [25, Pr2.11,Th2.13,Lem2.16] with possible finite base extension, and the arithmetic open may be shrunk to represent the test and nef domination. Absolute-minimum normalization makes Qtilde nef by Lem10.6. Uniform kappa is asserted by the Lem7.6 argument and therefore inherits its downward-shift caveat; any presentation should retain nef A via a simultaneous upward target/approximation shift rather than lose neffness. Since underlying E=0, the arithmetic intersection with E is unchanged by constant normalization. Proof gives liminf small-point test height >= limsup approximant normalized intersection through gamma=max(gap/r,1/n), lambda=r sqrt(gamma); a negative lambda or arbitrary-zero denominator is never used. Noncompact mass/tightness proof is deferred to following page and must be read before crediting probability convergence.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
