# Ballay–Sombra published source review — view 47

Physical pages: [93, 94].

Read the complete selected text and displayed matching rendered image.

Physical93-94: sup-differential consists of u with f(x)-f(x0)<=<u,x-x0>. At a maximum, 0 belongs, and not being a vertex means a nonzero symmetric pair +/-u after possible rescaling, equivalently the Canadian-tent upper bound f<=mu-|<u,x-x0>|. This condition is independent of maximum chosen. PropositionA.3 states wide condition (mu-t)/r(S_t;B)->0 equivalently width ratio->0, every fixed-direction width ratio->0, and 0 IS a vertex of every maximum sup-differential; this verifies the opposite wording in Remark8.12 is literal error. LemmaA.4 ratio is nonincreasing with t through homothety at a maximum; pushforward concave function u_*f reduces fixed-direction width to dimension1. Equality S_t(u_*f)=u(S_t(f)) requires fibre supremum attainment, supplied by upper semicontinuity on compact C, missing from the literal bare-concave setup. LemmaA.5 bounds f outside S_t by its directional width and preceding monotonicity. First proof half A.3: comparability gives1<=>2,2=>3; if0 notvertex, choose extreme projected distance at least half the width, giving ratio>=1/2 and contradicting3. Remaining direction4=>2 appears next page and has not yet been credited.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
