# Ballay–Sombra published source review — view 19

Physical pages: [37, 38].

Read the complete selected text and displayed matching rendered image.

Physical 37 explicitly derives placewise probability limits from Theorem 6.9 and Proposition 6.4 via zero-geometric-divisor directions, where the d mu_ess geometric correction vanishes. Remark 6.10 states defect/vol(Q_n)->0 is sufficient but generally stronger than defect/inradius->0; on curves they are equivalent up to fixed degree. Its bound r(Q_n;phi*D)>=Q_n^d/(d A^d) uses a fixed ample A dominating D, Lemma 3.4 for Q_n and phi*A, and monotonicity replacing reference A by D. This does not require D nef. Remark 6.11 only discusses applying the result to adelic integral divisors on nonnormal projective varieties via normalization; the R-divisor theorem itself retains normality. Corollary 6.12 recovers Yuan from constant approximants and Theorem 4.22, with big underlying D inherited from Section 6. Physical 38 gives Chen's corollary for arithmetically big Dbar with equality of the full-volume Zhang bound. Its derivative combines arithmetic and geometric positive intersections; these are distinct products and degrees. Lemma 6.14 constructs semipositive approximants for every t<mu_ess, with mu_abs>=t, geometric mass close to vol(R^t), and arithmetic top intersection close to volhat(Dbar(t))+(d+1)t vol(R^t). Those approximation errors must be chosen relative to the shrinking mass; simply taking t upward does not establish the main ratio criterion. Both pages fully read and displayed, no blank; Lemma 6.14 and Chen proofs continue.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
