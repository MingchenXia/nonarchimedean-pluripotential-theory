# Ballay–Sombra published source review — view 26

Physical pages: [51, 52].

Read the complete selected text and displayed matching rendered image.

Physical 51 introduces logarithmic tests: continuous and finite off an effective divisor, locally bounded in absolute value by a constant times log of an inverse local defining equation. Generic sequences eventually avoid this divisor. Proposition 7.11 states integrability under the main theorem's measure for any effective divisor, whereas convergence of such tests needs an extra equality. Lemma 7.12 obtains derivative_E mu_ess >=sum_v n_v integral g_E,v dnu from the lower cycle-height bound for each semipositive approximant; the relevant absolute minima are finite by the main criterion, so the earlier zero-times-minus-infinity boundary is absent. Physical 52 uses arithmetic Bezout to separate the cycle height, truncates g from above, and uses placewise weak convergence plus monotone convergence. For an effective adelic representative all g are nonnegative, so Fatou justifies the infinite-place sum/liminf interchange; no unsupported finite sum assumption is needed. The integrability proof's 'without loss phi=g' should be understood as compactness-based domination by C(g+constant), not an assertion that every logarithmic test is a Green function. Finite-place metric constants can make a representative adelically effective. Theorem 7.13 expressly requires equality (7.11) between the derivative and the sum of local Green integrals; weak convergence and mere limit-measure integrability alone do not give logarithmic equidistribution. Both full pages/render read, no blank; the equality-based convergence proof continues.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
