# Ballay–Sombra published source review — view 43

Physical pages: [85, 86].

Read the complete selected text and displayed matching rendered image.

Physical 85: nef in this completion is strongly nef in Yuan-Zhang terminology; agreement may require shrinking the arithmetic open subset (Remark10.5). Semipositivity/pseudoeffectivity/neffness are closures via corresponding model sequences; integrability is difference of nef completed divisors. Local MA measures on noncompact U have total mass D^d; formula10.4 initially gives convergence only for continuous compactly supported tests, not all bounded continuous tests without tightness. Heights on each U-point are finite sequence limits controlled by boundary Cauchy norm; arithmetic intersections are common-model limits imported from Burgos-Kramer Th3.37. Physical 86: dominant morphism pullbacks and birational invariance imported; Archimedean unit divisor [infinity] gives the geometric intersection when inserted. Quasi-projective mu_abs is DEFINED as sup lambda for Dbar-lambda[infinity] nef, rather than asserted equal to inf point heights on U. Lemma10.6 attains a finite threshold using finite boundary norm of [infinity] (strict effectivity) and a diagonal model sequence. Any later presentation must keep this threshold definition and the strong-nef convention explicit.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
