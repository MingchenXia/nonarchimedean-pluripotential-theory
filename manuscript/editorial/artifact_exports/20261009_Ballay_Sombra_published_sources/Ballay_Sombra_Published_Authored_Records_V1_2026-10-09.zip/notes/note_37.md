# Ballay–Sombra published source review — view 37

Physical pages: [73, 74].

Read the complete selected text and displayed matching rendered image.

Physical 73 Theorem 9.4 retains Section 9.2 hypotheses (nonzero section algebra for every eigen-divisor, big semiample sum, q_i>1). Its height derivative and probability limit use 1/D^d and finite-map pullback divided by degree(phi)^n. The explicit arithmetic mixed-eigenvalue formula requires each canonical summand DSP and the sum semipositive; local measure identification requires each summand locally semipositive at that place. Lemma 9.5's chosen semipositive Dbar' lies below the canonical sum pseudo-effectively, Qbar_n=q_max^(-n)phi^(n)*Dbar'. The geometric inradius is at least (q_min/q_max)^n, geometric mass is q_max^(-dn)degree(phi)^n D^d, and absolute minimum is q_max^(-n)mu_abs(Dbar'). Therefore the minimum defect decays relative to inradius at rate at most a fixed constant times q_min^(-n), not necessarily relative to volume. Physical 74 Lemma 9.6 proves mixed geometric terms outside q^a=degree(phi) vanish by projection; local mixed measures outside that set vanish only when they are positive with zero mass. One cannot infer the same for signed mixed measures from zero mass alone. The arithmetic formula in 9.4(2) still needs the proof of its remaining mixed-term limits. Both full pages/render read, no blank; hypotheses and finite pullback normalization confirmed.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
