# Ballay–Sombra published source review — view 18

Physical pages: [35, 36].

Read the complete selected text and displayed matching rendered image.

Physical 35 completes Proposition 6.3: interleaving a slope-attaining generic small sequence with any sequence having a different height limit would destroy convergence while remaining generic and small. Thus existence for every sequence forces a common value and opposite slopes. Proposition 6.4 treats all adelic directions; Proposition 6.6 treats only a single-place continuous-invariant test subspace. Physical 36 gives the exact local identity n_v integral(phi)dnu = derivative in 0bar^phi, so mass one follows from constant local perturbations, not from suppressing n_v. Definition 6.7 requires normal modification, semipositive Qbar, big underlying Q and adelically pseudo-effective pullback remainder. Theorem 6.9's full finite height derivative has the arithmetic mixed term minus d mu_ess(Dbar) times the geometric mixed term, divided by Q_n^d, and condition (6.3) is the defect over geometric inradius. Literal Remark 6.8 prints (Q^d)=vol(D)>0; semipositivity plus bigness actually gives (Q^d)=vol(Q)>0. The equality with vol(D) is false for a nontrivial approximation (e.g. standard semipositive O(2) on P1 and Qbar=O(1), nef remainder: masses 2 versus 1). This is a specific printing/scoping diagnostic, not a counterexample to Theorem 6.9, whose denominator correctly uses Q_n^d. Do not copy the erroneous equality into the book. Both full rendered pages read, no blank; main proof remains forthcoming.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
