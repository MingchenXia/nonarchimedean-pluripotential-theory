# Ballay–Sombra published source review — view 6

Physical pages: [11, 12].

Read the complete selected text and displayed matching rendered image.

Physical 11 fixes absolute values extending the usual Q_v values and weights n_v=[K_v:Q_v]/[K:Q], hence sum_v n_v log|alpha|_v=0 and sum_{v|v0} n_v=1. Analytification uses C_v, with a fixed embedding of the algebraic closure of K. A variety is separated and integral of finite type; geometric integrality is not silently included. Throughout X is normal projective, dimension d>=1; normal modifications are projective birational with normal source. Measures are Radon and weak convergence is explicitly sequential here, rather than a claim about cofinal sequences of all models. Physical 12 defines Cartier R-divisors via tensoring and uses the symbol equivalence for R-linear equivalence, not numerical equivalence; any book prose must translate this notation explicitly. Underlying intersection numbers are birationally invariant, nef top intersection equals volume, and (3.1) uses nef d-1 factors with a pseudo-effective final difference. Sections of R-divisors use actual rational functions with D+div(f)>=0, not arbitrary real tensor rational functions in the section space; the rational-functions tensor is reserved for R-principal equivalence. Product and zero conventions read completely. No blank page; signs and source notation confirmed in render.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
