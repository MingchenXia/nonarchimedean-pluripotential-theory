# Ballay–Sombra published source review — view 41

Physical pages: [81, 82].

Read the complete selected text and displayed matching rendered image.

Physical 81 finishes Proposition 9.13: with e=dim Y and e'=dim pi(Y), projection formula kills geometric terms j>e', while j=e' is positive by relative ampleness of M on the general fibre and ampleness of N on pi(Y); (Q_n^e.Y) has leading binomial(e,e') ell^{-n(e-e')} (M^{e-e'}.pi*N^{e'}.Y). Positivity of the mixed local measures allows zero total mass to imply vanishing; the same leading term yields the normalized mixed equilibrium measure. Theorem 9.14 uses Theorem 9.9 for torsion hypersurface closures and boundary components, all preperiodic for multiplication ell>1; log-test extension remains limited to these divisors, not arbitrary hypersurfaces. Physical 82 begins quasi-projective theory: geometric model divisors are the direct limit over normal modifications isomorphic on U=X minus supp B; B-adic norm may be infinite, completion depends on U rather than boundary choice. Volume continuity and intersection extension for nef/integrable completions are imported from Yuan-Zhang [40, Ths 5.2.1,5.2.9] and Burgos-Kramer [10, Th3.7], not proved here and not recursively checked. This completion is distinct from the earlier continuous projective adelic setting.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
