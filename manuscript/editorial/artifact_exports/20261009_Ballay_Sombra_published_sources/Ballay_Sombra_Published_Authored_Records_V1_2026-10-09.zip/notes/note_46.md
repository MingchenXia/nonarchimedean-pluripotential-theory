# Ballay–Sombra published source review — view 46

Physical pages: [91, 92].

Read the complete selected text and displayed matching rendered image.

Physical91 finishes Theorem10.11 by plus/minus compactly supported tests, yielding common limits for these tests. Printed proof does not separately establish tightness or total mass one on noncompact U; convergence on C_c alone is vague convergence and may lose mass (e.g. delta_n on the real line). This observation is a proof-scope gap, NOT an adelic counterexample. Cor10.12 has the constant full-mass nef MA limit, where C_c convergence plus preserved mass can give weak probability convergence; general moving approximants need the additional mass/tightness justification. Remark10.13 reduces to a normal open subset. Physical92 mentions checking whether Biswas quasi-projective Chen-type theorem follows from Th10.11, stated as interesting future work. Appendix A defines minimum directional width and translation-invariant convex inradius; they are comparable with constants depending on d and fixed reference B. Literal assumption f:C->R merely concave does not imply every upper level set compact or sup attained at boundary: f(0)=0 and f(x)=1 for x>0 on [0,1] is finite concave but S_t=(0,1] for 0<t<=1. Upper semicontinuity/continuity is needed for the printed compactness claim; actual toric roofs have the requisite closed-concave regularity. Do not propagate Appendix statements to arbitrary discontinuous concave boundary data.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
