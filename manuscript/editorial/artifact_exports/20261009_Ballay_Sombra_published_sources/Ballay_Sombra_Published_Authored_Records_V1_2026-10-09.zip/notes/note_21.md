# Ballay–Sombra published source review — view 21

Physical pages: [41, 42].

Read the complete selected text and displayed matching rendered image.

Physical 41 finishes Lemma 6.18. Forward implication shifts chosen nef Pbar_n by t_n; reverse writes t_n=mu_abs(Qbar_n) and Pbar_n=Qbar_n-t_n[infinity]. There is a literal endpoint omission: t_n may equal mu_ess(Dbar), as for Yuan's constant exact approximants, while rho(Dbar(t)) and Theta are defined here only for arithmetically big data at strict t<mu_ess. A strict choice t_n=mu_abs(Qbar_n)-epsilon_n, with epsilon_n>0 and epsilon_n/r_n->0 (e.g. r_n/n), retains the pseudo-effective remainder and gives nef Pbar_n with absolute minimum epsilon_n; it supplies the required strict threshold without claiming a new general theorem. The main condition's r_n<=1 makes t_n->mu_ess. Keep the printed proof and this boundary diagnostic separate. Lemma 6.19 squeezes full threshold-functional liminf/limsup by directional slopes, using Omega(Dbar) between mu_ess and (d+1)(mu_ess-t)+t. Physical 42 completes the squeeze and Theorem 6.17 via Theorem 6.9, so the full one-sided derivative limit follows from oddness, not from assuming a full inradius-ratio limit. Lemma 6.20 compares any arithmetic Fujita sequence's geometric inradii to rho within factor d+1, using arithmetic Siu and positive mixed-intersection asymptotics. Its reduction to identity modification requires common normal dominating modifications, not unrestricted divisor pushforward. Both complete pages displayed/read, no blank; the core Theorem 6.9 proof still awaits Section 7.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
