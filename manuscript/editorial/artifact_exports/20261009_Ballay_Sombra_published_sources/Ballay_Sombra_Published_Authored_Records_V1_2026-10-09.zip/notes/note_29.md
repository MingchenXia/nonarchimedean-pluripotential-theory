# Ballay–Sombra published source review — view 29

Physical pages: [57, 58].

Read the complete selected text and displayed matching rendered image.

Physical 57 fixes the split-torus character lattice M and dual cocharacter N, normal complete fan, R-virtual support function and quasi-rational polytope Delta_D. Geometric volume is d! vol_M(Delta), using actual lattice covolume one, with top nef intersection equal to that quantity; its mixed-volume convention includes the d! polarization. Physical 58 identifies pseudo-effective D with nonempty Delta, big with full dimension and nef with concave support function. The translation containment criterion for D-E requires E nef. Local val is -log absolute values, matching the book sign. A toric adelic metric's psi_v=-g_v is continuous and bounded relative to the support function and equals the support function at all but finitely many places. Roof theta_v is the concave Legendre infimum on Delta even when psi_v itself is not concave; local roofs vanish outside a finite place set and global theta=sum_v n_v theta_v. Thus roof information can encode non-semipositive metrics, but it must not be mistaken for equality of the raw psi and its concave envelope. The compact torus differs analytically between Archimedean and Berkovich places; forthcoming limiting Dirac masses are not uniform rigid-point measures. Both pages full text/render read, no blank; upcoming toric positivity, inradius and measure identities await reading.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
