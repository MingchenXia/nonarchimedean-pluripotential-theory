# Ballay–Sombra published source review — view 42

Physical pages: [83, 84].

Read the complete selected text and displayed matching rendered image.

Physical 83: quasi-projective nef intersection is the common-model Cauchy limit, D^d=vol(D); Definition10.1 extends the geometric inradius to B-adic completed divisors. Lemma10.2 proves continuity r(P;A)=lim r(P_i;A_i) and positive finiteness. Its limsup step uses a fixed c>0 with P_i-lambda A_i-c A_i big; the asserted positive volume limit requires the implicit quantitative monotonicity vol(P_i-lambda A_i)>=c^d vol(A_i), whose limit is positive because A is big. Arithmetic setup uses normal flat integral projective O_K models dimension d+1. Physical 84: arithmetic boundary Bbar is strictly effective, nonnegative underlying divisor and strictly positive Archimedean Green functions; the boundary norm completion depends only on the arithmetic open subset. Remark10.3 invokes shrinking the open subset and smooth compactifications/density to compare Burgos-Kramer smooth-generic/smooth-metric conventions; do not silently apply their original statements on an arbitrary unchanged singular open subset. Bounded differences for all indices (10.2) may be arranged after discarding finitely many terms. Geometric and arithmetic completions must remain distinct from projective continuous-metric spaces.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
