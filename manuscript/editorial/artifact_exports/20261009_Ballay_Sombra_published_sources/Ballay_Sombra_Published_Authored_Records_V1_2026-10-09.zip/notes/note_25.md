# Ballay–Sombra published source review — view 25

Physical pages: [49, 50].

Read the complete selected text and displayed matching rendered image.

Physical 49 finishes the continuous non-DSP direction using Ebar' below Ebar with an epsilon[infinity] pseudo-effective comparison. Mixed normalized errors are exactly epsilon, since tilde Q_n^d mass cancels; applying +/-Ebar squeezes liminf/limsup against opposite derivatives and Lemma 7.5 supplies the mu_ess formula. This finishes the detailed Section 7.2 proof reading, subject to the separately recorded Lemma 7.6 constant-shift step and external arithmetic Hodge/Siu inputs. Remark 7.7 can use mu_abs instead of mu_ess because the geometric correction difference is O(delta/r). Theorem 7.8 gives a different sequence condition: normalized arithmetic height defect divided by inradius tends to zero, while the absolute-minimum defect/inradius is merely bounded. Its conclusion is equidistribution, rather than the full all-geometric-direction derivative formula. Physical 50 keeps the nonnegative tilde Qbar^(d+1) term for zero underlying E, where the perturbed geometric volume is unchanged, and uses the first defect in a square-root scale; bounded second defect controls kappa. The same simultaneous Dbar/Qbar shift resolves the Lemma 7.6 reduction here. Remark 7.9 asserts equivalence in attainable criterion scope with Theorem 6.9 but expressly omits the technical construction; this is not independently established by this reading and should not be promoted as a proved equivalence in book prose. Both pages full text/render read, no blank.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
