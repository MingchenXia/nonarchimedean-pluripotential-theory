# Ballay–Sombra published source review — view 35

Physical pages: [69, 70].

Read the complete selected text and displayed matching rendered image.

Physical 69 Theorem 8.13 retains big toric D, wide global roof and effective E with zero generalized Mahler m_D(f_E), then gives logarithmic tests along E. Boundary components allow equation one; irreducible binomial components require log|gamma|_v=-<u_v,m> at every place, consistent with physical 66's calculation. Arbitrary hypersurfaces or arbitrary translated subtori are not included. Corollary 8.14 adds semipositivity and replaces the numerical condition by D-special nonboundary components, i.e. equality of their restricted essential minimum with that of Dbar; the source's lower bound on torus-point heights ensures the direction. Physical 70 proves this via the external Bogomolov theorem for monocritical toric metrics, after a finite field extension to ensure geometric irreducibility. The orbit-height/mass weights remain those of the enlarged number field, not an unnormalized degree factor. The local condition u_v in m-perpendicular plus val(x0) gives exactly the negative logarithm of gamma. Section 9 introduces normal projective X with a finite surjective endomorphism and R-linear eigen-equivalence phi*D~_R qD, q>1. The canonical metric property is R-linear adelic equivalence, rather than literal equality of chosen representatives. These arithmetic dynamical results are distinct from hybrid degenerations over a trivial base. Both full pages/render read, no blank; canonical existence/positivity and multi-eigenvalue approximation proof continue.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
