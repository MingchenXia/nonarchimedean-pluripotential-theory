# Ballay–Sombra published source review — view 13

Physical pages: [25, 26].

Read the complete selected text and displayed matching rendered image.

Physical 25 Theorem 4.19 identifies mu_ess with the pseudo-effective/big Archimedean-shift threshold only when underlying D is big; a one-sided inequality remains outside that scope. The proof's non-semipositive threshold extension uses Szachniewicz [33] and Moriwaki approximation; these originals are not recursively certified. Remark 4.20 gives the attained pseudo-effective normalized divisor Dbar-mu_ess[infinity]. Theorem 4.21 uses geometric vol(D) for the chi lower bound, and additionally arithmetic bigness for the full-volume lower bounds involving vol(R^0); zero volume is excluded. Theorem 4.22's equivalence between Zhang equality and mu_ess=mu_abs requires semipositive Dbar and big underlying D, not arbitrary heights. Physical 26 Lemma 4.23 constructs a unique invariant Radon measure from a positive functional on local Galois-invariant continuous tests. It uses density of functions defined over finite extensions (external Yuan/Gubler locators), followed by finite Galois averaging and Riesz, not density of invariant functions in all C(X_v). The averaging formula should choose a finite Galois extension or its Galois closure so the finite group has the requisite cosets; this routine choice is implicit in the displayed proof. Part (2) transfers convergence through invariance and a dense test subspace. Positivity plus the constant function gives boundedness and bounded masses, needed for the density passage. No global cofinal-model sequence assertion follows. Both pages completely read/rendered, no blank.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
