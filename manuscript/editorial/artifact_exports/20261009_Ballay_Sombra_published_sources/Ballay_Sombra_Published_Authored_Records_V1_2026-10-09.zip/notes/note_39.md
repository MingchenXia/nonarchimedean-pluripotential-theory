# Ballay–Sombra published source review — view 39

Physical pages: [77, 78].

Read the complete selected text and displayed matching rendered image.

Physical 77 completes Theorem 9.9 by bounding each normalized cycle-height gap between zero and -d mu_abs(Qbar_n)/r(Q_n;A), using dense height-zero preperiodic points and geometric mixed intersections; the main inradius criterion then makes it vanish. With only big semiample D, Q_n|Y can have zero volume on a contracted component, so the cited Theorem 4.21 quotient cannot be applied there without a zero-mass/semiample extension argument. In an ample-D specialization the restriction is big and this issue disappears; do not silently divide by zero in book applications. The final ample/preperiodic implication uses restriction to a periodic image and Fakhruddin's density theorem for an ample difference, then pulls points back to the preperiodic component. Physical 78 constructs the smooth (P1)^r-bundle compactification of a semiabelian extension of an abelian variety by a split torus. Multiplication by ell has degree ell^(r+2g), boundary M is relatively ample with eigenvalue ell, symmetric ample base divisor N has eigenvalue ell^2, and D=M+pi*N is ample. Their canonical metrics are semipositive using specific external CL/Künnemann models for M and standard polarized theory for N. No arbitrary compactification or nonsplit-torus metric claim follows. Different eigenvalues are the reason the approximation mass and inradius can decay at different rates. Both full rendered pages read, no blank; original density/regular-model proofs remain separate dependencies.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
