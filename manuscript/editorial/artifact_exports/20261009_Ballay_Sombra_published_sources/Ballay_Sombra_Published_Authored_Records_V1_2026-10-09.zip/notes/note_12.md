# Ballay–Sombra published source review — view 12

Physical pages: [23, 24].

Read the complete selected text and displayed matching rendered image.

Physical 23 proves mixed arithmetic monotonicity by DSP approximation plus the epsilon[infinity] intersection error, and Lemma 4.16 expresses a DSP perturbation as the difference of fixed big adelically nef divisors by adding the same ample metric and constant. Absolute minimum is an infimum over all algebraic points, invariant under proper surjections; finite lower bounds are specifically guaranteed for semiample underlying divisors. h_Dbar(t)=h_Dbar-t and semipositive nef-threshold equality (4.8) confirm signs. Physical 24 defines essential minimum as sup over proper closed subsets of the remaining height infima. It is finite real when the section algebra is nonzero, hence for big underlying D. Lemma 4.18's continuity and pseudo-effective monotonicity explicitly require big geometric first input, while effective monotonicity does not. Lemma 4.17's literal lower cycle-height display for all semipositive Dbar needs an extended-arithmetic check when mu_abs=-infinity and geometric mass vanishes: the preceding text only guarantees finite mu_abs for semiample D. The book must not import an undefined zero-times-minus-infinity expression; in the eventual nef approximants needed for the main theorem mu_abs is finite and nonnegative, so that boundary does not itself refute the main theorem. No independent counterexample or formal repair is claimed at this stage. The upcoming essential-minimum characterization imports Qu–Yin and Szachniewicz beyond semipositivity. Both pages fully read and displayed, no blank.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
