# Ballay–Sombra published source review — view 3

Physical pages: [5, 6].

Read the complete selected text and displayed matching rendered image.

Physical 5 states introductory Theorem 2: Dbar has big geometric D and admits semipositive approximations (phi_n,Qbar_n) with (mu_ess(Dbar)-mu_abs(Qbar_n))/r(Q_n;phi_n*D)->0. Each normalized local Monge–Ampere measure is pushed to X_v before taking its probability weak limit; all generic small Galois sequences have that same limit. Mere convergence of minima is explicitly insufficient because inradius may collapse. Formula (1.4), the stronger height/derivative result later Theorem 6.9, uses an arithmetic mixed intersection Qbar_n^d . phi_n*Ebar minus d mu_ess(Dbar) times the geometric mixed intersection Q_n^(d-1) . phi_n*E, divided by geometric Q_n^d. The correction vanishes for Ebar over the zero divisor, but local Green-function/height factors await exact conventions. This limit is asserted finite and independent of the approximating sequence. Physical 6 gives a separate toric wide-roof criterion: nonconstant global roofs can satisfy equidistribution while failing Yuan's equality. At a non-Archimedean place the stated limiting measure is one translated Gauss-point Dirac, while at an Archimedean place it is Haar on a translated compact torus. Introductory Theorem 4 allows logarithmic tests only along effective divisors with the stated essential-minimum condition for every non-boundary component, not arbitrary poles. These application proofs and the precise wide condition are not yet read. Both pages fully displayed, no blank.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
