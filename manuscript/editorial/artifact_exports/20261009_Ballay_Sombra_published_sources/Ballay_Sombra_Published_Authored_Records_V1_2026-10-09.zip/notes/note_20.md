# Ballay–Sombra published source review — view 20

Physical pages: [39, 40].

Read the complete selected text and displayed matching rendered image.

Physical 39 finishes Lemma 6.14 with Qbar=Pbar+t[infinity], so geometric mass is unchanged and arithmetic top intersection shifts by (d+1)t mass (higher powers of the zero-geometric divisor vanish). In Chen's corollary, volume equality forces the threshold-series volume to be full for every strict t<mu_ess in the positive interval; the proof's wording includes the endpoint t=mu_ess, which is not justified just by equality of an integral and is unnecessary for the chosen approximants. Only strict thresholds are used in Lemma 6.14 and subsequent formulas. The resulting masses approach full vol(D), defects vanish, and eventually nef Qbar_n form an actual Fujita sequence; arithmetic and geometric positive-intersection limits then differ in degree as required. Physical 40 Definition 6.16 introduces rho(Bbar;A) as a supremum of geometric inradii over nef approximations, not the geometric r(B;A) or arithmetic volume. Theorem 6.17 needs liminf_{t upward to mu_ess}(mu_ess-t)/rho(Dbar(t))=0, with all t strictly below; a full limit of this ratio is not its hypothesis. Its conclusion gives a full one-sided limit of normalized arithmetic positive intersections, and local probability limits. Lemma 6.18 begins equivalence with the existence of the main approximating sequence; supremum choices need only approach within a fixed factor, not attain rho. Both rendered pages read completely, no blank; endpoint issue is a proof-scope caution and not a claimed main-theorem counterexample.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
