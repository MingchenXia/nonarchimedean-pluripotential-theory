# Ballay–Sombra published source review — view 1

Physical pages: [1, 2].

Read the complete selected text and displayed matching rendered image.

Physical 1 fixes the exact Inventiones version of record, DOI 10.1007/s00222-026-01456-y, received 17 July 2025, accepted 18 September 2026 and published online 5 October 2026 (rendered footer). Title, authors and abstract match acquisition. Its declared extension permits failure of equality in Zhang's lower bound, then treats special logarithmic singularities, sums of dynamical heights and a separate quasi-projective extension. Physical 2 finishes the contents and introduces a number field K, fixed algebraic closure, projective variety of dimension d>=1 and adelic divisor. These are introductory scope claims, not yet checked theorem hypotheses or proof clearance. The application to arbitrary projective varieties must not be read as unconditional equidistribution for arbitrary heights; the forthcoming approximation condition is essential. Rendered text and mathematical conventions are legible; no blank page in this view.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
