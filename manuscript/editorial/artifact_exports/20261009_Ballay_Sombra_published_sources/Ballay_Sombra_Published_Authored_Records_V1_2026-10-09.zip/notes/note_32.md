# Ballay–Sombra published source review — view 32

Physical pages: [63, 64].

Read the complete selected text and displayed matching rendered image.

Physical 63 defines the wide-roof property through sup-level widths/inradii and zero as a vertex of the roof sup-differential, with precise Appendix A definitions still to be read. It associates a unique finitely supported balanced family of local sup-gradients sum_v n_v u_v=0 and measures eta_v,u_v. Theorem 8.7 applies to big underlying toric D without semipositivity of the original metrics, gives full essential-minimum differentiability, and an explicit height formula for Ebar with toric underlying divisor. The wide criterion supplies a full threshold-rho ratio limit and hence Theorem 6.17. Physical 64 proves the formula first for semipositive toric E using mixed integrals and affine sup-gradient bounds. The finite place set must be enlarged to include all noncanonical Dbar/Ebar metrics, all Archimedean places and nonzero u_v; otherwise the displayed weighted sums and epsilon_v t terms need not be supported there. This enlargement is available by adelicity but should be explicit in any book proof. The local affine errors kappa_v are nonnegative and weighted by n_v; balancing cancels the same <u_v,x1> term across places. The error uses (mu-t) mixed-volume/vol(S_t), which must be controlled by width/inradius, not just shrinking diameter. A smooth quadratic roof has widths of order sqrt(mu-t), suggesting a useful strict-Zhang example, while a cusp of order one need not be wide; Appendix verification precedes use. Both full rendered pages read, no blank; lower mixed-integral bound and general E extension continue.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
