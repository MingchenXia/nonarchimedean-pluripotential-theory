# Ballay–Sombra published source review — view 2

Physical pages: [3, 4].

Read the complete selected text and displayed matching rendered image.

Physical 3 states Yuan's introductory Theorem 1 for a semipositive adelic divisor with ample underlying D and equality mu_ess(Dbar)=(Dbar^(d+1))/((d+1)(D^d)). Generic D-small sequences have heights tending to mu_ess; their uniform Galois-orbit probability measures converge placewise to c1(Dbar_v)^d/(D^d). The denominator and d+1 belong to different normalizations. Here analytification is over C_v, not the trivially valued field. Physical 4 notes earlier big/non-semipositive variants but does not itself prove them. Its main framework now assumes normal projective X, dimension d>=1, over a number field. A semipositive approximation is a normal modification phi:X'->X with semipositive adelic R-divisor Qbar, big underlying Q and adelically pseudo-effective phi*Dbar-Qbar. This is weaker than literal effectiveness and does not assume Dbar semipositive. Inradius r(P;A)=sup{lambda:P-lambda A big} uses underlying geometric big R-divisors. The future defect-over-inradius condition must be retained; strict Zhang inequality alone cannot guarantee equidistribution. No blank page; rendered bars and powers were checked against extraction.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
