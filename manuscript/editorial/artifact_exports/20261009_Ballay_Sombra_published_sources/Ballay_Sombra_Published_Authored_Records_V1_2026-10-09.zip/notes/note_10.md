# Ballay–Sombra published source review — view 10

Physical pages: [19, 20].

Read the complete selected text and displayed matching rendered image.

Physical 19 fixes arithmetic volumes with 1/[K:Q] and m^(d+1)/(d+1)! normalization; the chi-volume uses Haar measure giving the adelic section-lattice quotient mass one. Effective means underlying effective plus nonnegative local Green functions off support. Adelic big means positive arithmetic volume, distinct from geometric big; pseudo-effective means adding every arithmetically big divisor remains big. Adelic nef means semipositive and nonnegative point heights. Remark 4.6 explicitly extends Moriwaki's geometrically irreducible source setting through the finite constant field in Stein factorization; this warrants normal integral rather than geometrically integral main scope. Physical 20 gives volume continuity under a fixed perturbation, the small-section threshold algebra R^t with Archimedean lognorm<=-mt, and Chen's arithmetic-volume integral (d+1) integral_0^infinity vol(R^t)dt for arithmetically big data. Theorem 4.8 distinguishes chi-volume=arithmetic intersection for semipositive Dbar from full arithmetic volume equality requiring adelic nef. Neither statement applies to arbitrary non-semipositive Dbar. External Moriwaki, Chen and Boucksom–Chen inputs are cited, not recursively read here. The exact negative shift agrees with increasing the small-section threshold. Both full rendered pages read, no blank.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
