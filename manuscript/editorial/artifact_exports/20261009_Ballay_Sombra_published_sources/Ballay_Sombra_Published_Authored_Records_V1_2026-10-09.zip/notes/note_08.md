# Ballay–Sombra published source review — view 8

Physical pages: [15, 16].

Read the complete selected text and displayed matching rendered image.

Physical 15 completes Lemma 3.5's lower volume bound and introduces analytifications, finite Galois orbits and local Gal(Kvbar/Kv)-invariant test functions. A source Green function has g_v+log|f|_v continuous for a local defining rational function: it corresponds to minus log norm, without the squared-norm factor 2. This fixes any future normalization conversion. Physical 16 defines an adelic R-divisor by continuous invariant Green functions coinciding with one normal projective integral model outside finitely many places. Thus this is the strict model-outside-finite-places framework, not an unqualified adelic completion or finite-energy singular metric. Zero-divisor adelic data are continuous functions supported at finitely many places. The Archimedean constant divisor [infinity] has g_v=1 at all Archimedean places and zero elsewhere; Dbar(t)=Dbar-t[infinity] subtracts t from heights because Archimedean weights total one. Principal data use -log|f|. Pullback requires the image avoid containment in support. Semipositivity is continuous PSH, with uniform vertically-nef model approximation at non-Archimedean places and nef underlying divisor; DSP means a difference of such metrics. Model approximating sequences here are a specific local uniform definition and do not replace arbitrary cofinal model nets in the book. Both pages/readable renders complete, no blank.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
