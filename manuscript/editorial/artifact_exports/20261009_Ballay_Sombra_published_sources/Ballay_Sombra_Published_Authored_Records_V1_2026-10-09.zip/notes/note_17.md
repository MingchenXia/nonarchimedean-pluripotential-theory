# Ballay–Sombra published source review — view 17

Physical pages: [33, 34].

Read the complete selected text and displayed matching rendered image.

Physical 33 works on the open cone of geometrically big underlying divisors, where mu_ess is finite concave homogeneous. Generic means eventually outside every proper closed subset; small means height tends to mu_ess, not absolute minimum. Lemma 6.2 bounds every generic small sequence's Ebar-height liminf/limsup between the finite directional slopes d_E mu_ess and -d_-E mu_ess. Physical 34 constructs a slope-attaining generic small sequence by perturbing Dbar+Ebar/n and choosing diagonal points with errors 1/n^2. Its enumeration of all hypersurfaces is legitimate because the algebraic closure of a number field is countable; this argument cannot be transported to an uncountable base without a new justification. After scaling E so underlying D+E is big, genericity and a section lower height bound give a common lower c along the diagonal (finitely many initial points absorbed). The n/(n-1) computation is for n>=2. The resulting heights tend to mu_ess(Dbar), and multiplying the 1/n perturbation bounds by n yields the slope, with errors 1/n vanishing. Proposition 6.3's equivalence between all small sequences having E-height limits and odd directional derivatives is stated; its interleaving proof continues next. Both pages completely read/displayed; no blank and no uncountable/cofinal model sequence inference.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
