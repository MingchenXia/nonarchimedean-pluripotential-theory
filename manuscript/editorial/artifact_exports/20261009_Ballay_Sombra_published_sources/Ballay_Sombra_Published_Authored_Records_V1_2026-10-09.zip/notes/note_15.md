# Ballay–Sombra published source review — view 15

Physical pages: [29, 30].

Read the complete selected text and displayed matching rendered image.

Physical 29 Theorem 5.4 represents the arithmetic-volume directional derivative for any Fujita sequence as (d+1)lim(Pbar_n^d.phi_n*Ebar), for every continuous adelic Ebar. Lemma 5.5 requires Pbar nef, a fixed big nef Abar dominating it pseudo-effectively, and Abar+/-Ebar nef; its quadratic error uses arithmetic vol(Abar), not geometric volume. The proof first decomposes DSP Ebar into fixed big nef N1bar-N2bar, chooses a common dominating Abar, and takes limsup in n before lambda->0. Physical 30 extends to continuous non-DSP Ebar via Lemma 4.14 and a controlled epsilon geometric-volume error; applying +/-Ebar and concavity squeezes all slopes and mixed intersections to finite equal limits. No interchange of uncontrolled derivatives and limits is used. Proposition 5.6 distinguishes three limits: arithmetic mixed intersection with Dbar -> arithmetic vol(Dbar), geometric top intersections -> vol(R^0(Dbar)), and mu_ess(Pbar_n)->mu_ess(Dbar). The second need not equal full geometric vol(D), and the third is essential minimum, not absolute minimum. The [infinity] derivative follows the integral threshold-volume formula; monotone left/right limits coincide by differentiability, hence the actual value at zero lies between and equals both. The essential-minimum proof continues. Both pages completely read and rendered, no blank.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
