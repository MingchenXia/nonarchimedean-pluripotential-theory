from pathlib import Path
from datetime import datetime,timezone
import urllib.request,hashlib,json,fitz,subprocess
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Ballay_Sombra_adelic_equdistribution_published_review_20261009')
assert not C.exists()
url='https://link.springer.com/content/pdf/10.1007/s00222-026-01456-y.pdf'
request=urllib.request.Request(url,headers={'User-Agent':'Book-source-audit/1.0'})
with urllib.request.urlopen(request,timeout=45) as response:
 data=response.read();resolved=response.url;content_type=response.headers.get('Content-Type')
assert data.startswith(b'%PDF-') and len(data)>10000
C.mkdir(parents=True);pdf=C/'Ballay_Sombra_Inventiones_2026_published.pdf';pdf.write_bytes(data)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
with fitz.open(pdf) as d:
 assert len(d)==99
 t=d[0].get_text();assert 'approximation of adelic divisors' in ' '.join(t.lower().split()) and 'sombra' in t.lower()
 assert '10.1007/s00222-026-01456-y' in t
text=C/'Ballay_Sombra_Inventiones_2026_published_preparation_text.txt'
subprocess.run(['pdftotext','-layout',str(pdf),str(text)],check=True)
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACQUIRED — zero actual primary-reading credit',edition='Inventiones 2026 version of record, published 5 October 2026',DOI='10.1007/s00222-026-01456-y',requested_URL=url,resolved_URL=resolved,content_type=content_type,path=str(pdf),bytes=len(data),SHA256=sha(pdf),physical_pages=99,preparation_text_path=str(text),preparation_text_SHA256=sha(text),arxiv_version_not_substituted='2407.14978v2 has different pagination',actual_reading_credit=0,mathematical_clearance=False,book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__))
(C/'source_acquisition_v1_20261009.json').write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:obj[k] for k in ['status','edition','physical_pages','bytes','SHA256']}))
