from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction as F
import hashlib, json, math, subprocess, zipfile, shutil, fitz

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Ballay_Sombra_adelic_equdistribution_published_review_20261009'
E=R/'manuscript/editorial'; O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
stamp=lambda:datetime.now(timezone.utc).isoformat()
write=lambda p,a:p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
actual=C/'actual_primary_reading_v1_20261009.json'
diag=C/'exact_diagnostics_v1_20261009.json'; checkpoint=C/'source_checkpoint_v1_20261009.json'
paths={k:E/f'Ballay_Sombra_published_source_{k}_20261009.{ext}' for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
dest=E/'artifact_exports/20261009_Ballay_Sombra_published_sources'
owned=O/'Ballay_Sombra_Published_Authored_Records_V1_2026-10-09.zip'
full=O/'Ballay_Sombra_Published_Actual_Source_Evidence_V1_2026-10-09.zip'
assert not any(p.exists() for p in [actual,diag,checkpoint,*paths.values(),dest,owned,full])
prep_path=C/'source_preparation_v1_20261009.json'; prep=json.loads(prep_path.read_text())
assert sha(prep['source']['path'])==prep['source']['SHA256']
assert sha(prep['manifest_path'])==prep['manifest_SHA256']
assert prep['actual_primary_reading_credit']==0 and not prep['book_changed']
rows=json.loads(Path(prep['manifest_path']).read_text()); assert len(rows)==50
views=[]; last=None
for i,x in enumerate(rows,1):
    note=C/f'primary_notes_v1/note_{i:02d}.md'; rp=note.with_name(note.stem+'_receipt.json')
    a=json.loads(rp.read_text())
    assert a['number']==i and a['physical_pages']==x['physical_pages']
    assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
    assert last is None or a['UTC']>last; last=a['UTC']
    assert not x['actually_viewed'] and not x['selected_text_read']
    assert sha(note)==a['note_SHA256'] and sha(a['helper_source'])==a['helper_SHA256']
    for key,h in [('path','image_SHA256'),('selected_text_path','selected_text_SHA256')]:assert sha(x[key])==x[h]==a[h]
    assert a['source_PDF_SHA256']==prep['source']['SHA256']
    views.append(dict(**a,note_path=str(note),image_path=x['path'],selected_text_path=x['selected_text_path'],observation_receipt_path=str(rp),observation_receipt_SHA256=sha(rp)))
pages=[p for v in views for p in v['physical_pages']];assert pages==list(range(1,100))
families=[]
mean=1-(F(1,3)-F(1,2)+F(1,4));assert mean==F(11,12)
assert 2*mean==F(11,6) and F(3,4)<mean<1
families.append(dict(name='quadratic roof exact heights',essential='1',absolute='3/4',roof_mean=str(mean),arithmetic_top=str(2*mean),Zhang_equality=False,status='PASS'))
for m in range(3,31):
    delta=F(1,m*m);width=F(2,m);assert delta/width==F(1,2*m)
families.append(dict(name='quadratic level-set inradius',cases=28,delta='1/m^2',width_and_relative_inradius='2/m',ratio='1/(2m)',status='PASS'))
for d in range(1,6):
    for delta in [F(0),F(1,100),F(1,5)]:
        r=F(1,d+1);epsilon=r/F(10)
        assert (delta+epsilon)/r==delta/r+F(1,10)
families.append(dict(name='strict intrinsic endpoint',recipe='epsilon_n=r_n/n; t_n=mu_abs(Qbar_n)-epsilon_n',added_normalized_gap='1/n',strict_t_below_mu=True,status='PASS'))
families.append(dict(name='common constant shift',target_and_approximants_shift='same c[infinity]',delta_unchanged=True,remainder_unchanged=True,Qtilde_unchanged=True,nef_A_downward_shift_required=False,status='PASS — formal height identities'))
assert 1-math.log(3)<0 and abs((1-math.log(3))+math.log(3)-1)<1e-12
families.append(dict(name='local roof versus global pseudoeffectivity',example='canonical O(1)+[infinity]+principal(3) over Q',infinite_roof='1-log(3)<0',three_adic_roof='log(3)',global_roof='1',local_necessity_statement_false=True,status='PASS'))
for n in range(2,41):assert F(1,n)*n==1
families.append(dict(name='logarithmic tail measure sequence',sequence='(1-1/n)delta_1+(1/n)delta_exp(-n)',weak_limit='delta_1',test='-log x',sequence_integral='1',limit_integral='0',adelic_counterexample=False,status='PASS'))
for r in range(2,6):
    for n in range(1,8):assert 0*2**((r-2)*n)==0
families.append(dict(name='semiabelian stronger-volume boundary',ratio='-mu_abs(Dbar)*ell^((r-2)n)/D^(r+g)',failure_requires_negative_absolute_minimum=True,zero_minimum_ratio='0',status='PASS'))
for a in [F(0),F(1,4),F(1,2),F(1)]:
    for x in [F(0),F(1,3),F(1)]:
        for y in [F(0),F(1,5),F(1)]:
            f=lambda z:int(z>0)
            assert f(a*x+(1-a)*y)>=a*f(x)+(1-a)*f(y)
families.append(dict(name='bare-concave boundary defect',example='f(0)=0, f(x)=1 for x>0 on [0,1]',positive_level_set='(0,1] not closed',continuity_used_by_actual_roof_example=True,status='PASS'))
families.append(dict(name='noncompact measure scope',sequence='delta_n on R',all_compact_test_limits='0',probability_limit_mass='0',tightness_from_C_c_alone=False,adelic_counterexample=False,status='PASS — explicit standard example'))
families.append(dict(name='constant roof sup-differential',interior_maximum_sup_differential='{0}',zero_is_vertex=True,Remark_8_12_not_vertex_literal_error=True,status='PASS'))
write(diag,dict(UTC=stamp(),status='DONE — ten elementary calibration families; seventeen source diagnostics in audit',families=families,original_results_promoted=[],independent_model_receipt=None,helper_source=__file__,helper_SHA256=sha(__file__)))
q=json.loads((R/'source_material/Qin_curvature_rank_review_20261009/book_export_v3_20261009.json').read_text())
m=q['artifacts']['minimal_TeX_source_archive'];assert sha(m['path'])==m['SHA256']
with zipfile.ZipFile(m['path']) as z:core=[n for n in z.namelist() if n.endswith('.tex')]
assert len(core)==425
protected={n:sha(R/n) for n in core}
for rel in ['manuscript/bibliography/ComplexGeometry.bib','manuscript/bibliography/NonArchimedean.bib','manuscript/book.pdf','output/open_problems_catalogue_2026-10-03.tex','output/open_problems_catalogue_2026-10-03.pdf']:protected[rel]=sha(R/rel)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
with fitz.open(R/'manuscript/book.pdf') as d:assert len(d)==4671
reading=dict(UTC=stamp(),status='DONE — whole exact published Ballaÿ–Sombra PDF read',source=prep['source'],actual_unique_physical_pages=99,actual_individually_displayed_matching_views=50,actually_read_physical_pages=pages,unread_physical_pages=[],whole_primary_PDF_actually_read=True,views=views,preparation=dict(path=str(prep_path),SHA256=sha(prep_path)),preparation_flags_unchanged=True,diagnostics_SHA256=sha(diag),actual_book_reading_credit=0,whole_book_new_reading_claim=False,recursive_original_dependency_certification=False,independent_model_receipt=None,original_results_promoted=[],canonical_status_changes=[],active_book_changed=False,native_editor_changed=False,BJ22_Theorem_6_21_repaired=False,baseline_commit=head,protected_core_inputs=protected,helper_source=__file__,helper_SHA256=sha(__file__))
write(actual,reading)
draft=Path('/tmp/Ballay_Sombra_published_source_review_draft_v1_20261009.md');assert draft.stat().st_size>10000
paths['review'].write_text(draft.read_text())
paths['reading_notes'].write_text('# Actual published Ballaÿ–Sombra source reading\n\n99/99 physical pages, fifty matching displays; external originals not recursively certified.\n'+''.join('\n---\n\n'+Path(v['note_path']).read_text() for v in views))
files={f'records/{p.name}':p for p in C.glob('*.json')}
files['manifests/prepared_views_v1.json']=Path(prep['manifest_path'])
for v in views:
    for key,kind in [('note_path','notes'),('observation_receipt_path','receipts')]:
        p=Path(v[key]);files[f'{kind}/{p.name}']=p
for p in Path('/tmp').glob('Ballay_Sombra_published_*_v1_20261009.py'):files[f'helpers/{p.name}']=p
files[f'drafts/{draft.name}']=draft
for k in ['review','reading_notes']:files[f'editorial/{paths[k].name}']=paths[k]
def archive(p,entries):
    with zipfile.ZipFile(p,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,q in sorted(entries.items()):z.write(q,n)
    with zipfile.ZipFile(p) as z:
        assert len(z.namelist())==len(entries) and z.testzip() is None
        for n,q in entries.items():assert z.read(n)==q.read_bytes()
archive(owned,files)
fullfiles=dict(files);fullfiles['primary/PDF/Ballay_Sombra_Inventiones_2026_published.pdf']=Path(prep['source']['path'])
for v in views:
    for key,kind in [('image_path','images'),('selected_text_path','text')]:
        p=Path(v[key]);fullfiles[f'primary/{kind}/{p.name}']=p
archive(full,fullfiles)
artifacts={k:dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p),members=n) for k,p,n in [('authored_records_archive',owned,len(files)),('cloud_source_evidence_archive',full,len(fullfiles))]}
write(paths['manifest'],dict(UTC=stamp(),status='DONE — full source checkpoint; book integration separately gated',actual_reading=reading,exact_diagnostics=json.loads(diag.read_text()),artifacts=artifacts,book_changed=False,GitHub_published=False))
write(paths['artifacts'],dict(UTC=stamp(),status='DONE — all archive members byte-verified',artifacts=artifacts,reading_credit_from_export=0,external_primary_PDF_text_images_uploaded=False,source_licence='CC BY4.0, physical97',GitHub_published=False))
dest.mkdir(parents=True);target=dest/owned.name;shutil.copyfile(owned,target);assert sha(target)==sha(owned)
(dest/'SHA256SUMS').write_text(sha(target)+'  '+target.name+'\n')
(dest/'README.md').write_text(f'''# Published Ballaÿ–Sombra source evidence, 9 October 2026

All 99 physical pages of the Inventiones version of record (5 October
2026), DOI 10.1007/s00222-026-01456-y, were read in fifty ordered
matching displays. The {len(files)}-member authored archive preserves notes,
receipts, immutable preparation, ten calibrations, seventeen source
diagnostics, helpers and the audit. The {len(fullfiles)}-member cloud archive
additionally preserves the controlling PDF and matching text/images.
All members are byte-verified. Export/upload adds zero reading credit.

This source checkpoint changes no book or native catalogue/editor.
No new theorem, independent-model receipt, recursive original-source
certificate, BJ22 critical Siu repair or canonical problem closure is
claimed. General BJ22 Siu/envelopes remain OPEN. The printed article
is CC BY4.0 (https://creativecommons.org/licenses/by/4.0/), with author
and source attribution retained; its original PDF is unchanged.
''')
p=R/'README.md';s=p.read_text();marker='**Latest verified curvature-rank GitHub publication, 9 October 2026:**';assert s.count(marker)==1
intro='''**Latest published adelic-equidistribution source checkpoint, 9 October 2026:**
the [source audit](manuscript/editorial/Ballay_Sombra_published_source_review_20261009.md)
records all 99 physical pages of Ballaÿ–Sombra's 5 October Inventiones
version in fifty matching displays. It preserves the inradius criterion,
strict-Zhang toric example, logarithmic-test hypotheses and seventeen
literal-source diagnostics. The [authored evidence](manuscript/editorial/artifact_exports/20261009_Ballay_Sombra_published_sources/README.md)
is prepared for authorized publication. The 4,671-page book and native
catalogue/editor are unchanged in this source-only checkpoint.

''';p.write_text(s.replace(marker,intro+marker,1))
p=E/'second_reading_and_research_programme_20261002.md';s=p.read_text();marker='## Latest verified curvature-rank GitHub publication, 9 October 2026\n';assert s.count(marker)==1
intro='''## Latest published adelic-equidistribution source checkpoint, 9 October 2026

The [source audit](Ballay_Sombra_published_source_review_20261009.md) records
99/99 physical published pages in fifty ordered matching displays.
Ten calibrations and seventeen source diagnostics keep approximation
mass, adelic neffness, strict thresholds, local/global roof comparison,
logarithmic tails and quasi-projective tightness separate. Imported
arithmetic Hodge/Siu/Fujita and convex originals are not recursively
certified. Question 6.21 is this source's necessity question, distinct
from BJ22 Theorem 6.21. Related open directions remain research notes,
not canonical register additions. Xue arXiv2608.08262 is metadata-only.

The [authored evidence](artifact_exports/20261009_Ballay_Sombra_published_sources/README.md)
is ready for authorized publication. The active 4,671-page book, native
86-page catalogue/editor, 42 atoms/twelve problems and tiers (0,3,7,15,17)
are preserved. No independent-model receipt or new result is claimed.
General BJ22 Siu/envelopes remain OPEN and LPWZ density UNVERIFIED.
Last complete ordered book reading remains 4 October. Next: scoped
projective variational exposition and a fully computed quadratic roof,
followed by validation and actual final-page reading. Cloud only;
Xean remains suspended. Export/upload adds no reading credit.

''';p.write_text(s.replace(marker,intro+marker,1))
editorial=[*paths.values(),dest/owned.name,dest/'SHA256SUMS',dest/'README.md',R/'README.md',p];assert len(editorial)==9
for rel,h in protected.items():assert sha(R/rel)==h
write(checkpoint,dict(UTC=stamp(),status='DONE — exact nine-file source export ready',baseline_commit=head,editorial_files={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in editorial},actual_reading_SHA256=sha(actual),diagnostics_SHA256=sha(diag),artifacts=artifacts,protected_core_inputs=protected,active_book_changed=False,native_editor_changed=False,GitHub_published=False,helper_source=__file__,helper_SHA256=sha(__file__)))
print(json.dumps(dict(status='DONE',actual_pages=99,actual_views=50,authored_members=len(files),cloud_members=len(fullfiles),actual_SHA256=sha(actual),diagnostics_SHA256=sha(diag),checkpoint_SHA256=sha(checkpoint))))
