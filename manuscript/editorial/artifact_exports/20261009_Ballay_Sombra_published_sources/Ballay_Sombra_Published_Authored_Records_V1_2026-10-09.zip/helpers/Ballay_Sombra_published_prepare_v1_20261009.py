from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, fitz
from PIL import Image, ImageDraw

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R / 'source_material/Ballay_Sombra_adelic_equdistribution_published_review_20261009'
W = Path('/tmp/Ballay_Sombra_published_views_v1_20261009')
pdf = C / 'Ballay_Sombra_Inventiones_2026_published.pdf'
record = C / 'source_preparation_v1_20261009.json'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not W.exists() and not record.exists()
acq = json.loads((C / 'source_acquisition_v1_20261009.json').read_text())
assert sha(pdf) == acq['SHA256'] == '6be58154779c6b26cf1ec6ccf1a3645100409f9b218994a2d42b9690f00ca5be'
text_path = Path(acq['preparation_text_path'])
assert sha(text_path) == acq['preparation_text_SHA256']
texts = text_path.read_text().split('\f')
assert len(texts) == 100 and not texts[-1].strip()
W.mkdir()
views = []
with fitz.open(pdf) as d:
    assert len(d) == 99
    first = d[0].get_text().lower()
    assert 'approximation of adelic divisors' in first and 'sombra' in first
    assert 's00222-026-01456-y' in first
    for number, start in enumerate(range(1, 100, 2), 1):
        pages = list(range(start, min(start+2, 100)))
        imgs = []
        for p in pages:
            pix = d[p-1].get_pixmap(matrix=fitz.Matrix(1.4, 1.4), alpha=False)
            imgs.append(Image.frombytes('RGB', [pix.width, pix.height], pix.samples))
        canvas = Image.new('RGB', (sum(i.width for i in imgs)+20, max(i.height for i in imgs)+38), 'white')
        draw = ImageDraw.Draw(canvas)
        x = 0
        for p, img in zip(pages, imgs):
            draw.text((x+8, 8), f'Ballay-Sombra published 2026: physical page {p}', fill='black')
            canvas.paste(img, (x, 30))
            x += img.width+20
        image_path = W / f'sheet_{number:02d}.png'
        canvas.save(image_path)
        selected = W / f'sheet_{number:02d}.txt'
        selected.write_text('\n\n'.join(f'BALLAY-SOMBRA PUBLISHED PHYSICAL PAGE {p}\n'+texts[p-1] for p in pages))
        views.append(dict(number=number, physical_pages=pages, path=str(image_path), image_SHA256=sha(image_path),
            selected_text_path=str(selected), selected_text_SHA256=sha(selected), source_PDF_SHA256=sha(pdf),
            actually_viewed=False, selected_text_read=False))
manifest = W / 'manifest.json'
manifest.write_text(json.dumps(views, ensure_ascii=False, indent=2)+'\n')
(C / 'primary_notes_v1').mkdir()
obj = dict(UTC=datetime.now(timezone.utc).isoformat(), status='PREPARED — zero actual-reading credit',
    source=dict(path=str(pdf), exact_edition=acq['edition'], DOI=acq['DOI'], bytes=pdf.stat().st_size,
                SHA256=sha(pdf), physical_pages=99),
    preparation_text_path=str(text_path), preparation_text_SHA256=sha(text_path),
    prepared_unique_pages=99, prepared_views=50, manifest_path=str(manifest), manifest_SHA256=sha(manifest),
    actual_primary_reading_credit=0, mathematical_clearance=False, book_changed=False,
    helper_source=__file__, helper_SHA256=sha(__file__))
record.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(dict(status=obj['status'], pages=99, views=50, preparation_SHA256=sha(record))))
