# Frozen v1 artifact preparation helper SHA256: ae3d1c3873ae74ecd1d857ff5e213ccd9b6d86d00319a79180a4e470428c0337
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Truong_polarized_CY_finiteness_review_20261008'
E=R/'manuscript/editorial';A=E/'artifact_exports/20261008_polarized_CY_finiteness_v2'
out=C/'repository_artifact_preparation_v2_20261008.json'
assert not A.exists() and not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
x=json.loads((C/'staged_export_v2_20261008.json').read_text())
act=E/'Truong_polarized_CY_finiteness_cloud_activation_v2_20261008.json';a=json.loads(act.read_text())
assert a['active_book_changed'] and sha(R/'manuscript/book.pdf')==a['active_PDF']['SHA256']==x['artifacts']['full_book_PDF']['SHA256']
A.mkdir();files={};lines=[]
for k in ['full_book_PDF','actual_book_review_PDF','minimal_TeX_source_archive','actual_book_evidence_archive']:
 row=x['artifacts'][k];p=Path(row['path'])
 assert sha(p)==row['SHA256'] and p.stat().st_size==row['bytes']<50*1024*1024
 q=A/p.name;shutil.copyfile(p,q);assert sha(q)==row['SHA256']
 files[str(q.relative_to(R))]=dict(SHA256=sha(q),bytes=q.stat().st_size,kind=k)
 lines.append(sha(q)+'  '+q.name)
(A/'SHA256SUMS').write_text('\n'.join(lines)+'\n')
(A/'README.md').write_text(f'''# Verified book and reading evidence: polarized Calabi–Yau uniformity, 8 October 2026

This directory contains the validated {a['active_PDF']['physical_pages']:,}-page book, its {a['actual_selected_book_pages']}-page selected review, the actual book-reading evidence archive ({x['artifacts']['actual_book_evidence_archive']['members']} byte-verified members), and the minimal reproducible source archive (472 byte-verified members). Section 62.8's unnumbered paragraph and new L.95 distinguish fixed-polarization stability from uniform analytic/algebraic data for varying families. All {a['actual_selected_book_pages']} selected book pages were genuinely read in {a['prior_genuine_matching_views']} v1 individual matching displays with complete text and sequential notes/receipts. EOF-only v2 reuses that review after exact complete-text and entire-page rendered-pixel equality on each selected page, adding zero fresh reading credit. SHA256SUMS pins the four binary exports; export and upload supply zero reading credit.

The controlling primary source arXiv:2610.00361v1, posted 30 September 2026, has 34 actually read pages in seventeen individual matching displays. Its [authored primary records](../20261008_truong_polarized_CY_finiteness_sources/README.md) are published separately. External primary PDF/text/images are absent from these book exports. The source is an unfinished finiteness programme. The book preserves the independent uniform Sobolev/curvature/embedding inputs, the conditional capacity/perimeter exponent calculation and exact literal proof diagnostics. A thin flat elliptic torus refutes the printed scale-free diameter formula; scale-dependent packing remains valid. A Fubini–Study P1 example refutes the general Kahler lemma's section-sup conclusion, and lower-dimensional added points refute the arbitrary-scheme Hilbert statement. These examples do not refute correctly restricted Ricci-flat or smooth connected pure-dimensional results. Classical compactness, boundedness and smooth-stratum Ehresmann inputs remain attributed and qualified. No unconditional finiteness theorem, general capacity/perimeter bridge or original general theorem is imported.

The evidence contains complete selected v2 book text/images, fourteen genuine v1 sequential notes/receipts, build/release/post-render records, mathematical self-audit, authored primary notes, draft TeX fragments and available reproduction helpers. The successful diagnostic helper's nonfatal descriptive-string warning and the primary extraction warning remain recorded. A prepared finalization template's preceding-source metadata was corrected in the actually executed v2 helper before creating finalization records. The v1 exact-commit whitespace preflight failed on one added empty EOF line; no commit or book upload occurred. V2 removes exactly one terminal newline, reruns full validation and preserves all frozen v1 records. Its evidence includes the prior actual images/text, notes/receipts, selected review and frozen editorial records, plus the new equality ledger. No new mathematical change or fresh v2 image-reading credit is claimed. Preparation flags remain false. The checks preserve 46 historical environment blocks including 14 proofs, and 61 manual equation tags; the other 423 TeX inputs and NonArchimedean bibliography remain unchanged. The last complete ordered whole-book reading remains 4 October.

The [cloud activation record](../../Truong_polarized_CY_finiteness_cloud_activation_v2_20261008.json) controls active bytes. The native catalogue/editor and 42 canonical atoms/twelve formal problems are unchanged: general BJ22 critical homogeneous Siu/envelopes OPEN, LPWZ density UNVERIFIED. No independent-model receipt is asserted. Frozen records retain their historical publication flags; GitHub publication and remote byte verification receive separate subsequent records.
''')
for n in ['README.md','SHA256SUMS']:
 p=A/n;files[str(p.relative_to(R))]=dict(SHA256=sha(p),bytes=p.stat().st_size,kind='documentation')
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — six owned repository artifact files prepared',files=files,book_export_record_SHA256=sha(C/'staged_export_v2_20261008.json'),activation_record_SHA256=sha(act),user_evidence_upload_authorized=True,reading_credit_from_preparation=0,GitHub_published=False,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',SHA256=sha(out),files=len(files))))
