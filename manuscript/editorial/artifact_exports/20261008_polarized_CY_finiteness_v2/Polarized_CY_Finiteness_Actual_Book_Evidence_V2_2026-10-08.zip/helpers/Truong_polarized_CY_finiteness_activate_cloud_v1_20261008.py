from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, zipfile

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Truong_polarized_CY_finiteness_review_20261008'
S=Path('/workspace/book-completion-drafts/polarized-CY-finiteness-staging-v1-20261008')
J=R/'manuscript/editorial/Truong_polarized_CY_finiteness_cloud_activation_20261008.json'
assert not J.exists()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(n):return json.loads((C/n).read_text())
names=['staging_preparation_v1_20261008.json','staged_export_v1_20261008.json','actual_staged_book_reading_v1_20261008.json','staged_book_release_checks_v1_20261008.json','post_render_checks_v1_20261008.json','staged_mathematical_self_audit_v1_20261008.json','staged_book_validation_v1_20261008.json','staged_underfull_delta_v1_20261008.json','exact_diagnostics_v1_20261008.json','exact_diagnostics_execution_observation_v1_20261008.json']
pins={n:sha(C/n) for n in names}
prep,export,reading,release,post,math=[load(n) for n in names[:6]]
assert reading['status'].startswith('DONE') and not reading['remaining_repairs']
assert reading['actual_unique_book_pages']==reading['fresh_complete_text_and_individually_displayed_pages']==len(release['selected_book_physical_pages'])==27
assert reading['fresh_matching_views']==len(reading['views'])==14
assert reading['reused_exact_complete_text_and_rendered_pixel_pages']==0
assert release['PDF']['SHA256']==reading['PDF']['SHA256']
assert math['actual_final_book_reading_SHA256']==pins[names[2]]
assert all(c['returncode']==0 for c in post['checks'])
assert not load(names[7])['added_blocks'] and not load(names[7])['removed_blocks']
for n,h in prep['before'].items():assert sha(R/n)==h
for n,h in prep['other_active_TeX_preserved'].items():assert sha(R/n)==sha(S/n)==h
nabib=prep['unchanged_bibliography'];assert sha(R/nabib['path'])==sha(S/nabib['path'])==nabib['SHA256']
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
for n,h in export['editorial_files'].items():assert sha(n)==h
changes=dict(prep['after'],**export['progress_document_hashes']);assert len(changes)==5
for n,h in changes.items():assert sha(S/n)==h
pdf=Path(reading['PDF']['path']);assert sha(pdf)==reading['PDF']['SHA256']
archive=Path(export['artifacts']['minimal_TeX_source_archive']['path'])
assert sha(archive)==export['artifacts']['minimal_TeX_source_archive']['SHA256']
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==472
 for n in z.namelist():
  assert (S/n).read_bytes()==z.read(n)
  if n not in changes:assert (R/n).read_bytes()==z.read(n)
before={n:sha(R/n) for n in changes}
for n,h in changes.items():
 target=R/n;tmp=target.with_name(target.name+'.polarized-CY-activation-tmp')
 assert not tmp.exists()
 shutil.copyfile(S/n,tmp);assert sha(tmp)==h;os.replace(tmp,target)
target=R/'manuscript/book.pdf';tmp=target.with_name(target.name+'.polarized-CY-activation-tmp')
assert not tmp.exists()
shutil.copyfile(pdf,tmp);assert sha(tmp)==reading['PDF']['SHA256'];os.replace(tmp,target)
with zipfile.ZipFile(archive) as z:
 for n in z.namelist():assert (R/n).read_bytes()==z.read(n)
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h
for n,h in pins.items():assert sha(C/n)==h
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — exact validated source and PDF activated in cloud workspace',before_source_hashes=before,after_source_hashes={n:sha(R/n) for n in changes},before_book_PDF_SHA256=prep['active_book_PDF_SHA256'],active_PDF=dict(path=str(target),bytes=target.stat().st_size,SHA256=sha(target),physical_pages=release['PDF']['physical_pages']),validation_record_hashes=pins,minimal_source_archive_members_byte_verified_against_active_tree=472,actual_selected_book_pages=27,fresh_complete_text_and_individually_displayed_book_pages=27,fresh_book_matching_views=14,exact_reused_actual_book_pages=0,exact_reused_book_views=0,actual_source_pages=34,actual_source_matching_images=17,source_scope='Truong Dinh Dat 2610.00361v1 complete primary reading; conditional programme only, literal gaps retained, external foundations qualified and source/helper warnings preserved',validation=release['build_checks'],underfull_diagnostics='All 955 inherited; normalized full text and multiplicities identical, zero added or removed',preserved_numbered_labels=release['all_prior_numbered_label_values_preserved'],preserved_citation_labels=release['bibliography']['prior_labels_preserved'],new_labels=release['new_semantic_labels'],new_bibliography_labels=release['bibliography']['new_labels'],other_TeX_inputs_preserved=423,historical_environment_blocks_including_proofs=46,historical_proofs=14,historical_manual_tags=61,open_problem_inventory='42 atoms, 12 formal problems, no status changes',critical_homogeneous_Siu_and_general_envelopes='OPEN',LPWZ_density='UNVERIFIED',native_catalogue_preserved=prep['native_catalogue_preserved'],native_editor_changed=False,whole_book_new_reading_claim=False,original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],active_book_changed=True,local_Git_commit_created_at_activation=False,GitHub_published=False,helper_source=__file__)
J.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],record_SHA256=sha(J),active_PDF_SHA256=sha(target),physical_pages=obj['active_PDF']['physical_pages'])))
