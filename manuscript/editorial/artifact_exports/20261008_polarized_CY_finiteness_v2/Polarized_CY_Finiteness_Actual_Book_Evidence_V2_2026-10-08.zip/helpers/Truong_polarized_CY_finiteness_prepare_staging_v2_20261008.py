from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess,shutil
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Truong_polarized_CY_finiteness_review_20261008'
B=Path('/workspace/book-completion-drafts/polarized-CY-finiteness-staging-v1-20261008')
S=Path('/workspace/book-completion-drafts/polarized-CY-finiteness-staging-v2-20261008')
out=C/'staging_preparation_v2_20261008.json'
failure=C/'local_commit_whitespace_gate_failure_v1_20261008.json'
assert not any(p.exists() for p in [S,out,failure])
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
old=json.loads((C/'staging_preparation_v1_20261008.json').read_text())
activation=R/'manuscript/editorial/Truong_polarized_CY_finiteness_cloud_activation_20261008.json'
a=json.loads(activation.read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==old['baseline_commit']
files=list(a['after_source_hashes'])+list(json.loads((C/'staged_export_v1_20261008.json').read_text())['editorial_files'])+[str(activation)]+list(json.loads((C/'repository_artifact_preparation_v1_20261008.json').read_text())['files'])
files=[str(Path(n).relative_to(R)) if Path(n).is_absolute() else n for n in files]
assert len(files)==len(set(files))==16
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).splitlines())==set(files)
run=subprocess.run(['git','diff','--cached','--check'],cwd=R,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
assert run.returncode==2 and run.stdout=='manuscript/appendices/appL_provenance.tex:10458: new blank line at EOF.\n'
failure.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='FAILED — exact commit preflight, no commit or upload occurred',command=['git','diff','--cached','--check'],returncode=run.returncode,output=run.stdout,staged_files=files,failed_helper_SHA256=sha('/tmp/Truong_polarized_CY_finiteness_local_integration_commit_v1_20261008.py'),v1_activation_SHA256=sha(activation),v1_export_SHA256=sha(C/'staged_export_v1_20261008.json'),failure_scope='one added empty line at Appendix L EOF; no mathematical or rendered defect',repair='new isolated v2 stage removes exactly one final newline; all completed v1 records/exports remain frozen',GitHub_book_published=False,helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
subprocess.run(['git','restore','--staged','--']+files,cwd=R,check=True)
shutil.copytree(B,S,ignore=shutil.ignore_patterns('*.pdf','*.aux','*.log','*.fls','*.fdb_latexmk','*.bbl','*.blg','*.toc','*.out','*.idx','*.ind','*.ilg','__pycache__'))
n='manuscript/appendices/appL_provenance.tex';p=S/n;t=p.read_bytes()
assert t.endswith(b'\n\n') and not t.endswith(b'\n\n\n')
p.write_bytes(t[:-1])
for n,h in old['after'].items():
 assert sha(R/n)==sha(B/n)==h
 if n!='manuscript/appendices/appL_provenance.tex':assert sha(S/n)==h
obj=dict(old)
obj.update(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — isolated EOF-only correction; v1 records frozen',stage_path=str(S),preceding_stage_path=str(B),preceding_preparation_SHA256=sha(C/'staging_preparation_v1_20261008.json'),commit_whitespace_failure_SHA256=sha(failure),after={n:sha(S/n) for n in old['after']},active_inputs_preserved={n:sha(R/n) for n in old['after']},baseline_book_PDF_SHA256=old['active_book_PDF_SHA256'],active_book_PDF_SHA256=sha(R/'manuscript/book.pdf'),EOF_only_repair=dict(path='manuscript/appendices/appL_provenance.tex',before_SHA256=sha(B/'manuscript/appendices/appL_provenance.tex'),after_SHA256=sha(S/'manuscript/appendices/appL_provenance.tex'),removed_bytes=1,source_byte_relation='v2 = v1[:-1], removing one terminal newline only'),actual_book_reading_credit=0,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],SHA256=sha(out),failure_record_SHA256=sha(failure),new_source_SHA256=obj['after'])))
