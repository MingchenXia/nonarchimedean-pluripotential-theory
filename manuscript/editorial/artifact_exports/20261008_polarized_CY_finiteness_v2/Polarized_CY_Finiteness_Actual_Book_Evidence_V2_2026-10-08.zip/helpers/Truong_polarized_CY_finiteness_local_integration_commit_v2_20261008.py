# Frozen failed v1 exact-commit helper SHA256: 54794277f1fa811c214092d0b8fe0a4eb2cd2f4fe3eb5d959e916e2051b1e8bc
# V2 includes the five frozen v1 editorial/activation records alongside sixteen final source/artifact files.
# Exact sixteen-file commit template SHA256: 3a169ffb6360cfa348af53f6824e0f2bddcf43b7b18a80f70a9378be2f8d89ef
# Frozen adapted exact-commit helper SHA256: dd091ee266a08f7a510ec804e658d1247941043623da70ecd699c1d6e13a3bd3
from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Truong_polarized_CY_finiteness_review_20261008';out=C/'local_integration_commit_v2_20261008.json';assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
act=R/'manuscript/editorial/Truong_polarized_CY_finiteness_cloud_activation_v2_20261008.json';a=json.loads(act.read_text());e=json.loads((C/'staged_export_v2_20261008.json').read_text());art=json.loads((C/'repository_artifact_preparation_v2_20261008.json').read_text())
prior=json.loads((C/'staged_export_v1_20261008.json').read_text());prior_act=R/'manuscript/editorial/Truong_polarized_CY_finiteness_cloud_activation_20261008.json'
files=list(a['after_source_hashes'])+[str(Path(n).relative_to(R)) for n in e['editorial_files']]+[str(act.relative_to(R))]+list(art['files'])+[str(Path(n).relative_to(R)) for n in prior['editorial_files']]+[str(prior_act.relative_to(R))];assert len(files)==len(set(files))==21
for n,h in prior['editorial_files'].items():assert sha(n)==h
for n,h in a['after_source_hashes'].items():assert sha(R/n)==h
for n,h in e['editorial_files'].items():assert sha(n)==h
for n,x in art['files'].items():assert sha(R/n)==x['SHA256']
assert sha(R/'manuscript/book.pdf')==a['active_PDF']['SHA256']
for n,h in a['native_catalogue_preserved'].items():assert sha(R/n)==h
assert subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True)==''
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head=='e0bcdf0d6322000ea9e464ad7d52d3a7da67047f'
subprocess.run(['git','add','--']+[n for n in files if n not in art['files']],cwd=R,check=True);subprocess.run(['git','add','-f','--']+list(art['files']),cwd=R,check=True)
assert set(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).splitlines())==set(files)
subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
run=subprocess.run(['git','commit','-m','Add qualified polarized Calabi-Yau finiteness programme with verified reading evidence'],cwd=R,check=True,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
new=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();obj={'UTC':datetime.now(timezone.utc).isoformat(),'status':'DONE — exact validated source and six owned artifact files committed','parent':head,'commit':new,'files':{n:sha(R/n) for n in files},'commit_output':run.stdout,'activation_SHA256':sha(act),'active_PDF':a['active_PDF'],'native_catalogue_preserved':True,'GitHub_published':False,'helper_source':__file__};out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':'DONE','commit':new,'files':len(files),'SHA256':sha(out)}))
