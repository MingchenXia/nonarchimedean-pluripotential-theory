# Frozen failed predecessor SHA256: 3a32dbd122fb8c3f680cd8052f5c5985668b99e68caa870bad7b06ffa79edb8e
# No-index --check accepts its ordinary difference exit 1 only with empty diagnostic output; dependent outputs were absent.
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,re,subprocess,difflib,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Truong_polarized_CY_finiteness_review_20261008'
S=Path('/workspace/book-completion-drafts/polarized-CY-finiteness-staging-v2-20261008')
B=Path('/workspace/book-completion-drafts/relative-Hessian-staging-v4-20261008')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
release=load('staged_book_release_checks_v2_20261008.json')
prior=load('actual_staged_book_reading_v1_20261008.json')
prep=load('staging_preparation_v2_20261008.json')
assert prior['fresh_complete_text_and_individually_displayed_pages']==27 and prior['fresh_matching_views']==14
manifest=Path(release['manifest_path']);assert sha(manifest)==release['manifest_SHA256']
xs=json.loads(manifest.read_text())
assert [x['physical_pages'] for x in xs]==[x['physical_pages'] for x in prior['views']]
views=[];page_equality=[]
with fitz.open(prior['PDF']['path']) as old,fitz.open(release['PDF']['path']) as new:
 assert len(old)==len(new)==4647
 for x,pv in zip(xs,prior['views']):
  assert not x['actually_viewed'] and not x['selected_text_read']
  assert sha(pv['path'])==pv['image_SHA256']
  assert sha(pv['selected_text_path'])==pv['selected_text_SHA256']
  assert sha(pv['sequential_note_path'])==pv['sequential_note_SHA256']
  assert sha(pv['observation_receipt_path'])==pv['observation_receipt_SHA256']
  note=Path(pv['sequential_note_path']).read_text()
  assert 'Read the complete selected text and displayed matching rendered image' in note
  receipt=json.loads(Path(pv['observation_receipt_path']).read_text())
  assert receipt['complete_selected_text_actually_read'] and receipt['matching_image_individually_displayed_and_reviewed']
  assert receipt['physical_pages']==x['physical_pages'] and receipt['source_PDF_SHA256']==prior['PDF']['SHA256']
  for n in x['physical_pages']:
   ot=old[n-1].get_text();nt=new[n-1].get_text();assert ot==nt
   op=old[n-1].get_pixmap(matrix=fitz.Matrix(1.4,1.4),alpha=False)
   np=new[n-1].get_pixmap(matrix=fitz.Matrix(1.4,1.4),alpha=False)
   assert (op.width,op.height,op.n,op.samples)==(np.width,np.height,np.n,np.samples)
   page_equality.append(dict(physical_page=n,complete_extracted_text_SHA256=hashlib.sha256(ot.encode()).hexdigest(),rendered_page_pixel_SHA256=hashlib.sha256(op.samples).hexdigest(),pixel_width=op.width,pixel_height=op.height,complete_text_identical=True,entire_page_rendered_pixels_identical=True))
  assert sha(x['path'])==x['image_SHA256'] and sha(x['selected_text_path'])==x['selected_text_SHA256']
  y={k:v for k,v in x.items() if k not in ['actually_viewed','selected_text_read']}
  y.update(inspection_mode='Exact complete-text and whole-page rendered-pixel equality to genuinely read/displayed v1 content',fresh_complete_text_read=False,fresh_matching_image_displayed=False,prior_actual_reading_reused=True,prior_actual_image_path=pv['path'],prior_actual_image_SHA256=pv['image_SHA256'],prior_actual_selected_text_path=pv['selected_text_path'],prior_actual_selected_text_SHA256=pv['selected_text_SHA256'],sequential_note_path=pv['sequential_note_path'],sequential_note_SHA256=pv['sequential_note_SHA256'],observation_receipt_path=pv['observation_receipt_path'],observation_receipt_SHA256=pv['observation_receipt_SHA256'])
  views.append(y)
assert len(page_equality)==27 and len({x['physical_page'] for x in page_equality})==27
reading=C/'actual_staged_book_reading_v2_20261008.json'
audit=C/'staged_mathematical_self_audit_v2_20261008.json'
post=C/'post_render_checks_v2_20261008.json'
assert not any(q.exists() for q in (reading,audit,post))
checks=[]
for command in (['python3','editorial/tools/refcheck.py'],['python3','editorial/tools/check_open_problem_inventory.py']):
 run=subprocess.run(command,cwd=S/'manuscript',text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 assert run.returncode==0,run.stdout
 checks.append(dict(command=command,returncode=run.returncode,output=run.stdout))
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
for n,h in prep['other_active_TeX_preserved'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
historical={};whitespace={}
for n in ('manuscript/parts/part5/ch62_k_stability_kahler.tex','manuscript/appendices/appL_provenance.tex'):
 before=(B/n).read_text();after=(S/n).read_text();counts={}
 for env in ('theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important'):
  patt=r'\\begin\{'+env+r'\}.*?\\end\{'+env+r'\}'
  blocks=re.findall(patt,before,re.S)
  assert all(b in after for b in blocks) and len(blocks)==len(re.findall(patt,after,re.S))
  counts[env]=len(blocks)
 tags=re.findall(r'\\tag\{([^}]+)\}',before)
 assert tags==re.findall(r'\\tag\{([^}]+)\}',after)
 historical[n]=dict(byte_preserved_environment_blocks=counts,prior_manual_equation_tags=tags)
assert sum(sum(v['byte_preserved_environment_blocks'].values()) for v in historical.values())==46
assert sum(v['byte_preserved_environment_blocks']['proof'] for v in historical.values())==14
assert sum(len(v['prior_manual_equation_tags']) for v in historical.values())==61
for n in prep['after']:
 before=(B/n).read_text().splitlines();after=(S/n).read_text().splitlines()
 wb=Counter(x for x in before if x!=x.rstrip());wa=Counter(x for x in after if x!=x.rstrip());assert wb==wa
 added=[x[2:] for x in difflib.ndiff(before,after) if x.startswith('+ ')];assert all(x==x.rstrip() for x in added)
 run=subprocess.run(['git','diff','--no-index','--check',str(B/n),str(S/n)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 assert run.returncode in (0,1) and run.stdout=='',(run.returncode,run.stdout)
 whitespace[n]=dict(historical_whitespace_lines_preserved=sum(wb.values()),added_lines_checked=len(added),added_trailing_whitespace_lines=0,git_whitespace_check_including_EOF='PASS',no_index_returncode=run.returncode,no_index_diagnostic_output=run.stdout)
reading.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — EOF-only v2, exact complete-text and rendered-pixel reuse of genuinely reviewed v1 pages',PDF=release['PDF'],actual_unique_book_pages=27,fresh_complete_text_and_individually_displayed_pages=0,fresh_matching_views=0,reused_exact_complete_text_and_rendered_pixel_pages=27,reused_matching_views=14,prior_actual_reading_record_SHA256=sha(C/'actual_staged_book_reading_v1_20261008.json'),page_equality_checks=page_equality,views=views,legacy_preparation_flags_rewritten=False,remaining_repairs=[],whole_book_new_reading_claim=False,active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
oldmath=load('staged_mathematical_self_audit_v1_20261008.json')
obj=dict(oldmath);obj.update(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — prior scoped mathematical audit preserved, EOF-only v2 source and exact-render reuse verified',source_input_hashes=prep['after'],actual_final_book_reading_SHA256=sha(reading),actual_final_book_reading_credit=0,reused_genuinely_reviewed_book_pages=27,preceding_math_audit_SHA256=sha(C/'staged_mathematical_self_audit_v1_20261008.json'),EOF_only_repair=prep['EOF_only_repair'],helper_source=__file__)
audit.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
post.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE',checks=checks,source_input_hashes=prep['after'],rendered_gate_SHA256=sha(reading),historical_formal_proof_warning_important_blocks_byte_preserved=historical,other_active_TeX_inputs_byte_preserved=423,whitespace_gate='PASS — added lines clean, historical whitespace preserved, no added EOF blank line',whitespace_details=whitespace,legacy_writing_audit_unavailable=True,manual_semantic_delimiter_source_and_rendered_audits_used=True,active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',reading_SHA256=sha(reading),math_SHA256=sha(audit),post_SHA256=sha(post),fresh_v2_reading_pages=0,exact_reused_actual_pages=27,prior_actual_views=14)))
