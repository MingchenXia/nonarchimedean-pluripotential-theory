from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, zipfile, fitz

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Truong_polarized_CY_finiteness_review_20261008'
S=Path('/workspace/book-completion-drafts/polarized-CY-finiteness-staging-v1-20261008')
E=R/'manuscript/editorial'
O=Path('/workspace/book-completion-drafts/research-integration')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(n):return json.loads((C/n).read_text())
prep=load('staging_preparation_v1_20261008.json')
release=load('staged_book_release_checks_v1_20261008.json')
reading=load('actual_staged_book_reading_v1_20261008.json')
post=load('post_render_checks_v1_20261008.json')
math=load('staged_mathematical_self_audit_v1_20261008.json')
underfull=load('staged_underfull_delta_v1_20261008.json')
assert reading['status'].startswith('DONE') and not reading['remaining_repairs']
assert not underfull['added_blocks'] and not underfull['removed_blocks']
assert all(x['returncode']==0 for x in post['checks'])
assert math['source_scope'].startswith('Truong Dinh Dat 2610.00361v1')
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
np=release['PDF']['physical_pages'];nb=reading['actual_unique_book_pages'];nv=reading['fresh_matching_views']
assert (np,nb,nv)==(4647,27,14)
assert nb==len(release['selected_book_physical_pages']) and nv==len(reading['views'])
full=O/'Non-Archimedean_Pluripotential_Theory_Polarized_CY_Finiteness_Staged_Preview_2026-10-08.pdf'
review=O/'Polarized_CY_Finiteness_Staged_Book_Review_2026-10-08.pdf'
minimal=O/'Polarized_CY_Finiteness_Staged_Minimal_Source_2026-10-08.zip'
evidence=O/'Polarized_CY_Finiteness_Actual_Book_Evidence_2026-10-08.zip'
record=C/'staged_export_v1_20261008.json'
paths={k:E/f'Truong_polarized_CY_finiteness_staged_integration_{k}_20261008.{ext}' for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in [full,review,minimal,evidence,record,*paths.values()])
shutil.copy2(release['PDF']['path'],full)
assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as book:
 d=fitz.open()
 for n in release['selected_book_physical_pages']:d.insert_pdf(book,from_page=n-1,to_page=n-1)
 assert len(d)==nb
 d.set_metadata(dict(title='Polarized Calabi–Yau uniformity and finiteness — book review, 8 October 2026',subject=f'{nb} actually reviewed pages; export adds no reading credit.'))
 d.save(review,garbage=4,deflate=True);d.close()
paths['audit'].write_text(f'''# Polarized Calabi–Yau uniformity and finiteness: integration audit, 8 October 2026

The validated staged edition has {np:,} pages. An unnumbered paragraph in Section 62.8 distinguishes stability on a fixed polarized manifold from uniform analytic and algebraic inputs for a varying family. New L.95, “Uniform bounds and Calabi–Yau finiteness,” gives the conditional exponent bookkeeping, explicit smooth diagnostics and qualified classical compactness/boundedness interfaces. The source is arXiv:2610.00361v1, posted 30 September 2026; it expressly leaves essential bridges unfinished. No unconditional finiteness theorem or general capacity-to-perimeter estimate is imported.

All 34 primary physical pages were actually read in seventeen individually displayed matching images, with complete selected text and sequential notes/receipts. The original extraction warning and the nonfatal descriptive-string SyntaxWarning from the successful exact diagnostic helper are retained. External classical foundations are attributed inputs, without recursive proof certification. The authored source checkpoint is already published and remotely byte-verified in e0bcdf0d6322000ea9e464ad7d52d3a7da67047f.

The final scoped book review freshly reads all {nb} selected physical pages in {nv} individually displayed matching views. It covers the new contents row, complete Section 62.8 context and adjacent part transition, the complete L.95 addition and both appendix seams, the complete index and the complete TD26F bibliography entry. Preparation flags remain false; actual observations are separate sequential receipts. There are no remaining repairs. A prepared, unexecuted finalization template had two preceding-source metadata fields; the executed v2 helper corrects those fields before any finalization record was created. No failed rendered iteration or earlier partial reading is claimed in this unit. The last complete ordered whole-book pass remains 4 October; this is a scoped review.

Required validation, the six existing checker regression tests, reference closure and canonical inventory pass. Fresh post-render reference/inventory checks and direct semantic, notation, delimiter, source, whitespace and rendered audits pass. The legacy writing audit is unavailable and is not reported as an automated pass. There are no TeX errors, LaTeX/package/pdfTeX warnings, missing glyphs, overfull boxes, undefined references/citations or rerun requests. All 955 underfull diagnostics are inherited with identical normalized text and multiplicities. All {release['all_prior_numbered_label_values_preserved']:,} prior numbered values and {release['bibliography']['prior_labels_preserved']} prior citation labels are preserved. One semantic label, one contents row, TD26F and two index terms are new. All {release['index']['accepted']} index entries are accepted without warnings or rejections; all {release['navigation']['internal_links']:,} internal links pass. External URL availability is not certified.

The two changed TeX inputs preserve all 46 historical environment blocks, including 14 proofs, and all 61 manual equation tags. No formal environment or manual tag is added. The other 423 TeX inputs and the NonArchimedean bibliography are unchanged. The 42 canonical atoms/twelve formal problems, native catalogue and editor remain unchanged: general BJ22 critical homogeneous Siu/envelopes OPEN and LPWZ density UNVERIFIED. No original general theorem, independent-model receipt or fresh whole-book pass is claimed.

The mathematical self-audit checks the following precise boundaries:

'''+''.join(f'{i}. {x}\n\n' for i,x in enumerate(math['checks'],1))+'''This byte-verified staged export does not itself claim cloud activation or GitHub publication of the book unit. Those actions receive separate records. Export adds zero reading credit.
''')
paths['reading_notes'].write_text(f'# Final scoped rendered-book notes, 8 October 2026\n\n{nb} fresh pages in {nv} individual matching displays. Preparation flags remain frozen.\n'+''.join('\n---\n\n'+Path(v['sequential_note_path']).read_text() for v in reading['views']))
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md'
prog=(R/programme).read_text()
marker='## Latest polarized Calabi–Yau finiteness source checkpoint, 8 October 2026\n'
assert prog.count(marker)==1
header=f'''## Latest polarized Calabi–Yau finiteness cloud integration checkpoint, 8 October 2026

The validated edition has {np:,} pages. The
[integration audit](Truong_polarized_CY_finiteness_staged_integration_audit_20261008.md)
records the unnumbered paragraph in Section 62.8 and new L.95. They separate
fixed-polarization stability from varying-family uniformity. The source operator
is 2 pi times the binding book operator. Capacity/perimeter exponent arithmetic
is conditional; no actual uniform perimeter bridge or unconditional finiteness
theorem is imported from arXiv:2610.00361v1.

The literal fixed-exponent and truncation gaps, Bishop–Gromov direction and
thin flat-torus numerical counterexample, corrected scale-dependent packing,
Bergman pointwise-versus-section-supremum distinction and arbitrary-scheme
Hilbert counterexample are stated with their exact scope. Smooth compactness,
common embeddings, restricted boundedness and smooth-base stratification
retain explicit hypotheses and attributed classical foundations.

All 34 primary pages were read in seventeen individual matching displays.
The final book gate freshly reads {nb} pages in {nv} individual matching displays.
Required validation and post-render checks pass; all 955 underfull diagnostics
are inherited. All {release['all_prior_numbered_label_values_preserved']:,} prior numbered values
and {release['bibliography']['prior_labels_preserved']} citation labels are preserved.
One label, one contents row, TD26F and two index terms are added. Other 423 TeX
inputs, the NonArchimedean bibliography, 46 historical environment blocks
including 14 proofs, and 61 manual tags remain unchanged.

The native catalogue/editor and all 42 atoms/twelve formal problems are
preserved: general BJ22 critical homogeneous Siu/envelopes OPEN, LPWZ density
UNVERIFIED. No original general result, independent receipt or new whole-book
pass is claimed; the last complete ordered pass remains 4 October.
The [activation record](Truong_polarized_CY_finiteness_cloud_activation_20261008.json)
controls the cloud edition; publication receives a separate record.
Continue author-update checks and the next exact primary source,
Lyuhui Wu arXiv:2609.27610v1 on local non-Archimedean psh functions.
Its 55-page PDF and twenty-eight prepared views have zero actual reading credit.

'''
(S/programme).write_text(prog.replace(marker,header+marker,1))
readme=(R/'README.md').read_text()
assert readme.count('**4,642 pages**')==1
readme=readme.replace('**4,642 pages**',f'**{np:,} pages**')
marker='**Latest polarized Calabi–Yau finiteness source checkpoint, 8 October 2026:**'
assert readme.count(marker)==1
intro=f'''**Latest checked book integration, 8 October 2026:** the
[polarized Calabi–Yau finiteness audit](manuscript/editorial/Truong_polarized_CY_finiteness_staged_integration_audit_20261008.md)
adds the uniformity paragraph in Section 62.8 and new L.95. It preserves the
unfinished analytic bridges and qualifies the literal proof gaps, smooth
diagnostics and classical compactness/boundedness inputs. All {nb} selected book
pages were freshly read in {nv} individual matching displays; required validation
and post-render gates pass. The
[activation record](manuscript/editorial/Truong_polarized_CY_finiteness_cloud_activation_20261008.json)
controls the {np:,}-page cloud edition. No unconditional finiteness theorem,
original general result, new whole-book pass or canonical status change is claimed.

'''
(S/'README.md').write_text(readme.replace(marker,intro+marker,1))
oldzip=O/'Relative_Hessian_Boundary_Staged_Minimal_Source_2026-10-08.zip'
with zipfile.ZipFile(oldzip) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 assert len(old.namelist())==472 and len(set(old.namelist()))==472
 for n in old.namelist():
  assert (S/n).is_file()
  z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
 for n in z.namelist():assert z.read(n)==(S/n).read_bytes()
paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — source/math/rendered staged gates',staging_preparation_SHA256=sha(C/'staging_preparation_v1_20261008.json'),validation_SHA256=sha(C/'staged_book_validation_v1_20261008.json'),release_checks=release,actual_reading=reading,post_render_checks=post,mathematical_self_audit=math,underfull_delta=underfull,exact_diagnostic_execution_observation=load('exact_diagnostics_execution_observation_v1_20261008.json'),source_input_hashes=prep['after'],progress_document_hashes={n:sha(S/n) for n in ['README.md',programme]},active_book_changed=False,GitHub_published=False,canonical_status_changes=[],original_results_promoted=[],independent_model_receipt=None),ensure_ascii=False,indent=2)+'\n')
files={f'records/{q.name}':q for q in C.glob('*.json')}
for q in sorted(C.glob('staged_book_validation_*.log')):files['records/'+q.name]=q
files['records/'+review.name]=review
files['records/final_views_manifest.json']=Path(release['manifest_path'])
for v in reading['views']:
 for key,folder in [('path','images'),('selected_text_path','text'),('sequential_note_path','notes'),('observation_receipt_path','receipts')]:
  q=Path(v[key]);files[folder+'/'+q.name]=q
for q in (C/'primary_notes_v1').iterdir():files['authored_primary_notes/'+q.name]=q
for key in ['audit','reading_notes','manifest']:
 q=paths[key];files['editorial/'+q.name]=q
for q in sorted(Path('/tmp').glob('Truong_polarized_CY_finiteness_*_20261008.py')):files['helpers/'+q.name]=q
for q in Path(prep['draft_path']).iterdir():
 if q.is_file():files['final_draft/'+q.name]=q
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
 assert len(z.namelist())==len(files)
 for n,q in files.items():assert z.read(n)==q.read_bytes()
artifacts=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — byte-verified staged book exports',full_book_PDF=dict(path=str(full),bytes=full.stat().st_size,SHA256=sha(full),physical_pages=np),actual_book_review_PDF=dict(path=str(review),bytes=review.stat().st_size,SHA256=sha(review),physical_pages=nb),minimal_TeX_source_archive=dict(path=str(minimal),bytes=minimal.stat().st_size,SHA256=sha(minimal),members=472,all_members_byte_verified=True),actual_book_evidence_archive=dict(path=str(evidence),bytes=evidence.stat().st_size,SHA256=sha(evidence),members=len(files),all_members_byte_verified=True),actual_source_export_record_SHA256=sha(C/'source_export_v1_20261008.json'),source_publication_record_SHA256=sha(C/'GitHub_source_publication_v1_20261008.json'),external_primary_files_uploaded_in_book_exports=False,actual_reading_credit_from_export=0,active_book_changed=False,native_editor_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__)
paths['artifacts'].write_text(json.dumps(artifacts,ensure_ascii=False,indent=2)+'\n')
record.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — frozen staged checkpoint and exports',editorial_files={str(q):sha(q) for q in paths.values()},artifacts=artifacts,progress_document_hashes={n:sha(S/n) for n in ['README.md',programme]},active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',record_SHA256=sha(record),artifacts=artifacts)))
