# Frozen v1 helper SHA256: b65f9f8b8c567f9874a442c20fc7e55ac67de4bdf64e92a162bd56e2e75b27da
# v2 removes only a terminal newline, retaining all v1 records.
# Template SHA256: 2c6fde753d042f59741487b897d65f56db134af139d0fbdb46ac9c2fee450993
# Frozen preceding v3 helper SHA256: 847a340b079a7db02ccb0f80d93182fdbf3c69d913762ea9470e7597cf12d272
# Frozen preceding v2 helper SHA256: 59782dc523ce739d94f91ceb1b3a639675a41cb68a9c98a64c79c276ee06fb1f
# Frozen preceding v1 helper SHA256: 0720f748a0f52e3bd2866ea7cd0f70eee92533ecd050e5ba30aa1a1cc43b88e2
# Frozen adapted underfull comparison template SHA256: e9c97b57b928e6b46fdcd17c3de2c76f3a2e114cc023a33c08eb950a1144e231
# Frozen v1 helper SHA256: b6159899ae10180b2543a0657d655448d3ecfe390637d7470ffcbdc28c63855e
# Frozen adapted diagnostic template SHA256: 5dc1c516878047cffc37f4c94606a05e515697eda6e4449df60bd8223d622251
# Frozen preceding template SHA256: 8654ec9a0bd874468753be15408269889bbc6387e08b22ea68419d9c95fc82b7
# Frozen v1 template SHA256: 624449f96eead60ffc9d9e701e0acf834c59742ad12a4130faab892897ec74c4
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import re,hashlib,json
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Truong_polarized_CY_finiteness_review_20261008')
old=Path('/workspace/book-completion-drafts/relative-Hessian-staging-v4-20261008/manuscript/book.log');new=C/'compiled_staged_v2/book.log';out=C/'staged_underfull_delta_v2_20261008.json'
assert not out.exists()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def blocks(t):
    rows=t.splitlines();ans=[]
    for i,x in enumerate(rows):
        if not re.match(r'Underfull \\[hv]box',x):continue
        a=[re.sub(r'at lines \d+(?:--\d+)?','at lines <range>',x)]
        for y in rows[i+1:]:
            if not y.strip():break
            a.append(y)
        ans.append('\n'.join(a))
    return Counter(ans)
a=blocks(old.read_text(errors='replace'));b=blocks(new.read_text(errors='replace'))
assert sum(a.values())==sum(b.values())==955 and a==b
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — all 955 underfull diagnostics inherited; none added or removed',baseline_log=dict(path=str(old),SHA256=sha(old)),staged_log=dict(path=str(new),SHA256=sha(new)),normalization='Only TeX paragraph source line ranges are replaced; all diagnostic text and font/content lines remain compared with multiplicity',prior_blocks=955,current_blocks=955,added_blocks=[],removed_blocks=[],all_normalized_blocks_and_multiplicities_identical=True,visual_reading_credit=0,helper_source=dict(path=__file__,SHA256=sha(__file__)))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='DONE',record_SHA256=sha(out),new_underfull_blocks=0)))
