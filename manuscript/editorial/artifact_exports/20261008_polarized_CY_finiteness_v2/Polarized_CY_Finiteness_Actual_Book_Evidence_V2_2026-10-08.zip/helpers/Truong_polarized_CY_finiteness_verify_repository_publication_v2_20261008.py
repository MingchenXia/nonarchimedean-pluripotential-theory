# Frozen remote verification template SHA256: a186a1e3217256f2d3b0ae6a0ebff98a1ab546e5fb67811b9619c2120d2838c3
# Frozen adapted remote-verification helper SHA256: efb81a05731d9a233fcec785937d965ad4718370bace3f6a838799cf4ecac97f
from pathlib import Path
from datetime import datetime,timezone
import subprocess,json,hashlib
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Truong_polarized_CY_finiteness_review_20261008';out=C/'GitHub_book_publication_v2_20261008.json';assert not out.exists();repo='MingchenXia/nonarchimedean-pluripotential-theory';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
api=lambda ep:json.loads(subprocess.check_output(['gh','api',ep],cwd=R,text=True))
local=json.loads((C/'local_integration_commit_v2_20261008.json').read_text());head=local['commit'];assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==head
remote=api(f'repos/{repo}/git/ref/heads/work');assert remote['object']['sha']==head
main=api(f'repos/{repo}/git/ref/heads/main');assert main['object']['sha']=='00957114db21b627e97369563032ceda9cea09c7'
tree=api(f'repos/{repo}/git/trees/{head}?recursive=1');assert not tree['truncated'];mapping={x['path']:x for x in tree['tree'] if x['type']=='blob'};rows=[]
for rel,h in local['files'].items():
 p=R/rel;assert sha(p)==h;x=mapping[rel];blob=subprocess.check_output(['git','hash-object',str(p)],cwd=R,text=True).strip();assert blob==x['sha'] and p.stat().st_size==x['size'];rows.append({'path':rel,'bytes':p.stat().st_size,'SHA256':h,'local_and_remote_Git_blob_SHA1':blob})
assert len(rows)==21
obj={'UTC':datetime.now(timezone.utc).isoformat(),'status':'DONE — twenty-one final book/source/audit/artifact and frozen v1 provenance files remotely verified','repository':repo,'branch':'work','commit':head,'main_unchanged':main['object']['sha'],'files':rows,'book_pages':4647,'actual_selected_book_pages':27,'actual_book_matching_images':14,'fresh_v2_book_reading_credit':0,'exact_text_and_whole_page_pixel_reused_book_pages':27,'source_pages':34,'source_matching_images':17,'EOF_only_repair':True,'v1_failed_commit_whitespace_record_SHA256':sha(C/'local_commit_whitespace_gate_failure_v1_20261008.json'),'external_foundation_proofs_recursively_certified':False,'external_primary_PDF_text_images_uploaded':False,'reading_credit_from_upload':0,'canonical_status_changes':[],'helper_source':__file__};out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':obj['status'],'commit':head,'SHA256':sha(out),'verified_files':len(rows)}))
