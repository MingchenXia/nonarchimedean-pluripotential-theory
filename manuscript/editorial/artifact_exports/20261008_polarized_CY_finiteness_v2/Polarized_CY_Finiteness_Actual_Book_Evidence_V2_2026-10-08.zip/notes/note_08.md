# Polarized CY uniformity and finiteness actual book view 08

UTC: 2026-10-08T22:14:23.588406+00:00. Physical pages: 4605, 4606.

Read the complete selected text and displayed matching rendered image for physical pages 4605–4606, the first two index pages. The new Bergman kernel / sum of section suprema and Calabi–Yau manifold / uniformity and finiteness subentries both point to printed page 4314, the actual L.95 start. Alphabetic placement, indentation, column transitions and linked page numbers are legible. Existing A–C entries retain their distinctions between BFJ/BJ capacity, CLD products, framework comparisons and complex normalization. No displaced entry, clipped column or new mathematical claim appears in these index pages.
