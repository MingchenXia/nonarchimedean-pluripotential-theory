# Polarized CY uniformity and finiteness actual book view 13

UTC: 2026-10-08T22:15:09.128389+00:00. Physical pages: 4615, 4616.

Read the complete selected text and displayed matching rendered image for physical pages 4615–4616. The final T–Z index page preserves tropical, valuation, higher-rank integral-data, weighted cscK, Yau–Tian–Donaldson and zero-volume references. Its final columns terminate cleanly and all page links are readable. Page 4616 is an intentional blank verso separating the finished index from the references; it contains no lost index continuation or stray marks. This closes the complete twelve-page index inspection for the current edition without requiring a repair.
