# Polarized CY uniformity and finiteness actual book view 12

UTC: 2026-10-08T22:15:01.124738+00:00. Physical pages: 4613, 4614.

Read the complete selected text and displayed matching rendered image for physical pages 4613–4614. The R–T index pages preserve research-frontier, source-audit and theorem-status navigation, and the two explicitly scoped complex Siu-decomposition subentries. Those index entries do not assert a repaired general BJ22 homogeneous Siu decomposition. Relative normalization, subintegral extensions, Stokes formulas, support notions, split-norm attainment and toric calculations remain separate. Both columns and page links are legible; the continued skeleton entry crosses the page boundary normally. No layout or status repair is needed here.
