# Qin curvature-rank source review — view 13

Physical pages: [25, 26].

Read the complete selected text and displayed matching rendered image.

Read full physical pages 25–26 and displayed their matching render. Lemma 7.1 keeps inherited G constraints on actual source variables and introduces tube inequalities holomorphic in all parameter copies. The normalized integral partition has a polynomial lower bound from fixed parameter margins and tube scale, independent of retained y. Relative collation takes horizontal components before parameter integration; derivatives in parameters retain dbar-b factors, while compact cutoffs justify Fubini and distributional differentiation. Face projections have bounded fiber volumes and preserve the pulled-back bundle metric. Ordered coarse fiber powers and their polynomial/logarithmic count are retained; the argument does not substitute zero repeated-index ordinary cochains for independent parameter copies. The result remains conditional on supplied vertical models. Proposition 7.2 begins their degree-budget recursion; the actual metric reconciliation and fine-grid count are still pending.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
