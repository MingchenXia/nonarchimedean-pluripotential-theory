# Qin curvature-rank source review — view 4

Physical pages: [7, 8].

Read the complete selected text and displayed matching rendered image.

Read full physical pages 7–8 and reviewed their matching render. Lemma 3.2 uses a triangular biholomorphism with determinant one to turn a graph into a flat hyperplane slice, imports successive Ohsawa–Takegoshi extension, and only then applies ambient Taylor truncation. The degree-N rank binomial and exponential error are consistent with fixed ambient/inequality dimensions; unbounded unrestricted graph evaluation is explicitly avoided. The extension constant still needs the exact external Ber96 theorem. Uniform buffers apply to every inherited inequality. Definition 3.3 keeps the maximal differential untruncated and adds T_(Q+1); its polynomial differential-product bounds are substantive hypotheses. The support nerve uses relative closed-support intersections and actual set inclusions, not merely coordinate identifications. The subsequent construction of these identities and their counts remains unverified.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
