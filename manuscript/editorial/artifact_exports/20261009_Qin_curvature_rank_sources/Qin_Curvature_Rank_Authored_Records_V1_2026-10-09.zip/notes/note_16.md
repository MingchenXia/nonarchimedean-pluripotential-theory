# Qin curvature-rank source review — view 16

Physical pages: [31, 32].

Read the complete selected text and displayed matching rendered image.

Read full physical pages 31–32 and displayed their matching render. The k=1 calibration has t=p^(-1/7), P0=p^(3/7), P1=p^(1/7), tube error O(p^(-11/7)) and global exponent r+2(n-r)/7; the inherited error is not rescaled. Final logarithmic absorption chooses fixed k before p. Extreme ranks use fixed unitary local frames for r=0 and the classical Morse bound for r=n. Kodaira rank follows from an integer exponent and classical section-growth lower bounds. Fixed line twists use one chosen section, divisor resolution and an induction on smooth components with fixed twists; vector twists use the lines-in-E-dual projective bundle with pushforward O(1)=E. Top-degree duality uses the dual line curvature, the same rank, and a fixed canonical/vector twist. Original section-growth, resolution and Serre/Hodge inputs remain external. The Euler-characteristic statement starts at the page end; its proof and examples are not yet read.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
