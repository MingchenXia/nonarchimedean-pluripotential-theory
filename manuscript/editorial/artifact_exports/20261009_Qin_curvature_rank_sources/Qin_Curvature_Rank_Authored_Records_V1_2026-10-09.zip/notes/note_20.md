# Qin curvature-rank source review — view 20

Physical pages: [39].

Read the complete selected text and displayed matching rendered image.

Read the complete final bibliography and author block. The decisive references include Berndtsson 1996 AIF 46(4),1083–1094 (DOI 10.5802/aif.1541) for graph extension; Binyamini–Novikov, Complex cellular structures, Annals 190(1),145–248 (2019), DOI 10.4007/annals.2019.190.1.3, for bounded-complexity complex cells; and Hormander 1965 Acta 113,89–152 for the terminal barpartial estimate. These are primary dependencies, not recursively cleared by merely reading this bibliography.

The MMZ scaling reference is the 2015 Contemporary Mathematics 644 chapter,175–202, DOI 10.1090/conm/644/12768. The source Fin26 reference is specifically arXiv:2603.22194v1, Kodaira–Iitaka dimension and multiplicity: an analytic perspective. The volume/contact-set comparison anchors are BEGZ10, BD12 and DNT21 in their listed published editions. Wlodarczyk principalization is the 2009 Gokova proceedings contribution,31–63. The author identity is Xiangsen Qin, Nankai University, matching the PDF identity and abstract metadata.

This final one-page matching view completes actual reading of physical pages 1–39 of the exact arXiv v1 PDF. No page was a skipped blank verso. Reading completion does not independently certify the cited originals, supply a separate-model production receipt, establish a sharp intermediate-degree bound, or clear a book insertion. No new mathematical claim is inferred from the bibliography or AI-use disclosure.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
