# Qin curvature-rank source review — view 19

Physical pages: [37, 38].

Read the complete selected text and displayed matching rendered image.

Appendix C derives the geometric section-map rank bound on Fujiki class C from earlier volume and envelope theory, independently of Theorem A. On a Kähler resolution, a=pi^*Theta_L/(2pi) has rank at most r, beta=f^*omega_FS/(2pi p) is semipositive of maximal rank d, and theta_epsilon=a+epsilon omega is big because beta+epsilon omega+p^(-1)[D] is a positive current in its class. The non-pluripolar product removes divisor mass and yields volume at least c epsilon^(n-d). The minimal-singularity obstacle envelope has contact-set mass 1_{phi_epsilon=0} theta_epsilon^n, and theta_epsilon is semipositive there. Bounded eigenvalues and at least n-r zero eigenvalues of a give volume at most C epsilon^(n-r). Constants are fixed for the chosen linear system/resolution, independent of epsilon; comparison as epsilon decreases gives d<=r.

Exact imported locators are BEGZ10 Definition 1.17 and Proposition 1.20, DNT21 Corollary 3.4(i), BD12 section 2 before Corollary 2.5, Blanchard Theoreme II.6 p.202, Demailly VI Definition 12.10, and Fujiki Lemma 4.6(2) p.35. This Qin review does not recursively certify those original editions. A Kähler modification preserves the mapping rank and cannot increase pulled-back curvature rank. Smooth divisor components and projective bundles remain in class C, supporting the endpoint reductions.

Page 38 relates the argument to Finski26 Theorems 1.1 and 1.3, Remark 1.4(a), Corollary 1.5 and Remark 1.6: graded-series envelopes require the stated projective and eventual-nonzero-degree hypotheses; agreement with minimal singularities is asserted for the complete series of a big line bundle. Outside bigness, the two envelopes can differ and non-pluripolar numerical dimension supplies only an upper bound for Kodaira dimension. These section-growth statements are explicitly not an all-degree argument for Theorem A.

The corank-one fixed-vector-bundle case is separately classical: choose a maximal nonzero mixed wedge of positive-power sections, principalize its coefficient ideal, and obtain an injection of the twisted section space into finitely many H^0(Y,M^(p-a_i) tensor O(D)). The divisor filtration and classical (n-1)-dimensional bound control the divisor terms without using Theorem A. On surfaces, flat rank zero, ordinary rank two, and rank-one endpoints plus Serre duality/Riemann–Roch give all-degree sharp bounds. Acknowledgments and the source AI-use disclosure were read as source metadata, not mathematical validation. References begin with Atiyah. Matching images and full selected text were readable.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
