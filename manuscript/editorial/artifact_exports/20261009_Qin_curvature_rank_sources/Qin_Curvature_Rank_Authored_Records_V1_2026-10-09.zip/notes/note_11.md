# Qin curvature-rank source review — view 11

Physical pages: [21, 22].

Read the complete selected text and displayed matching rendered image.

Read complete physical pages 21–22 and displayed their matching image. Initial jets use ambient derivatives through 2k+5, retain finite Taylor orders and obtain a C2 remainder after parabolic scaling; rank-zero germs have pluriharmonic Taylor jets. The rank threshold is qualitative and may be much smaller than actual t. In Lemma 6.4 all product maps and branch/grid choices are frozen as auxiliary tau tends to zero. The leading composition is independent of V, with added W in the old affine slots. The Schur coefficient gives K1 pluriharmonic on Q fibers; global polarized evaluation splits it without inverse-coordinate estimates. The quotient removes orders zero/one and the pure part of order two, while the old remainder is composed using C2 bounds, not differentiated in tau. The new mixed kernel's W block is invertible but its inverse is not controlled; the continuation must justify its rank identification and bounded refactorization. No complete recursion clearance yet.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
