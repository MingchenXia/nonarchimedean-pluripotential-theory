# Qin curvature-rank source review — view 3

Physical pages: [5, 6].

Read the complete selected text and displayed matching rendered image.

Read full physical pages 5–6 and displayed their matching image. The symbol table separates actual scale t, auxiliary tau, fixed rescaling depth and coefficient P_l=p t^(4+2l), with all source and retained variables still included in the Dolbeault differential. The scalar frame comparison uses e^(pg) and phi-2Re(g), consistent with squared Hermitian norms. Proposition 3.1 is conditional on recursively buffered covers, polynomial coordinate/cutoff comparisons and bounded terminal weights. Those hypotheses cannot be inferred from the counting assertion alone; their construction in Sections 4–9 remains to be checked. Intrinsic maximal distributional complexes avoid arbitrary exponential transition coefficients; fixed E affects constants/multiplicity. The displayed source is readable. No clearance of the local solvability or global collation argument is assigned yet.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
