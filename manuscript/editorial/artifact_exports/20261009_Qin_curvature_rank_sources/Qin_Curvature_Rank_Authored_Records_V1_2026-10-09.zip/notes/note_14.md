# Qin curvature-rank source review — view 14

Physical pages: [27, 28].

Read the complete selected text and displayed matching rendered image.

Read full physical pages 27–28 and displayed their matching render. The recursive degree budget increases child order by one and keeps all higher homotopies; fixed depth bounds dimensions and all inherited inequality margins. Outer t and t^2 grids have the expected complex-real dimension counts, and dense regular centers are used only for Taylor identities rather than uniform rank neighborhoods. Rank-zero tuples stop at a bounded terminal weight. Tube coverage uses the approximation accuracy (2p)^(-2), adds m displacement parameters but leaves actual z independent, and obtains polynomial cutoff denominator bounds by a parameter ball of radius comparable to eta. The first-copy b-grid is applied before inherited clipping, with V/W ungridded. This resolves the concern that product maps would have to be immersive coordinate charts: the old variables are retained and tube constraints compare them to a new parameter model. The accumulated scalar-metric error still needs the continuation on page 29.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
