# Qin curvature-rank source review — view 2

Physical pages: [3, 4].

Read the complete selected text and displayed matching rendered image.

Read full physical pages 3–4 and displayed their matching render. The introduction itself explicitly distinguishes fixed-epsilon power loss from the stronger prescribed-divergent-factor MMZ question, since constants are not controlled as rescaling count k grows. Semipositive degree bounds and prior class-C/surface/end-degree results keep their external attributions. The strategy identifies complex cellular parametrization, finite-jet rank retention, and additive restriction-factor counts as load-bearing steps to audit. The curvature convention in (2.2) has a literal sign inconsistency: connection -partial(phi) yields R=-barpartial partial(phi)=partial barpartial(phi), whereas its displayed R is barpartial partial(phi) and displayed Theta is i partial barpartial(phi). A Gaussian local weight can calibrate this; rank itself ignores this sign. Congruence preserves rank and inertia but not numeric eigenvalues, as the text correctly states. Pullback rank and tensor/dual conventions were read; none clears the later rescaling proof. External Berndtsson/WZ/Bouche/volume/cellular references remain unaudited here.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
