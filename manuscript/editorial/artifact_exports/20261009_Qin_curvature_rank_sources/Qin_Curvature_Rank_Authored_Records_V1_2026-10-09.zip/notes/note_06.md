# Qin curvature-rank source review — view 6

Physical pages: [11, 12].

Read the complete selected text and displayed matching rendered image.

Read complete physical pages 11–12 and displayed their matching image. Lemma 3.4 uses exact telescoping with F=K-W and retains Q+1 layers; repeated W lowers vertical degree, while a single displayed holomorphic factor in each surviving summand permits additive approximation ranks. The child order Q+1 supplies homotopy maps through Q+2, as needed for the maximal-domain step. Prefixes are kept exact rather than separately approximated. The final root approximation occurs after harmonic projection, giving an injective finite-rank operator on cohomology when error is below one half; it does not need a uniform spectral gap or approximate chain-map assertion. These algebraic steps remain conditional on the geometric covers and polynomial operator bounds. The fourth-order section begins on page 12 with a Hermitian-kernel/Jacobian identity and an explicit ban on reciprocal-eigenvalue dependence in estimates. Its construction is still to be checked.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
