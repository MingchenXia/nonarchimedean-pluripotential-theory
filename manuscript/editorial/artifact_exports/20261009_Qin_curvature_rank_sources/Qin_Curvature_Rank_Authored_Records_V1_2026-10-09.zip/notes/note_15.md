# Qin curvature-rank source review — view 15

Physical pages: [29, 30].

Read the complete selected text and displayed matching rendered image.

Read full physical pages 29–30 and displayed their matching render. Equation (8.3) keeps the exact finite-jet family separate from a bounded scalar-metric error depending on retained old variables. Tube comparison adds P_l times a first-derivative error of size eta; P_l<=p and eta=40(2p)^(-2) bound the fixed-depth sum. The error is not divided by t^2 and receives no rank or derivative assertion. This explicitly reconciles nonimmersive product parametrizations with the actual bundle metric and preserves old constraints at their original variables. The terminal square completion gives bounded actual weights. The counting cancellation t^(-2km)*P_k^m=(p*t^4)^m, the improvement for smaller b dimensions, and the global t^(-2n)*(p*t^2)^r exponent r+2(n-r)/(2k+5) were read and algebraically checked. Additive restriction ranks prevent nerve-degree powers of the fine grids. External cellular/extension/local-solvability inputs remain separate; this does not solve the stronger variable-loss question.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
