# Qin curvature-rank source review — view 8

Physical pages: [15, 16].

Read the complete selected text and displayed matching rendered image.

Read full physical pages 15–16 and displayed their matching image. The continuation of Lemma 4.3 replaces the inverse-based identification by bounded kernel sections, preserving the affine-in-u/quadratic-in-v shape and using C*JC=A0 only for invertibility. Estimates need no bound on C inverse, and the working box need not remain in the constant-rank germ. Section 5 imports precise complex-cell conventions and coefficient-uniform algebraic parametrization from BN19. Lemma 5.1 encodes a small sublevel by beta*rho*xi-h rather than division by rho, retaining zero cells and deleting the forced point fiber; its reliance on the original cellular theorem is explicit. Lemma 5.2 promises uniform product approximation while keeping selected Q dependence exact and graph complexity independent of epsilon. Disc and punctured-disc steps were read; the annular step and full parameter-count assertion still need audit. BN19 has not been independently read.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
