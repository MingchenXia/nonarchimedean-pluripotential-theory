# Qin curvature-rank source review — view 7

Physical pages: [13, 14].

Read the complete selected text and displayed matching rendered image.

Read complete physical pages 13–14 and displayed their matching image. Lemma 4.1's Fekete determinant argument bounds the Lagrange basis and the indefinite kernel factor by d*sqrt(B), using no lower bound on small eigenvalues. Dense regular points follow from maximal rank on each open set. The parabolic construction uses constant rank only as a germ Taylor identity: D=B* A^(-1) B, D0=D1=0, closed holomorphic first cross-block rows, and the scaled Levi limit. Unbounded A0 inverse appears only in identifying W=u+A0^(-1)G; the upcoming bounded-factor replacement must remove it from estimates. The C5 Taylor remainder scales to O(t) in the pulled-back Levi comparison. The shape and degree of the resulting Q and independent coefficient bounds have not been fully checked until the continuation. No proof of variable-rank cover construction is inferred from regular-set density alone.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
