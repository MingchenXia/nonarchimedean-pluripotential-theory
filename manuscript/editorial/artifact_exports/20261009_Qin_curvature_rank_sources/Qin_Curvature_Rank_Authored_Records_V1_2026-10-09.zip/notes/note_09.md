# Qin curvature-rank source review — view 9

Physical pages: [17, 18].

Read the complete selected text and displayed matching rendered image.

Read full physical pages 17–18 and displayed their matching image. The annulus proof separates two ends from a middle region. Fixed-margin affine discs plus graph-sublevel refinement control the ends without dividing by small coefficients; Laurent tails bound the middle by a constant multiple of theta. Its midpoint uses a holomorphic square root after the cited cellular two-cover, not a nonholomorphic modulus. Approximation is uniform in retained parameters, while Q composition remains an exact identity. The logarithmic chart recurrence is fixed-depth, with no claim of uniformly controlled constants as dimension/depth grows. Prefix preservation and bounded algebraic complexity rely on BN19's precise theorem and two-cover, still external. Proposition 5.3 starts a target-first graph parametrization with b-dimension at most m and total free dimension at most n; its proof and later augmentation for dimension-changing maps remain to be read.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
