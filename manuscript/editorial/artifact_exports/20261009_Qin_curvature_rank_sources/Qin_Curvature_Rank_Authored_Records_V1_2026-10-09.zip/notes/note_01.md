# Qin curvature-rank source review — view 1

Physical pages: [1, 2].

Read the complete selected text and displayed matching rendered image.

Read full physical pages 1–2 and displayed their matching render. The title, author and arXiv v1 date are uppercase in the source, explaining the earlier case-sensitive identity preflight failure; the PDF itself is the intended edition. The abstract and Theorem A claim O_epsilon(p^(r+epsilon)) in all Dolbeault degrees for smooth Hermitian L on compact complex X with fixed E, without positivity, constant rank or Kahler assumptions. End degrees claim O(p^r). The quantitative exponent r+2(n-r)/(2k+5) retains k fixed before p and degree-independent C_k,N_k. The stated earlier MMZ question asks for an arbitrarily prescribed divergent factor, which is stronger than a bound with each fixed positive exponent loss; this distinction must remain. The printed end-degree display has a literal malformed p>=) endpoint. Demailly/Bouche/MMZ/Wang are original external inputs, not yet inspected here. The source renders legibly despite the extraction font-type warning. The statement's proof is not cleared by reading its introduction.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
