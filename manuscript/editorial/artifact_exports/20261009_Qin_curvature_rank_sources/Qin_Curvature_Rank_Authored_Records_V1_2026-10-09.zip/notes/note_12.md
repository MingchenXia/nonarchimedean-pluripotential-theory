# Qin curvature-rank source review — view 12

Physical pages: [23, 24].

Read the complete selected text and displayed matching rendered image.

Read complete physical pages 23–24 and displayed their matching image. Lemma 6.4 derives the new mixed kernel rank from a C2 limit and an invertible W block, then uses bounded Fekete sections to remove reciprocal-eigenvalue estimates. Its finite-jet remainder consumes exactly two powers without re-expanding the smooth tail; actual-scale bounds are distinguished from qualitative rank thresholds. The final target-cell square completion keeps the 1/2 constant and requires P*t bounded. Section 7 retains previous constraints at their original variables and uses Euclidean form metrics in added parameter directions, avoiding a degenerate pulled-back tangent metric. Lemma 7.1 begins the dimension-changing parameter integration argument. A key remaining check is how its arbitrary, possibly nonimmersive product maps are reconciled with the m-slot rescaling and the actual scalar metric on the original source; this cannot be inferred merely from density of their images.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
