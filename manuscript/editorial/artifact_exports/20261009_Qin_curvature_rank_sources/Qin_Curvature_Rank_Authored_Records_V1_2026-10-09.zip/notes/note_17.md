# Qin curvature-rank source review — view 17

Physical pages: [33, 34].

Read the complete selected text and displayed matching rendered image.

Proposition 10.5 uses the globally smooth Chern form alpha=Theta_L/(2pi): rank at most r implies alpha^(r+1)=0 pointwise, and analytic Hirzebruch–Riemann–Roch truncates the Euler characteristic polynomial at degree r without requiring X to be Kähler. Corollary 10.6 on surfaces then bounds the middle group by the two sharp endpoint bounds and |chi|; the source explicitly classifies this as a classical consequence, not a new intermediate-degree application.

Example 11.1 on P^r times a connected compact complex manifold Y, with L pulled back from O(1), has h^0=binomial(p+r,r), showing that the exponent r is sharp. Example 11.2 blows up P^1 times P^1 at one point and pulls back the first projection metric. In the charts f=uv and f=s, the curvature rank is one except at the isolated critical point u=v=0. The two kernel lines along the coordinate axes have different limits there, so the metric does not supply a global regular kernel foliation. Hartogs descent gives h^0=p+1. These examples illustrate rank geometry; the source does not present them as new all-degree applications.

Question 11.3 leaves the sharp O(p^r) bound for intermediate degrees on general compact complex manifolds open, for n>=3 and 1<=r<n, with a fixed auxiliary holomorphic vector bundle and no positivity, constant-rank, or foliation hypothesis. The stronger arbitrary-divergent-factor formulation discussed in Remark 11.4 is equivalent, for fixed geometric data, to a sharp bound: if a_p=h^q/p^(n-s) is unbounded, select increasing p_j with a_(p_j)>(j+1)^s and a nondecreasing epsilon equal to j between successive p_j. The asserted eventual bound then fails at infinitely many p_j. In contrast, all fixed positive exponent losses permit p^r log p and do not imply the sharp bound.

Appendix A begins Lemma A.1, linear-in-p vanishing-order control for a nonzero section of a fixed tensor power family. The finite-atlas frame transitions have exponential-in-p bounds, and the three-circle exponent is fixed by the three chosen radii. The propagation along fixed finite paths continues on the next pages. No clipped equation or line was identified in the matching page images.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
