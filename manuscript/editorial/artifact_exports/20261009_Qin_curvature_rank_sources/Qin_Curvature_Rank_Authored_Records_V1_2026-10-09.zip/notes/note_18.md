# Qin curvature-rank source review — view 18

Physical pages: [35, 36].

Read the complete selected text and displayed matching rendered image.

Lemma A.1 finishes by a fixed finite covering/path propagation estimate, then compares exp(-C p) with the radial Schwarz bound 2^(-v) exp(C p), yielding v<=c p. Lemma A.2 is the classical Serre–Siegel growth argument: choose a power with kappa independent section ratios, choose a local root frame for s_0, and use maximal mapping rank to show every local coefficient depends only on the kappa ratio coordinates. The linear vanishing-order bound makes its degree floor(c p) jet injective; independent ratio monomials give the binomial lower bound in a fixed arithmetic progression. Cases kappa=0 and no sections are treated separately.

Appendix B Proposition B.1 is independent of Theorem A. It locates a positive maximum at a point of maximal section-map rank, with semipositive curvature of rank at least that mapping rank. Principalization resolves the common-zero ideal and extends the section map to a proper map from a smooth compact modification. The image of its critical locus has dimension at most d-1 and is projective algebraic, allowing a polynomial P that vanishes on critical values but not on the image. Multiplying all sections by P of the section tuple moves the positive maximum of their squared norm sum off both the base locus and the critical locus. At this point the Hessian inequality is 0<=Phi^*omega_FS<=p(e+1)Theta_L, hence the curvature is semipositive and its kernel is contained in that of the pullback Fubini–Study form. The polynomial degree need not be bounded, since this is a qualitative rank comparison. For d=0 use P=1; disconnected components are handled by restricting the subsystem image.

Load-bearing external locators in this appendix are Wlodarczyk 2009 Theorem 2.0.3 and Lemma 4.0.3, Remmert proper-image/dimension results, and Chow algebraicity. Those originals have not been recursively read in this Qin review. The source states the consistent positive curvature convention i partial barpartial phi here; the earlier printed Chern-connection sign discrepancy should remain a literal-source diagnostic, not a change to this argument. Both page images were readable with complete text; Appendix C begins at the end of page 36.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
