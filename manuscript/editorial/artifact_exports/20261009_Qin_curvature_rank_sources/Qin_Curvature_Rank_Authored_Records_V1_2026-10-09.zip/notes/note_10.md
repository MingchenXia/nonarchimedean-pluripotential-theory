# Qin curvature-rank source review — view 10

Physical pages: [19, 20].

Read the complete selected text and displayed matching rendered image.

Read full physical pages 19–20 and displayed their matching render. Proposition 5.3 parametrizes the target-first graph; its maps may have lower source dimension and are explicitly not assumed injective, immersive or invertible. Graph-complexity preservation includes exceptional frozen nodes via normalized polynomial limits, distinct from analytic norm bounds obtained by Cauchy estimates. Definition 6.1 separates uniform coefficient/C2 remainder bounds from a possibly nonuniform small-tau rank threshold, and does not assert that actual t lies below that threshold. This is a crucial quantifier boundary to retain during rescaling. The leading kernel is affine in its m nondegenerate variables and may have m=0. Lemma 6.3 begins the initial finite-jet construction but its proof is on the next selected pages. No new rank theorem is cleared by these definitions or algebraic operations alone.

Scope: these selected source pages only; no recursive reference certification or book-integration clearance.
