# Actual ordered reading 37 — Xue arXiv v2, physical pages 73–74

Complete selected text and matching displayed image read. Actual coverage now 1–74 of 83.

Corollary 108 and Remark 110 explicitly use restricted quasi-canonical Bogomolov before the strict upgrade, rather than importing the later monocritical conclusion circularly. The relative fiber-specialness appendix is expressly not part of this main route. The actual restricted metrics and their smallness comparison still need the following restriction package, and the already flagged auxiliary proof failures remain. The explicit general-fan hypotheses cannot be lost through phrases such as 'standing hypotheses' or 'under consideration'.

Remark 109 usefully restricts 'general metric' to semipositive, monocritical and arithmetic T-effective metrics on ample T-effective geometry. It does not prove arbitrary semipositive toric equidistribution/Bogomolov. Proposition 111's compact-support description is the translated maximal compact subgroup in the complex semiabelian group, conditional on the strict theorem. Tropical concentration alone does not select the phase distribution; the quasi-canonical equidistribution input is what supplies the Haar phase part.

Lemma 112's minimum-dimension subgroup-coset envelope is a valid algebraic construction. The intersection of two candidates may have finite components; irreducibility of X places it in one connected component, and minimal dimension gives uniqueness. A proper translate inside the minimal envelope intersects X properly, so an X-generic sequence is strict under the source's every-translate avoidance convention.

The subsequent notation TB=B intersect T needs care before treating TB as a torus: for a connected semiabelian subgroup B, that intersection can contain a nontrivial finite part. The torus part is its identity component, while B/TB^0 maps isogenously, not always isomorphically, onto pi(B). Such finite-kernel data should be retained in the restriction/torsor package. No source-specific repaired construction is claimed here.

Theorem 113 imports classical abelian Bogomolov with symmetric ample Néron–Tate height. Lemma 114 begins the torsion-base representative argument under equality of the subvariety and ambient minima; its proof continues on page 75. No intended main theorem, restricted metric or book integration is cleared yet.
