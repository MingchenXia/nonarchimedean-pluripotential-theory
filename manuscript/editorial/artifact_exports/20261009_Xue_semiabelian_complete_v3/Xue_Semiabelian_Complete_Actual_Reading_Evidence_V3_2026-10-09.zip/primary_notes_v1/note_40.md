# Actual ordered reading 40 — Xue arXiv v2, physical pages 79–80

Complete selected text and matching displayed image read. Actual coverage now 1–80 of 83.

Theorem 122 continues the imported BGPS toric Bogomolov property and affine-valuation criterion for special torus translates, citing Theorem 5.12 and Proposition 5.14. Remark 123 correctly says that this toric theorem alone does not give a semiabelian theorem: one also needs abelian control and a global subgroup-coset gluing argument. This explicit warning is retained rather than treating a reference to toric Bogomolov as clearance of the semiabelian proof.

Proposition 124 cites BGPS Proposition 5.13 for point attainment and a simultaneous S-unit/root construction. The complete source statement, ground-field conventions, all places of a finite extension and simultaneous realizability of the adelic vector need verification there. This reading does not independently derive simultaneous attainment merely from the displayed separate-place membership conditions. No counterexample to the cited original criterion is asserted.

Lemma 125's rational lattice intersection is a correct split-torus calculation for a genuine saturated subtorus: choose an integral lattice complement and tensor with the rationalized valuation group. The ambient real-subspace intersection then equals the subtorus's rationalized valuation group. Applying it to TB still requires resolving the earlier finite part of B intersect T and the defining field.

Proposition 126 is a coherent conditional use of that lattice calculation and of a verified simultaneous toric special-point criterion, together with Lemma 116 and the restriction package. Identifying ambient L-special points with the toric criterion also uses the torsion-base decomposition and the compatible intrinsic height formula; it does not follow solely by replacing the toric metric or citing Proposition 124. The final abelian height contribution is zero because the base image is torsion.

Lemma 127 begins the converse by translating the Zariski-dense torsion points of B. A minimal-height p must have torsion abelian image, and can be written q t with q torsion. Height invariance for (q xi)t depends on the actual torsion-translation height identity (Corollary 22). This is a conditional standard converse mechanism; its proof continues on page 81.

No recursively cleared BGPS source, main-theorem counterexample, new independent verification or book change is claimed.
