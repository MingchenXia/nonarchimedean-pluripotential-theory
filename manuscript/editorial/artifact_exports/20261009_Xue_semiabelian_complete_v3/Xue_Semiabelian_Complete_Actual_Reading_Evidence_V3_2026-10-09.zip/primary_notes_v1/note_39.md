# Actual ordered reading 39 — Xue arXiv v2, physical pages 77–78

Complete selected text and matching displayed image read. Actual coverage now 1–78 of 83.

Proposition 118's support-function restriction is the correct formal toric calculation conditional on an actual intrinsic semiabelian restriction construction: Psi_DB=Psi_D composed with iota_N, and alpha_v-u_v=-iota_N(w_v). Centering of w follows from injectivity and the two weighted product formulas over a common defining field. This calculation does not supply Lemma 115's missing passage beyond the torus, resolve the finite part of B intersect T, or prove the full restricted metric/gluing identity.

Translation by a torsion point preserves Neron–Tate heights. Literal translation invariance of a symmetric ample line bundle on A needs more precision: its translated difference is a torsion Picard-zero line bundle, not necessarily the trivial bundle. A suitable tensor power or rational metrized-line-bundle identification, with its compatible canonical isometry, must be specified for the displayed equality. Likewise NB on pi(B) must be pulled along the actual isogeny from B/TB^0 if the toric intersection has a finite part. No repaired source-specific isometry is established here.

Corollary 119 correctly uses the global KR/Lipschitz mechanism conditional on those restriction identities and the common-field orbit conventions; a one-place weak convergence alone would not justify the adelic height comparison. Proposition 120's strictness follows from the minimal envelope. Zariski density of a translated maximal compact subgroup is a standard complex semiabelian fact. However, invoking Theorem 106 cannot remove the general-fan assumptions of Theorem 77. Proposition 118 checks ampleness, effectivity and centering; it does not independently establish the required curvature–Haar package on every restricted subvariety. Thus the general-fan strict equidistribution and resulting Bogomolov route remain unverified.

Proposition 121 explicitly records normal forms, monocriticality and scalar extension through BGPS 4.16, 5.3 and 4.17. Those are primary-source dependency locators to check, not recursive clearance obtained by this reading. Theorem 122 begins the imported toric Bogomolov statement and continues on page 79. No arbitrary semipositive toric metric claim is inferred.

No main-theorem counterexample, independent production-verifier receipt, repaired theorem or book integration is claimed.
