# Actual ordered reading 34 — Xue arXiv v2, physical pages 67–68

Complete selected text and matching displayed image read. Actual coverage now 1–68 of 83.

Lemma 98's proof now invokes an X-generic AMBIENT-small sequence to obtain the restricted cycle-height bound and the arithmetic-volume package. This supplies the missing smallness input in the intended application, though it was absent from the lemma's broad statement. Proposition 100(a) explicitly imposes mu_ess(X)=mu_ess(H) and the corresponding generic small sequence, so that particular signature deficiency is not by itself a counterexample to this application. Compatible lifts and zero abelian-image height still need the correctly defined metrized tower.

The binomial cancellation is now stated in both numerator and denominator, and cancellation of delta(Y) is distinguished from field-degree normalization. Those are appropriate probability conventions. First-variation powers must retain the component cycle and exact metric pullback before exponent estimates; merely naming the projection formula does not fix the earlier noncanonical shift/index failure.

Proposition 100 is an assembly of the preceding restricted variation package, archimedean charts, corner/Haar formula, Riemannian domination, operation smallness and pushforward. It directly invokes the failed whole-slice formula and the overly broad finite-slice functoriality statement. Enumerating their locators as explicit replacements does not establish those inputs after the P2/graph calibrations.

The theta sign discussion is meaningful as a consistent change of coordinate/dual convention. If one changes m to -m, the support-function/toric-character description must transform with that coordinate change; it is not a license to invert an arbitrary nonsymmetric toric metric while claiming it unchanged. Canonical Picard-zero flatness at complex places does justify its own zero-curvature contribution, but still does not authenticate the raw non-archimedean theta norm.

The remainder of Proposition 100 and the dominant bridge proof continue after page 68. No full transport package, intended Bogomolov theorem, or book integration is cleared.
