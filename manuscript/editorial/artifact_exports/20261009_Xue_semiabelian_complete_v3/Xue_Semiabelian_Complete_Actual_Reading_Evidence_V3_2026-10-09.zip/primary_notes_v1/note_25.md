# Actual ordered reading 25 — Xue arXiv v2, physical pages 49–50

Complete selected text and matching displayed image read. Actual coverage now 1–50 of 83.

Section 9.4 now cites the actual published Kühne archimedean coordinate, mixed-measure and difference-map locators. Lemma 79 correctly shifts a canonical toric potential by its critical vector and transports the support from the unit torus to the corresponding positive-radius compact torus. The additive constant has no curvature contribution. Group products and differences act linearly on tropical centers; repeated equal centers cancel under the difference map. 'Haar measure' here must retain geometric mass before normalization: the unnormalized top toric Chern measure has mass E^t, not automatically one (the P1 boundary example has mass two).

Lemma 80 correctly limits the local-chart input to the ARCHIMEDEAN published Kühne Lemma 3.3, rather than the unresolved non-archimedean Theorem 4.1. Toric characters in a cone's dual monoid extend to its affine chart. Their modulus recovers the toric valuation. Independent lattice characters induce a compact-torus submersion, while a full Z-basis gives an isomorphism. Independent nonprimitive characters may have a finite kernel; their lattice-index contribution must be kept in later volume formulas.

Definition 81 chooses r=d-d0 independent characters whose joint map with the abelian projection is generically immersive on X's smooth locus. Chart independence is valid for the JOINT map: a transition can depend on the base, but with the base included its differential is triangular and invertible in the toric component. This does not assert that the toric-coordinate derivative alone is chart independent. The r=0 case gives the empty character tuple and a generically finite abelian projection.

Lemma 82 begins the regularity statement for the associated shifted rank slices; its exceptional-set description and proof continue after page 50. These geometry statements alone do not prove a general-fan curvature/Haar decomposition or eliminate boundary mass. Those remain explicit independent inputs in Theorem 77. No Bogomolov proof clearance or book integration is claimed.
