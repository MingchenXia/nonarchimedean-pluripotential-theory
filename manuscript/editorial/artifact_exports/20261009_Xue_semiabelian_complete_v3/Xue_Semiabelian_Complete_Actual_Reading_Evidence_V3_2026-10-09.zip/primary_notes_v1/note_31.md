# Actual ordered reading 31 — Xue arXiv v2, physical pages 61–62

Complete selected text and matching displayed image read. Actual coverage now 1–62 of 83.

Lemma 92 is a correct torus-level pullback formula: compose the local toric support function with the cocharacter linear map A_beta. When the target critical center is A_beta times the source center, the pullback is in the corresponding quasi-canonical normal form. Products, inversion and adjacent difference maps transport these centers accordingly. This says nothing about the restriction of inactive ambient coordinates to arbitrary X becoming monomial in a chosen active quotient, the issue in Proposition 9.6.

Lemma 93's algebraic character-pushout identities are correct formal consequences of the universal property of extension pushouts: character addition gives tensor product, negation gives the dual, and a semiabelian homomorphism pulls the target bundle back along its abelian map. For the adjacent difference map the character tuple is (m1,m2-m1,...,m_{r-1}-m_{r-2},-m_{r-1}); the displayed tensor factors match those signs. This preserves the actual dual/rigidification conventions. Its theta-source locator references retain the arXiv-versus-journal numbering firewall.

Lemma 94 correctly uses uniqueness of the rigidified canonical Picard-zero metric under the specified multiplication isometries to prove compatibility with pullbacks, tensors and duals. At complex places the known canonical Picard-zero metric is flat and contributes zero Chern curvature. The proof's citation to Proposition 4.24 does not independently clear its earlier raw-theta formula, but the canonical flat-metric statement itself is classical. Archimedean flatness does not force non-archimedean raw period multipliers to have norm one.

The final bookkeeping paragraph explicitly says that the measure pushforward identity is to come from source/target equidistribution of Galois orbit measures, not from the character/flatness identities. That is the right logical distinction. Those source/target smallness and genericity conditions remain to be checked in the following proof pages. No main proof or new result is promoted into the book.
