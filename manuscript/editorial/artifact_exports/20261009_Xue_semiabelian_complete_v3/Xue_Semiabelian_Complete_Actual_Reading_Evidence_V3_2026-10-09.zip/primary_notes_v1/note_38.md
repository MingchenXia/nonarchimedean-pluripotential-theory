# Actual ordered reading 38 — Xue arXiv v2, physical pages 75–76

Complete selected text and matching displayed image read. Actual coverage now 1–76 of 83.

Lemma 114 completes a coherent conditional reduction to a torsion base representative. An ambient-small generic sequence has abelian height tending to zero. Classical abelian Bogomolov identifies its projected closure with a torsion coset; minimality of the subgroup-coset envelope makes its abelian subgroup the entire projected subgroup. Replacing a by a+b then gives torsion pi(a). The decomposition a=q ta is unique for a fixed chosen torsion lift q, rather than canonical independently of q.

Lemma 115's proof does not establish its semiabelian statement: when B has a positive-dimensional abelian quotient, its torus TB is not dense in B, and points of q ta B cannot all be written as q ta iota(s) with s in TB. The calculation correctly treats that torus coset. Extending it to B requires an actual functorial intrinsic semiabelian tropicalization or a compatible canonical-norm construction; 'the same computation in local charts' does not supply that missing argument. No counterexample to an appropriately defined intrinsic valuation is asserted.

Lemma 116's weak probability limit on a closed affine subspace is valid conditional on Lemma 115 and on using a common defining field for the translated envelope. A coset defined only over the algebraic closure need not contain all conjugates taken over the original field. Passing to a suitable finite defining extension, with compatible place and orbit conventions, must be explicit before claiming every orbit is supported on this one affine subspace.

Lemma 117 is the standard normalization-of-subtorus-closure construction when TB is a genuine connected saturated subtorus. Its finite normalization map preserves ampleness, and a distinguished toric eigensection nonzero on the dense torus preserves T-effectivity. The preceding definition TB=B intersect T may include a finite part; its identity component is the torus, while B/TB^0 maps isogenously to pi(B). This finite-kernel issue must be settled before applying the character-lattice and torsor construction. The cited Cox–Little–Schenck section has not been recursively read here. The concluding associated-bundle normalization assertion remains conditional on those choices and the actual translation/torsor morphism.

These are source-audit findings, not a repaired theorem or a new book result. No independent model-verifier verdict, main-theorem counterexample or book integration is claimed.
