# Actual ordered reading 28 — Xue arXiv v2, physical pages 55–56

Complete selected text and matching displayed image read. Actual coverage now 1–56 of 83.

Lemma 88's completion and Proposition 9.2 use the locality of Bedford–Taylor products under an explicit local weight pullback plus a pluriharmonic discrepancy. With the correct Chern-potential sign and genuine corner-active coordinates, that is the right local formal mechanism. A local submersion and equality of weights do not prove all the global covering, lattice or boundary hypotheses of the general-fan decomposition.

Proposition 9.3 invokes the BPS comparison between top toric Chern measure and r! times real Monge–Ampère, including polarized mixed measures. A piecewise affine weight on an r-dimensional quotient has top real Monge–Ampère supported at vertices, hence finite atomic tropical mass when its polyhedral complex is finite. On X of dimension d=r+d0, however, c1(E|X)^r alone is a current rather than a top-degree measure unless d0=0. Its 'toric part' needs the stated local quotient/fiber interpretation and then wedge with the abelian factor. Pulling back an invariant quotient measure gives a local density in quotient coordinates; it does not supply a global compact-torus action or global invariant measure on arbitrary X without the additional gluing/covering conditions.

Lemma 89 correctly pushes a normalized Haar probability to normalized Haar on the IMAGE compact subgroup. It does not assert Haar on the entire ambient target torus when the character map is not surjective. This distinction matters in rank-changing difference maps and in lattice-index normalizations.

Proposition 9.4's matching image retains the outer absolute value around log|psi|+<m,uv>, so the current is the circle-wall current rather than the vanishing dd^c of an affine logarithm. Its positive coefficient has to include the real mixed weight, one-wall half-factor, Chern normalization and relevant lattice determinant. Rank-active and product-corner hypotheses remain essential. Section 9.5 expressly says these three general-fan hypotheses are sufficient for the present proof and are not claimed necessary or minimal; their removal/replacement is left open. Their exact statements continue on page 57, unread at this point.

No unrestricted general-fan decomposition, global phase invariance, main Bogomolov proof clearance or book integration is claimed.
