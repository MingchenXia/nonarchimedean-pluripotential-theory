# Actual ordered reading 22 — Xue arXiv v2, physical pages 43–44

Complete selected text and matching displayed image read. Actual coverage now 1–44 of 83.

Lemma 65 is a correct direct consequence of arithmetic T-effectivity: the placewise supremum bound for the distinguished weight-zero section gives each local roof at zero at least the prescribed constant, their weighted sum is the toric absolute/essential minimum, and zero lies in the polytope by geometric T-effectivity. Thus the global roof attains its maximum at zero. This does not assert that arbitrary geometrically T-effective metrics are arithmetically T-effective.

Definition 66 keeps probabilities with finite first moment and all but finitely many components delta_0. Their weighted barycenters may be nonzero. Lemma 67 rewrites the earlier valuation/height package, so its metric/chart independence and barycenter identification retain the Section 4 theta obligations. Rewriting them in probability notation does not clear them.

Proposition 68 adapts the known toric defect functions to general center c, choosing x=0 in the maximum face so no extra affine pairing with x appears. The centered local dual potentials are nonpositive by Fenchel duality. The sum of their integrals gives the height defect. Since the second local potential is nonpositive, the right-hand defect inequality follows. The left-hand bound begins a sup-convolution/Jensen argument across the other places and continues on page 45. Its center identity c/nv-E[nu_v]=sum_{w!=v}(nw/nv)E[nu_w] is correct.

The displayed uniform center comparison is consistent with the Lipschitz bound for the concave duals: their slopes lie in the compact polytope, so changing the argument by c/nv costs at most RD*||c||/nv. The source imports the zero-defect face/barycenter characterization and the monocritical single-point rigidity from BGPS. The claimed weak-cluster assertion is an imported source theorem, not a newly read proof in this checkpoint. General-center smallness still needs control of the semiabelian abelian heights and centers. No book integration, original theorem or main-proof clearance is claimed.
