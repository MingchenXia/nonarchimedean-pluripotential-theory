from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Xue_semiabelian_review_20261009'
E=R/'manuscript/editorial'
W=Path('/tmp/Xue_semiabelian_primary_views_v1_20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
prep=json.loads((C/'source_preparation_v1_20261009.json').read_text())
assert sha(prep['source']['path'])==prep['source']['SHA256']
assert sha(W/'manifest.json')==prep['manifest_SHA256']
manifest=json.loads((W/'manifest.json').read_text())
receipts=[];pages=[];previous=None
for i in range(1,43):
    note=C/'primary_notes_v1'/('note_%02d.md'%i)
    receipt=note.with_name('note_%02d_receipt.json'%i)
    d=json.loads(receipt.read_text());v=manifest[i-1]
    assert d['view_number']==i==v['number']
    assert d['source_PDF_SHA256']==prep['source']['SHA256']
    assert d['note_SHA256']==sha(note) and d['previous_receipt_SHA256']==previous
    assert d['physical_pages']==v['physical_pages']
    assert d['full_selected_text_read'] and d['matching_rendered_image_displayed_and_read']
    assert sha(d['image_path'])==d['image_SHA256']==v['image_SHA256']
    assert sha(d['selected_text_path'])==d['selected_text_SHA256']==v['selected_text_SHA256']
    pages+=d['physical_pages'];previous=sha(receipt)
    receipts.append(dict(view_number=i,physical_pages=d['physical_pages'],note_path=str(note),note_SHA256=sha(note),receipt_path=str(receipt),receipt_SHA256=sha(receipt)))
assert pages==list(range(1,84)) and prep['source']['physical_pages']==83
old1=C/'source_checkpoint_v1_20261009.json';old2=C/'source_checkpoint_v2_20261009.json'
assert json.loads(old1.read_text())['actual_unique_pages']==list(range(1,21))
assert json.loads(old2.read_text())['actual_unique_pages']==list(range(1,41))
cal1=C/'translated_circle_calibration_v1_20261009.json'
cal2=C/'corner_slice_calibrations_v1_20261009.json'
assert json.loads(cal1.read_text())['normalized_limit_difference']=='1/5'
assert not json.loads(cal2.read_text())['intended_main_theorem_counterexample']
book=R/'manuscript/book.pdf';assert sha(book)=='2c90129c35506ac72005c5189ff235b0e1bd52f5b529ef44e5fc58bf7dbfcfe8'
findings=[
dict(locator='Lemmas 54–56, pp. 38–39; Theorem 61, pp. 41–43',status='LITERAL AUXILIARY ESTIMATES DISPROVED IN KNOWN TORIC MODEL',detail='Same-index translated-circle comparison has normalized limit gap 1/5; the metrized pullback changes D_m to D_mn. Main theorem remains unverified, not refuted.'),
dict(locator='Propositions 90 and 9.5, pp. 57–60',status='LITERAL WHOLE-SLICE FORMULA DISPROVED IN KNOWN TORIC CURVE',detail='The P2 curve (z,1+z) requires actual polyhedral corner domains. Product corners, saturated primitive rank-one normals and zero boundary mass do not supply constant positive whole-slice Haar weights.'),
dict(locator='Proposition 9.6, p. 60',status='OVERBROAD FUNCTORIALITY DISPROVED IN STANDARD MODEL',detail='On the product-boundary curve (z,1+z), beta=z2 pushes a Haar slice to a circle centered at 1; its tropical pushforward is not finite atomic. An ambient monomial need not factor through the active coordinate quotient.'),
dict(locator='Proposition 78, Lemma 101, pp. 70–71',status='FINITE STABILIZER MUST BE RETAINED',detail='Quotienting only by the connected stabilizer leaves a finite part; the graph z2=1+z1² has nontrivial finite stabilizer. Degree-one claims require its treatment.'),
dict(locator='Lemmas 112–117, pp. 74–76',status='RESTRICTION CONSTRUCTION UNVERIFIED',detail='B intersect T may include a finite part. Its identity-component torus quotient maps isogenously to pi(B). The torus is not dense in a semiabelian B with positive abelian quotient, contrary to the proof reduction in Lemma 115.'),
dict(locator='Lemmas 116 and Proposition 118, pp. 75–77',status='FIELD AND METRIZED IDENTIFICATIONS MUST BE SPECIFIED',detail='All orbits must use a common defining field for the coset. Torsion translation preserves heights but need not preserve the literal ample line bundle without a suitable power/rational identification and canonical isometry.'),
dict(locator='Theorems 77, 106 and 129, pp. 48, 72, 81',status='GENERAL-FAN SIGNATURE AND RESTRICTIONS UNVERIFIED',detail='Theorem 106 signature omits the earlier general-fan inputs; final Theorem 129 restores them. The restricted models require their own verified inputs. No arbitrary semipositive metric result is inferred.'),
dict(locator='Propositions 121–126, pp. 78–80',status='BGPS PRIMARY INPUTS PENDING',detail='Verify original normal forms, monocriticality, field extension and simultaneous adelic special-point attainment. Separate-place lattice calculation does not replace the original simultaneous construction.'),
dict(locator='Appendix A, p. 82',status='RESEARCH DIRECTIONS ONLY',detail='Relative toric fiber specialness, global-to-generic-fiber height comparison and function-field descent are proposed ingredients, not proved extensions or new canonical inventory atoms.'),
dict(locator='FRSS arXiv v2 Lemma 4.2, p. 15; Xue Definition 4.21',status='FORMAL-BASE POINT OBJECTION CLEARED IN EXACT SCOPE',detail='Canonical unique-Shilov Raynaud base gives a multiplicative norm. Period-character norms and raw-chart isometries remain unverified; journal numbering is not authenticated by arXiv reading.'),
dict(locator='Kühne published §3–4 and Appendix A; Maillot 4.6.1',status='DEPENDENCY SCOPE PRESERVED',detail='Published Kühne has none of the attributed theta locators. Maillot proves uniform positive approximation with smooth Kahler lower bound, not positive smooth domination of singular original curvature; no logarithmic-tail proof repair.'),
dict(locator='Frozen note 38 and actual bibliography p. 83',status='FRESH BIBLIOGRAPHIC ADDENDUM',detail='Note 42 corrects note 38: reference 20 is Fulton, not Cox–Little–Schenck. Frozen historical note and receipt remain intact.')]
cp=C/'source_checkpoint_v3_20261009.json';assert not cp.exists()
obj=dict(UTC=now(),status='COMPLETE ACTUAL PRIMARY READING — all 83 pages; main proofs UNVERIFIED and unintegrated',exact_version='arXiv:2608.08262v2',source_PDF_SHA256=prep['source']['SHA256'],source_bytes=prep['source']['bytes'],total_physical_pages=83,metadata_pages=82,actual_unique_pages=pages,actual_matching_views=42,unread_pages=[],receipts=receipts,prior_checkpoints=[dict(path=str(p),SHA256=sha(p)) for p in [old1,old2]],prior_checkpoints_preserved=True,findings=findings,earlier_findings_reference='source_checkpoint_v2_20261009.json',calibrations=[dict(path=str(p),SHA256=sha(p)) for p in [cal1,cal2]],mathematical_clearance=False,recursive_dependency_clearance=False,independent_verifier_receipt=False,intended_main_theorem_counterexample=False,complete_proof_repair=False,book_changed=False,canonical_status_changes=[],book_pages=4675,book_PDF_SHA256=sha(book),FRSS_arxiv_actual_pages=21,FRSS_journal_locators_authenticated=False,Kuhne_published_actual_pages=55,Maillot_bounded_actual_pages=5,Maillot_total_physical_pages=130,native_compile_success_verified=False,helper_source=__file__,helper_SHA256=sha(__file__))
cp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
prefix='Xue_semiabelian_complete_source_'
paths={k:E/(prefix+k+'_v3_20261009.'+ext) for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in paths.values())
review='''# Complete actual reading of Xue's semiabelian preprint

Wei Xue, *Equidistribution for semiabelian varieties over number fields*,
arXiv:2608.08262v2, revised 30 August 2026. Exact PDF SHA256:
`fc81cd8cb291fac389bc0bab50e96711240249498bec0ac4be3a90578edd12d5`.
**All 83 physical pages were actually read, in 42 chronological displays
of complete selected text and matching rendered images.** Metadata's
82-page count is not substituted for the downloaded PDF. Full reading
does not clear all proofs. The main results remain **UNVERIFIED** and
have not been integrated into the book.

## Three exact auxiliary calibrations

1. The source's same-index comparison in Lemma 54, Proposition 55 and
   Lemma 56 fails for its permitted translated P1 boundary metric a=2.
   For f(z)=|z|²/(1+|z|²), source probability integral is
   4^n/(1+4^n), target 4/5: the gap tends to **1/5**, not O(1/n).
   The metrized pullback instead changes D_m to D_mn. Theorem 61 uses
   the flagged estimate, so subsequent main proofs are not cleared.
2. For the canonical O(1) metric on P2 restricted to (z,1+z), the local
   psh weight is log max(1,|z|,|1+z|). Product corners, primitive
   saturated rank-one characters and continuous boundary weights hold.
   Curvature on a left unit-circle arc requires a positive e1 term, but
   the entire same Haar slice adds unwanted mass near z=1, where the
   original weight is harmonic. The printed whole-slice formula in
   Propositions 90/9.5 omits the actual polyhedral cell inequalities.
3. On (z,1+z) with the standard product boundary metric, the source
   probability is half Haar on |z|=1 plus half Haar on |1+z|=1.
   The ambient monomial beta=z2 pushes the first part to a circle
   centered at 1, with non-atomic tropical distribution. Proposition
   9.6's general fixed-modulus Haar pushforward conclusion therefore
   needs actual factorization through the active quotient or a more
   general density/support description.

These are known-model audits of **literal auxiliary assertions**. No
counterexample to the intended main equidistribution/Bogomolov statement,
new global proof, priority claim or independent verifier receipt follows.

## Restriction, normalization and dependency boundaries

Quotienting by the connected stabilizer leaves finite stabilizers. Likewise
B intersect T can include a finite part; its identity component is the
torus, and the abelian quotient maps isogenously to pi(B). The proof of
Lemma 115 incorrectly treats this torus as dense in a semiabelian B with
positive-dimensional abelian quotient. A functorial intrinsic norm/tropical
restriction construction must fill that step. Common defining fields are
needed for a single affine envelope to contain every orbit. Torsion
translation preserves Neron–Tate height; literal bundle/metric identities
require compatible power or rational identifications. General-fan inputs
must survive restriction and cannot disappear from Theorem 106's signature.

The earlier conditional arbitrary-affinoid objection is cleared for the
intended formal Raynaud base by the separately read FRSS arXiv Lemma 4.2.
This does not remove period characters or authenticate journal numbering.
All 55 pages of published Kühne were read separately: the attributed theta
locators are absent in that edition. Maillot's Theorem 4.6.1 and full proof
were read on five selected pages of its 130-page PDF; its smooth Kahler
lower bound does not give the stronger printed domination of singular
original curvature in Kühne Appendix A. No logarithmic-tail repair is
claimed. Full original BGPS special-point and field-extension inputs
remain to be checked. Source reference 20 is Fulton; note 42 corrects the
author identification in frozen note 38 by a fresh addendum.

## Related directions and current publication scope

Appendix A proposes relative fiber specialness, a global-to-generic-fiber
height comparison and function-field toric Bogomolov/descent. These are
directions with unresolved signatures, rather than proved extensions.

The active book remains **4,675 pages**. The canonical inventory remains
42 atoms/twelve formal problems, tiers (0,3,7,15,17). BJ22 homogeneous
Siu/general envelopes remain OPEN; LPWZ density remains UNVERIFIED.
The existing catalogue's two arithmetic source questions are separately
published; its native compilation is still unverified. Its editor and
historical PDF are preserved. This is not a new whole-book reread.

The archive contains 99 authored note, receipt, checkpoint, calculation,
preparation-manifest and executed-helper members. It does not redistribute
primary paper PDFs, complete extracted text or rendered images. The old
twenty- and forty-page checkpoints and exports remain frozen. Upload adds
no reading credit.
'''
paths['review'].write_text(review)
notes='# Complete Xue actual reading: all 83 physical pages\n\n'
notes+='Historical notes are frozen; the final note includes the fresh bibliographic correction to note 38.\n\n'
notes+='\n\n---\n\n'.join((C/'primary_notes_v1'/('note_%02d.md'%i)).read_text().rstrip() for i in range(1,43))+'\n'
paths['reading_notes'].write_text(notes)
paths['manifest'].write_text(json.dumps(dict(obj,controlling_source_URL='https://arxiv.org/pdf/2608.08262v2',checkpoint_SHA256=sha(cp),prior_partial_publication='manuscript/editorial/Xue_semiabelian_partial_GitHub_publication_v2_20261009.json',FRSS_publication='manuscript/editorial/Xue_theta_dependency_GitHub_publication_v1_20261009.json',Kuhne_publication='manuscript/editorial/Kuhne_semiabelian_dependency_GitHub_publication_v1_20261009.json'),ensure_ascii=False,indent=2)+'\n')
X=E/'artifact_exports/20261009_Xue_semiabelian_complete_v3';assert not X.exists();X.mkdir()
members={}
for i in range(1,43):
    for suffix in ['.md','_receipt.json']:
        p=C/'primary_notes_v1'/('note_%02d'%i+suffix);members['primary_notes_v1/'+p.name]=p
for name in ['source_acquisition_v1_20261009.json','source_preparation_v1_20261009.json','source_checkpoint_v1_20261009.json','source_checkpoint_v2_20261009.json','source_checkpoint_v3_20261009.json','translated_circle_calibration_v1_20261009.json','corner_slice_calibrations_v1_20261009.json']:
    members['records/'+name]=C/name
members['records/prepared_view_manifest.json']=W/'manifest.json'
for name in ['Xue_semiabelian_acquire_prepare_v1_20261009.py','Xue_semiabelian_record_reading_v1_20261009.py','Xue_semiabelian_checkpoint_v1_20261009.py','Xue_semiabelian_export_partial_evidence_v2_20261009.py','Xue_semiabelian_translated_circle_calibration_v1_20261009.py','Xue_semiabelian_corner_slice_calibrations_v1_20261009.py','Xue_semiabelian_export_complete_evidence_v3_20261009.py']:
    members['executed_helpers/'+name]=Path('/tmp')/name
assert len(members)==99
archive=X/'Xue_Semiabelian_Complete_Actual_Reading_Evidence_V3_2026-10-09.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(members.items()):z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==99
    for name,p in members.items():assert z.read(name)==p.read_bytes()
(X/'README.md').write_text('''# Complete actual Xue reading evidence

All 83 physical pages of arXiv:2608.08262v2 read in 42 chronological
complete-text and matching-image views. Main proofs remain UNVERIFIED.
Three known-model calibrations flag auxiliary assertions, not the intended
main theorems. The 99-member ZIP preserves authored notes, receipts,
records and executed helpers; no primary PDFs, full text or images are
redistributed. Earlier checkpoints and exports remain frozen. Book and
canonical statuses are unchanged. Upload adds zero reading credit.
''')
(X/'SHA256SUMS').write_text(sha(archive)+'  '+archive.name+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=now(),status='EXPORTED — complete actual reading; main proof unverified',archive=str(archive.relative_to(R)),bytes=archive.stat().st_size,SHA256=sha(archive),members=99,actual_Xue_pages=83,total_Xue_pages=83,Xue_views=42,book_changed=False,intended_main_theorem_counterexample=False,independent_verifier_receipt=False,new_reading_credit_for_upload=0),indent=2)+'\n')
update='''
## Complete Xue source audit, 9 October 2026

All **83/83 physical pages** of Xue arXiv:2608.08262v2 are now actually
read in 42 chronological matching text/image displays. Three exact
known-model calibrations flag literal auxiliary transport, whole-slice
and monomial-pushforward assertions; the intended main theorems remain
UNVERIFIED and unintegrated. Finite stabilizers, finite toric intersections,
defining fields and general-fan restriction inputs remain explicit.

See [complete source audit](manuscript/editorial/Xue_semiabelian_complete_source_review_v3_20261009.md)
and [99-member authored evidence](manuscript/editorial/artifact_exports/20261009_Xue_semiabelian_complete_v3/).
Earlier partial checkpoints remain frozen. The **4,675-page book**, its
canonical statuses and the historical catalogue PDF are unchanged.
Native catalogue compilation remains unverified. No new whole-book pass,
main-theorem counterexample or independent verifier receipt is claimed.
'''
readme=R/'README.md';readme.write_text(readme.read_text().rstrip()+'\n'+update)
progress=E/'second_reading_and_research_programme_20261002.md'
progress.write_text(progress.read_text().rstrip()+'\n'+update.replace('(manuscript/editorial/','('))
owned=[*paths.values(),*sorted(X.iterdir()),readme,progress];assert len(owned)==9
out=C/'complete_evidence_export_v3_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=now(),status='READY FOR EXPLICIT NINE-FILE PUBLICATION — complete actual reading',owned_files=[dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,SHA256=sha(p)) for p in owned],archive_members=99,actual_Xue_pages=83,book_changed=False,native_catalogue_changed_by_this_helper=False,helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
print(json.dumps(dict(status='EXPORTED',owned_files=9,archive_members=99,Xue_pages=83,archive_SHA256=sha(archive),export_SHA256=sha(out))))
