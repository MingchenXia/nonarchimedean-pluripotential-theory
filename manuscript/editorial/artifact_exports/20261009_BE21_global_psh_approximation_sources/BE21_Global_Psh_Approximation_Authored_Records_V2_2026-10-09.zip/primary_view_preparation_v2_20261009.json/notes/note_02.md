# BE21 global psh approximation actual primary view 02

UTC: 2026-10-09T01:47:47.644330+00:00. Physical pages: 62, 63.

Read the complete selected text and displayed matching rendered image.

Physical 62–63, printed 61–62, gives complete Lemma 7.4, Corollaries 7.5–7.6, nef definitions and Theorem 7.8 with proof. The triple relation in 7.4 is literally a preorder if distinct triples give the same metric; identifying equivalent triples supplies a directed partially ordered set. Compactness and a strictly positive added margin are the actual ingredients of its Dini argument. This does not provide an unjustified cofinal sequence in a general net.

The continuous global PSH class is the uniform closure of FS metrics with the allowed subgroup convention. The printed converse's claim that every given uniformly convergent sequence admits decreasing constant shifts needs a fast subsequence with summable adjacent errors; that correction has already been diagnosed in the earlier norm-dependency checkpoint. It preserves the closure theorem, and no arbitrary original-sequence shift claim is used.

Nefness is a model numerical condition invariant under different models inducing the same metric, via an earlier cited theorem. Theorem 7.8 requires K nontrivially valued, L ample and the metric continuous; pure FS metrics are semiample models, while a nef model is approximated using an ample model on a dominating projective model and rational epsilon perturbations. The proof first names the ample model A and then writes H, an undeclared symbol; reading H as that ample model restores the typed argument. The last convergence phrase “as epsilon >0” means epsilon tends to zero. Relative ampleness and invariance remain attributed earlier inputs. Remark 7.10 is an expectation for semiample L, with missing Stein descent/local Hodge-index input, not a theorem. Definition 7.11 is smooth-curvature semipositivity, kept separate from global singular FS-psh and nef models. All text and displayed hypotheses are legible.
