# BE21 global psh approximation actual primary view 05

UTC: 2026-10-09T01:50:37.668006+00:00. Physical pages: 68, 69.

Read the complete selected text and displayed matching rendered image.

Physical 68–69, printed 67–68, contains Proposition 7.25, Theorem 7.26, section-norm envelope invariance, the continuity definition and criterion, and Conjecture 7.30. The 7.25 approximants decrease to the competitor psi, not to the obstacle phi as one printed sentence says; the positive-epsilon compactness argument is correct with that variable restored. Lower-semicontinuous obstacle regularization is separate from the upper-semicontinuous regularization of an envelope.

Theorem 7.26 applies to a bounded metric on a semiample Q-line bundle and tensor powers in the globally-generated semigroup N(L). Section-product supnorm submultiplicativity yields superadditive FS metrics and the Fekete limit Q. The normalized sequence need not itself be monotone; uniformity when Q is continuous can use a common-multiple finite-cover approximation and finitely many residue classes, rather than an unjustified direct Dini invocation on the full sequence. Corollary 7.27 preserves norms on reduced sections and handles non-globally-generated m by powers.

Lemma 7.29's printed first opening repeats the continuity hypothesis although that block is supposed to prove the reverse implication from psh closure of upper regularized envelopes. A direct typed proof is available: the assumed closure puts P(phi)-usc in PSH, it remains below continuous phi, hence is at most P(phi); P(phi) is already lsc by 7.25/7.26. Conversely a usc upper envelope has a decreasing continuous-majorant net; continuous P of these majorants decreases to it. This explains the equivalent properties without proving that either holds universally.

Conjecture 7.30 is still presented as a conjecture for normal projective X and semiample L; the next page lists dated known cases. It must not be used as an unconditional arbitrary-field envelope theorem or a repair of BJ22 6.21. The full displayed relations, norms and source references are legible. Earlier net topology, projective geometry and the stated external source results remain attributed.
