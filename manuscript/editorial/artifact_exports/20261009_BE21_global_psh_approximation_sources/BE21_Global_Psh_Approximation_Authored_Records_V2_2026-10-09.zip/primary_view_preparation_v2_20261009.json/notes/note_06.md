# BE21 global psh approximation actual primary view 06

UTC: 2026-10-09T01:51:59.300393+00:00. Physical pages: 70, 71.

Read the complete selected text and displayed matching rendered image.

Physical 70–71, printed 69–70, gives the dated known-envelope cases and complete Theorem 7.31 proof, followed by the fundamental-cycle and zero-dimensional-measure seam. The 2021 list concerns smooth X: curves, discretely/trivially valued residue characteristic zero, and a positive-characteristic function-field case with explicit resolution in dimension n+d. It is not a current exhaustive literature-status claim or an unconditional general envelope theorem.

The field-extension criterion requires projective geometrically reduced X, a continuous metric, semiample Q-line bundle and complete F/K. Pullback of decreasing FS nets gives one direction. Conversely, the psh continuous pullback has uniform FS approximation, and exact FS pullback of the extended original norm plus 1-Lipschitz dependence gives an error at most epsilon_m + m^{-1}d-infinity. Theorem 6.6 makes the second term vanish. This argument does not assume general envelope continuity: the special obstacle on the extension is already continuous psh. No arbitrary local USC descent follows, and geometric reducedness is load-bearing for section norms.

The Section 8 seam retains top-dimensional component multiplicities as generic local-ring lengths. For a finite K-algebra the Dirac weight is dim_K A_i, equal to composition length times residue degree. Real-field measures are explicitly pushed from the complex analytification, a further reminder to keep real/complex evaluation conventions typed. The complete theorem proof, its inequality directions, source references and all seam formulas are legible. This completes twelve selected source pages in six fresh matching displays; seven overlap the three preceding selections and only five new distinct pages are added to their union.
