# BE21 global psh approximation actual primary view 01

UTC: 2026-10-09T01:46:51.832002+00:00. Physical pages: 60, 61.

Read the complete selected text and displayed matching rendered image.

Physical 60–61, printed 59–60, includes the end of Theorem 6.6 and the beginning of the actual Section 7, “Plurisubharmonic metrics and envelopes.” The initial v1 heading/page preflight failed before any views or text were created; v2 uses statement-based guards and includes the true beginning seam. No reading credit attaches to that failure.

The norm proof again has C+2m epsilon followed by the printed epsilon limsup; the corrected 2epsilon has the same vanishing conclusion. Trivially valued cases use Lemma 1.26 for the countable tensor-power norm family and a common complete extension, with two sublinear comparisons rather than exact arbitrary-field equality.

The Archimedean Theorem 7.1 is semiample Q-line bundle on a projective scheme. Its reduction through Stein factorization, connected fibres, Fornaess–Narasimhan, extension to projective space and Demailly/Ohsawa–Takegoshi is explicitly imported; those earlier proofs are not recursively read here. The non-Archimedean Definition 7.2 defines global psh via a decreasing net of FS metrics, with semiample polarization. It does not identify arbitrary local CLD psh with this class. FS weight subgroup density and the Stein/reduction invariance of Lemma 7.3 have their cited earlier inputs. The full text, formulas and hyperlinks are legible; no source theorem is promoted beyond its scope.
