# BE21 global psh approximation actual primary view 04

UTC: 2026-10-09T01:49:32.367990+00:00. Physical pages: 66, 67.

Read the complete selected text and displayed matching rendered image.

Physical 66–67, printed 65–66, proves Theorem 7.16 by the 1-Lipschitz FS estimate and diagonalizable norm density, not by asserting that every norm is itself split. In the non-Archimedean Lemma 7.20, the orthogonal basis must be a basis of the specified normed subspace V; the printed H0(L) would be untyped if V is proper. Scalar-extension and the max formula then give exact FS pullback, while metric-induced section supnorms only have the separate asymptotic comparison from 6.6.

The Archimedean real-field proof's literal equality of real and complex unit-ball evaluation suprema requires further care. At a complex evaluation vector (1,i), the Euclidean real-ball supremum is 1, whereas the Hermitian complex-ball supremum is sqrt(2); similarly real Cauchy–Schwarz alone does not give Lemma 7.17's complex coefficient optimum. The intended conjugation-invariant convention can be implemented by complexifying sections before evaluation, as noted in the prior view, but the literal real-ball step is not accepted as an argument. This observation is confined to the printed Archimedean formulation; the present book comparisons use the explicit non-Archimedean proof.

Definition 7.21 uses sections on Xred, so nilpotent sections are not silently treated as nondegenerate supnorm vectors. Theorem 7.22 asserts the necessary FS fixed-point condition for sufficiently divisible m; its statement is not replaced by an unproved converse. Lemma 7.23 proves FS(phi)<=phi, fixed points for quotient presentations, preservation of the reduced section supnorm and 1-Lipschitz dependence, with the correct norm inequality directions. The two envelopes P and Q are bounded-obstacle pointwise suprema, Q over FS/continuous global psh competitors; Q is lsc and Q<=P<=phi. No general continuity or pshness of their upper regularizations is inferred here. All formulas and seams are legible.
