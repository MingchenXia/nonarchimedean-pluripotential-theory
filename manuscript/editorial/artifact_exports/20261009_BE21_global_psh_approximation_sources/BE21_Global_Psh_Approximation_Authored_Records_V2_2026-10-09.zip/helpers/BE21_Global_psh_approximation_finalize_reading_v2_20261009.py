# Adapted frozen finalizer SHA256: 9448168696b6a84713917dc30c4ef9ef58f4b7046bc42759ff539647705d11d3
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BE21_global_psh_approximation_review_20261009'
out=C/'actual_primary_reading_v2_20261009.json'; assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sets=[('primary_view_preparation_v2_20261009.json',C/'primary_notes_v2')]
views=[];pages=[];pins={};last=None
for name,N in sets:
    p=C/name;prep=json.loads(p.read_text());pins[name]=sha(p)
    assert prep['actual_source_reading_credit']==prep['actually_read_pages']==0
    assert sha(prep['source_PDF']['path'])==prep['source_PDF']['SHA256']
    mp=Path(prep['manifest_path']); assert sha(mp)==prep['manifest_SHA256']
    rows=json.loads(mp.read_text()); assert len(rows)==prep['prepared_views']
    for i,row in enumerate(rows,1):
        receipt=N/f'note_{i:02d}_receipt.json';a=json.loads(receipt.read_text())
        assert a['number']==i and a['physical_pages']==row['physical_pages']
        assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
        assert last is None or a['UTC']>last
        last=a['UTC']
        assert not row['actually_viewed'] and not row['selected_text_read']
        for k,h in [('image_path','image_SHA256'),('selected_text_path','selected_text_SHA256'),('note_path','note_SHA256')]:
            assert sha(a[k])==a[h]
        assert a['source_PDF_SHA256']==prep['source_PDF']['SHA256']==row['source_PDF_SHA256']
        assert 'Read the complete selected text and displayed matching rendered image.' in Path(a['note_path']).read_text()
        views.append(dict(batch=name,**a,observation_receipt_path=str(receipt),observation_receipt_SHA256=sha(receipt)))
        pages.extend(row['physical_pages'])
    for n,h in prep['protected_core_inputs'].items(): assert sha(R/n)==h
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==prep['baseline_commit']
assert len(views)==6 and len(pages)==len(set(pages))==12
previous=R/'source_material/BE21_reduced_fibre_integrability_review_20261009/actual_primary_reading_v1_20261009.json'
prior=json.loads(previous.read_text());old=set(prior['cumulative_distinct_page_list']);new=set(pages)
assert len(old)==53 and old&new=={60,62,63,64,69,70,71} and new-old=={61,65,66,67,68} and len(old|new)==58
d=C/'exact_diagnostics_v2_20261009.json';diag=json.loads(d.read_text())
assert len(diag['families'])==7 and all(a['status'].startswith('PASS') for a in diag['families'])
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — twelve selected primary pages freshly read; partial published PDF',
    source_PDF=prep['source_PDF'],actual_source_unique_pages=12,actual_individually_displayed_matching_views=6,
    selected_physical_pages=sorted(new),views=views,preparation_record_SHA256=pins,
    exact_diagnostics_SHA256=sha(d),previous_partial_reading_record_SHA256=sha(previous),
    new_unique_pages_relative_to_three_prior_checkpoints=5,overlap_pages_freshly_read=sorted(old&new),
    cumulative_distinct_pages_in_four_checkpoints=58,cumulative_distinct_page_list=sorted(old|new),
    remaining_primary_pages_not_read_in_four_checkpoints=67,
    complete_selected_text_read=True,preparation_flags_unchanged=True,whole_primary_PDF_reading_claim=False,
    active_book_changed=False,native_editor_changed=False,book_PDF_SHA256=sha(R/'manuscript/book.pdf'),
    baseline_commit=prep['baseline_commit'],primary_attested_inputs=['Complete Section 7 and proof seams, non-Archimedean FS-psh definition and net closure','Continuous uniform closure with a fast-subsequence proof clarification','Ample nontrivially valued nef-model approximation and semiample expectation','Smooth-max regularizability, norm FS operator, finite norm approximation and exact non-Archimedean FS pullback','Bounded-obstacle Q/P relations and quantitative FS limit, with envelope continuity as a separate hypothesis','Complete non-Archimedean continuous semiample geometrically reduced field-extension criterion'],
    printed_proof_clarifications=['Triple relation is a preorder before quotienting equal metrics','Corollary 7.6 original sequence needs a fast subsequence','Theorem 7.8 H denotes the previously chosen ample model A','Lemma 7.20 orthogonal basis belongs to V rather than arbitrary H0(L)','Proposition 7.25 approximants tend to psi, not obstacle phi','Lemma 7.29 first opening has the wrong hypothesis for the implication proved','Literal real-ball evaluation requires complexification before the Archimedean FS comparison'],
    earlier_inputs_not_recursively_certified=['Demailly/Ohsawa-Takegoshi, Fornaess-Narasimhan and projective psh extension for the Archimedean theorem','Section 1 diagonalization, quotient norms and density foundations','CLD regularized maxima and smooth semipositivity','Model-FS equivalence, nef model invariance, model domination and relative ampleness','Classical compactness/net topology and dated external known envelope-continuity cases'],
    failed_v1_preflight_SHA256=sha(C/'failed_view_preflight_v1_20261009.json'),
    Archimedean_literal_real_ball_argument_accepted=False,
    general_local_weak_psh_or_affine_regularization_admitted=False,general_envelope_theorem_admitted=False,
    canonical_status_changes=[],original_results_promoted=[],independent_model_receipt=None,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],pages=12,views=6,new_distinct_pages=5,cumulative_distinct_pages=58,record_SHA256=sha(out))))
