# Adapted frozen source exporter SHA256: bfe8372c93ec6fcec7bc83b95d7e19dc4e12ec574879a8ff358cc6eeb96e9ffa
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, zipfile

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BE21_global_psh_approximation_review_20261009'
E=R/'manuscript/editorial'
O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
reading=json.loads((C/'actual_primary_reading_v2_20261009.json').read_text())
diag=json.loads((C/'exact_diagnostics_v2_20261009.json').read_text())
assert reading['actual_source_unique_pages']==12 and reading['actual_individually_displayed_matching_views']==6
assert len(diag['families'])==7
for name in reading['preparation_record_SHA256']:
    prep=json.loads((C/name).read_text())
    assert sha(C/name)==reading['preparation_record_SHA256'][name]
    for n,h in prep['protected_core_inputs'].items():assert sha(R/n)==h
paths={k:E/f'BE21_global_psh_approximation_source_{k}_20261009.{ext}' for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
record=C/'source_checkpoint_v2_20261009.json'
owned=O/'BE21_Global_Psh_Approximation_Authored_Records_V2_2026-10-09.zip'
full=O/'BE21_Global_Psh_Approximation_Actual_Source_Evidence_V2_2026-10-09.zip'
dest=E/'artifact_exports/20261009_BE21_global_psh_approximation_sources'
assert not any(p.exists() for p in [*paths.values(),record,owned,full,dest])
draft=Path('/tmp/BE21_Global_psh_approximation_source_review_draft_v2_20261009.md')
paths['review'].write_bytes(draft.read_bytes());assert sha(paths['review'])==sha(draft)
paths['reading_notes'].write_text('# Actual BE21 global psh approximation source notes, 9 October 2026\n\nTwelve selected pages in six fresh matching displays; five new distinct pages relative to three preceding checkpoints.\n'+''.join('\n---\n\n'+Path(v['note_path']).read_text() for v in reading['views']))
files={f'records/{p.name}':p for p in C.glob('*.json')}
for v in reading['views']:
    for k,folder in [('note_path','notes'),('observation_receipt_path','receipts')]:
        p=Path(v[k]);files[f'{v["batch"]}/{folder}/{p.name}']=p
for name in reading['preparation_record_SHA256']:
    p=Path(json.loads((C/name).read_text())['manifest_path']);files[f'manifests/{name}']=p
for p in Path('/tmp').glob('BE21_Global_psh_approximation_*_v*_20261009.py'):files[f'helpers/{p.name}']=p
files[f'drafts/{draft.name}']=draft
for k in ['review','reading_notes']:files[f'editorial/{paths[k].name}']=paths[k]
with zipfile.ZipFile(owned,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,p in sorted(files.items()):z.write(p,n)
with zipfile.ZipFile(owned) as z:
    assert len(z.namelist())==len(files)
    for n,p in files.items():assert z.read(n)==p.read_bytes()
fullfiles=dict(files)
p=Path(reading['source_PDF']['path']);fullfiles['primary/Boucksom_Eriksson_2021_published.pdf']=p
for v in reading['views']:
    for k,folder in [('image_path','images'),('selected_text_path','text')]:
        p=Path(v[k]);fullfiles[f'{v["batch"]}/{folder}/{p.name}']=p
with zipfile.ZipFile(full,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,p in sorted(fullfiles.items()):z.write(p,n)
with zipfile.ZipFile(full) as z:
    assert len(z.namelist())==len(fullfiles)
    for n,p in fullfiles.items():assert z.read(n)==p.read_bytes()
artifacts={k:dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p),members=count) for k,p,count in [('authored_records_archive',owned,len(files)),('cloud_complete_source_evidence_archive',full,len(fullfiles))]}
paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — actual partial primary reading and ordinary source audit',actual_reading=reading,exact_diagnostics=diag,artifacts=artifacts,active_book_changed=False,native_editor_changed=False,GitHub_published=False,canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — byte-verified source exports',artifacts=artifacts,reading_credit_from_export=0,external_primary_PDF_text_images_uploaded=False,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
dest.mkdir(parents=True)
target=dest/owned.name;shutil.copyfile(owned,target);assert sha(target)==sha(owned)
(dest/'SHA256SUMS').write_text(sha(target)+'  '+target.name+'\n')
(dest/'README.md').write_text(f'''# Global psh approximation and field descent primary checkpoint, 9 October 2026

The {len(files)}-member authored archive contains the ordinary source audit,
twelve-page/six-view actual notes and receipts, immutable preparation records,
seven exact elementary diagnostic families and helpers. Only five pages are
new relative to three previous selections. The four-checkpoint union covers
58 distinct pages of the controlling 125-page BE21 PDF, leaving 67 unread.
This is not a whole-paper or new whole-book reading claim.

The audit retains decreasing FS nets, the continuous/global positivity
categories, ample nontrivially valued nef-model approximation, and the
semiample expectation. The printed uniform-sequence shift needs a fast
subsequence. Exact norm-FS extension is distinguished from asymptotic
metric-induced section norms; bounded-obstacle Q limits are distinguished
from general envelope continuity. The continuous semiample geometrically
reduced field-descent proof does not assume universal envelope continuity.
The literal Archimedean real-ball equality requires complexification;
no counterexample to an intended correctly typed theorem is asserted.

The failed v1 heading/page view-preparation preflight created no images,
text or reading credit; it is frozen, and successful fresh v2 completes
all stated observations. External primary PDF/text/images remain in the
separate {len(fullfiles)}-member cloud evidence archive. SHA256SUMS pins the
owned archive. Preparation/export/upload add zero reading credit.

The 4,659-page book, native catalogue/editor and 42 atoms/twelve problems
are unchanged during this source-only checkpoint. General BJ22 critical
homogeneous Siu/envelopes stay OPEN and LPWZ density UNVERIFIED. No original
general theorem or independent-model receipt is claimed. Earlier foundations
remain attributed, not recursively certified. Remote publication receives
its separate later verification record.
''')
readme=R/'README.md';s=readme.read_text();marker='**Latest verified supnorm and logarithmic-integrability GitHub publication, 9 October 2026:**';assert s.count(marker)==1
intro='''**Latest global psh approximation primary checkpoint, 9 October 2026:**
the [source audit](manuscript/editorial/BE21_global_psh_approximation_source_review_20261009.md)
reads twelve selected BE21 pages in six fresh individual matching displays.
It distinguishes global FS nets, ample nef-model approximation, smooth
regularization, exact norm-FS pullback and asymptotic section-norm descent.
Seven elementary diagnostic families retain the printed proof clarifications.
The [authored evidence](manuscript/editorial/artifact_exports/20261009_BE21_global_psh_approximation_sources/README.md)
preserves the zero-credit failed heading preflight and successful fresh v2.
Only five source pages are newly covered; the four-checkpoint union is
58 of 125 pages, still partial. The 4,659-page book, native editor and
canonical statuses are unchanged during this source checkpoint.

''';readme.write_text(s.replace(marker,intro+marker,1))
programme=E/'second_reading_and_research_programme_20261002.md';s=programme.read_text();marker='## Latest supnorm and logarithmic-integrability GitHub publication, 9 October 2026\n';assert s.count(marker)==1
intro='''## Latest global psh approximation source checkpoint, 9 October 2026

The [source audit](BE21_global_psh_approximation_source_review_20261009.md)
freshly reads published BE21 physical 60--71, all of Section 7 and seams:
twelve pages in six individually displayed matching views with complete
text and sequential notes/receipts. Seven overlap the three prior related
selections; five new pages give a four-checkpoint union of 58 of 125,
with 67 unread. Seven exact elementary diagnostic families pass. The first
heading/page preflight failed before creating images or text and remains
frozen with zero reading credit; fresh v2 succeeds.

Global FS-psh is a decreasing-net class. Continuous psh/nef-model equivalence
requires ample polarization and a nontrivially valued field; the merely
semiample extension remains an expectation in the source. Uniform closure
uses a fast subsequence with summable errors rather than a decreasing shift
of every prescribed sequence. Smooth maximum regularization and all earlier
CLD/model/norm foundations retain their separate source scopes.

The bounded-obstacle Q limit is not a general envelope-continuity theorem.
The continuous, semiample, geometrically reduced field-descent criterion
uses exact norm-FS pullback plus the o(m) metric-section-norm estimate.
Its pullback obstacle is already continuous psh, so the proof does not assume
universal envelope continuity. The literal Archimedean real-ball step
requires typed complexification; the book uses the non-Archimedean proof.
No intended correctly typed theorem is refuted.

The [authored archive](artifact_exports/20261009_BE21_global_psh_approximation_sources/README.md)
retains actual notes, receipts, diagnostics, helpers and frozen failure.
External primary PDF/text/images stay in the cloud; export/upload adds zero
reading credit. The 4,659-page book, 425 core TeX inputs, bibliographies,
native catalogue/editor and 42 atoms/twelve problems are unchanged.
General BJ22 critical homogeneous Siu/envelopes stay OPEN, LPWZ density
UNVERIFIED, and the BJ22 6.21 proof warning remains binding. No original
general theorem, independent-model receipt or new whole-book pass is claimed.

Continue cloud-only with recent related primary papers and the remaining
local/global approximation and open-problem interfaces. Integrate useful
qualified explanations only through isolated build and actual rendered-book
gates. Check incoming author updates and periodically push checked evidence.
Xean stays suspended.

''';programme.write_text(s.replace(marker,intro+marker,1))
published=[*paths.values(),*sorted(dest.iterdir()),readme,programme]
assert len(published)==9
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — primary checkpoint and byte-verified authored artifacts exported',
    editorial_files={str(p.relative_to(R)):dict(SHA256=sha(p),bytes=p.stat().st_size) for p in published},
    artifacts=artifacts,actual_primary_pages=12,actual_matching_views=6,new_distinct_pages=5,
    cumulative_distinct_pages_in_four_checkpoints=58,active_book_changed=False,native_editor_changed=False,
    canonical_status_changes=[],GitHub_published=False,helper_source=__file__)
record.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],files=9,owned_members=len(files),cloud_members=len(fullfiles),record_SHA256=sha(record))))
