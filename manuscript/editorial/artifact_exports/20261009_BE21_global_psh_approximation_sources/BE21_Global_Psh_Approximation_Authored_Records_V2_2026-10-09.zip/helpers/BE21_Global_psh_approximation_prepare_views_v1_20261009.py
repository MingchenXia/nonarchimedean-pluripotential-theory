# Adapted frozen primary-view helper SHA256: d1f8014026e92381609afe306b77ff3f6d20659195c901ace464f4fef074c334
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, fitz
from PIL import Image, ImageDraw

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R / 'source_material/BE21_global_psh_approximation_review_20261009'
W = Path('/tmp/BE21_Global_psh_approximation_primary_views_v1_20261009')
N = C / 'primary_notes_v1'
out = C / 'primary_view_preparation_v1_20261009.json'
assert not C.exists() and not W.exists()
pdf = R / 'source_material/Ben_Bassat_harmonic_quiver_dependencies_20261008/Boucksom_Eriksson_2021_published.pdf'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(pdf) == 'f9b8d54cfb2733486f35d450f5f763acf81a51816368ccd2c24c0663845d84f9'
core = json.loads((R / 'source_material/BE21_reduced_fibre_integrability_review_20261009/staging_preparation_v1_20261009.json').read_text())
names = sorted(set(core['other_active_TeX_preserved']) | {n for n in core['after'] if n.endswith('.tex')})
assert len(names) == 425
protected = {n: sha(R / n) for n in names}
for n in ['manuscript/bibliography/ComplexGeometry.bib', 'manuscript/bibliography/NonArchimedean.bib', 'manuscript/book.pdf', 'output/open_problems_catalogue_2026-10-03.tex', 'output/open_problems_catalogue_2026-10-03.pdf', 'README.md', 'manuscript/editorial/second_reading_and_research_programme_20261002.md']:
    protected[n] = sha(R / n)
selected = list(range(61, 72))
with fitz.open(pdf) as doc:
    assert len(doc) == 125
    assert '7. Semipositive metrics' in doc[60].get_text()
    assert 'Theorem 7.31.' in doc[70].get_text()
    C.mkdir(); W.mkdir(); N.mkdir()
    views = []
    for i in range(0, len(selected), 2):
        pages = selected[i:i+2]; panels = []; texts = []
        for n in pages:
            pix = doc[n-1].get_pixmap(matrix=fitz.Matrix(1.45, 1.45), alpha=False)
            panels.append(Image.frombytes('RGB', [pix.width, pix.height], pix.samples))
            texts.append(f'BE21 GLOBAL PSH APPROXIMATION REVIEW PHYSICAL PAGE {n}\n' + doc[n-1].get_text())
        canvas = Image.new('RGB', (sum(p.width for p in panels), max(p.height for p in panels)+28), 'white')
        draw = ImageDraw.Draw(canvas); x = 0
        for n, panel in zip(pages, panels):
            draw.text((x+8, 8), f'BE21 published global psh approximation physical {n}', fill='black')
            canvas.paste(panel, (x, 28)); x += panel.width
        number = i//2+1; ip = W / f'sheet_{number:02d}.png'; tp = W / f'sheet_{number:02d}.txt'
        canvas.save(ip); tp.write_text('\n\n'.join(texts))
        views.append(dict(number=number, physical_pages=pages, path=str(ip), image_SHA256=sha(ip), selected_text_path=str(tp), selected_text_SHA256=sha(tp), source_PDF_SHA256=sha(pdf), actually_viewed=False, selected_text_read=False))
mp = W / 'manifest.json'
mp.write_text(json.dumps(views, ensure_ascii=False, indent=2)+'\n')
obj = dict(UTC=datetime.now(timezone.utc).isoformat(), status='DONE — cached-primary view preparation; zero actual reading credit',
    source_PDF=dict(path=str(pdf), bytes=pdf.stat().st_size, SHA256=sha(pdf), physical_pages=125, printed_article_pages=124, source_reused=True, new_acquisition=False),
    scope='Complete Section 7 global Fubini–Study and psh metrics, nef-model approximation, regularized maxima and field-extension criterion; selected physical pages 61–71',
    selected_physical_pages=selected, prepared_pages=11, prepared_views=6,
    manifest_path=str(mp), manifest_SHA256=sha(mp), protected_core_inputs=protected,
    baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    actual_source_reading_credit=0, actually_read_pages=0, active_book_changed=False,
    native_editor_changed=False, canonical_status_changes=[], helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'], prepared_pages=11, prepared_views=6, preparation_SHA256=sha(out))))
