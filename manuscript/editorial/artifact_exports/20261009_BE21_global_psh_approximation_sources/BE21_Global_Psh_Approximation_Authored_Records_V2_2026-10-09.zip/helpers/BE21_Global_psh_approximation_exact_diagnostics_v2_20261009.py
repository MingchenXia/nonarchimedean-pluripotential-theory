from pathlib import Path
from datetime import datetime,timezone
from fractions import Fraction as F
from itertools import product
import hashlib,json

C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/BE21_global_psh_approximation_review_20261009')
out=C/'exact_diagnostics_v2_20261009.json';assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
families=[]
def add(name,**data):families.append(dict(name=name,status='PASS — exact finite diagnostic and stated elementary argument',**data))
total=F(0)
for i in range(1,129):
 a=F((-1)**i,i);b=F((-1)**(i+1),i+1)
 needed=max(b-a,a-b);assert needed==F(1,i)+F(1,i+1);total+=needed
assert total==2*sum((F(1,i) for i in range(1,129)),F(0))+F(1,129)-1
add('Prescribed uniform sequence cannot always be shifted decreasing',metrics='On two reduced projective points phi_i=((-1)^i/i,-(-1)^i/i)',necessary_shift_difference='c_i-c_{i+1} >= 1/i+1/(i+1)',partial_sum=str(total),proof='Summing gives 2H_N+1/(N+1)-1 tending to infinity; constants tending to zero are impossible.',scope='Known direct diagnostic from the preceding norm-dependency audit, independently rechecked; does not refute uniform closure.')
for k in range(1,129):
 e=F(1,2**k);en=F(1,2**(k+1));c=3*e;cn=3*en;assert c-cn==e+en
add('Fast subsequence and decreasing-constant repair',formula='If ||u_k-u|| <= 2^-k, c_k=3*2^-k gives c_k-c_{k+1}=2^-k+2^-(k+1).',proof='The positive pointwise increment is at most the sum of adjacent errors; shifted subsequence decreases and has the same limit.',scope='Direct elementary proof clarification for Corollary 7.6 and smooth FS regularization.')
assert max(F(2,2),F(2,2))==F(1)
add('Triple order is a preorder before quotienting equal metrics',fixture='The same constant metric can be represented by distinct triples (i,j,m) after offsetting the added 1/m.',proof='Equal represented functions give both alpha>=beta and beta>=alpha; identify equivalent representations to obtain antisymmetry.',scope='Formal notation correction of Lemma 7.4; directedness and the limiting metric remain unchanged.')
a=lambda m:F(m//2,m)
for m,n in product(range(1,41),repeat=2):assert (m+n)//2>=m//2+n//2
assert a(2)==F(1,2)>a(3)==F(1,3)
add('Superadditive averages are not a monotone sequence',sequence='A_m=floor(m/2), so A_{m+n}>=A_m+A_n but A_2/2=1/2>A_3/3=1/3.',proof='The averages converge to 1/2; this shows why superadditivity alone does not justify Dini on the whole normalized sequence.',scope='Arithmetic boundary of the Fekete proof, not a counterexample to Theorem 7.26.')
grid=list(product([F(-1),F(0),F(1)],repeat=2));values=[(F(-2),F(3)),(F(0),F(0)),(None,F(1)),(F(2),None)]
checks=0
for w,u,g in product(grid,grid,values):
 fs=lambda v:max(x-y for x,y in zip(g,v) if x is not None)
 assert abs(fs(w)-fs(u))<=max(abs(x-y) for x,y in zip(w,u));checks+=1
add('FS maximum has the correct signs and 1-Lipschitz bound',formula='FS(alpha)=max_i(g_i-log alpha_i); |FS(alpha)-FS(beta)|<=max_i|log alpha_i-log beta_i|.',finite_cases=checks,scope='Exact diagonal non-Archimedean fixtures with one possible zero section and no common zero; general norm density remains an attributed input.')
for k in range(1,129):
 m=k*k;delta=F(k);epsilon=F(1,k);assert delta/m+epsilon==F(2,k)
add('Global field-extension error vanishes with its separate inputs',fixture='m=k^2, delta_m=k, epsilon_m=1/k gives delta_m/m+epsilon_m=2/k.',proof='For arbitrary data the proof needs delta_m=o(m) and epsilon_m->0 separately. It supplies no uniform convergence rate without further bounds.',scope='Illustration of the quantitative inequality in Theorem 7.31, not a local descent theorem.')
real_gram=((1,0),(0,1));assert real_gram==((1,0),(0,1))
complex_value_squared=F(4,2);assert complex_value_squared==2
add('Literal real-ball evaluation differs from complex Hermitian evaluation',real_fixture='At (1,i), |a+ib|^2=a^2+b^2 for real a,b; on the real Euclidean unit ball the supremum is 1.',complex_fixture='At coefficients (1,-i)/sqrt(2), the Hermitian norm is 1 and evaluation squared is 2; Cauchy-Schwarz bounds it by 2.',conclusion='The printed real-ball equality is not an argument under literal real sections. Complexify before evaluating to obtain the intended conjugation-invariant FS convention.',scope='Literal Archimedean proof-step diagnostic; no counterexample to the intended correctly typed theorem, and no effect on the non-Archimedean max proof.')
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — seven exact elementary approximation and typing diagnostic families',families=families,arithmetic='Exact integers and fractions; real/complex optimum is certified by the explicit quadratic identity and Cauchy-Schwarz.',original_general_theorems_promoted=[],independent_model_receipt=None,book_changed=False,native_editor_changed=False,canonical_status_changes=[],helper_source=dict(path=__file__,SHA256=sha(__file__)))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',families=len(families),record_SHA256=sha(out))))
