from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, fitz
from PIL import Image, ImageDraw
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009/dependencies_v1/BGPS19Published')
W=Path('/tmp/Xue_semiabelian_dependency_views_v1_20261009/BGPS19Published')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
src=json.loads((C/'source_acquisition_v1_20261009.json').read_text())['source']
assert sha(src['path'])==src['SHA256'];doc=fitz.open(src['path'])
read=[]
for i in range(1,11):
    r=json.loads((C/'primary_notes_v1'/('note_%02d_receipt.json'%i)).read_text());read+=r['physical_pages']
assert sorted(read)==list(range(11,17))+list(range(41,55)) and len(read)==20
remaining=[p for p in range(1,75) if p not in read];assert len(remaining)==54
views=[]
for n,start in enumerate(range(0,len(remaining),2),11):
    pages=remaining[start:start+2];imgs=[]
    for p in pages:
        pix=doc[p-1].get_pixmap(matrix=fitz.Matrix(1.3,1.3),alpha=False)
        imgs.append(Image.frombytes('RGB',[pix.width,pix.height],pix.samples))
    canvas=Image.new('RGB',(sum(i.width for i in imgs),max(i.height for i in imgs)+35),'white')
    draw=ImageDraw.Draw(canvas);offset=0
    for p,img in zip(pages,imgs):
        canvas.paste(img,(offset,35));label='publisher cover' if p==1 else 'printed %d'%(p+307)
        draw.text((offset+8,8),'BGPS published 2019: physical %d / %s'%(p,label),fill='black');offset+=img.width
    ip=W/('sheet_%02d.png'%n);tp=W/('sheet_%02d.txt'%n);assert not ip.exists() and not tp.exists()
    canvas.save(ip);tp.write_text('\n\n'.join('BGPS PUBLISHED PHYSICAL PAGE %d\n%s'%(p,doc[p-1].get_text(sort=True)) for p in pages))
    views.append(dict(number=n,physical_pages=pages,path=str(ip),image_SHA256=sha(ip),selected_text_path=str(tp),selected_text_SHA256=sha(tp),source_PDF_SHA256=src['SHA256'],actually_viewed=False,selected_text_read=False))
m=W/'manifest_remaining_v4.json';assert not m.exists();m.write_text(json.dumps(views,indent=2)+'\n')
out=C/'source_preparation_v4_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='REMAINING VIEWS PREPARED — zero new actual reading credit',source=src,prepared_physical_pages=remaining,prepared_views=27,view_numbers=list(range(11,38)),manifest_path=str(m),manifest_SHA256=sha(m),prior_actual_selected_pages=sorted(read),prior_actual_pages=20,prior_checkpoint_SHA256=sha(C/'actual_source_checkpoint_v2_20261009.json'),new_actual_primary_reading_credit=0,book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
print('Prepared remaining 54 pages in 27 views. Actual coverage stays 20/74.')
