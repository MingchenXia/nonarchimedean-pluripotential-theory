from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, sys
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009/dependencies_v1/BGPS19Published')
W=Path('/tmp/Xue_semiabelian_dependency_views_v1_20261009/BGPS19Published')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
n=int(sys.argv[1]);assert 11<=n<=37
prep=json.loads((C/'source_preparation_v4_20261009.json').read_text());m=W/'manifest_remaining_v4.json'
assert sha(m)==prep['manifest_SHA256'];v=json.loads(m.read_text())[n-11];assert v['number']==n
assert sha(prep['source']['path'])==v['source_PDF_SHA256']==prep['source']['SHA256']
assert sha(v['path'])==v['image_SHA256'] and sha(v['selected_text_path'])==v['selected_text_SHA256']
note=C/'primary_notes_v1'/('note_%02d.md'%n);receipt=note.with_name('note_%02d_receipt.json'%n);previous=note.with_name('note_%02d_receipt.json'%(n-1))
assert note.exists() and len(note.read_text())>300 and not receipt.exists()
assert previous.exists() and json.loads(previous.read_text())['view_number']==n-1
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='ACTUALLY READ — complete selected text and matching displayed image',source_key='BGPS19Published',source_PDF_SHA256=v['source_PDF_SHA256'],view_number=n,physical_pages=v['physical_pages'],full_selected_text_read=True,matching_rendered_image_displayed_and_read=True,image_path=v['path'],image_SHA256=v['image_SHA256'],selected_text_path=v['selected_text_path'],selected_text_SHA256=v['selected_text_SHA256'],note_path=str(note),note_SHA256=sha(note),previous_receipt_SHA256=sha(previous),actual_dependency_reading_credit=len(v['physical_pages']),no_other_page_credit=True,no_Xue_page_reading_credit=True,independent_model_verdict=False,book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__))
receipt.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(view=n,pages=v['physical_pages'],receipt_SHA256=sha(receipt))))
