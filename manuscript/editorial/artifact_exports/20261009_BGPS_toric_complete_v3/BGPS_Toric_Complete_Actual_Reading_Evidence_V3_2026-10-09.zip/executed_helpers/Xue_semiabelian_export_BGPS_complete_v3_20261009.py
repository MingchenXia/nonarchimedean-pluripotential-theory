from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile

R=Path('/workspace/nonarchimedean-pluripotential-theory');E=R/'manuscript/editorial'
C=R/'source_material/Xue_semiabelian_review_20261009/dependencies_v1/BGPS19Published'
W=Path('/tmp/Xue_semiabelian_dependency_views_v1_20261009/BGPS19Published')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
src=json.loads((C/'source_acquisition_v1_20261009.json').read_text())['source']
assert sha(src['path'])==src['SHA256'] and Path(src['path']).stat().st_size==src['bytes']
views=[]
manifest_names=['manifest.json','manifest_supplement_v2.json','manifest_height_v3.json','manifest_remaining_v4.json']
for version,name in zip(['v1','v2','v3','v4'],manifest_names):
    prep=json.loads((C/('source_preparation_'+version+'_20261009.json')).read_text())
    assert sha(W/name)==prep['manifest_SHA256']
    views+=json.loads((W/name).read_text())
assert [v['number'] for v in views]==list(range(1,38))
receipts=[];pages=[];previous=None
for i,v in enumerate(views,1):
    p=C/'primary_notes_v1'/('note_%02d.md'%i);r=p.with_name('note_%02d_receipt.json'%i)
    d=json.loads(r.read_text())
    assert d['view_number']==i and d['physical_pages']==v['physical_pages']
    assert d['source_PDF_SHA256']==src['SHA256'] and d['note_SHA256']==sha(p)
    assert d['previous_receipt_SHA256']==previous
    assert d['full_selected_text_read'] and d['matching_rendered_image_displayed_and_read']
    assert sha(d['image_path'])==d['image_SHA256']==v['image_SHA256']
    assert sha(d['selected_text_path'])==d['selected_text_SHA256']==v['selected_text_SHA256']
    pages+=d['physical_pages'];previous=sha(r)
    receipts.append(dict(view_number=i,physical_pages=d['physical_pages'],note_path=str(p),note_SHA256=sha(p),receipt_path=str(r),receipt_SHA256=sha(r)))
assert len(pages)==len(set(pages))==74 and sorted(pages)==list(range(1,75))
candidate=C/'real_quadratic_attainment_candidate_v1_20261009.md'
cal=C/'real_quadratic_attainment_calibration_v1_20261009.json'
assert json.loads(cal.read_text())['full_candidate_SHA256']==sha(candidate)
assert not json.loads(cal.read_text())['production_VERIFIED']
book=R/'manuscript/book.pdf';expected_book='2c90129c35506ac72005c5189ff235b0e1bd52f5b529ef44e5fc58bf7dbfcfe8'
assert sha(book)==expected_book
cp=C/'actual_source_checkpoint_v3_20261009.json';assert not cp.exists()
obj=dict(UTC=now(),status='COMPLETE ACTUAL READING — all 74 physical pages in 37 matching views; not recursive proof clearance',DOI='10.1353/ajm.2019.0007',edition='AJM 141(2), April 2019, 309–381',source_PDF_SHA256=src['SHA256'],source_total_physical_pages=74,actual_pages=sorted(pages),actual_matching_views=37,receipts=receipts,other_page_credit=0,whole_source_read=True,physical_order_reading=False,recursive_inputs_verified=False,candidate_path=str(candidate),candidate_SHA256=sha(candidate),calibration_path=str(cal),calibration_SHA256=sha(cal),candidate_status='ADVERSARIAL RESEARCH CANDIDATE — independent production verification pending',candidate_scope='Separate-place exact point-attainment converse and dependent special-point clauses; not geometric Bogomolov or equidistribution',independent_verifier_receipt=False,production_VERIFIED=False,intended_geometric_Bogomolov_counterexample=False,Xue_main_theorem_counterexample=False,book_changed=False,book_pages=4675,book_PDF_SHA256=expected_book,canonical_status_changes=[],native_compile_success_verified=False,prior_bounded_checkpoint_SHA256=sha(C/'actual_source_checkpoint_v2_20261009.json'),prior_bounded_publication_SHA256=sha(C/'GitHub_bounded_publication_v2_20261009.json'),prior_failed_export_preserved=True,helper_source=__file__,helper_SHA256=sha(__file__))
cp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
prefix='BGPS_toric_complete_source_'
paths={k:E/(prefix+k+'_v3_20261009.'+ext) for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in paths.values())
review='''# Complete published toric-source reading and attainment audit

BGPS, *The distribution of Galois orbits of points of small height in toric
varieties*, American Journal of Mathematics 141(2) (2019), 309–381,
DOI 10.1353/ajm.2019.0007. The exact published PDF is 802,111 bytes,
SHA256 `d8b3f9c9b12d0151502dc5b112b0b57689cce16fbeb34793e8b747d80f66a75e`.
**All 74 physical pages, including the publisher cover, have now been
actually read as complete selected text with matching rendered images,
in 37 chronological displays.** Initial selected batches were out of page
order. The fresh complete checkpoint verifies every note, text, image,
receipt link, and the exact once-only union of physical pages 1–74.
The earlier bounded twenty-page checkpoint and evidence remain frozen.

## Source scope and imported inputs

The reading covers the entire article, not only the attainment statements:
global-field height and measure conventions; convex superdifferentials,
barycenters and weak/KR distinctions; adelic tropical distributions and
monocriticality; generic and strict equidistribution; geometric Bogomolov
and point-attainment clauses; integral-model and Fubini–Study examples;
potential theory, capacity approximation and cross-place phase effects;
all figures and references. It gives no recursive actual-reading credit
to BPS14, BPS15, BMPS16, Bilu, Rumely, Baker–Rumely, or other citations.
**Complete reading is not blanket proof clearance or an independent
production-verifier receipt.**

Theorem 4.19's global KR conclusion uses a weighted global height budget,
centering and coercivity, not merely convergence at individual places.
Theorem 5.2 is read in its big semipositive toric divisor formulation;
Theorem 5.7 explicitly allows R-divisors but is Archimedean over a number
field and assumes strictness against every proper translated subtorus.
Proposition 5.14 uses all places of one common defining extension.
Theorem 5.12's geometric translated-subtorus conclusion has a separate
argument from its additional special-point attainment clause.

The point-distribution density input in Proposition 4.11 is approximation
in global KR topology. It does not supply exact simultaneous realization
of independently prescribed local values. Its displayed outside-S
coupling is compressed and must average over every extension place,
with normalized weights, rather than selecting a single local value.
This is not a claimed counterexample to its density conclusion.

## Exact point-attainment candidate remains unverified

Proposition 5.13 literally assumes u_v belongs to val_v(T(K)) tensor Q
**separately** at every place of the ground number field. The proof's
commensurability claim between independently chosen local valuation
groups and one simultaneous S-unit image is not cleared by Dirichlet's
unit theorem. A complete adversarial candidate over K=Q(sqrt(2)) tests
this distinction for P1 and O(1): u_+=−log 2, u_−=log 2, all finite values
zero, both real weights 1/2, and local translated canonical metrics.
The global roof is zero and the interior superdifferentials give the
monocritical vector u. The separate local witnesses are 2 and 1/2.

The direct all-place height formula is nonnegative. A hypothetical
height-zero torus point alpha over F/K would have all real-conjugate
moduli 2 above the first real place and 1/2 above the other, with all
finite moduli 1. Its norm q in K would have moduli 2^d and 2^(−d).
Since K is real quadratic, the first value forces q=±2^d in K and hence
the same absolute value at the second real place, a contradiction.
Roots of suitable powers of the unit 1+sqrt(2) have heights tending to
zero, giving a generic small subsequence and essential minimum zero.
Boundary point zero is not the torus special-point notion and is not
claimed to have positive height. Abstract energy minimizers need not be
the Galois-orbit distribution of one algebraic point.

Later actual source pages permit finite independent local metric choices
and introduce no hidden global-translation condition excluding this
model. Explicit smooth semipositive approximations also confirm the
metric-admissibility direction. The full dossier and seven illustrative
numeric calculations remain frozen. Numerics are not the norm proof.
**No independent production verifier has returned VERIFIED for this
candidate. It is not a book theorem, verified erratum, priority claim,
or counterexample to geometric Bogomolov, equidistribution, or Xue's
intended main theorem.** The candidate concerns the printed converse,
the extra special-point clause of Theorem 5.12, and Corollary 5.15.
A simultaneous global valuation-span condition is only a repair direction.

## Further full-source diagnostics

The notes distinguish weak probability convergence from finite moments,
require compactness/tightness and full place weights, and retain proper
vs projective and divisor-vs-real-divisor hypotheses. In Example 6.2 the
roof domain is [−1,1], despite a later printed [0,2]. Example 6.3 has a
plateau of roof maximizers and nevertheless is monocritical: uniqueness
of the roof maximizer is not the definition of monocriticality.

Theorem 6.4 and Example 6.5 give a useful ordinary Cartier-divisor case:
standard P1_Q, Fubini–Study at infinity, canonical metrics at all finite
places. Small generic orbits tend to unit-circle Haar at infinity and
Gauss Dirac at finite places, whereas the original Fubini–Study curvature
is smooth area. Modifying finite models can preserve or destroy
monocriticality. This classical example is a potential explanatory book
addition, pending a separate normalization and integration audit.

Propositions 7.3–7.4 construct points in shrinking adelic neighborhoods
and identify equilibrium limits at capacity one; they establish
approximation and do not clear exact point attainment. The phrase
“does not charge singletons” must mean classical type-I points, because
the finite-place equilibrium measure can be a Gauss-point atom.

Proposition 7.5's written cross-place argument needs attention before
reuse. Its capacities c and 1/c give global capacity c^(n_v0−n_v), unless
the unspecified extension equalizes selected local weights or the scale
is compensated. The Archimedean inverse-image display omits the lower
conjugate arc, although Figure 4 correctly shows both. Shrinking
neighborhoods do not give exact zero valuations at the Archimedean
places: uniform annular bounds and limiting KR/product-formula arguments
are needed instead. A later expectation display repeats the wrong place
and omits weights. These are written-proof diagnostics and repair
directions, not verified refutations of the intended proposition.
Theorem 7.2's degree-one divisor statement must not be silently applied
to every higher-degree example without the corresponding reduction.
Remark 7.7 explains a genuine exception to cross-place phase effects
when the tropical fiber is a single type-III point. Historical 2019
open questions, including Remark 5.9, are not asserted open in 2026
without an additional current-literature search.

## Book, catalogue and exported evidence

The active 4,675-page book is unchanged, SHA256
`2c90129c35506ac72005c5189ff235b0e1bd52f5b529ef44e5fc58bf7dbfcfe8`.
Canonical inventory stays 42 atoms in twelve formal problems; no tier or
status changes. General BJ22 Siu/envelopes stay OPEN and LPWZ density
stays UNVERIFIED. Xue remains a complete-source audit with its main
results unverified and unintegrated. The native catalogue's saved source
and historical PDF remain preserved; native compilation is unverified.
This increment is a complete source read, not a new whole-book reread.

The 105-member ZIP contains authored notes/receipts, acquisition and
preparation records, frozen prior checkpoints/publication records,
candidate/calibration, preparation manifests and executed helpers.
It excludes primary PDFs, full extracted text and rendered page images.
The failed first bounded export and all later successful records remain
distinct and frozen. Upload itself grants zero new reading credit.
'''
paths['review'].write_text(review)
notes='# Complete actual published toric-source reading notes\n\nAll 74 physical pages in 37 chronological matching views; no recursive source credit.\n\n'
notes+='\n\n---\n\n'.join((C/'primary_notes_v1'/('note_%02d.md'%i)).read_text().rstrip() for i in range(1,38))
notes+='\n\n---\n\n'+candidate.read_text()
paths['reading_notes'].write_text(notes)
paths['manifest'].write_text(json.dumps(dict(obj,source_URL=json.loads((C/'source_acquisition_v1_20261009.json').read_text())['source_URL'],checkpoint_SHA256=sha(cp)),ensure_ascii=False,indent=2)+'\n')
X=E/'artifact_exports/20261009_BGPS_toric_complete_v3';assert not X.exists();X.mkdir()
members={}
for i in range(1,38):
    for suffix in ['.md','_receipt.json']:
        p=C/'primary_notes_v1'/('note_%02d'%i+suffix);members['primary_notes_v1/'+p.name]=p
records=['source_acquisition_v1_20261009.json']+['source_preparation_'+v+'_20261009.json' for v in ['v1','v2','v3','v4']]
records+=['actual_source_checkpoint_'+v+'_20261009.json' for v in ['v1','v2','v3']]
records+=['bounded_export_failure_v1_20261009.json','real_quadratic_attainment_candidate_v1_20261009.md','real_quadratic_attainment_calibration_v1_20261009.json','bounded_evidence_export_v2_20261009.json','GitHub_bounded_publication_v2_20261009.json','GitHub_bounded_documentation_v2_20261009.json']
for name in records:members['records/'+name]=C/name
for name in manifest_names:members['records/'+name]=W/name
helpers=['Xue_semiabelian_acquire_BGPS_published_v1_20261009.py','Xue_semiabelian_prepare_BGPS_bounded_v1_20261009.py','Xue_semiabelian_prepare_BGPS_supplement_v2_20261009.py','Xue_semiabelian_prepare_BGPS_height_v3_20261009.py','Xue_semiabelian_record_dependency_reading_v1_20261009.py','Xue_semiabelian_record_BGPS_supplement_v2_20261009.py','Xue_semiabelian_record_BGPS_height_v3_20261009.py','Xue_semiabelian_BGPS_real_quadratic_calibration_v1_20261009.py','Xue_semiabelian_export_BGPS_bounded_v1_20261009.py','Xue_semiabelian_export_BGPS_bounded_v2_20261009.py','Xue_semiabelian_prepare_BGPS_remaining_v4_20261009.py','Xue_semiabelian_record_BGPS_remaining_v4_20261009.py','Xue_semiabelian_export_BGPS_complete_v3_20261009.py']
for name in helpers:members['executed_helpers/'+name]=Path('/tmp')/name
assert len(records)==14 and len(members)==105
archive=X/'BGPS_Toric_Complete_Actual_Reading_Evidence_V3_2026-10-09.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(members.items()):z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==105
    for name,p in members.items():assert z.read(name)==p.read_bytes()
(X/'README.md').write_text('''# Complete published toric-source reading evidence

All 74 physical pages were actually read in 37 complete-text and matching-image
views. The 105-member ZIP preserves authored notes, receipts, frozen records,
the unverified real-quadratic attainment candidate, and executed helpers.
No primary PDF, full extracted text or rendered page images are redistributed.
Complete reading is not recursive proof clearance. No independent production
verifier receipt is available; candidate and Xue main results stay unverified.
The 4,675-page book, catalogue/editor and canonical statuses are unchanged.
''')
(X/'SHA256SUMS').write_text(sha(archive)+'  '+archive.name+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=now(),status='EXPORTED — complete original-source reading and unverified attainment candidate',archive=str(archive.relative_to(R)),bytes=archive.stat().st_size,SHA256=sha(archive),members=105,actual_BGPS_pages=74,total_BGPS_pages=74,BGPS_views=37,whole_source_read=True,book_changed=False,independent_verifier_receipt=False,production_VERIFIED=False,new_reading_credit_for_upload=0),indent=2)+'\n')
update='''
## Complete published toric-source reading, 9 October 2026

Read **all 74 physical pages** of published BGPS 2019 in 37 matching displays.
The complete source audit now also covers the density construction, all model
and Fubini–Study examples, potential theory and cross-place phase arguments.
It distinguishes exact point attainment from approximation and preserves
weighted-capacity and neighborhood-estimate diagnostics. The real-quadratic
attainment candidate still has **no independent production-verifier receipt**;
it is not promoted to a book theorem or a verified counterexample to geometric
Bogomolov, equidistribution or Xue's intended main result.

See [complete published-source audit](manuscript/editorial/BGPS_toric_complete_source_review_v3_20261009.md)
and [105-member authored evidence](manuscript/editorial/artifact_exports/20261009_BGPS_toric_complete_v3/).
The **4,675-page book**, canonical 42-atom/twelve-problem inventory, catalogue
source and historical PDF are unchanged; native compilation remains unverified.
The earlier bounded checkpoints and evidence are preserved without rewriting.
'''
readme=R/'README.md';progress=E/'second_reading_and_research_programme_20261002.md'
readme.write_text(readme.read_text().rstrip()+'\n'+update)
progress.write_text(progress.read_text().rstrip()+'\n'+update.replace('(manuscript/editorial/','('))
owned=[*paths.values(),*sorted(X.iterdir()),readme,progress];assert len(owned)==9
out=C/'complete_evidence_export_v3_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=now(),status='READY FOR EXPLICIT NINE-FILE PUBLICATION — complete source reading; candidate unverified',owned_files=[dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,SHA256=sha(p)) for p in owned],archive_members=105,actual_BGPS_pages=74,total_BGPS_pages=74,whole_source_read=True,book_changed=False,independent_verifier_receipt=False,production_VERIFIED=False,helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
print(json.dumps(dict(status='EXPORTED',owned_files=9,archive_members=105,BGPS_pages=74,archive_SHA256=sha(archive),export_SHA256=sha(out))))
