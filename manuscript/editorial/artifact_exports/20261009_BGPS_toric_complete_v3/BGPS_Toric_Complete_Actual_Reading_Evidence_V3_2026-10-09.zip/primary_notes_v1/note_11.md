# Actual BGPS published reading 11 — physical pages 1–2 / cover and printed 309

Complete selected text and matching displayed image read. Actual distinct selected coverage is now 22 of 74 physical pages. The new full-source pass fills the previously unread pages while retaining all earlier selected notes and chronological receipts.

The publisher cover and article first page directly authenticate the controlling edition: American Journal of Mathematics 141(2), April 2019, 309–381, Johns Hopkins University Press, DOI 10.1353/ajm.2019.0007. The source contains one publisher cover plus 73 printed article pages, explaining its 74 physical pages. Received 10 March 2016 and revised 20 June 2018 are article dates, not dates of a 2026 revision.

The abstract distinguishes monocritical equidistribution for generic small points from the geometric Bogomolov property for subvarieties whose essential minimum equals the ambient one. It announces examples of non-monocritical metrics for which geometric Bogomolov fails. It does not supply a new proof of the separate-place special-point condition; the candidate audit of that condition remains separate.

The contents confirm Sections 2–5 as the height, convex, modulus and equidistribution inputs, Section 6 as examples, and Section 7 as potential theory for nonconcentrating limits. The introduction begins the historical abelian small-point motivation. Preparing the remaining 54 pages granted no actual credit; only this complete display and note adds these two pages. No new whole-book pass, recursive clearance or production verifier verdict is claimed.
