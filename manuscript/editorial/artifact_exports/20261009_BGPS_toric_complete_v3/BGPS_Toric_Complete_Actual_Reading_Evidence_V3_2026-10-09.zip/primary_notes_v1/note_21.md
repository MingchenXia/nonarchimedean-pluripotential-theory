# Actual BGPS published reading 21 — physical pages 27–28 / printed 334–335

Complete selected text and matching displayed image read. Actual distinct selected coverage is now 42 of 74 physical pages.

Lemma 3.10 completes its coercivity proof using a dual-norm closed ball about an interior polytope point. Psi(u)<=<u,x>-c2*norm(u), with c2>0. The two linear terms cancel through the expectation, while the remaining support-function deficit is nonpositive. This correctly supplies a uniform first-moment bound on a near-zero Phi tail.

Proposition 3.11 obtains probability cluster points by that first-moment bound, Markov tightness, lower semicontinuity of the moment and Prokhorov compactness. The moment-bounded set is compact in weak probability topology; it is not asserted compact in KR topology. Upper semicontinuity of Phi then forces every cluster point to have zero deficit and the face/barycenter signature. For a net, discard an eventual tail where Phi>=-1; choosing an arbitrary subnet would not justify a claim about every original cluster point. The eventual-tail version is sufficient and follows from the given convergence.

Definition 3.12 is Wasserstein order one on finite-first-moment probabilities, with transport cost the chosen norm. The product coupling makes its finiteness explicit. Lipschitz test bounds control differences of their integrals, and Remark 3.13 identifies its stronger topology with continuous linear-growth tests. This is the topology used later for height continuity and adelic convergence, rather than bounded-continuous weak convergence alone.

These checked compactness and moment facts are known analytic inputs. The candidate about simultaneous algebraic attainment remains a distinct arithmetic issue. No new book result or independent verifier verdict is claimed.
