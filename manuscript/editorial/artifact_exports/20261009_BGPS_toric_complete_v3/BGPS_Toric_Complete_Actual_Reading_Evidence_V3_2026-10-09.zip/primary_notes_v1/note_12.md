# Actual BGPS published reading 12 — physical pages 3–4 / printed 310–311

Complete selected text and matching displayed image read. Actual distinct selected coverage is now 24 of 74 physical pages.

The introduction places classical SUZ, Bilu, Chambert-Loir, Yuan and related equidistribution under Zhang-equality/quasi-canonical assumptions, then motivates the wider toric classification. The claim about then-available methods is historical 2019 context; the separately read 2026 Ballaÿ–Sombra approximation criterion has since extended the non-quasi-canonical arithmetic picture. No historical sentence is promoted to a present-day limitation.

The source defines the general signature as a proper algebraic variety over a global field, semipositive metrized Cartier divisor and big underlying geometry. It separates quasi-canonicity, expressed by essential minimum equal to h_D(X)/((n+1)deg_D(X)), from point attainment. The former is an equality of a generic infimum and a normalized intersection, and does not itself assert a minimum in the principal torus. Thus that definition does not supply a missing simultaneous algebraic realization in the candidate audit.

The probability normalization of Galois orbits and the geometric mass of the local Monge–Ampere measure are explicit: orbit probability has total mass one, while c1(D)^n has mass deg_D(X). Any normalized limiting Chern measure divides by that positive geometric degree. The spaces of adelic measures in the proof are not compact; the source motivates several topologies precisely to address that issue.

The non-monocritical examples and cluster-measure classification are announced but not yet read in full. No arbitrary semiabelian extension or current unresolved question is inferred from this introduction. Book and candidate verification statuses are unchanged.
