# Actual BGPS published reading 13 — physical pages 5–6 / printed 312–313

Complete selected text and matching displayed image read. Actual distinct selected coverage is now 26 of 74 physical pages.

The introductory classical equidistribution theorem retains projectivity, an ample underlying divisor, semipositivity, quasi-canonicity and generic small nets. Its limit is the normalized local Chern probability. These signatures are stronger than proper/big toric geometry and are used after passing to an ample normal-fan model; an arbitrary proper model is not silently substituted in the imported classical statement.

The toric metric dictionary is explicit: psi_v is log norm of the distinguished toric section evaluated at the valuation vector (-log absolute values), local roofs are its concave Legendre–Fenchel duals, each psi_v differs boundedly from the support function, and all but finitely many are canonical. The real-quadratic candidate's psi_v=min(0,t-u_v) and g_v=-psi_v(-log|z|) match these signs. Its roofs x*u_v sum to zero with the actual weights, so the source's cited essential-minimum formula gives zero independently of the dossier's explicit generic unit-root approximation. No finite-place height contribution is discarded when testing arbitrary alpha.

The introduction defines monocriticality using uniqueness of a minimizing measure of the adelic height functional, not the existence of an algebraic point attaining that energy. Its measure space contains more than Galois-orbit measures of individual algebraic points. This distinction supports the need to audit the later attainment converse separately; it does not settle that converse by itself.

No newer source version, independent model verdict, whole-paper proof clearance or book change is claimed. The frozen candidate and its publication remain unchanged.
