# Actual BGPS published reading 17 — physical pages 19–20 / printed 326–327

Complete selected text and matching displayed image read. Actual distinct selected coverage is now 34 of 74 physical pages.

Theorem 2.11 finishes the normalized Chern-limit assertion and attributes it precisely to Yuan over number fields and Gubler, with its own more general signature, over function fields. These remain imported primary inputs rather than proofs recursively supplied by the toric paper. Non-quasi-canonical limits can differ from the original normalized Chern measure; the article's purpose is not to drop every positivity or genericity condition.

Section 3 uses finite-dimensional dual real vector spaces, compact nonempty convex domains and continuous concave functions. Its Legendre–Fenchel transform uses an infimum, and its sup-differential inequality is g(z)-g(x)<=<u,z-x>. These conventions match the candidate's concave metric/roof calculation and the sign used in the global coercivity proof. Relative interior, not ambient interior of a lower-dimensional domain, is the relevant notion.

Lemma 3.1 begins the two-function maximal-face calculation: their restrictions to the maximizer set are affine with opposite slopes. The local deficit phi_i(u)=g_i^vee(u)-<x,u>+g_i(x) is nonpositive and vanishes exactly on the appropriate sup-differential. The proof begins its face comparison by extending a segment slightly beyond a relative-interior maximizer, rather than assuming every boundary maximizer is interior. It continues on the next view. In reuse, faces are convex faces; a segment-absorption condition alone should not accidentally license a nonconvex union of extreme points.

This convex background supplies no extra arithmetic constraint making independent place values simultaneous. No promotion or book integration is claimed.
