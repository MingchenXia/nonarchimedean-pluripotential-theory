# Actual BGPS published reading 26 — physical pages 37–38 / printed 344–345

Complete selected text and matching displayed image read. Actual distinct selected coverage is now 52 of 74 physical pages.

Corollary 4.10's proof uses the convex sum rule to choose a centered vector of local sup-gradients, then applies Lemma 4.8 to its Dirac family. It constructs an abstract minimizing family, without asserting that it is the orbit distribution of one algebraic point.

Proposition 4.11's density construction is read through its final genericity step, continued next. Approximate each local probability by equally weighted atoms, correct the last atom to preserve its expectation exactly, then choose a degree-d extension completely split at the selected places. The source imports BPS15 Lemmas 2.2 and 2.3 for that extension and **density** of the rational simultaneous valuation image in the centered real space. Density is not equality of its rational image with the product of separate-place valuation groups. This does not remove the candidate's exact-attainment obstruction.

For places in S the explicit coupling pairs each atom with its corresponding split place, and the roots' additional conjugates have the same modulus. Outside S, a general alpha in F may have different valuations at different places over v. The printed single Dirac coupling/val_v(alpha^r) notation is too compressed to represent that full orbit marginal without an extra equal-valuation hypothesis. An expanded coupling uses delta_0 tensor nu_{p,v} there and the actual weighted sum over all F-places, n_w= n_v*[F_w:K_v]/[F:K]. This is the ordinary correct all-place expression underlying the L1 bound, not a proof that every v outside S has one scalar valuation or that no extra finite places contribute. The weighted L1 approximation remains the relevant imported input.

Torsion translates preserve every valuation distribution and give a dense algebraic orbit, allowing prescribed nonempty opens. This supplies genericity without claiming the torsion translates form a strict sequence. Full source-dependency clearance, a repaired arithmetic theorem and an independent VERIFIED result are not claimed.
