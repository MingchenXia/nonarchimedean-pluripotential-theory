# Actual BGPS published reading 24 — physical pages 33–34 / printed 340–341

Complete selected text and matching displayed image read. Actual distinct selected coverage is now 48 of 74 physical pages.

Theorem 4.3's modulus cluster signature is stated for all small nets in the principal torus, without genericity. Definition 4.4 requires a finite-support family of finite-first-moment probabilities, centered by the weighted sum of expectations. It is an abstract measure space, not a collection restricted to the orbit measures of individual algebraic points. The extended height eta_D=-sum_v n_v integral psi_v exactly agrees with the height of an algebraic point through the full Galois average and product formula.

Lemma 4.5 uses the correct normalized defect eta_D-mu_ess, resolving the introductory shorthand noted in note 15. Its inequalities place max_v(-n_v Phi_v) below that global defect, and the sum of the nonnegative local deficits above it. Centering cancels the linear supergradient term. The right inequality follows from Phi_v<=integral phi1,v. The proof of the left inequality starts the weighted sup-convolution formula and continues on page 35.

Both estimates retain every place weight, finite metric support and finite moments; no indefinite difference of infinite energies is formed. For a small net, the global nonnegative defect tending to zero will force each local Phi_v to zero. Conversely, a bounded set of selected local limits alone need not control every place in the global sum.

The exact abstract space confirms that a unique energy-minimizing Dirac family can exist before an algebraic point realizes that entire family. The real-quadratic candidate still has no independent production-verifier receipt, and no book changes occur.
