# Actual BGPS published reading 27 — physical pages 39–40 / printed 346–347

Complete selected text and matching displayed image read. Actual distinct selected coverage is now 54 of 74 physical pages: all physical 1–54 are read, although the chronological views first covered the selected theorem range. The twenty-page checkpoint remains frozen and accurately scoped to its earlier date.

Proposition 4.11 ends by prescribing a nonempty open and using dense torsion translates to obtain a generic net while preserving valuation measures. The zero-dimensional case needs the direct point construction rather than the displayed division by a hypersurface-component count. Theorem 4.7 then uses Lipschitz height continuity to turn strong adelic approximation of a minimizing family into generic smallness. No exact algebraic attainment is asserted by this density result.

Corollary 4.12 completes one local zero-defect measure to a centered adelic minimizing family via the weighted roof sup-differential sum. A finite-support choice is made using the finitely many nonzero roofs, with zeros elsewhere; the fixed local measure's expectation is retained. This is stronger than choosing unrelated individual small nets at every place, and does not imply exact simultaneous local-value realization by one point.

Corollary 4.13 gives equivalence of all-small modulus convergence in bounded-continuous probability topology, generic-small convergence in compact-support test topology, and singleton F_v. To disprove universal convergence when F_v is not singleton, choose a barycenter in B_v in the relative interior of its minimal face and two distinct symmetric points in that face. The two finite probabilities have distinct limits and can be interlaced on a product directed set. This is a nonconverging generic small net, not an illicit replacement of nets by sequences over arbitrary global fields.

Together with the actually read following pages, Section 4's printed statements and proofs are now covered. Recursive arithmetic-density and convex source inputs remain imported. The special-point candidate remains independently unverified, and the book remains unchanged.
