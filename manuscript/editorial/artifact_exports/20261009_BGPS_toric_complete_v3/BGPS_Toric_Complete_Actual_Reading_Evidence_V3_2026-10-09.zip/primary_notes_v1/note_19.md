# Actual BGPS published reading 19 — physical pages 23–24 / printed 330–331

Complete selected text and matching displayed image read. Actual distinct selected coverage is now 38 of 74 physical pages.

Proposition 3.5 treats finite-first-moment probabilities in finite-dimensional Euclidean space. Its barycenter lies in the convex hull of the support, with separation followed by restriction to an affine hyperplane if necessary; finite-support probabilities are dense by truncating and discretizing. Convex hull, closed convex hull and relative interior must retain their correct roles in a rewritten proof, rather than applying strict separation to a nonclosed set without qualification. The stated finite-dimensional barycenter conclusion has the familiar supporting-hyperplane proof.

For the remainder of Section 3, the source explicitly restores full-dimensional compact C and continuous concave g1,g2. Phi is the integral of one concave conjugate plus the other at minus the barycenter, corrected by the maximum of their sum. Example 3.6 gives a direct weak-moment failure: (1-1/l)delta_0+(1/l)delta_{-l} converges weakly to delta_0, while Phi remains -1 rather than approaching zero. This is the precise reason not to infer unbounded-test convergence from weak convergence.

Lemma 3.8's bounded-above/below integral semicontinuity is a standard truncation statement. For a value -infinity the printed epsilon comparison should be expressed using arbitrary finite upper thresholds, not '-infinity plus epsilon'; the conclusion remains the standard extended-valued semicontinuity. The use of sequences is appropriate in the metrizable probability space defined earlier. Proposition 3.7 begins its upper semicontinuity proof by choosing a supergradient of the finite concave conjugate at the negative expectation; this avoids assuming weak continuity of expectation and continues on page 25.

These functional-analytic scope checks do not remove the independent arithmetic attainment issue. No new theorem, whole-source clearance or book insertion is claimed.
