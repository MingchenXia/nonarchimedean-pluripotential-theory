# Actual BGPS published reading 28 — physical pages 55–56 / printed 362–363

Complete selected text and matching displayed image read. Actual distinct selected coverage is now 56 of 74 physical pages.

Section 6 begins by recalling canonical toric metrics: full-dimensional Delta and zero roofs give singleton local faces and monocriticality. When quoting its equidistribution conclusion for arbitrary real coefficients, retain the previously checked theorem scope; Theorem 5.2 itself was stated for a Cartier divisor, while specific R-divisor extensions need their own inputs.

The paragraph realizing every lambda_v-rational piecewise-affine metric as an exact K-toric morphism pullback of the canonical O(1) metric is too compressed for reuse: fractional slopes require clearing denominators and rescaling the pulled-back bundle, and coefficients must realize the desired logarithmic constants over the actual field. At an archimedean place arbitrary rational intercepts with lambda_v=1 do not automatically come from algebraic coefficient logarithms. The broad local concave-metric dictionary on pages 31–32, not this exact morphism assertion, supplies the candidate's admissibility framework. No claim is made that this paragraph repairs the simultaneous attainment issue.

Example 6.1's actual explicit map is (1:t/2:t), whose closure normalization is P1. Its local roof at 2 is x*log(2), with other roofs zero; the global maximum is at x=1 and equals log(2). The local minimal faces are non-singleton half-lines, with bounded B_2=[0,log(2)] and B_v=[-log(2),0] elsewhere. Hence modulus concentration fails at every place for the restricted metric, despite the original ambient canonical metric being monocritical.

Two generic small sequences are written using primitive roots of unity and a fixed root of a prime a different from 2. Their full-height and measure comparison continues on page 57. The example will be checked with all finite contributions rather than concluding from the archimedean radius alone. No book change or independent verifier receipt is claimed.
