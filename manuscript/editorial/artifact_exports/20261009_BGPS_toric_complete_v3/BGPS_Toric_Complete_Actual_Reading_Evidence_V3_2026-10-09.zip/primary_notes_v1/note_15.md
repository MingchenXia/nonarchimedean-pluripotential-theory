# Actual BGPS published reading 15 — physical pages 9–10 / printed 316–317

Complete selected text and matching displayed image read. Actual distinct selected coverage is now 30 of 74 physical pages.

The introduction completes the local modulus cluster/realizability statement with support in F_v and expectation in B_v. The genericity requirement of full Galois-orbit equidistribution is not present in modulus concentration for small nets. Replacing the metric by the quasi-canonical centered one is explicitly the bridge from that concentration to the classical theorem; this is a toric construction, not an arbitrary semiabelian descent argument.

The sentence saying the extended height functional eta_D 'vanishes' when the local auxiliary functions vanish requires normalization by the essential minimum. In general the minimum energy is mu_ess, which can be nonzero under a constant metric shift; the substantive later statements in Section 4 will be checked in their exact normalization. No argument in the candidate relies on that introductory wording; its energy and essential minimum are explicitly zero.

Theorem 1.4 visibly repeats the additional special-point clause from Theorem 5.12, using separate-place ground-field rationalized valuation membership. Nothing in this introductory statement adds simultaneous S-unit membership. The candidate remains directed at that additional clause and Proposition 5.13's converse, not at the independent geometric translated-subtorus assertion.

The historical questions distinguish all-place equidistribution from one-place equidistribution and ask whether geometric Bogomolov implies monocriticality in dimension at least two. Proposition 7.5, Remark 7.7 and Proposition 6.7 supply specific partial answers later in the article. They are not newly entered into the canonical 42-atom list or described as current 2026 open questions without checking those sections and subsequent primary literature. Section 7's Fekete–Szego construction is a capacity theorem input still unread.

No original result is independently VERIFIED or integrated in the book by this reading.
