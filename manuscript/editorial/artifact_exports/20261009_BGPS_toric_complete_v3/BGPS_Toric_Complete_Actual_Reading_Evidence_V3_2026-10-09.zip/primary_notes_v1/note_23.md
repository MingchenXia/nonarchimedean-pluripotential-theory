# Actual BGPS published reading 23 — physical pages 31–32 / printed 338–339

Complete selected text and matching displayed image read. Actual distinct selected coverage is now 46 of 74 physical pages.

The exact Section 4 dictionary confirms nef geometry as concave support function and bigness as full-dimensional polytope. A quasi-algebraic toric metric is encoded by continuous psi_v with bounded difference from that support function, canonical outside finitely many places; concavity is the semipositivity condition. The stated converse imports BMPS16 Proposition 4.19(1). In the candidate the psi_v are concave translates of min(0,t), differ boundedly from it, and are canonical at all finite places. No hidden requirement here forces both real places to be modified by the same global algebraic translation. The direct smooth approximation in note 16 also checks the actual local positivity definition.

The local/global roof construction and the source's BPS15 essential-minimum formula use the weighted sum of local roofs. The candidate's two opposite real linear roofs cancel, so the global roof is zero and the model fits the actual source signature. Its separate witnesses 2 and 1/2 still fail the simultaneous norm condition; this reading adds a fresh admissibility attestation without rewriting the frozen candidate.

Notation 4.2 defines g2,v using the ratio n_w/n_v, not unweighted other-place roofs. Thus n_v*(g1,v+g2,v) is the same global roof at every v. B_v, F_v, A_v and Phi_v are taken with the relative interior of the roof-maximizer set, and the local Galois-valuation distribution is a discrete probability. Omitting these weights or confusing A_v with its minimal face F_v would change the cluster criterion.

All canonical-metric and toric semipositivity source references remain imported unless separately read. No candidate is production VERIFIED, and no book content changes.
