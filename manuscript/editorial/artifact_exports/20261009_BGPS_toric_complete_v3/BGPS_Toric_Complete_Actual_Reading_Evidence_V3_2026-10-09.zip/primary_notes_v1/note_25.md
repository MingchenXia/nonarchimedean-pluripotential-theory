# Actual BGPS published reading 25 — physical pages 35–36 / printed 342–343

Complete selected text and matching displayed image read. Actual distinct selected coverage is now 50 of 74 physical pages.

Lemma 4.5 completes the lower local-defect estimate using weighted sup-convolution and Jensen's inequality, with centering supplying the admissible expectation decomposition. Theorem 4.3 then follows from Phi_v<=0, the global small-height defect tending to zero and the earlier compactness result. This gives actual probability cluster measures with first moments; it does not infer mass preservation from vague compactness.

Definition 4.6's adelic KR distance is sum_v n_v W, a finite sum for each pair of the finite-support centered families defined earlier. Theorem 4.7 states approximation of any zero-defect such family by a generic small net in the **strong adelic KR** topology; its construction is not yet read. Approximate realization of a family is distinct from one algebraic point exactly attaining all its coordinates. Density cannot replace rational simultaneous membership in the special-point converse.

Lemma 4.8's complete proof gives a uniform Lipschitz bound from the bounded polytope, independent of the place, and characterizes minimizing families by all local support/expectation conditions. Corollary 4.9 correctly applies that characterization to an algebraic point's actual orbit distributions. Under monocriticality these distributions must be Dirac at u_v, so every conjugate must have the same valuation. This is exactly the all-conjugate input used in Proposition 5.13's necessity and in the candidate's norm obstruction.

Corollary 4.10 asserts attainment of the extended functional by a centered vector/Dirac family in the abstract measure space. Its proof continues on page 37. It does not assert attainment by a torus algebraic point. No book result or independently verified source counterexample is claimed.
