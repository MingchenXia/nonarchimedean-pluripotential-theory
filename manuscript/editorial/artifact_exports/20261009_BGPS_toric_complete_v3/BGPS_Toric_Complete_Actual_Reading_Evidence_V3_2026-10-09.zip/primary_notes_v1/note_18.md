# Actual BGPS published reading 18 — physical pages 21–22 / printed 328–329

Complete selected text and matching displayed image read. Actual distinct selected coverage is now 36 of 74 physical pages.

Lemma 3.1's proof finishes by the sup-differential sum rule, maximal-set affine identities and the minimal-face comparison. Its imported convex rules are BPS14 2.2.8, 2.3.6(2) and 2.2.6. Definition 3.2 names B as the common opposite-gradient intersection and F as its containing minimal face, both independent of the chosen maximizer. The definition retains continuous concave functions on a compact nonempty convex domain.

Lemma 3.3 bounds B and excludes lines in F by letting a ray/line parameter diverge in the gradient inequalities. Full-dimensionality of C then contradicts the forced hyperplane containment. Reuse must retain the preceding continuity/maximizer-existence setting even though the short lemma signature only says 'concave functions': a finite concave function with a downward boundary jump on a compact interval need not attain its supremum. Restricting to the affine hull is necessary for lower-dimensional C, where annihilator lines can otherwise appear. These are hypothesis-scope cautions, not a new claim about the paper's actual toric continuous roofs.

Definition 3.4 uses Borel probability measures with bounded-continuous weak topology and its finite-first-moment subspace. Expectation is the vector integral and is defined only in that subspace. The full probability space is Polish with an appropriate compatible complete metric; this does not say the inherited topology makes the finite-first-moment subspace complete or that expectations are weakly continuous there. Later KR topology is needed for first moments.

The convex and probability ingredients introduce no additional simultaneous arithmetic realization condition. No source candidate or book theorem gains an independent VERIFIED verdict from this reading.
