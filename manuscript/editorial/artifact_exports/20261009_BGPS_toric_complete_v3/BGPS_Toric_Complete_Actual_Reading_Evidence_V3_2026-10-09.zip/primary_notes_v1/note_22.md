# Actual BGPS published reading 22 — physical pages 29–30 / printed 336–337

Complete selected text and matching displayed image read. Actual distinct selected coverage is now 44 of 74 physical pages.

Proposition 3.14's complete proof gives KR continuity of Phi through continuous linear-growth test integrals and continuity of the conjugate at the converging expectations. This is stronger than the weak upper semicontinuity used for compactness. It does not infer first-moment convergence from a uniform bound alone.

Lemma 3.15's complete finite Minkowski-sum proof is now read. A vertex of the sum has one decomposition, whose components are vertices; conversely those two properties force a vertex of the sum. The argument exchanges one component between two decompositions, then applies extremality. It works for finite nonempty convex sets without compactness or polyhedrality; 'vertex' is the extreme-point condition used in the proof. Positive weights in the later sup-differential sum can be absorbed into the summands. This is the previously imported ingredient behind Proposition 4.16, with no arithmetic realization assertion.

Section 4 begins with a split torus, the character/cocharacter lattices and the intrinsic valuation to N_R. Its coordinate formula (-log absolute values) is independent of a splitting when interpreted in the lattice, and its zero fiber is the maximal compact analytic torus. Complete fan, open principal orbit and invariant real Cartier divisors are fixed before support functions are introduced. In the non-archimedean case the phrase analytic group refers to the analytic group object; it should not be rewritten as a naive pointwise topological group law on arbitrary Berkovich points.

The next support-function and metric definitions will be checked directly. No special-point candidate or book content is promoted by this read.
