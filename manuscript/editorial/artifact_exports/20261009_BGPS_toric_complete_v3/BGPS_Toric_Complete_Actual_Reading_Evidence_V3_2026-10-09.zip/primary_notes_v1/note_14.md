# Actual BGPS published reading 14 — physical pages 7–8 / printed 314–315

Complete selected text and matching displayed image read. Actual distinct selected coverage is now 28 of 74 physical pages.

Theorem 1.1 repeats the proper/big semipositive toric Cartier-divisor equidistribution equivalence, while Corollary 1.2 visibly permits an R-divisor over Q with smooth positive archimedean and canonical finite-place metrics. The latter invokes the later special-case theorem rather than deleting the coefficient restriction of Theorem 5.2. A critical point is centered; its unique adelic minimizing measure need not be the orbit of an individual algebraic point.

The Fubini–Study P1 example has essential minimum log(2)/2 and limiting Haar probability on the unit circle at infinity, although its original smooth Chern measure is not that circle measure. This is a useful prospective explanatory bridge for the book's arithmetic differentiability paragraph. It requires reading the complete Example 6.5 and its Theorem 6.4 input before integration; it is not yet added to the book by this introductory reading.

The restricted canonical metric on the line 2z1-z2=0 in P2 is announced as a nonconcentrating example. This is a restriction to a nonlinear/translated torus coordinate situation with a new metric, not a refutation of the ambient canonical-height theorem. The example and exact local roofs remain to be read.

The modulus cluster statement uses bounded-continuous weak probability topology on N_R, finite first moment, support in F_v and expectation in B_v. Tightness, moment control and the distinction between B_v and its containing face F_v are substantive; no arbitrary vague limit is called a probability cluster measure. The converse realizability statement continues on page 9.

No newer-paper conclusion, cleared original candidate or book change is claimed.
