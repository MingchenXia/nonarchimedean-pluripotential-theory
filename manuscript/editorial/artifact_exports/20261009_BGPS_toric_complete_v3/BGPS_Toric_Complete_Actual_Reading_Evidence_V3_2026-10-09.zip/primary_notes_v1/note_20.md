# Actual BGPS published reading 20 — physical pages 25–26 / printed 332–333

Complete selected text and matching displayed image read. Actual distinct selected coverage is now 40 of 74 physical pages.

Proposition 3.7's proof finishes with a bounded-above integral supergradient touching Phi at the chosen probability. This proves upper semicontinuity without assuming weak continuity of the first moment: the linear expectation contribution is absorbed into the integral before applying the truncation lemma. Concavity and first-moment finiteness keep these differences defined.

Proposition 3.9's full proof characterizes zero deficit by support in the minimal face F and barycenter in B. Its decomposition into two nonpositive terms gives support in A1 and the opposite-gradient condition on the barycenter. The subsequent face argument uses the fact that a positive-mass distribution outside a closed finite-dimensional convex face cannot have its barycenter on that face. In an expanded proof this follows from supporting-hyperplane separation, with affine-hull restriction as needed, rather than assuming that the closure of the support of a restricted measure stays outside the face. Faces of a closed finite-dimensional convex set are closed; the relative-interior segment argument gives that fact. These are ordinary convex background details, not arithmetic point realizability.

Lemma 3.10 starts the first-moment coercivity estimate Phi(mu)<=c1-c2*integral norm, for full-dimensional compact C. The support function Psi=min_C <u,y> controls the concave conjugates up to bounded constants. Its proof continues on page 27. Full-dimensionality will supply a positive interior-radius constant; the inequality is not available in annihilator directions of a lower-dimensional C without quotienting.

The forty-page actual coverage is a new scoped source-reading fact; the frozen published twenty-page checkpoint still describes its own earlier coverage. No source candidate, independent verdict or book content is changed by this read.
