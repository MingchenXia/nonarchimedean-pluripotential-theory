# Published Ballay-Sombra book review — view 8

Physical pages: [4651].

Read the complete selected text and displayed matching rendered image.

Final-v2 physical4651 was fully read and displayed, including the complete new BS26Eq entry. Author accents Francois Ballay and Martin Sombra render correctly as François Ballaÿ and Martín Sombra; title, Inventiones journal, year2026 and version-of-record publication5October2026 match the controlling PDF. The DOI exists in the checked bib source without an invented print-volume/page range. Adjacent BPR/BR/Brelot/Branden/Bedford-Taylor/Binder-Vecchi/Benali-Zeriahi entries retain their labels and source qualifications; all lines fit without overlap, clipping or broken glyphs. Fifteen unique final book pages have now been read in eight fresh matching displays; no blank versos and no transfer of v1 six-page credit, no new whole-book or recursive original-source credit.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
