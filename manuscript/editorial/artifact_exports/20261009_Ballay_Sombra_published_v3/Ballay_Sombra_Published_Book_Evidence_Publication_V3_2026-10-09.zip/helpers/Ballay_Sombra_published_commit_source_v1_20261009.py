from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Ballay_Sombra_adelic_equdistribution_published_review_20261009'
out=C/'local_source_commit_v1_20261009.json';assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checkpoint=C/'source_checkpoint_v1_20261009.json';a=json.loads(checkpoint.read_text());files=list(a['editorial_files']);assert len(files)==9
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==a['baseline_commit']
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).strip()
for n,row in a['editorial_files'].items():assert sha(R/n)==row['SHA256'] and (R/n).stat().st_size==row['bytes']
for n,h in a['protected_core_inputs'].items():assert sha(R/n)==h
subprocess.run(['git','add','--',*files],cwd=R,check=True)
assert sorted(subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).splitlines())==sorted(files)
subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
subprocess.run(['git','commit','-m','Read published adelic equidistribution and preserve source scope evidence'],cwd=R,check=True)
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert sorted(subprocess.check_output(['git','diff-tree','--no-commit-id','--name-only','-r',commit],cwd=R,text=True).splitlines())==sorted(files)
out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — exact nine-file source/evidence commit',commit=commit,parent=a['baseline_commit'],checkpoint_SHA256=sha(checkpoint),files=a['editorial_files'],active_book_changed=False,native_editor_changed=False,reading_credit_from_commit=0,GitHub_published=False,helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
print(json.dumps(dict(commit=commit,files=len(files),record_SHA256=sha(out))))
