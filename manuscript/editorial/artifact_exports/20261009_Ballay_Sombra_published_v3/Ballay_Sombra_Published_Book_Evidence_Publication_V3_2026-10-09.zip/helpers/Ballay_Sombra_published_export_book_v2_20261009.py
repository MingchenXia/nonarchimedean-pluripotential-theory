from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile,shutil,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Ballay_Sombra_adelic_equdistribution_published_review_20261009'
S=Path('/workspace/book-completion-drafts/Ballay-Sombra-published-staging-v2-20261009');E=R/'manuscript/editorial';O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
write=lambda p,a:p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
prep=load('book_staging_preparation_v2_20261009.json');release=load('book_release_checks_v2_20261009.json');reading=load('actual_book_reading_v2_20261009.json')
post=load('book_post_render_checks_v2_20261009.json');math=load('book_mathematical_self_audit_v2_20261009.json');under=load('book_underfull_delta_v2_20261009.json')
assert reading['status'].startswith('DONE') and not reading['remaining_repairs']
assert reading['actual_unique_book_pages']==15 and reading['fresh_matching_views']==8 and reading['reused_matching_views']==0 and reading['explicitly_reviewed_blank_versos']==[]
assert all(x['returncode']==0 for x in post['checks']) and not under['added_blocks'] and not under['removed_blocks']
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['before'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
assert sha(release['PDF']['path'])==release['PDF']['SHA256']==reading['PDF']['SHA256']
record=C/'book_export_v2_20261009.json';paths={k:E/f'Ballay_Sombra_published_staged_integration_{k}_v2_20261009.{ext}' for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
full=O/'Non-Archimedean_Pluripotential_Theory_Adelic_Equidistribution_V2_2026-10-09.pdf';review=O/'Ballay_Sombra_Published_Actual_Book_Review_V2_2026-10-09.pdf'
minimal=O/'Ballay_Sombra_Published_Minimal_Source_V2_2026-10-09.zip';evidence=O/'Ballay_Sombra_Published_Actual_Book_Evidence_V2_2026-10-09.zip';dest=E/'artifact_exports/20261009_Ballay_Sombra_published_v2'
assert not any(p.exists() for p in [record,*paths.values(),full,review,minimal,evidence,dest])
shutil.copyfile(release['PDF']['path'],full);assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as b:
 d=fitz.open()
 for n in release['selected_book_physical_pages']:d.insert_pdf(b,from_page=n-1,to_page=n-1)
 assert len(d)==15;d.set_metadata(dict(title='Adelic approximation and arithmetic equidistribution — actual book review',subject='15 final physical pages read in eight fresh matching displays. Export adds zero reading credit.'));d.save(review,garbage=4,deflate=True);d.close()
summary='''The checked 4,675-page edition adds an attributed arithmetic counterpart to
Chapter 27, a quadratic toric roof with strict Zhang lower bound and an
Appendix L source audit. The number-field category, minus-log-norm Green
convention, place weights, approximant mass and geometric inradius are
explicit. The exact published Ballaÿ–Sombra source was read in all 99
physical pages and fifty matching displays. Arithmetic Hodge/Siu/Fujita
and deeper convex originals remain imported, not recursively certified.
No original mathematical result or independent-model receipt is claimed.

All fifteen final selected pages were read in eight fresh matching
displays: new prose and seams, two actual contents pages, first/last
index pages and the complete BS26Eq entry. This does not claim reading
the middle ten index pages or a new whole-book pass. No blank versos.
The last complete ordered book pass remains 4 October. Preparation
flags remain unchanged; actual observations are separate receipts.

V1 stopped after six pages in three actual displays when reference
comparison required a fixed c in the permitted lambda interval. Fresh
v2 uses 0<lambda<c*r_m, retains fixed constants and improves running
headers. Both stages and all receipts remain frozen. Two view-helper
failures preceded preparation: whole-page title search matched running
headers, and an initial coordinate cutoff still included them. Measured
coordinates supplied the successful selection. Prepared captions inherited
V1, separately clarified; controlling hashes and actual book content are
the final v2 PDF. No v1 actual-reading credit is transferred.

Required validation, six existing tests and final checks pass. Zero
errors, package/pdfTeX warnings, missing glyphs, overfull boxes, unresolved
references/citations and rerun requests. All 955 inherited underfull
blocks retain identical normalized content and multiplicities. All
13,382 old numbered values, 601 cited keys/labels and 900 index entries
remain. BS26Eq gives 602 cited entries; one unnumbered TOC entry is added
and all 2,765 earlier titles/hierarchy remain. All internal links resolve.
Two core TeX inputs and the NA bibliography change; the other 423 core
TeX inputs and complex bibliography remain identical. No formal result,
semantic label or manual equation tag is added.

Source Question 6.21 concerns necessity of the arithmetic criterion,
distinct from BJ22 Theorem 6.21. Logarithmic tests retain the extra
derivative equality and stabilization. Quasi-projective completion and
noncompact tightness are excluded from this discussion. Canonical
inventory 42 atoms/twelve problems and tiers (0,3,7,15,17) are unchanged.
General BJ22 homogeneous Siu/envelopes remain OPEN, LPWZ density
UNVERIFIED, and the user warning remains binding. Native catalogue/editor
unchanged. Activation and GitHub verification are separate records.
Export/upload adds zero reading credit.
'''
paths['audit'].write_text('# Published adelic-equidistribution book integration, 9 October 2026\n\n'+summary+'\nScoped mathematical checks:\n\n'+''.join(f'{i}. {x}\n\n' for i,x in enumerate(math['checks'],1)))
paths['reading_notes'].write_text('# Actual final adelic-equidistribution book reading\n\nFifteen selected pages in eight fresh views; no blank versos, no whole-book credit.\n'+''.join('\n---\n\n'+Path(x['sequential_note_path']).read_text() for x in reading['views']))
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md'
intro='''**Latest checked adelic-equidistribution book integration, 9 October 2026:**
the [integration audit](manuscript/editorial/Ballay_Sombra_published_staged_integration_audit_v2_20261009.md)
records the 4,675-page edition: Chapter 27 explains the published
defect/inradius criterion and a quadratic roof whose Zhang lower bound
is strict, while Appendix L preserves source hypotheses and limitations.
All fifteen selected final pages were read in eight fresh matching
displays. Required validation and final checks pass; all earlier numbered
values, cited labels, contents hierarchy and index terms remain.
The [artifacts](manuscript/editorial/artifact_exports/20261009_Ballay_Sombra_published_v2/README.md)
preserve full PDF, actual review, minimal source and authored evidence.
The [activation record](manuscript/editorial/Ballay_Sombra_published_cloud_activation_v2_20261009.json)
separately records the cloud update. General BJ22 Siu/envelopes remain OPEN.

'''
p=S/'README.md';s=p.read_text();marker='**Latest published adelic-equidistribution source checkpoint, 9 October 2026:**';assert s.count(marker)==1;p.write_text(s.replace(marker,intro+marker,1))
p=S/programme;s=p.read_text();marker='## Latest published adelic-equidistribution source checkpoint, 9 October 2026\n';assert s.count(marker)==1
intro='''## Latest checked adelic-equidistribution book checkpoint, 9 October 2026

The [integration audit](Ballay_Sombra_published_staged_integration_audit_v2_20261009.md)
records the 4,675-page edition. Chapter 27 imports published Ballaÿ–Sombra
with exact arithmetic signature, derivative and normalized probability
conventions. The quadratic roof has essential minimum 1, absolute 3/4,
Zhang lower bound 11/12 and wide-level inradius ratio tending to zero.
The source necessity and logarithmic stabilization questions remain
open in their stated scopes. No homogeneous BJ22 Siu repair follows.

All fifteen final selected pages were actually read in eight fresh views;
there are no blank versos. Two contents pages, first/last index pages
and complete BS26Eq entry were read; the middle ten index pages were
mechanically compared, not reread in this increment. V1's six-page
reading and its lambda-domain repair remain frozen. The view-locator
failures and inherited caption metadata issue are separately recorded.
Required validation, six tests and final checks pass. All 13,382 earlier
numbered values, 601 cited labels and 900 index entries remain. One key
gives 602 citations and one unnumbered TOC entry gives 2766 entries.
All links resolve; 955 inherited underfull blocks remain identical.
Last complete ordered book pass remains 4 October.

The [artifacts](artifact_exports/20261009_Ballay_Sombra_published_v2/README.md)
preserve full PDF, actual review, 472-member minimal source and evidence.
Published source/evidence commit 823ef4886d771c618d6e36b82eb1eeeeeb25a5ee
has all nine remote blobs verified. Activation/publication are separate.
Native 86-page catalogue/editor, 42 atoms/twelve problems, tiers(0,3,7,15,17)
are unchanged. General BJ22 Siu/envelopes stay OPEN, LPWZ UNVERIFIED.
No independent-model receipt or original result is introduced. Continue
cloud-only; Xean suspended. Next related candidate: Xue 2608.08262v2,
metadata-only so far; read before adding claims or updating source-open
directions in the native catalogue. Export/upload adds no reading credit.

''';p.write_text(s.replace(marker,intro+marker,1))
with zipfile.ZipFile(prep['baseline_minimal_source']['path']) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 members=old.namelist();assert len(members)==len(set(members))==472
 for n in members:z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
 assert z.testzip() is None
 for n in z.namelist():assert z.read(n)==(S/n).read_bytes()
files={f'records/{q.name}':q for q in C.glob('*.json')}
for v in [1,2]:
 q=C/f'book_validation_v{v}_20261009.log';files[f'logs/{q.name}']=q
 stage=Path(f'/workspace/book-completion-drafts/Ballay-Sombra-published-staging-v{v}-20261009');draft=Path(f'/workspace/book-completion-drafts/Ballay-Sombra-published-integration-v{v}-20261009')
 for rel in prep['after']:files[f'staged_inputs/v{v}/{rel}']=stage/rel
 for q in draft.iterdir():files[f'drafts/v{v}/{q.name}']=q
 for q in (C/f'book_compiled_staged_v{v}').iterdir():
  if q.suffix!='.pdf':files[f'compiled/v{v}/{q.name}']=q
 for rp in (C/f'book_notes_v{v}').glob('*_receipt.json'):
  a=json.loads(rp.read_text());n=a['number'];w=Path(f'/tmp/Ballay_Sombra_published_staged_book_views_v{v}_20261009')
  for kind,q in [('notes',rp.with_name(rp.name.replace('_receipt.json','.md'))),('receipts',rp),('images',w/f'sheet_{n:02d}.png'),('text',w/f'sheet_{n:02d}.txt')]:files[f'actual_v{v}/{kind}/{q.name}']=q
 files[f'actual_v{v}/prepared_manifest.json']=Path(load(f'book_release_checks_v{v}_20261009.json')['manifest_path'])
for q in Path('/tmp').glob('Ballay_Sombra_published_*_v*_20261009.py'):files[f'helpers/{q.name}']=q
for q in [paths['audit'],paths['reading_notes'],S/programme,S/'README.md']:files[f'editorial/{q.name}']=q
q=E/'artifact_exports/20261009_Ballay_Sombra_published_sources/Ballay_Sombra_Published_Authored_Records_V1_2026-10-09.zip';files[f'source_owned_records/{q.name}']=q
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
 assert len(z.namelist())==len(files) and z.testzip() is None
 for n,q in files.items():assert z.read(n)==q.read_bytes()
artifacts={k:dict(path=str(q),bytes=q.stat().st_size,SHA256=sha(q)) for k,q in [('full_book_PDF',full),('selected_review_PDF',review),('minimal_TeX_source_archive',minimal),('actual_book_evidence_archive',evidence)]}
artifacts['full_book_PDF']['physical_pages']=4675;artifacts['selected_review_PDF']['physical_pages']=15;artifacts['minimal_TeX_source_archive']['members']=472;artifacts['actual_book_evidence_archive']['members']=len(files)
progress={n:sha(S/n) for n in ['README.md',programme]}
write(paths['manifest'],dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — mathematical/mechanical/actual-final-render gate',preparation=prep,release=release,actual_reading=reading,mathematical_audit=math,post_render=post,underfull_comparison=under,artifacts=artifacts,active_book_changed=False,GitHub_published=False))
write(paths['artifacts'],dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — all export members byte-verified',artifacts=artifacts,actual_final_book_pages=15,fresh_matching_views=8,explicitly_reviewed_blank_versos=[],reading_credit_from_export=0,GitHub_published=False))
dest.mkdir(parents=True)
for q in [full,review,minimal,evidence]:shutil.copyfile(q,dest/q.name);assert sha(dest/q.name)==sha(q)
(dest/'SHA256SUMS').write_text(''.join(sha(q)+'  '+q.name+'\n' for q in [full,review,minimal,evidence]))
(dest/'README.md').write_text('# Adelic-equidistribution book artifacts, 9 October 2026\n\n'+summary+f'\nArtifacts: full 4,675-page PDF, 15-page actual review, 472-member minimal\nsource and {len(files)}-member byte-verified evidence archive. Source originals\nremain in their separate cloud archive; authored source records are included.\n')
editorial={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in paths.values()}
for p in dest.iterdir():editorial[str(p.relative_to(R))]=dict(bytes=p.stat().st_size,SHA256=sha(p))
write(record,dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — final book/evidence export',artifacts=artifacts,editorial_files=editorial,progress_document_hashes=progress,actual_final_book_pages=15,actual_final_matching_views=8,reused_matching_views=0,explicitly_reviewed_blank_versos=[],active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)))
print(json.dumps(dict(status='DONE',record_SHA256=sha(record),evidence_members=len(files),artifacts=artifacts)))
