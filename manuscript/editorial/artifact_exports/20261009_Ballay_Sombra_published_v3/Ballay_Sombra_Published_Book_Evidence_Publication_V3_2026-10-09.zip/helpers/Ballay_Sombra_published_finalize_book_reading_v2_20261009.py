from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,re,subprocess,difflib,fitz

R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Ballay_Sombra_adelic_equdistribution_published_review_20261009'
S=Path('/workspace/book-completion-drafts/Ballay-Sombra-published-staging-v2-20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
ch=load('book_release_checks_v2_20261009.json');prep=load('book_staging_preparation_v2_20261009.json')
mp=Path(ch['manifest_path']);assert sha(mp)==ch['manifest_SHA256'];xs=json.loads(mp.read_text())
reading=C/'actual_book_reading_v2_20261009.json';audit=C/'book_mathematical_self_audit_v2_20261009.json';post=C/'book_post_render_checks_v2_20261009.json'
assert not any(p.exists() for p in [reading,audit,post])
views=[];last=None
for x in xs:
    assert not x['actually_viewed'] and not x['selected_text_read']
    n=C/'book_notes_v2'/f"note_{x['number']:02d}.md";rp=n.with_name(n.stem+'_receipt.json');a=json.loads(rp.read_text())
    assert 'Read the complete selected text and displayed matching rendered image' in n.read_text()
    assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
    assert a['number']==x['number'] and a['physical_pages']==x['physical_pages']
    assert a['source_PDF_SHA256']==ch['PDF']['SHA256'] and sha(n)==a['note_SHA256']
    assert sha(x['path'])==a['image_SHA256']==x['image_SHA256']
    assert sha(x['selected_text_path'])==a['selected_text_SHA256']==x['selected_text_SHA256']
    assert last is None or a['UTC']>last;last=a['UTC']
    y={k:v for k,v in x.items() if k not in ['actually_viewed','selected_text_read']}
    y.update(actual_complete_text_read=True,actual_matching_image_freshly_displayed=True,sequential_note_path=str(n),sequential_note_SHA256=sha(n),observation_receipt_path=str(rp),observation_receipt_SHA256=sha(rp));views.append(y)
pages=sorted({p for x in xs for p in x['physical_pages']});assert pages==ch['selected_book_physical_pages']
assert sum(len(x['physical_pages']) for x in xs)==len(pages)==ch['prepared_book_pages'] and len(views)==ch['prepared_views']
checks=[]
for command in [['python3','editorial/tools/refcheck.py'],['python3','editorial/tools/check_open_problem_inventory.py']]:
    run=subprocess.run(command,cwd=S/'manuscript',text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);assert run.returncode==0,run.stdout
    checks.append(dict(command=command,returncode=run.returncode,output=run.stdout))
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
for n,h in prep['other_active_TeX_preserved'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['unchanged_bibliographies'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
assert sha(ch['PDF']['path'])==ch['PDF']['SHA256']
historical={};whitespace={}
for row in prep['historical_formal_environment_counts_preserved']:
    n=row['path'];before=(R/n).read_text();after=(S/n).read_text()
    for e,count in row['environment_counts'].items():
        pat=r'\\begin\{'+e+r'\}';assert len(re.findall(pat,before))==len(re.findall(pat,after))==count
    assert re.findall(r'\\tag\{([^}]+)\}',after)==re.findall(r'\\tag\{([^}]+)\}',before)
    assert re.findall(r'\\label\{([^}]+)\}',before)==re.findall(r'\\label\{([^}]+)\}',after)
    historical[n]=row
for n in prep['after']:
    before=(R/n).read_text().splitlines();after=(S/n).read_text().splitlines()
    assert Counter(x for x in before if x!=x.rstrip())==Counter(x for x in after if x!=x.rstrip())
    added=[x[2:] for x in difflib.ndiff(before,after) if x.startswith('+ ')];assert all(x==x.rstrip() for x in added)
    run=subprocess.run(['git','diff','--no-index','--check',str(R/n),str(S/n)],text=True,capture_output=True)
    assert run.returncode in [0,1] and not(run.stdout+run.stderr).strip()
    whitespace[n]=dict(added_lines=len(added),added_trailing_whitespace=0)
for p,h in prep['draft_fragments'].items():assert sha(p)==h
under=load('book_underfull_delta_v2_20261009.json')
assert not under['added_blocks'] and not under['removed_blocks']
with fitz.open(ch['PDF']['path']) as doc:blank=[p for p in pages if not doc[p-1].get_text().strip()]
reading.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — all selected final book pages read with matching individual display',PDF=ch['PDF'],actual_unique_book_pages=len(pages),fresh_complete_text_and_individually_displayed_pages=len(pages),substantive_selected_pages=len(pages)-len(blank),explicitly_reviewed_blank_versos=blank,fresh_matching_views=len(views),reused_matching_views=0,views=views,legacy_preparation_flags_rewritten=False,remaining_repairs=[],whole_book_new_reading_claim=False,last_complete_ordered_book_pass='2026-10-04',active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
mathchecks=['The projective arithmetic discussion explicitly replaces local BFJ standing hypotheses by a normal integral projective variety of dimension d>=1 over a number field, with completed algebraic closures at places. No trivially valued-field or E1 completion extension is inferred.', 'Green functions are minus log norm, the same model is used outside finitely many places, and place weights obey the product formula. No dd^c of a minus-log-norm function is silently identified with a squared-norm potential convention.', 'Geometric and arithmetic bigness, local semipositivity and adelic neffness are distinguished. Pseudoeffectivity uses addition of every arithmetically big divisor, not separate local roof domination.', 'Exact published Th6.9 assumes big semipositive approximants on normal modifications, adelically pseudoeffective remainder and finite essential-to-absolute defect divided by geometric inradius tending to zero. The target need not be locally semipositive.', 'The derivative subtracts d*mu times Q^(d-1).E, divides by approximant Q^d and preserves d+1 arithmetic versus d geometric factors. A zero-geometric test gives n_v times the integral against a probability measure; the place weight is divided out.', 'The normalized approximant is adelic nef. A fixed geometric reference comparison changes BOTH the quadratic-error constant and permitted lambda interval. Final v2 uses 0<lambda<c*r_m for fixed c>0; square-root choices eventually belong to it. The common upward target/approximant shift keeps the remainder, defect, geometric data and normalized approximants unchanged.', 'The quadratic continuous concave roof on [0,1] yields essential1, absolute3/4, average11/12 and arithmetic top11/6. For epsilon<1/4 the exact upper-level interval has width/inradius2sqrt(epsilon), giving ratio sqrt(epsilon)/2. This is an imported-theorem illustration, not a new formal result.', 'The toric balanced local slopes are all zero at the interior maximizing point. Limiting infinite measure is unit-circle Haar; finite measures are Gauss Dirac probabilities, with Laurent norm max of coefficient norms. Original metric MA is not silently substituted for the small-point equilibrium measure.', 'Published Th6.17 is stated with strict t<mu and liminf approximation criterion. The source Question6.21 is a necessity question, distinct from the BJ22 Theorem6.21 warning. Partial converses retain the dominating Zhang-equality metric or semipositive toric hypotheses.', 'Logarithmic convergence keeps Th7.13 derivative/Green-integral equality and Cor7.15 eventual all-place stabilization; Remark7.16 is not solved. Mere weak convergence plus limit integrability is insufficient.', 'AppendixL preserves all99 primary published pages in50 matching displays, exact edition and locators; arithmetic Hodge/Siu/Fujita and deeper convex originals remain imports, not recursively verified. Quasi-projective completion and proof tightness issues are outside the book discussion.', 'V1 reading stopped at six actual pages in three views after the lambda-domain precision issue was found. V1 files, helpers, receipts and preparation are unchanged; v2 uses fresh final-PDF displays. Running headers now identify arithmetic discussion and notes. No old reading credit transfers.', 'All old numbered values,601 cited keys/labels and900 index entries remain. One new attributed BS26Eq key and one unnumbered TOC entry are added. Two core TeX inputs and NA bibliography change; other423 core TeX inputs and complex bibliography remain identical.', 'No formal result, semantic label, manual equation tag, independent-model production receipt or canonical closure is introduced. Inventory42/twelve and tiers(0,3,7,15,17), native catalogue/editor, general BJ22 Siu/envelope OPEN and LPWZ UNVERIFIED remain intact.']

audit.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — ordinary scoped mathematical audit and actual final render clearance',checks=mathchecks,actual_final_book_reading_SHA256=sha(reading),source_input_hashes=prep['after'],draft_fragments=prep['draft_fragments'],original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
post.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — post-render references, inventory and input preservation checked',checks=checks,historical_formal_environment_counts_preserved=historical,whitespace_checks=whitespace,underfull_delta_SHA256=sha(C/'book_underfull_delta_v2_20261009.json'),actual_final_reading_SHA256=sha(reading),mathematical_audit_SHA256=sha(audit),release_checks_SHA256=sha(C/'book_release_checks_v2_20261009.json'),active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',pages=len(pages),views=len(views),blank_pages=blank,reading_SHA256=sha(reading),math_SHA256=sha(audit),post_SHA256=sha(post))))
