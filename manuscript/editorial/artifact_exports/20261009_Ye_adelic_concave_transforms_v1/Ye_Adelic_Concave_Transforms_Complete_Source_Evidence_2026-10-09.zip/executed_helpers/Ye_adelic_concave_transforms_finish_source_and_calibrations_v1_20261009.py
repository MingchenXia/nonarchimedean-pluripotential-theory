from pathlib import Path
from datetime import datetime,timezone
from math import comb,factorial
from fractions import Fraction as Q
import hashlib,json,sympy as sp
R=Path('/workspace/nonarchimedean-pluripotential-theory')
D=R/'source_material/Ye_adelic_concave_transforms_review_20261009/YeArxivV1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
prep=json.loads((D/'scope_preparation_v1_20261009.json').read_text())
receipts=[];pages=[]
for n,x in enumerate(prep['entries'],1):
 note=D/f'primary_notes_v1/note_{n:02d}.md';p=note.with_suffix('.json');r=json.loads(p.read_text())
 assert r['number']==n and r['physical_pages']==x['physical_pages']
 assert r['complete_text_actually_read'] and r['matching_image_actually_viewed']
 assert sha(note)==r['note_SHA256'] and sha(x['image_path'])==r['image_SHA256'] and sha(x['text_path'])==r['text_SHA256']
 assert r['PDF_SHA256']==prep['PDF_SHA256']==sha(prep['PDF'])
 assert r['previous_receipt_SHA256']==(receipts[-1]['receipt_SHA256'] if n>1 else None)
 receipts.append(dict(number=n,pages=x['physical_pages'],note_SHA256=sha(note),receipt_SHA256=sha(p)))
 pages.extend(x['physical_pages'])
assert pages==list(range(1,24)) and len(receipts)==12
book=sha(R/'manuscript/book.pdf');native=sha(R/'output/open_problems_catalogue_2026-10-03.tex')
assert book=='79a07672385e2ace08e064474a0948b8acdaae8ac6b43f94aecbc36afd10e45c'
assert native=='2d55114885d92f1ceacc17e74a2c397d992fb049d0f40810847787bff2f70fe8'
N=sp.symbols('N',positive=True);a=sp.symbols('a',real=True)
counts={};limits=[];cases=0
for dim in range(1,5):
 for degree in [1,2,3]:
  rank=sp.prod(degree*N+j for j in range(1,dim+1))/sp.Integer(factorial(dim))
  for field_degree in [1,2,3,4]:
   for c in [Q(-1),Q(-1,4),Q(0),Q(1,4),Q(1)]:
    C=sp.Rational(c.numerator,c.denominator)
    limit=sp.limit(rank*N*field_degree*C*sp.factorial(dim+1)/N**(dim+1),N,sp.oo)
    expected=(dim+1)*field_degree*C*degree**dim
    integral=field_degree*C*degree**dim/sp.factorial(dim)
    assert limit==expected==sp.factorial(dim+1)*integral
    assert limit/field_degree==(dim+1)*C*degree**dim
    limits.append(dict(dimension=dim,line_bundle_degree=degree,K_degree=field_degree,c_normalized=str(c),signed_chi_raw=str(limit),Chebyshev_integral_raw=str(integral)))
    for n in range(1,9):
     r=comb(degree*n+dim,dim);total=Q(n*r*field_degree)*c;positive=Q(n*r*field_degree)*max(c,Q(0))
     assert positive>=total and positive>=0
     if c<0:assert positive==0 and total<0
     cases+=1
counts['constant_roof_finite_total_and_positive_degree_cases']=cases
counts['constant_roof_symbolic_chi_factorial_and_field_normalizations']=len(limits)
cube_integral=sp.integrate((1-a)**2,(a,0,1))/3
assert cube_integral==sp.Rational(1,9)
counts['plane_cubic_factor_integral']=1
product_cases=0;product_limits=[]
for k in range(1,5):
 for b in range(1,5):
  rank=sp.prod(b*N+j for j in range(1,k+1))/sp.Integer(factorial(k))
  limit=sp.limit(rank/N**k,N,sp.oo)
  assert limit==sp.Rational(b**k,factorial(k))
  product_limits.append(dict(projective_dimension=k,b=b,limit=str(limit)))
  for n in range(1,17):
   assert sp.expand(rank).subs(N,n)==comb(b*n+k,k)
   product_cases+=1
counts['product_projective_monomial_exact_counts']=product_cases
counts['product_projective_monomial_symbolic_limits']=len(product_limits)
height_cases=0
for m in range(1,33):
 for h in [Q(0),Q(1,9),Q(1),Q(3,2)]:
  assert Q(m*m)*h/(m*m)==h
  for Kdegree in [1,2,4]:
   top_sum_leading=-Kdegree*m*m*h
   assert -top_sum_leading/(m*m)==Kdegree*h
   assert -Q(-2*Kdegree*h,1)/2==Kdegree*h
   height_cases+=1
counts['abstract_quadratic_height_and_Hodge_sign_cases']=height_cases
boundary_cases=0
for m in range(1,65):
 for epsilon in [Q(1,2),Q(1,4),Q(1,8),Q(1,16)]:
  orders=list(range(m+1));strip=[i for i in orders if Q(i,m)<epsilon or Q(m-i,m)<epsilon]
  assert len(strip)<=2*epsilon*m+2
  shift_effect=Q(m*len(strip),m*m)
  assert shift_effect<=2*epsilon+Q(2,m)
  boundary_cases+=1
counts['one_dimensional_boundary_metric_shift_bounds']=boundary_cases
cal=D/'own_exact_normalization_calibrations_v1_20261009.json';assert not cal.exists()
cal.write_text(json.dumps(dict(UTC=now(),status='EXACT SCOPED DIAGNOSTICS PASSED — not a proof of source dependencies',counts=counts,
 constant_roof_limits=limits,product_monomial_limits=product_limits,plane_cubic_factor=str(cube_integral),
 abstract_height_model_only=True,elliptic_curve_height_computed=False,Picard_bundle_theorem_verified=False,
 arithmetic_Riemann_Roch_dependency_verified=False,independent_verifier_receipt=None,
 helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
out=D/'actual_complete_source_checkpoint_v1_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=now(),status='DONE — actual complete pinned preprint reading and scoped ordinary source audit',
 source_version='arXiv:2609.23722v1, 20 September 2026',internal_title_date='22 September 2026',
 PDF=prep['PDF'],PDF_SHA256=prep['PDF_SHA256'],physical_pages_read=pages,unique_physical_pages=23,
 full_source_read=True,fresh_matching_views=12,reused_matching_views=0,receipts=receipts,
 preparation_SHA256=sha(D/'scope_preparation_v1_20261009.json'),acquisition_SHA256=sha(D/'source_acquisition_v1_20261009.json'),
 own_exact_calibrations_SHA256=sha(cal),own_review_SHA256=sha(D/'own_complete_source_review_v1_20261009.md'),
 main_results_status='SOURCE-REPORTED; controlling dependency and normalization checks pending for book integration',
 main_results_imported=False,intended_main_results_refuted=False,deeper_dependencies_recursively_verified=False,
 original_results_promoted=[],canonical_status_changes=[],independent_verifier_receipt=None,
 active_book_changed=False,book_pages=4685,book_PDF_SHA256=book,native_editor_changed=False,native_catalogue_SHA256=native,
 whole_book_reading_claim=False,helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(full_pages=23,fresh_views=12,checkpoint_SHA256=sha(out),calibrations_SHA256=sha(cal),counts=counts)))
