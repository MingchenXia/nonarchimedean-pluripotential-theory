from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
R=Path('/workspace/nonarchimedean-pluripotential-theory');E=R/'manuscript/editorial'
D=R/'source_material/Ye_adelic_concave_transforms_review_20261009/YeArxivV1'
A=E/'artifact_exports/20261009_Ye_adelic_concave_transforms_v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
cp=D/'actual_complete_source_checkpoint_v1_20261009.json';c=json.loads(cp.read_text())
assert c['full_source_read'] and c['physical_pages_read']==list(range(1,24)) and c['fresh_matching_views']==12
for x in c['receipts']:
 p=D/f"primary_notes_v1/note_{x['number']:02d}.md";q=p.with_suffix('.json')
 assert sha(p)==x['note_SHA256'] and sha(q)==x['receipt_SHA256']
assert sha(R/'manuscript/book.pdf')==c['book_PDF_SHA256']
assert sha(R/'output/open_problems_catalogue_2026-10-03.tex')==c['native_catalogue_SHA256']
assert not A.exists();A.mkdir(parents=True)
prefix='Ye_adelic_concave_transforms_complete_source_'
review=E/(prefix+'review_v1_20261009.md');notes=E/(prefix+'reading_notes_v1_20261009.md')
manifest=E/(prefix+'manifest_v1_20261009.json');artifacts=E/(prefix+'artifacts_v1_20261009.json')
for p in [review,notes,manifest,artifacts]:assert not p.exists()
review.write_bytes((D/'own_complete_source_review_v1_20261009.md').read_bytes())
notes.write_text('# Actual complete Ye source reading notes\n\n'
 'Twenty-three physical pages in twelve fresh ordered matching text/image views.\n'
 'No recursive dependency clearance or original-result promotion is claimed.\n\n'+
 '\n\n'.join('## View '+str(n)+'\n\n'+(D/f'primary_notes_v1/note_{n:02d}.md').read_text().strip() for n in range(1,13))+'\n')
members={}
for n in range(1,13):
 for suffix in ['md','json']:
  p=D/f'primary_notes_v1/note_{n:02d}.{suffix}';members['actual_reading/'+p.name]=p
for name in ['source_acquisition_v1_20261009.json','scope_preparation_v1_20261009.json',
 'own_exact_normalization_calibrations_v1_20261009.json','actual_complete_source_checkpoint_v1_20261009.json']:
 members['records/'+name]=D/name
members['own_audit/own_complete_source_review_v1_20261009.md']=D/'own_complete_source_review_v1_20261009.md'
for kind in ['acquire','prepare_source_views','record_source_note','finish_source_and_calibrations','export_complete_source']:
 p=Path('/tmp/Ye_adelic_concave_transforms_'+kind+'_v1_20261009.py');assert p.exists();members['executed_helpers/'+p.name]=p
assert len(members)==34
archive=A/'Ye_Adelic_Concave_Transforms_Complete_Source_Evidence_2026-10-09.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for name,p in members.items():z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(members)
 for name,p in members.items():assert z.read(name)==p.read_bytes()
obj=dict(UTC=now(),status='ACTUAL FULL PINNED PREPRINT READING; ordinary scoped source audit',
 source_version=c['source_version'],internal_title_date=c['internal_title_date'],source_PDF_SHA256=c['PDF_SHA256'],
 actual_unique_primary_pages=23,fresh_matching_views=12,reused_matching_views=0,
 complete_source_checkpoint_SHA256=sha(cp),actual_receipts=c['receipts'],
 mathematical_calibration_SHA256=c['own_exact_calibrations_SHA256'],
 source_main_results_status=c['main_results_status'],main_results_imported=False,intended_main_results_refuted=False,
 deeper_dependencies_recursively_verified=False,ordinary_source_audit=True,independent_verifier_receipt=None,
 archive=str(archive.relative_to(R)),archive_members=34,archive_SHA256=sha(archive),archive_bytes=archive.stat().st_size,
 all_members_byte_verified=True,archive_excludes=['Primary PDF','Primary full text','Primary rendered pages','Book/catalogue PDFs'],
 book_pages=4685,active_book_changed=False,book_PDF_SHA256=c['book_PDF_SHA256'],native_catalogue_changed=False,
 native_catalogue_SHA256=c['native_catalogue_SHA256'],native_compile_success_verified=False,native_editor_kept_open=True,
 canonical_atoms=42,formal_problems=12,canonical_tiers=[0,3,7,15,17],original_results_promoted=[],canonical_status_changes=[],
 BJ22_general_homogeneous_Siu='OPEN',LPWZ_density='UNVERIFIED',whole_book_rereading_claim=False,
 helper_source=__file__,helper_SHA256=sha(__file__))
manifest.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
artifacts.write_text(json.dumps(dict(UTC=now(),archive=obj['archive'],SHA256=sha(archive),bytes=archive.stat().st_size,
 members=34,all_members_byte_verified=True,primary_text_or_images_redistributed=False,book_changed=False,
 original_results_promoted=[],helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
(A/'README.md').write_text('# Ye concave transforms: complete source evidence, 9 October 2026\n\n'
 'All 23 physical pages of arXiv:2609.23722v1 were actually read in twelve\n'
 'ordered matching text/image views. This 34-member archive contains own\n'
 'notes, chained receipts, source audit, exact normalization diagnostics\n'
 'and frozen executed helpers. All members are byte-verified. Primary\n'
 'paper PDF, full text and rendered pages are excluded.\n\n'
 'The audit distinguishes local monic Chebyshev transforms from global\n'
 'HN transforms, signed chi-volume from positive volume, and fixed-flag\n'
 'metric independence from flag independence. The curve/theta and\n'
 'higher-dimensional claims remain source-reported pending controlling\n'
 'dependency/normalization checks for book integration. No intended main\n'
 'result is declared refuted; no original book result is promoted.\n\n'
 'The active 4,685-page book, same native catalogue/editor and canonical\n'
 '42-atom/twelve-problem statuses are unchanged. General BJ22 homogeneous\n'
 'Siu remains OPEN. Upload adds no reading credit or theorem clearance.\n')
(A/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in [archive,A/'README.md']))
for p,link,artifact in [(R/'README.md','manuscript/editorial/'+review.name,'manuscript/editorial/'+str(A.relative_to(E))+'/README.md'),
 (E/'second_reading_and_research_programme_20261002.md',review.name,str(A.relative_to(E))+'/README.md')]:
 p.write_text(p.read_text().rstrip()+'\n\n### Ye concave-transform full-source checkpoint, 9 October 2026\n\n'
 'All 23 physical pages of arXiv:2609.23722v1 were actually read in twelve\n'
 'ordered matching text/image views. The [source audit]('+link+')\n'
 'and [34-member authored evidence]('+artifact+') retain the Chebyshev/HN\n'
 'distinction, signed-volume factorial and [K:Q] normalization, boundary\n'
 'terms, curve/theta proof structure and higher-dimensional flag scope.\n'
 'The new preprint results remain source-reported pending controlling\n'
 'dependency and normalization checks for book integration. No original\n'
 'book result or canonical problem is promoted. The active 4,685-page\n'
 'book and same native catalogue/editor are unchanged by this audit.\n'
 'Work continues cloud-only; upload supplies no additional reading credit.\n')
owned=[review,notes,manifest,artifacts,archive,A/'README.md',A/'SHA256SUMS',R/'README.md',E/'second_reading_and_research_programme_20261002.md']
out=D/'complete_source_evidence_export_v1_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=now(),status='AUTHORED SOURCE EVIDENCE EXPORTED AND BYTE VERIFIED',archive_SHA256=sha(archive),
 archive_members=34,owned_files=[dict(path=str(p.relative_to(R)),SHA256=sha(p),bytes=p.stat().st_size) for p in owned],
 member_files=[dict(name=n,SHA256=sha(p),bytes=p.stat().st_size) for n,p in members.items()],original_results_promoted=[],
 canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(owned_files=9,archive_members=34,archive_bytes=archive.stat().st_size,archive_SHA256=sha(archive),export_SHA256=sha(out))))
