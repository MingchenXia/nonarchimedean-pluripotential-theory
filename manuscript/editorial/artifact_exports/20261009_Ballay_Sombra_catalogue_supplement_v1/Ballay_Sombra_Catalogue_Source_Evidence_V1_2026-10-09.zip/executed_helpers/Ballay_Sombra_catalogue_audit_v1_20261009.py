from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R/'source_material/Ballay_Sombra_catalogue_supplement_20261009'
source = R/'output/open_problems_catalogue_2026-10-03.tex'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
before = (C/'catalogue_before_v1_20261009.tex').read_text()
after = source.read_text()
edit = json.loads((C/'catalogue_edit_v1_20261009.json').read_text())
assert sha(source) == edit['after_SHA256']
problems = lambda s: re.findall(r'\\begin\{problem\}.*?\\end\{problem\}', s, re.S)
atoms = lambda s: re.findall(r'\\label\{atom:[^}]+\}', s)
bib = lambda s: dict(re.findall(r'(\\bibitem(?:\[[^\]]*\])?\{[^}]+\})(.*?)(?=\\bibitem|\\end\{thebibliography\})', s, re.S))
assert problems(before) == problems(after) and len(problems(after)) == 12
assert atoms(before) == atoms(after) and len(atoms(after)) == 42
old_bib, new_bib = bib(before), bib(after)
assert all(new_bib[k] == v for k,v in old_bib.items())
assert len(new_bib) == len(old_bib)+1
labels = re.findall(r'\\label\{([^}]+)\}', after)
assert len(labels) == len(set(labels))
refs = re.findall(r'\\(?:eqref|ref|[Cc]ref|hyperref)\{([^}]+)\}', after)
assert set(refs).issubset(set(labels))
assert sha(source.with_suffix('.pdf')) == edit['prior_historical_PDF_SHA256']
assert sha(R/'manuscript/book.pdf') == '2c90129c35506ac72005c5189ff235b0e1bd52f5b529ef44e5fc58bf7dbfcfe8'

obj = dict(UTC=datetime.now(timezone.utc).isoformat(), status='SOURCE AUDIT COMPLETE — native compiler still pending',
    source_SHA256=sha(source), original_formal_problems_byte_identical=12,
    original_atom_labels_byte_identical=42, original_bibliography_entries_byte_identical=len(old_bib),
    added_bibliography_entries=1, duplicate_labels=0, unresolved_checked_source_references=0,
    mathematical_scope_checks=[
      'Normal integral projective number-field category, dimension at least one; no implicit geometric integrality.',
      'Continuous quasi-algebraic R-Cartier metrics, big geometry; no target semipositivity added to the general question.',
      'Essential and absolute minima separated; all defect absolute minima finite; strict t<mu endpoint.',
      'Geometric inradius versus arithmetic nef-approximant supremum, fixed geometric reference D.',
      'All-direction differentiability separated from metric-direction/all-place equidistribution.',
      'Known necessity requires same-geometric semipositive upper bound with both minima equal to mu.',
      'Toric special case retains semipositivity; no general criterion declared necessary.',
      'Logarithmic question retains exact effective-cycle height, coefficient d, approximant denominator Q_m^d.',
      'Original corollary requires one common m_0 for all places; removed hypothesis remains a question.',
      'Integrability, weak convergence, and derivative/Green-integral equality remain distinct.',
      'Elementary probability example has weak limit delta_1 but log integrals 1 versus 0; no adelic counterexample.',
      'BS Question 6.21 separated explicitly from unresolved BJ22 Theorem 6.21 homogeneous Siu proof.'
    ],
    targeted_searches_20261009=[
      '"Ballaÿ" "Sombra" "Question 6.21"',
      '"equidistribution" "Remark 7.16" Sombra',
      '"Approximation of adelic divisors" "converse"',
      '"Wei Xue" "Equidistribution for semiabelian"'
    ],
    targeted_search_result='Published primary-source questions identified; no checked general resolution located. Not exhaustive.',
    primary_source_PDF_SHA256=edit['primary_source_PDF_SHA256'],
    existing_full_primary_reading='99 physical pages / 50 views; no reading credit added here',
    native_preview_actually_read=False, independent_verifier_receipt=False,
    mathematical_status_changes=[], book_PDF_unchanged=True, historical_catalogue_PDF_unchanged=True,
    helper_source=__file__, helper_SHA256=sha(__file__))
out = C/'catalogue_source_audit_v1_20261009.json'
assert not out.exists()
out.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(dict(status=obj['status'], formal_problems=12, canonical_atoms=42,
    old_bibliography=len(old_bib), audit_SHA256=sha(out))))
