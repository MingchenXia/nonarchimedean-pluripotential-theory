from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R / 'source_material/Ballay_Sombra_catalogue_supplement_20261009'
source = R / 'output/open_problems_catalogue_2026-10-03.tex'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not C.exists()
assert sha(source) == 'dd84419eead17f91403527a5817d6d259f630531f240cdee0619a236c91fc4da'
old = source.read_text()
C.mkdir(parents=True)
(C / 'catalogue_before_v1_20261009.tex').write_bytes(source.read_bytes())
pdf = source.with_suffix('.pdf')
old_pdf_sha = sha(pdf)
assert old_pdf_sha == '65125a7809e34e4dbe2440855df21447f2c38b79dc3dd6f4a46107353dcb53e2'

addition = r'''\section*{Supplementary source questions: arithmetic equidistribution}
\addcontentsline{toc}{section}{Supplementary source questions: arithmetic equidistribution}
\label{supp:arithmetic-equidistribution}
These two questions belong to the arithmetic direction added to Book
Chapter~27 on 9 October 2026. They are supplementary source questions,
outside the unchanged inventory of 42 atoms and twelve formal problem
families. Their status below is the unresolved scope explicitly recorded
in Balla\"y--Sombra's published paper \cite{BallaySombra26Published},
with a targeted search on 9 October 2026. That search found no checked
general resolution; it is not an exhaustive certification of all current
literature. Neither question is the homogeneous Siu division assertion
in Boucksom--Jonsson's 2022 Theorem~6.21.

\subsection*{Arithmetic setting and conventions}
\addcontentsline{toc}{subsection}{Arithmetic setting and conventions}
Here $F$ is a number field and $Y$ is a normal integral projective
$F$-variety of dimension $d\geq1$. Geometric integrality is not silently
assumed. At a place $v$, write $\mathbf C_v$ for the completed algebraic
closure of $F_v$ and $Y_v^{\mathrm{an}}$ for the corresponding analytic
space. The product-formula weight is
$n_v=[F_v:\mathbf Q_v]/[F:\mathbf Q]$.
An adelic $\mathbf R$-Cartier divisor $\overline D$ has continuous local
metrics and is induced by a model outside finitely many places. Its
geometric divisor $D$ is big. Green functions use $-\log\|s\|$, rather
than $-\log\|s\|^2$.

For its point height $h_{\overline D}$, set
\[
 \mu=\mu_{\mathrm{ess}}(\overline D)
   =\sup_{U\subseteq Y\ \mathrm{nonempty\ open}}
       \inf_{x\in U(\overline F)}h_{\overline D}(x),
 \qquad
 \mu_{\mathrm{abs}}(\overline D)
   =\inf_{x\in Y(\overline F)}h_{\overline D}(x).
\]
The essential minimum is finite in this geometric-big setting; absolute
minima appearing in the numerical hypotheses below are required to be
finite. A sequence is generic if it eventually avoids every proper closed
subset, and $\overline D$-small if its heights tend to $\mu$.
Let $\overline{[\infty]}$ have geometric divisor zero and Green function
one at every Archimedean place and zero elsewhere. Thus
$\overline D(t)=\overline D-t\overline{[\infty]}$ has the same geometric
divisor $D$ and essential minimum $\mu-t$. All endpoint limits below are
taken strictly from $t<\mu$.

For big geometric divisors $P,A$, define
\[
 r(P;A)=\sup\{\lambda>0:P-\lambda A\text{ is big}\}.
\]
A semipositive approximation of $\overline B$ is a normal modification
$\pi:Y'\to Y$ and a semipositive adelic divisor $\overline Q$ on $Y'$
with big geometric divisor $Q$ and pseudoeffective remainder
$\pi^*\overline B-\overline Q$.
Semipositive requires geometric nefness and locally semipositive metrics;
adelic nefness also requires nonnegative point heights. Let
$\Theta(\overline B)$ consist of these approximations with
$\overline Q$ adelic nef. When $\overline B$ is arithmetically big, set
\[
 \rho(\overline B;A)
  =\sup_{(\pi,\overline Q)\in\Theta(\overline B)}r(Q;\pi^*A),
 \qquad
 \rho(\overline B)=\rho(\overline B;B).
\]
In particular, $\overline D(t)$ is arithmetically big for $t<\mu$,
and the reference in $\rho(\overline D(t))$ is the fixed geometric $D$.
This radius is neither the geometric volume nor a metric distance.

\subsection*{BS.Q6.21: necessity of the inradius criterion}
\addcontentsline{toc}{subsection}{BS.Q6.21: necessity of the inradius criterion}
\label{supp:BS-Q621}
\begin{description}
\item[Full question.]
Suppose $\mu_{\mathrm{ess}}$ is G\^ateaux differentiable at
$\overline D$ in every continuous adelic $\mathbf R$-Cartier direction:
the two-sided limits
\[
 \partial_{\overline E}\mu_{\mathrm{ess}}(\overline D)
   =\lim_{\lambda\to0}
       \frac{\mu_{\mathrm{ess}}(\overline D+\lambda\overline E)-\mu}{\lambda}
\]
exist in $\mathbf R$ and define a linear functional of $\overline E$.
Must one have
\begin{equation}\label{eq:supp-BS-inradius}
 \liminf_{\substack{t\uparrow\mu\\t<\mu}}
       \frac{\mu-t}{\rho(\overline D(t))}=0?
\end{equation}
The stronger proposed converse asks whether \eqref{eq:supp-BS-inradius}
already follows from equidistribution at every place: for each $v$ there
is one probability measure $\nu_v$ such that every generic
$\overline D$-small sequence has its normalized Galois-orbit measures
$\delta_{O(x_\ell),v}$ converging weakly to $\nu_v$.
\item[Known sufficient direction.]
Published Theorem~6.17, physical p.~40, proves that
\eqref{eq:supp-BS-inradius} implies all-direction differentiability and
all-place equidistribution. By Definition~6.7 and Theorem~6.9,
physical p.~36, and Lemma~6.18, physical pp.~40--41, the criterion is
equivalent to the existence of semipositive approximations
$(\pi_m,\overline Q_m)$ with
\[
 \frac{\mu-\mu_{\mathrm{abs}}(\overline Q_m)}
      {r(Q_m;\pi_m^*D)}\longrightarrow0.
\]
Every approximant measure is divided by its own positive mass $Q_m^d$;
the target need not itself be semipositive.
\item[Known converse under an extra hypothesis.]
Proposition~7.17, physical pp.~55--56, proves equivalence of
differentiability, all-place equidistribution, and the \emph{full} limit
$(\mu-t)/\rho(\overline D(t))\to0$ if there exists a semipositive
$\overline D'$ with the same geometric divisor $D$, pseudoeffective
$\overline D'-\overline D$, and
\[
 \mu_{\mathrm{ess}}(\overline D')
 =\mu_{\mathrm{abs}}(\overline D')
 =\mu_{\mathrm{ess}}(\overline D).
\]
Theorem~8.10, physical pp.~67--68, supplies the semipositive toric
equivalence; Proposition~8.11 establishes the required upper bound in
that setting. These results retain semipositivity and the toric category.
\item[Residual scope and a successful outcome.]
Question~6.21, physical p.~43, leaves the necessity open without the
special upper bound. A resolution must prove the displayed liminf in
the general category or give a counterexample satisfying its exact
differentiability hypothesis. The stronger equidistribution converse is
a separate target: continuous local tests probe geometric-zero metric
directions and do not automatically give all-direction differentiability.
No answer follows from a failure of Zhang's lower-bound equality alone.
\end{description}

\subsection*{BS.R7.16: logarithmic tests without eventual constancy}
\addcontentsline{toc}{subsection}{BS.R7.16: logarithmic tests without eventual constancy}
\label{supp:BS-R716}
\begin{description}
\item[Full question.]
Assume $(\pi_m:Y_m\to Y,\overline Q_m)$ are semipositive approximations
of $\overline D$ satisfying the defect/inradius condition above. Put
\[
 \nu_{m,v}=(\pi_m)_*
   \frac{c_1(\overline Q_{m,v})^{\wedge d}}{Q_m^d},
 \qquad \nu_{m,v}\rightharpoonup\nu_v.
\]
For an effective Cartier divisor $E$ on $Y$, suppose the normalized
effective-cycle height gap tends to zero:
\begin{equation}\label{eq:supp-BS-cycle-gap}
 \frac{h_{\overline Q_m}([\pi_m^*E])
        -d\,\mu_{\mathrm{abs}}(\overline Q_m)
            (Q_m^{d-1}\cdot\pi_m^*E)}{Q_m^d}
     \longrightarrow0.
\end{equation}
Here $[\pi_m^*E]$ is the associated effective Weil cycle and its height
is unnormalized; the displayed factor $d$ and denominator $Q_m^d$
are part of the condition.
Must every generic $\overline D$-small sequence satisfy, at every place,
\[
 \lim_{\ell\to\infty}\int\varphi\,\rd\delta_{O(x_\ell),v}
       =\int\varphi\,\rd\nu_v
\]
for every function $\varphi$ with at most logarithmic singularities along
$E$, without requiring the approximant measures to become constant?
Such a function is real-valued and continuous away from
$\Supp(E)_v^{\mathrm{an}}$ and locally bounded in absolute value by a
constant times $\log|f_E|_v^{-1}$ after choosing a local equation with
$|f_E|_v<1$; infinite values on the support are allowed. Genericity gives
eventual avoidance of that support.
\item[What is proved.]
Corollary~7.15, physical p.~54, proves the conclusion if there is
\emph{one} $m_0$ such that
\[
 \nu_{m,v}=\nu_v\qquad\text{for every }m\geq m_0
                 \text{ and every place }v.
\]
Remark~7.16 on the same page asks whether this hypothesis can be removed.
The source records it in its dynamical setting; this is a proved special
case of the corollary, not a general stabilization theorem.
\item[More intrinsic sufficient condition.]
Theorem~7.13, physical pp.~52--53, proves logarithmic equidistribution
when an adelic extension $\overline E$ of $E$ satisfies
\begin{equation}\label{eq:supp-BS-green-equality}
 \partial_{\overline E}\mu_{\mathrm{ess}}(\overline D)
    =\sum_v n_v\int g_{\overline E,v}\,\rd\nu_v.
\end{equation}
Proposition~7.11 proves integrability of logarithmic tests under the main
approximation hypothesis. Integrability alone does not establish
\eqref{eq:supp-BS-green-equality}. Remark~7.14 proves that this equality
is independent of the chosen continuous adelic extension of $E$.
\item[The missing passage.]
The arithmetic B\'ezout formula expresses the derivative as the limit
of the cycle gap plus
$\sum_v n_v\int g_{\overline E,v}\,\rd\nu_{m,v}$.
Equation~\eqref{eq:supp-BS-cycle-gap} removes the first term.
Weak convergence controls the continuous truncations
$\min(c,g_{\overline E,v})$, but passing $c\to\infty$ still requires
control of logarithmic tails. The unresolved step is to deduce
\eqref{eq:supp-BS-green-equality} from the stated arithmetic hypotheses
without eventual constancy, or to disprove the proposed corollary in
that exact setting. Extra uniform tail bounds would give a conditional
route and must be stated as extra assumptions.
\item[Elementary obstruction to a weak-convergence-only argument.]
On $[0,1]$, let
$\eta_m=(1-1/m)\delta_1+(1/m)\delta_{\exp(-m)}$ for $m\geq2$.
Then $\eta_m\rightharpoonup\delta_1$, whereas
$\int-\log x\,\rd\eta_m=1$ and
$\int-\log x\,\rd\delta_1=0$.
This direct probability calculation explains the tail issue. It is not
an adelic counterexample to Remark~7.16.
\end{description}

The controlling locators are physical pages in the 99-page Inventiones
version of record published on 5 October 2026, DOI
\href{https://doi.org/10.1007/s00222-026-01456-y}{10.1007/s00222-026-01456-y}.
The book's 9 October source audit records a full ordered reading of that
PDF. This supplement imports source questions and known special cases;
it makes no new proof claim, no new independent verification verdict,
and no change to the canonical atom statuses. Related semiabelian
preprints are being checked separately before any further status update.

'''
anchor = r'\section*{Settled questions excluded from the active count}'
assert old.count(anchor) == 1
new = old.replace(anchor, addition+anchor)
new = new.replace('Revised catalogue: 5 October 2026', 'Revised catalogue: 9 October 2026 (targeted supplement)')
new = new.replace('conditional and source-scoped results and does not assert',
    'conditional and source-scoped results. A dated supplement gives two\narithmetic source questions outside that canonical count. It does not assert')
date_anchor = 'This targeted source check is not an exhaustive literature update.\n'
assert new.count(date_anchor) == 1
new = new.replace(date_anchor, date_anchor+
    'The 9 October supplement adds full formulations of Balla\\"y--Sombra\'s\n'
    'two arithmetic source questions and their published special cases.\n'
    'It does not reclassify the original families or renew their literature\n'
    'cutoff. The general homogeneous Siu issue below remains unresolved.\n')
note_anchor = 'and no new literature search beyond the dated source coverage.'
assert new.count(note_anchor) == 1
new = new.replace(note_anchor, 'and no exhaustive literature search beyond the dated source coverage.\n'
    'The arithmetic supplement records its own published-source reading and\n'
    'targeted 9 October searches separately from the original extraction.')
bib = r'''\bibitem[BS26Eq]{BallaySombra26Published}
Fran{\c c}ois Balla{\"y} and Mart{\'i}n Sombra.
\newblock Approximation of adelic divisors and equidistribution of small points.
\newblock {\em Inventiones mathematicae}, 2026.
\newblock Version of record published 5 October 2026.
\newblock \href{https://doi.org/10.1007/s00222-026-01456-y}{doi:10.1007/s00222-026-01456-y}.

'''
assert new.count(r'\end{thebibliography}') == 1
new = new.replace(r'\end{thebibliography}', bib+r'\end{thebibliography}')
assert old.count(r'\begin{problem}') == new.count(r'\begin{problem}') == 12
assert re.findall(r'\\label\{atom:[^}]+\}', old) == re.findall(r'\\label\{atom:[^}]+\}', new)
assert len(re.findall(r'\\label\{atom:[^}]+\}', old)) == 42
assert '(0,3,7,15,17)' in new
source.write_text(new)
(C / 'supplement_inserted_v1_20261009.tex').write_text(addition)
record = dict(UTC=datetime.now(timezone.utc).isoformat(), status='EDITED — native compilation pending',
    source=str(source), before_SHA256=sha(C/'catalogue_before_v1_20261009.tex'),
    after_SHA256=sha(source), prior_historical_PDF_SHA256=old_pdf_sha,
    source_snapshot=str(C/'catalogue_before_v1_20261009.tex'),
    inserted_supplement_SHA256=sha(C/'supplement_inserted_v1_20261009.tex'),
    formal_problem_environments=12, canonical_atoms=42, canonical_tiers=[0,3,7,15,17],
    supplementary_source_addresses=['BS.Q6.21','BS.R7.16'], canonical_status_changes=[],
    primary_source_PDF_SHA256='6be58154779c6b26cf1ec6ccf1a3645100409f9b218994a2d42b9690f00ca5be',
    published_source_pages=[36,40,41,43,52,53,54,55,56,67,68],
    full_original_primary_reading='99 pages / 50 matching ordered views, existing source receipt',
    new_primary_reading_credit=0, mathematical_verdict='No new proof or independent-model verdict',
    compile_method='Built-in compile_latex_document; preserve existing editor',
    no_replacement_document=True, historical_PDF_not_replaced=True,
    helper_source=__file__, helper_SHA256=sha(__file__))
(C / 'catalogue_edit_v1_20261009.json').write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['status','before_SHA256','after_SHA256','formal_problem_environments','canonical_atoms','supplementary_source_addresses']}))
