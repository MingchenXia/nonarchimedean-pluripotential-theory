from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, zipfile

R=Path('/workspace/nonarchimedean-pluripotential-theory'); E=R/'manuscript/editorial'
C=R/'source_material/Ballay_Sombra_catalogue_supplement_20261009'
source=R/'output/open_problems_catalogue_2026-10-03.tex'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
edit=json.loads((C/'catalogue_edit_v1_20261009.json').read_text())
audit=json.loads((C/'catalogue_source_audit_v1_20261009.json').read_text())
assert sha(source)==edit['after_SHA256']==audit['source_SHA256']
before=(C/'catalogue_before_v1_20261009.tex').read_text(); after=source.read_text()
problems=lambda s:re.findall(r'\\begin\{problem\}.*?\\end\{problem\}',s,re.S)
atoms=lambda s:re.findall(r'\\label\{atom:[^}]+\}',s)
assert problems(before)==problems(after) and len(problems(after))==12
assert atoms(before)==atoms(after) and len(atoms(after))==42
assert sha(source.with_suffix('.pdf'))==edit['prior_historical_PDF_SHA256']
book_sha='2c90129c35506ac72005c5189ff235b0e1bd52f5b529ef44e5fc58bf7dbfcfe8'
assert sha(R/'manuscript/book.pdf')==book_sha
waits=[]
for n in range(1,4):
    p=C/('native_compiler_client_wait_timeout_v%d_20261009.json'%n)
    d=json.loads(p.read_text())
    assert d.get('attempt',n)==n and not d.get('compile_success_verified',d.get('compilation_success_claimed',False)) and not d.get('compiler_failure_verdict',d.get('compilation_error_claimed',False))
    waits.append(dict(attempt=n,path=str(p),SHA256=sha(p),status=d['status'],backend_job_state=d.get('backend_job_state',d.get('native_backend_job_state'))))
checkpoint=C/'catalogue_export_checkpoint_v1_20261009.json'; assert not checkpoint.exists()
obj=dict(UTC=now(),status='SOURCE AUDITED — native compilation unverified after three calls returned no diagnostics',source_path=str(source),source_SHA256=sha(source),source_bytes=source.stat().st_size,source_audit_SHA256=sha(C/'catalogue_source_audit_v1_20261009.json'),source_questions=['BS.Q6.21','BS.R7.16'],canonical_atoms=42,formal_problems=12,canonical_tiers=[0,3,7,15,17],old_formal_problem_bodies_byte_identical=True,old_atom_labels_byte_identical=True,canonical_status_changes=[],native_compiler_calls=waits,native_compile_success_verified=False,native_compiler_failure_verdict=False,native_preview_actually_read=False,new_native_PDF_exported=False,historical_catalogue_PDF_SHA256=sha(source.with_suffix('.pdf')),historical_catalogue_PDF_pages=86,historical_PDF_current_for_updated_source=False,editor_kept_open=True,replacement_document_created=False,book_SHA256=book_sha,book_pages=4675,book_changed=False,primary_source_PDF_SHA256=edit['primary_source_PDF_SHA256'],existing_primary_reading_pages=99,existing_primary_matching_views=50,new_primary_reading_credit=0,new_original_result=False,independent_verifier_receipt=False,helper_source=__file__,helper_SHA256=sha(__file__))
checkpoint.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
prefix='Ballay_Sombra_catalogue_supplement_source_'
paths={key:E/(prefix+key+'_v1_20261009.'+ext) for key,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in paths.values())
review='''# Arithmetic source questions in the open-problem catalogue

The existing `output/open_problems_catalogue_2026-10-03.tex` has been
edited in place to add two supplementary questions from the 5 October
2026 published Ballaÿ–Sombra paper, DOI 10.1007/s00222-026-01456-y.
Its 99 physical pages were already actually read in fifty matching
text/image displays. This supplement adds no primary reading credit.

**Source audit passes; native compilation is unverified.** Three calls
to the built-in editor compiler remained pending without returning any
diagnostics. Each waiting client was ended and separately recorded;
backend job states are unknown. No source error, compiler failure, or
successful compilation has been inferred from the absence of a reply.
The same editor remains open. No replacement document or catalogue PDF
was made. The historical 86-page PDF is unchanged and is not verified
as a rendering of the updated source.

## Complete question statements and current knowledge

**BS.Q6.21:** in the normal integral projective number-field category,
for a continuous quasi-algebraic adelic real Cartier divisor with big
geometry, does all-direction Gâteaux differentiability of the essential
minimum force the defect/inradius liminf criterion? The stronger question
asks whether all-place equidistribution already forces that criterion.
The source states the sufficient direction, the exact nef-approximation
radius, and equivalence under a special semipositive upper bound with
both minima equal to the original essential minimum. Semipositive toric
special cases are retained. The general necessity is not claimed solved.

**BS.R7.16:** can logarithmic equidistribution be obtained from the
defect/inradius approximation and vanishing effective-cycle height gap
without eventual constancy of every approximant measure? The full source
condition requires one common threshold for all places. The supplement
keeps the unnormalized cycle height, dimension factor, approximant mass,
Green convention and the separate derivative/Green-integral equality.
Weak convergence and logarithmic integrability do not by themselves give
uniform control of logarithmic tails. A simple probability example only
calibrates that missing step; it is not an adelic counterexample.

The saved source provides full definitions, exact hypotheses, published
physical-page locators, known sufficient and special converse results,
the remaining scope and what would count as a resolution. A targeted
9 October search found no checked general resolution; no exhaustive
literature certification is claimed.

## Preservation and evidence

The original **twelve formal problem bodies, 42 canonical atom labels,
and thirty bibliography entries** are byte-identical. The two questions
are supplementary source addresses, outside that canonical inventory.
One bibliography entry is added; checked source labels/references have
no duplicates or unresolved targets. Tiers (0,3,7,15,17) are unchanged.
The 4,675-page active book PDF is unchanged. BJ22 homogeneous Siu and
general envelopes remain OPEN; BS Question 6.21 is explicitly separated
from the unresolved BJ22 Theorem 6.21 proof warning.

The archive contains the saved source, prior source snapshot, inserted
supplement, edit/audit/checkpoint records, three compiler-wait records
and executed helpers. No paper PDF, paper full text, page images, or
replacement catalogue PDF is redistributed. No new mathematical theorem,
independent verifier receipt or native preview reading is claimed.
'''
paths['review'].write_text(review)
paths['reading_notes'].write_text('''# Catalogue source-check notes

These are source and formula checks, not actual reading of a newly
compiled native-editor PDF. Compilation remains unverified.

1. Both supplementary questions use the published 99-page version;
   existing full primary-source reading is linked separately.
2. BS.Q6.21 retains normal integral projective geometry, number-field
   weights, big divisor, finite minima in defect conditions, strict
   t<mu endpoint and the nef-approximant geometric radius.
3. All-direction differentiability and metric-direction equidistribution
   are separate converse targets. The special upper-bound equivalence
   and toric results do not settle general necessity.
4. BS.R7.16 retains the effective Weil cycle, coefficient d, Q_m^d
   denominator, weak-limit probabilities and one common stabilization
   threshold. Green integrability is separate from derivative equality.
5. The elementary measures (1-1/m) delta_1+(1/m) delta_exp(-m) have
   weak limit delta_1, but logarithmic averages 1 rather than 0. This
   validates a tail warning only, not an arithmetic counterexample.
6. Twelve old problem bodies, 42 atom labels and thirty old bibliography
   entries remain exact. One published source entry is added. Canonical
   statuses and the active book are unchanged.
7. Three native calls returned no diagnostics; their client-wait endings
   provide neither success nor failure verdict. Preserve the same editor
   and source, and do not present the historical PDF as current.
''')
manifest=dict(obj,source_path=str(source.relative_to(R)),review=str(paths['review'].relative_to(R)),reading_notes=str(paths['reading_notes'].relative_to(R)),checkpoint_SHA256=sha(checkpoint),existing_source_audit='manuscript/editorial/Ballay_Sombra_published_source_review_20261009.md')
paths['manifest'].write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
X=E/'artifact_exports/20261009_Ballay_Sombra_catalogue_supplement_v1'; assert not X.exists(); X.mkdir()
members={'source/saved_catalogue.tex':source,'source/prior_catalogue.tex':C/'catalogue_before_v1_20261009.tex','source/inserted_supplement.tex':C/'supplement_inserted_v1_20261009.tex'}
for name in ['catalogue_edit_v1_20261009.json','catalogue_source_audit_v1_20261009.json','catalogue_export_checkpoint_v1_20261009.json','catalogue_export_helper_failure_v1_20261009.json']+[f'native_compiler_client_wait_timeout_v{i}_20261009.json' for i in range(1,4)]:
    members['records/'+name]=C/name
for name in ['Ballay_Sombra_catalogue_supplement_v1_20261009.py','Ballay_Sombra_catalogue_audit_v1_20261009.py','Ballay_Sombra_catalogue_native_wait_record_v3_20261009.py','Ballay_Sombra_catalogue_export_v1_20261009.py','Ballay_Sombra_catalogue_export_v2_20261009.py']:
    members['executed_helpers/'+name]=Path('/tmp')/name
assert len(members)==15
archive=X/'Ballay_Sombra_Catalogue_Source_Evidence_V1_2026-10-09.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(members.items()):z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert len(set(z.namelist()))==len(members)
    for name,p in members.items():assert z.read(name)==p.read_bytes()
(X/'README.md').write_text('''# Audited catalogue source; compilation unverified

The existing catalogue source adds BS.Q6.21 and BS.R7.16 with full
hypotheses, known results and unresolved scopes. Its twelve canonical
problem bodies and 42 atom labels remain exact.

The ZIP has fifteen source/audit/helper members. Three native-editor
compiler calls returned no diagnostics. No compilation success, native
preview reading or new catalogue PDF is claimed. The unchanged historical
86-page PDF is not verified as a rendering of this updated source.
''')
(X/'SHA256SUMS').write_text(sha(archive)+'  '+archive.name+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=now(),status='SOURCE EVIDENCE EXPORTED — native compilation unverified',archive=str(archive.relative_to(R)),bytes=archive.stat().st_size,SHA256=sha(archive),members=len(members),native_compile_success_verified=False,new_catalogue_PDF=False,new_reading_credit=0,canonical_status_changes=[]),indent=2)+'\n')
update='''
## Arithmetic catalogue source supplement, 9 October 2026

The existing [LaTeX catalogue](output/open_problems_catalogue_2026-10-03.tex)
now includes full statements and known results for BS.Q6.21 (necessity of
the arithmetic inradius criterion) and BS.R7.16 (logarithmic tests without
eventual measure constancy). Twelve canonical problem bodies, 42 atoms
and their tiers are unchanged. **Source audit passes; native compilation
is unverified:** three calls returned no diagnostics. The historical
86-page PDF is unchanged and is not verified as current. The same editor
and source are preserved. The 4,675-page book is unchanged.

See [source audit](manuscript/editorial/Ballay_Sombra_catalogue_supplement_source_review_v1_20261009.md)
and [source evidence](manuscript/editorial/artifact_exports/20261009_Ballay_Sombra_catalogue_supplement_v1/).
'''
readme=R/'README.md'; readme.write_text(readme.read_text().rstrip()+'\n'+update)
progress=E/'second_reading_and_research_programme_20261002.md'
pu=update.replace('(output/','(../../output/').replace('(manuscript/editorial/','(')
progress.write_text(progress.read_text().rstrip()+'\n'+pu)
owned=[source,*paths.values(),*sorted(X.iterdir()),readme,progress]; assert len(owned)==10
out=C/'catalogue_evidence_export_v1_20261009.json'; assert not out.exists()
out.write_text(json.dumps(dict(UTC=now(),status='READY FOR EXPLICIT TEN-FILE PUBLICATION — source audit only',owned_files=[dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,SHA256=sha(p)) for p in owned],archive_members=len(members),native_compile_success_verified=False,book_changed=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
print(json.dumps(dict(status='EXPORTED',owned_files=10,archive_members=15,archive_SHA256=sha(archive),export_SHA256=sha(out))))
