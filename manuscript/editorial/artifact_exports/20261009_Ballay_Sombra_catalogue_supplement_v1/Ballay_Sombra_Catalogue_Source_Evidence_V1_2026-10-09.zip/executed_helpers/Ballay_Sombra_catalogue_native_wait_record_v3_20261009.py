from pathlib import Path
from datetime import datetime, timezone
import hashlib, json
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Ballay_Sombra_catalogue_supplement_20261009')
p=Path('/workspace/nonarchimedean-pluripotential-theory/output/open_problems_catalogue_2026-10-03.tex')
q=C/'native_compiler_client_wait_timeout_v3_20261009.json'
assert not q.exists()
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),attempt=3,status='CLIENT WAIT ENDED WITHOUT RETURNED COMPILER DIAGNOSTICS',functions_cell_id='679',client_cell_terminated=True,backend_job_state='UNKNOWN',source_path=str(p),source_SHA256=hashlib.sha256(p.read_bytes()).hexdigest(),compile_success_verified=False,compiler_failure_verdict=False,source_repair_performed=False,editor_kept_open=True,replacement_document_or_PDF_created=False,reason='Third and final diagnostic call remained pending for approximately half an hour during independent source reading. Ended the waiting client; this gives no compiler success/failure verdict. No fourth call or replacement compiler is used.',helper_source=__file__,helper_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
q.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],attempt=3,record=str(q),record_SHA256=hashlib.sha256(q.read_bytes()).hexdigest())))
