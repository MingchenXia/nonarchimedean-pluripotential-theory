# Graded FS normalization and usc book review — view 2

Physical pages: [1364, 1365].

Read the complete selected text and displayed matching rendered image.

Read complete text and matching rendering of physical 1364--1365. The mixed-reduction surface retains total mass 2mc ell and compatible Raynaud data, and separates harmonic-chart forms from ordinary delta-metricity using the residual torsion condition. Section 19.8 keeps its algebraically closed complete nontrivial-ground formal-model signature; the equivalence and measure proofs retain their existing sources. The later BFJ paragraph remains restricted to discretely valued residue-characteristic-zero smooth projective model metrics. The affine growth discussion keeps upper growth, coercive lower growth and decreasing global presentation separate, including the qualified Wu source and locally finite versus globally infinite mass. The weighted finite-flat norm formula retains local Artinian lengths and residue degrees. Page boundaries, theorem continuation, displayed mass and cross-references remain clear; no new original claim enters these historical passages.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
