# Graded FS normalization and usc book review — view 1

Physical pages: [73, 1363].

Read the complete selected text and displayed matching rendered image.

Read the full contents page and the complete preceding Chapter 19 seam. L.99 is a single aligned contents row leading to printed page 4330; the long title remains fully legible, with no clipping or collision with the page number. Existing L.87--L.98 and Appendices M/N remain in order. The abelian-surface seam preserves probability-versus-degree conventions: B has determinant 3 and polarization type (1,3), giving unnormalized mass 6; the primitive-line examples give 2 and 6. Mixed-reduction descent data remain explicitly compatible rather than independently chosen. No change to these historical formulas or source scopes is introduced by the new section.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
