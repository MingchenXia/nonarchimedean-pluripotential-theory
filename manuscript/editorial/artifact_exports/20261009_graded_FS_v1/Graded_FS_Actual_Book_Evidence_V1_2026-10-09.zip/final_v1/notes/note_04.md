# Graded FS normalization and usc book review — view 4

Physical pages: [1368, 4407].

Read the complete selected text and displayed matching rendered image.

Read full text and matching image of 1368 and 4407, the downstream Chapter 19 seam and preceding L.98 seam. The comparison theorem keeps ample L, positive mass V, normal flat projective models and completed-extension delta/curve tests separate. Its signed dpsh model extension is distinguished from positive Bedford--Taylor products and its continuous locus from singular local psh. The L.98 boundary keeps disjoint value cosets, the open cut I and nonfinite closure explicit, and does not contradict the algebraically closed norm proof. Logarithmic integrability still requires a regular Cartier section and global continuous psh-regularizable tuples, including the dimension-zero case. The regularized-max construction uses two explicitly regularizable metrics and decreases, unlike the increasing new FS example; the differing directions are coherent and clearly stated. No display, delimiter, reference or pagination defect is visible.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
