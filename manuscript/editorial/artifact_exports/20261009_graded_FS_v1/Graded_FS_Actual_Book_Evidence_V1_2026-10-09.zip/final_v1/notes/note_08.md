# Graded FS normalization and usc book review — view 8

Physical pages: [4621, 4622].

Read the complete selected text and displayed matching rendered image.

Read every index entry on 4621--4622 and matching image, spanning cone continuation, C/D/E/F and the beginning of G. Horizontal and vertical divisors, divisorial analytic points and trivially valued valuations retain separate entries. Envelope history, continuity-where-used, weak-psh descent, rooftop and singularity type remain distinguished. The new Fubini--Study metric subentry 'upper semicontinuous regularization' points to printed 4330 (L.99), wraps safely within its column and sits beside the existing projective-line computation. Absolute and signed conventions are not represented as interchangeable by any new index text. Extended-real forbidden subtraction, finite descent, Gauss extension mass bookkeeping and geodesic/filtration entries remain legible and alphabetically ordered. No overflow, misplaced link or dropped hierarchy is visible; index reading adds no primary proof/status credit.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
