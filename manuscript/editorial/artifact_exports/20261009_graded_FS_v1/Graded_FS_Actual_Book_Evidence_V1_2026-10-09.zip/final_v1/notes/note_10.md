# Graded FS normalization and usc book review — view 10

Physical pages: [4625, 4626].

Read the complete selected text and displayed matching rendered image.

Read all entries and matching rendering on 4625--4626, spanning moment/Monge--Ampere through N/O and P/Q. Probability-normalized versus mixed/model/local curvature measures have distinct targets, as do BFJ and BJ energies and finite-dimensional versus finite-flat norms. Net/no-cofinal-sequence, zero-volume Okounkov regime and open-problem ledgers remain explicitly indexed. The plurisubharmonic-family list separates BFJ, CLD, local valuative and transcendental notions, consistent with the new paragraph's scope. Minus-log and Poincare--Lelong normalizations remain separately referenced. Long norm and comparison subentries wrap inside their columns; all mathematical glyphs, accents, indentation and page links are clear. No new entry or status claim is introduced in this portion, and no repair is required.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
