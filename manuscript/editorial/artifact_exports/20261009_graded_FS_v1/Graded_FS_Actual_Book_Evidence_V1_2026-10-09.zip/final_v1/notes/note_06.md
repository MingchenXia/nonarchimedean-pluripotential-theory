# Graded FS normalization and usc book review — view 6

Physical pages: [4410, 4411].

Read the complete selected text and displayed matching rendered image.

Read full text and matching image of 4410--4411. The local frame X0 and rho=|T| are explicit. The max expression yields finite -log 2 at rho=0, agrees with log rho for rho>=1, and increases to standard FS away from T=0. Positive-radius Gauss points approaching zero show the raw downward jump fails usc. Continuous global FS minorants yield Q(raw)=raw by two opposite inequalities, while Q(raw)^usc equals standard FS, without any general envelope-continuity premise. Source locator BE21 7.26 and Reboulet Definition 5.2.4 match their directly reviewed statements. The final scope paragraph keeps dense-valued lattice density, big/ample semigroup requirements, Fekete direction and nontrivial-ground horizontal valuation typing separate; it neither refutes a properly formulated general correspondence nor repairs BJ22 6.21. Appendix M begins on a clean new page and retains its P06.1 versus continuous zero-current P06.2 distinction and dated-receipt caveat. Cases, superscript star, infinity convention, references and page transitions are clear. No repair is needed.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
