# Graded FS normalization and usc book review — view 3

Physical pages: [1366, 1367].

Read the complete selected text and displayed matching rendered image.

Read complete physical 1366--1367 text and individual matching image. The new common-core paragraph correctly separates signed normalized volume from absolute d1, confines the zero-asymptotic-distance statement to the explicit P1 monomial norm, and gives normalized operator distance log 2. It describes increasing continuous global FS metrics, a bounded raw downward jump and its usc correction, with the full proof delegated to L.99. The concluding qualification continues onto 1367 and remains visible before the next section; it supplies neither universal envelope continuity nor arbitrary local weak-psh descent. Reb20FS is resolved and cited as a qualified 2020 source. The preceding section-norm/integrability signatures remain intact. Section 19.9 retains discretely valued residue-characteristic-zero BFJ hypotheses, normalization v(pi)=1, normal flat projective models, and the separate completed-algebraic-closure setting for delta/curve tests. Its dictionary remains aligned, with vertical-divisor multiplicities and minus-log metric changes clear. No repair is needed.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
