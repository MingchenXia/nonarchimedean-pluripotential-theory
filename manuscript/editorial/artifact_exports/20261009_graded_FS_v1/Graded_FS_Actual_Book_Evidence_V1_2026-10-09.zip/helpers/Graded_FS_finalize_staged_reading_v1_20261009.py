# Adapted frozen finalizer SHA256: b28cf6a3f48001debd06629d44b96968c7812ede1d641695f83a549bf77abe42
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, json, re, subprocess, difflib

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Reboulet_asymptotic_FS_review_20261009'
S=Path('/workspace/book-completion-drafts/graded-FS-staging-v1-20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
release=C/'staged_book_release_checks_v1_20261009.json'
ch=json.loads(release.read_text())
manifest=Path(ch['manifest_path'])
assert sha(manifest)==ch['manifest_SHA256']
xs=json.loads(manifest.read_text())
views=[]
last=None
for x in xs:
    assert not x['actually_viewed'] and not x['selected_text_read']
    n=C/'staged_book_notes_v1'/f"note_{x['number']:02d}.md"
    r=n.with_name(n.stem+'_receipt.json')
    receipt=json.loads(r.read_text())
    assert 'Read the complete selected text and displayed matching rendered image' in n.read_text()
    assert receipt['complete_selected_text_actually_read']
    assert receipt['matching_image_individually_displayed_and_reviewed']
    assert receipt['number']==x['number'] and receipt['physical_pages']==x['physical_pages']
    assert receipt['source_PDF_SHA256']==ch['PDF']['SHA256']
    assert sha(n)==receipt['note_SHA256']
    assert sha(x['path'])==receipt['image_SHA256']==x['image_SHA256']
    assert sha(x['selected_text_path'])==receipt['selected_text_SHA256']==x['selected_text_SHA256']
    assert last is None or receipt['UTC']>last
    last=receipt['UTC']
    y={k:v for k,v in x.items() if k not in ['actually_viewed','selected_text_read']}
    y.update(inspection_mode='Fresh complete text and individual matching image display',
             actual_complete_text_read=True,actual_matching_image_freshly_displayed=True,
             sequential_note_path=str(n),sequential_note_SHA256=sha(n),
             observation_receipt_path=str(r),observation_receipt_SHA256=sha(r))
    views.append(y)
pages=sorted({p for x in xs for p in x['physical_pages']})
assert pages==ch['selected_book_physical_pages']
assert sum(len(x['physical_pages']) for x in xs)==len(pages)
reading=C/'actual_staged_book_reading_v1_20261009.json'
audit=C/'staged_mathematical_self_audit_v1_20261009.json'
post=C/'post_render_checks_v1_20261009.json'
assert not any(q.exists() for q in (reading,audit,post))
prep=json.loads((C/'staging_preparation_v1_20261009.json').read_text())
checks=[]
for command in (['python3','editorial/tools/refcheck.py'],
                ['python3','editorial/tools/check_open_problem_inventory.py']):
    run=subprocess.run(command,cwd=S/'manuscript',text=True,
                       stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    assert run.returncode==0,run.stdout
    checks.append(dict(command=command,returncode=run.returncode,output=run.stdout))
for n,h in prep['after'].items():
    assert sha(S/n)==h
for n,h in prep['other_active_TeX_preserved'].items():
    assert sha(R/n)==sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():
    assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
for n,h in prep['native_catalogue_preserved'].items():
    assert sha(R/n)==h
for n,h in prep['unchanged_bibliographies'].items():
    assert sha(R/n)==sha(S/n)==h
assert (S/'manuscript/bibliography/NonArchimedean.bib').read_bytes()==(R/'manuscript/bibliography/NonArchimedean.bib').read_bytes()+Path(prep['draft_path'],'NonArchimedean_graded_FS_entry.bib').read_bytes()
assert prep['new_bibliographic_keys']==['Reb20AsymptoticFSV1']
historical={}
whitespace={}
for n in ('manuscript/parts/part2/ch19_cld_examples.tex','manuscript/appendices/appL_provenance.tex'):
    before=(R/n).read_text()
    after=(S/n).read_text()
    counts={}
    for env in ('theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important'):
        patt=r'\\begin\{'+env+r'\}.*?\\end\{'+env+r'\}'
        blocks=re.findall(patt,before,re.S)
        assert all(b in after for b in blocks)
        assert len(blocks)==len(re.findall(patt,after,re.S))
        counts[env]=len(blocks)
    tags=re.findall(r'\\tag\{([^}]+)\}',before)
    assert tags==re.findall(r'\\tag\{([^}]+)\}',after)
    historical[n]=dict(byte_preserved_environment_blocks=counts,prior_manual_equation_tags=tags)
assert sum(sum(v['byte_preserved_environment_blocks'].values()) for v in historical.values())==92
assert sum(v['byte_preserved_environment_blocks']['proof'] for v in historical.values())==25
assert sum(len(v['prior_manual_equation_tags']) for v in historical.values())==6
for n in prep['after']:
    before=(R/n).read_text().splitlines()
    after=(S/n).read_text().splitlines()
    wb=Counter(x for x in before if x!=x.rstrip())
    wa=Counter(x for x in after if x!=x.rstrip())
    assert wb==wa
    added=[x[2:] for x in difflib.ndiff(before,after) if x.startswith('+ ')]
    assert all(x==x.rstrip() for x in added)
    run=subprocess.run(['git','diff','--no-index','--check',str(R/n),str(S/n)],
                       text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    assert run.returncode in (0,1) and run.stdout=='',(run.returncode,run.stdout)
    whitespace[n]=dict(historical_whitespace_lines_preserved=sum(wb.values()),
                       added_lines_checked=len(added),added_trailing_whitespace_lines=0,
                       no_index_returncode=run.returncode,no_index_diagnostic_output=run.stdout,
                       EOF_whitespace_check='PASS')
for q,h in prep['draft_fragments'].items():
    assert sha(q)==h
    assert all(x==x.rstrip() for x in Path(q).read_text().splitlines())
underfull=json.loads((C/'staged_underfull_delta_v1_20261009.json').read_text())
reading.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — all selected book pages freshly read and individually displayed',
    PDF=ch['PDF'],actual_unique_book_pages=len(pages),
    fresh_complete_text_and_individually_displayed_pages=len(pages),
    fresh_matching_views=len(views),reused_exact_complete_text_and_rendered_pixel_pages=0,
    reused_matching_views=0,views=views,legacy_preparation_flags_rewritten=False,
    remaining_repairs=[],whole_book_new_reading_claim=False,
    active_book_changed=False,GitHub_published=False,canonical_status_changes=[],
    helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
mathchecks=['Complete pinned Reboulet arXiv 2004.11635v1: all 43 pages, 22 individual matching images and chronological notes. Prior published BE21 global checkpoint covers 12 pages in six views, and its four-checkpoint union is 58 of 125 pages. External foundations are attributed, not recursively certified. The later published Reboulet edition has not been audited.', 'Spectral probability divides by nonzero section dimension N_m. Signed logarithmic mean is relative volume; absolute mean is d_1. The normalized infinity distance takes the largest absolute ratio. Hilbert growth retains vol(L)/n!, and a Veronese degree k corresponding to rk multiplies normalized weights by r; divide the regraded volume by r before comparison.', 'For any complete non-Archimedean K, the P1 O(1) norms eta_m=max|a_i| and zeta_m=max(2^m|a_0|,|a_1|,...,|a_m|), with ground absolute value in degree zero, are diagonal and submultiplicative. Gauss product and penalized constant coefficient bounds separately prove the product inequality. eta_m<=zeta_m<=2^m eta_m gives explicit logarithmic O(m) boundedness.', 'With a=log 2 and logarithmic ratios eta/zeta, sigma_m=(delta_-a+m delta_0)/(m+1), d_1/m=a/(m+1) tends to zero, d_infinity/m=a, and sigma_m converges weakly to delta_0. This is a direct worked instance of the cited known distinction, without proving a general quotient correspondence.', 'The homogeneous FS formula in the X0 frame is phi_m=m^-1 log max(2^-m,rho,...,rho^m): max(-a,log(rho)/m) for rho<=1 and log(rho) for rho>=1. log 0 is negative infinity but the weight is finite. Each is a continuous global FS metric and this particular sequence increases. The raw limit differs from standard phi_0 only by a downward jump -a at T=0.', 'Positive-radius Gauss points converge to T=0 with raw weight zero. Thus raw phi is not upper semicontinuous and phi*=phi_0. Every phi_m is a continuous global psh minorant of phi; the obstacle upper bound proves Q(phi)=phi and Q(phi)*=phi_0. This explicit bounded-obstacle computation uses no general continuity-of-envelopes premise.', 'The general Reboulet v1 correspondence explicitly assumes continuity of envelopes and ample polarization. The pinned proof needs correctly typed determination and approximation inputs. Dense diagonal norms do not imply dense lattice norms without dense value group; semiample need not be big or recover X by Proj; superadditive degree numerators need not have decreasing divided averages.', 'Horizontal c ord_E is trivial on K* and does not define the prescribed analytic point over a nontrivially valued K. An applicable analytic valuation family and uniqueness theorem are necessary; no blanket assertion that merely vertical divisors handle every complete ground field is made.', 'Thirteen exact source diagnostic families remain frozen, including normalization, energy cocycle orientation, closed-tail endpoint, minimum-of-norms failure and the explicit P1 computation. They diagnose the controlling v1 formulas and proof interfaces, without declaring the intended correctly formulated general theorem false.', 'The two changed TeX roots preserve 92 historical environment blocks including 25 proofs and six manual tags. No new formal environment or manual tag is added; all other 423 core TeX inputs remain byte unchanged. NonArchimedean.bib appends precisely the pinned Reb20AsymptoticFSV1 entry; ComplexGeometry.bib is unchanged. All 13,379 prior numbered values and 596 citation labels are preserved.', 'The native catalogue/editor, 42 canonical atoms and twelve formal problems retain their statuses. General BJ22 critical homogeneous Siu/envelopes remain OPEN, LPWZ density UNVERIFIED. The BJ22 6.21 proof warning remains binding; no original general theorem, independent-model receipt or new complete whole-book reading is claimed.']

audit.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — ordinary scoped mathematical audit and actual rendered clearance',
    checks=mathchecks,source_input_hashes=prep['after'],draft_fragments=prep['draft_fragments'],
    actual_final_book_reading_SHA256=sha(reading),actual_final_book_reading_credit=len(pages),
    source_scope='Complete pinned Reboulet2004.11635v1: 43 primary pages/22 views; published BE21 global checkpoint 12 pages/6 views and four-checkpoint union 58 of 125; external foundations attributed',
    exact_diagnostics_SHA256=sha(C/'exact_diagnostics_v1_20261009.json'),
    underfull_comparison_SHA256=sha(C/'staged_underfull_delta_v1_20261009.json'),
    new_underfull_blocks=underfull['added_blocks'],original_results_promoted=[],
    independent_model_receipt=None,canonical_status_changes=[],whole_book_new_reading_claim=False,
    helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
post.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE',
    checks=checks,source_input_hashes=prep['after'],rendered_gate_SHA256=sha(reading),
    historical_formal_proof_warning_important_blocks_byte_preserved=historical,
    other_active_TeX_inputs_byte_preserved=423,whitespace_gate='PASS including EOF',
    whitespace_details=whitespace,legacy_writing_audit_unavailable=True,
    manual_semantic_delimiter_source_and_rendered_audits_used=True,
    active_book_changed=False,GitHub_published=False,canonical_status_changes=[],
    helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',actual_reading_SHA256=sha(reading),
                     math_audit_SHA256=sha(audit),post_render_SHA256=sha(post),
                     actual_pages=len(pages),fresh_views=len(views))))
