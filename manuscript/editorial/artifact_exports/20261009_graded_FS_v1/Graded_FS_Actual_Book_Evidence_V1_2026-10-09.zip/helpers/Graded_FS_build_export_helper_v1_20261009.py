from pathlib import Path
import hashlib
old=Path('/tmp/Supnorm_integrability_export_staged_checkpoint_v1_20261009.py')
p=Path('/tmp/Graded_FS_export_staged_checkpoint_v1_20261009.py');assert not p.exists()
t=old.read_text();top=t[:t.index("paths['audit'].write_text")];tail=t[t.index("with zipfile.ZipFile(prep['baseline_minimal_source']['path'])"):]
for a,b in [('BE21_reduced_fibre_integrability_review_20261009','Reboulet_asymptotic_FS_review_20261009'),('supnorm-integrability-staging-v1-20261009','graded-FS-staging-v1-20261009'),('BE21_supnorm_integrability','graded_FS'),('Supnorm_Integrability','Graded_FS'),('np==4659 and nb==24 and nv==12','np==4661 and nb==25 and nv==13'),("math['source_scope'].startswith('Published BE21 partial union 53')","math['source_scope'].startswith('Complete pinned Reboulet2004.11635v1')"),('Section supnorms, reduced fibres and logarithmic integrability — actual book review','Graded norm normalization and upper semicontinuous FS limits — actual book review')]:
 top=top.replace(a,b);tail=tail.replace(a,b)
tail=tail.replace("for q in Path('/tmp').glob('Supnorm_integrability_*_v1_20261009.py'):","for q in sorted(Path('/tmp').glob('Graded_FS_*_v*_20261009.py')):")
tail=tail.replace(",norm_basechange_publication_record_SHA256=prep['norm_basechange_publication_SHA256']",'')
middle=r'''paths['audit'].write_text(f"""# Graded norm normalization and upper semicontinuous FS limits: book integration

Date: 9 October 2026. The checked staged book has {np:,} pages.
Chapter 19's common core now leads to L.99, “Graded norm normalization
and upper semicontinuous FS limits.” The section distinguishes signed
relative volume from absolute spectral distance, retains Hilbert's n!
and fixes degree scaling under Veronese restriction. Its explicit P1
calculation proves submultiplicativity, logarithmic boundedness, vanishing
asymptotic d1 and a nonzero normalized operator distance. The continuous
FS metrics increase to a bounded raw limit with a downward jump at T=0;
positive-radius Gauss points show that its usc regularization is standard
FS. The continuous-psh minorant envelope Q equals the raw obstacle, while
Q* is the standard metric. This computation requires no general envelope
continuity hypothesis and asserts no general quotient correspondence.

The controlling primary is Reboulet arXiv 2004.11635v1, 24 April 2020.
All 43 pages were actually read with 22 individual matching image displays
and chronological notes. Thirteen elementary diagnostic families are
frozen. The nine-file authored source unit was published and remotely
verified at 51905508d307a13c1c2cb9342992d00dbb7235d9. The later Math. Z.
published edition has not been audited. The previous published BE21
global-approximation checkpoint covers 12 pages in six views; its four
related checkpoints have a union of 58 of 125 pages, leaving 67 unread
in that union. Earlier external foundations remain attributed.

The general Reboulet v1 comparison retains ampleness, envelope continuity
and separately applicable determination/approximation inputs. Lattice
density needs a dense value group; semiample alone need not be big or
recover X by Proj. Submultiplicativity does not make divided FS averages
decreasing. Horizontal c ord_E is trivial on K* and cannot represent the
prescribed analytic point over a nontrivially valued field. These source
qualifications do not declare the intended correctly formulated theorem
false and do not import arbitrary local weak-psh descent.

All {nb} selected final pages were freshly read with complete text in
{nv} individually displayed matching views and sequential notes/receipts:
contents, complete common core and seams, complete L.99 and seams, all
12 affected index pages, and the complete new bibliography entry.
Preparation flags stay frozen false; there is no reused page credit and
no new whole-book-reading claim. The last complete ordered pass is 4 October.

Full validation, six existing tests, references and canonical inventory
pass. Post-render reference/inventory, semantic, notation, delimiter,
source and whitespace audits pass. The unavailable legacy writing audit
is not reported as an automated pass. No TeX errors, LaTeX/package/pdfTeX
warnings, missing glyphs, overfull boxes, unresolved references/citations
or rerun requests occur. All 955 underfull blocks have identical normalized
text and multiplicities. All {release['all_prior_numbered_label_values_preserved']:,}
prior numbered values and 596 citation labels are preserved; the new pinned
Reb20AsymptoticFSV1 entry renders as Reb20FS, for 597 total citations.
All {release['index']['accepted']} index entries are accepted with no warnings
or rejections. All {release['navigation']['internal_links']:,} internal links
pass; external URL availability is not certified. One semantic label,
one contents row and two index terms are added.

The two changed TeX roots preserve 92 historical environment blocks,
including 25 proofs, and six manual tags. No new formal environment or
manual tag is added; the other 423 core TeX inputs are byte unchanged.
NonArchimedean.bib retains its old byte prefix and appends one newline
plus the pinned new entry; ComplexGeometry.bib is unchanged. The first
finalizer wrongly expected no separating newline and stopped before
writing final gates; that helper and failure record are frozen. The fresh
v2 finalizer checks the exact correct bytes and passes. No source or
compiled-stage change was needed for that preflight correction.

Native catalogue/editor, 42 atoms/twelve problems and their statuses stay
unchanged. General BJ22 critical homogeneous Siu/envelopes remain OPEN,
LPWZ density UNVERIFIED, and the BJ22 Theorem 6.21 proof warning remains
binding. No original general theorem or independent-model receipt is claimed.

The mathematical audit checks:

"""+''.join(f'{i}. {a}\n\n' for i,a in enumerate(math['checks'],1))+"""The four owned exports are byte verified. Activation and remote publication
receive separate later records. Preparation, export and upload provide
zero actual reading credit. External primary PDFs remain in the cloud.
""")
paths['reading_notes'].write_text(f'# Actual rendered-book notes, 9 October 2026\n\n{nb} complete pages read in {nv} individual matching displays. No reuse; preparation flags stay frozen.\n'+''.join('\n---\n\n'+Path(a['sequential_note_path']).read_text() for a in reading['views']))
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md'
marker='## Latest asymptotic Fubini–Study source checkpoint, 9 October 2026\n'
t=(R/programme).read_text();assert t.count(marker)==1
intro=f"""## Latest graded-norm and upper semicontinuous FS book checkpoint, 9 October 2026

The [integration audit](graded_FS_staged_integration_audit_v1_20261009.md)
adds Chapter 19's common-core paragraph and L.99. Its direct P1 computation
separates asymptotic d1 from normalized operator distance, and the bounded
raw FS limit Q from its usc regularization Q*. Signed/absolute means,
Hilbert n! and Veronese degree scaling remain explicit. The controlling
Reboulet v1 general comparison retains its envelope and determination
qualifications; no general correspondence is independently established.

The {np:,}-page book passes full validation and post-render gates. All {nb}
selected pages were freshly read in {nv} individually displayed matching
views with complete text and sequential notes. All 955 underfull blocks,
13,379 prior numbered values and 596 citation labels are preserved. One
pinned bibliography entry makes 597 citations. The other 423 TeX inputs
and ComplexGeometry.bib are unchanged; 92 historical blocks including
25 proofs and six manual tags are preserved. The separating-newline
finalizer preflight failure is frozen; the fresh v2 passes with no source
change. All 43 Reboulet v1 primary pages were actually read in 22 views;
BE21 has a partial four-checkpoint union of 58 of 125 pages.

The [activation record](graded_FS_cloud_activation_v1_20261009.json)
controls this cloud edition; publication receives a separate later record.
Native catalogue/editor and 42 atoms/twelve problem statuses stay unchanged.
General BJ22 critical homogeneous Siu/envelopes remain OPEN and LPWZ density
UNVERIFIED. No original general theorem, independent-model receipt or new
complete ordered book reading is claimed; the latter remains 4 October.
Continue cloud-only related primary reading, sequential open-problem
interfaces, incoming author-update checks and regular checked pushes.
Xean stays suspended.

"""
(S/programme).write_text(t.replace(marker,intro+marker,1))
t=(R/'README.md').read_text();assert t.count('**4,659 pages**')==1;t=t.replace('**4,659 pages**',f'**{np:,} pages**')
marker='**Latest asymptotic Fubini–Study primary checkpoint, 9 October 2026:**';assert t.count(marker)==1
intro=f"""**Latest checked graded-norm and upper semicontinuous FS integration, 9 October 2026:**
the [integration audit](manuscript/editorial/graded_FS_staged_integration_audit_v1_20261009.md)
adds Chapter 19's common-core paragraph and L.99. A direct P1 calculation
separates asymptotic d1, normalized operator distance and raw/usc FS limits;
signed means and Veronese scaling are explicit. The Reboulet v1 general
comparison retains its qualified proof dependencies. All {nb} affected
pages were freshly read in {nv} individual matching displays; validation
and post-render checks pass. The
[activation record](manuscript/editorial/graded_FS_cloud_activation_v1_20261009.json)
controls the {np:,}-page cloud edition. One pinned bibliography entry is
added. Native editor and canonical statuses stay unchanged; general
Siu/envelope questions remain OPEN. No original general theorem or new
whole-book reading is claimed.

"""
(S/'README.md').write_text(t.replace(marker,intro+marker,1))
'''
p.write_text('# Adapted frozen exporter SHA256: '+hashlib.sha256(old.read_bytes()).hexdigest()+'\n'+top+middle+tail)
compile(p.read_text(),str(p),'exec')
print(p)
