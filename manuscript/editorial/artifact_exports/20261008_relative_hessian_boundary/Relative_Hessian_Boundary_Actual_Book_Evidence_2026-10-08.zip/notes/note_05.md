# Relative Hessian boundary and mass actual book view 05

UTC: 2026-10-08T21:39:54.155505+00:00. Physical pages: 4391, 4392.

Read the complete selected text and displayed matching rendered image. Physical page 4391 closes the radial common-boundary diagnostic: the beta-integral is 3/4, the uniform energy bound is 11/4, and the limit is -53/28. The canonical integer truncations coincide with the infinite-total-mass limit, so basic-class membership fails even with the common trace; the paragraph expressly preserves local one-factor distributional continuity. The separate Section 6 constant-shift test forces finite admissible data to vanish and does not assert admissibility of the earlier nonzero density. Singular-reference and moving-product limitations remain stated. Formulas, exponents, and qualifiers are legible without overflow. Physical page 4392 is an intentional blank before Appendix M, with no orphaned concluding text.
