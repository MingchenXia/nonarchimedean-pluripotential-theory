# Relative Hessian boundary and mass actual book view 12

UTC: 2026-10-08T21:40:54.925152+00:00. Physical pages: 4612, 4640.

Read the complete selected text and displayed matching rendered image. Physical page 4612 is the intentional blank after the Index. Physical page 4640 contains the complete TD26H bibliography entry, with author Truong Dinh Dat, exact title, 2026, version 1 posted 10 September 2026 and the explicit boundary/mass audit qualification. Its link and shorthand render legibly; no general theorem is attributed as imported. Every surrounding complete selected bibliography line from Sup26h through Vig19 was read, including preserved edition and limited-source-reading notes. The dense reference layout stays within margins and the new entry neither clips its title nor merges with Tem04. This completes fresh paired reading of all 24 selected physical pages in the final v4 rendering; it does not claim a new whole-book reading.
