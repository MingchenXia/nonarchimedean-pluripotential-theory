# Relative Hessian boundary and mass actual book view 07

UTC: 2026-10-08T21:40:11.910255+00:00. Physical pages: 4602, 4603.

Read the complete selected text and displayed matching rendered image. Physical pages 4602-4603 continue the complete Index from Berkovich-line entries through envelope/BFJ. Both columns, alphabetic section changes, continuation of contraction across the page boundary, and all intervening locators were read. Capacity, CLD, comparison frameworks, covolume, curvature, differential calculus, dual energy and entropy remain differentiated by their subentries. Linked page numbers render cleanly; long existing comparison names wrap within their column. No clipping, overlapping columns, lost continuation or new unsupported status assertion appears in this shifted index region.
