# Relative Hessian boundary and mass actual book view 02

UTC: 2026-10-08T21:36:02.061643+00:00. Physical pages: 3108, 3109.

Read the complete selected text and displayed matching rendered image. Final v4 pages 3108–3109 include the entire local boundary/mass paragraph and its unchanged compact normalization and increasing-net neighbors. The local disk is explicitly separate from compact X; D_0=2 dd^c, reference psi=|z|^2-2, same-measure shifts, distinct boundary traces and the common-trace mass warning are all stated accurately. L.94 and TD26H links resolve visibly. Existing subsection 51.6.6, equation 51.19 and the warning on nonpluripolar decreasing limits retain their hypotheses and scope. The addition makes no unsupported import from the new preprint. Formula glyphs, source links, warning frame and page seam are legible; no repair was found.
