# Relative Hessian boundary and mass actual book view 06

UTC: 2026-10-08T21:40:03.041316+00:00. Physical pages: 4393, 4601.

Read the complete selected text and displayed matching rendered image. Physical page 4393 begins Appendix M on a recto after the intentional blank. Its zero-current status distinguishes the supplied classical-pluriharmonic theorem from the remaining continuous-function residual; the prior regularity scopes and verification receipts are preserved. Links to Theorem 18.12.1, Problem 72.1.5 and Chapter 72 render clearly. Physical page 4601 is the Index opening: A and B entries occupy balanced columns; the earlier higher-rank abeloid entry now points to printed page 4308. All displayed entries and page locators were inspected, including the continuation from abelian varieties through Berkovich affine-line types. No new spill or obscured line appears.
