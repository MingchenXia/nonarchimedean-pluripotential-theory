# Relative Hessian boundary and mass actual book view 08

UTC: 2026-10-08T21:40:19.749988+00:00. Physical pages: 4604, 4605.

Read the complete selected text and displayed matching rendered image. Physical pages 4604-4605 continue the Index from envelope subentries to Laurent domains. Every selected entry was inspected in both columns, including finite-energy measures/potentials with distinct BFJ and BJ locators, Gauss-extension bookkeeping, higher-rank and general background topics. The two added Hessian equation subentries, boundary normalization and relative energy and total mass, both visibly link to printed page 4310, the beginning of L.94. They remain separate from the existing Hessian equations/relative bounds and Hessian operators/integral comparison entries. Alphabetic headings, continuation of Green function, typography and hyperlink-number spacing are coherent; no clipped line or overflow was found.
