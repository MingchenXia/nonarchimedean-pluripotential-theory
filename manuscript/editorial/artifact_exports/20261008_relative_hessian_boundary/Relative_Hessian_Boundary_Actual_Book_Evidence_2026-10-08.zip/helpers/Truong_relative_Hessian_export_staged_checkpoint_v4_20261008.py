from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, zipfile, fitz

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Truong_relative_Hessian_review_20261008'
S=Path('/workspace/book-completion-drafts/relative-Hessian-staging-v4-20261008')
E=R/'manuscript/editorial';O=Path('/workspace/book-completion-drafts/research-integration')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(n):return json.loads((C/n).read_text())
prep=load('staging_preparation_v4_20261008.json')
release=load('staged_book_release_checks_v4_20261008.json')
reading=load('actual_staged_book_reading_v4_20261008.json')
post=load('post_render_checks_v4_20261008.json')
math=load('staged_mathematical_self_audit_v4_20261008.json')
underfull=load('staged_underfull_delta_v4_20261008.json')
assert reading['status'].startswith('DONE') and not reading['remaining_repairs']
assert not underfull['added_blocks'] and all(x['returncode']==0 for x in post['checks'])
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
np=release['PDF']['physical_pages'];nb=reading['actual_unique_book_pages'];nv=reading['fresh_matching_views']
assert nb==len(release['selected_book_physical_pages']) and nv==len(reading['views'])
full=O/'Non-Archimedean_Pluripotential_Theory_Relative_Hessian_Boundary_Staged_Preview_2026-10-08.pdf'
review=O/'Relative_Hessian_Boundary_Staged_Book_Review_2026-10-08.pdf'
minimal=O/'Relative_Hessian_Boundary_Staged_Minimal_Source_2026-10-08.zip'
evidence=O/'Relative_Hessian_Boundary_Actual_Book_Evidence_2026-10-08.zip'
record=C/'staged_export_v4_20261008.json'
paths={k:E/f'Truong_relative_Hessian_staged_integration_{k}_20261008.{ext}' for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in [full,review,minimal,evidence,record,*paths.values()])
shutil.copy2(release['PDF']['path'],full);assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as book:
 d=fitz.open()
 for n in release['selected_book_physical_pages']:d.insert_pdf(book,from_page=n-1,to_page=n-1)
 assert len(d)==nb
 d.set_metadata(dict(title='Relative Hessian boundary and total mass — book review, 8 October 2026',subject=f'{nb} actually reviewed pages; export adds no reading credit.'))
 d.save(review,garbage=4,deflate=True);d.close()
paths['audit'].write_text(f'''# Relative Hessian boundary and total mass: integration audit, 8 October 2026

The validated staged edition has {np:,} pages. A paragraph in 51.6.5 and new L.94 separate local Dirichlet boundary data from compact constant normalization, and weighted relative energy from unweighted total mass near a domain boundary. The source operator is explicitly D_0=2 dd^c; the binding book operator is unchanged.

With the smooth reference psi=|z|²−2 on the disk, u=−3, v=psi−1 and w=psi−2 have Hessians 0,beta_0,beta_0 and signed energies −3/2,−2,−4. Strict decreasing approximants verify membership under the source definitions. The literal punctured-disk comparison integrals are 2 and 0; distinct v,w have the same nonzero measure. A stationary sequence w with target v tests unnormalized stability. The L-infinity density is not asserted to satisfy the source's separate Theorem 6.1 measure hypothesis. A smooth unit-ball C² example gives global integration-by-parts integrals 4 and 0 and isolates the discarded Stokes boundary term.

The common-trace radial family has alpha=3/4, h_epsilon(s)=−(1−s+epsilon)^alpha+epsilon^alpha and f_epsilon=psi+h_epsilon. Its total mass is 2+(3/2)epsilon^(−1/4), but its absolute signed energy is at most 11/4 and tends to −53/28. The limit is locally smooth with infinite total mass; every integer canonical truncation equals that limit and is outside the printed basic finite-global-mass class. The example does not refute local one-factor distributional continuity. The constant-shift test forces zero data mass under the unnormalized measure inequality; the changed Section 6 definition also permits positive energies in the printed square root. Singular products, tails, moving tests, smoothing hypotheses and nonmonotone limits remain separate proof obligations. No replacement general existence theorem is asserted.

The controlling source is arXiv:2609.12032v1, posted 10 September 2026. All 26 physical pages were actually read in thirteen matching individual displays with sequential notes. Its general theorems are excluded under the literal definitions; external bibliography proofs are not recursively certified. The extraction font warning, failed symbolic branch-limit and failed manually copied catalogue-hash assertion are retained with corrective versions. A separate formula-rendering addendum repairs two frozen source-audit Markdown displays without changing the primary notes, exact diagnostic JSON or book TeX.

The first mechanical build found one overfull display; v2 splits it without changing values. The actual ten-page/five-view partial v2 reading found a nearly empty concluding page. V3 condenses repeated qualifications; its text-only preflight still found a two-line status spill and supplies zero matching-image reading credit. V4 removes the duplicate new status paragraph; the immediately preceding L.93 and canonical inventory preserve those same statuses. All earlier records remain frozen. All {nb} selected final pages were freshly read in {nv} matching individual displays and sequential notes, including the new contents row, complete additions and adjacent seams, complete index and complete TD26H entry. Preparation flags remain false. The last complete ordered whole-book pass remains 4 October.

Required validation, the six existing checker regression tests, reference closure and exact canonical inventory pass. Post-render reference/inventory and whitespace checks pass. There are no errors, LaTeX/package/pdfTeX warnings, missing glyphs, overfull boxes, undefined references/citations or rerun requests. All 955 underfull diagnostics are inherited with identical normalized text and multiplicities. All {release['all_prior_numbered_label_values_preserved']:,} prior number values and {release['bibliography']['prior_labels_preserved']} citation labels remain identical. One semantic label, one contents row, TD26H and two index terms are new; no manual equation tag or formal theorem/proof environment is added. All {release['index']['accepted']} index entries are accepted without warnings/rejections, and all {release['navigation']['internal_links']:,} internal links pass. External URL availability is not certified. The other 423 TeX inputs, NonArchimedean bibliography, 119 historical formal starts, 31 proofs and 54 manual tags remain unchanged. The unavailable legacy writing audit is replaced by direct semantic, notation, delimiter, source, whitespace and rendered checks.

The 42 canonical atoms/twelve formal problems retain their statuses: general BJ22 critical homogeneous Siu division/envelopes OPEN, LPWZ density UNVERIFIED. The native catalogue/editor are unchanged. No original general theorem, independent-model receipt or new whole-book pass is claimed. The nine-file authored source checkpoint is published and remotely verified in 79ae5c4c4065ab0e84870f58489ad246d321b4f5. This export does not claim activation or GitHub publication of the book unit; those actions receive separate records. Export adds zero reading credit.
''')
paths['reading_notes'].write_text(f'# Final scoped rendered-book notes, 8 October 2026\n\n{nb} fresh pages in {nv} matching individual displays. Earlier partial reading and preparation flags remain frozen.\n'+''.join('\n---\n\n'+Path(v['sequential_note_path']).read_text() for v in reading['views']))
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md'
prog=(R/programme).read_text();marker='## Latest relative Hessian source checkpoint, 8 October 2026\n';assert prog.count(marker)==1
header=f'''## Latest relative Hessian cloud integration checkpoint, 8 October 2026

The validated edition has {np:,} pages. The
[integration audit](Truong_relative_Hessian_staged_integration_audit_20261008.md)
records a boundary/normalization paragraph in 51.6.5 and new L.94. The operator
D_0=2 dd^c preserves the binding convention. Smooth examples check comparison,
injectivity, stability and the global Stokes boundary term. A common-trace
radial family has bounded signed energy and infinite limiting global mass.
The constant-shift measure test is separate from the Lp uniqueness example.
None of arXiv:2609.12032v1's general theorems is imported.

All 26 primary pages were read in thirteen individual matching displays.
The final book gate freshly reads {nb} pages in {nv} matching displays.
The first overfull repair, ten-page partial v2 reading, v3 text-only preflight
and v4 concise ending remain recorded. The
[formula-rendering addendum](Truong_relative_Hessian_source_formula_rendering_corrections_20261008.md)
repairs the frozen source-audit formatting without changing the mathematics.
Full validation and post-render checks pass; all 955 underfull diagnostics
are inherited. The {release['all_prior_numbered_label_values_preserved']:,} prior number values and 592 citation labels remain.
One label, one contents row, TD26H and two index terms are added.
Other 423 TeX inputs, the NonArchimedean bibliography and historical formal
blocks/proofs/tags remain unchanged. The native catalogue/editor and all
42 atoms/twelve formal problems are preserved: general BJ22 critical homogeneous
Siu/envelopes OPEN, LPWZ density UNVERIFIED. No original result, independent
receipt or new whole-book pass is claimed; the last complete pass is 4 October.

The authored primary checkpoint is already uploaded and remotely verified.
The byte-verified book exports and
[activation record](Truong_relative_Hessian_cloud_activation_20261008.json)
control the new cloud edition; publication receives a separate record.
Continue regular author-update checks and related primary reading, next
arXiv:2610.00361v1 on a pluripotential approach to polarized Calabi–Yau finiteness.
Its 34-page PDF and seventeen prepared views have zero actual reading credit.

'''
(S/programme).write_text(prog.replace(marker,header+marker))
readme=(R/'README.md').read_text();assert readme.count('**4,636 pages**')==1
readme=readme.replace('**4,636 pages**',f'**{np:,} pages**')
marker='**Latest relative Hessian source checkpoint, 8 October 2026:**';assert readme.count(marker)==1
intro=f'''**Latest checked book integration, 8 October 2026:** the
[relative Hessian boundary audit](manuscript/editorial/Truong_relative_Hessian_staged_integration_audit_20261008.md)
adds the local normalization paragraph in 51.6.5 and L.94's smooth boundary
and radial mass tests. The source operator is rescaled explicitly and none of
the preprint's general theorems is imported. All {nb} selected book pages were
freshly read in {nv} matching displays; mechanical and post-render gates pass.
The [formatting addendum](manuscript/editorial/Truong_relative_Hessian_source_formula_rendering_corrections_20261008.md)
supplies readable frozen audit formulas. The
[activation record](manuscript/editorial/Truong_relative_Hessian_cloud_activation_20261008.json)
controls the {np:,}-page cloud edition. No original general theorem, new
whole-book pass or canonical status change is claimed.

'''
(S/'README.md').write_text(readme.replace(marker,intro+marker,1))
oldzip=O/'Higher_Rank_Integral_Data_Staged_Minimal_Source_2026-10-08.zip'
with zipfile.ZipFile(oldzip) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 assert len(old.namelist())==472
 for n in old.namelist():assert (S/n).is_file();z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
 for n in z.namelist():assert z.read(n)==(S/n).read_bytes()
corrections=load('source_formula_rendering_corrections_v1_20261008.json')
paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — source/math/rendered staged gates',staging_preparation_SHA256=sha(C/'staging_preparation_v4_20261008.json'),validation_SHA256=sha(C/'staged_book_validation_v4_20261008.json'),release_checks=release,actual_reading=reading,post_render_checks=post,mathematical_self_audit=math,underfull_delta=underfull,source_formula_rendering_corrections=corrections,source_input_hashes=prep['after'],progress_document_hashes={n:sha(S/n) for n in ['README.md',programme]},active_book_changed=False,GitHub_published=False,canonical_status_changes=[],original_results_promoted=[],independent_model_receipt=None),ensure_ascii=False,indent=2)+'\n')
files={f'records/{q.name}':q for q in C.glob('*.json')}
for q in sorted(C.glob('staged_book_validation_*.log')):files['records/'+q.name]=q
files['records/'+review.name]=review
files['records/final_views_manifest.json']=Path(release['manifest_path'])
for v in reading['views']:
 for key,folder in [('path','images'),('selected_text_path','text'),('sequential_note_path','notes'),('observation_receipt_path','receipts')]:
  q=Path(v[key]);files[folder+'/'+q.name]=q
for q in (C/'staged_book_notes_v2').iterdir():
 files['v2_partial_notes/'+q.name]=q
 if q.name.endswith('_receipt.json'):
  r=json.loads(q.read_text())
  for key,folder in [('image_path','v2_partial_images'),('selected_text_path','v2_partial_text')]:
   q=Path(r[key]);files[folder+'/'+q.name]=q
for q in (C/'primary_notes_v1').iterdir():files['authored_primary_notes/'+q.name]=q
for key in ['audit','reading_notes','manifest']:
 q=paths[key];files['editorial/'+q.name]=q
for suffix in ['md','json']:
 q=E/f'Truong_relative_Hessian_source_formula_rendering_corrections_20261008.{suffix}'
 files['editorial/'+q.name]=q
for q in sorted(Path('/tmp').glob('Truong_relative_Hessian_*_20261008.py')):files['helpers/'+q.name]=q
for q in Path(prep['draft_path']).iterdir():files['final_draft/'+q.name]=q
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
 assert len(z.namelist())==len(files)
 for n,q in files.items():assert z.read(n)==q.read_bytes()
artifacts=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — byte-verified staged book exports',full_book_PDF=dict(path=str(full),bytes=full.stat().st_size,SHA256=sha(full),physical_pages=np),actual_book_review_PDF=dict(path=str(review),bytes=review.stat().st_size,SHA256=sha(review),physical_pages=nb),minimal_TeX_source_archive=dict(path=str(minimal),bytes=minimal.stat().st_size,SHA256=sha(minimal),members=472,all_members_byte_verified=True),actual_book_evidence_archive=dict(path=str(evidence),bytes=evidence.stat().st_size,SHA256=sha(evidence),members=len(files),all_members_byte_verified=True),actual_source_export_record_SHA256=sha(C/'source_export_v1_20261008.json'),source_publication_record_SHA256=sha(C/'GitHub_source_publication_v1_20261008.json'),external_primary_files_uploaded_in_book_exports=False,actual_reading_credit_from_export=0,active_book_changed=False,native_editor_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__)
paths['artifacts'].write_text(json.dumps(artifacts,ensure_ascii=False,indent=2)+'\n')
record.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — frozen staged checkpoint and exports',editorial_files={str(q):sha(q) for q in paths.values()},supplementary_editorial_files={str(E/f'Truong_relative_Hessian_source_formula_rendering_corrections_20261008.{suffix}'):sha(E/f'Truong_relative_Hessian_source_formula_rendering_corrections_20261008.{suffix}') for suffix in ['md','json']},artifacts=artifacts,progress_document_hashes={n:sha(S/n) for n in ['README.md',programme]},active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',record_SHA256=sha(record),artifacts=artifacts)))
