from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Truong_relative_Hessian_review_20261008'
V=Path('/workspace/book-completion-drafts/relative-Hessian-staging-v1-20261008')
S=Path('/workspace/book-completion-drafts/relative-Hessian-staging-v2-20261008')
D=Path('/workspace/book-completion-drafts/relative-Hessian-integration-v2-20261008')
out=C/'staging_preparation_v2_20261008.json';assert not out.exists() and not S.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=C/'staging_preparation_v1_20261008.json';p=json.loads(old.read_text())
assert sha(old)=='56ba97520e8ca8215e278c8c1e28f2416fda92c916d6faf40cb50f040088dd01'
for n,h in p['after'].items():assert sha(V/n)==h
for n,h in p['active_inputs_preserved'].items():assert sha(R/n)==h
for n,h in p['native_catalogue_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==p['active_book_PDF_SHA256']
shutil.copytree(V,S,ignore=shutil.ignore_patterns('*.pdf','*.aux','*.log','*.fls','*.fdb_latexmk','*.bbl','*.blg','*.toc','*.out','*.idx','*.ind','*.ilg','__pycache__'))
n='manuscript/appendices/appL_provenance.tex'
before=(Path(p['draft_path'])/'appL_relative_Hessian_fragment.tex').read_text()
after=(D/'appL_relative_Hessian_fragment.tex').read_text()
assert before.replace('D_0u=0,\\qquad D_0v=D_0w=\\beta_0,\\qquad','D_0u=0,\\qquad D_0v=D_0w=\\beta_0,\n\\]\n\\[')==after
x=(S/n).read_text();assert x.count(before)==1
(S/n).write_text(x.replace(before,after,1))
assert sha(S/'manuscript/parts/part5/ch51_complex_prerequisites.tex')==p['after']['manuscript/parts/part5/ch51_complex_prerequisites.tex']
assert sha(S/'manuscript/bibliography/ComplexGeometry.bib')==p['after']['manuscript/bibliography/ComplexGeometry.bib']
for n,h in p['other_active_TeX_preserved'].items():assert sha(S/n)==sha(R/n)==h
p.update(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — v2 stage splits one overfull display without changing mathematics',stage_path=str(S),draft_path=str(D),after={n:sha(S/n) for n in p['after']},draft_fragments={str(z):sha(z) for z in sorted(D.iterdir())},prior_staging_preparation_SHA256=sha(old),prior_validation_SHA256=sha(C/'staged_book_validation_v1_20261008.json'),prior_failed_release_SHA256=sha(C/'staged_release_attempt_v1_FAILED_20261008.json'),prior_underfull_delta_SHA256=sha(C/'staged_underfull_delta_v1_20261008.json'),repair='Split the five smooth Hessian/energy identities into two displays; numerical values and hypotheses unchanged',source_formula_rendering_corrections_SHA256=sha(C/'source_formula_rendering_corrections_v1_20261008.json'),actual_book_reading_credit=0,helper_source=__file__)
out.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
src=Path('/tmp/Truong_relative_Hessian_validate_staged_book_v1_20261008.py');dst=Path('/tmp/Truong_relative_Hessian_validate_staged_book_v2_20261008.py');assert not dst.exists()
x=src.read_text().replace('relative-Hessian-staging-v1-20261008','relative-Hessian-staging-v2-20261008').replace('v1_20261008','v2_20261008').replace('compiled_staged_v1','compiled_staged_v2')
dst.write_text('# Frozen v1 validation helper SHA256: '+sha(src)+'\n'+x)
print(json.dumps(dict(status=p['status'],record_SHA256=sha(out))))
