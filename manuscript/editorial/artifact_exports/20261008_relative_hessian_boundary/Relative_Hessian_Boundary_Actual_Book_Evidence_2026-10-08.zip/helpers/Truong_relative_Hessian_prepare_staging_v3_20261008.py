from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, re

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Truong_relative_Hessian_review_20261008'
V=Path('/workspace/book-completion-drafts/relative-Hessian-staging-v2-20261008')
S=Path('/workspace/book-completion-drafts/relative-Hessian-staging-v3-20261008')
D=Path('/workspace/book-completion-drafts/relative-Hessian-integration-v3-20261008')
out=C/'staging_preparation_v3_20261008.json';assert not out.exists() and not S.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=C/'staging_preparation_v2_20261008.json';p=json.loads(old.read_text())
assert sha(old)=='bb469a045e8f3037cb7514e5a59cffb57c734bd0a4887223a1bde86e5f2f213d'
for n,h in p['after'].items():assert sha(V/n)==h
for n,h in p['active_inputs_preserved'].items():assert sha(R/n)==h
for n,h in p['native_catalogue_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==p['active_book_PDF_SHA256']
partial=C/'actual_partial_staged_book_reading_v2_20261008.json'
assert sha(partial)=='22fe52c1335f72a054eeddc54b3595d0e2caf6343acdd6762d0ce93405460a1e'
shutil.copytree(V,S,ignore=shutil.ignore_patterns('*.pdf','*.aux','*.log','*.fls','*.fdb_latexmk','*.bbl','*.blg','*.toc','*.out','*.idx','*.ind','*.ilg','__pycache__'))
before=(Path(p['draft_path'])/'appL_relative_Hessian_fragment.tex').read_text()
after=(D/'appL_relative_Hessian_fragment.tex').read_text()
assert before[:before.index('For references with poles')]==after[:after.index('With a singular reference')]
assert before[before.index('The forty-two canonical atoms'):]==after[after.index('The forty-two canonical atoms'):]
assert re.findall(r'\\\[.*?\\\]',before,re.S)==re.findall(r'\\\[.*?\\\]',after,re.S)
n='manuscript/appendices/appL_provenance.tex';x=(S/n).read_text();assert x.count(before)==1
(S/n).write_text(x.replace(before,after,1))
for n in ['manuscript/parts/part5/ch51_complex_prerequisites.tex','manuscript/bibliography/ComplexGeometry.bib']:
 assert sha(S/n)==p['after'][n]
for n,h in p['other_active_TeX_preserved'].items():assert sha(S/n)==sha(R/n)==h
p.update(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — v3 stage condenses repeated final qualification after actual rendered finding',stage_path=str(S),draft_path=str(D),after={n:sha(S/n) for n in p['after']},draft_fragments={str(z):sha(z) for z in sorted(D.iterdir())},prior_staging_preparation_v2_SHA256=sha(old),prior_validation_v2_SHA256=sha(C/'staged_book_validation_v2_20261008.json'),prior_release_v2_SHA256=sha(C/'staged_book_release_checks_v2_20261008.json'),prior_underfull_delta_v2_SHA256=sha(C/'staged_underfull_delta_v2_20261008.json'),prior_actual_partial_reading_v2_SHA256=sha(partial),repair='Condense repeated final qualifications; all display equations and final canonical statuses unchanged',actual_book_reading_credit=0,helper_source=__file__)
out.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
for kind in ['validate_staged_book','prepare_staged_book_views','check_underfull_delta','record_book_note','finalize_staged_reading']:
 src=Path(f'/tmp/Truong_relative_Hessian_{kind}_v2_20261008.py');dst=Path(f'/tmp/Truong_relative_Hessian_{kind}_v3_20261008.py');assert not dst.exists()
 x=src.read_text().replace('relative-Hessian-staging-v2-20261008','relative-Hessian-staging-v3-20261008').replace('relative-Hessian-integration-v2-20261008','relative-Hessian-integration-v3-20261008').replace('staged_book_views_v2_20261008','staged_book_views_v3_20261008').replace('staged_book_notes_v2','staged_book_notes_v3').replace('compiled_staged_v2','compiled_staged_v3')
 for name in ['staged_book_release_checks','staged_book_validation','staged_underfull_delta','actual_staged_book_reading','staged_mathematical_self_audit','post_render_checks','staging_preparation']:
  x=x.replace(name+'_v2_20261008',name+'_v3_20261008')
 x=x.replace('STAGED BOOK V2','STAGED BOOK V3').replace('staged v2:','staged v3:')
 dst.write_text('# Frozen preceding v2 helper SHA256: '+sha(src)+'\n'+x)
print(json.dumps(dict(status=p['status'],record_SHA256=sha(out))))
