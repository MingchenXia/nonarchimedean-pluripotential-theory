from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Truong_relative_Hessian_review_20261008'
out=C/'local_source_commit_v1_20261008.json';assert not out.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
cp=json.loads((C/'source_checkpoint_v2_20261008.json').read_text())
ex=json.loads((C/'source_export_v1_20261008.json').read_text())
for p,h in cp['protected_core_inputs'].items():assert sha(Path(p))==h
files=[str(Path(p).relative_to(R)) for p in cp['editorial_files']]
files+=list(ex['repository_artifact_files'])
files+=['README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']
assert len(files)==len(set(files))==9
for p,h in cp['editorial_files'].items():assert sha(Path(p))==h
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==cp['baseline_commit']
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).strip()
subprocess.run(['git','diff','--check'],cwd=R,check=True)
subprocess.run(['git','add','--']+[f for f in files if f not in ex['repository_artifact_files']],cwd=R,check=True)
subprocess.run(['git','add','-f','--']+list(ex['repository_artifact_files']),cwd=R,check=True)
staged=subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).splitlines()
assert sorted(staged)==sorted(files)
subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
subprocess.run(['git','commit','-m','Audit relative Hessian boundary conditions and finite-energy mass tests'],cwd=R,check=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
record=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — nine-file authored source checkpoint committed; remote publication pending',baseline_commit=cp['baseline_commit'],commit=head,files={p:sha(R/p) for p in files},actual_source_pages=26,actual_images=13,active_book_changed=False,external_primary_PDF_text_images_uploaded=False,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
for p,h in cp['protected_core_inputs'].items():assert sha(Path(p))==h
print(json.dumps(dict(status=record['status'],commit=head,record_SHA256=sha(out))))
