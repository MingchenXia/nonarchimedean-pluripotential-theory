# Frozen preceding v1 helper SHA256: 95efee453c7ee88d6e843c312ab79df761f3f173759dc678b889c3a47719f35f
# Frozen adapted book-note helper SHA256: f103e837cea05cdf23bf80ce8d01591d80e95b9b4e3e89d3ff76478f443f6f9f
# Frozen v1 helper SHA256: 83dc09180349054ac2797bebbe85af1f026b2066bb3f0ade3c2aa2fb2f530e36
# Frozen adapted note template SHA256: 811aa19d98df776e29577f051d870cdc674de75d9d76a1d8c84af48ab0ed49ae
# Frozen actual-source-note helper SHA256: 9f6b4363620e0c009d5c026b75e9f279a3823e4c0f4fa1ed9b5e89b74d19413e
from pathlib import Path
from datetime import datetime,timezone
import sys,json,hashlib
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Truong_relative_Hessian_review_20261008');W=Path('/tmp/Truong_relative_Hessian_staged_book_views_v2_20261008');N=C/'staged_book_notes_v2'
number=int(sys.argv[1]);assert 1<=number<=len(json.loads((W/'manifest.json').read_text()))
p=N/f'note_{number:02d}.md';receipt=N/f'note_{number:02d}_receipt.json';assert not p.exists() and not receipt.exists()
if number>1:assert (N/f'note_{number-1:02d}_receipt.json').exists()
row=json.loads((W/'manifest.json').read_text())[number-1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(Path(row['path']))==row['image_SHA256'] and sha(Path(row['selected_text_path']))==row['selected_text_SHA256']
body=sys.stdin.read();assert len(body)>150
stamp=datetime.now(timezone.utc).isoformat();p.write_text(f'# Relative Hessian boundary and mass actual book view {number:02d}\n\nUTC: {stamp}. Physical pages: '+', '.join(map(str,row['physical_pages']))+'.\n\n'+body.rstrip()+'\n')
obj=dict(number=number,UTC=stamp,physical_pages=row['physical_pages'],source_PDF_SHA256=row['source_PDF_SHA256'],image_path=row['path'],image_SHA256=row['image_SHA256'],selected_text_path=row['selected_text_path'],selected_text_SHA256=row['selected_text_SHA256'],complete_selected_text_actually_read=True,matching_image_individually_displayed_and_reviewed=True,note_path=str(p),note_SHA256=sha(p),reading_credit=len(row['physical_pages']),not_an_independent_model_receipt=True,whole_book_new_reading_claim=False,preparation_flags_unchanged=True,helper_source=__file__)
receipt.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(number=number,pages=row['physical_pages'],receipt_SHA256=sha(receipt))))
