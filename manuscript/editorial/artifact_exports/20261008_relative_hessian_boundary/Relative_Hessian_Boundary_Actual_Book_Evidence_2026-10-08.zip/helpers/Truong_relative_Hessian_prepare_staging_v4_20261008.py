from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, re

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Truong_relative_Hessian_review_20261008'
V=Path('/workspace/book-completion-drafts/relative-Hessian-staging-v3-20261008')
S=Path('/workspace/book-completion-drafts/relative-Hessian-staging-v4-20261008')
D=Path('/workspace/book-completion-drafts/relative-Hessian-integration-v4-20261008')
out=C/'staging_preparation_v4_20261008.json';assert not out.exists() and not S.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=C/'staging_preparation_v3_20261008.json';p=json.loads(old.read_text())
assert sha(old)=='d7f1b32f7cc26590ff32672ada4aeacf05504e0dcb9781e04df42e819c4e6f02'
for n,h in p['after'].items():assert sha(V/n)==h
for n,h in p['active_inputs_preserved'].items():assert sha(R/n)==h
for n,h in p['native_catalogue_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==p['active_book_PDF_SHA256']
shutil.copytree(V,S,ignore=shutil.ignore_patterns('*.pdf','*.aux','*.log','*.fls','*.fdb_latexmk','*.bbl','*.blg','*.toc','*.out','*.idx','*.ind','*.ilg','__pycache__'))
before=(Path(p['draft_path'])/'appL_relative_Hessian_fragment.tex').read_text()
after=(D/'appL_relative_Hessian_fragment.tex').read_text()
assert before[:before.index('The forty-two canonical atoms')].rstrip()+'\n'==after
assert re.findall(r'\\\[.*?\\\]',before,re.S)==re.findall(r'\\\[.*?\\\]',after,re.S)
n='manuscript/appendices/appL_provenance.tex';x=(S/n).read_text();assert x.count(before)==1
(S/n).write_text(x.replace(before,after,1))
assert 'general BJ22 critical homogeneous\nSiu division and envelopes remain open' in (S/n).read_text()
for n in ['manuscript/parts/part5/ch51_complex_prerequisites.tex','manuscript/bibliography/ComplexGeometry.bib']:
 assert sha(S/n)==p['after'][n]
for n,h in p['other_active_TeX_preserved'].items():assert sha(S/n)==sha(R/n)==h
p.update(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — v4 stage removes duplicated concluding status paragraph; canonical statuses preserved',stage_path=str(S),draft_path=str(D),after={n:sha(S/n) for n in p['after']},draft_fragments={str(z):sha(z) for z in sorted(D.iterdir())},prior_staging_preparation_v3_SHA256=sha(old),prior_validation_v3_SHA256=sha(C/'staged_book_validation_v3_20261008.json'),prior_text_only_layout_preflight_v3_SHA256=sha(C/'staged_layout_text_preflight_v3_20261008.json'),repair='Remove duplicate new L.94 status paragraph; preceding L.93, canonical inventory, all examples and proof qualifications preserved',actual_book_reading_credit=0,helper_source=__file__)
out.write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
for kind in ['validate_staged_book','prepare_staged_book_views','check_underfull_delta','record_book_note','finalize_staged_reading']:
 src=Path(f'/tmp/Truong_relative_Hessian_{kind}_v3_20261008.py');dst=Path(f'/tmp/Truong_relative_Hessian_{kind}_v4_20261008.py');assert not dst.exists()
 x=src.read_text().replace('relative-Hessian-staging-v3-20261008','relative-Hessian-staging-v4-20261008').replace('relative-Hessian-integration-v3-20261008','relative-Hessian-integration-v4-20261008').replace('staged_book_views_v3_20261008','staged_book_views_v4_20261008').replace('staged_book_notes_v3','staged_book_notes_v4').replace('compiled_staged_v3','compiled_staged_v4')
 for name in ['staged_book_release_checks','staged_book_validation','staged_underfull_delta','actual_staged_book_reading','staged_mathematical_self_audit','post_render_checks','staging_preparation']:
  x=x.replace(name+'_v3_20261008',name+'_v4_20261008')
 x=x.replace('STAGED BOOK V3','STAGED BOOK V4').replace('staged v3:','staged v4:')
 dst.write_text('# Frozen preceding v3 helper SHA256: '+sha(src)+'\n'+x)
print(json.dumps(dict(status=p['status'],record_SHA256=sha(out))))
