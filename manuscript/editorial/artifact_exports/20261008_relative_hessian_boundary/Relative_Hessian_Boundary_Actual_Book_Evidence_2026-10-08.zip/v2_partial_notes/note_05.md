# Relative Hessian boundary and mass actual book view 05

UTC: 2026-10-08T21:26:04.121834+00:00. Physical pages: 4391, 4392.

Read the complete selected text and displayed matching rendered image. Physical pages 4391–4392 contain the full energy calculation, exact bound 11/4 and limit -53/28, canonical truncation failure despite common trace, local one-factor continuity qualification, and the separate constant-shift measure-hypothesis test. The positive-energy example is explicitly restricted to Section 6's changed class and stays negative for 0<C<1. All formulas and source locators are correct and legible. The final repeated qualification and canonical-status paragraph spills into only five lines on a nearly empty page 4392; this is a readability/layout repair finding. Condense the concluding proof qualifications without changing any example, value, condition, source status or canonical status, and retain this v2 partial reading. No full final rendered clearance is claimed.
