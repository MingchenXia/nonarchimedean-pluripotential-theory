from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/BJKS1_Finski_dependencies_review_20261009'
out=C/'local_source_commit_v1_20261009.json';assert not out.exists()
repo='MingchenXia/nonarchimedean-pluripotential-theory'
api=lambda ep:json.loads(subprocess.check_output(['gh','api',ep],cwd=R,text=True))
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
checkpoint=json.loads((C/'source_checkpoint_v1_20261009.json').read_text());prep=json.loads((C/'primary_view_preparation_v1_20261009.json').read_text())
head=git('rev-parse','HEAD');assert git('branch','--show-current')=='work' and head==prep['baseline_commit']=='9f789371c3f56be040de94ed846cb9aab9a06580'
w=api(f'repos/{repo}/git/ref/heads/work')['object']['sha'];m=api(f'repos/{repo}/git/ref/heads/main')['object']['sha'];p=api(f'repos/{repo}/pulls/2')
assert w==head and m=='00957114db21b627e97369563032ceda9cea09c7' and p['state']=='open' and p['draft'] and p['head']['sha']==head
progress=['README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']
for n,h in prep['protected_core_inputs'].items():
    if n not in progress:assert sha(R/n)==h
files=checkpoint['editorial_files'];assert len(files)==9
for n,row in files.items():assert sha(R/n)==row['SHA256'] and (R/n).stat().st_size==row['bytes']
assert not git('diff','--cached','--name-only') and sorted(git('diff','--name-only').splitlines())==sorted(progress)
subprocess.run(['git','diff','--check'],cwd=R,check=True)
art=[n for n in files if '/artifact_exports/' in n]
subprocess.run(['git','add','--']+[n for n in files if n not in art],cwd=R,check=True)
subprocess.run(['git','add','-f','--']+art,cwd=R,check=True)
assert sorted(git('diff','--cached','--name-only').splitlines())==sorted(files)
subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
run=subprocess.run(['git','commit','-m','Audit original BJKS1 dependencies and retain raw FS and envelope gates'],cwd=R,check=True,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
new=git('rev-parse','HEAD')
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — nine-file selected source unit locally committed; remote publication pending',baseline_commit=head,commit=new,files=files,
    author_update_check=dict(work=w,main=m,PR2_open_draft=True),actual_primary_pages=50,actual_matching_views=25,whole_primary_PDF_read=False,
    active_book_PDF_SHA256=prep['protected_core_inputs']['manuscript/book.pdf'],active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],commit_output=run.stdout,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='DONE',commit=new,files=9,record_SHA256=sha(out))))
