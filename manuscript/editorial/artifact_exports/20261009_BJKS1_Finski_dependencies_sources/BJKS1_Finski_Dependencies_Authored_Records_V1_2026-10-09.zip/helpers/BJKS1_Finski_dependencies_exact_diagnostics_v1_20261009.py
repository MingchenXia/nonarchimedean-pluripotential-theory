from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction as F
import hashlib, json, math

C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/BJKS1_Finski_dependencies_review_20261009')
out=C/'exact_diagnostics_v1_20261009.json'; assert not out.exists()
families=[]
def add(name,evidence,scope):
    families.append(dict(name=name,status='PASS — exact elementary diagnostic only',evidence=evidence,scope=scope))
for m in range(1,12):
    for n in range(1,12):
        for a in [False,True]:
            for b in [False,True]:
                assert (m+n if a or b else 0)>=(m if a else 0)+(n if b else 0)
add('Raw homogeneous FS is not automatically USC',
    dict(P1_filtration='chi_m(s)=m if s(p)=0, otherwise 0',at_supported_point=0,
         at_every_finite_positive_Gauss_weight=1,upper_regularization=1),
    'Published Example 2.21; rational Gauss weights tending to infinity approach the supported point. A downward raw jump does not refute a canonical regularized psh correspondence.')
rows=[]
for d in range(1,9):
    for k in range(1,11):
        m=d*k
        possible={0}
        for _ in range(k):
            possible={x+j for x in possible for j in range(d+1)}
        assert possible==set(range(m+1))
        for j in range(m+1):
            states={(0,0)}
            for _ in range(k):
                states={(x+i,w+(d if i else 0)) for x,w in states for i in range(d+1) if x+i<=j}
            maximum=max(w for x,w in states if x==j)
            assert maximum==d*min(j,k)
        assert F(m-d,m)==1-F(1,k)
    rows.append(dict(base_degree=d,simple_vanishing_weight=d,asymptotic_original_normalized_gap=1))
add('Canonical Veronese approximants retain original weights',rows,
    'Definition 1.12 uses unrescaled restriction to R_d. Example 2.21 printed simple-vanishing value 1 is native rescaling; the original value is d. Its nonuniform approximation conclusion remains correct.')
for r in range(1,8):
    for k in range(1,9):
        assert F((-r*k),r*k)==-1
add('Native Veronese barycenter and original-degree barycenter',
    dict(original_constant_weight='w_m=-m',native_barycenter_for_L_power_r='-r',original_degree_barycenter=-1),
    'Restriction of weights alone does not preserve a volume divided by native degree. The source direct-limit convention retains original degree.')
add('Probability Monge–Ampere intersection normalization',
    dict(P1_O2_product_central_intersection=2,volume=2,probability_mass=1,constant_energy='E(c)=c'),
    'The printed ordinary-intersection sum on p. 881 needs division by (L^n), as confirmed by MA(0)=delta_triv and energy formula (4.4).')
hilbert=[]
for k in range(1,31):
    m=2*k; values=list(range(0,m+1,2)); assert len(values)==k+1
    hilbert.append(dict(original_degree=m,dimension=k+1,dim_over_degree=str(F(k+1,m)),
                        ambient_interval_length=1,value_lattice_index=2))
assert 101 not in set(range(0,202,2))
add('Okounkov value lattice for a non-birational subalgebra',hilbert,
    'S=k[x^2,y^2] has ambient body [0,1] but even-degree Hilbert coefficient tending to 1/2. The printed body-volume and interior lattice equalities need the value-lattice/degree support convention. This example does not refute the intended approximation limit.')
sign=[]
for c in [F(1,4),F(1,2),F(3,4),F(1)]:
    for xi in [F(i,4) for i in range(-12,13)]:
        gv=max(xi+c,c*xi+c,F(0))
        direct=max(c-xi,c-c*xi,F(0))-max(F(0),-xi)
        reflected=max(-xi+c,-c*xi+c,F(0))-max(F(0),-xi)
        assert direct==reflected
        sign.append(dict(c=str(c),xi=str(xi),direct_FS=str(direct),reflected_Legendre=str(reflected)))
assert max(F(0),1-F(1))-max(F(0),-F(1))==0
assert max(F(0),F(1)+1)-max(F(0),F(1))==1
add('Valuation and plus-sign Legendre coordinates',sign,
    'For v_xi(T)=xi and the source plus-sign Legendre transform, section evaluation gives g-vee(-xi)-0-vee(-xi). The printed toric FS and real-MA identification need reflection; the positive gradient pushforward is consistent with the valuation coordinate.')
add('Redundant higher-rank product action',
    dict(configuration='X times A^r, pullback L, torus acting only on A^r',
         Laurent_extendable_exponents='alpha_i<=0',max_positive_direction_pairing=0,induced_norm_rank=0),
    'Definition A.14 permits this product for any positive rationally independent direction. Proposition A.15 exact-rank assertion needs effectiveness/minimality; finite-type existence and rank at most r survive.')
count=0
grid=[F(i,3) for i in range(-9,10)]
for a in grid:
    for b in grid:
        rho=(a+b)/2
        for delta in [F(0),F(1,3),F(1)]:
            sigma=min(a,rho)-delta; tau=min(b,rho)-delta
            assert 2*rho-sigma-tau>=abs(a-b)/2;count+=1
add('Ordered rooftop estimate and constants',dict(exact_cases=count),
    'Theorem 5.8 pointwise estimate is a direct formal inequality; it does not clear imported locality, domination or finite-energy continuity.')
count=0
for a in grid:
    for b in grid:
        assert math.floor(a+b)>=math.floor(a)+math.floor(b)
        assert 0<=a-math.floor(a)<1;count+=1
add('Integer rounding and degree-zero translation',dict(floor_cases=count,unit_degree=0,unit_translation=0),
    'Floor error is below one before degree normalization; degree-zero unit cannot be moved by adding c*m. No uniform-in-all-ray-time approximation is asserted.')
add('Signed mean versus L1 and constant quotient',
    dict(joint_spectrum=[-1,1],signed_mean=0,probability_L1=1,unquotiented_constant_distance='|c-d|',
         constant_quotient_distance=0),
    'Ordered energy differences, unordered L1 distance and quotient by constants are three distinct operations.')
assert len(families)==10
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — ten exact elementary diagnostic families',
    families=families,general_theorems_admitted=[],independent_model_receipt=None,
    BJ22_Theorem_6_21_repaired=False,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',families=10,SHA256=hashlib.sha256(out.read_bytes()).hexdigest())))
