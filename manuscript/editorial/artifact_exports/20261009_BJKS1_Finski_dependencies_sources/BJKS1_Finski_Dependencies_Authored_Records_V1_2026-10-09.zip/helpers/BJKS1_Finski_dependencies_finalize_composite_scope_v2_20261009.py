from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,copy
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/BJKS1_Finski_dependencies_review_20261009')
old=C/'actual_primary_reading_v1_20261009.json';out=C/'actual_primary_reading_v2_20261009.json';assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.loads(old.read_text());b=copy.deepcopy(a)
assert len(a['selected_physical_pages'])==50 and len(a['views'])==25
assert a['sources']['BJKS1_AIF2025']['selected_physical_pages']==[21,22]
for v in a['views']:
    for p,h in [('image_path','image_SHA256'),('selected_text_path','selected_text_SHA256'),('note_path','note_SHA256'),('observation_receipt_path','observation_receipt_SHA256')]:assert sha(v[p])==v[h]
b['sources']['BJKS1_AIF2025']['selected_physical_pages']=a['selected_physical_pages']
b['UTC']=datetime.now(timezone.utc).isoformat()
b['composite_scope_metadata_addendum']=dict(prior_path=str(old),prior_SHA256=sha(old),
    reason='v1 source descriptor retained only the final two-page preparation selection; top-level fifty-page scope and all twenty-five actual views were correct. This fresh composite descriptor lists the full selected union.',
    prior_records_unchanged=True,new_actual_reading_credit=0)
b['helper_source']=__file__;out.write_text(json.dumps(b,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',retained_actual_pages=50,retained_actual_views=25,fresh_reading_credit=0,SHA256=sha(out))))
