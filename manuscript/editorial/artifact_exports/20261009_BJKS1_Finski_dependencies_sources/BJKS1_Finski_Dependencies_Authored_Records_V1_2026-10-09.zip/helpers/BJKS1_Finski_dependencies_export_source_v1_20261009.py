from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile,shutil
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/BJKS1_Finski_dependencies_review_20261009'
E=R/'manuscript/editorial';O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
reading=json.loads((C/'actual_primary_reading_v2_20261009.json').read_text());prep=json.loads((C/'primary_view_preparation_v1_20261009.json').read_text())
diag=json.loads((C/'exact_diagnostics_v1_20261009.json').read_text())
assert reading['actual_selected_source_page_pairs']==50 and len(reading['views'])==25
assert len(reading['sources']['BJKS1_AIF2025']['selected_physical_pages'])==50 and not reading['whole_primary_PDF_reading_claim']
for n,h in prep['protected_core_inputs'].items():assert sha(R/n)==h
paths={k:E/f'BJKS1_Finski_dependencies_source_{k}_20261009.{ext}' for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
record=C/'source_checkpoint_v1_20261009.json';draft=Path('/tmp/BJKS1_Finski_dependencies_source_review_draft_v1_20261009.md')
owned=O/'BJKS1_Finski_Dependencies_Authored_Records_V1_2026-10-09.zip';full=O/'BJKS1_Finski_Dependencies_Actual_Source_Evidence_V1_2026-10-09.zip'
dest=E/'artifact_exports/20261009_BJKS1_Finski_dependencies_sources'
assert not any(p.exists() for p in [*paths.values(),record,owned,full,dest])
paths['review'].write_text(draft.read_text().rstrip()+'\n')
paths['reading_notes'].write_text(('# Actual selected BJKS1 dependency reading, 9 October 2026\n\nFifty physical pages, twenty-five individually displayed matching views. Partial hundred-page source; no recursive external-proof clearance. The initial 34/17 selection is followed by actual supplementary 10/5, 4/2 and 2/1 selections. Prior field and approximation clarifications remain as fresh later notes.\n\n'+''.join('\n---\n\n'+Path(v['note_path']).read_text() for v in reading['views'])).rstrip()+'\n')
files={f'records/{p.relative_to(C)}':p for p in C.rglob('*.json') if 'primary_notes_v1' not in p.parts}
for i,v in enumerate(reading['views'],1):
    for key,kind in [('note_path','notes'),('observation_receipt_path','receipts')]:files[f'actual/{kind}/view_{i:02d}{Path(v[key]).suffix}']=Path(v[key])
for i,p in enumerate(reading['preparations'],1):
    a=json.loads(Path(p['path']).read_text());files[f'manifests/prepared_{i:02d}.json']=Path(a['manifest_path'])
for p in sorted(Path('/tmp').glob('BJKS1_Finski_dependencies_*_v*_20261009.py')):files[f'helpers/{p.name}']=p
files[f'drafts/{draft.name}']=draft
for key in ['review','reading_notes']:files[f'editorial/{paths[key].name}']=paths[key]
def archive(target,entries):
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,p in sorted(entries.items()):z.write(p,n)
    with zipfile.ZipFile(target) as z:
        assert len(z.namelist())==len(entries) and z.testzip() is None
        for n,p in entries.items():assert z.read(n)==p.read_bytes()
archive(owned,files);fullfiles=dict(files)
fullfiles['primary/PDF/BJKS1_published_AIF2025.pdf']=Path(reading['sources']['BJKS1_AIF2025']['path'])
for i,v in enumerate(reading['views'],1):
    for key,kind in [('image_path','images'),('selected_text_path','text')]:fullfiles[f'actual/{kind}/view_{i:02d}{Path(v[key]).suffix}']=Path(v[key])
fullfiles['supplementary/physical58_equivalence_close_render.png']=Path(reading['supplementary_formula_reinspection']['path'])
archive(full,fullfiles)
artifacts={k:dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p),members=count) for k,p,count in [('authored_records_archive',owned,len(files)),('cloud_source_evidence_archive',full,len(fullfiles))]}
paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — selected published BJKS1 Finski-dependency source audit',actual_reading=reading,exact_diagnostics=diag,artifacts=artifacts,active_book_changed=False,native_editor_changed=False,GitHub_published=False,canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — all authored/cloud archive members byte-verified',artifacts=artifacts,reading_credit_from_export=0,external_primary_PDF_text_images_uploaded=False,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
dest.mkdir(parents=True);target=dest/owned.name;shutil.copyfile(owned,target);assert sha(target)==sha(owned)
(dest/'SHA256SUMS').write_text(sha(target)+'  '+target.name+'\n')
(dest/'README.md').write_text(f'''# Published BJKS1 Finski-dependency source checkpoint, 9 October 2026

Fifty of the hundred physical pages were actually read in twenty-five
matching text/image views. This is a selected dependency audit, not a full
paper or new whole-book reading. The named old Chapter 50 checkpoint has
four repeated pages; the fresh selection adds 46 unique pages against it,
giving a named union of 54, with no all-historical claim.

The {len(files)}-member owned archive pins notes, actual receipts, preparation
and composite-scope records, ten exact elementary diagnostic families,
helpers and review. The {len(fullfiles)}-member cloud-only archive additionally
retains the unmodified primary PDF and matching extracted text/images.
External primary source files stay in the cloud. Export and upload add
zero reading credit. The initial aggregate source descriptor was clarified
in a fresh v2 record; the actual 50 pages/25 views were unchanged.

Lemma 6.17(iii) requires psh membership of upper-regularized FS for strong
convergence. Raw bounded multiplicative FS can jump downward at a supported
point, as in published Example 2.21. Probability volume, original Veronese
degrees and valuation/Legendre signs are retained explicitly. Selected
source-local lattice, rank and formula omissions do not promote a general
new theorem. This 2025 paper imports BJ22 Global pluripotential theory and
its addendum; neither transitive independence from the reported Siu gap nor
a repair of BJ22 Theorem 6.21 is claimed.

The 4,663-page active book, both bibliographies, native catalogue and editor
remain unchanged. Canonical 42 atoms/twelve formal problems retain their
statuses, general BJ22 critical Siu/envelopes stay OPEN and LPWZ density
UNVERIFIED. No independent-model receipt exists for this selected audit.
Last complete ordered book pass remains 4 October. Continue cloud only.
'''.rstrip()+'\n')
p=R/'README.md';s=p.read_text();marker='**Latest complete published Finski source checkpoint, 9 October 2026:**';assert s.count(marker)==1
intro='''**Latest selected BJKS1 dependency source checkpoint, 9 October 2026:**
the [published-source audit](manuscript/editorial/BJKS1_Finski_dependencies_source_review_20261009.md)
checks fifty of the hundred physical pages in twenty-five matching views,
including Finski's original FS/energy and test-configuration interfaces.
Lemma 6.17(iii) retains the psh-membership gate for regularized FS; raw FS,
probability volume and original Veronese degree stay distinct. The
[authored evidence](manuscript/editorial/artifact_exports/20261009_BJKS1_Finski_dependencies_sources/README.md)
records exact scope and ten elementary diagnostics. BJ22 and its addendum
remain explicit original dependencies; no Siu proof repair is claimed.
The 4,663-page book and native catalogue are unchanged here.

''';p.write_text(s.replace(marker,intro+marker,1))
p=E/'second_reading_and_research_programme_20261002.md';s=p.read_text();marker='## Latest complete published Finski source checkpoint, 9 October 2026\n';assert s.count(marker)==1
intro='''## Latest selected published BJKS1 dependency checkpoint, 9 October 2026

The [actual source audit](BJKS1_Finski_dependencies_source_review_20261009.md)
reads fifty distinct physical pages of the hundred-page AIF 2025 primary
PDF in twenty-five matching views. Four are repeated against the named
eight-page Chapter 50 audit; 46 new unique pages give a named union of 54.
This is a partial primary reading, not a full source or whole-book pass.
The [owned archive](artifact_exports/20261009_BJKS1_Finski_dependencies_sources/README.md)
retains all actual notes and later clarifications; preparation, composite
metadata correction, export and upload add zero reading credit.

The exact gate in Lemma 6.17(iii) requires upper-regularized FS to be psh
before strong E1 convergence. Full and weak envelope properties are kept
separate. Published Example 2.21 anchors the book's raw P1 downward jump;
Definition 1.12 clarifies its original-degree approximant weights.
Ten elementary diagnostic families also check probability MA mass,
Veronese barycenters, the value-lattice steps in arbitrary-subalgebra
Okounkov arguments, toric signs, redundant higher-rank directions,
ordered rooftop estimates, integer floors/units and signed versus L1
distance. They do not prove the imported general pluripotential inputs.

The original citation chain includes BJ22 Global pluripotential theory
and its separate addendum. No independence from the reported Theorem 6.21
gap or repair is claimed. Next a scoped book increment can attribute
the P1 example, retain the explicit FS membership gate and explain
Finski's fixed-r Parseval argument. BBJ21 maximal rays, holomorphic
extension and the original Okounkov lattice prerequisites remain source
tasks. The 4,663-page book, both bibliographies, native editor and canonical
42 atoms/twelve problems remain unchanged in this source checkpoint.
BJ22 critical Siu/general envelopes remain OPEN and LPWZ density
UNVERIFIED. No independent-model receipt or new complete book pass is
asserted; the last ordered pass is 4 October. Continue cloud only and
integrate incoming author research while publishing reviewed units.

''';p.write_text(s.replace(marker,intro+marker,1))
published=[*paths.values(),*sorted(dest.iterdir()),R/'README.md',p];assert len(published)==9
for path in [paths['review'],paths['reading_notes'],dest/'README.md']:
    assert path.read_bytes().endswith(b'\n') and not path.read_bytes().endswith(b'\n\n')
    assert all(line==line.rstrip() for line in path.read_text().splitlines())
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — nine authored source/progress/artifact files exported',
    editorial_files={str(p.relative_to(R)):dict(SHA256=sha(p),bytes=p.stat().st_size) for p in published},
    artifacts=artifacts,actual_primary_pages=50,actual_matching_views=25,whole_primary_PDF_read=False,
    active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],GitHub_published=False,helper_source=__file__)
record.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',files=9,authored_members=len(files),cloud_members=len(fullfiles),record_SHA256=sha(record))))
