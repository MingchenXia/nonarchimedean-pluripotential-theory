# Additional conventions/A.6 selection from frozen v1 dbc629c77e97cdd6fface59977dfb2e655d40ac50cbab6f68e0f053e0b406c73
# Fresh supplementary selection from frozen primary helper 5f133012b31fe38f89cc1a3ed3eff133a641e29677c09f4039aa343662efa251
# Fresh BJKS1 selection adapted from frozen Finski preparation 65239cb2cb39bfb4de428b6286a5938211d2f5fe5194e56549665fab4469b7c2
# New completion selection; frozen earlier three-source prep SHA256 2a2df7d5de9e7bf35cd45d1880376875d29627e8cd7fe541aca24790bdc1bb93
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,fitz,subprocess
from PIL import Image,ImageDraw
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BJKS1_Finski_dependencies_review_20261009/supplementary_v2'
W=Path('/tmp/BJKS1_Finski_dependencies_supplementary_views_v2_20261009')
N=C/'primary_notes_v1';out=C/'primary_view_preparation_v1_20261009.json'
assert not any(p.exists() for p in [C,W]);C.mkdir();W.mkdir();N.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
bookprep=json.loads((R/'source_material/Reboulet_asymptotic_FS_review_20261009/staging_preparation_v1_20261009.json').read_text())
names=sorted(set(bookprep['other_active_TeX_preserved'])|{n for n in bookprep['after'] if n.endswith('.tex')});assert len(names)==425
names+=['manuscript/book.pdf','manuscript/bibliography/ComplexGeometry.bib','manuscript/bibliography/NonArchimedean.bib','output/open_problems_catalogue_2026-10-03.tex','output/open_problems_catalogue_2026-10-03.pdf','README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']
protected={n:sha(R/n) for n in names}
sources=[('BJKS1_AIF2025','source_material/ch50_audit_20261001/BJKS1_published.pdf','f68e2a7fff4b0d9eb8541166ace4b4e3dbb974c0eebda876ea65c8dc10e4b743',100,[13,18,91,92])]
views=[];pdfs={}
for key,name,pin,total,selected in sources:
    pdf=R/name;assert sha(pdf)==pin
    pdfs[key]=dict(path=str(pdf),bytes=pdf.stat().st_size,SHA256=pin,total_physical_pages=total,selected_physical_pages=selected,whole_PDF_selected=False)
    with fitz.open(pdf) as d:
        assert len(d)==total
        for i in range(0,len(selected),2):
            pp=selected[i:i+2];panels=[];texts=[]
            for n in pp:
                pix=d[n-1].get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False)
                panels.append(Image.frombytes('RGB',[pix.width,pix.height],pix.samples))
                texts.append(f'{key} SELECTED PRIMARY PHYSICAL PAGE {n}\n'+d[n-1].get_text())
            canvas=Image.new('RGB',(sum(p.width for p in panels),max(p.height for p in panels)+28),'white');draw=ImageDraw.Draw(canvas);x=0
            for n,panel in zip(pp,panels):draw.text((x+8,8),f'{key} physical {n}',fill='black');canvas.paste(panel,(x,28));x+=panel.width
            number=len(views)+1;ip=W/f'sheet_{number:02d}.png';tp=W/f'sheet_{number:02d}.txt';canvas.save(ip);tp.write_text('\n\n'.join(texts))
            views.append(dict(number=number,source=key,physical_pages=pp,path=str(ip),image_SHA256=sha(ip),selected_text_path=str(tp),selected_text_SHA256=sha(tp),source_PDF_SHA256=pin,actually_viewed=False,selected_text_read=False))
assert len(views)==2 and sum(len(v['physical_pages']) for v in views)==4
mp=W/'manifest.json';mp.write_text(json.dumps(views,ensure_ascii=False,indent=2)+'\n')
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — selected original dependency views prepared; zero reading credit',sources=pdfs,prepared_source_page_pairs=4,prepared_views=2,manifest_path=str(mp),manifest_SHA256=sha(mp),protected_core_inputs=protected,baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),actual_source_reading_credit=0,actually_read_pages=0,whole_primary_PDF_reading_claim=False,whole_book_new_reading_claim=False,active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',prepared_source_page_pairs=4,prepared_views=2,record_SHA256=sha(out))))
