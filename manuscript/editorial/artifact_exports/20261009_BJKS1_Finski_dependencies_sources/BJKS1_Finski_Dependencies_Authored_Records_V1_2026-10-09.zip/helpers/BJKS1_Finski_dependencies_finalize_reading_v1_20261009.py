from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BJKS1_Finski_dependencies_review_20261009'
out=C/'actual_primary_reading_v1_20261009.json';assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
selections=[(C,34,17),(C/'supplementary_v1',10,5),(C/'supplementary_v2',4,2),(C/'supplementary_v3',2,1)]
views=[];preparations=[];last=None
for folder,count,total in selections:
    pp=folder/'primary_view_preparation_v1_20261009.json'; prep=json.loads(pp.read_text())
    assert prep['actual_source_reading_credit']==prep['actually_read_pages']==0
    assert sha(prep['manifest_path'])==prep['manifest_SHA256']
    rows=json.loads(Path(prep['manifest_path']).read_text());assert len(rows)==total
    assert sum(len(v['physical_pages']) for v in rows)==count
    for i,row in enumerate(rows,1):
        rp=folder/f'primary_notes_v1/note_{i:02d}_receipt.json';a=json.loads(rp.read_text())
        assert a['number']==i and a['physical_pages']==row['physical_pages']
        assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
        assert not row['actually_viewed'] and not row['selected_text_read']
        assert last is None or a['UTC']>last;last=a['UTC']
        for key,h in [('image_path','image_SHA256'),('selected_text_path','selected_text_SHA256'),('note_path','note_SHA256')]:assert sha(a[key])==a[h]
        assert a['source_PDF_SHA256']==row['source_PDF_SHA256']=='f68e2a7fff4b0d9eb8541166ace4b4e3dbb974c0eebda876ea65c8dc10e4b743'
        views.append(dict(**a,selection=str(folder.relative_to(C)),observation_receipt_path=str(rp),observation_receipt_SHA256=sha(rp)))
    for n,h in prep['protected_core_inputs'].items():assert sha(R/n)==h
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==prep['baseline_commit']
    preparations.append(dict(path=str(pp),SHA256=sha(pp),pages=count,views=total))
pages=sorted(p for a in views for p in a['physical_pages']);assert len(pages)==len(set(pages))==50 and len(views)==25
source=prep['sources']['BJKS1_AIF2025'];assert sha(source['path'])==source['SHA256'] and source['total_physical_pages']==100
diag=C/'exact_diagnostics_v1_20261009.json';d=json.loads(diag.read_text());assert len(d['families'])==10
assert all(a['status'].startswith('PASS') for a in d['families'])
old=R/'manuscript/editorial/ch50_quality_audit_20261001.md';oldpages=[34,60,62,67,75,78,84,88]
assert '34, 60, 62, 67, 75, 78, 84, 88' in old.read_text()
overlap=sorted(set(pages)&set(oldpages));assert overlap==[34,60,62,75]
crop=Path('/tmp/BJKS1_Finski_dependencies_equivalence_formula_20261009.png')
reinspection=dict(path=str(crop),SHA256=sha(crop),physical_page=58,individually_displayed=True,new_physical_reading_credit=0)
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — fifty selected physical pages / twenty-five actual matching views; partial primary PDF',
    sources={'BJKS1_AIF2025':source},actual_selected_source_page_pairs=50,actual_individually_displayed_matching_views=25,
    selected_physical_pages=pages,views=views,preparations=preparations,
    named_older_comparison=dict(audit_path=str(old),audit_SHA256=sha(old),stated_old_pages=oldpages,
        freshly_repeated_pages=overlap,new_unique_pages=sorted(set(pages)-set(oldpages)),new_unique_count=46,
        named_combined_unique_pages=sorted(set(pages)|set(oldpages)),named_combined_count=54,
        all_historical_checkpoint_union_claimed=False,old_images_or_proofs_not_newly_revalidated=True),
    supplementary_formula_reinspection=reinspection,exact_diagnostics_SHA256=sha(diag),
    complete_selected_text_read=True,preparation_flags_unchanged=True,whole_primary_PDF_reading_claim=False,
    whole_book_new_reading_claim=False,active_book_changed=False,native_editor_changed=False,
    BJ22_Theorem_6_21_repaired=False,general_envelope_theorem_admitted=False,canonical_status_changes=[],
    original_results_promoted=[],independent_model_receipt=None,baseline_commit=prep['baseline_commit'],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',actual_pages=50,actual_views=25,named_overlap=overlap,named_new_unique=46,SHA256=sha(out))))
