# Original BJKS1 Finski-dependency actual view 01

UTC: 2026-10-09T05:25:03.542521+00:00. Source: BJKS1_AIF2025. Physical pages: 1, 2.

Read the complete selected text and displayed matching rendered image. This is the controlling Annales de l'Institut Fourier 75(2), 2025, pp. 829–927, DOI 10.5802/aif.3668, authored by Boucksom and Jonsson. Physical page 1 is an added publisher cover, so printed page 829 is physical page 2. The abstract concerns polarized varieties over a trivially valued ground field, finite-generated filtrations, Hausdorff completions and finite-energy measures; it does not supply a general local weak-psh or Siu theorem. The cover's CC-BY-ND licence is preserved by retaining the unmodified source in cloud primary-source storage; this source checkpoint will upload authored audit records, rather than represent source extraction as original book prose. Whole-paper or independent-verifier clearance is not claimed from the abstract.
