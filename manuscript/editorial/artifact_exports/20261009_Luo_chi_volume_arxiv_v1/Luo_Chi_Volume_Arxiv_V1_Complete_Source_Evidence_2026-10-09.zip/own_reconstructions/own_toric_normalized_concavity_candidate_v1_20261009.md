# Toric normalized-concavity diagnostic candidate

**UNVERIFIED FOR PROMOTION.** This is an own reconstruction addressing
the literal Proposition 3.11 in arXiv:2303.01604v1. It is outside book
theorem typography and changes no canonical problem status. No independent
production-verifier receipt is available. The 2025 journal version has
not been obtained, so no verdict about its corresponding assertions is
made. The intended Hilbert–Samuel, continuity and birational-invariance
conclusions are separate from this normalized-concavity assertion.

## Geometry and specified metrics

Use F=Q with one unit-measure trivial absolute value. This is a proper
adelic curve with perfect countable field, discrete sigma-algebra, zero
Archimedean measure and a finite positive-measure subset.

Let P be the integral triangle with vertices (0,0),(8,0),(0,8).
Let Q be the rectangle [0,1] x [0,8]. Their normal fans have a common
smooth projective refinement with outward primitive rays
(-1,0),(0,-1),(1,0),(1,1),(0,1), in cyclic order. It is the toric
surface obtained from P2 by blowing up the two relevant torus-fixed
vertices, equivalently from P1 x P1 by blowing up one vertex.
On that surface, let L1 and L2 be the nef semiample big toric line
bundles with polytopes P and Q. Big here means geometric big, as in
the source's Definition 3.1; ampleness of these pullbacks is not claimed.
The toric flag at (0,0) gives Delta(L1)=P, Delta(L2)=Q and
Delta(L1+L2)=P+Q.

Choose the continuous semipositive toric metrics with roofs

    rho1(x,y) = -x on P,       rho2(x,y) = 0 on Q.

In additive real torus coordinates u,v their convex potentials are

    psi1(u,v) = max(0, 8(u-1), 8v),
    psi2(u,v) = max(0,u) + 8 max(0,v).

These explicit support functions specify the metrics, rather than
assuming that geometric degrees determine them. The tensor metric
has potential psi1+psi2 and roof

    rho3(x,y) = -max(0,x-1) on P+Q.

Indeed, for a decomposition (x,y)=(x1,y1)+(x2,y2), maximizing -x1
minimizes x1=max(0,x-1). This choice is feasible at each point of
P+Q, whose vertical height is 16 for 0<=x<=1 and 17-x for
1<=x<=9.

## Exact section norms and degrees

In H0(nL1), monomials with i,j>=0, i+j<=8n have norms exp(i).
In H0(nL2), monomials with 0<=i<=n, 0<=j<=8n have norm one.
In H0(n(L1+L2)), the monomial norm is exp(max(0,i-n)).
These bases are orthogonal over the trivially valued field. The upper
bound follows from the monomial metric bounds and the ultrametric
triangle inequality. Gauss seminorms at (u,v)=(0,0) and (1,0) give
the exact lower bounds for a polynomial: its norm is the maximum
of its monomial weights, since nonzero coefficients have norm one.

Thus the slopes are the negatives of the displayed logarithmic
weights. All lower normalized minimal slopes are finite: -8, 0, -8.
The first bundle has

    rank H0(nL1) = (8n+1)(8n+2)/2,
    degree H0(nL1) = -(8n)(8n+1)(8n+2)/6.

For the tensor product, putting z=i-n in the nonzero-weight strip,

    degree = -sum_{z=1}^{8n} z(16n-z+1)
           = -(8n)(8n+1)(32n+2)/6.

Its rank is

    (9n+1)(16n+1) - (8n)(8n+1)/2.

Dividing ranks by n^2/2 and total degrees by n^3/6 yields

    vol(L1)=64,       chi_vol(L1)=-512,
    vol(L2)=16,       chi_vol(L2)=0,
    vol(L1+L2)=224,   chi_vol(L1+L2)=-2048.

Consequently the proposed normalized inequality has left side -64/7,
while the sum of the right sides is -8. Their difference is -8/7.
This uses signed total degree, rather than positive-degree arithmetic
volume. Adding a positive constant to either roof changes its
normalized chi-volume by three times that constant; it cannot remove
this difference.

## Independent integral calculation

The area of P is 32 and the average of rho1 is -8/3.
The area of Q is 8 and the average of rho2 is zero.
The area of P+Q is 112, while

    integral rho3 = -integral_0^8 z(16-z) dz = -1024/3.

Its average is -64/21, less than -8/3 by 8/21. With the usual
lattice Lebesgue measure, chi-volume is 3! times the roof integral,
so chi-volume/geometric-volume is three times the average.
The failure of the normalized-average implication is independent
of the separate missing-factorial issue in the source.

## Remaining verification boundary

The own exact helper checks the finite lattice sums, polynomial ranks,
limits, polygon integrals and strict rational difference. These checks
are not an independent proof verifier. The whole geometric/metric
realization and source-category match require an exact-current
independent audit before any original-result promotion. In particular,
this note does not declare the source's ample-only Theorem 4.3
refuted: passing from these nef pullbacks to ample bundles would
require an additional specified construction. No claim about the
unread journal version, general Fujita approximation, envelopes or
the book's 42 open atoms is inferred.
