from pathlib import Path
from datetime import datetime,timezone
import urllib.request,hashlib,json,fitz,subprocess,re
D=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Luo_chi_volume_dependency_review_20261009/LuoArxivV1')
assert not D.exists();D.mkdir(parents=True);rows=[]
for suffix,url in [('html','https://arxiv.org/abs/2303.01604v1'),('pdf','https://arxiv.org/pdf/2303.01604v1')]:
 with urllib.request.urlopen(url,timeout=45) as r:
  data=r.read(32*1024*1024+1);assert len(data)<=32*1024*1024
  status=r.status;ctype=r.headers.get('Content-Type');resolved=r.geturl()
 p=D/('Luo_Chi_Volume_2303.01604v1.'+suffix);assert not p.exists();p.write_bytes(data)
 rows.append(dict(path=str(p),URL=url,resolved_URL=resolved,HTTP=status,Content_Type=ctype,
  bytes=len(data),SHA256=hashlib.sha256(data).hexdigest(),UTC=datetime.now(timezone.utc).isoformat()))
pdf=D/'Luo_Chi_Volume_2303.01604v1.pdf';assert pdf.read_bytes().startswith(b'%PDF')
with fitz.open(pdf) as doc:pages=len(doc)
txt=pdf.with_suffix('.txt');subprocess.run(['pdftotext','-layout',str(pdf),str(txt)],check=True)
out=D/'source_acquisition_v1_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
 status='ACQUIRED PINNED PRIMARY SOURCE — no reading credit',
 source_version='2303.01604v1, 2 March 2023',physical_pages=pages,files=rows,
 extracted_text_SHA256=hashlib.sha256(txt.read_bytes()).hexdigest(),
 later_journal_version='European Journal of Mathematics 11 (2025), Paper 33; not read here',
 version_comparison_performed=False,full_source_read=False,book_changed=False,
 native_catalogue_changed=False,original_results_promoted=[],helper_source=__file__,
 helper_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(pages=pages,files=rows),ensure_ascii=False))
