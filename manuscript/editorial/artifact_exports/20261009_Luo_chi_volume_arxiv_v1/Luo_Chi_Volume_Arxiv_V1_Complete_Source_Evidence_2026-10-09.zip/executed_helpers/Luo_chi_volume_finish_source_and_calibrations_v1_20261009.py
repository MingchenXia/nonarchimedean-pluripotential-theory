from pathlib import Path
from datetime import datetime,timezone
from math import comb,factorial
from fractions import Fraction as Q
import hashlib,json,sympy as sp

R=Path('/workspace/nonarchimedean-pluripotential-theory')
D=R/'source_material/Luo_chi_volume_dependency_review_20261009/LuoArxivV1'
J=R/'source_material/Luo_chi_volume_dependency_review_20261009/LuoJournal2025'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
prep=json.loads((D/'scope_preparation_v1_20261009.json').read_text())
receipts=[];pages=[]
for n,x in enumerate(prep['entries'],1):
 note=D/f'primary_notes_v1/note_{n:02d}.md';p=note.with_suffix('.json')
 r=json.loads(p.read_text())
 assert r['number']==n and r['physical_pages']==x['physical_pages']
 assert r['complete_text_actually_read'] and r['matching_image_actually_viewed']
 assert sha(note)==r['note_SHA256'] and sha(x['image_path'])==r['image_SHA256'] and sha(x['text_path'])==r['text_SHA256']
 assert r['PDF_SHA256']==prep['PDF_SHA256']==sha(prep['PDF'])
 assert r['previous_receipt_SHA256']==(receipts[-1]['receipt_SHA256'] if n>1 else None)
 receipts.append(dict(number=n,pages=x['physical_pages'],note_SHA256=sha(note),receipt_SHA256=sha(p)))
 pages.extend(x['physical_pages'])
assert pages==list(range(1,26)) and len(receipts)==13
assert sha(R/'manuscript/book.pdf')=='79a07672385e2ace08e064474a0948b8acdaae8ac6b43f94aecbc36afd10e45c'
assert sha(R/'output/open_problems_catalogue_2026-10-03.tex')=='2d55114885d92f1ceacc17e74a2c397d992fb049d0f40810847787bff2f70fe8'
N=sp.symbols('N',positive=True)
counts={};limits=[];finite=0
for d in range(4):
 rank=sp.Integer(1)*sp.prod(N+j for j in range(1,d+1))/sp.Integer(factorial(d))
 for c in [Q(-1),Q(-1,4),Q(0),Q(1,4),Q(1),Q(2)]:
  C=sp.Rational(c.numerator,c.denominator)
  expr=sp.cancel(rank*N*C*sp.Integer(factorial(d+1))/N**(d+1))
  limit=sp.limit(expr,N,sp.oo);assert limit==(d+1)*C
  integral=C/sp.Integer(factorial(d))
  assert sp.factorial(d+1)*integral==limit
  limits.append(dict(d=d,c=str(c),signed_chi_limit=str(limit),usual_roof_integral=str(integral)))
  for n in range(1,17):
   r=comb(n+d,d);total=Q(r*n)*c;positive=Q(r*n)*max(c,Q(0))
   assert total==Q(r*n)*c and positive>=total and positive>=0
   finite+=1
counts['constant_metric_degree_and_positive_degree_cases']=finite
counts['exact_symbolic_signed_chi_and_roof_limits']=len(limits)
sq=0
for n in range(1,17):
 for m in range(1,17):
  assert (n+m)**2-n*n-m*m==2*n*m>0
  assert (n*m)**2//m==n*n*m
  sq+=1
counts['rank_one_square_exponent_cases']=sq
assert sp.limit(sp.exp(N),N,sp.oo)==sp.oo and sp.limit(sp.exp(-N),N,sp.oo)==0
literal_L_chi=Q(2*2);literal_M_chi=Q(2)
literal_bound=literal_M_chi-2*Q(1)*(2-1)
assert literal_L_chi==4 and literal_bound==0
corrected_source_chi=Q(2);corrected_target_chi=Q(4)
assert corrected_source_chi==corrected_target_chi-2*Q(1)*(2-1)
counts['lemma36_literal_direction_witnesses']=1
counts['lemma36_corrected_direction_equalities']=1
z=sp.symbols('z',real=True)
polygon_integral=sp.integrate(-z*(16-z),(z,0,8))
assert polygon_integral==-sp.Rational(1024,3)
assert sp.Rational(112)>0 and polygon_integral/112==-sp.Rational(64,21)
assert polygon_integral/112+sp.Rational(8,3)==-sp.Rational(8,21)
rank1=(8*N+1)*(8*N+2)/2
degree1=-(8*N)*(8*N+1)*(8*N+2)/6
rank2=(N+1)*(8*N+1)
rank3=(9*N+1)*(16*N+1)-(8*N)*(8*N+1)/2
degree3=-(8*N)*(8*N+1)*(32*N+2)/6
expected=[64,16,224,-512,-2048]
actual=[sp.limit(2*rank1/N**2,N,sp.oo),sp.limit(2*rank2/N**2,N,sp.oo),
 sp.limit(2*rank3/N**2,N,sp.oo),sp.limit(6*degree1/N**3,N,sp.oo),
 sp.limit(6*degree3/N**3,N,sp.oo)]
assert actual==expected
toric=0
for n in range(1,33):
 a=8*n
 r1=sum(a-i+1 for i in range(a+1));deg1=-sum(i*(a-i+1) for i in range(a+1))
 r3=sum((16*n+1 if i<=n else 17*n-i+1) for i in range(9*n+1))
 deg3=-sum(max(0,i-n)*(16*n+1 if i<=n else 17*n-i+1) for i in range(9*n+1))
 assert r1==rank1.subs(N,n) and deg1==degree1.subs(N,n)
 assert r3==rank3.subs(N,n) and deg3==degree3.subs(N,n)
 toric+=1
assert Q(-2048,224)-Q(-512,64)==Q(-8,7)
counts['toric_candidate_exact_finite_lattice_sums']=toric
counts['toric_candidate_exact_asymptotic_limits']=5
counts['toric_candidate_exact_polygon_integral']=1
out=D/'own_exact_normalization_calibrations_v1_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=now(),status='PASS — own exact normalization diagnostics; original toric candidate UNVERIFIED',
 source_version='2303.01604v1',PDF_SHA256=prep['PDF_SHA256'],counts=counts,
 constant_metric_limits=limits,
 rank_one_spectral_models=dict(literal_printed_direction='norm_n=exp(n^2), spectral limit infinity',
 corrected_direction_without_right_bound='norm_n=exp(-n^2), spectral limit zero'),
 lemma36_literal=dict(L='O(2), total constant shift1',M='O(1), total constant shift1',
 s='nonzero section of L-M=O(1), canonical norm1 and degree0',L_chi=4,printed_bound=0,
 corrected_input_direction='s belongs to M-L and quotient rank is rank(M)-rank(L)'),
 toric_candidate=dict(status='UNVERIFIED FOR PROMOTION; exact calculations only',
 geometric_volumes=[64,16,224],signed_chi_volumes=[-512,0,-2048],
 normalized_difference='-8/7',candidate_SHA256=sha(D/'own_toric_normalized_concavity_candidate_v1_20261009.md')),
 finite_checks_are_not_universal_verification=True,main_Hilbert_Samuel_refuted=False,
 main_birational_invariance_refuted=False,main_continuity_refuted=False,journal_version_checked=False,
 original_results_promoted=[],independent_verifier_receipt=None,helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
journal=json.loads((J/'source_acquisition_v1_20261009.json').read_text())
assert journal['physical_pages'] is None
fake=J/'Luo_Chi_Volume_Journal2025.pdf'
assert fake.exists() and not fake.read_bytes().startswith(b'%PDF')
precision=D/'own_journal_access_precision_v1_20261009.json';assert not precision.exists()
precision.write_text(json.dumps(dict(UTC=now(),status='JOURNAL FULL TEXT UNAVAILABLE — public publisher metadata/abstract only',
 DOI='10.1007/s40879-025-00826-9',publisher_page_full_paper_read=False,publisher_HTML_body_sections=['Abstract','References','Author information','Additional information','Rights and permissions','About this article'],
 publisher_metadata_flags={'Open Access':'N','hasAccess':'N','bypassPaywall':'N'},
 PDF_URL_response='HTML returned, not a PDF',response_file_extension='The frozen .pdf-suffix response is HTML and is not a journal PDF',
 HTML_response_SHA256=sha(fake),physical_PDF_pages_read=0,journal_proof_reading_credit=0,
 version_comparison_performed=False,metadata_only_OpenAlex=str(Path('/workspace/book-completion-drafts/Luo_chi_volume_open_copy_metadata_v1_20261009.json')),
 access_controls_bypassed=False,book_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
p=D/'actual_complete_source_checkpoint_v1_20261009.json';assert not p.exists()
p.write_text(json.dumps(dict(UTC=now(),status='DONE — actual full pinned arXiv v1 reading; ordinary scoped reconstruction pending',
 source_version='arXiv:2303.01604v1, 2 March2023',internal_footer_date='6 March2023',
 PDF=prep['PDF'],PDF_SHA256=prep['PDF_SHA256'],physical_pages_read=pages,unique_physical_pages=25,
 full_source_read=True,fresh_matching_views=13,reused_matching_views=0,receipts=receipts,
 preparation_SHA256=sha(D/'scope_preparation_v1_20261009.json'),acquisition_SHA256=sha(D/'source_acquisition_v1_20261009.json'),
 own_exact_calibrations_SHA256=sha(out),journal_access_precision_SHA256=sha(precision),
 own_toric_candidate_SHA256=sha(D/'own_toric_normalized_concavity_candidate_v1_20261009.md'),
 original_toric_candidate_status='UNVERIFIED FOR PROMOTION',
 main_results_status='NOT IMPORTED; version-specific literal repairs and dependency reconstruction required',
 intended_main_results_refuted=False,later_journal_full_source_read=False,version_comparison_performed=False,
 deeper_primary_dependencies_recursively_verified=False,active_book_changed=False,native_editor_changed=False,
 original_results_promoted=[],canonical_status_changes=[],whole_book_reading_claim=False,
 helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(full_pages=25,fresh_views=13,checkpoint_SHA256=sha(p),calibrations_SHA256=sha(out),
 journal_access_record_SHA256=sha(precision),counts=counts)))
