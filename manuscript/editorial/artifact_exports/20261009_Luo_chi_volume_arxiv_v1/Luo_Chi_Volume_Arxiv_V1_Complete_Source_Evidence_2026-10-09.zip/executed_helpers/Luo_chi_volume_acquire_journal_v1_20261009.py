from pathlib import Path
from datetime import datetime,timezone
import urllib.request,urllib.error,hashlib,json,fitz,subprocess
D=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Luo_chi_volume_dependency_review_20261009/LuoJournal2025')
assert not D.exists();D.mkdir(parents=True);rows=[]
for suffix,url in [('html','https://link.springer.com/article/10.1007/s40879-025-00826-9'),('pdf','https://link.springer.com/content/pdf/10.1007/s40879-025-00826-9.pdf')]:
 try:
  with urllib.request.urlopen(url,timeout=40) as r:
   data=r.read(32*1024*1024+1);assert len(data)<=32*1024*1024
   status=r.status;ctype=r.headers.get('Content-Type');resolved=r.geturl()
  p=D/('Luo_Chi_Volume_Journal2025.'+suffix);assert not p.exists();p.write_bytes(data)
  rows.append(dict(path=str(p),URL=url,resolved_URL=resolved,HTTP=status,Content_Type=ctype,bytes=len(data),
   SHA256=hashlib.sha256(data).hexdigest(),UTC=datetime.now(timezone.utc).isoformat()))
 except Exception as exc:
  rows.append(dict(URL=url,UTC=datetime.now(timezone.utc).isoformat(),acquired=False,
   error_type=type(exc).__name__,error=str(exc)[:500]))
pdf=D/'Luo_Chi_Volume_Journal2025.pdf';pages=None
if pdf.exists() and pdf.read_bytes().startswith(b'%PDF'):
 with fitz.open(pdf) as doc:pages=len(doc)
 subprocess.run(['pdftotext','-layout',str(pdf),str(pdf.with_suffix('.txt'))],check=True)
out=D/'source_acquisition_v1_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
 status='PRIMARY JOURNAL ACQUISITION; no reading credit',
 DOI='10.1007/s40879-025-00826-9',journal='European Journal of Mathematics 11 (2025), Paper 33',
 published='22 May 2025',physical_pages=pages,files=rows,full_source_read=False,
 version_comparison_performed=False,book_changed=False,native_catalogue_changed=False,
 original_results_promoted=[],helper_source=__file__,
 helper_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(pages=pages,files=rows),ensure_ascii=False))
