from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile
R=Path('/workspace/nonarchimedean-pluripotential-theory')
D=R/'source_material/Luo_chi_volume_dependency_review_20261009/LuoArxivV1'
J=R/'source_material/Luo_chi_volume_dependency_review_20261009/LuoJournal2025'
E=R/'manuscript/editorial'
A=E/'artifact_exports/20261009_Luo_chi_volume_arxiv_v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
cp=D/'actual_complete_source_checkpoint_v1_20261009.json';c=json.loads(cp.read_text())
assert c['full_source_read'] and c['physical_pages_read']==list(range(1,26)) and c['fresh_matching_views']==13
assert c['original_toric_candidate_status']=='UNVERIFIED FOR PROMOTION'
for x in c['receipts']:
 n=x['number'];p=D/f'primary_notes_v1/note_{n:02d}.md';q=p.with_suffix('.json')
 assert sha(p)==x['note_SHA256'] and sha(q)==x['receipt_SHA256']
assert sha(R/'manuscript/book.pdf')=='79a07672385e2ace08e064474a0948b8acdaae8ac6b43f94aecbc36afd10e45c'
assert sha(R/'output/open_problems_catalogue_2026-10-03.tex')=='2d55114885d92f1ceacc17e74a2c397d992fb049d0f40810847787bff2f70fe8'
assert not A.exists();A.mkdir(parents=True)
review=E/'Luo_chi_volume_complete_source_review_v1_20261009.md'
notes=E/'Luo_chi_volume_complete_source_reading_notes_v1_20261009.md'
manifest=E/'Luo_chi_volume_complete_source_manifest_v1_20261009.json'
artifacts=E/'Luo_chi_volume_complete_source_artifacts_v1_20261009.json'
for p in [review,notes,manifest,artifacts]:assert not p.exists()
review.write_bytes((D/'own_complete_source_review_v1_20261009.md').read_bytes())
notes.write_text('# Actual complete arXiv v1 source reading notes\n\n'
 'Twenty-five physical pages in thirteen fresh matching text/image views.\n'
 'The 2025 journal proof is unread. No new book reading credit or original\n'
 'theorem promotion is supplied by this source-only audit.\n\n'+
 '\n\n'.join('## View '+str(n)+'\n\n'+(D/f'primary_notes_v1/note_{n:02d}.md').read_text().strip() for n in range(1,14))+'\n')
members={}
for n in range(1,14):
 for suffix in ['md','json']:
  p=D/f'primary_notes_v1/note_{n:02d}.{suffix}'
  members['actual_reading/'+p.name]=p
for name in ['source_acquisition_v1_20261009.json','scope_preparation_v1_20261009.json',
             'own_exact_normalization_calibrations_v1_20261009.json','actual_complete_source_checkpoint_v1_20261009.json']:
 members['records/'+name]=D/name
for name in ['own_complete_source_review_v1_20261009.md','own_toric_normalized_concavity_candidate_v1_20261009.md']:
 members['own_reconstructions/'+name]=D/name
members['records/own_journal_access_precision_v1_20261009.json']=D/'own_journal_access_precision_v1_20261009.json'
members['records/journal_acquisition_v1_20261009.json']=J/'source_acquisition_v1_20261009.json'
for name in ['Luo_chi_volume_primary_discovery_v1_20261009.json','Luo_chi_volume_journal_metadata_v1_20261009.json',
             'Luo_chi_volume_open_copy_metadata_v1_20261009.json']:
 members['metadata/'+name]=Path('/workspace/book-completion-drafts')/name
for kind in ['acquire','prepare_source_views','record_source_note','finish_source_and_calibrations',
             'acquire_journal','export_complete_source']:
 p=Path('/tmp/Luo_chi_volume_'+kind+'_v1_20261009.py');assert p.exists()
 members['executed_helpers/'+p.name]=p
assert len(members)==43
archive=A/'Luo_Chi_Volume_Arxiv_V1_Complete_Source_Evidence_2026-10-09.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for name,p in members.items():z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(members)
 for name,p in members.items():assert z.read(name)==p.read_bytes()
obj=dict(UTC=now(),status='ACTUAL FULL PINNED ARXIV V1 READING; own scoped audit and original candidate unverified',
 source_version='arXiv:2303.01604v1, 2 March 2023',internal_footer='6 March 2023',
 source_PDF_SHA256=c['PDF_SHA256'],source_PDF_bytes=Path(c['PDF']).stat().st_size,
 actual_unique_primary_pages=25,fresh_matching_views=13,reused_matching_views=0,
 complete_source_checkpoint_SHA256=sha(cp),actual_receipts=c['receipts'],
 mathematical_calibration_SHA256=sha(D/'own_exact_normalization_calibrations_v1_20261009.json'),
 own_toric_candidate_SHA256=sha(D/'own_toric_normalized_concavity_candidate_v1_20261009.md'),
 original_toric_candidate_status='UNVERIFIED FOR PROMOTION',independent_verifier_receipt=None,
 journal_DOI='10.1007/s40879-025-00826-9',journal_proof_read=False,journal_actual_PDF_pages_read=0,
 journal_pdf_response_was_HTML=True,version_comparison_performed=False,
 journal_access_record_SHA256=sha(D/'own_journal_access_precision_v1_20261009.json'),
 main_results_refuted=False,main_results_imported=False,deeper_dependencies_recursively_verified=False,
 ordinary_source_audit=True,archive=str(archive.relative_to(R)),archive_members=43,
 archive_SHA256=sha(archive),archive_bytes=archive.stat().st_size,all_members_byte_verified=True,
 archive_excludes=['Primary paper PDFs','Primary paper full texts','Primary rendered source pages','Book or catalogue PDFs'],
 book_pages=4685,active_book_changed=False,
 book_PDF_SHA256=sha(R/'manuscript/book.pdf'),native_catalogue_changed=False,
 native_catalogue_SHA256=sha(R/'output/open_problems_catalogue_2026-10-03.tex'),
 native_compile_success_verified=False,native_editor_kept_open=True,
 canonical_atoms=42,formal_problems=12,canonical_tiers=[0,3,7,15,17],
 original_results_promoted=[],canonical_status_changes=[],BJ22_general_homogeneous_Siu='OPEN',LPWZ_density='UNVERIFIED',
 whole_book_rereading_claim=False,helper_source=__file__,helper_SHA256=sha(__file__))
manifest.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
artifacts.write_text(json.dumps(dict(UTC=now(),archive=obj['archive'],SHA256=sha(archive),
 bytes=archive.stat().st_size,members=43,all_members_byte_verified=True,
 primary_text_or_images_redistributed=False,original_toric_candidate_status='UNVERIFIED FOR PROMOTION',
 journal_proof_read=False,book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
(A/'README.md').write_text(
 '# Luo chi-volume arXiv v1: complete source evidence, 9 October 2026\n\n'
 'The pinned 25-page arXiv:2303.01604v1 was actually read in thirteen\n'
 'ordered matching text/image views. The 43-member archive contains own\n'
 'notes, chained receipts, reconstructions, exact diagnostics, metadata,\n'
 'journal-access records and frozen executed helpers. Every member was\n'
 'verified byte-for-byte. Paper PDFs, full texts and rendered source pages\n'
 'are excluded. Upload adds no reading credit or theorem clearance.\n\n'
 'The source audit retains the signed-degree chi-volume convention,\n'
 'the section/quotient direction, slope bounds and source-version scope.\n'
 'The toric normalized-concavity candidate is **UNVERIFIED FOR PROMOTION**;\n'
 'its exact lattice/integral calculations are not an independent receipt.\n'
 'No main Hilbert–Samuel, birational or continuity result is declared\n'
 'refuted. The separate 2025 journal proof cited by Liu remains unread:\n'
 'its public PDF request returned HTML and full-text access is unavailable.\n\n'
 'The active 4,685-page book and same native catalogue are unchanged.\n'
 'Canonical 42-atom/twelve-problem statuses are unchanged. General BJ22\n'
 'homogeneous Siu stays OPEN; no original theorem is promoted.\n')
(A/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in [archive,A/'README.md']))
p=R/'README.md'
p.write_text(p.read_text().rstrip()+
 '\n\n**Luo chi-volume primary-source checkpoint, 9 October 2026:**\n'
 'all 25 physical pages of arXiv:2303.01604v1 were actually read in thirteen\n'
 'ordered matching text/image views. The [complete source audit](manuscript/editorial/Luo_chi_volume_complete_source_review_v1_20261009.md)\n'
 'and [43-member evidence](manuscript/editorial/artifact_exports/20261009_Luo_chi_volume_arxiv_v1/README.md)\n'
 'retain the signed-degree convention and version-specific reconstruction\n'
 'requirements. The normalized-concavity candidate is UNVERIFIED FOR\n'
 'PROMOTION. The 2025 journal proof cited by Liu remains unread; its PDF\n'
 'request returned HTML without full-text access. The 4,685-page book,\n'
 'same native catalogue and canonical statuses are unchanged.\n')
p=E/'second_reading_and_research_programme_20261002.md'
p.write_text(p.read_text().rstrip()+
 '\n\n### Complete Luo chi-volume arXiv v1 reading, 9 October 2026\n\n'
 'Read all 25 physical pages of 2303.01604v1 in thirteen ordered matching\n'
 'text/image views. The primary audit distinguishes signed chi-volume from\n'
 'positive-degree arithmetic volume, retains the Section 3/4 hypotheses,\n'
 'and records product-norm, factorial and section-direction reconstruction.\n'
 'An explicit toric normalized-concavity candidate has exact lattice sums\n'
 'and polygon integrals, with normalized difference -8/7, but remains\n'
 'UNVERIFIED FOR PROMOTION without an independent exact-current receipt.\n'
 'It does not close a canonical problem or refute the intended main\n'
 'Hilbert–Samuel, birational-invariance or continuity conclusions.\n\n'
 'The 2025 journal edition, DOI 10.1007/s40879-025-00826-9, is separate.\n'
 'Public publisher responses give abstract/metadata only; the PDF URL\n'
 'returned HTML, never counted as a PDF or proof reading. Open-copy\n'
 'metadata found no open location. No version-wide proof comparison is\n'
 'claimed. Liu cites this journal version for the preceding birational\n'
 'bigness step, not its later small-section step.\n\n'
 'See [full source audit](Luo_chi_volume_complete_source_review_v1_20261009.md)\n'
 'and [43-member evidence](artifact_exports/20261009_Luo_chi_volume_arxiv_v1/README.md).\n'
 'The active 4,685-page book and same native catalogue are unchanged;\n'
 'tiers (0,3,7,15,17) remain exact. Upload adds no reading credit or\n'
 'independent mathematical clearance. Work continues cloud-only.\n')
owned=[review,notes,manifest,artifacts,archive,A/'README.md',A/'SHA256SUMS',
       R/'README.md',E/'second_reading_and_research_programme_20261002.md']
assert len(owned)==9
out=D/'complete_source_evidence_export_v1_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=now(),status='AUTHORED SOURCE EVIDENCE EXPORTED AND BYTE VERIFIED',
 archive_SHA256=sha(archive),archive_members=43,
 owned_files=[dict(path=str(p.relative_to(R)),SHA256=sha(p),bytes=p.stat().st_size) for p in owned],
 member_files=[dict(name=n,SHA256=sha(p),bytes=p.stat().st_size) for n,p in members.items()],
 original_results_promoted=[],canonical_status_changes=[],journal_proof_read=False,
 helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(owned_files=9,archive_members=43,archive_bytes=archive.stat().st_size,
 archive_SHA256=sha(archive),export_SHA256=sha(out))))
