# Reboulet Witt Nystrom flats actual primary view 03

UTC: 2026-10-09T03:31:38.540166+00:00. Physical pages: 5, 6.

Read the complete selected text and displayed matching rendered image.

Physical pages 5–6 give finite complex spectral distances, sequence pseudodistances and the initial quantization formulas. Successive minima are logarithms of norm ratios, not logarithms of squared Gram eigenvalues; for Hermitian norms they are half the log Gram eigenvalues. The probability normalization is 1/N. The relative signed mean is consistent with this convention, and the finite Hermitian maximum identity (1.4) follows in a common orthogonal basis.

The displayed 'unique geodesic' formula in Proposition 1.1 is a sum of absolute coordinates times interpolated norm weights. That is a weighted l1 norm, not a Hermitian norm. In rank two with equal standard Euclidean endpoints it gives |a|+|b|, differing from sqrt(|a|^2+|b|^2) already at t=0 and t=1. The corrected Hermitian formula is the square root of the sum of |c_i|^2 times the squared interpolated weights. This is a direct endpoint/type diagnostic, not a denial of the usual Hermitian geodesic theorem.

Section 1.2 defines sequence distances and volumes by limsup. Formula (1.5) cannot hold for arbitrary relatively bounded sequences merely by passing the finite identity to limsup. Take eta_k any Hermitian norm on H0(P1,kO(1)) and xi_k=exp((-1)^k k) eta_k. The left normalized d1 is always 1. The two normalized distances to the Hermitian maximum alternate between 1 and 0, so each limsup is 1 and the printed right side is 2. The signed volume limsups in opposite orders are both 1 as well. An actual common limit or a restricted submultiplicative convergence setting is needed before using a signed cocycle or the asymptotic maximum identity. This example is for the literal arbitrary-sequence definition and does not challenge an applicable theorem for submultiplicative sequences with established limits.

The opening L2 expression on page 6 prints |s| rather than |s|^2 inside a formula for the squared norm; literal scalar scaling would not be quadratic. Its sup-norm exponent must also be checked against the squared-metric convention and the later FS definition. The finite norm contraction/metric claims are cited to BE21 and Fin23, whose precise Archimedean hypotheses are separate primary inputs.

These actual two-page observations remain ordinary source diagnostics, with no active book change, original general theorem, canonical status change or independent-model receipt.
