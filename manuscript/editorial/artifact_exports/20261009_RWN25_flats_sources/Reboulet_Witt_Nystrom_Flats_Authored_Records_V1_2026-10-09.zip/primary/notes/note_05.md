# Reboulet Witt Nystrom flats actual primary view 05

UTC: 2026-10-09T03:33:26.214277+00:00. Physical pages: 9, 10.

Read the complete selected text and displayed matching rendered image.

Physical pages 9–10 give a properly bounded trivially valued graded-norm class and, importantly, the actual support-domain repair. The ground field for this construction is C with its trivial absolute value. Every finite-dimensional norm has an adapted orthogonal basis; this exact fact does not transfer to arbitrary norms for a nontrivial absolute value. The graded bound is explicitly exp(-delta k) times the trivial norm <= F_k <= exp(delta k) times the trivial norm. Thus it is not the vacuous unrestricted-reference definition in the 2026 paper. The filtration norm has basis weights exp(-a_i), correcting the introductory omission of the exponential.

The normalized spectral arguments in the construction are -log F(s_i)/k. Section 2.2 explicitly acknowledges that some finite arguments can lie below the limiting support [a,b]. For f with bounded right derivative, it extends f affinely below a, with slope f'_+(a), to a fixed segment containing all arguments. The source says this extension is always implicit thereafter. This supplies a real, separately stated convention that was not spelled out in the 2026 norm formula. Its explanation accidentally writes positive log F/k when referring to the negative-log spectral arguments; the sign must follow the actual measure and construction formula.

The stated claim that extension values do not affect asymptotics needs its precise topology: finite-p spectral probabilities with common bounded interval and continuous extensions can ignore values on a limiting-null part; the strong infinity metric does not generally ignore rare spectral outliers. The earlier exp(k) constant-monomial example detects this distinction. The arbitrary-derivative case is deferred to a completeness/approximation procedure later in the main theorem, not claimed by the finite-degree formula alone.

Example 2.1 correctly maps f=0 to the trivial norm and f(x)=-x to the original norm. The measure display uses k^{-n} total mass, so no probability normalization can be silently assigned. BC11/CM15 convergence and BHJ17 Corollary 5.4/Remark 5.5 are the cited original inputs for support and finite spectral bounds; their actual hypotheses remain separate dependencies. No new general theorem or independent model receipt is asserted.
