# Reboulet Witt Nystrom flats actual primary view 02

UTC: 2026-10-09T03:31:01.394330+00:00. Physical pages: 3, 4.

Read the complete selected text and displayed matching rendered image.

Physical pages 3–4 explicitly describe the support repair: first define the construction for convex decreasing f on all of R, then approximate functions on the limiting DH support by globally defined functions and extend using metric completeness. This is an additional procedure absent from the literal finite-degree formula in the 2026 filtration paper. Its actual proof in §2.2 and §3 remains to be checked; the introduction cannot by itself settle finite-degree evaluation or representative independence.

The modified FS expression uses squared section lengths multiplied by exp(-k f(lambda/k)). The corresponding Hermitian norm weights must therefore have logarithmic shift k f/2 if the norm denotes the square root of the L2 integral. Later conventions need checking before asserting the displayed dp equality. The limiting DH mass is still degree-volume normalized, not assumed probability normalized.

The introductory filtration-to-norm display sets the norm equal to the supremum of filtration indices. That is a weight, potentially zero or negative, and not a positive definite ultrametric norm. The usual positive norm is exp(-sup lambda); the body must fix the sign and exponential. The introductory assertion that every bounded filtration gives an infinite-dimensional cone also needs a nontrivial spectral-support qualification: a scalar filtration has a singleton support and only a one-dimensional function cone.

Uniform approximation of every bounded convex decreasing function by global convex functions requires an endpoint-continuity convention. A bounded convex function on a closed interval can jump at the left endpoint: f(0)=1 and f(x)=0 for x>0 on [0,1] is convex and decreasing but not continuous, so cannot be a uniform limit of continuous restrictions. This diagnoses the literal introductory phrasing only. The source may use a more precise function class or Lp/completeness argument in the body, which is not yet reviewed.

The main theorem is stated for a continuous positive initial metric on an ample line bundle over a compact projective complex manifold. Finski's quantization/isometry inputs are explicitly external. This partial reading supplies no imported general theorem, canonical problem resolution or independent-model receipt.
