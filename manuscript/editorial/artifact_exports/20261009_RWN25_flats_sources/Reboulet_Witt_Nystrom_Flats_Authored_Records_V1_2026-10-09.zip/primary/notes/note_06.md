# Reboulet Witt Nystrom flats actual primary view 06

UTC: 2026-10-09T03:34:03.363584+00:00. Physical pages: 11, 12.

Read the complete selected text and displayed matching rendered image.

Physical pages 11–12 prove Theorem 2.2's submultiplicativity and begin the finite complex rescaling construction. With the extension already supplied on a common spectral interval, the algebraic proof is sound: if alpha=-log F_m(u), beta=-log F_n(v), then every nonzero coefficient of their product in an adapted basis has weight delta_j>=alpha+beta. Decreasing f and Jensen's inequality give (m+n) f(delta_j/(m+n)) <= m f(alpha/m)+n f(beta/n). Taking the maximum proves the required product bound, and the ultrametric inequality extends it to arbitrary sections. Several intermediate left sides omit the new f subscript; they must refer to the modified norm, as their right sides show. A zero product is handled directly before taking its logarithm.

The boundedness constant must be sup |f| on the full extended finite spectral interval, or another nonnegative two-sided bound. The displayed C=sup f fails for a negative constant f, when exp(-Ck) exceeds exp(Ck). The substantive conclusion still follows from boundedness of the extension. The common adapted-basis formula is intrinsically determined by the original norm levels: for a nonzero vector it applies the increasing transform r -> exp(k f(-log r/k)) to F(v), so it is independent of the adapted basis. This is a direct explanation of the existing construction, not a new general theorem.

The last flat-dimension sentence still needs a non-singleton support premise. Its strict-convexity observation is explicitly for p>1 here, correctly distinguishing it from L1. The complex apartment has the probability-normalized l_p metric, including N^{-1/p}; it is not the unnormalized counting-norm metric. The finite rescaling multiplies norm lengths by exp(-a_i), and the NA gauge uses the same exponential values. The general non-Hermitian envelope construction on the next page must be checked against these signs.

This is a qualified ordinary proof/interface review. No active book change, independent hostile-model receipt or canonical status change is claimed.
