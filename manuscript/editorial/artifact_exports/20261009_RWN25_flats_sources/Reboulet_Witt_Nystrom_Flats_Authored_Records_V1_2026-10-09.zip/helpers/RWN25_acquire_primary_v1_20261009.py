from pathlib import Path
from datetime import datetime,timezone
import urllib.request,json,hashlib,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Reboulet_Witt_Nystrom_flats_review_20261009';C.mkdir(exist_ok=True)
j=C/'primary_acquisition_v1_20261009.json';assert not j.exists();rows=[]
for extension,url in [('abs.html','https://arxiv.org/abs/2311.13451v2'),('pdf','https://arxiv.org/pdf/2311.13451v2')]:
    p=C/('Reboulet_Witt_Nystrom_2311.13451v2.'+extension);assert not p.exists();start=datetime.now(timezone.utc).isoformat()
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Book-source-audit/1.0'}),timeout=30) as response:data=response.read();resolved=response.url;ctype=response.headers.get('Content-Type')
        if extension=='pdf':assert data.startswith(b'%PDF-')
        else:assert b'<html' in data.lower() or b'<!doctype html' in data.lower()
        p.write_bytes(data);rows.append(dict(start_UTC=start,status='acquired',URL=url,resolved_URL=resolved,path=str(p),bytes=len(data),SHA256=hashlib.sha256(data).hexdigest(),content_type=ctype))
    except Exception as e:rows.append(dict(start_UTC=start,status='failed',URL=url,error_type=type(e).__name__,error=str(e)))
pdf=C/'Reboulet_Witt_Nystrom_2311.13451v2.pdf'
if pdf.exists():
    with fitz.open(pdf) as d:
        pages=len(d);t=C/'Reboulet_Witt_Nystrom_2311.13451v2.txt';assert not t.exists();t.write_text('\n'.join(f'PRIMARY PHYSICAL PAGE {i+1}\n'+p.get_text() for i,p in enumerate(d)))
    rows.append(dict(status='full text prepared only',path=str(t),bytes=t.stat().st_size,SHA256=hashlib.sha256(t.read_bytes()).hexdigest(),physical_pages=pages))
j.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='Primary acquisition only — zero actual reading credit',arxiv_version='2311.13451v2, 29 October 2025',published_IMRN_edition_audited=False,publisher_web_PDF_fetch='web tool returned 429 Too Many Requests; no publisher PDF acquired',rows=rows,actual_source_reading_credit=0,book_changed=False,GitHub_published=False,helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(rows=rows,record_SHA256=hashlib.sha256(j.read_bytes()).hexdigest())))
