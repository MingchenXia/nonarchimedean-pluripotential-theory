# Adapted frozen complete source finalizer SHA256: bcabceb917587e1a7039cf2e623fc92ea96798a02b35754d12b6c349683874f0
# Frozen unsuccessful v1 SHA256: 78aaf27c9f7a5a7e26325619ec5cc174c699dbe6698167549d2c0a08ba29a973
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Reboulet_Witt_Nystrom_flats_review_20261009'
out=C/'actual_primary_reading_v1_20261009.json'
assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=C/'primary_view_preparation_v1_20261009.json';prep=json.loads(p.read_text())
assert prep['actual_source_reading_credit']==prep['actually_read_pages']==0
assert sha(prep['source_PDF']['path'])==prep['source_PDF']['SHA256']
assert sha(prep['manifest_path'])==prep['manifest_SHA256']
rows=json.loads(Path(prep['manifest_path']).read_text())
views=[];pages=[];last=None
for i,row in enumerate(rows,1):
    receipt=C/f'primary_notes_v1/note_{i:02d}_receipt.json';a=json.loads(receipt.read_text())
    assert a['number']==i and a['physical_pages']==row['physical_pages']
    assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
    assert last is None or a['UTC']>last
    last=a['UTC']
    assert not row['actually_viewed'] and not row['selected_text_read']
    for k,h in [('image_path','image_SHA256'),('selected_text_path','selected_text_SHA256'),('note_path','note_SHA256')]:assert sha(a[k])==a[h]
    assert a['source_PDF_SHA256']==prep['source_PDF']['SHA256']==row['source_PDF_SHA256']
    assert 'Read the complete selected text and displayed matching rendered image.' in Path(a['note_path']).read_text()
    views.append(dict(batch=p.name,**a,observation_receipt_path=str(receipt),observation_receipt_SHA256=sha(receipt)))
    pages.extend(row['physical_pages'])
assert len(views)==10 and pages==list(range(1,20)) and len(set(pages))==19
for n,h in prep['protected_core_inputs'].items():assert sha(R/n)==h
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==prep['baseline_commit']
d=C/'exact_diagnostics_v1_20261009.json';diag=json.loads(d.read_text())
assert len(diag['families'])==11 and all(x['status'].startswith('PASS') for x in diag['families'])
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete pinned RWN25 v2 actually read in order; qualified ordinary source audit',source_PDF=prep['source_PDF'],actual_source_unique_pages=19,actual_individually_displayed_matching_views=10,selected_physical_pages=pages,views=views,preparation_record_SHA256={p.name:sha(p)},exact_diagnostics_SHA256=sha(d),complete_selected_text_read=True,preparation_flags_unchanged=True,whole_primary_PDF_reading_claim=True,whole_book_new_reading_claim=False,active_book_changed=False,native_editor_changed=False,baseline_commit=prep['baseline_commit'],arxiv_version='2311.13451v2, 29 October 2025',published_IMRN_edition_audited=False,ordinary_importable_interfaces=['Finite-right-derivative affine extension over the full finite spectral interval','Decreasing-convex functional calculus preserves genuinely bounded trivial graded norms','Complex sum-envelope construction and correctly summed product bound','Weighted Hermitian/envelope logarithmic-rank comparison, without exact equality','Source-stated common-flat, big/prescribed/Kahler and toric-degeneration research directions'],general_main_flat_theorem_accepted_as_recursively_complete=False,load_bearing_qualifications=['Hermitian interpolation needs the quadratic formula','Arbitrary-sequence limsup does not preserve the maximum-distance sum','Squared metric potentials require consistent factor-two norm lengths and FS weights','Probability versus Hilbert/DH mass and pth degree scaling stay explicit','Finite spectral extension independence is a finite-p argument, not a strong infinity statement','Complex sum-envelope is generally not Hermitian','Endpoint Lp quotient/continuity and uniform bounds are needed in completion','General toric convexity uses multiplicative monomial bases'],earlier_inputs_not_recursively_certified_in_this_checkpoint=['Exact controlling Fin22 version and quantization/isometry locators','BHJ17 support interval and finite spectral endpoints','Darvas full-mass completion theorem','Ross–Witt Nystrom partial moment-map inputs'],general_envelope_theorem_admitted=False,BJ22_Theorem_6_21_repaired=False,canonical_status_changes=[],original_results_promoted=[],independent_model_receipt=None,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],pages=19,views=10,record_SHA256=sha(out))))
