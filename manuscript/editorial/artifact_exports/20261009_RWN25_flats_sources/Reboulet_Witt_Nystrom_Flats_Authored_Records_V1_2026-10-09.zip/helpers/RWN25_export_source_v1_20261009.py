# Adapted frozen source exporter SHA256: 2a2dba40e8f54145c8132df7c6d372e6a203ba0536999795c2b6baafa598e25f
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,zipfile

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Reboulet_Witt_Nystrom_flats_review_20261009';E=R/'manuscript/editorial'
O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
reading=json.loads((C/'actual_primary_reading_v1_20261009.json').read_text())
diag=json.loads((C/'exact_diagnostics_v1_20261009.json').read_text())
assert reading['actual_source_unique_pages']==19 and reading['actual_individually_displayed_matching_views']==10 and len(diag['families'])==11
for name,h in reading['preparation_record_SHA256'].items():
    prep=json.loads((C/name).read_text());assert sha(C/name)==h
    for n,pin in prep['protected_core_inputs'].items():assert sha(R/n)==pin
paths={k:E/f'RWN25_flats_source_{k}_20261009.{ext}' for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
record=C/'source_checkpoint_v1_20261009.json'
owned=O/'Reboulet_Witt_Nystrom_Flats_Authored_Records_V1_2026-10-09.zip'
full=O/'Reboulet_Witt_Nystrom_Flats_Actual_Source_Evidence_V1_2026-10-09.zip'
dest=E/'artifact_exports/20261009_RWN25_flats_sources'
assert not any(p.exists() for p in [*paths.values(),record,owned,full,dest])
draft=Path('/tmp/RWN25_source_review_draft_v1_20261009.md')
assert draft.exists() and len(draft.read_bytes())>10000
paths['review'].write_bytes(draft.read_bytes());assert sha(paths['review'])==sha(draft)
paths['reading_notes'].write_text('# Actual Reboulet–Witt Nyström revised source notes, 9 October 2026\n\nComplete pinned v2: 19 physical pages in ten individually displayed matching views.\n'+''.join('\n---\n\n'+Path(v['note_path']).read_text() for v in reading['views']))
files={f'records/{p.name}':p for p in C.glob('*.json')}
for v in reading['views']:
    for k,folder in [('note_path','notes'),('observation_receipt_path','receipts')]:
        p=Path(v[k]);files[f'primary/{folder}/{p.name}']=p
files['manifests/manifest.json']=Path(prep['manifest_path'])
for p in sorted(Path('/tmp').glob('RWN25_*_v*_20261009.py')):files[f'helpers/{p.name}']=p
files['helpers/CM15_Reboulet_filtrations_acquire_primaries_v1_20261009.py']=Path('/tmp/CM15_Reboulet_filtrations_acquire_primaries_v1_20261009.py')
files[f'drafts/{draft.name}']=draft
for k in ['review','reading_notes']:files[f'editorial/{paths[k].name}']=paths[k]
def archive(target,entries):
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,p in sorted(entries.items()):z.write(p,n)
    with zipfile.ZipFile(target) as z:
        assert len(z.namelist())==len(entries) and z.testzip() is None
        for n,p in entries.items():assert z.read(n)==p.read_bytes()
archive(owned,files)
fullfiles=dict(files)
for extension in ['pdf','txt','abs.html']:
    p=C/f'Reboulet_Witt_Nystrom_2311.13451v2.{extension}';fullfiles[f'primary/{p.name}']=p
for v in reading['views']:
    for k,folder in [('image_path','images'),('selected_text_path','text')]:
        p=Path(v[k]);fullfiles[f'primary/{folder}/{p.name}']=p
archive(full,fullfiles)
artifacts={k:dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p),members=count) for k,p,count in [('authored_records_archive',owned,len(files)),('cloud_complete_source_evidence_archive',full,len(fullfiles))]}
paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete pinned RWN25 v2 reading and qualified ordinary source audit',actual_reading=reading,exact_diagnostics=diag,artifacts=artifacts,active_book_changed=False,native_editor_changed=False,GitHub_published=False,canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — every archive member byte-verified',artifacts=artifacts,reading_credit_from_export=0,external_primary_PDF_text_images_uploaded=False,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
dest.mkdir(parents=True);target=dest/owned.name;shutil.copyfile(owned,target);assert sha(target)==sha(owned)
(dest/'SHA256SUMS').write_text(sha(target)+'  '+target.name+'\n')
(dest/'README.md').write_text(f"""# RWN25 revised flat construction checkpoint, 9 October 2026

All 19 pages of arXiv:2311.13451v2 were actually read in order with
complete text, ten individually displayed matching images and notes.
Eleven elementary diagnostic families preserve the actual finite spectral
extension, decreasing-convex norm construction, complex sum-envelope
versus Hermitian comparison, squared metric/DH factors, endpoint and
bounded-completion premises, and the toric monomial-basis scope.
The published IMRN PDF was not acquired (publisher web fetch: HTTP 429).

The {len(files)}-member authored archive pins notes, receipts, calculations,
records, helpers and the audit. The {len(fullfiles)}-member cloud archive
also holds the external PDF/text/images/metadata. Only authored records
are uploaded here. Preparation/export/upload add zero reading credit.
The main intended flat theorem is not declared false or independently
complete; its calibrated quantization/completion interfaces stay explicit.

The 4,661-page book, native editor and canonical 42 atoms/twelve problems
stay unchanged. General BJ22 critical Siu/envelopes remain OPEN,
LPWZ density UNVERIFIED and the Theorem 6.21 proof warning binding.
No original general theorem, independent-model receipt or new complete
whole-book pass is claimed. Remote publication gets a later separate
expected-head and byte-verification record.
""")
readme=R/'README.md';s=readme.read_text();marker='**Latest Reboulet 2026 filtration revision checkpoint, 9 October 2026:**';assert s.count(marker)==1
intro="""**Latest Reboulet–Witt Nyström revised flat checkpoint, 9 October 2026:**
the [complete source audit](manuscript/editorial/RWN25_flats_source_review_20261009.md)
reads all nineteen pages of arXiv:2311.13451v2 in ten matching displays.
The actual revision extends functions beyond limiting DH support before
finite spectral evaluation. Eleven elementary diagnostics calibrate norm
and metric factors, distinguish the complex envelope from a Hermitian
norm, and retain completion/endpoint and toric-basis premises. The
[authored evidence](manuscript/editorial/artifact_exports/20261009_RWN25_flats_sources/README.md)
preserves actual notes and calculations. The intended corrected theorem
retains its original quantization dependencies. The book, native editor
and canonical statuses stay unchanged; export/upload supply zero credit.

""";readme.write_text(s.replace(marker,intro+marker,1))
programme=E/'second_reading_and_research_programme_20261002.md';s=programme.read_text();marker='## Latest Reboulet 2026 filtration revision source checkpoint, 9 October 2026\n';assert s.count(marker)==1
intro="""## Latest Reboulet–Witt Nyström revised flat source checkpoint, 9 October 2026

The [complete source audit](RWN25_flats_source_review_20261009.md)
reads all nineteen pages of arXiv:2311.13451v2, 29 October 2025, with
complete selected text, ten individually displayed matching images and
chronological notes. Eleven elementary diagnostic families are archived.
The IMRN publisher PDF returned HTTP 429 and was not acquired; no
published-PDF byte identity or reading is claimed.

The actual v2 support repair affinely extends finite-right-derivative
functions across the full finite spectral interval. This is an additional
source input to the preceding 2026 review, not a retroactive enlargement
of its receipt. Decreasing-convex norm submultiplicativity and a correctly
summed complex norm-envelope product proof are useful attributed inputs.
The complex envelope is generally not Hermitian, but has the required
logarithmic-rank comparison. Squared metric/norm factors, probability vs
DH mass, degree powers, endpoint Lp quotients and uniform completion
bounds remain explicit. The intended corrected main flat theorem is not
declared false or independently complete.

The source's common-flat, big/prescribed/Kahler and toric-degeneration
questions remain research directions without new canonical atoms or
solved statuses. Actual toric monomial-basis premises must be retained.
The [owned evidence](artifact_exports/20261009_RWN25_flats_sources/README.md)
and separate cloud full-source archive preserve the calculations and
notes. Preparation/export/upload add zero credit. The 4,661-page book,
core inputs, bibliographies, native editor, canonical 42 atoms/twelve
problems and last complete ordered 4 October pass stay unchanged.
General BJ22 critical Siu/envelopes remain OPEN, LPWZ density UNVERIFIED,
and the BJ22 Theorem 6.21 warning remains binding. No independent-model
receipt or original general theorem is claimed.

Continue cloud-only with the exact Finski isometry/version, Parreau
Proposition 2.18, BE21 Theorem 9.5 and original analytic/lattice inputs.
Existing cloud Finski and Parreau copies/partial notes must be checked
before acquisition or new reading; old partial scopes stay fixed.
Monitor incoming author research and regularly publish verified authored
evidence. Xean stays suspended.

""";programme.write_text(s.replace(marker,intro+marker,1))
published=[*paths.values(),*sorted(dest.iterdir()),readme,programme];assert len(published)==9
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete pinned source checkpoint and byte-verified authored artifacts exported',editorial_files={str(p.relative_to(R)):dict(SHA256=sha(p),bytes=p.stat().st_size) for p in published},artifacts=artifacts,actual_primary_pages=19,actual_matching_views=10,active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],GitHub_published=False,helper_source=__file__)
record.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],files=9,owned_members=len(files),cloud_members=len(fullfiles),record_SHA256=sha(record))))
