from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction as Q
import hashlib, json
import sympy as s

C = Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Wu_local_NA_psh_review_20261008')
out = C / 'exact_diagnostics_v1_20261008.json'
assert not out.exists()
families = []
def save(name, locators, calculation, scope):
    families.append(dict(name=name, source_locators=locators,
                         exact_calculation=calculation, scope=scope))

assert 0 > Q(-1)  # -|t| fails the midpoint convexity inequality.
save('Missing touching constant', ['Definition 3.1(3), p.14'],
     'f(t)=-|t|: f(0)=0>(f(-1)+f(1))/2=-1. Nevertheless l=f(x)-1,C=1 passes the printed local condition by continuity.',
     'Literal definition; genuine convexity must be used in all intended theorem discussions.')

valuation_pi, valuation_T = 1, -2
valuation_unit = min(0, valuation_pi + valuation_T)
assert valuation_unit == -1
save('Generic scheme open versus reduction tube', ['model metric convention, p.7'],
     'On the standard P1 DVR model, U=D(1+pi*T), T=pi^-2: v(1+pi*T)=-1 although the point belongs to U_K.',
     'A model frame has norm one on its reduction tube; the entire generic scheme open is too large.')

assert all(-i >= -(i+1) for i in range(1, 20))
save('Excluded infinite decreasing limit', ['Proposition 2.21', 'Corollary 4.18(4)', 'Proposition 5.7'],
     'Constants -i decrease to -infinity, excluded by generic finiteness. The whole product D=Y^an x A1^an is Runge with d_D=infinity.',
     'Finite-limit/nondegeneracy hypotheses are required; generic finite versions are not refuted.')

for j in range(1, 21):
    for t in range(-20, 21):
        assert max(t-j, 0) >= max(t-j-1, 0)
save('Lower growth is not preserved by decreasing FS limits', ['Definition 3.15', 'Corollary 3.18', 'Lemmas 3.24(3), 3.25(3)', 'Definition 6.1(2)'],
     'v_j(T)=max(log|T|-j,0) decreases to 0. Every FS function on A1 has an unbounded positive-degree generator term at Gauss radii tending to infinity; hence 0 has no FS lower bound up to a constant.',
     'The printed lower-coercive class conflicts with the later upper-growth class. No conclusion about a consistently corrected theorem.')

for m in range(0, 51):
    for k in range(0, 101):
        assert 2*m*k-k*k == m*m-(k-m)**2
    assert max(2*m*k-k*k for k in range(0, 101)) == m*m
save('Quadratic radial growth obstructs an FS upper majorant', ['Lemmas 3.24(3), 3.26', 'Proposition 4.19'],
     'w(T)=max_{k>=0}(k log|T|-k^2), w(0)=0. At log|T|=2m, w=m^2 by completion of squares; max(log|T|,0)<=w+1. On bounded-radius sets only finitely many terms are active. A finite FS function is eventually at most A log|T|+B.',
     'Continuous local convex PL psh with the printed lower growth, but no decreasing global FS presentation; elementary one-variable argument.')

assert all((k+1)-k == 1 for k in range(0, 50))
save('Local integrability versus global integrability', ['Theorem 4.2(3)'],
     'In normalized graph calculus the slopes of w jump by one at log|T|=2k+1. Its positive Radon curvature is locally finite with infinite total mass. The constant function 1 is not globally L1 for that measure on A1.',
     'Conditional on the established curve slope-to-curvature normalization; does not reject local Bedford-Taylor calculus.')

assert 2 != 0
save('Strict maximum locality uses the active operand', ['Theorem 4.11(1)'],
     'On a bounded annulus u=1+|log|T||>v=0. max(u,v)=u has curvature 2 delta at the unit Gauss point, while v has curvature 0.',
     'The displayed local operand v must be u; the corrected maximum locality is not refuted.')

assert Q(1) > Q(1, 2)
save('Simultaneous tightening can destroy an interior', ['Lemma 5.3', 'Proposition 5.7 interior presentations'],
     'Present P={|T|<=1} also with the redundant constraint |1|<=1. Every positive tightening imposes 1<=exp(-epsilon)<1, hence P_epsilon is empty although {|T|<1} lies in int(P).',
     'Counterexample to that displayed presentation identity, not to polynomial convexity or a corrected Runge-neighbourhood theorem.')

formal_power, c = Q(1), Q(1,2)
assert formal_power > c
for t in range(-20, 21):
    uc = max(t, -t, 0)
    assert max(-t, t, 0) == uc
save('Formal denominator power is not the actual pole order', ['Lemma 5.11'],
     'f=T^2,g=T,r=1,c1=1,c=1/2,u=max(log|T|,0),w=u_c=max(log|T|,-log|T|,0). The term log|g/f|=-log|T| is dominated by u_c, but c1*r=1>c. g is not in (f) yet vanishes on all of V(f).',
     'Refutes the claimed denominator-power estimate with a nonradical principal ideal; does not itself refute a corrected localization theorem.')

eps = s.symbols('eps', positive=True)
x = s.symbols('x', real=True)
kernel = eps/s.sqrt(2*s.pi)*s.exp(-eps**2*x**2)
mass = s.integrate(kernel, (x, -s.oo, s.oo))
at_zero = s.integrate(-x*kernel, (x, -s.oo, 0))
assert s.simplify(mass - 1/s.sqrt(2)) == 0
assert s.simplify(at_zero - 1/(2*eps*s.sqrt(2*s.pi))) == 0
save('Printed Gaussian normalization and scale', ['Lemma 6.6'],
     dict(one_dimensional_total_mass=str(mass), convolution_of_max_0_minus_t_at_zero=str(at_zero),
          k_dimensional_mass='2^(-k/2)', narrow_normalized_kernel='(2*pi*epsilon^2)^(-k/2)*exp(-||t||^2/(2*epsilon^2))'),
     'Literal printed kernel is not normalized and broadens as epsilon tends to zero.')

assert s.sqrt(2).is_rational is False
save('Completed residue field can be nondiscrete', ['Proposition 6.12, pp.44-45; invocation of Proposition 4.19'],
     'For a discretely valued K with v(pi)=1, the Gauss valuation v(T)=sqrt(2) has value group containing Z+sqrt(2)Z, which is nondiscrete. H(s) therefore need not satisfy the discrete/trivial hypothesis of 4.19.',
     'A scope gap at an actual invocation; not a counterexample to the claimed final envelope theorem.')

gamma = 1
assert gamma-1 == 0
assert sum([]) == 0
save('Unit branch multiplicity requires a separate case', ['Lemma 6.15, Steps 4-5'],
     'The identity finite map has gamma=1. The displayed denominator 2(gamma-1) is zero; the other branch contribution is then an empty sum, equal to 0.',
     'Use a separate case or max(1,gamma-1), conditional on a proved local branch-rank statement.')

phi, cg, degree = Q(2), Q(3), 2
assert degree*(phi+cg) == 10
assert -degree*(phi+cg) == -10
save('Norm potential sign', ['Proposition 6.11, p.42'],
     'If phi+cg=-log|s|_metric, its additive weighted norm is -log of the section norm under the norm metric. The printed positive log reverses the sign.',
     'Metric/potential interface correction; psh preservation still needs the cited norm-metric theorem.')

obj = dict(UTC=datetime.now(timezone.utc).isoformat(),
           status='DONE — 13 exact elementary diagnostic families',
           families=families, families_count=len(families),
           source_version='arXiv:2609.27610v1',
           source_PDF_SHA256='11808a6c9ede9c0158b27e16700fc180a4ac8df12a4586a7178e1958e8f6bba8',
           finite_computations_not_general_theorem_proofs=True,
           symbolic_and_arithmetic_assertions_passed=True,
           general_envelope_theorem_admitted=False,
           original_general_theorem_promoted=False,
           independent_model_receipt_claimed=False,
           canonical_status_changes=[], helper_source=__file__)
assert len(families) == 13
out.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(dict(status='DONE', diagnostic_families=len(families),
                     record_SHA256=hashlib.sha256(out.read_bytes()).hexdigest())))
