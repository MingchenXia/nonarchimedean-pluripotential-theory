from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

R = Path('/workspace/nonarchimedean-pluripotential-theory')
E = R / 'manuscript/editorial'
C = R / 'source_material/Wu_local_NA_psh_review_20261008'
out = C / 'source_checkpoint_v1_20261008.json'
assert not out.exists()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
protected = json.loads((C/'protected_source_baseline_v1_20261008.json').read_text())['protected_core_inputs']
for p, h in protected.items():
    assert sha(p) == h
actual = C/'actual_primary_reading_v1_20261008.json'
diag = C/'exact_diagnostics_v1_20261008.json'
a = json.loads(actual.read_text())
assert a['actual_read_pages'] == list(range(1,56))
assert len(a['actual_observations']) == 28
d = json.loads(diag.read_text())
assert d['families_count'] == 13 and d['symbolic_and_arithmetic_assertions_passed']
paths = {k: E/f'Wu_local_NA_psh_{k}_20261008.{ext}' for k,ext in [
    ('source_review','md'), ('source_reading_notes','md'),
    ('source_reading_manifest','json'), ('source_artifacts','json')]}
assert paths['source_review'].exists()
assert not any(paths[k].exists() for k in ['source_reading_notes','source_reading_manifest','source_artifacts'])
notes = ('# Actual sequential Wu local psh primary notes, 8 October 2026\n\n'
         'All 55 pages of arXiv:2609.27610v1 were read in 28 individually displayed matching views. '
         'These immutable contemporaneous notes retain tentative concerns and their refinements. '
         'The final source audit distinguishes literal diagnostics, repairable formulas and unverified proof obligations. '
         'No general envelope/comparison theorem or independent-model receipt is admitted. '
         'External bibliography proofs are not recursively certified.\n')
for observation in a['actual_observations']:
    notes += '\n---\n\n' + Path(observation['note_path']).read_text()
paths['source_reading_notes'].write_text(notes)
manifest = dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — complete primary reading, 13 elementary diagnostics and qualified proof-interface audit',
    actual_ledger_path=str(actual), actual_ledger_SHA256=sha(actual), actual_record=a,
    source_audit_SHA256=sha(paths['source_review']), exact_diagnostic_path=str(diag),
    exact_diagnostic_SHA256=sha(diag), extraction_warning='Syntax Warning: Mismatch between font type and embedded font file',
    all_actual_views_readable_and_matching=True, general_envelope_theorem_admitted=False,
    weak_local_global_comparison_admitted=False, original_general_theorem_promoted=False,
    external_foundation_proofs_recursively_certified=False, independent_model_receipt_claimed=False,
    whole_book_new_reading_claim=False, active_book_changed=False, canonical_status_changes=[],
    GitHub_published=False)
paths['source_reading_manifest'].write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
helpers = sorted(Path('/tmp').glob('Wu_local_NA_psh_*_20261008.py'))
files = [p for name in ['Wu_local_NA_psh_sources_20261008','Wu_local_NA_psh_review_20261008']
         for p in (R/'source_material'/name).rglob('*') if p.is_file()]
artifacts = dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — cloud source checkpoint before authorized publication',
    files=[dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p)) for p in sorted(files)],
    helpers={str(p):sha(p) for p in helpers},
    editorial_files={str(p):sha(p) for k,p in paths.items() if k!='source_artifacts'},
    protected_core_inputs=protected, active_TeX_inputs_preserved=425, bibliographies_preserved=2,
    native_catalogue_preserved=True, book_PDF_preserved=True, actual_source_pages=55,
    actual_images=28, reading_credit_from_exports=0, GitHub_published=False)
paths['source_artifacts'].write_text(json.dumps(artifacts,ensure_ascii=False,indent=2)+'\n')
obj = dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — cloud primary source checkpoint; publication has a separate subsequent record',
    baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    editorial_files={str(p):sha(p) for p in paths.values()}, protected_core_inputs=protected,
    actual_source_pages=55, actual_images=28, actual_primary_reading_SHA256=sha(actual),
    exact_diagnostics_SHA256=sha(diag), general_envelope_theorem_admitted=False,
    weak_local_global_comparison_admitted=False, active_book_changed=False,
    GitHub_published=False, helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
for p,h in protected.items():
    assert sha(p)==h
print(json.dumps(dict(status='DONE',checkpoint_SHA256=sha(out),editorial_files=4,protected_inputs=430)))
