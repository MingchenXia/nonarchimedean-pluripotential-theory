from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile, shutil

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R/'source_material/Wu_local_NA_psh_review_20261008'
S = R/'source_material/Wu_local_NA_psh_sources_20261008'
E = R/'manuscript/editorial'
W = Path('/tmp/Wu_local_NA_psh_primary_views_v1_20261008')
O = Path('/workspace/book-completion-drafts/research-integration')
out = C/'source_export_v1_20261008.json'
assert not out.exists()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
cp = json.loads((C/'source_checkpoint_v1_20261008.json').read_text())
for p,h in cp['protected_core_inputs'].items():
    assert sha(p)==h
editorial = [Path(p) for p in cp['editorial_files']]
assert all(sha(p)==cp['editorial_files'][str(p)] for p in editorial)
authored = {f'authored_records/{p.relative_to(C)}':p for p in C.rglob('*') if p.is_file()}
authored.update({f'editorial/{p.name}':p for p in editorial})
authored.update({f'helpers/{p.name}':p for p in sorted(Path('/tmp').glob('Wu_local_NA_psh_*_20261008.py'))})
full = {f'primary/{p.name}':p for p in S.iterdir() if p.is_file()}
full.update({f'actual_views/{p.name}':p for p in W.iterdir() if p.is_file()})
full.update(authored)
def export(path,items):
    assert not path.exists()
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,p in sorted(items.items()):
            z.write(p,name)
    with zipfile.ZipFile(path) as z:
        assert sorted(z.namelist())==sorted(items)
        for name,p in items.items():
            assert z.read(name)==p.read_bytes(),name
    return dict(path=str(path),bytes=path.stat().st_size,SHA256=sha(path),
                members=len(items),members_byte_verified=True)
fullzip = export(O/'Wu_Local_NA_Psh_Actual_Source_Evidence_2026-10-08.zip',full)
authzip = export(O/'Wu_Local_NA_Psh_Authored_Audit_Records_2026-10-08.zip',authored)
review = O/'Wu_Local_NA_Psh_Actual_Source_Review_2026-10-08.pdf'
assert not review.exists()
shutil.copy2(S/'Wu_local_NA_psh_arxiv_v1.pdf',review)
D = E/'artifact_exports/20261008_wu_local_na_psh_sources'
assert not D.exists()
D.mkdir()
target = D/Path(authzip['path']).name
shutil.copy2(authzip['path'],target)
assert sha(target)==authzip['SHA256']
(D/'SHA256SUMS').write_text(sha(target)+'  '+target.name+'\n')
(D/'README.md').write_text(f'''# Wu local psh primary audit, 8 October 2026

The {authzip['members']}-member authored archive records the complete 55 pages of
Lyuhui Wu's arXiv:2609.27610v1, posted 23 September 2026, in 28 individually
displayed matching images with complete selected text and sequential notes.
Source: https://arxiv.org/abs/2609.27610v1.

It contains authored notes, receipts, hash records, four editorial files and
acquisition/diagnostic helpers. The primary PDF, extracted full text and source
images are absent from this uploaded archive; the complete {fullzip['members']}-member,
byte-verified source evidence remains in the cloud.

The audit does not admit the claimed general weak/local/global comparison or
geometrically-unibranch envelope theorem. Thirteen elementary diagnostics
separate printed lower/upper growth, decreasing-limit generic finiteness,
quadratic radial majorants, local/global integrability, maximum operands,
polytope plateau constraints, actual versus formal pole orders, Gaussian
normalization, nondiscrete completed residue fields, unit branch multiplicity
and metric norm signs. Repairable formulas, unresolved proof obligations and
the scope of the intended main theorem are kept distinct. An intended corrected
main theorem may be true; no counterexample to that main theorem is asserted.
Unversioned APW tropical preprints and other cited foundations are not
recursively certified. No LPWZ density or BJ22 Siu proof repair is imported.

The extraction font warning remains recorded; all mathematical assertions in
the diagnostic helper pass. Prepared flags remain false. Exports and uploads
give zero reading credit and supply no independent-model receipt.

The active 4,647-page PDF, 425 TeX inputs, both bibliographies and native
catalogue/editor are unchanged at this source checkpoint. The 42 atoms/twelve
formal problems retain status: general BJ22 critical homogeneous Siu/envelopes
OPEN, LPWZ density UNVERIFIED. The last complete ordered book reading is
4 October. Book integration and publication have separate subsequent gates.
SHA256SUMS pins the authored archive.
''')
obj = dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — byte-verified source archives; repository publication pending at export',
    full_source_evidence=fullzip, authored_source_evidence=authzip,
    source_review_PDF=dict(path=str(review),bytes=review.stat().st_size,SHA256=sha(review),physical_pages=55),
    repository_artifact_directory=str(D.relative_to(R)),
    repository_artifact_files={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in sorted(D.iterdir())},
    external_primary_artifact_upload=False, actual_source_pages=55, actual_images=28,
    general_envelope_theorem_admitted=False, weak_local_global_comparison_admitted=False,
    export_reading_credit=0, canonical_status_changes=[], GitHub_published=False, helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
for p,h in cp['protected_core_inputs'].items():
    assert sha(p)==h
print(json.dumps(dict(status='DONE',record_SHA256=sha(out),
                     full_source_evidence=fullzip,authored_source_evidence=authzip)))
