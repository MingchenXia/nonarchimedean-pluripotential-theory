# Template SHA256: 4da467d4c37ac6e594dde7dfaac6dfbda5b86e1ea0b67371731372632ccde6c4
# Frozen preceding acquisition helper SHA256: 92e199c891d81a70285eae3031b17d10d412acbadb3b77f9e7b68c778d7595bf
# Frozen adapted acquisition helper SHA256: 1c1a52fcd7120a85e2dc5170006cfa1fffa18d9d9f8ea604b783c4b5f5ae319e
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,urllib.request,subprocess,fitz,traceback
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Wu_local_NA_psh_review_20261008';S=R/'source_material/Wu_local_NA_psh_sources_20261008';out=C/'primary_acquisition_v1_20261008.json';assert not out.exists();C.mkdir(exist_ok=True);S.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
meta=R/'source_material/recent_related_metadata_followup_20261008/metadata_scan_v2_20261008.json';assert sha(meta)=='a0afb497688bd7fd02dda875a2882ea99f6d9d197af8cbe67392f4308dfb75d1';m=json.loads(meta.read_text());row=next(x for x in [e for q in m['queries'] for e in q.get('entries',[])] if x['id'].endswith('2609.27610v1'));url='https://arxiv.org/pdf/2609.27610v1';pdf=S/'Wu_local_NA_psh_arxiv_v1.pdf';txt=pdf.with_suffix('.txt');assert not pdf.exists() and not txt.exists();obj={'start_UTC':datetime.now(timezone.utc).isoformat(),'source_metadata':row,'metadata_record_SHA256':sha(meta),'requested_URL':url,'actual_primary_pages_read':0,'actual_matching_images_displayed':0,'book_changed':False,'canonical_status_changes':[],'helper_source':__file__}
try:
 req=urllib.request.Request(url,headers={'User-Agent':'book-source-audit/1.0'})
 with urllib.request.urlopen(req,timeout=45) as r:raw=r.read();obj.update(HTTP_status=r.status,final_URL=r.url,response_Content_Type=r.headers.get('Content-Type'))
 assert raw.startswith(b'%PDF-');pdf.write_bytes(raw)
 with fitz.open(pdf) as d:pages=len(d);pdfmeta=d.metadata
 run=subprocess.run(['pdftotext','-layout',str(pdf),str(txt)],text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE);assert run.returncode==0 and txt.exists()
 obj.update(status='DONE — pinned PDF/full text acquired; zero proof-reading credit',PDF={'path':str(pdf),'bytes':len(raw),'SHA256':sha(pdf),'physical_pages':pages,'metadata':pdfmeta},full_text={'path':str(txt),'bytes':txt.stat().st_size,'SHA256':sha(txt)},extraction_stderr=run.stderr)
except Exception as e:obj.update(status='FAILED — no proof-reading credit',error=repr(e),traceback=traceback.format_exc())
obj['end_UTC']=datetime.now(timezone.utc).isoformat();out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps({'status':obj['status'],'record_SHA256':sha(out),'PDF':obj.get('PDF'),'extraction_stderr':obj.get('extraction_stderr'),'error':obj.get('error')},ensure_ascii=False))

raise SystemExit(0 if obj['status'].startswith('DONE') else 1)
