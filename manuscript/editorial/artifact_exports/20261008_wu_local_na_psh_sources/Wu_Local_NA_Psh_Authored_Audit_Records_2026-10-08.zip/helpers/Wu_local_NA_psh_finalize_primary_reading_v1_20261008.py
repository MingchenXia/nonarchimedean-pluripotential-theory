from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R / 'source_material/Wu_local_NA_psh_review_20261008'
out = C / 'actual_primary_reading_v1_20261008.json'
assert not out.exists()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
baseline = C / 'protected_source_baseline_v1_20261008.json'
b = json.loads(baseline.read_text())
assert len(b['protected_core_inputs']) == 430
for p, h in b['protected_core_inputs'].items():
    assert sha(p) == h, p
prep = C / 'primary_view_preparation_v1_20261008.json'
p = json.loads(prep.read_text())
assert sha(p['manifest_path']) == p['manifest_SHA256']
rows = json.loads(Path(p['manifest_path']).read_text())
assert len(rows) == 28
observations, pages, last = [], [], None
for row in rows:
    assert not row['actually_viewed'] and not row['selected_text_read']
    receipt = C / 'primary_notes_v1' / f"note_{row['number']:02d}_receipt.json"
    x = json.loads(receipt.read_text())
    assert x['number'] == row['number'] and x['physical_pages'] == row['physical_pages']
    assert x['complete_selected_text_actually_read']
    assert x['matching_image_individually_displayed_and_reviewed']
    for kind in ['image', 'selected_text', 'note']:
        assert sha(x[kind + '_path']) == x[kind + '_SHA256']
    assert x['image_SHA256'] == row['image_SHA256']
    assert x['selected_text_SHA256'] == row['selected_text_SHA256']
    assert x['source_PDF_SHA256'] == p['source_PDF']['SHA256']
    assert 'Read the complete selected text and displayed matching rendered image' in Path(x['note_path']).read_text()
    assert last is None or last < x['UTC']
    last = x['UTC']
    observations.append(dict(receipt_path=str(receipt), receipt_SHA256=sha(receipt), **x))
    pages += x['physical_pages']
assert pages == list(range(1, 56))
assert sha(p['source_PDF']['path']) == p['source_PDF']['SHA256']
obj = dict(
    UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — complete 55-page primary text and 28 individually displayed matching views',
    source_PDF=p['source_PDF'], actual_read_pages=pages,
    actual_matching_images=28, actual_sequential_notes=28,
    actual_observations=observations, preparation_record_SHA256=sha(prep),
    prepared_flags_preserved=True, extraction_warning_preserved=True,
    all_image_text_pairs_readable_with_no_detected_content_loss=True,
    general_envelope_theorem_admitted=False,
    weak_local_global_comparison_admitted=False,
    external_foundation_proofs_recursively_certified=False,
    independent_model_receipt_claimed=False, canonical_status_changes=[],
    active_book_changed=False, last_whole_book_pass='4 October 2026',
    reading_credit_from_exports_or_uploads=0,
    protected_baseline_SHA256=sha(baseline), helper_source=__file__)
out.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(status='DONE', actual_pages=55, views=28,
                     ledger_SHA256=sha(out))))
