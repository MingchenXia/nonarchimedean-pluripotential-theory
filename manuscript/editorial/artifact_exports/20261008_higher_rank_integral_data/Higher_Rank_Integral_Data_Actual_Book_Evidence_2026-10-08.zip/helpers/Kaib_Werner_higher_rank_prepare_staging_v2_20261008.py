# Frozen v1 preparation helper SHA256: 44ba4e5c180fe2dba28c1c3da62184a63f7f4532146eb7b83ad1f2219abc0f6e
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, re, subprocess
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Kaib_Werner_higher_rank_review_20261008'
B=Path('/workspace/book-completion-drafts/adiabatic-normalization-staging-v2-20261008')
S=Path('/workspace/book-completion-drafts/higher-rank-abeloid-staging-v2-20261008')
D=Path('/workspace/book-completion-drafts/higher-rank-abeloid-integration-v2-20261008')
out=C/'staging_preparation_v2_20261008.json'
assert not out.exists() and not S.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cp=C/'source_checkpoint_v2_20261008.json'
assert sha(cp)=='195fd00f450477cf5eeecd9f6b399133e54241d04441872257bba724e557f131'
p=json.loads(cp.read_text())
for n,h in p['protected_core_inputs'].items(): assert sha(Path(n))==h
for n,h in p['editorial_files'].items(): assert sha(Path(n))==h
publication=C/'GitHub_source_publication_v1_20261008.json'
assert sha(publication)=='ddf721f9b2d699e0a20f0d86f7fbe865eadd2e02237054768cd9ddf470d4dbb5'
assert sha(B/'manuscript/book.pdf')==sha(R/'manuscript/book.pdf')
shutil.copytree(B,S,ignore=shutil.ignore_patterns('*.pdf','*.aux','*.log','*.fls','*.fdb_latexmk','*.bbl','*.blg','*.toc','*.out','*.idx','*.ind','*.ilg','__pycache__'))
changed=[Path('manuscript/parts/part1/ch03_models.tex'),Path('manuscript/appendices/appL_provenance.tex'),Path('manuscript/bibliography/NonArchimedean.bib')]
before={str(n):sha(S/n) for n in changed}
assert all(sha(R/n)==h for n,h in before.items())
z=S/changed[0];t=z.read_text();marker='\\section*{Source notes}'
assert t.count(marker)==1
z.write_text(t.replace(marker,(D/'ch03_higher_rank_fragment.tex').read_text()+marker,1))
z=S/changed[1];z.write_text(z.read_text()+(D/'appL_higher_rank_fragment.tex').read_text())
z=S/changed[2];z.write_text(z.read_text()+(D/'higher_rank_bibliography_fragment.bib').read_text())
keys=['KaibWerner26HigherRankV1'];assert z.read_text().count('@misc{'+keys[0]+',')==1
tex={str(Path(n).relative_to(R)):h for n,h in p['protected_core_inputs'].items() if Path(n).is_relative_to(R/'manuscript') and Path(n).suffix=='.tex'}
assert len(tex)==425
unchanged={n:h for n,h in tex.items() if Path(n) not in changed}
assert len(unchanged)==423
for n,h in unchanged.items(): assert sha(R/n)==sha(S/n)==h
assert sha(S/'manuscript/bibliography/ComplexGeometry.bib')==sha(R/'manuscript/bibliography/ComplexGeometry.bib')
formal=[]
for n in changed[:2]:
    old=(R/n).read_text();new=(S/n).read_text()
    envs=['theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important']
    starts=re.findall(r'\\begin\{('+('|'.join(envs))+r')\}',old)
    assert starts==re.findall(r'\\begin\{('+('|'.join(envs))+r')\}',new)
    for env in envs:
        assert all(block in new for block in re.findall(r'\\begin\{'+env+r'\}.*?\\end\{'+env+r'\}',old,re.S))
    tags=re.findall(r'\\tag\{([^}]+)\}',old);newtags=re.findall(r'\\tag\{([^}]+)\}',new)
    assert all(x in newtags for x in tags)
    formal.append(dict(path=str(n),historical_formal_starts=len(starts),historical_proofs=starts.count('proof'),historical_manual_tags=len(tags),new_manual_tags=[x for x in newtags if x not in tags]))
assert formal[0]['new_manual_tags']==['3.1'] and not formal[1]['new_manual_tags']
for rel in ['README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']:
    shutil.copy2(R/rel,S/rel)
for rel in p['editorial_files']:
    q=Path(rel);target=S/q.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(q,target)
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — higher-rank integral-data exposition prepared in isolated stage',stage_path=str(S),baseline_stage_path=str(B),baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),draft_path=str(D),before=before,after={str(n):sha(S/n) for n in changed},draft_fragments={str(z):sha(z) for z in sorted(D.iterdir())},active_inputs_preserved={str(n):sha(R/n) for n in changed},other_active_TeX_preserved=unchanged,unchanged_bibliography=dict(path='manuscript/bibliography/ComplexGeometry.bib',SHA256=sha(R/'manuscript/bibliography/ComplexGeometry.bib')),historical_formal_blocks_preserved=formal,active_book_PDF_SHA256=sha(R/'manuscript/book.pdf'),native_catalogue_preserved={str(Path(n).relative_to(R)):h for n,h in p['protected_core_inputs'].items() if Path(n).is_relative_to(R/'output')},source_checkpoint_SHA256=sha(cp),actual_primary_reading_SHA256=sha(C/'actual_primary_reading_v1_20261008.json'),exact_diagnostics_SHA256=sha(C/'exact_diagnostics_v1_20261008.json'),source_locator_corrections_SHA256=sha(C/'source_locator_corrections_v1_20261008.json'),source_publication_SHA256=sha(publication),new_bibliographic_keys=keys,new_formal_environments=0,original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],active_book_changed=False,GitHub_published=False,actual_book_reading_credit=0,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
src=Path('/tmp/Hattori_CY_fibrations_validate_staged_book_v2_20261008.py');dst=Path('/tmp/Kaib_Werner_higher_rank_validate_staged_book_v2_20261008.py');assert not dst.exists()
t=src.read_text().replace('Hattori_CY_fibrations','Kaib_Werner_higher_rank').replace('adiabatic-normalization-staging-v2-20261008','higher-rank-abeloid-staging-v2-20261008')
dst.write_text('# Frozen adapted validation template SHA256: '+sha(src)+'\n'+t)
print(json.dumps(dict(status=obj['status'],record_SHA256=sha(out),other_TeX=len(unchanged),historical=formal)))
