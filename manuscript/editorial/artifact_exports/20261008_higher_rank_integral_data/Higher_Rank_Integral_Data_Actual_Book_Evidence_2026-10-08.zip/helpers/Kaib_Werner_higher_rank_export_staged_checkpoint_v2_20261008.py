from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,zipfile,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Kaib_Werner_higher_rank_review_20261008'
S=Path('/workspace/book-completion-drafts/higher-rank-abeloid-staging-v2-20261008')
E=R/'manuscript/editorial';O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
prep=load('staging_preparation_v2_20261008.json')
release=load('staged_book_release_checks_v2_20261008.json')
reading=load('actual_staged_book_reading_v2_20261008.json')
post=load('post_render_checks_v2_20261008.json')
math=load('staged_mathematical_self_audit_v2_20261008.json')
underfull=load('staged_underfull_delta_v2_20261008.json')
assert reading['status'].startswith('DONE') and not reading['remaining_repairs'] and not underfull['added_blocks']
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
np=release['PDF']['physical_pages'];nb=reading['actual_unique_book_pages'];nv=reading['fresh_matching_views']
assert nb==len(release['selected_book_physical_pages']) and nv==len(reading['views'])
full=O/'Non-Archimedean_Pluripotential_Theory_Higher_Rank_Integral_Data_Staged_Preview_2026-10-08.pdf'
review=O/'Higher_Rank_Integral_Data_Staged_Book_Review_2026-10-08.pdf'
minimal=O/'Higher_Rank_Integral_Data_Staged_Minimal_Source_2026-10-08.zip'
evidence=O/'Higher_Rank_Integral_Data_Actual_Book_Evidence_2026-10-08.zip'
record=C/'staged_export_v2_20261008.json'
paths={k:E/f'Kaib_Werner_higher_rank_staged_integration_{k}_20261008.{ext}' for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in [full,review,minimal,evidence,record,*paths.values()])
shutil.copy2(release['PDF']['path'],full);assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as book:
    doc=fitz.open()
    for n in release['selected_book_physical_pages']:doc.insert_pdf(book,from_page=n-1,to_page=n-1)
    assert len(doc)==nb
    doc.set_metadata(dict(title='Higher-rank integral data and abeloid model interfaces — book review, 8 October 2026',subject=f'{nb} actually reviewed pages; export adds no reading credit.'))
    doc.save(review,garbage=4,deflate=True);doc.close()
paths['audit'].write_text(f'''# Higher-rank integral data and abeloid model interfaces: integration audit, 8 October 2026

The validated staged edition has {np:,} pages. New 3.12 and L.93 keep a complete nontrivially real-valued field topology while adding a possibly higher-rank integral valuation ring. The direct Q-p((t)) example composes t-order and p-order of the first nonzero coefficient. Its ring Z-p+t Q-p[[t]], residual DVR, intermediate non-finitely-generated prime and two-point adic base are explicit. The full lexicographic group cannot embed as an ordered real subgroup; its rank-one coarsening forgets the residue direction. These are classical worked calculations, not a new original general theorem.

The elliptic equation y²=x³+3ax+2a, a=1/(1728p−1), has Delta=−1728²p/(1728p−1)³ and j=1/p for p>=5. Its t-adic discriminant is a unit, but its j is not integral over K-plus. Only the standard necessary j-integrality criterion for good elliptic reduction is used, including the residual Z-p model obstruction. The nodal residual equation and split tangent for p=7 are supplementary checks. The source's algebraically closed full classification is not asserted over the worked field. The DVR alternative for strong marked formal models does not supply Theorem 5.7's algebraically closed nongeneric residue fields.

Proper analytic recovery and compatible integral formal-model gluing remain distinct. Proposition 3.12 keeps its proper/topologically finite-type objects and locally topologically finite-type base. Lemmas 3.5, 3.8 and 3.9 retain their integral, partial-proper and locally +weakly topologically finite-type premises. The Raynaud cross has a generically good quotient after the required finite separable affinoid extension; Corollary 6.9 distinguishes good reduction by the full torus pushout. Full algebraic, marked algebraic, marked formal and strong marked formal models have their own mapping domains. The formal clause of Proposition 6.12 explicitly keeps algebraically closed k and a semiabelian fiberwise identity component; its algebraic clause keeps an algebraically closed fraction field and semiabelian generic fiber. Algebraic Tate components Q/ell Z over C-p are distinct from the connected strong marked formal special fiber and from the full real skeleton circle. No arbitrary higher-rank extension of the book's real Monge–Ampère/energy theory is asserted.

The controlling source is arXiv:2610.01354v1, posted 1 October 2026. All 24 physical pages were actually read in twelve individually displayed matching images with sequential notes. The extraction font warning is preserved; ordinary and calligraphic component notation was distinguished visually. External adic/formal, compactification, classical uniformization, duality and Néron foundations are qualified rather than recursively certified. The earlier frozen source audit misnamed the environment type of some correct numeric locators; the separate source-locator correction ledger is included, and the book uses the exact source types. No fresh reading credit is claimed for that correction.

The v1 mechanical build and four-page/two-image partial reading are preserved. That reading identified the need for an explicit nontrivial-norm hypothesis; the final isolated v2 also makes the multiplication identity-component premise explicit. All {nb} selected final pages were freshly read in {nv} individually displayed matching images with sequential notes and receipts, including both actual contents pages, all new text and neighboring seams, the complete index and complete KW26A entry. Preparation flags remain false. This is not a new whole-book pass; 4 October remains the last complete ordered reading.

Required validation, six existing reference-checker regression tests, reference closure and the exact canonical inventory pass. Post-render reference/inventory and whitespace checks pass. There are zero errors, LaTeX/package/pdfTeX warnings, missing glyphs, overfull boxes, undefined references/citations or rerun requests. All 955 underfull diagnostics are inherited with identical normalized text and multiplicities. All {release['all_prior_numbered_label_values_preserved']:,} prior number values and {release['bibliography']['prior_labels_preserved']} citation labels remain identical. Three semantic labels, supplementary tag 3.1, two contents rows, one cited entry [KW26A] and three index terms are added. All {release['index']['accepted']} index entries are accepted without warnings/rejections; all {release['navigation']['internal_links']:,} internal links pass. External URL availability is not certified by that check. The other 423 TeX inputs, ComplexGeometry bibliography, 69 historical formal starts, 20 proofs and six old manual tags are byte-preserved. The unavailable legacy writing audit is replaced by recorded direct semantic, notation, delimiter, source, whitespace and rendered checks.

The 42 canonical atoms and twelve formal problems retain status: general BJ22 critical homogeneous Siu division/envelopes OPEN, LPWZ density UNVERIFIED. The native catalogue/editor are unchanged. No original general theorem or independent-model receipt is introduced. The authorized authored primary records were published in 6587b7c35460768b847c51e61b87598f498d0375 and all nine remote blobs verified. These frozen staged records claim neither cloud activation nor GitHub publication of the book unit; separate records control those actions. Export adds zero reading credit.
''')
paths['reading_notes'].write_text(f'# Final scoped rendered-book notes, 8 October 2026\n\n{nb} fresh pages in {nv} individually displayed matching images. The v1 partial reading and all preparation flags are preserved.\n'+''.join('\n---\n\n'+Path(v['sequential_note_path']).read_text() for v in reading['views']))
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md'
prog=(R/programme).read_text();marker='## Latest Kaib–Werner primary-source checkpoint, 8 October 2026\n';assert prog.count(marker)==1
header=f'''## Latest higher-rank integral-data cloud integration checkpoint, 8 October 2026

The validated edition has {np:,} pages. The
[integration audit](Kaib_Werner_higher_rank_staged_integration_audit_20261008.md)
records new 3.12 and L.93: a nontrivial real norm with higher-rank integral
data, an explicit composed valuation and elliptic j obstruction, proper
analytic recovery versus formal-model gluing, and distinct Néron mapping
domains. Exact source hypotheses, including the formal multiplication
identity-component premise, remain explicit. Algebraic Tate components and
strong marked formal components are different; neither is the whole skeleton.

The 24-page/twelve-display primary reading is reused without extra credit.
The final scoped book gate freshly reads {nb} pages in {nv} matching individual
displays with sequential notes and receipts. The earlier v1 mechanical and
four-page partial reading remain frozen. Full validation and post-render
reference/inventory/whitespace gates pass. All 955 underfull diagnostics are
inherited; no errors, warnings, overfull boxes or unresolved links occur.
The {release['all_prior_numbered_label_values_preserved']:,} prior number values and 591 citation labels remain;
three labels, tag 3.1, two contents rows, KW26A and three index terms are new.
Other 423 active TeX inputs, the Complex bibliography and historical formal
blocks/proofs/tags remain unchanged. The native catalogue/editor and canonical
42 atoms/twelve problems are preserved: general BJ22 critical homogeneous
Siu/envelopes OPEN, LPWZ density UNVERIFIED. No original result, independent
receipt or new whole-book pass is claimed. The last complete pass is 4 October.

The authored primary records are uploaded and remotely verified on work.
The byte-verified book exports and
[activation record](Kaib_Werner_higher_rank_cloud_activation_20261008.json)
control the new cloud edition; publication of this unit receives a separate
record after its authorized upload. Continue related recent primary research
and checks for incoming author updates.

''';(S/programme).write_text(prog.replace(marker,header+marker))
readme=(R/'README.md').read_text();assert readme.count('**4,634 pages**')==1
readme=readme.replace('**4,634 pages**',f'**{np:,} pages**')
marker='**Latest primary-source continuation, 8 October 2026:**';assert readme.count(marker)==2
intro=f'''**Latest checked book integration, 8 October 2026:** the
[higher-rank integral-data audit](manuscript/editorial/Kaib_Werner_higher_rank_staged_integration_audit_20261008.md)
adds 3.12 and L.93, with a computed valuation/elliptic example and explicit
analytic, integral and Néron model interfaces. Every source hypothesis remains
visible. All {nb} selected book pages were freshly read in {nv} matching displays;
mechanical and post-render gates pass. The
[activation record](manuscript/editorial/Kaib_Werner_higher_rank_cloud_activation_20261008.json)
controls the {np:,}-page cloud edition. No original general theorem, new
whole-book pass or canonical status change is claimed.

''';(S/'README.md').write_text(readme.replace(marker,intro+marker,1))
oldzip=O/'Hattori_Normalization_Staged_Minimal_Source_2026-10-08.zip'
with zipfile.ZipFile(oldzip) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    assert len(old.namelist())==472
    for n in old.namelist():assert (S/n).is_file();z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
    for n in z.namelist():assert hashlib.sha256(z.read(n)).hexdigest()==sha(S/n)
paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — source/math/rendered staged gates',staging_preparation_SHA256=sha(C/'staging_preparation_v2_20261008.json'),validation_SHA256=sha(C/'staged_book_validation_v2_20261008.json'),release_checks=release,actual_reading=reading,post_render_checks=post,mathematical_self_audit=math,underfull_delta=underfull,source_locator_corrections=load('source_locator_corrections_v1_20261008.json'),source_input_hashes=prep['after'],progress_document_hashes={n:sha(S/n) for n in ['README.md',programme]},active_book_changed=False,GitHub_published=False,canonical_status_changes=[],original_results_promoted=[],independent_model_receipt=None),ensure_ascii=False,indent=2)+'\n')
files={}
for q in C.glob('*.json'):
    if q.name.startswith(('staged_','staging_','actual_staged_','actual_partial_staged_','post_render_','source_locator_')):files['records/'+q.name]=q
for q in [C/'staged_book_validation_v1_20261008.log',C/'staged_book_validation_v2_20261008.log',review,Path(release['manifest_path'])]:files['records/'+q.name]=q
for v in reading['views']:
    for key,folder in [('path','images'),('selected_text_path','text'),('sequential_note_path','notes'),('observation_receipt_path','receipts')]:q=Path(v[key]);files[folder+'/'+q.name]=q
for q in (C/'staged_book_notes_v1').iterdir():
    files['v1_partial_notes/'+q.name]=q
    if q.name.endswith('_receipt.json'):
        r=json.loads(q.read_text())
        for key,folder in [('image_path','v1_partial_images'),('selected_text_path','v1_partial_text')]:
            p=Path(r[key]);files[folder+'/'+p.name]=p
for key in ['audit','reading_notes','manifest']:q=paths[key];files['editorial/'+q.name]=q
for q in sorted(Path('/tmp').glob('Kaib_Werner_higher_rank_*_20261008.py')):
    if any(x in q.name for x in ['staged','staging','book_note','underfull']):files['helpers/'+q.name]=q
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
    assert len(z.namelist())==len(files)
    for n,q in files.items():assert hashlib.sha256(z.read(n)).hexdigest()==sha(q)
artifacts=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — byte-verified staged book exports',full_book_PDF=dict(path=str(full),bytes=full.stat().st_size,SHA256=sha(full),physical_pages=np),actual_book_review_PDF=dict(path=str(review),bytes=review.stat().st_size,SHA256=sha(review),physical_pages=nb),minimal_TeX_source_archive=dict(path=str(minimal),bytes=minimal.stat().st_size,SHA256=sha(minimal),members=472,all_members_byte_verified=True),actual_book_evidence_archive=dict(path=str(evidence),bytes=evidence.stat().st_size,SHA256=sha(evidence),members=len(files),all_members_byte_verified=True),actual_source_export_record_SHA256=sha(C/'source_export_v1_20261008.json'),source_publication_record_SHA256=sha(C/'GitHub_source_publication_v1_20261008.json'),external_primary_files_uploaded_in_book_exports=False,actual_reading_credit_from_export=0,active_book_changed=False,native_editor_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__)
paths['artifacts'].write_text(json.dumps(artifacts,ensure_ascii=False,indent=2)+'\n')
record.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — frozen staged checkpoint and exports',editorial_files={str(q):sha(q) for q in paths.values()},artifacts=artifacts,progress_document_hashes={n:sha(S/n) for n in ['README.md',programme]},active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',record_SHA256=sha(record),artifacts=artifacts)))
