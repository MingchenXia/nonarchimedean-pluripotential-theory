# Kaib–Werner integral-data actual book view 01

UTC: 2026-10-08T20:30:59.240690+00:00. Physical pages: 10, 73.

Read the complete selected text and displayed matching rendered image. Physical 10 and 73 are the two actual contents pages: new 3.12 is on printed 80, new L.93 on 4306, with the surrounding chapter and appendix hierarchy retained. Both long titles fit on their rows with readable leaders and page numbers. The release preparation's title search also lists physical 158–159, which are正文 title matches rather than additional contents pages; this does not add reading credit. Existing sections, appendices, index and references remain ordered, and no layout repair is needed.
