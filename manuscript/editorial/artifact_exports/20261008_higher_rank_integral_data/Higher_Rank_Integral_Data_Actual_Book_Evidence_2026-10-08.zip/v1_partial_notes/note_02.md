# Kaib–Werner integral-data actual book view 02

UTC: 2026-10-08T20:31:46.527909+00:00. Physical pages: 157, 158.

Read the complete selected text and displayed matching rendered image. The existing model dictionary and 3.11 ledger remain readable and keep their discrete/rank-one intersection restrictions. New 3.12 starts on printed 80 with the compatible plus/residue rings and an aligned, legible supplementary equation (3.1). The opening currently says complete real-valued K but should explicitly require its absolute value to be nontrivial, as the source does; the chapter as a whole also allows trivial fields. This is a remaining hypothesis clarification, so the v1 mechanical pass is not final mathematical/rendered clearance. The formula's concrete t-adic example already has a nontrivial norm. Preserve this observation and repair in a new stage rather than rewriting frozen sources or receipts.
