# Kaib–Werner integral-data actual book view 12

UTC: 2026-10-08T20:41:59.164675+00:00. Physical pages: 4604, 4605.

Read the complete selected text and displayed matching rendered image. The complete final S–Z index pages retain readable two-column continuation, including Tate curve, skeleton, tensor seminorm and trivial-valued topics. The new valuation-ring/higher-rank integral-data entry correctly points to printed 80 and stays separate from the older higher-rank algebraic warning at printed 60. All three new index terms have now been individually located and read. End-of-index Y/Z headings, accents and wrapped lists are clear; no layout repair is required.
