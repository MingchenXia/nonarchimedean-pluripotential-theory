# Kaib–Werner integral-data actual book view 05

UTC: 2026-10-08T20:39:14.074066+00:00. Physical pages: 4383, 4384.

Read the complete selected text and displayed matching rendered image. The L.92 seam retains the d/2 volume integral and explicit negative incomplete-vertical intersection diagnostic, with no lemma/main-theorem refutation. New L.93 has accurate source version/date/24-page scope, nontrivial real norm and qualified external foundations. Proposition/Lemma/Remark locators use the corrected source environment names. Integral-sheaf localization, partially proper reflection, +weak topological finite-type assumptions and compatible residual V-gluing stay separate from proper analytic recovery. The Raynaud exact sequence, finite separable extension with L-plus intersect K=K-plus, generically good quotient and analytic-site H1 universal-cover characterization are readable. No layout or mathematical repair remains on these pages.
