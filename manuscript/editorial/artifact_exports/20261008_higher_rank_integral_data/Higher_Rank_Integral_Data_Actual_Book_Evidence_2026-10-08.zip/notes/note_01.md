# Kaib–Werner integral-data actual book view 01

UTC: 2026-10-08T20:37:25.290832+00:00. Physical pages: 10, 73.

Read the complete selected text and displayed matching rendered image. Both actual contents pages, physical 10 and 73, were freshly read and displayed for the final v2. The new 3.12 and L.93 rows remain legible on one line, with printed targets 80 and 4306 and the surrounding hierarchy intact. The title-search preparation also lists physical 158–159; those are正文 matches rather than extra contents pages. No fresh credit is reused from the v1 receipt and no layout repair remains here.
