# Kaib–Werner integral-data actual book view 04

UTC: 2026-10-08T20:38:48.649591+00:00. Physical pages: 161, 162.

Read the complete selected text and displayed matching rendered image. The first two Chapter 4 pages provide the seam after the new integral-data discussion. The chapter continues to allow a trivial real absolute value, unlike the explicitly restricted 3.12 source account; its real-valued multiplicative seminorms and nonzero kernels remain unchanged. The spectral-seminorm lemma uses power bounds/Fekete and the C^(1/m) limit, with its exact cited spectral-radius formula still separate. Heading, display alignment and proof end are readable, and no new integral direction is inserted into Berkovich real seminorms.
