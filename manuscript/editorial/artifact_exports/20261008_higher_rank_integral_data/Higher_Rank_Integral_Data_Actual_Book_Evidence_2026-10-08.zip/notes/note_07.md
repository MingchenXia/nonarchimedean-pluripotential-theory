# Kaib–Werner integral-data actual book view 07

UTC: 2026-10-08T20:40:01.188174+00:00. Physical pages: 4387, 4595.

Read the complete selected text and displayed matching rendered image. The Appendix M opening is a preserved scope seam: supplied classical pluriharmonic results do not automatically settle arbitrary continuous zero-current P06.2, and archived verification scopes are not extended. The first index page is readable in two columns; new abeloid/generically good reduction points to printed 4306, while established A/B entries and page lists retain their order. The fresh display covers only this M opening, not a new full appendix reading. No new-unit repair is needed.
