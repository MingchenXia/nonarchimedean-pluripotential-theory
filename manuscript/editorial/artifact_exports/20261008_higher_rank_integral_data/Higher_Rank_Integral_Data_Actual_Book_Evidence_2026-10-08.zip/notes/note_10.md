# Kaib–Werner integral-data actual book view 10

UTC: 2026-10-08T20:41:07.153174+00:00. Physical pages: 4600, 4601.

Read the complete selected text and displayed matching rendered image. The L-through-early-P index pages retain the MA probability/measure, model, energy and nonpluripolar distinctions. The new Néron model/marked formal model entry is alphabetized correctly and points to printed 4306. Its accent, nested indentation and link are legible. Existing open-problem and normalization entries retain their separate references; the new integral-data unit changes no canonical status. Long number lists and page continuations stay within their two-column layout, with no repair required.
