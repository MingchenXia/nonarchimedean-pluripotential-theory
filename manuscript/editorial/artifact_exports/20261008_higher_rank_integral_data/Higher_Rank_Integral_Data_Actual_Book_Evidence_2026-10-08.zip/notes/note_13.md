# Kaib–Werner integral-data actual book view 13

UTC: 2026-10-08T20:42:27.748505+00:00. Physical pages: 4606, 4627.

Read the complete selected text and displayed matching rendered image. Physical 4606 is the intentional blank index verso, confirmed visually rather than treated as extraction loss. The complete KW26A bibliography entry on physical 4627 gives Kaib/Werner, the exact abeloid title, pinned arXiv:2610.01354v1, year/date and controlling 24-page edition. Its label, accented Néron title and neighboring KSW/KT/Lagerberg/Lahdili/Lazarsfeld/Li entries are readable without collisions; the complete selected reference page was read. This completes all 26 final selected pages in thirteen individually displayed matching views, with fresh text and sequential receipts and no remaining new-unit repair. It is not a new full bibliography or whole-book reading.
