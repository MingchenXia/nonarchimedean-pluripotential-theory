# Kaib–Werner integral-data actual book view 09

UTC: 2026-10-08T20:40:41.914580+00:00. Physical pages: 4598, 4599.

Read the complete selected text and displayed matching rendered image. The envelope continuation through L index entries remains ordered and readable, with distinct BFJ/BJ energies, capacities and MA-adjacent topics, and retained source-correction/erratum entries. Adiabatic class versus normalization, relative Hessian bounds and multigraded integral closure stay distinct entries. Diacritics and math symbols, long wrapped lists and cross-page continuations fit within their columns. No added index repair is needed.
