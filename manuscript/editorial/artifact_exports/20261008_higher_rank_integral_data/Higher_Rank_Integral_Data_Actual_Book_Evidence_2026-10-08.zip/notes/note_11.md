# Kaib–Werner integral-data actual book view 11

UTC: 2026-10-08T20:41:35.452096+00:00. Physical pages: 4602, 4603.

Read the complete selected text and displayed matching rendered image. The P–S index spread preserves framework-specific psh and singularity-type entries, quoted model support/density references, research-frontier pointers and the separate Siu examples. The skeleton circle entry remains an established real skeleton reference and is not replaced by a Néron component formula. Nested entries, accented names and multiline page lists remain readable with no clipping, and the continuation boundaries are clear. No new-unit repair remains.
