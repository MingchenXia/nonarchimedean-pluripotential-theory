# Maximal-ray and extension book review — view 16

Physical pages: [4638, 4652].

Read the complete selected text and displayed matching rendered image.

Read the complete closing index page 4638 and bibliography page 4652, then displayed their matching image. The index ends with W, Y, and Z in the established two-column layout; its short final page is not an empty page. The bibliography now distinguishes Fin22a (the published characteristic-forms paper) from Fin22b (the existing metric-structure key, newly cited). Both titles and the version-two September 2022 metadata are visible. Fin22b's note states that the supremum restriction-quotient input uses Corollaries 2.11–2.12 through Bernstein–Markov comparison and continues onto the next selected page. Its label and line wrapping are readable; no collision with the preceding full Fin22a entry was observed. Other bibliography text on this selected page was read as bibliographic text without claiming additional primary-source review.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
