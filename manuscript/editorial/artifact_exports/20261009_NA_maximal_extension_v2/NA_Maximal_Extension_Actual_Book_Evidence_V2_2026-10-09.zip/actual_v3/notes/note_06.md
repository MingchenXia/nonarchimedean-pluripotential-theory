# Maximal-ray and extension book review — view 6

Physical pages: [3515, 3516].

Read the complete selected text and displayed matching rendered image.

Read the complete fixed-rank Parseval explanation and the new holomorphic restriction paragraph across its page seam. The symmetric monomial count and sqrt(d_k) comparison remain correct. The quotient and restricted sup norms are explicitly defined, and the displayed normalized logarithmic limit cites both original Corollaries 2.11 and 2.12. The text states that Corollary 2.12 is directly an L2 comparison, with quotient-stable Bernstein–Markov comparison giving the sup conclusion. Eventual surjectivity, fixed twist, epsilon-dependent constant and smooth ample continuous-psh premises are preserved. The Fin22b link is legible; the final page has a substantial coherent closing paragraph and no clipped equation or unintentional blank verso.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
