# Maximal-ray and extension book review — view 9

Physical pages: [3624, 3625].

Read the complete selected text and displayed matching rendered image.

Read both complete pages 3624–3625 and displayed the matching image. The uniform-limit argument for semipositive models concludes before the imported BBJ compactness implication, whose negative energy slope and stability inequality have consistent signs. The new paragraph correctly distinguishes unit-speed length d1(0,uj) from d1(u,uj) for another origin. Constant c has I=J=0 and d1=|c| under probability normalization; the displayed absolute integral for the literal Lemma A.2 specialization is |c|V. The paragraph continues cleanly across the page break and explicitly retains normalization or mean control without claiming a repair of the compactness theorem or a counterexample to existence. The subsequent MPWN theorem keeps its version-one and all-big-model hypothesis, followed by the ordinary-YTD limitation and the beginning of the conditional quantization section. The equations and volume factor are readable and no layout defect was observed.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
