# Maximal-ray and extension book review — view 15

Physical pages: [4636, 4637].

Read the complete selected text and displayed matching rendered image.

Read complete index pages 4636–4637 and displayed their matching image. The S-to-V sequence and the Thuillier continuation are intact. The Siu decomposition entry here names complex surface residual and positive pluriharmonic-current material; it does not assert the quarantined general non-Archimedean Siu theorem. The tensor norm/symmetric polynomial comparison entry still points to printed page 3437. Net calculus, trivial valuation, and probability-normalization entries remain distinct. All columns and links are legible with no clipped continuation or overlapping text.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
