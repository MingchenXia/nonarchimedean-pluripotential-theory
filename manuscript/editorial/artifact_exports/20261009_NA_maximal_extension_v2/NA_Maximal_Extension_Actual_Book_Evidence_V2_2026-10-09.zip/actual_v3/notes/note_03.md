# Maximal-ray and extension book review — view 3

Physical pages: [3345, 3346].

Read the complete selected text and displayed matching rendered image.

Read the complete maximal-ray theorem, imported proof and revised Remark 60.5.1 across both pages. The published BBJ21 anchors render correctly; both potential and time factors are doubled, preserving the slope. The inequality chain starts on the next page, remains complete, and ordered strictness rather than energy convergence alone identifies the datum. Constants and the projective/Kahler distinction are explicit. The following order/translation proposition and its proof retain their numbering, labels and displayed bounds. Formula spacing, citation links, headings and page seam are legible, with no clipped symbols.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
