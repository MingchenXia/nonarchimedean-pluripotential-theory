from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile, shutil, fitz

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R / 'source_material/BJ_original_NA_model_dependencies_review_20261009'
S = Path('/workspace/book-completion-drafts/NA-maximal-extension-staging-v2-20261009')
E = R / 'manuscript/editorial'
O = Path('/workspace/book-completion-drafts/research-integration')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda n: json.loads((C / n).read_text())
prep = load('book_staging_preparation_v2_20261009.json')
release = load('book_release_checks_v3_20261009.json')
reading = load('actual_book_reading_v3_20261009.json')
post = load('book_post_render_checks_v3_20261009.json')
math = load('book_mathematical_self_audit_v3_20261009.json')
under = load('book_underfull_delta_v2_20261009.json')
assert reading['status'].startswith('DONE') and not reading['remaining_repairs']
assert reading['actual_unique_book_pages'] == 33 and reading['fresh_matching_views'] == 17
assert reading['reused_matching_views'] == 0 and reading['explicitly_reviewed_blank_versos'] == []
assert all(x['returncode'] == 0 for x in post['checks'])
assert not under['added_blocks'] and not under['removed_blocks']
for n, h in prep['after'].items(): assert sha(S / n) == h
for n, h in prep['before'].items(): assert sha(R / n) == h
assert sha(R / 'manuscript/book.pdf') == prep['active_book_PDF_SHA256']
assert sha(release['PDF']['path']) == release['PDF']['SHA256'] == reading['PDF']['SHA256']
record = C / 'book_export_v1_20261009.json'
paths = {k: E / f'NA_maximal_extension_staged_integration_{k}_v2_20261009.{ext}'
         for k, ext in [('audit', 'md'), ('reading_notes', 'md'), ('manifest', 'json'), ('artifacts', 'json')]}
full = O / 'Non-Archimedean_Pluripotential_Theory_Maximal_Extension_V2_2026-10-09.pdf'
review = O / 'NA_Maximal_Extension_Actual_Book_Review_V2_2026-10-09.pdf'
minimal = O / 'NA_Maximal_Extension_Minimal_Source_V2_2026-10-09.zip'
evidence = O / 'NA_Maximal_Extension_Actual_Book_Evidence_V2_2026-10-09.zip'
dest = E / 'artifact_exports/20261009_NA_maximal_extension_v2'
assert not any(p.exists() for p in [record, *paths.values(), full, review, minimal, evidence, dest])
shutil.copyfile(release['PDF']['path'], full)
assert sha(full) == release['PDF']['SHA256']
with fitz.open(full) as book:
    d = fitz.open()
    for n in release['selected_book_physical_pages']: d.insert_pdf(book, from_page=n-1, to_page=n-1)
    assert len(d) == 33
    d.set_metadata(dict(title='Maximal rays, holomorphic restriction and compactness normalization — selected book review',
                        subject='33 complete selected physical pages actually read in 17 matching views. Export adds no reading credit.'))
    d.save(review, garbage=4, deflate=True)
    d.close()

audit_text = '''# Maximal-ray and holomorphic-extension book integration, 9 October 2026

The checked 4,669-page edition clarifies three source-dependent arguments.
Chapter 60 uses the published BBJ21 Theorem 6.4, Lemma 6.3, Theorem 6.6
and Corollary 6.7 for the NA energy bound, ordered strictness and maximal
ray. Potential and time are both doubled in the book's squared-norm
convention, preserving energy per unit time. General Kähler existence
and decreasing model regularization keep their separate inputs.

Chapter 65.19 states the holomorphic restriction-quotient input for a
smooth complex projective variety, an ample line bundle, a continuous
psh metric and a closed complex submanifold. Finski v2 Corollary 2.12
directly compares L2 quotient norms; Corollary 2.11 supplies the
Bernstein–Markov comparisons with supremum norms. Taking quotient infima
preserves the uniform comparison. Eventual surjectivity, fixed twists
and degree-independent constants for each fixed epsilon are explicit.
The preceding symmetric Parseval calculation remains a separate step.

Chapter 68.6 retains the origin, supremum normalization and mean control
needed for the cited compactness argument. A nonzero constant makes the
literal absolute-integral estimate in published BBJ21 Lemma A.2 false:
the I-dependent right side is zero and the left side is |c|V. The book
does not claim a replacement compactness proof or a counterexample to
the intended existence theorem. Imported regularity remains explicit.

This integration uses earlier source reading with its actual boundaries:
published BBJ21 48/48 pages; Finski metric structure v2 18/50 pages;
BoJ18a v1 35/79, BoJ18b v1 20/39 and Berman v3 13/41, all three partial.
Their references are not recursively certified. No additional primary
reading or independent-model receipt is created by this book increment.

All 33 selected final book pages were completely read in 17 individually
displayed matching text/image views with chronological notes. They cover
the revised passages and seams, contents, all twelve index pages, and
both full Fin22a/Fin22b bibliography entries. None is a blank verso.
The last complete ordered whole-book read remains 4 October. Preparation
flags remain unchanged; actual reading receipts are separate.

Required validation, six existing tests and post-render reference/inventory
checks pass. The log has zero errors, package/pdfTeX warnings, missing
glyphs, overfull boxes, unresolved references/citations or rerun requests.
All 955 inherited underfull blocks retain normalized content/multiplicity.
All 13,382 prior numbered values, 599 prior cited keys and 2,765 TOC
titles/hierarchies are retained. Existing Fin22 is newly cited: the
characteristic-forms label becomes Fin22a and metric structure Fin22b;
598 other prior labels are unchanged, and there are now 600 cited entries.
All 900 index entries are accepted and all 48,766 internal links resolve.

Three core TeX inputs and the existing Fin22 bibliography entry change.
The other 422 core TeX inputs and NA bibliography remain byte-identical.
Formal environment counts, manual equation tags and semantic labels are
preserved. No new source key or formal result is added. The compiled v1
wording was superseded before activation or rendered reading because it
omitted the Corollary 2.11 comparison. The release-helper v2 bibliography
assertion failed before view preparation; fresh v3 accounts for the
expected Fin22a/Fin22b disambiguation without changing the v2 PDF.
All superseded drafts, helpers and records stay frozen.

The native catalogue/editor and canonical 42 atoms/twelve formal problems,
tiers (0,3,7,15,17), are unchanged. General BJ22 homogeneous Siu/envelopes
remain OPEN, LPWZ density UNVERIFIED, and the Theorem 6.21 warning binding.
Activation and GitHub publication have separate subsequent records.
Export/upload add no reading credit. The scoped mathematical checks are:

''' + ''.join(f'{i}. {a}\n\n' for i, a in enumerate(math['checks'], 1))
paths['audit'].write_text(audit_text.rstrip() + '\n')
paths['reading_notes'].write_text(('# Actual maximal-ray/extension book reading, 9 October 2026\n\n'
    '33 complete selected physical pages, 17 individually displayed matching views; no new whole-book or primary-source pass.\n'
    + ''.join('\n---\n\n' + Path(x['sequential_note_path']).read_text() for x in reading['views'])).rstrip() + '\n')
programme = 'manuscript/editorial/second_reading_and_research_programme_20261002.md'
marker = '**Latest original NA/model dependency source checkpoint, 9 October 2026:**'
p = S / 'README.md'; s = p.read_text(); assert s.count(marker) == 1
intro = '''**Latest checked maximal-ray/extension book integration, 9 October 2026:**
the [integration audit](manuscript/editorial/NA_maximal_extension_staged_integration_audit_v2_20261009.md)
records the 4,669-page edition: published BBJ21 maximal-ray anchors in
Chapter 60, the L2-plus-Bernstein–Markov restriction argument in 65.19,
and normalized mean-sensitive compactness in 68.6. All 33 selected pages
were read in 17 matching displays; required validation and post-render
checks pass. All prior numbered values and cited keys are preserved;
the newly cited existing Finski entry gives the expected Fin22a/Fin22b
disambiguation. The [artifacts](manuscript/editorial/artifact_exports/20261009_NA_maximal_extension_v2/README.md)
contain the full book, selected review, minimal source and actual evidence.
The [activation record](manuscript/editorial/NA_maximal_extension_cloud_activation_v2_20261009.json)
records activation separately. General BJ22 Siu/envelopes remain OPEN.

'''; p.write_text(s.replace(marker, intro + marker, 1))
marker = '## Latest original NA/model dependency source checkpoint, 9 October 2026\n'
p = S / programme; s = p.read_text(); assert s.count(marker) == 1
intro = '''## Latest checked maximal-ray/extension book checkpoint, 9 October 2026

The [integration audit](NA_maximal_extension_staged_integration_audit_v2_20261009.md)
records the published maximal-ray chain in Chapter 60, Finski's L2
restriction quotient plus Bernstein–Markov comparison in 65.19, and
the origin/mean-control explanation in 68.6. Exact original hypotheses
and imported compactness/regularity inputs remain explicit. The literal
BBJ21 Lemma A.2 constant defect is recorded without declaring the
intended existence theorem false or claiming a complete repair.

The final 4,669-page book passes required validation, six existing tests,
and post-render references/inventory. All 33 selected pages were actually
read in 17 matching displays, including the full twelve-page index and
complete Fin22a/Fin22b entries. There are no selected blank versos.
Last complete ordered whole-book read remains 4 October. Existing
primary-source scopes remain unchanged: BBJ21 complete; Finski metric
structure, BoJ18a/BoJ18b and Berman v3 partial.

All 13,382 old numbered values, 599 prior cited keys and 2,765 TOC
titles/hierarchies are retained. One existing key is newly cited;
Fin22a/Fin22b is the expected disambiguation, with 598 old citation
labels unchanged. All 900 index entries and 48,766 internal links pass.
Zero overfull boxes; all 955 inherited underfull blocks have identical
normalized content and multiplicity. Other 422 core TeX inputs are
unchanged; no formal block, manual tag, semantic label or new key is added.

The [artifacts](artifact_exports/20261009_NA_maximal_extension_v2/README.md)
preserve full PDF, actual review, minimal build source and evidence,
including the superseded v1 wording and v2 bibliography preflight.
Activation and remote publication are separately recorded. Preserve the
native catalogue/editor and 42 atoms/twelve formal problems with tiers
(0,3,7,15,17). General BJ22 homogeneous Siu/envelopes remain OPEN,
LPWZ density UNVERIFIED and the Theorem 6.21 warning binding. No new
general theorem, independent-model receipt or new complete book pass.
Continue cloud-only with related original extension/Okounkov inputs,
recent papers and incoming author progress; publish reviewed units
regularly. Xean remains suspended.

'''; p.write_text(s.replace(marker, intro + marker, 1))

with zipfile.ZipFile(prep['baseline_minimal_source']['path']) as old, zipfile.ZipFile(minimal, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    members = old.namelist(); assert len(members) == len(set(members)) == 472
    for n in members: z.write(S / n, n)
with zipfile.ZipFile(minimal) as z:
    assert z.testzip() is None
    for n in z.namelist(): assert z.read(n) == (S / n).read_bytes()

files = {f'records/{q.name}': q for q in C.glob('*.json')}
for v in [1, 2]:
    q = C / f'book_validation_v{v}_20261009.log'; files[f'logs/{q.name}'] = q
    stage = Path(f'/workspace/book-completion-drafts/NA-maximal-extension-staging-v{v}-20261009')
    draft = Path(f'/workspace/book-completion-drafts/NA-maximal-extension-integration-v{v}-20261009')
    for rel in prep['after']: files[f'staged_inputs/v{v}/{rel}'] = stage / rel
    for q in draft.iterdir(): files[f'drafts/v{v}/{q.name}'] = q
    for q in (C / f'book_compiled_staged_v{v}').iterdir():
        if q.suffix != '.pdf': files[f'compiled/v{v}/{q.name}'] = q
for a in reading['views']:
    for key, folder in [('sequential_note_path', 'notes'), ('observation_receipt_path', 'receipts'), ('path', 'images'), ('selected_text_path', 'text')]:
        q = Path(a[key]); files[f'actual_v3/{folder}/{q.name}'] = q
files['actual_v3/prepared_manifest.json'] = Path(release['manifest_path'])
for q in sorted(Path('/tmp').glob('NA_maximal_extension_*_v*_20261009.py')): files[f'helpers/{q.name}'] = q
for q in [paths['audit'], paths['reading_notes'], S / programme, S / 'README.md']: files[f'editorial/{q.name}'] = q
for folder, name in [
    ('20261009_BJ_original_NA_model_dependencies_sources', 'BJ_Original_NA_Model_Dependencies_Authored_Records_V1_2026-10-09.zip'),
    ('20261009_BBJ21_Finski_original_dependencies_sources', 'BBJ21_Finski_Original_Dependencies_Authored_Records_V2_2026-10-09.zip')]:
    q = E / 'artifact_exports' / folder / name
    if not q.exists():
        candidates = list((E / 'artifact_exports' / folder).glob('*Authored*zip'))
        assert len(candidates) == 1
        q = candidates[0]
    files[f'source_owned_records/{q.name}'] = q
with zipfile.ZipFile(evidence, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
    for n, q in sorted(files.items()): z.write(q, n)
with zipfile.ZipFile(evidence) as z:
    assert len(z.namelist()) == len(files) and z.testzip() is None
    for n, q in files.items(): assert z.read(n) == q.read_bytes()
artifacts = {k: dict(path=str(q), bytes=q.stat().st_size, SHA256=sha(q)) for k, q in [
    ('full_book_PDF', full), ('selected_review_PDF', review),
    ('minimal_TeX_source_archive', minimal), ('actual_book_evidence_archive', evidence)]}
artifacts['full_book_PDF']['physical_pages'] = 4669
artifacts['selected_review_PDF']['physical_pages'] = 33
artifacts['minimal_TeX_source_archive']['members'] = 472
artifacts['actual_book_evidence_archive']['members'] = len(files)
progress = {n: sha(S / n) for n in ['README.md', programme]}
paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(), status='DONE — scoped mathematical/mechanical/actual-render gate',
    preparation=prep, release=release, actual_reading=reading, mathematical_audit=math, post_render=post, underfull_comparison=under,
    artifacts=artifacts, progress_document_hashes=progress, active_book_changed=False, GitHub_published=False, canonical_status_changes=[]), ensure_ascii=False, indent=2) + '\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(), status='DONE — all owned archive members byte-verified',
    artifacts=artifacts, reading_credit_from_export=0, active_book_changed=False, GitHub_published=False), ensure_ascii=False, indent=2) + '\n')
dest.mkdir(parents=True)
for row in artifacts.values():
    q = Path(row['path']); target = dest / q.name; shutil.copyfile(q, target); assert sha(target) == row['SHA256']
(dest / 'SHA256SUMS').write_text(''.join(row['SHA256'] + '  ' + Path(row['path']).name + '\n' for row in artifacts.values()))
(dest / 'README.md').write_text(f'''# Checked maximal-ray and extension edition, 9 October 2026

Full 4,669-page book, 33-page actual review, 472-member minimal source
and {len(files)}-member evidence archive. Every archive member is byte-verified;
SHA256SUMS pins the four owned artifacts. Source/PDF stage is v2 and
actual book-reading preparation/receipts are v3. All 33 selected pages
were read in 17 matching displays; no selected blank verso. Last full
ordered book reading remains 4 October. Export/upload add no credit.

Chapter 60 uses published BBJ maximal-ray anchors and the squared-norm
calibration. Chapter 65.19 combines Finski v2 Corollary 2.12's L2 quotient
input with Corollary 2.11's Bernstein–Markov comparison. Chapter 68.6
preserves the compactness origin, normalization and mean control, and
records the literal Lemma A.2 constant defect without claiming a full
repair or a counterexample to the intended existence equivalence.

Required validation, six existing tests and post-render checks pass.
All 13,382 prior numbered values, 599 prior cited keys and 2,765 TOC
titles/hierarchies remain. Fin22a/Fin22b is the expected disambiguation
from newly citing the existing metric-structure key: 600 cited entries,
598 old labels unchanged and one specified old label disambiguated.
All 900 index entries and 48,766 internal links pass. Zero overfull boxes;
all 955 inherited underfull blocks have identical normalized content
and multiplicity. Other 422 core TeX inputs remain unchanged. No new
formal result, manual tag, semantic label or bibliography key is added.

Superseded v1 wording and the release-v2 bibliography assertion failure
are preserved. Owned original-source records are included; external
primary PDFs remain in separate cloud source archives. This increment
does not extend the recorded complete/partial primary-source scopes.
Native catalogue/editor and canonical 42 atoms/twelve problems, tiers
(0,3,7,15,17), are unchanged. BJ22 general homogeneous Siu/envelopes
remain OPEN, LPWZ density UNVERIFIED and Theorem 6.21's warning binding.
No independent-model receipt or new complete-book pass is asserted.
Activation and verified remote publication receive separate records.
'''.rstrip() + '\n')
published = [*paths.values(), *sorted(dest.iterdir())]; assert len(published) == 10
for p in [paths['audit'], paths['reading_notes'], dest / 'README.md']:
    assert p.read_bytes().endswith(b'\n') and not p.read_bytes().endswith(b'\n\n')
    assert all(line == line.rstrip() for line in p.read_text().splitlines())
record.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(), status='DONE — actual staged book checkpoint and owned artifacts exported',
    artifacts=artifacts, editorial_files={str(q): sha(q) for q in published}, progress_document_hashes=progress,
    actual_final_book_pages=33, actual_final_matching_views=17, reused_matching_views=0, active_book_changed=False, GitHub_published=False,
    canonical_status_changes=[], helper_source=__file__, helper_SHA256=sha(__file__)), ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(status='DONE', book_pages=4669, selected_pages=33, views=17, evidence_members=len(files), record_SHA256=sha(record))))
