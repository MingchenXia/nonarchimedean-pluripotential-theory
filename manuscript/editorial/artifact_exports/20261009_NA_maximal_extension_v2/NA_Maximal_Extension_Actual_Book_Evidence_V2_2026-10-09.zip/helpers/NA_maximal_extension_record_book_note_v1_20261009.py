from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, sys

C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/BJ_original_NA_model_dependencies_review_20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
a=json.load(sys.stdin);number=a['number'];assert isinstance(number,int) and number>=1
ch=json.loads((C/'book_release_checks_v1_20261009.json').read_text())
xs=json.loads(Path(ch['manifest_path']).read_text());x=xs[number-1];assert x['number']==number
assert sha(x['path'])==x['image_SHA256'] and sha(x['selected_text_path'])==x['selected_text_SHA256']
assert not x['actually_viewed'] and not x['selected_text_read']
N=C/'book_notes_v1';note=N/f'note_{number:02d}.md';receipt=N/f'note_{number:02d}_receipt.json'
assert not note.exists() and not receipt.exists()
now=datetime.now(timezone.utc).isoformat()
if number>1:
 prev=json.loads((N/f'note_{number-1:02d}_receipt.json').read_text());assert now>prev['UTC']
assert a['observations'].strip()
note.write_text(f"# Maximal-ray and extension book review — view {number}\n\nPhysical pages: {x['physical_pages']}.\n\nRead the complete selected text and displayed matching rendered image.\n\n"+a['observations'].strip()+"\n\nScope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.\n")
obj=dict(UTC=now,number=number,physical_pages=x['physical_pages'],source_PDF_SHA256=ch['PDF']['SHA256'],complete_selected_text_actually_read=True,matching_image_individually_displayed_and_reviewed=True,note_SHA256=sha(note),image_SHA256=sha(x['path']),selected_text_SHA256=sha(x['selected_text_path']),helper_source_SHA256=sha(__file__))
receipt.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(number=number,physical_pages=x['physical_pages'],note_SHA256=sha(note),receipt_SHA256=sha(receipt))))
