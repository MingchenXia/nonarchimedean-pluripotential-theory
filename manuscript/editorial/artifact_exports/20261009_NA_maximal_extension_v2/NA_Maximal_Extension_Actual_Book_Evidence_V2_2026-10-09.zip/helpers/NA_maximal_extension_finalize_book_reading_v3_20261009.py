from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,re,subprocess,difflib,fitz

R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/BJ_original_NA_model_dependencies_review_20261009'
S=Path('/workspace/book-completion-drafts/NA-maximal-extension-staging-v2-20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
ch=load('book_release_checks_v3_20261009.json');prep=load('book_staging_preparation_v2_20261009.json')
mp=Path(ch['manifest_path']);assert sha(mp)==ch['manifest_SHA256'];xs=json.loads(mp.read_text())
reading=C/'actual_book_reading_v3_20261009.json';audit=C/'book_mathematical_self_audit_v3_20261009.json';post=C/'book_post_render_checks_v3_20261009.json'
assert not any(p.exists() for p in [reading,audit,post])
views=[];last=None
for x in xs:
    assert not x['actually_viewed'] and not x['selected_text_read']
    n=C/'book_notes_v3'/f"note_{x['number']:02d}.md";rp=n.with_name(n.stem+'_receipt.json');a=json.loads(rp.read_text())
    assert 'Read the complete selected text and displayed matching rendered image' in n.read_text()
    assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
    assert a['number']==x['number'] and a['physical_pages']==x['physical_pages']
    assert a['source_PDF_SHA256']==ch['PDF']['SHA256'] and sha(n)==a['note_SHA256']
    assert sha(x['path'])==a['image_SHA256']==x['image_SHA256']
    assert sha(x['selected_text_path'])==a['selected_text_SHA256']==x['selected_text_SHA256']
    assert last is None or a['UTC']>last;last=a['UTC']
    y={k:v for k,v in x.items() if k not in ['actually_viewed','selected_text_read']}
    y.update(actual_complete_text_read=True,actual_matching_image_freshly_displayed=True,sequential_note_path=str(n),sequential_note_SHA256=sha(n),observation_receipt_path=str(rp),observation_receipt_SHA256=sha(rp));views.append(y)
pages=sorted({p for x in xs for p in x['physical_pages']});assert pages==ch['selected_book_physical_pages']
assert sum(len(x['physical_pages']) for x in xs)==len(pages)==ch['prepared_book_pages'] and len(views)==ch['prepared_views']
checks=[]
for command in [['python3','editorial/tools/refcheck.py'],['python3','editorial/tools/check_open_problem_inventory.py']]:
    run=subprocess.run(command,cwd=S/'manuscript',text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);assert run.returncode==0,run.stdout
    checks.append(dict(command=command,returncode=run.returncode,output=run.stdout))
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
for n,h in prep['other_active_TeX_preserved'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['unchanged_bibliographies'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
assert sha(ch['PDF']['path'])==ch['PDF']['SHA256']
historical={};whitespace={}
for row in prep['historical_formal_environment_counts_preserved']:
    n=row['path'];before=(R/n).read_text();after=(S/n).read_text()
    for e,count in row['environment_counts'].items():
        pat=r'\\begin\{'+e+r'\}';assert len(re.findall(pat,before))==len(re.findall(pat,after))==count
    assert re.findall(r'\\tag\{([^}]+)\}',after)==row['historical_manual_tags']
    assert re.findall(r'\\label\{([^}]+)\}',before)==re.findall(r'\\label\{([^}]+)\}',after)
    historical[n]=row
for n in prep['after']:
    before=(R/n).read_text().splitlines();after=(S/n).read_text().splitlines()
    assert Counter(x for x in before if x!=x.rstrip())==Counter(x for x in after if x!=x.rstrip())
    added=[x[2:] for x in difflib.ndiff(before,after) if x.startswith('+ ')];assert all(x==x.rstrip() for x in added)
    run=subprocess.run(['git','diff','--no-index','--check',str(R/n),str(S/n)],text=True,capture_output=True)
    assert run.returncode in [0,1] and not(run.stdout+run.stderr).strip()
    whitespace[n]=dict(added_lines=len(added),added_trailing_whitespace=0)
for p,h in prep['draft_fragments'].items():assert sha(p)==h
under=load('book_underfull_delta_v2_20261009.json')
assert not under['added_blocks'] and not under['removed_blocks']
with fitz.open(ch['PDF']['path']) as doc:blank=[p for p in pages if not doc[p-1].get_text().strip()]
reading.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — all selected final book pages read with matching individual display',PDF=ch['PDF'],actual_unique_book_pages=len(pages),fresh_complete_text_and_individually_displayed_pages=len(pages),substantive_selected_pages=len(pages)-len(blank),explicitly_reviewed_blank_versos=blank,fresh_matching_views=len(views),reused_matching_views=0,views=views,legacy_preparation_flags_rewritten=False,remaining_repairs=[],whole_book_new_reading_claim=False,last_complete_ordered_book_pass='2026-10-04',active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
mathchecks=[
    'Published BBJ21 Theorem 6.4 supplies a lower NA energy bound for arbitrary E1 rays in the smooth projective ample setting. Lemma 6.3 uses order plus strict energy; Theorem 6.6 constructs the maximal ray and Corollary 6.7 separates equality/maximality from the general inequality.',
    'The book doubles both the source logarithmic norm potential and the source time -log|tau|. Normalized complex energy doubles with the potential, so the ratio energy/time and the NA slope are unchanged.',
    'MA uniqueness first gives equality modulo constants. Ordered strictness and equality of normalized energies fix the constant. Independent supremum recentering must not destroy the order used in that comparison.',
    'The decreasing sequence of model data is a separate source regularization input, not a countable cofinal sequence in an arbitrary directed SNC model set. The general Kahler existence statement retains the MP source and is not obtained by applying the projective BBJ result to a transcendental class.',
    'Finski arXiv v2 Corollary 2.12 directly compares L2 restriction quotient norms. Corollary 2.11 supplies Bernstein–Markov equivalence with supremum norms. Uniform multiplicative comparison is preserved by quotient infima, yielding the explicitly written supremum quotient limit.',
    'The restriction signature is smooth projective complex X, ample L, continuous psh h and closed smooth complex Y. Eventual surjectivity follows for large degrees, not every small degree. A fixed twist and reference metric are chosen before degree growth.',
    'Restriction gives M_Y<=M_q. For each fixed epsilon the extension/Bernstein–Markov upper bound has C_epsilon independent of m. Ordinary length-log and squared-norm distances differ by two, which does not affect asymptotic equivalence after division by degree.',
    'Parseval on fixed-rank symmetric tensors remains a different finite-dimensional step. It neither constructs holomorphic lifts nor proves the external extension theorem for singular bases, big classes or arbitrary finite-energy metrics.',
    'The source compactness application is based at zero, with segment length d1(0,u_j). A different initial point needs d1(u,u_j). Supremum normalization and mean control are distinct from I/J bounds.',
    'Literal published BBJ21 Lemma A.2 fails for u0=c!=0 and v0=f_j=0: all its stated I terms vanish but the absolute mixed integral is |c|V. The paragraph records the necessary normalization/mean-sensitive input without claiming a counterexample to the intended existence equivalence or a complete replacement proof.',
    'The final v2 uses the existing Fin22 key, specifying arXiv v2 and both Corollaries 2.11 and 2.12. It adds no formal environment, semantic label, manual tag or bibliography key. All prior numeric labels, 599 prior cited keys and TOC title hierarchy are retained. The newly cited Fin22 entry gets Fin22b and the existing characteristic-form Finski22 entry is disambiguated to Fin22a; its citation key and destination remain the same.',
    'The v1 stage compiled but its wording called the supremum quotient expression Corollary 2.12 directly. It was superseded before activation and before any rendered-reading claim. Fresh v2 spells out the L2 plus Bernstein–Markov chain; frozen v1 draft/helper/build bytes remain preserved.',
    'This ordinary source-attested explanatory integration provides no new general theorem or independent-model receipt. General BJ22 homogeneous Siu/envelopes remain OPEN, LPWZ density UNVERIFIED; no resolution of the reported Theorem 6.21 proof error is inferred.'
]
audit.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — ordinary scoped mathematical audit and actual final render clearance',checks=mathchecks,actual_final_book_reading_SHA256=sha(reading),source_input_hashes=prep['after'],draft_fragments=prep['draft_fragments'],original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
post.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — post-render references, inventory and input preservation checked',checks=checks,historical_formal_environment_counts_preserved=historical,whitespace_checks=whitespace,underfull_delta_SHA256=sha(C/'book_underfull_delta_v2_20261009.json'),actual_final_reading_SHA256=sha(reading),mathematical_audit_SHA256=sha(audit),release_checks_SHA256=sha(C/'book_release_checks_v3_20261009.json'),active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',pages=len(pages),views=len(views),blank_pages=blank,reading_SHA256=sha(reading),math_SHA256=sha(audit),post_SHA256=sha(post))))
