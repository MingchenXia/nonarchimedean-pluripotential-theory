from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,shutil,subprocess,zipfile

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BJ_original_NA_model_dependencies_review_20261009'
B=Path('/workspace/book-completion-drafts/parseval-raw-FS-staging-v2-20261009')
S=Path('/workspace/book-completion-drafts/NA-maximal-extension-staging-v1-20261009')
D=Path('/workspace/book-completion-drafts/NA-maximal-extension-integration-v1-20261009')
out=C/'book_staging_preparation_v1_20261009.json';assert not S.exists() and not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pubpath=C/'GitHub_source_publication_v1_20261009.json';pub=json.loads(pubpath.read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();assert head==pub['commit']=='1a9dc791df611b58e36518903347815a2e83db3d'
assert pub['actual_primary_pages']==68 and pub['actual_matching_images']==36 and pub['all_three_primary_PDFs_partial']
for row in pub['files']:assert sha(R/row['path'])==row['SHA256']
prep=json.loads((C/'primary_view_preparation_v1_20261009.json').read_text());protected=prep['protected_core_inputs']
progress=['README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']
for n,h in protected.items():
    if n not in progress:assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==sha(B/'manuscript/book.pdf')=='60e0e21a5a966a3a954c171aedd13e6cd623261b01e448db6b67febab253efcf'
xp=R/'source_material/BJKS1_Finski_dependencies_review_20261009/staged_export_v2_20261009.json'
m=json.loads(xp.read_text())['artifacts']['minimal_TeX_source_archive'];archive=Path(m['path']);assert sha(archive)==m['SHA256']
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==472
    for n in z.namelist():assert not Path(n).is_absolute() and '..' not in Path(n).parts
    S.mkdir();z.extractall(S)
for n in progress:
    p=S/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,p)
alltex={n:h for n,h in protected.items() if n.startswith('manuscript/') and n.endswith('.tex')};assert len(alltex)==425
for n,h in alltex.items():assert sha(S/n)==sha(R/n)==sha(B/n)==h
changed=['manuscript/parts/part5/ch60_mp_psh.tex','manuscript/parts/part6/ch65_rays_filtrations.tex','manuscript/parts/part6/ch68_ytd_bridge.tex','manuscript/bibliography/ComplexGeometry.bib']
before={n:sha(R/n) for n in changed}
for n in changed:assert sha(S/n)==sha(R/n)==sha(B/n)
for p in D.iterdir():assert all(line==line.rstrip() for line in p.read_text().splitlines())
p=S/changed[0];s=p.read_text();start=s.index('In the projective polarized argument,');end=s.index('\\end{remark}',start)
s=s[:start]+(D/'ch60_maximal_source_replacement.tex').read_text().rstrip()+'\n'+s[end:];p.write_text(s.rstrip()+'\n')
p=S/changed[1];p.write_text(p.read_text().rstrip()+'\n\n'+(D/'ch65_extension_fragment.tex').read_text().rstrip()+'\n')
p=S/changed[2];s=p.read_text();marker='\\begin{theorem}\\label{thm:ytd-mpwn-implication}';assert s.count(marker)==1
s=s.replace(marker,(D/'ch68_constants_fragment.tex').read_text().rstrip()+'\n\n'+marker,1);p.write_text(s.rstrip()+'\n')
p=S/changed[3];s=p.read_text();old='''@misc{Fin22,
  title={On the metric structure of section ring},
  author={Finski, Siarhei},
  archivePrefix = {arXiv},
  eprint={2209.03853},
  year={2022}
}''';assert s.count(old)==1
new='''@misc{Fin22,
  title={On the metric structure of section ring},
  author={Finski, Siarhei},
  archivePrefix = {arXiv},
  eprint={2209.03853v2},
  year={2022},
  howpublished={arXiv:2209.03853v2},
  note={Version 2, revised 29 September 2022. Corollary 2.12 is the continuous-psh restriction-quotient input in the smooth projective ample setting; the selected source reading covers physical pages 1--14 and 47--50 of fifty}
}''';p.write_text(s.replace(old,new,1))
checks=[]
for n in changed[:3]:
    old=(R/n).read_text();new=(S/n).read_text();counts={}
    for e in ['theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important']:
        pattern=r'\\begin\{'+e+r'\}';counts[e]=len(re.findall(pattern,old));assert counts[e]==len(re.findall(pattern,new))
    tags=re.findall(r'\\tag\{([^}]+)\}',old);assert tags==re.findall(r'\\tag\{([^}]+)\}',new)
    assert re.findall(r'\\label\{([^}]+)\}',old)==re.findall(r'\\label\{([^}]+)\}',new)
    checks.append(dict(path=n,environment_counts=counts,historical_manual_tags=tags))
unchanged={n:h for n,h in alltex.items() if n not in changed};assert len(unchanged)==422
for n,h in unchanged.items():assert sha(R/n)==sha(S/n)==h
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — published maximal-ray anchors, extension input and constant-control explanation prepared',stage_path=str(S),baseline_stage_path=str(B),baseline_compiled_snapshot=str(R/'source_material/BJKS1_Finski_dependencies_review_20261009/compiled_staged_v2'),baseline_commit=head,baseline_minimal_source=m,draft_path=str(D),before=before,after={n:sha(S/n) for n in changed},draft_fragments={str(p):sha(p) for p in D.iterdir()},active_inputs_preserved=before,other_active_TeX_preserved=unchanged,other_active_TeX_count=422,unchanged_bibliographies={'manuscript/bibliography/NonArchimedean.bib':sha(R/'manuscript/bibliography/NonArchimedean.bib')},historical_formal_environment_counts_preserved=checks,active_book_PDF_SHA256=sha(R/'manuscript/book.pdf'),native_catalogue_preserved={n:h for n,h in protected.items() if n.startswith('output/')},source_checkpoint_SHA256=sha(C/'source_checkpoint_v1_20261009.json'),actual_primary_reading_SHA256=sha(C/'actual_primary_reading_v1_20261009.json'),exact_diagnostics_SHA256=sha(C/'exact_diagnostics_v1_20261009.json'),BBJ21_Finski_actual_reading_SHA256=sha(R/'source_material/BBJ21_Finski_original_dependencies_review_20261009/actual_primary_reading_v1_20261009.json'),source_publication_SHA256=sha(pubpath),new_bibliographic_keys=[],changed_bibliographic_keys=['Fin22'],new_semantic_labels=[],new_formal_environments=0,original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],active_book_changed=False,GitHub_published=False,actual_book_reading_credit=0,helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',record_SHA256=sha(out),unchanged_TeX=422,changed_files=4)))
