# Chambert–Loir published 2000 — actual source reading 17

Physical pages 33–34 (article pages 820–821) were read completely in selected text and matching displayed image. This completes actual reading of all 34 physical pages, including the Numdam cover and all 33 article pages, through seventeen sequential text-plus-image notes. No other source or book page is credited.

The appendix finishes the estimate separating conjugates near and far from the unit circle, dividing by orbit cardinality and using uniform continuity. The displayed threshold sqrt(h(x_n)) needs a positive replacement when h(x_n)=0, for example sqrt(h(x_n))+1/n. The valid preceding height inequality suffices; the erroneous printed equality identified in note 16 is unnecessary. The result is convergence of orbit averages of every continuous test function to unit-circle Haar.

All 35 bibliography entries were read. Primary dependencies include Bilu 1997, Gillet–Soule arithmetic intersection 1990, Chambert–Loir 1999, Kunnemann 1996/1998 for Picard/model constructions, Maillot 2000, Szpiro–Ullmo–Zhang 1997, Zhang 1995 adelic metrics and Zhang 1998 abelian equidistribution. Reading their bibliographic entries is not actual reading of their proofs. Manuscript received 5 November 1998 and accepted after revision 18 November 1999; publication is Annales ENS (4) 33 (2000), 789–821.

The full-source audit establishes exact published locators and the mixed-versus-full-power binomial normalization of Theorem 2.5. It does not recursively clear all imported results, promote any new repair/counterexample to a theorem, certify Hultberg's unread journal version, close the general homogeneous Siu problem, or change the book/open-problem inventory. No independent production-verifier receipt is asserted.
