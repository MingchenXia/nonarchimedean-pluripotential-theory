# Chambert–Loir published 2000 — actual source reading 13

Physical pages 25–26 (article pages 812–813) were read completely in selected text and matching displayed image. No other pages credited.

Lemma 6.3 identifies the canonical ordinary section norm on the product compactification as |u|/max(|t|,|u|). Its curvature on P1 is unit-circle Haar measure. This is the canonical max metric, distinct from the smooth Fubini–Study metric; translate curvature with the source's squared-norm convention rather than dropping its factor two.

Lemma 6.4 is read in full, including its proof. For a smooth f, the continuous extension Phi equals f on the maximal compact subgroup and adds lambda times log((|t|^2+|u|^2)/(2 max(|t|^2,|u|^2))). The correction vanishes on |t/u|=1. The perturbed curvature decomposes into the smooth block pi*omega_A + epsilon lambda omega_FS + epsilon ddc f and the positive singular term (1-epsilon lambda) times circle Haar. Choose lambda sufficiently large to make the vertical block positive, then epsilon sufficiently small. The first g principal minors stay positive; the determinant has positive first-order term epsilon(lambda K+c) det(h_A+epsilon a), with uniform O(epsilon^2) remainder on two compact chart regions.

This argument retains the positive singular Haar term. It does not provide a smooth current bounded below by a positive multiple of that singular current, so it does not resolve the separate literal Kuhne Appendix A.1 issue. The perturbation is one-sided; applying it separately to f and -f still requires the later argument transferring orbit averages from Phi to f by concentration near the maximal compact subgroup. Theorem 6.1's whole-product proof only begins on page 813 and is not yet credited as fully read.

No book change, independent production-verifier receipt, general nonsplit theorem clearance or extra page credit.
