# Chambert–Loir published 2000 — actual source reading 03

Physical pages 5–6 (article pages 792–793) were read completely in selected text and matching image. No other pages credited.

Local positivity is expressed through continuous psh potentials for the squared norm and weakly positive curvature currents. On reduced singular analytic spaces the text uses smooth/psh pullback tests; do not silently identify every alternative weak/ambient notion in nonnormal settings.

An adelic metric is compared to an algebraic model metric, with bounded continuous invariant ratios and equality outside finitely many places. Convergence has one common finite exceptional set and local uniform convergence. Semipositivity is approximation by relatively nef model metrics and nonnegative smooth Archimedean curvature; integrability is a difference of semipositive metrized line bundles. Arithmetic intersections are defined by that controlled approximation, then extended multilinearly to integrable inputs.

The normalized variety height is explicitly arithmetic top intersection divided by (dim V+1)deg_L(V), unlike Hultberg v1's raw top intersection. The printed rational-point formula uses minus log ordinary norms with raw local degree weights [k_v:Q_v], not the normalized weights [k_v:Q_v]/[k:Q]. Track any further ground-field normalization separately when comparing formulas; the Q-based calibrations avoid this ambiguity. The text equates its big condition with positive top geometric degree in this positivity setting; do not export that as a definition for arbitrary nonnef divisors.

Absolute infimum and essential minimum are separately defined through all algebraic points and complements of proper closed subvarieties. The normalized height requires positive geometric degree on the relevant variety; arbitrary zero-degree boundary normalizations cannot be divided into these formulas.

No book change, independent verifier receipt or recursive import clearance.
