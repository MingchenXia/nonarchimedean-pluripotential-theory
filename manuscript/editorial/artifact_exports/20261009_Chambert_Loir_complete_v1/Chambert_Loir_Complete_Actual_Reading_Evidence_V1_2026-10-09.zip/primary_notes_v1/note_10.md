# Chambert–Loir published 2000 — actual source reading 10

Physical pages 19–20 (article pages 806–807) were read completely in selected text and matching image. No other pages credited. The complete Theorem 4.2 height computation is now read.

The boundary-product relation gives pi_*(D0^t)=1, pi_*(D0^(t+1))=-sum Q_i, and pi_*(D0^(t+2))=one half of [(sum Q_i)^2+sum Q_i^2], after intersection with the indicated remaining base classes. Theorem 2.5 then supplies the mixed arithmetic coefficient. The proof keeps binomial(g+t+1,t+2) and the anticanonical scaling (t+1), leading to the raw top intersection
-(g+t+1)!/[g!*(t+2)!]*(t+1)^(t+1)*(M^g)*[(t+1)sum_i hhat_M(q_i)-hhat_M(sum_i q_i)].

The geometric degree is binomial(g+t,t)*(t+1)^t*(M^g). Dividing by (g+t+1) times that degree gives normalized height -[(t+1)sum hhat(q_i)-hhat(sum q_i)]/(t+2), equivalently the vertex sum formula of Theorem 4.2. This explicitly retains the total-bundle degree and clears the correct normalization conversion. For t=g=1, degree(M)=a and a fixed dual extension point, the raw degree factor cancels the 1/a polarization-transferred height, in agreement with the exact formal calibration direction.

Corollary 4.3 says this normalized compactification height is nonpositive, equal to zero exactly in the almost-split case over a number field. It does not contradict nonnegative point heights on the open group: boundary strata and Zhang's absolute minimum matter. Remark 4.4 tracks arbitrary weighted boundary bundles and an additional translated quadratic correction; Lemma 4.5 states the compactification absolute minimum as negative of the largest vertex height. Its proof is on the next page and has not yet received reading credit here.

No book change, independent verifier receipt or recursive proof clearance.
