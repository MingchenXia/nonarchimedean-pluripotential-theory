# Chambert–Loir published 2000 — actual source reading 07

Physical pages 13–14 (article pages 800–801) were read completely in selected text and matching image. No other pages credited.

G-linearized fiber bundles include a cocycle relation, a canonical identity trivialization and coherent isomorphisms [n]*L ≅ L^n. Proposition 3.4 gives their unique canonical adelic metric for all n>1. It first constructs the invariant metric locally, then spreads the compactification, multiplication, divisor and isomorphism over one dense open of the integer base. This proves the finite-place adelic condition rather than assuming separate local metrics automatically globalize.

The independence of the integer n uses coherence of the canonical rigidified multiplication isomorphisms and bounded error functions; it does not assert independence of arbitrarily rescaled nonrigidified isomorphisms over the ground field. Remark 3.5 recovers the ordinary canonical maximum norm on projective space, not Fubini–Study.

Proposition 3.6 asserts semipositivity when the invariant fiber divisor is ample, and integrability of all fiber-linearized canonical bundles via differences. Its finite-place argument splits the torus after finite extension, uses the numerically trivial positive tensor-power models of Picard-zero character bundles, takes one common dominating base model, and pushes out the torsor by the Nth-power map. Its proof continues on the next page; no completed proof credit for that continuation yet.

No book change, independent verifier receipt or recursive import clearance.
