# Chambert–Loir published 2000 — actual source reading 11

Physical pages 21–22 (article pages 808–809) were read completely in selected text and matching image. No other pages credited.

Lemma 4.5's complete proof obtains the compactification absolute minimum from the t+1 boundary complements. On the complement of D0, the height is (t+1)h_D0(x)+h_M(pi(x)+q)-h_M(q), with the first term nonnegative from the effective divisor. Equality is achieved on the intersection of the other boundary divisors above -q, where D0 becomes trivial. The other vertices give the analogous values q-(t+1)q_i. This is actual boundary attainment, not a general dense-torus point-attainment assertion. Corollary 4.6 gives nonpositive absolute minimum, zero exactly when almost split.

Section 5 distinguishes the point-height Bogomolov gap, the zero-subvariety-height Philippon-type statement and strict-sequence equidistribution. The source explicitly says these need not be equivalent in the nonsplit case. Lemma 5.4 requires nonnegative absolute minimum on the compactified closure, not only on the open group, to compare zero essential minimum with zero normalized variety height using Zhang's sandwich. Its dimension induction removes torsion subvarieties and obtains a uniform remaining gap.

Lemma 5.5 uses the same compactification positivity and a generic small sequence; to apply strict-sequence equidistribution one must first ensure the ambient group is the appropriate smallest subgroup/torsion translate containing the subvariety. A generic sequence in an arbitrary proper subgroup is not automatically strict in the original ambient group. The printed short proof suppresses that reduction; do not import the inference as unconditional for every chosen ambient G. The support conclusion continues on the next page.

Historical 2000 conjectural labels are not a current-2026 open-status verdict. No book change, independent verifier receipt or general semiabelian theorem clearance.
