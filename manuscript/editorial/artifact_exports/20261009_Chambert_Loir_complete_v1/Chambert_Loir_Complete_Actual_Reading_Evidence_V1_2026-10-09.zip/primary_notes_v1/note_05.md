# Chambert–Loir published 2000 — actual source reading 05

Physical pages 9–10 (article pages 796–797) were read completely in selected text and matching image. No other pages credited.

Proposition 1.8 finishes by matching model-metric arithmetic trivial-class intersections with ordinary curvature integrals and then taking the same controlled adelic limit.

Section 2 explicitly fixes a rigidification at the abelian identity. Cube and square isomorphisms are the unique ones preserving it. Lemma 2.1 shows an invariant metric for [n]*L ≅ L^d, d>=2, makes those rigidified isomorphisms isometric: the bounded norm-error function satisfies f(nx)=d f(x), and surjectivity forces its extrema to zero. This requires boundedness and surjectivity, not the existence of arbitrary global norm-one trivializations.

Symmetric bundles have eigenweight n squared and antisymmetric/Picard-zero bundles eigenweight n. Corollary 2.2 identifies the canonical metric on Q=phi_L(q) with t_q*L tensor L inverse tensor the inverse constant fiber L|q. The last factor is necessary for rigidification. It gives the familiar point-height identity h_Q(x)=h_L(x+q)-h_L(x)-h_L(q), so adding Q to L leads to the translated quadratic height minus h_L(q). This is a direct explanatory consequence, not a newly proved theorem.

The source separately establishes integrability and then semipositivity of canonical Picard-zero metrics; the latter is not automatic from zero Archimedean curvature, especially at bad finite reduction. Lemma 2.3 starts with a characteristic-zero discretely valued fraction field and algebraically trivial line bundle; its exact model statement and proof continue next page.

No book change, independent verifier receipt or recursive import clearance.
