# Chambert–Loir published 2000 — actual source reading 14

Physical pages 27–28 (article pages 814–815) were read completely in selected text and matching displayed image. No other pages credited.

Lemma 6.5 uses support on the maximal compact subgroup, invariance under torsion translations and density of torsion to identify the top curvature measure as a multiple of Haar. Lemma 6.6 transfers averages from Phi to f using small point heights and uniform continuity. The whole-product variational proof then applies the resulting inequality separately to f and -f.

The printed function delta(t)=-log max(1,|t|) is not a nonnegative distance to the unit circle and vanishes for every |t|<=1. Its literal use as a distance misses the inside of the circle. The standard elementary completion uses |log|t|| and both t and t^{-1}; the product formula gives h(t^{-1})=h(t), and Markov's inequality bounds the exceptional proportion by the two-sided logarithmic height divided by the threshold. This is a scoped proof-reading issue, not a counterexample to the stated equidistribution theorem.

For the proper-V alternative, the proof chooses cutoffs away from the non-etale locus, applies positive curvature perturbations to both signs, and invokes abelian equidistribution to remove the cutoffs. The printed assertion that pi(x_n) is generic in A requires pi(V)=A. Merely being generically finite onto its image does not give dominance onto A, or an etale locus as a map to A of larger dimension. Theorem 6.1's wording was re-read on pages 810–811: it says generically finite, not explicitly dominant. A reduction to the appropriate abelian image/translate must be supplied before using this argument in that wider reading. In the later strict-sequence application, dominance is established separately. The final Bedford–Taylor exceptional-set step continues on page 816.

No new-result promotion, independent verifier receipt, general nonsplit theorem clearance or book change.
