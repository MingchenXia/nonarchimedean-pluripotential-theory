# Chambert–Loir published 2000 — actual source reading 09

Physical pages 17–18 (article pages 804–805) were read completely in selected text and matching image. No other pages credited.

The projective compactification is P(O_A plus Q_i dual), with boundary divisors D_i and canonically metrized relation D_i=D_0+pi*Q_i. The relative anticanonical bundle is (t+1)D_0+pi*(sum Q_i), and the point q is the sum of the q_i under the fixed polarization.

Proposition 4.1 proves the arithmetic product of all t+1 distinct boundary classes with further integrable factors vanishes. Empty algebraic intersection is not alone enough: its smooth model Green-current contribution is kept, then canonical multiplication limits and toric canonical height zero eliminate it. The proof uses local flat product structure and actual model/approximation control, not a fraction of an original singular curvature current.

Theorem 4.2 gives the NORMALIZED total-variety height -[hhat_M(q)+sum_i hhat_M(q-(t+1)q_i)]/[(t+1)(t+2)]. There is no factor (d+1)deg(base M) in this normalized expression. To recover a RAW arithmetic top intersection, multiply by (d+1)deg_total(G), including the toric/base binomial factors. The multiplication degree is n^(t+2g), and the proof eliminates all mixed top intersections except fiber exponent a=t+2; its full binomial expansion is displayed. The rest of the computation continues on the next page, so complete proof clearance is not yet claimed.

This controls the normalization direction of Hultberg v1 Lemma 6.0.3 but does not grant the latter's printed coefficient or authenticate the unexamined 2026 journal version.

No book change, independent verifier receipt or recursive import clearance.
