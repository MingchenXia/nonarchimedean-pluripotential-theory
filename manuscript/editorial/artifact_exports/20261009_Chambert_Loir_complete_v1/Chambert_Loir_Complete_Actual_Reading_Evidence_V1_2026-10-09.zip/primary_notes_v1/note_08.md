# Chambert–Loir published 2000 — actual source reading 08

Physical pages 15–16 (article pages 802–803) were read completely in selected text and matching image. No other pages credited.

Proposition 3.6's proof checks finite-place relative nefness through invariant effective generating divisors and numerically trivial base twists. At infinity the flat Picard-zero character metrics give local differential product structure, allowing nonnegative-curvature approximation. Integrability follows through differences, not by treating arbitrary signed curvature products as positive.

Definition 3.8 fixes a canonical height from the chosen equivariant compactification, fiber-linearized relatively ample C and canonically metrized ample symmetric base M. The point formula is h([n]x)=n*h_C(x)+n^2*h_M(pi(x)), explicitly two different weights. In the Fano cases the relative anticanonical boundary divisor is a natural effective choice.

Lemma 3.9's nonnegative point-height proof uses that h_C is bounded below on the open group from an effective boundary divisor; multiplication then forces h_C>=0. The printed argument mentions boundary support but does not explicitly add effectiveness. Preserve the effective boundary choice (or a separately justified lower bound); do not extend this positivity proof to arbitrary translated divisor representatives/base Picard-zero twists merely from relative ampleness. Its zero-height/torsion equivalence uses Northcott for the ample total bundle and iterates remaining in a fixed number field, not just height zero without degree control. The later standard anticanonical example meets the effective-boundary condition.

Proposition 3.11 concerns cycle pushforward, not only set images: mixed factors of powers a,b scale by n^(a+2b), with a+b=dim V+1. Torsion translates preserve each arithmetic intersection and the geometric degree. Section 4 sets up the projective-space compactification from dual Picard-zero bundles Q_i=phi_M(q_i); keep these dual/sign conventions for the forthcoming formula.

No book change, independent verifier receipt or main-theorem clearance.
