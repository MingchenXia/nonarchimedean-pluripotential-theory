# Chambert–Loir published 2000 — actual source reading 12

Physical pages 23–24 (article pages 810–811) were read completely in selected text and matching image. No other pages credited.

Theorem 5.6 rejects the zero-normalized-subvariety-height generalization in the nonsplit case, where the standard anticanonical compactification has negative height; it does not reject the point-height Bogomolov or equidistribution statements. Almost-split reduction passes via isogeny to a product.

Theorem 6.1 is specifically G=A times G_m with compactification A times P1 and its canonical ample total bundle. A positive-dimensional irreducible V meeting the group and a generic height-zero limiting sequence are required, with the additional alternative V=whole compactification or V→A generically finite. The conclusion is at a fixed Archimedean place with the normalized restricted curvature measure. Do not remove the generically finite/product hypothesis or promote it to arbitrary nonsplit toric bundles.

Proposition 6.2's variational inequality requires an ample adelically positive bundle, normalized variety height zero, generic small sequence, and continuous f admitting all sufficiently small positive curvature perturbations. It obtains liminf of the orbit averages at least the curvature average by the height sandwich and first variation. Both signs/test-density and approximation are separate later proof obligations. The source's metric-change/curvature notation must be translated with the squared-norm convention fixed earlier; the book uses an explicit ordinary-norm potential and its factor two.

The support argument finishing Lemma 5.5 needs the prior reduction to an appropriate smallest ambient group; being generic in V alone does not imply strictness in any larger G.

No book change, independent verifier receipt or general semiabelian theorem clearance.
