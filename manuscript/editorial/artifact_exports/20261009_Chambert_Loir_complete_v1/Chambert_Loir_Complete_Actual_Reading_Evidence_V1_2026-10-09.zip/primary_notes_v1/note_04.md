# Chambert–Loir published 2000 — actual source reading 04

Physical pages 7–8 (article pages 794–795) were read completely in selected text and matching image. No other pages credited.

Theorem 1.5's Zhang sandwich is essential minimum >= normalized variety height >= [essential minimum + dim(X)*absolute minimum]/[dim(X)+1], assuming big semipositive metric and finite absolute infimum. The proof adds an ample twist on a generic resolution, uses arithmetic approximation, rescales all geometric/arithmetic degrees and minima, and retains the finite-infimum hypothesis. Do not divide raw top intersections as if they were normalized heights.

Proposition-Definition 1.7 assumes continuous metrics uniformly approximated by smooth nonnegative curvature metrics on a pure-dimensional projective complex variety. Bedford–Taylor/Demailly supplies positive closed wedge limits; a dominating resolution and zero mass of pluripolar exceptional sets give resolution independence. The curvature probability measure is defined only when the total mass is nonzero. This is not a claim for arbitrary singular unbounded potentials or all differences of currents without integrability.

Proposition 1.8 assumes a continuous test f admitting an ample positive metric M with c1(M)+ddc f nonnegative. The varied metric L(epsilon f) is integrable, and the normalized height has first variation epsilon times integral f against normalized curvature, with a quadratic remainder. Its proof uses the full multilinear binomial expansion and an arithmetic trivial-metric intersection identity, which continues on the next page. Preserve ordinary norm versus squared-norm curvature and the source's place/field normalization when transferring the variation formula.

No book change, independent verifier receipt or recursive source clearance.
