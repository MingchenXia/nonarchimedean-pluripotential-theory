# Chambert–Loir published 2000 — actual source reading 02

Physical pages 3–4 (article pages 790–791) were read completely in selected text and matching rendered image. No other pages credited.

The introductory main theorem is for an almost-split semiabelian variety over a number field. Its small sequence avoids subsequences contained in a proper algebraic subgroup; the Archimedean conclusion is vague convergence of normalized Galois measures to Haar on the maximal compact subgroup. The zero-subvariety-height characterization and uniform small-point exclusion after removing maximal torsion subvarieties retain the almost-split hypothesis. The text explicitly warns that the zero-height clause is false without it, referring to later Theorem 5.6. Do not confuse that clause with the intended general semiabelian point-height Bogomolov conjecture.

The introduction emphasizes that marginal equidistribution on abelian and toric factors does not alone establish joint equidistribution; independence is a further proof obligation. It treats nonsmooth canonical metrics by adelic approximation and positive-current products, first in toric rank one, then via a Bilu argument. Statements about the then-open general case are historical to 2000.

The complex convention is d^c=(i/4pi)(dbar-d), dd^c=(i/2pi)partial dbar, and c1(L)=-dd^c log ||s|| squared. Thus an ordinary minus-log norm g gives curvature dd^c(2g), exactly the normalization distinction retained in the book's Fubini–Study example. This image-confirmed squared norm must not be replaced by the OCR's corrupted superscript.

No book change, independent verifier receipt or main-theorem/import clearance.
