# Chambert–Loir published 2000 — actual source reading 01

Physical pages 1–2 (Numdam cover and article page 789) were read completely in the selected text and matching rendered image. No other pages receive credit.

The controlling edition is Annales scientifiques de l ENS (4), volume 33, number 6 (2000), pages 789–821, by Antoine Chambert–Loir. The scan includes its archive cover and copyright notice. No primary PDF or page-image redistribution is part of the authored evidence export.

The abstract restricts the proved Bogomolov/equidistribution case to semiabelian varieties isogenous to a product of a torus and an abelian variety (almost split), rather than arbitrary extensions. The introduction is over a number field and associates canonical heights to a smooth equivariant toric compactification, an ample invariant fiber divisor and an ample symmetric abelian-base bundle. Pure abelian and pure projective-toric special cases recover Néron–Tate and Weil–Mahler heights. Torsion subvariety means a torsion translate of a connected algebraic subgroup. The introduction does not supply the later arithmetic intersection normalization or clear the general modern semiabelian conjecture.

No book change, recursive import clearance or independent verifier receipt.
