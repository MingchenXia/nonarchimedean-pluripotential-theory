# Chambert–Loir published 2000 — actual source reading 15

Physical pages 29–30 (article pages 816–817) were read completely in selected text and matching displayed image. No other pages credited.

Theorem 6.1's proper-V proof finishes by vanishing of Bedford–Taylor mass on the proper algebraic exceptional preimage. This uses its continuous-potential measure; it does not assert that arbitrary singular curvature measures ignore every algebraic subset. The dominance issue identified in note 14 remains a qualification for the literal generically-finite wording.

Section 7 reduces almost-split semiabelian varieties by isogeny to A times T. Theorem 7.1 prints 'variete abelienne isotriviale' while the section, statement context and proof concern semiabelian varieties. Proposition 7.2 and a following support lemma both carry number 7.2. The rank-one proposition is read in this product/isogeny-reduction context, not as a proof for arbitrary nonsplit rank-one extensions.

For a strict small sequence, the abelian Bogomolov theorem supplies pi(V)=A; thus the use of generically finite and etale in this application includes the needed dominance. The two limiting curvature measures yield proportional mixed and base currents. The support lemma follows by restriction of the smooth zero fiber curvature off the unit circle. The first case argues by a fiber outside the compact support and intersection positivity; the simultaneous-fiber support argument needs its stated algebraic hypotheses and is not separately certified here. In the disjoint-boundary case, finite affine projection to the proper abelian base yields a monic polynomial with constant coefficients, hence a constant torus point, which smallness forces to be torsion.

For larger split torus rank, pushforward along every nontrivial character produces rank-one joint distributions over the abelian factor. The joint character information and compact support, rather than separate marginal distributions alone, identify Haar by Fourier theory. The final compactness conclusion continues on page 818.

No independent production-verifier receipt, book theorem addition or general nonsplit equidistribution clearance.
