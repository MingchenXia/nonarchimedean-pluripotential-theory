# Chambert–Loir published 2000 — actual source reading 06

Physical pages 11–12 (article pages 798–799) were read completely in selected text and matching image. No other pages credited. The complete controlling statement and proof of Theorem 2.5 were actually read.

Lemma 2.3 gives, after finite field extension and taking a positive tensor power, a proper flat model and a line bundle of degree zero on every special-fiber curve. It imports regular models and correspondence results from Künnemann; characteristic zero and rational/power model corrections are not removed. The elliptic discussion uses the special-fiber intersection matrix and Faltings–Hriljac interpretation.

Theorem 2.5 is for an abelian variety over a number field, canonically metrized rigidified bundles L ample symmetric and Q algebraically trivial, with Q=phi_L(q). Among mixed arithmetic intersections Q^a L^(g+1-a), every term is zero except a=2; for that term the exact formula is Qbar^2 Lbar^(g-1)=-(2/g)(L^g)hhat_L(q). It is NOT the formula for the full power (Lbar+Qbar)^(g+1).

The proof uses canonical eigenweights under [2] and its degree 4^g to eliminate a!=2. It then computes f(x)=(Lbar+xQbar)^(g+1) from the rigidified translation formula, giving f(x)=-(g+1)(L^g)hhat_L(q)*x^2. Comparing binomial coefficients proves the mixed formula. Consequently the full power equals -(g+1)(L^g)hhat_L(q); the multiplier binomial(g+1,2) turns -(2/g) into -(g+1).

This authenticates the source of Hultberg v1's page-37 discrepancy: it quotes the mixed Q^2 L^(g-1) coefficient as though it were the full (L+Q) power. The original Chambert–Loir theorem and proof contain the necessary binomial coefficient. The normalized height of the full twisted abelian variety is -hhat_L(q), consistent with the translated point-height identity. Ground-field normalization is kept the same on both sides.

Section 3 starts with a projective smooth equivariant toric compactification of a semiabelian scheme and its contracted-product fibration. Arbitrary fans or singular generic fibers are not the setting here.

No book change, new theorem, independent verifier receipt or recursive clearance of Künnemann/Zhang inputs.
