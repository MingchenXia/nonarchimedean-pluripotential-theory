# Chambert–Loir published 2000 — actual source reading 16

Physical pages 31–32 (article pages 818–819) were read completely in selected text and matching displayed image. No other pages credited.

The almost-split proof finishes by uniqueness of every weak accumulation measure on the compactification. The appendix begins a separate Arakelov proof of Bilu for generic small nonzero algebraic points in P1. Smooth test functions are replaced by their continuous harmonic extensions on both unit-circle complementary discs. Fourier coefficients c_n extend as c_n min(r^n,r^{-n}) e^{in theta}; the curvature is a bounded-density circle measure for smooth boundary data. Consequently both signs of sufficiently small metric perturbations preserve positivity. The arithmetic height sandwich and first variation produce convergence for the harmonic extension.

The appendix correctly introduces a nonnegative two-sided logarithmic distance d(x)=one half log max(|x|,|x|^{-1}), unlike the literal one-sided signed expression in Lemma 6.6. Its initial bound h(x)>=the average of d(x) is valid; the following displayed 'soit' formula prints equality. Equality is not valid with nonzero finite height contributions: x=2 over Q has h=log 2 but Archimedean d=(log 2)/2. The inequality is all the subsequent Markov argument requires. This is a literal elementary calibration, not a refutation of Bilu's theorem.

Northcott plus genericity implies orbit sizes tend to infinity. Markov bounds the proportion of conjugates outside a shrinking circle neighborhood by h(x_n)/alpha_n; uniform continuity then transfers the harmonic-extension averages to the original test function. The final estimate continues on page 820. No independent verifier receipt or book change.
