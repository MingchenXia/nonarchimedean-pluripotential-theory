from pathlib import Path
from datetime import datetime, timezone
import hashlib, json
import sympy as s

C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009/dependencies_v1/ChambertLoir00Published')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=C/'literal_normalization_calibrations_v1_20261009.json'
assert not out.exists()
g=s.symbols('g',integer=True,positive=True)
d,H=s.symbols('d H',positive=True)
mixed=-2*d*H/g
full= s.simplify(g*(g+1)/2*mixed)
assert s.simplify(full+(g+1)*d*H)==0
checks=[dict(id='CL2.5-mixed-to-full',article_pages=[798,799],mixed=str(mixed),binomial='g(g+1)/2',full=str(full),normalized_full=str(s.simplify(full/((g+1)*d))),identity_verified=True),
dict(id='CL2.5-g2',mixed=str(mixed.subs(g,2)),full=str(full.subs(g,2)),missing_binomial=3,identity_verified=True)]
samples=[]
for gg in range(1,6):
    for tt in range(1,6):
        # S=sum h(q_i), Q=h(sum q_i), D=(M^g). Raw is CL4.2 proof.
        S,Q,D=s.symbols('S Q D')
        raw=-s.factorial(gg+tt+1)/s.factorial(gg)/s.factorial(tt+2)*(tt+1)**(tt+1)*D*((tt+1)*S-Q)
        degree=s.binomial(gg+tt,tt)*(tt+1)**tt*D
        normalized=s.cancel(raw/((gg+tt+1)*degree))
        expected=-((tt+1)*S-Q)/(tt+2)
        assert s.simplify(normalized-expected)==0
        samples.append(dict(g=gg,t=tt,raw=str(raw),geometric_degree=str(degree),normalized=str(normalized)))
checks.append(dict(id='CL4.2-raw-and-normalized',article_pages=[804,805,806,807],sample_count=len(samples),samples=samples,identity_verified=True))
# t=g=1, one twist q_1, degree one, h(q_1)=1: q=q_1.
raw=s.Rational(-4);degree=s.Rational(4);normalized=raw/(3*degree)
assert normalized==s.Rational(-1,3)
checks.append(dict(id='CL4.2-elliptic-rank-one',raw=str(raw),geometric_degree=str(degree),dim_plus_one=3,normalized=str(normalized),vertex_numerator=2,vertex_denominator=6,identity_verified=True))
# A distance must detect the inside of S1 as well as its outside.
r=s.Rational(1,2)
printed=-s.log(max(s.Integer(1),r));two_sided=abs(s.log(r))
assert printed==0 and two_sided==s.log(2)
checks.append(dict(id='CL6.6-distance-inside-circle',article_page=814,r=str(r),printed_delta=str(printed),two_sided_log_distance=str(two_sided),identity_verified=True))
# The appendix's inequality is enough; its following equality fails at 2.
height=s.log(2);arch_half=s.log(2)/2
assert s.simplify(height-arch_half)==s.log(2)/2
checks.append(dict(id='CL-appendix-height-equality',article_page=819,point=2,global_height=str(height),archimedean_half_log=str(arch_half),equality_false=True,preceding_inequality_sufficient=True,identity_verified=True))
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='EXACT CLASSICAL NORMALIZATION AND LITERAL-TEXT CALIBRATIONS',source_PDF_SHA256='1d29542d8109b860b55828b8f2aa82e602d6d223588c4c13ee0401cb2c3bae04',checks_count=len(checks),checks=checks,floating_point_used=False,new_corrected_general_theorem=False,production_VERIFIED=False,independent_verifier_receipt=False,book_changed=False,helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(checks=len(checks),raw_normalized_samples=len(samples),SHA256=sha(out))))
