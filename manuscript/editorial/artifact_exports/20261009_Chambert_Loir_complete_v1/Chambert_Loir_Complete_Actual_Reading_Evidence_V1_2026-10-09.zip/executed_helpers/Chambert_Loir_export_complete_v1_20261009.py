from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile,subprocess

R=Path('/workspace/nonarchimedean-pluripotential-theory');E=R/'manuscript/editorial'
C=R/'source_material/Xue_semiabelian_review_20261009/dependencies_v1/ChambertLoir00Published'
H=R/'source_material/Xue_semiabelian_review_20261009/dependencies_v1/Hultberg24ArxivV1'
W=Path('/tmp/Xue_semiabelian_dependency_views_v1_20261009/ChambertLoir00Published')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
parent='b10fbfb1ed5f50db850ce21c63725c1431b9886c'
assert git('rev-parse','HEAD')==parent and not git('diff','--name-only') and not git('diff','--cached','--name-only')
acq=json.loads((C/'source_acquisition_v1_20261009.json').read_text());src=acq['source']
prep=json.loads((C/'source_preparation_v1_20261009.json').read_text())
assert sha(src['path'])==src['SHA256'] and Path(src['path']).stat().st_size==src['bytes']
assert sha(W/'manifest.json')==prep['manifest_SHA256']
views=json.loads((W/'manifest.json').read_text());assert len(views)==17
receipts=[];pages=[];previous=None
for n,v in enumerate(views,1):
    note=C/'primary_notes_v1'/('note_%02d.md'%n);receipt=note.with_name('note_%02d_receipt.json'%n)
    d=json.loads(receipt.read_text())
    assert d['view_number']==v['number']==n and d['physical_pages']==v['physical_pages']
    assert d['source_PDF_SHA256']==src['SHA256'] and d['note_SHA256']==sha(note)
    assert d['previous_receipt_SHA256']==previous
    assert d['full_selected_text_read'] and d['matching_rendered_image_displayed_and_read']
    assert sha(d['image_path'])==d['image_SHA256']==v['image_SHA256']
    assert sha(d['selected_text_path'])==d['selected_text_SHA256']==v['selected_text_SHA256']
    pages+=d['physical_pages'];previous=sha(receipt)
    receipts.append(dict(view=n,physical_pages=d['physical_pages'],note_path=str(note),note_SHA256=sha(note),receipt_path=str(receipt),receipt_SHA256=sha(receipt)))
assert pages==list(range(1,35))
cal=C/'literal_normalization_calibrations_v1_20261009.json';cj=json.loads(cal.read_text())
assert cj['checks_count']==6 and not cj['floating_point_used'] and not cj['production_VERIFIED']
book=R/'manuscript/book.pdf';book_sha='9e01eefb787a201d3cdc1dd8e5c5802f3ca86c3acd88c22c9f28ca3d401d3f9b'
native={'output/open_problems_catalogue_2026-10-03.tex':'ec3a2a9d8c4d713afe2c0ff8dcf17720ef0d77442b6086d515dea382fe7b77ec','output/open_problems_catalogue_2026-10-03.pdf':'65125a7809e34e4dbe2440855df21447f2c38b79dc3dd6f4a46107353dcb53e2'}
assert sha(book)==book_sha
for name,h in native.items():assert sha(R/name)==h
add=H/'Chambert_Loir_raw_normalized_height_addendum_v3_20261009.json';assert not add.exists()
add.write_text(json.dumps(dict(UTC=now(),status='PRIMARY SOURCE ATTESTED — raw versus normalized height kept distinct',source_SHA256=src['SHA256'],locator='Theorem 4.2 and complete proof, article pages 804–807, physical pages 17–20',actual_receipts=[receipts[8],receipts[9]],geometric_degree='binomial(g+t,t)*(t+1)^t*(M^g)',raw_arithmetic_top='-(g+t+1)!/[g!(t+2)!]*(t+1)^(t+1)*(M^g)*[(t+1)*sum h(q_i)-h(sum q_i)]',normalized_height='-[(t+1)*sum h(q_i)-h(sum q_i)]/(t+2)',normalization='raw / [(g+t+1)*geometric_degree]',rank_one_elliptic_degree_one=dict(raw_minus_4H=True,geometric_degree=4,normalized_minus_H_over_3=True),calibration_SHA256=sha(cal),Hultberg_journal_full_text_read=False,diagnosis_applies_to_journal=False,old_notes_records_archives_rewritten=False,book_changed=False,production_VERIFIED=False,new_reading_credit=0),ensure_ascii=False,indent=2)+'\n')
cp=C/'actual_source_checkpoint_v1_20261009.json';assert not cp.exists()
obj=dict(UTC=now(),status='COMPLETE ACTUAL PUBLISHED-SOURCE READING — scoped primary audit, not recursive proof clearance',DOI=acq['DOI'],edition=acq['edition'],source_PDF_SHA256=src['SHA256'],source_bytes=src['bytes'],source_total_physical_pages=34,article_pages=33,actual_pages=pages,actual_matching_views=17,physical_order_reading=True,receipts=receipts,whole_source_read=True,recursive_inputs_verified=False,calibration_SHA256=sha(cal),exact_calibrations=6,independent_verifier_receipt=False,production_VERIFIED=False,book_changed=False,book_pages=4677,book_PDF_SHA256=book_sha,native_catalogue_preserved=native,native_compile_success_verified=False,canonical_status_changes=[],other_page_credit=0,helper_source=__file__,helper_SHA256=sha(__file__))
cp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
paths={k:E/('Chambert_Loir_complete_source_'+k+'_v1_20261009.'+ext) for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in paths.values())
review='''# Complete Chambert–Loir published-source reading

Antoine Chambert–Loir, *Points de petite hauteur sur les variétés
semi-abéliennes*, Ann. ENS (4) 33(6) (2000), 789–821,
DOI [10.1016/s0012-9593(00)01053-3](https://doi.org/10.1016/s0012-9593(00)01053-3).
All **34 physical pages** (Numdam cover plus 33 article pages) were
actually read in order, with complete selected text and matching images
in **17 displays**, including every proof and reference. The PDF has
4,101,287 bytes, SHA256
`1d29542d8109b860b55828b8f2aa82e602d6d223588c4c13ee0401cb2c3bae04`.
Acquisition, extraction and the prepared manifest alone give no reading
credit. Sequential authored notes and hash-linked receipts control it.

## Primary arithmetic normalization

Theorem 2.5 and its complete proof are on article pages 798–799
(physical 11–12). Let A have dimension g>=1 over a number field, L be
ample symmetric with canonical rigidification, and Q=phi_L(q) in Picard
zero with its canonical rigidification. The mixed arithmetic product is
Qbar squared times Lbar to g-1 = -(2/g)(L^g) hhat_L(q), and all other
mixed terms of total degree g+1 vanish. The **full power** (Lbar+Qbar)
to g+1 therefore includes binomial(g+1,2) and equals
-(g+1)(L^g) hhat_L(q). The normalized height is -hhat_L(q).
Hultberg arXiv:2412.04169v1 page 37 applies the mixed coefficient to
the full power. This exact primary-source addendum resolves the earlier
imported-coefficient uncertainty without rewriting the frozen audit.
Its later 2026 IMRN full text remains unread, so no journal diagnosis
is inferred.

Theorem 4.2 and its full proof (article 804–807, physical 17–20) keep
raw arithmetic intersection, geometric degree and normalized variety
height separate. For the standard rank-t anticanonical compactification,
the degree is binomial(g+t,t)*(t+1)^t*(M^g), and the normalized height is
-[(t+1) sum hhat(q_i)-hhat(sum q_i)]/(t+2). The raw top intersection
is this height times (g+t+1) times the degree. For t=g=1, base degree
one and hhat(q_1)=H, these are respectively -H/3, 4 and -4H.
This explains why raw and normalized formulas cannot be compared
without their degree and dimension factors. Six exact symbolic/rational
checks include 25 raw/normalized dimension/rank samples; no floating
point or new corrected general theorem is used.

## Analytic scope and literal proof qualifications

The main Bogomolov/equidistribution proof reduces **almost-split**
semiabelian varieties by isogeny to A times T. Theorem 6.1 is a product
A times G_m statement, with a whole-product or generically-finite
projection alternative. It is not an arbitrary nonsplit theorem.
For its proper-subvariety proof, the printed genericity in A and etale
cutoff argument need dominance onto A, which the later strict-sequence
application separately establishes. A wider reading as merely finite
onto an arbitrary image needs an additional abelian-image reduction.
This is a scoped audit qualification, not a promoted counterexample.

Lemma 6.4 keeps a positive singular Haar term alongside the smooth
positive block after changing test functions. It does not claim that a
smooth current dominates a fraction of the singular canonical current.
It supplies no repair of the separate literal Kuhne Appendix A.1 claim.
The two-sided logarithmic height and both t and inverse-t are needed
for concentration on the unit circle; Lemma 6.6's printed signed
one-sided function is not itself a distance. The Bilu appendix supplies
the appropriate two-sided quantity. Its following printed height
equality fails at the elementary point 2; the preceding inequality
suffices. Positive shrinking thresholds also cover exact height zero.
The analytic Chern convention is translated through squared norms;
ordinary-norm potentials do not lose their factor two.

Effective standard boundary divisors underpin the open-group
nonnegative-height argument. Arbitrary translated relative-ample
boundary choices need the separate bounded-below condition. Negative
compactification height does not contradict nonnegative open-point
height or disprove point Bogomolov. Joint character pushforwards retain
the abelian factor; separate marginals alone do not imply independence.
Historical open statements are not automatically current 2026 status.

## Status and preserved artifacts

There is **no independent production-verifier receipt** for a new
repair or counterexample. Reading all pages does not recursively audit
every imported result. No new result is promoted to book theorem
typography. The 4,677-page book, canonical 42 atoms/twelve problems,
BJ22 homogeneous Siu/envelopes OPEN and LPWZ density UNVERIFIED remain
unchanged. The native catalogue source, historical PDF and open editor
are preserved; native compilation remains unverified. This is not a
new ordered whole-book reading.

The authored evidence archive contains 46 byte-checked members:
17 notes and 17 receipts, seven source/calibration/checkpoint/addendum
records and five executed helpers. It excludes the primary PDF, full
extracted source text and rendered images. The earlier Hultberg archive
and all executed notes/helpers/records remain frozen. Upload adds no
proof or reading credit. Incoming GitHub continuation302/P12.3 metadata
is explicitly unreviewed; its new claims are being checked separately.
'''
paths['review'].write_text(review)
notes='# Complete actual Chambert–Loir published reading notes\n\n34 physical pages, 17 matching displays; no recursive proof clearance.\n\n'
notes+='\n\n---\n\n'.join((C/'primary_notes_v1'/('note_%02d.md'%n)).read_text().rstrip() for n in range(1,18))
paths['reading_notes'].write_text(notes+'\n')
paths['manifest'].write_text(json.dumps(dict(obj,source_URL=acq['source_URL'],checkpoint_SHA256=sha(cp)),ensure_ascii=False,indent=2)+'\n')
X=E/'artifact_exports/20261009_Chambert_Loir_complete_v1';assert not X.exists();X.mkdir()
members={}
for n in range(1,18):
    for suffix in ['.md','_receipt.json']:
        p=C/'primary_notes_v1'/('note_%02d'%n+suffix);members['primary_notes_v1/'+p.name]=p
for p in [C/'source_acquisition_v1_20261009.json',C/'source_preparation_v1_20261009.json',cal,cp,W/'manifest.json',H/'Chambert_Loir_primary_locator_and_binomial_addendum_v2_20261009.json',add]:members['records/'+p.name]=p
for name in ['Xue_semiabelian_acquire_Chambert_Loir_published_v1_20261009.py','Xue_semiabelian_prepare_Chambert_Loir_published_v1_20261009.py','Xue_semiabelian_record_dependency_reading_v1_20261009.py','Chambert_Loir_literal_calibrations_v1_20261009.py','Chambert_Loir_export_complete_v1_20261009.py']:members['executed_helpers/'+name]=Path('/tmp')/name
assert len(members)==46 and all(p.exists() for p in members.values())
archive=X/'Chambert_Loir_Complete_Actual_Reading_Evidence_V1_2026-10-09.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(members.items()):z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==46
    for name,p in members.items():assert z.read(name)==p.read_bytes()
(X/'README.md').write_text('''# Complete Chambert–Loir published-source evidence

All 34 physical pages were actually read in 17 matching displays.
The 46-member archive preserves authored notes/receipts, exact arithmetic
calibrations and primary normalization addenda with frozen helpers.
No primary PDF, full extracted text or page images are redistributed.
No new theorem or independent production-verifier receipt is claimed.
Hultberg's later journal full text is unread; diagnoses apply to arXiv v1.
The book and native catalogue/editor are preserved. Upload adds no credit.
''')
(X/'SHA256SUMS').write_text(sha(archive)+'  '+archive.name+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=now(),status='EXPORTED — complete published-source reading and primary addenda',archive=str(archive.relative_to(R)),SHA256=sha(archive),bytes=archive.stat().st_size,members=46,actual_Chambert_Loir_pages=34,matching_views=17,exact_calibrations=6,whole_published_source_read=True,Hultberg_journal_full_text_read=False,independent_verifier_receipt=False,production_VERIFIED=False,book_changed=False,reading_credit_for_upload=0),indent=2)+'\n')
update='''
## Complete Chambert–Loir normalization dependency, 9 October 2026

Read all **34 physical pages** of the published 2000 paper in 17 matching
text/image displays. Theorem 2.5 gives a mixed arithmetic coefficient;
the full power has its binomial multiplier. Theorem 4.2 keeps the raw
intersection, geometric degree and normalized height distinct. Six exact
calibrations include 25 dimension/rank normalization samples. Fresh
addenda preserve the frozen Hultberg audit and correct its previously
unread primary-import boundary. The later Hultberg journal remains unread.

See [complete published-source review](manuscript/editorial/Chambert_Loir_complete_source_review_v1_20261009.md)
and [46-member authored evidence](manuscript/editorial/artifact_exports/20261009_Chambert_Loir_complete_v1/README.md).
Almost-split/product hypotheses and scoped literal proof qualifications
remain explicit. No new result or independent VERIFIED receipt is claimed.
The 4,677-page book, catalogue/editor and canonical statuses are unchanged.
Incoming continuation302/P12.3 is unreviewed and under a separate audit.
'''
readme=R/'README.md';progress=E/'second_reading_and_research_programme_20261002.md'
readme.write_text(readme.read_text().rstrip()+'\n'+update)
progress.write_text(progress.read_text().rstrip()+'\n'+update.replace('(manuscript/editorial/','('))
owned=[*paths.values(),*sorted(X.iterdir()),readme,progress];assert len(owned)==9
for p in owned:
    if p.suffix in ['.md','.json']:assert p.read_bytes().endswith(b'\n') and not p.read_bytes().endswith(b'\n\n')
assert sha(book)==book_sha
for name,h in native.items():assert sha(R/name)==h
out=C/'complete_evidence_export_v1_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=now(),status='READY FOR EXPLICIT NINE-FILE PUBLICATION',parent=parent,owned_files=[dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,SHA256=sha(p)) for p in owned],archive_members=46,actual_Chambert_Loir_pages=34,matching_views=17,exact_calibrations=6,book_changed=False,independent_verifier_receipt=False,production_VERIFIED=False,helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
print(json.dumps(dict(owned_files=9,archive_members=46,archive_SHA256=sha(archive),checkpoint_SHA256=sha(cp),export_SHA256=sha(out))))
