from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction
import hashlib, json
import sympy as s

C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009/dependencies_v1/Hultberg24ArxivV1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=C/'literal_normalization_calibrations_v1_20261009.json'
assert not out.exists()
source=json.loads((C/'source_acquisition_v1_20261009.json').read_text())['source']
assert sha(source['path'])==source['SHA256']
for n in range(1,22):
    note=C/'primary_notes_v1'/('note_%02d.md'%n)
    receipt=json.loads(note.with_name('note_%02d_receipt.json'%n).read_text())
    assert receipt['note_SHA256']==sha(note)
    assert receipt['full_selected_text_read'] and receipt['matching_rendered_image_displayed_and_read']

checks=[]
c=Fraction(1,3);ell=2
assert ell*c!=c
checks.append(dict(key='tensor_roof_degree',physical_page=11,locator='Definition 2.3.2',model='Canonical toric metric shifted by c=1/3; zero monomial in degree l=2',minus_log_section_norm=str(ell*c),printed_degree_independent_roof=str(c),normalized_minus_log_section_norm=str(ell*c/ell),kind='Exact tensor homogeneity diagnostic'))

h=s.symbols('h');f=h**2
assert s.diff(f,h).subs(h,3)==6 and f.subs(h,3)==9
checks.append(dict(key='roof_boundary_derivative',physical_page=33,locator='Proposition 5.3.2 as printed',model='t=0, roof height h, f(h)=h^2',derivative_at_3=6,printed_boundary_value_at_3=9,kind='Literal functional-symbol diagnostic; hypograph integral differs from boundary-value integral'))

h1,h2=s.symbols('h1 h2',positive=True)
matrix=s.Matrix([[1,0],[1,2]])
area=h1*h2/abs(matrix.det())
mixed=s.diff(area,h1,h2)
assert matrix.det()==2 and mixed==s.Rational(1,2)
checks.append(dict(key='simplicial_support_Jacobian',physical_page=33,locator='Lemma 5.3.1',model='0<=x<=h1, 0<=x+2y<=h2; primitive normal rows (1,0),(1,2)',area=str(area),mixed_support_derivative=str(mixed),printed_determinant_factor=2,smooth_unimodular_scope_unaffected=True,kind='Exact linear change-of-variables diagnostic for nonunimodular extension'))

D,a,b,l1,l2=s.symbols('D a b l1 l2')
coefficient=s.expand((D+l1*a+l2*b)**2).coeff(l1,1).coeff(l2,1)
printed=2*D*a*b
assert coefficient==2*a*b and s.simplify(coefficient-printed)!=0
checks.append(dict(key='squarefree_power_derivative',physical_page=35,locator='Lemma 5.4.1 proof, first derivative identity',model='t=i=1; two squarefree directions in (D+lambda1*a+lambda2*b)^2',actual_coefficient=str(coefficient),printed_coefficient=str(printed),correct_general_coefficient='(t+i)!/(i-1)! times rho(Delta)^(i-1)',kind='Exact falling-factorial and excess-codimension diagnostic; announced lemma has the compatible factor'))

ratios={str(g):str(Fraction(-2,g*(g+1))) for g in [1,2,3]}
assert ratios=={'1':'-1','2':'-1/3','3':'-1/6'}
checks.append(dict(key='quoted_abelian_degree_ratio',physical_page=37,locator='Lemma 6.0.1 proof',printed_numerator='-2 deg(M^g)/g times h_M(q)',printed_denominator='(g+1) deg(M^g)',exact_result_coefficients=ratios,printed_result_coefficient='-1',kind='Internal algebraic mismatch; Chambert–Loir controlling source still pending'))

m=s.symbols('m',real=True)
integral=s.integrate(m**2,(m,-1,1))
theorem_C=-s.factorial(3)*integral
lemma_603=-s.Rational(3,2*3)*(1+1)
assert integral==s.Rational(2,3) and theorem_C==-4 and lemma_603==-1
checks.append(dict(key='anticanonical_simplex_internal_consistency',physical_pages=[38,39],locators=['Theorem C','Lemma 6.0.3'],model='t=g=1, d=2, deg(base M)=1, Delta=[-1,1], hhat(c(m))=H*m^2 with H=1',roof_integral=str(integral),Theorem_C_value=str(theorem_C),Lemma_603_value=str(lemma_603),kind='Exact comparison of two printed source formulas; no external arithmetic theorem needed'))

scalings=[]
for degree in [1,2,3]:
    I=s.integrate(m**2/degree,(m,0,1))
    base_volume=s.Integer(degree)
    printed=-s.factorial(3)*I
    product=-s.factorial(3)*base_volume*I
    assert product==-2
    scalings.append(dict(base_M_power=degree,transferred_dual_height_coefficient=str(s.Rational(1,degree)),base_Okounkov_volume=str(base_volume),roof_integral=str(I),printed_Theorem_C_value=str(printed),product_body_formula_value=str(product)))
assert scalings[0]['printed_Theorem_C_value']=='-2' and scalings[1]['printed_Theorem_C_value']=='-1'
checks.append(dict(key='base_polarization_scaling',physical_pages=[7,37,38],model='Elliptic base with principal symmetric M1, fixed dual character point, Ma=M1^a, Delta=[0,1], hhat_Ma(c(m))=H*m^2/a, H=1',calculations=scalings,kind='Conditional formal consequence of the stated product body/roof and standard polarization transfer; not independent verification of the total height theorem'))

obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='EXACT EXECUTABLE SOURCE CALIBRATIONS — arXiv v1 only; main results unverified',source_PDF_SHA256=source['SHA256'],checks=checks,checks_count=len(checks),floating_point_used=False,independent_verifier_receipt=False,production_VERIFIED=False,journal_version_checked=False,new_mathematical_results_promoted=[],book_changed=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(checks=len(checks),record=str(out),SHA256=sha(out),all_exact=True,journal_version_checked=False)))
