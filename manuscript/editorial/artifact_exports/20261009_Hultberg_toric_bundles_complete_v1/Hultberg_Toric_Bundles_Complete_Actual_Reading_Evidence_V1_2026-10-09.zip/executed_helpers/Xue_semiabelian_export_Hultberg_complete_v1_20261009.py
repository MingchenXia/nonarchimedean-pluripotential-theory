from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile,subprocess

R=Path('/workspace/nonarchimedean-pluripotential-theory');E=R/'manuscript/editorial'
C=R/'source_material/Xue_semiabelian_review_20261009/dependencies_v1/Hultberg24ArxivV1'
W=Path('/tmp/Xue_semiabelian_dependency_views_v1_20261009/Hultberg24ArxivV1')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
assert git('rev-parse','HEAD')=='c09aca85f5762b2e37f77118d53e6496f2c6df46'
assert not git('diff','--name-only') and not git('diff','--cached','--name-only')
acq=json.loads((C/'source_acquisition_v1_20261009.json').read_text());src=acq['source']
prep=json.loads((C/'source_preparation_v1_20261009.json').read_text())
assert sha(src['path'])==src['SHA256'] and Path(src['path']).stat().st_size==src['bytes']
assert sha(W/'manifest.json')==prep['manifest_SHA256']
views=json.loads((W/'manifest.json').read_text());assert len(views)==21
receipts=[];pages=[];previous=None
for n,v in enumerate(views,1):
    note=C/'primary_notes_v1'/('note_%02d.md'%n);receipt=note.with_name('note_%02d_receipt.json'%n)
    d=json.loads(receipt.read_text())
    assert d['view_number']==v['number']==n and d['physical_pages']==v['physical_pages']
    assert d['source_PDF_SHA256']==src['SHA256'] and d['note_SHA256']==sha(note)
    assert d['previous_receipt_SHA256']==previous
    assert d['full_selected_text_read'] and d['matching_rendered_image_displayed_and_read']
    assert sha(d['image_path'])==d['image_SHA256']==v['image_SHA256']
    assert sha(d['selected_text_path'])==d['selected_text_SHA256']==v['selected_text_SHA256']
    pages+=d['physical_pages'];previous=sha(receipt)
    receipts.append(dict(view=n,physical_pages=d['physical_pages'],note_path=str(note),note_SHA256=sha(note),receipt_path=str(receipt),receipt_SHA256=sha(receipt)))
assert pages==list(range(1,43))
cal=C/'literal_normalization_calibrations_v1_20261009.json';cj=json.loads(cal.read_text())
assert cj['checks_count']==7 and not cj['production_VERIFIED'] and not cj['floating_point_used']
book=R/'manuscript/book.pdf';book_sha='9e01eefb787a201d3cdc1dd8e5c5802f3ca86c3acd88c22c9f28ca3d401d3f9b'
assert sha(book)==book_sha
native={'output/open_problems_catalogue_2026-10-03.tex':'ec3a2a9d8c4d713afe2c0ff8dcf17720ef0d77442b6086d515dea382fe7b77ec','output/open_problems_catalogue_2026-10-03.pdf':'65125a7809e34e4dbe2440855df21447f2c38b79dc3dd6f4a46107353dcb53e2'}
for n,h in native.items():assert sha(R/n)==h
lit=C/'current_primary_literature_and_GitHub_check_v1_20261009.md';assert not lit.exists()
lit.write_text('''# Version and repository check, 9 October 2026

Primary metadata was inspected separately from the actual PDF reading.
The arXiv page https://arxiv.org/abs/2412.04169 lists only v1, 5 December
2024, 42 pages. The completed reading and all literal calibrations concern
those exact bytes.

Oxford Academic's primary article record
https://academic.oup.com/imrn/article-abstract/2026/4/rnag015/8472538
redirects to https://oup.silverchair-cdn.com/article-minimal/8472538.
It identifies the published article in IMRN 2026(4), rnag015,
DOI https://doi.org/10.1093/imrn/rnag015, published 11 February 2026,
received 4 August 2025, revised 8 November 2025, accepted 28 December
2025. The accessible response provides metadata/abstract and labels the
article available for purchase. No journal PDF/full text was acquired or
read. Do not transfer arXiv v1 numbering or error diagnoses to the journal
edition, which may incorporate corrections. No exhaustive erratum search
or current published-theorem verdict is claimed.

The author's public site https://sites.google.com/view/nuno-hultberg/home
also links the directly relevant 2026 preprint
https://arxiv.org/abs/2601.04972, New gap principle for semiabelian
varieties using globally valued fields. Its primary arXiv metadata lists
v1 of 8 January 2026 and 43 pages. Its abstract distinguishes a
characteristic-zero result, a positive-characteristic reduction with an
unresolved abelian input, and an elliptic-quotient special case. This is
metadata only; no proof or PDF-reading credit is given.

The primary Numdam record for Chambert–Loir's 2000 paper is
https://www.numdam.org/item/ASENS_2000_4_33_6_789_0/.
The published dependency has been acquired in a separate directory for
fresh reading; acquisition gives no Hultberg or dependency reading credit.

The GitHub branches API was read on this date. main remained
00957114db21b627e97369563032ceda9cea09c7 and work matched our verified
c09aca85f5762b2e37f77118d53e6496f2c6df46. Other returned branch heads
were codex/cloud-env-setup-20261001 at d89e36d247394fbe3f45501a0c6657d2082ce5da
and codex/xean-research-20261003 at 1aeb16838fc957d36947eb70664cab1ea15335e6.
This snapshot does not claim their contents have been newly read or merged.

Search/metadata inspection, acquisition and upload add zero proof-page credit.
''')
cp=C/'actual_source_checkpoint_v1_20261009.json';assert not cp.exists()
obj=dict(UTC=now(),status='COMPLETE ACTUAL READING — arXiv v1 only; source diagnostics not blanket proof clearance',arXiv='2412.04169v1',source_PDF_SHA256=src['SHA256'],source_bytes=src['bytes'],source_total_physical_pages=42,actual_pages=pages,actual_matching_views=21,physical_order_reading=True,receipts=receipts,whole_source_read=True,recursive_inputs_verified=False,calibration_path=str(cal),calibration_SHA256=sha(cal),exact_calibrations=7,journal=dict(DOI='10.1093/imrn/rnag015',published='2026-02-11',metadata_only=True,full_text_read=False,error_diagnoses_apply_to_journal=False),literature_record_SHA256=sha(lit),independent_verifier_receipt=False,production_VERIFIED=False,intended_main_theorems_status='UNVERIFIED FOR IMPORT — exact arXiv v1; journal edition not audited',book_changed=False,book_pages=4677,book_PDF_SHA256=book_sha,native_catalogue_preserved=native,native_compile_success_verified=False,canonical_status_changes=[],other_page_credit=0,helper_source=__file__,helper_SHA256=sha(__file__))
cp.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
paths={k:E/('Hultberg_toric_bundles_complete_source_'+k+'_v1_20261009.'+ext) for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in paths.values())
review='''# Complete toric-bundle source reading and version-specific audit

Nuno Hultberg, *Arakelov geometry of toric bundles: Okounkov bodies and
BKK*, arXiv:2412.04169v1, 5 December 2024. All **42 physical pages**
were actually read in order, with complete selected text and matching
rendered images in **21 displays**. The PDF is 491,226 bytes, SHA256
`65fd4d1052fc359e6d64ec87ea55fc12be5a07947114575f2a0f59fe387194dc`.
This completes the source's proofs, examples and references, not recursive
verification of every imported theorem.

## Controlling version boundary

A current primary metadata check found the published IMRN 2026(4)
article rnag015, DOI [10.1093/imrn/rnag015](https://doi.org/10.1093/imrn/rnag015),
published 11 February 2026 after a November 2025 revision. The accessible
journal response supplies metadata and abstract. **Its full text has not
been acquired or read. Every following diagnosis applies only to the
exact 2024 arXiv v1.** Do not call it a verified journal erratum or assume
the later edition has the same statements, numbering or mistakes.

## Scope that must be retained

Torsors are for split tori in the Zariski topology, encoded by coherent
monoidal functors on the character lattice. Picard classes alone discard
the tensor identifications and rigidifications. Semiabelian group laws
require Picard-zero twists and a rigidification. Flat torsors preserve
semipositivity; integrable torsors preserve integrability with a common
positive base twist. Metrized morphisms have norm one; general degenerate
equivariant maps are not all admitted toric-bundle morphisms.

Orbit closures use the quotient character lattice M intersect sigma
perpendicular and retain the base twist when faces are translated.
Canonical fiber boundary divisors have multiplication weight n, while
abelian polarizations have weight n squared. Actual morphism degrees and
all mixed/binomial factors must retain this distinction.

Okounkov-body and transform fibers are identified on the geometrically
big base-twist locus using an adapted toric/base flag. Theorem A adds
semipositivity of all base twists for its absolute-minimum formula.
Full-dimensional fiber polytopes/interior conventions and the precise
general absolute-minimum import need checking. Torus invariance in the
height-filtration argument concerns Zariski closures under torsion
density; arbitrary torus translates do not preserve individual heights.
An infimum of heights is not exact point attainment.

The arithmetic BKK formula uses a smooth projective base of dimension g,
smooth generic toric fiber of dimension t, integrable adelic metrics and
an operational arithmetic class of codimension g+1-i on a flat model.
Its coefficient is i! on the intersection versus (t+i)! on the weighted
roof integral. Extensions to b-cycles require the stated integrability
and positivity/continuity controls. Fan/model approximation and curvature
current support arguments are load-bearing, not automatic from a
pointwise product of Green functions.

## Exact checks of the literal arXiv text

Seven executable calculations use rational/symbolic arithmetic with no
floating point:

1. Definition 2.3.2 omits the degree l in a monomial's minus log norm.
   A constant metric shift c gives lc on lD and c on the normalized roof.
2. Proposition 5.3.2 confuses the boundary-value functional with its
   hypograph integral: at torus rank zero f(h)=h squared differentiates
   to 2h, not f(h).
3. The printed determinant factor for a simplicial support-coordinate
   derivative needs the inverse Jacobian. The primitive normals (1,0),
   (1,2) give area h1*h2/2, mixed derivative 1/2 versus the printed 2.
   A smooth unimodular cone has determinant one and hides this issue.
4. The squarefree derivative display in Lemma 5.4.1's proof retains one
   excess rho(Delta) factor. Order t+1 differentiation leaves exponent
   i-1 and factorial (t+i)!/(i-1)!, consistent with the lemma's announced
   factor. This is separated from the truth of the intended BKK identity.
5. Lemma 6.0.1's printed imported numerator divided by its denominator
   gives -2/[g(g+1)] times the Néron–Tate height, rather than -1 when g>1.
   The controlling Chambert–Loir primary theorem remains to be read.
6. With t=g=1, base degree one and anticanonical interval [-1,1], a
   quadratic hhat(c(m))=H*m squared gives -4H from printed Theorem C
   and -H from printed Lemma 6.0.3. These source formulas are internally
   inconsistent under their stated conventions.
7. On an elliptic base, scaling M to M to the power a scales its body
   volume by a and its polarization-transferred dual height by 1/a.
   The product-body integral preserves their product, whereas printed
   Theorem C drops the base volume. This is a formal normalization test,
   not an independent verification of a corrected height theorem.

The detailed notes also preserve increasing-filtration/sign problems,
continuous roofs versus literal polytopes, the misuse of Noetherianity
for increasing closed chains, and the ground-field dependence of
rescaled dynamical identifications. These are distinct diagnoses, not
a blanket assertion that all intended Theorems A–D are false.

**No independent production-verifier receipt is available. No new result,
verified counterexample, priority claim or source-wide repair is promoted.**
The current journal edition is unexamined, and the arXiv main results
remain unverified for book import. Chambert–Loir's published source is
the next normalization dependency. The author's 2026 GVF gap-principle
preprint is a relevant later reading direction, with metadata only so far.

## Preserved book and authored evidence

The 4,677-page book is unchanged, SHA256
`9e01eefb787a201d3cdc1dd8e5c5802f3ca86c3acd88c22c9f28ca3d401d3f9b`.
The canonical 42 atoms/twelve problems, general BJ22 Siu/envelopes OPEN,
and LPWZ density UNVERIFIED are unchanged. The native catalogue source,
historical PDF and editor are preserved; native compilation is unverified.
This is a source read, not another ordered whole-book reread.

The 53-member evidence ZIP contains authored notes/receipts, source
acquisition/preparation and actual checkpoint, exact calibrations,
version/GitHub metadata, preparation manifest and executed helpers.
Primary PDFs, full extracted text and rendered page images are excluded.
Every archive member is compared byte-for-byte to its local source.
Upload grants zero additional reading or proof credit.
'''
paths['review'].write_text(review)
notes='# Complete actual Hultberg arXiv v1 reading notes\n\n42 pages, 21 matching displays; no journal/recursive proof clearance.\n\n'
notes+='\n\n---\n\n'.join((C/'primary_notes_v1'/('note_%02d.md'%n)).read_text().rstrip() for n in range(1,22))
paths['reading_notes'].write_text(notes+'\n')
paths['manifest'].write_text(json.dumps(dict(obj,source_URL=acq['source_URL'],checkpoint_SHA256=sha(cp)),ensure_ascii=False,indent=2)+'\n')
X=E/'artifact_exports/20261009_Hultberg_toric_bundles_complete_v1';assert not X.exists();X.mkdir()
members={}
for n in range(1,22):
    for suffix in ['.md','_receipt.json']:
        p=C/'primary_notes_v1'/('note_%02d'%n+suffix);members['primary_notes_v1/'+p.name]=p
for p in [C/'source_acquisition_v1_20261009.json',C/'source_preparation_v1_20261009.json',cal,lit,cp,W/'manifest.json']:members['records/'+p.name]=p
for name in ['Xue_semiabelian_acquire_Hultberg_toric_bundles_v1_20261009.py','Xue_semiabelian_prepare_Hultberg_toric_bundles_v1_20261009.py','Xue_semiabelian_record_dependency_reading_v1_20261009.py','Xue_semiabelian_Hultberg_literal_calibrations_v1_20261009.py','Xue_semiabelian_export_Hultberg_complete_v1_20261009.py']:members['executed_helpers/'+name]=Path('/tmp')/name
assert len(members)==53 and all(p.exists() for p in members.values())
archive=X/'Hultberg_Toric_Bundles_Complete_Actual_Reading_Evidence_V1_2026-10-09.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
    for name,p in sorted(members.items()):z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==53
    for name,p in members.items():assert z.read(name)==p.read_bytes()
(X/'README.md').write_text('''# Complete toric-bundle arXiv source evidence

All 42 arXiv v1 pages were actually read in 21 matching displays.
The 53-member archive contains authored notes, receipts, exact calibration
and frozen acquisition/preparation/checkpoint records with helpers.
No primary PDF, full extracted text or rendered images are redistributed.
The February 2026 IMRN edition was checked only as metadata; its full text
is unread. All diagnostics apply to the exact 2024 arXiv v1.
No independent VERIFIED receipt, new theorem or journal erratum is claimed.
The 4,677-page book and native catalogue source/PDF are unchanged.
''')
(X/'SHA256SUMS').write_text(sha(archive)+'  '+archive.name+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=now(),status='EXPORTED — complete arXiv v1 source reading, no journal proof clearance',archive=str(archive.relative_to(R)),SHA256=sha(archive),bytes=archive.stat().st_size,members=53,actual_Hultberg_pages=42,matching_views=21,exact_calibrations=7,whole_arXiv_v1_read=True,journal_full_text_read=False,independent_verifier_receipt=False,production_VERIFIED=False,book_changed=False,reading_credit_for_upload=0),indent=2)+'\n')
update='''
## Complete toric-bundle arXiv reading, 9 October 2026

Read all **42 pages** of Hultberg arXiv:2412.04169v1 in 21 matching
complete-text/image displays. Seven exact calibrations isolate tensor,
derivative, lattice-Jacobian and arithmetic-height normalization defects
in the literal 2024 text. The intended main results remain unverified
for book import; no new result or source-wide refutation is promoted.

A primary metadata check found the later IMRN 2026(4) edition rnag015,
published 11 February 2026. Its full text is unread: the arXiv diagnoses
must not be transferred to that version. Chambert–Loir's published 2000
paper is the next normalization dependency; the author's 2026 GVF gap
principle is a later research direction with metadata-only status.

See [version-specific full source audit](manuscript/editorial/Hultberg_toric_bundles_complete_source_review_v1_20261009.md)
and [53-member authored evidence](manuscript/editorial/artifact_exports/20261009_Hultberg_toric_bundles_complete_v1/README.md).
The **4,677-page book**, native catalogue source/PDF/editor and canonical
problem statuses are unchanged. Upload adds no reading or proof credit.
'''
readme=R/'README.md';progress=E/'second_reading_and_research_programme_20261002.md'
readme.write_text(readme.read_text().rstrip()+'\n'+update)
progress.write_text(progress.read_text().rstrip()+'\n'+update.replace('(manuscript/editorial/','('))
owned=[*paths.values(),*sorted(X.iterdir()),readme,progress];assert len(owned)==9
for p in owned:
    if p.suffix in ['.md','.json']:
        assert p.read_bytes().endswith(b'\n') and not p.read_bytes().endswith(b'\n\n')
for n,h in native.items():assert sha(R/n)==h
assert sha(book)==book_sha
out=C/'complete_evidence_export_v1_20261009.json';assert not out.exists()
out.write_text(json.dumps(dict(UTC=now(),status='READY FOR EXPLICIT NINE-FILE PUBLICATION',parent='c09aca85f5762b2e37f77118d53e6496f2c6df46',owned_files=[dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,SHA256=sha(p)) for p in owned],archive_members=53,actual_Hultberg_pages=42,matching_views=21,exact_calibrations=7,journal_full_text_read=False,book_changed=False,independent_verifier_receipt=False,production_VERIFIED=False,helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
print(json.dumps(dict(owned_files=9,archive_members=53,archive_SHA256=sha(archive),checkpoint_SHA256=sha(cp),export_SHA256=sha(out))))
