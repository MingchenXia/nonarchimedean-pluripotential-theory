# Version and repository check, 9 October 2026

Primary metadata was inspected separately from the actual PDF reading.
The arXiv page https://arxiv.org/abs/2412.04169 lists only v1, 5 December
2024, 42 pages. The completed reading and all literal calibrations concern
those exact bytes.

Oxford Academic's primary article record
https://academic.oup.com/imrn/article-abstract/2026/4/rnag015/8472538
redirects to https://oup.silverchair-cdn.com/article-minimal/8472538.
It identifies the published article in IMRN 2026(4), rnag015,
DOI https://doi.org/10.1093/imrn/rnag015, published 11 February 2026,
received 4 August 2025, revised 8 November 2025, accepted 28 December
2025. The accessible response provides metadata/abstract and labels the
article available for purchase. No journal PDF/full text was acquired or
read. Do not transfer arXiv v1 numbering or error diagnoses to the journal
edition, which may incorporate corrections. No exhaustive erratum search
or current published-theorem verdict is claimed.

The author's public site https://sites.google.com/view/nuno-hultberg/home
also links the directly relevant 2026 preprint
https://arxiv.org/abs/2601.04972, New gap principle for semiabelian
varieties using globally valued fields. Its primary arXiv metadata lists
v1 of 8 January 2026 and 43 pages. Its abstract distinguishes a
characteristic-zero result, a positive-characteristic reduction with an
unresolved abelian input, and an elliptic-quotient special case. This is
metadata only; no proof or PDF-reading credit is given.

The primary Numdam record for Chambert–Loir's 2000 paper is
https://www.numdam.org/item/ASENS_2000_4_33_6_789_0/.
The published dependency has been acquired in a separate directory for
fresh reading; acquisition gives no Hultberg or dependency reading credit.

The GitHub branches API was read on this date. main remained
00957114db21b627e97369563032ceda9cea09c7 and work matched our verified
c09aca85f5762b2e37f77118d53e6496f2c6df46. Other returned branch heads
were codex/cloud-env-setup-20261001 at d89e36d247394fbe3f45501a0c6657d2082ce5da
and codex/xean-research-20261003 at 1aeb16838fc957d36947eb70664cab1ea15335e6.
This snapshot does not claim their contents have been newly read or merged.

Search/metadata inspection, acquisition and upload add zero proof-page credit.
