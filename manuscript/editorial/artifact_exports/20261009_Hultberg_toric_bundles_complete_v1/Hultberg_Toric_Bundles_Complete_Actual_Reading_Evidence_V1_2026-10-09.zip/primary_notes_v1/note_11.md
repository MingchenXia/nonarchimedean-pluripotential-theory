# Hultberg arXiv v1 — actual source reading 11

Physical pages 21–22 were read completely in selected text and matching image. No other pages credited.

Proposition 3.3.4 constructs metrized descent through a local algebraic trivialization corrected by its tropical norm, since norm-one local trivializations generally do not exist. Unit-torus isometry gives the required factorization of metric distortion. Proposition 3.3.5 globalizes using models of both the torsor and vector bundle on one dense open. This keeps period/norm information rather than discarding it through arbitrary trivializations.

Lemma 3.3.6 requires a semipositive toric fiber metric and semipositive base twists L+T(m) for every rational point of the Newton polytope. The proof uses sup-norm/maximum-monomial norm comparison, then quotient metrics and uniform approximation on a semiample line bundle. The error is bounded by log(number of lattice points)/l, tending to zero. Some displayed indexing literally uses (1/l)Delta intersect M where sections of lD should use lDelta intersect M, or scaled points Delta intersect (1/l)M; keep the scaling straight when checking this proof. The needed approximation imports are CM18 and Moriwaki and are not recursively cleared here.

Corollary 3.3.7 distinguishes integrability preservation for an integrable torsor from semipositivity preservation for a flat torsor. The latter uses simultaneous positivity of all character twists, not arbitrary torsors or a single positive basis. This distinction will matter for Theorem A and the abelian Pic^0 application.

No book change, independent verifier receipt or main-theorem clearance.
