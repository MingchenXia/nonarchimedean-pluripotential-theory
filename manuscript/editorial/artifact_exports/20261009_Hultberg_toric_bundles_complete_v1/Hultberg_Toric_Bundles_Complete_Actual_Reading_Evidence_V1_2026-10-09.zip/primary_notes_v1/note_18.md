# Hultberg arXiv v1 — actual source reading 18

Physical pages 35–36 were read completely in selected text and matching image. No other pages credited. This finishes the printed proof of Theorem B, but not recursive clearance of its imports.

The squarefree arithmetic derivative computation on page 35 literally has (t+i)!/i! times rho(Delta)^i and t+1 ray-divisor factors. Differentiating a degree t+i power t+1 times instead gives (t+i)!/(i-1)! times rho(Delta)^(i-1). The printed product has one excess codimension. The earlier Lemma 5.4.1's announced factor i(t+i)!/i! is consistent with the corrected falling factorial, suggesting a repair of this intermediate display, not a verified failure of the intended theorem. The vertex reduction and projection then require the corrected exponent and correct determinant/local-weight conventions.

The repeated-ray derivative step expresses one support derivative as a translation Lie derivative plus directions outside the current cone, reducing multiplicity. The Lie derivative computations give L_v I_gamma = i I_(c(v)gamma) and L_v F_gamma = (t+i) F_(c(v)gamma), with the extended c(v) including the roof-height coordinate. Induction on i produces the intended factorial relation. Some displayed arguments suppress theta and mislabel translation variables; do not reproduce them verbatim.

Polynomial homogeneity and all order-(t+1) derivative comparisons determine the degree-(t+i) difference for i>0; i=0 was separately treated by projection. Compatible fans/model approximation and continuous integrable intersections remain load-bearing. Literal display errors have been separated from any assertion about the true arithmetic BKK identity.

No book change, independent verifier receipt or main-theorem clearance.
