# Hultberg arXiv v1 — actual source reading 12

Physical pages 23–24 were read completely in selected text and matching image. No other pages credited.

Integrability preservation is proved using one common positive base twist for the finitely many vertices of the Newton polytope and convexity, then semipositivity of the descended twist. Dynamical fiber metrics agree with descent of the fixed canonical torsor metric. This concerns the fiber divisor's r-eigenweight, not the abelian ample divisor's r-squared eigenweight.

Lemma 3.4.1 obtains pushforward/eigenspace decompositions by flat base change and gluing, with character twists T(m). Proposition 3.4.2 compares fiberwise supremum norms to descended section norms; a normed trivialization at an analytic fiber may require extending its residue field, rather than asserting a global norm-one trivialization. Lemma 3.4.3 uses orthogonality and the corrected tensor-homogeneous roof definition.

Section 3.5 assumes an integrable smooth projective toric bundle over a smooth projective base and a compatible smooth projective adelic fan. Proposition 3.5.1 states vanishing of arithmetic products for rays that span no cone, with model torsor metrics at finite places and smooth torsor metrics at infinity. Finite-place proof uses regular ambient toric models and empty intersections. The archimedean proof uses piecewise linear Green functions and support/flatness properties. A mere pointwise product of continuous Green functions equal to zero does not by itself imply vanishing of a curvature-product current; the shared-fan support geometry and an admissible approximation are necessary. The continuation of that proof is on the next page and not yet credited here.

No book change, independent verifier receipt or main-theorem clearance.
