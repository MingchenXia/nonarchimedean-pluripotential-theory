# Hultberg arXiv v1 — actual source reading 07

Physical pages 13–14 were read completely in selected text and the matching image. No other reading credit.

Operational arithmetic cohomology is a compatible family on projective test schemes with smooth generic fiber. Proper compatibility is stated for generically smooth maps plus a fundamental-class provision; flat/lci compatibility includes special fibers with ordinary Chow groups. Proposition 2.4.3 extends intersections to integrable adelic metrics via model domination and sup-norm continuity. The archimedean argument decomposes a smooth curvature representative into strongly positive forms; a uniform mass bound, not merely pointwise positivity, is necessary for the constant K. The finite-place argument uses numerical nef dual classes and their pullback/intersection with nef divisors, importing FL17 Lemma 3.7. This import is not recursively checked here.

Definition 2.4.4 is restricted to a smooth proper variety over Q and inverse limits of proper flat integral models under proper pushforward. Positivity is tested against one effective vertical divisor and further relatively nef factors at finite places. Integrability is a difference of positive compatible b-cycles, rather than arbitrary inverse-limit cycles. Proposition 2.4.5's extension relies on exactly that positivity/control; do not broaden it to all arithmetic b-cycles, all singular generic fibers or undefined arbitrary bivariant pushforwards.

No book change, independent verifier verdict or main-theorem clearance.
