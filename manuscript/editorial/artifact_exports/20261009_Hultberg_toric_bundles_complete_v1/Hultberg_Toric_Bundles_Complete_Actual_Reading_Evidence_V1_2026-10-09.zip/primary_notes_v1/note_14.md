# Hultberg arXiv v1 — actual source reading 14

Physical pages 27–28 were read completely in selected text and matching image. No other pages credited.

The geometric adapted flag first cuts toric divisors down to a copy of the base, then extends by a base flag. Translating the fiber polytope changes the base twist L as well. Theorem 4.0.1 describes the body as a closure of (m,base-body) fibers; actual fiber equality is asserted where L+T(m) is geometrically big. It uses eigensection surjectivity and continuity/convexity inside the big cone, not arbitrary nonbig fiber equalities.

Theorem 4.1.1 similarly describes the concave transform as theta(m)+G_(L+T(m))(x) on geometrically big fibers, relying on the consistent signed/tensor-normalized roof and orthogonality. Its proof does not independently repair the earlier definition-sign issues. Remark 4.1.2 is a conditional research direction toward Ballaÿ–Sombra approximation criteria, not a general equidistribution theorem for every toric bundle.

Theorem A takes at least one geometrically big base twist and semipositive toric fiber metric; its absolute-minimum clause further needs every base twist semipositive. Essential minimum is a supremum over the closed polytope; the absolute expression uses its interior. The argument that a big base twist makes the whole bundle divisor big also needs a full-dimensional fiber polytope in the fiber character space, or an appropriate effective quotient dimension. The printed general setup does not explicitly supply that restriction here. An ordinary interior of a lower-dimensional polytope is empty. Retain this boundary diagnostic pending the next-page remark.

The essential proof restricts to the big-twist locus then uses concavity to approximate boundary values. Do not read it as equality of every nonbig Okounkov fiber or remove the big-locus qualification.

No book change, independent verifier receipt or main-theorem clearance.
