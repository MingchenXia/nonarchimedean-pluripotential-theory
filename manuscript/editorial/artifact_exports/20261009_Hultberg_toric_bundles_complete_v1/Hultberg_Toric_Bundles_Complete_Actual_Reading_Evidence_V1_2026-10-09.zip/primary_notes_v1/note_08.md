# Hultberg arXiv v1 — actual source reading 08

Physical pages 15–16 were read completely in the selected text and matching image. No other pages credited.

Remark 2.4.6 passes operational classes to compatible b-cycles and permits computing bundle intersections on models flat over base models. Its final wording mentions arbitrary b-cycles, while the preceding continuity theorem explicitly requires integrable b-cycles; preserve that requirement unless a separate extension argument is supplied. No general pullback of b-cycles is asserted. Example 2.4.7 obtains finite-place positive b-cycles from closures of a fixed generic cycle and a Green current, using vertical effectiveness and relative nefness.

All torsors in section 3 are Zariski torsors for split tori. A torus bundle is encoded as a symmetric monoidal functor from the character lattice category to the category of line bundles, including coherent tensor isomorphisms and morphisms, not merely a map to abstract Picard classes. Metrized/adelic versions preserve these identifications and norms. Flat means both the bundle and its dual are semipositive; because a lattice contains m and -m, semipositivity of every image automatically implies flatness. Algebraic metrics may come from rational model line bundles, while model metrics here use actual line bundles.

Morphisms allow a torus homomorphism with contravariant character map alpha:M'→M and a monoidal natural transformation. Proposition 3.1.5's sections must be torsor sections/trivializations, hence nowhere vanishing and tensor-compatible; arbitrary vanishing vector-bundle sections would not give equivariant torsor maps. These distinctions are relevant to the semiabelian extension and period-norm constructions.

No book integration, independent verifier receipt or main-theorem clearance.
