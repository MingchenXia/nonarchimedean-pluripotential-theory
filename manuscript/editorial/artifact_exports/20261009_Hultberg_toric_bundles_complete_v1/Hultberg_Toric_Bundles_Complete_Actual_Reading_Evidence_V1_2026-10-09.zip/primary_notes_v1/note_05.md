# Hultberg arXiv v1 — actual source reading 05

Physical pages 9–10 were read completely in the selected text and matching rendered two-page display. No other pages receive credit.

- Definition 2.1.13 introduces place-wise interior inside a compatible effective cone; its vector-space/topological meaning must remain explicit for later directional derivatives.
- Section 2.2 defines the Okounkov body using a regular geometric point, completed local parameters and lexicographic valuation. Valuations are of nonzero sections and the scaled degrees must start at n=1 even though the displayed union literally starts at zero. Choice of flag/coordinates is load-bearing for transforms and absolute-minimum comparisons.
- The printed increasing filtration is spanned by section vectors of height at most t, and the printed transform is the infimum of membership thresholds. Standard concave Boucksom–Chen transforms instead use a decreasing filtration and a supremum. Their later metric/section sign convention must be inspected before importing this definition: an increasing height filtration produces the negative of the usual concave roof unless signs are changed. This is a definition diagnostic, not a cleared main-theorem counterexample.
- Theorem 2.2.1 asserts essential minimum = maximum of the transform for geometrically big real divisors, then absolute minimum = infimum if semipositive, referencing QY23/Ballaÿ. Need check the controlling primary imports, chosen flag and sign; the literal text here does not itself clear the wider absolute-minimum assertion.
- Theorem 2.2.2 keeps geometric volume d! times body volume, arithmetic positive-part volume (d+1)! integral max(0,G), and chi volume bounded by (d+1)! integral G, with equality under finite lower bound. The arithmetic normalization is explicitly distinguished from Ballaÿ's.
- Theorem 2.2.3 uses geometric nefness for volume=degree and semipositivity for chi volume=unnormalized arithmetic height, within the section's geometrically big projective setting. Do not remove these ambient hypotheses downstream.
- Section 2.3 explains the need for an adapted toric flag to identify the body and transform with the Newton polytope and toric roof. A smooth projective toric refinement is selected, rather than declaring every complete fan projective. This clarifies the earlier refinement scope.

No independent verifier receipt, book integration, recursive source clearance, or main-theorem clearance is claimed.
