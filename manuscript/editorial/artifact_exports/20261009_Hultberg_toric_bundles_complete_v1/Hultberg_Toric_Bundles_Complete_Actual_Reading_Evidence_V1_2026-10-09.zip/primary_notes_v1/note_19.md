# Hultberg arXiv v1 — actual source reading 19

Physical pages 37–38 were read completely in selected text and matching image. No other pages credited.

Section 6 now pins all key conventions: split torus, an ample fiber divisor with full-dimensional Newton polytope, ample symmetric base M with canonical metrics, and Néron–Tate height transferred to A-dual through M's polarization. It is not an intersection-degree-weighted replacement height. The total dimension is d=t+g. Lemma 6.0.1's intended body is Delta times the base Okounkov body, with constant base-fiber transform -hhat(c(m)). Translation by torsion makes point-height infimum and essential minimum equal in each twisted abelian base; it need not give exact attainment of every torus-fiber minimum.

The printed arithmetic degree quoted from Chambert–Loir on page 37 is -2 deg(M^g)/g times h_M(q). Dividing this by (g+1)deg(M^g) gives -2/[g(g+1)] h_M(q), not the printed -h_M(q) for general g. This is an exact internal coefficient mismatch; check the controlling original theorem before using either formula. At g=0 the displayed quotient is undefined, so the pure-torus case needs separate treatment.

Theorem C prints unnormalized total height = -(d+1)! integral_Delta hhat(c(m)) dm. Its proof first integrates over the product body, which requires multiplication by vol_R^g(Delta_A(M))=(M^g)/g!. Subsequent lines insert and cancel degree/volume factors without justification, dropping that base volume. The adopted height convention on page 7 and transferred Néron–Tate convention here do not absorb it. A scaling calibration of M versus the polarization-transferred height is now needed. This is a source/math audit diagnosis, not a promoted new result or an independently verified main-theorem counterexample.

Theorem D uses ascending minima: first g+1 equal the absolute minimum, then negative max over faces of dimension t+g+1-i of the minimum hhat on each face. The essential case is the full face; the absolute case is vertices. Restrictions to orbit closures require the appropriate base twist when a face is translated into its quotient character space. The proof continues next page.

No book change, independent verifier receipt or main-theorem clearance.
