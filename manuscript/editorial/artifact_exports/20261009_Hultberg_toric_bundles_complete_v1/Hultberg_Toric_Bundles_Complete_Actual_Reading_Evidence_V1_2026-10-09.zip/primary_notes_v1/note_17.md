# Hultberg arXiv v1 — actual source reading 17

Physical pages 33–34 were read completely in selected text and matching image. No other pages credited.

Corollary 5.2.10 gives degree t+i for the arithmetic polynomial. Section 5.3 uses directions dual to primitive fan rays with support value one, a simplicial compatible fan and place-wise interior points. Derivative comparisons depend on the distinction between integrating a polynomial over a hypograph and integrating its boundary value over the base.

Proposition 5.3.2 literally gives a (t+1)-st derivative of hat I_f as f evaluated at a roof vertex. For t=0, hat I_f(h)=f(h), whose derivative is f'(h), not f(h). The statement appears to confuse the hypograph-volume integral with the boundary-value functional. Corollary 5.3.3 does differentiate f in the roof variable, consistent with the preceding fundamental-theorem-of-calculus decomposition. Preserve this literal symbol/derivative diagnostic, not a claim that the later comparison is thereby false.

Lemma 5.3.1 prints multiplication by the determinant of primitive ray generators. For support-value coordinates, a nonunimodular cone usually gives the inverse determinant Jacobian; an exact rank-two cone calibration is needed before importing the simplicial generalization. The earlier smooth-fan context has determinant one and would not see this discrepancy. Place weights must also persist in derivatives of a weighted global roof.

Corollary 5.3.3 uses [infinity]^2=0 and gives i c(A)^(i-1)[infinity] gamma times the asserted determinant factor. Lemma 5.4.1 proposes the matching arithmetic derivative times (t+i)!/i!. Noncone derivatives vanish using Proposition 3.5.2; the expansion keeps the full multinomial coefficients. Its proof continues on the next page.

No book change, independent verifier receipt or main-theorem clearance.
