# Hultberg arXiv v1 — actual source reading 10

Physical pages 19–20 were read completely in selected text and matching image. No other pages credited.

Example 3.2.6 confirms that general degenerate equivariant maps need not factor through a single fixed orbit closure, because orbit type can vary with the base point. The paper then deliberately defines toric-bundle morphisms as the narrower class that does factor as a nondegenerate map followed by an orbit embedding. Preserve that restriction in functoriality. Multiplication [n] on a semiabelian variety extends to fixed-fan compactifications via multiplication on cocharacters and [n] on the abelian base, with the rigidification retained. This does not identify the toric eigenweight n with the abelian polarization eigenweight n squared.

Section 3.3 uses T-linearized sheaves and their descent to the contracted product. A genuine linearization includes the cocycle/unit compatibility in addition to the displayed isomorphism. Proposition 3.3.2 constructs the descent functor locally with tensor-compatible trivializing sections and glues via that linearization. Equivariantly different divisor representatives that are ordinarily linearly equivalent can descend to inequivalent base twists; this is essential for c(m).

The metric descent is to use the unit-norm part of the torsor, with linearization isometric over the unit torus; naive quotients by all torus points would change metrics. Adelic vector bundles must also come from a model over a dense open of the global base. Canonical outside finitely many places and coherent metric descent remain necessary hypotheses.

No book integration, independent verifier receipt or main-theorem clearance.
