# Hultberg arXiv v1 — actual source reading 09

Physical pages 17–18 were read completely in selected text and the matching image. No other pages credited.

Metrized torsor morphisms are explicitly norm-one. Tensor-power maps and base pullbacks include their coherent identifications. The Weil–Barsotti discussion requires image in Pic^0 and a rigidification at the origin to recover the group law; an arbitrary torus torsor over an abelian base is not a semiabelian variety.

Definition 3.1.9 uses f*T ≅ T^r with r>1 for dynamical metrics. The assertion that its metrized isomorphism class does not depend on the chosen isomorphism needs an allowed coefficient/base-extension convention: rescaling an isomorphism changes the canonical metric by a (r-1)-st root of that scale, which need not be realized by a ground-field isomorphism. Fixed rigidifications or extension/coefficient changes can remove this issue, but are not implicit in an actual norm-one isomorphism over the ground field. No formal counterclaim is promoted here.

Toric bundles are Zariski-locally products with a fixed fan and arise by contracted products. Ordinary noncanonical DVR toric models need a broader relative construction. Orbit closures use the quotient torus with character lattice M intersect sigma-perpendicular; this supports keeping active quotient characters separate from arbitrary ambient characters.

Proposition 3.2.5's fan criterion classifies nondegenerate equivariant maps extending torsor maps. Its no-map clause must stay in that nondegenerate context, since boundary-constant maps can be equivariant. The printed proof self-cites Proposition 3.2.5; the preceding torsor classification is Proposition 3.1.5. This is a source locator defect rather than proof clearance or a claim that the standard fan-extension theorem fails.

No book integration, independent verifier receipt or main-theorem clearance.
