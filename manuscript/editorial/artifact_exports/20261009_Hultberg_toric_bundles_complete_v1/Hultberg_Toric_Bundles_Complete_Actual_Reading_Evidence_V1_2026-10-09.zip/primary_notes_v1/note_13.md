# Hultberg arXiv v1 — actual source reading 13

Physical pages 25–26 were read completely in selected text and matching image. No other pages credited.

Proposition 3.5.1's continuation identifies the archimedean intersection with its current integral. Rational model metrics are handled via torsor tensor powers. Proposition 3.5.2 then approximates each basis character metric as a difference of semipositive algebraic limits and extends coherently to the lattice. A common positive base twist controls all factors; a piecewise linear Green function's Lipschitz constant bounds metric changes by the tropical translation norm. This supplies genuine uniform convergence, rather than weak convergence alone. Its imported current/support and intersection-continuity inputs remain to be checked.

Section 3.6 explicitly takes Zariski closures of height-sublevel sets. Lemma 3.6.1 proves invariance of the closure under the full torus by first using torsion translations, whose tropicalizations vanish at all places, then their Zariski density. It does not say individual point heights are invariant under arbitrary torus translations.

The claim that Noetherianity forces an increasing height filtration of closed sets to have only finitely many stages is not justified: Noetherianity gives the descending chain condition on closed sets, not the ascending condition. For toric fibers there are finitely many orbit types, but that is a different input and does not settle arbitrary bases.

Fiber roof functions are theta(m)+h_T(m)(b), with weighted global sums and coherent trivialization norms. h_Delta(b) is their maximum, identifying the infimum of heights in the dense fiber torus in the usual toric setting. Exact sublevels at a minimum require attainment; a maximum roof value does not by itself produce a point of exactly that height. Keep epsilon-approximation and endpoint attainment separate in the forthcoming filtration/minimum argument, particularly in view of the separately unverified BGPS converse candidate.

No book change, independent verifier receipt or main-theorem clearance.
