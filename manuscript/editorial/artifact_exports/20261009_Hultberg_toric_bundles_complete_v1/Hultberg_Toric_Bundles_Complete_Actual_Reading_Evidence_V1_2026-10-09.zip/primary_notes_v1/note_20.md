# Hultberg arXiv v1 — actual source reading 20

Physical pages 39–40 were read completely in selected text and matching image. No other pages credited. Theorem D and the source's mathematical body are now completely read; two reference pages remain.

The face restriction finishes by translating a face F by m_sigma and retaining the base twist c(m_sigma). Thus it does not discard the character-induced base contribution. For the anticanonical projective-space compactification, Delta=(t+1)standard-simplex minus the sum of basis vectors has barycentric vertex sum zero. Lemma 6.0.2 recovers an absolute-minimum vertex formula and points to Chambert–Loir Lemma 4.5, whose controlling primary text still needs inspection.

Lemma 6.0.3 prints height = -(d+1)deg(M)/[(t+1)(t+2)] times the sum of vertex Néron–Tate heights. M has continued to denote the base ample bundle, whereas converting the simplex integral to an unnormalized total height would involve the degree of the total bundle, including toric volume and the binomial/base dimension factors. In the exact formal calibration t=g=1, base degree one, Delta=[-1,1], and hhat(c(m))=H m^2, its displayed formula gives -H, while its own Theorem C gives -6*(2H/3)=-4H. This already tests an internal mismatch without invoking an uninspected external intersection theorem. Preserve the formulas and check them in an executable calibration; do not promote a new theorem from this diagnosis.

The homogeneous-polynomial simplex integration identity keeps volume divided by binomial(t+r,r), and for r=2 with vertex sum zero it reduces to volume/[(t+1)(t+2)] times the sum of diagonal values. That identity supplies a direct coefficient check; an external Lasserre–Avrachenkov reference is cited.

The reference list pins Ballaÿ 2021, Ballaÿ's March 2022 arithmetic Okounkov preprint, 2024 Ballaÿ–Sombra preprint, Boucksom–Chen 2011, arithmetic toric positivity 2016, Astérisque 360, successive minima 2015, and Chambert–Loir Ann. ENS 33(2000),789–821, DOI 10.1016/S0012-9593(00)01053-3. These bibliographic entries are reading anchors, not recursive proof clearance.

No book change, independent verifier receipt or main-theorem clearance.
