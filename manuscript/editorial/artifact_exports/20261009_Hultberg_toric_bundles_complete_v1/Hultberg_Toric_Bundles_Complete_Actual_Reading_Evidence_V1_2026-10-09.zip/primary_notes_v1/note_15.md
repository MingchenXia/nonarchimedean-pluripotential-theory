# Hultberg arXiv v1 — actual source reading 15

Physical pages 29–30 were read completely in selected text and matching image. No other pages credited.

Theorem A's absolute-minimum proof uses nefness of every underlying base twist plus one big twist: convex combinations show interior twists are big. It still relies on the earlier general absolute-minimum/concave-transform assertion and upper-semicontinuity passage; these imports/signs are not independently cleared by this argument. No explicit lower-dimensional-polytope repair appears on these pages.

Theorem B is restated with relative toric dimension t, smooth generic fiber, smooth projective base of dimension g, integrable adelic torsor, operational gamma of codimension g+1-i on a flat projective base model, and a height-one trivial class [infinity]. Its exact coefficient is i! on the bundle intersection and (t+i)! on the integral of (c(m)+theta(m)[infinity])^i gamma. Keep lattice-normalized Lebesgue measure, weights, and the arithmetic base dimension g+1. A height-one trivial adelic class must still be model-canonical outside finitely many places, not a nonzero metric shift at infinitely many places.

Remark 5.0.1 permits extra integrable Chern factors by approximation, homological classes on a model when the torsor is modeled there, and suitably positive/integrable b-cycles in the general setting. It does not authorize all inverse-limit cycles without continuity control.

The proof overview compares homogeneous polynomial derivatives, inducting on i plus derivative multiplicity. The i=0 case is geometric BKK times the arithmetic degree of gamma, treating closed-point and archimedean-measure components separately via projection/Fubini. Subsequent derivative comparisons must preserve this normalization; the overview alone is not a completed proof.

No book change, independent verifier receipt or main-theorem clearance.
