# Hultberg arXiv v1 — actual source reading 21

Physical pages 41–42 were read completely in selected text and matching image. All 42 physical pages of this exact arXiv v1 are now actually read in 21 matched complete-text/image displays. Prepared but undisplayed material receives no additional credit, and this completion does not recursively clear cited sources.

The remaining bibliography pins Chambert–Loir–Tschinkel arithmetic torsors (2001), Chen–Moriwaki extension (2018), Cox–Little–Schenck, Demailly, Fulger–Lehmann dual-cycle cones (2017), Fulton toric varieties and intersection theory, Gillet–Soulé arithmetic Riemann–Roch (1992), Hofscheier–Khovanskii–Monin arXiv 2006.12043, Knop–Lange (1984), and Lasserre–Avrachenkov (2001). Subsequent entries anchor Lazarsfeld–Mustata 2009, Moriwaki adelic/semipositive works, Pukhlikov–Khovanskii 1992, Qu–Yin arXiv 2208.13230, Soulé's arithmetic intersection chapter, Witt Nyström's metric transform and Zhang's two foundational arithmetic positivity/small-point papers. Edition/version-sensitive numbers must be checked in those controlling sources before integration.

The primary next dependency is Chambert–Loir's published 2000 paper, for the actual arithmetic degree normalization in Theorem 2.5 and the compactification height formula. Exact internal calibrations of Hultberg's tensor scaling, derivative factorial and product-body volume will be preserved separately. The intended Theorems A–D remain unverified for book import; the standard special-case facts and classical identities are distinguished from literal printed auxiliary defects.

No book change, new theorem, independent verifier receipt or canonical problem-status change is claimed.
