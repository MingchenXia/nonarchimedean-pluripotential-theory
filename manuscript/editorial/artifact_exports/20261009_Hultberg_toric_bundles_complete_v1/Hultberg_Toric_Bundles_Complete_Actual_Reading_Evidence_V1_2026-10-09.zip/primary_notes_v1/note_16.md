# Hultberg arXiv v1 — actual source reading 16

Physical pages 31–32 were read completely in selected text and matching image. No other pages credited.

Section 5.2 uses the Pukhlikov–Khovanskii convex-chain algebra, finite additive valuations, translation differences, degree-zero ideal and polynomial measures. Its convolution is the convex-chain/Euler-characteristic convolution from that framework, not ordinary Lebesgue convolution of indicator functions. The imported ideal relation gives polynomial degree at most ambient dimension plus translation degree; continuity on finite-dimensional subspaces excludes discontinuous polynomial pathologies.

Theorem 5.2.8 extends integrals of homogeneous polynomial functions to virtual polytopes with degree t+k. The arithmetic construction has finitely many active place coordinates and pushes their roofs to one global coordinate. This pushforward must use the local weights n_v when the global roof is sum n_v theta_v; a plain unweighted addition is only the equal-weight convention.

Theorem 5.2.9 reduces integral f(m,theta(m)) to integral f(m,0) over the underlying polytope plus integral partial_t f over the nonnegative roof hypograph. The latter has ambient dimension t+1 and polynomial degree k-1, yielding t+k. This elementary degree accounting is correct in the polyhedral/virtual framework, with a constant f handled separately when k=0. Extending from actual polytopes to arbitrary continuous concave roofs still requires the completion/continuity convention flagged earlier; no such source import has been independently checked here.

No book change, independent verifier receipt or main-theorem clearance.
