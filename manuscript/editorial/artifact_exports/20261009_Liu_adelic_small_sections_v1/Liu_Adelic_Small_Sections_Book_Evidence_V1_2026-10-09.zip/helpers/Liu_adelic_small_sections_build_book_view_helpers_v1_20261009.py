from pathlib import Path
s=Path('/tmp/GVF_Foundations_prepare_book_views_v1_20261009.py').read_text()
changes={
'source_material/GVF_Foundations_representation_book_integration_20261009':'source_material/Liu_adelic_small_sections_book_integration_20261009',
"S=Path('/workspace/book-completion-drafts/GVF-Foundations-representation-staging-v1-20261009')":"S=Path('/workspace/book-completion-drafts/Liu-adelic-small-sections-staging-v1-20261009')",
"B=Path('/workspace/book-completion-drafts/Luo-Yu-small-points-staging-v1-20261009')":"B=Path('/workspace/book-completion-drafts/GVF-Foundations-representation-staging-v1-20261009')",
'/tmp/GVF_Foundations_representation_staged_book_views_v1_20261009':'/tmp/Liu_adelic_small_sections_staged_book_views_v1_20261009',
'len(ob)==606 and len(nb)==607':'len(ob)==607 and len(nb)==608',
'BDHS26GVFFoundationsV2':'Liu26AdelicFujitaV4',
'heading=\'Representing a height by places.\'':'heading=\'Global positivity and simultaneous small sections.\'',
'Globally valued field representations and symmetry.':'Arithmetic positivity and simultaneous small sections.',
'GVF FOUNDATIONS REPRESENTATION STAGED BOOK V1':'LIU ADELIC SMALL SECTIONS STAGED BOOK V1',
'GVF foundations representation staged v1':'Liu adelic small sections staged v1'
}
for a,b in changes.items():assert a in s,a;s=s.replace(a,b)
p=Path('/tmp/Liu_adelic_small_sections_prepare_book_views_v1_20261009.py');assert not p.exists();p.write_text(s)
s=Path('/tmp/GVF_Foundations_underfull_delta_v1_20261009.py').read_text().replace('source_material/GVF_Foundations_representation_book_integration_20261009','source_material/Liu_adelic_small_sections_book_integration_20261009').replace('/workspace/book-completion-drafts/Luo-Yu-small-points-staging-v1-20261009/manuscript/book.log','/workspace/book-completion-drafts/GVF-Foundations-representation-staging-v1-20261009/manuscript/book.log')
p=Path('/tmp/Liu_adelic_small_sections_underfull_delta_v1_20261009.py');assert not p.exists();p.write_text(s)
s=Path('/tmp/GVF_Foundations_record_book_note_v1_20261009.py').read_text().replace('source_material/GVF_Foundations_representation_book_integration_20261009','source_material/Liu_adelic_small_sections_book_integration_20261009')
p=Path('/tmp/Liu_adelic_small_sections_record_book_note_v1_20261009.py');assert not p.exists();p.write_text(s)
