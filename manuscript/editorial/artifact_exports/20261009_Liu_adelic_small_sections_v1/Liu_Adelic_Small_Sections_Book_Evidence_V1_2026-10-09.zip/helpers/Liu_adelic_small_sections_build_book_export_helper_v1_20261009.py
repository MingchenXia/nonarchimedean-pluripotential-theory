from pathlib import Path
s=Path('/tmp/Luo_Yu_export_book_v1_20261009.py').read_text()
repls={
'source_material/Luo_Yu_small_points_book_integration_20261009':'source_material/Liu_adelic_small_sections_book_integration_20261009',
'source_material/Hultberg_GVF_dependency_review_20261009/LuoYu25ArxivV3':'source_material/Arithmetic_Fujita_adelic_curves_review_20261009/LiuArxivV4',
'/workspace/book-completion-drafts/Luo-Yu-small-points-staging-v1-20261009':'/workspace/book-completion-drafts/Liu-adelic-small-sections-staging-v1-20261009',
'/workspace/book-completion-drafts/Luo-Yu-small-points-integration-v1-20261009':'/workspace/book-completion-drafts/Liu-adelic-small-sections-integration-v1-20261009',
'/tmp/Luo_Yu_small_points_staged_book_views_v1_20261009':'/tmp/Liu_adelic_small_sections_staged_book_views_v1_20261009',
'Luo_Yu_small_points_staged_integration':'Liu_adelic_small_sections_staged_integration',
'Non-Archimedean_Pluripotential_Theory_Small_Points_V1':'Non-Archimedean_Pluripotential_Theory_Adelic_Small_Sections_V1',
'Luo_Yu_Small_Points_Actual_Book_Review':'Liu_Adelic_Small_Sections_Actual_Book_Review',
'Luo_Yu_Small_Points_Minimal_Source':'Liu_Adelic_Small_Sections_Minimal_Source',
'Luo_Yu_Small_Points_Book_Evidence':'Liu_Adelic_Small_Sections_Book_Evidence',
'20261009_Luo_Yu_small_points_v1':'20261009_Liu_adelic_small_sections_v1',
'4681':'4685','4,681':'4,685','4430':'4434',
"assert q.suffix=='.tex'":"assert q.suffix in ['.tex','.bib']",
'Luo_Yu_*_book_*_20261009.py':'Liu_adelic_small_sections_*_book_*_20261009.py',
'Luo_Yu_underfull_delta_*_20261009.py':'Liu_adelic_small_sections_underfull_delta_*_20261009.py',
'Luo_Yu_Complete_Source_Evidence_V1_2026-10-09.zip':'Liu_Adelic_Fujita_Complete_Source_Evidence_V1_2026-10-09.zip',
'88009956d0c0512c70823485f821dc085871247afd14776ae2921778f5ad2016':'c380b81ea0960cab78d2648ff5523f245d7e6556b95c53bcb4dbdf4eaeaf09a1',
'own_rank_two_curve_height_reconstruction_v1_20261009.md':'own_three_place_model_reconstruction_v1_20261009.md',
'Small points without zero-height points — actual book review':'Global positivity and simultaneous small sections — actual book review',
'# Small-points book integration, 9 October 2026':'# Three-place metric book integration, 9 October 2026',
'# Actual final small-points book reading':'# Actual final three-place model book reading',
'# Small-points book artifacts':'# Three-place metric book artifacts',
'final small-points book/evidence export':'final three-place metric book/evidence export'
}
for a,b in repls.items():assert a in s,a;s=s.replace(a,b)
a=s.index('summary=');b=s.index("markdown(paths['audit']",a)
summary=Path('/tmp/Liu_adelic_small_sections_book_integration_summary_v1_20261009.md').read_text()
s=s[:a]+'summary='+repr(summary)+'\n'+s[b:]
a=s.index("intro='**Current checked small-points edition:");b=s.index('with zipfile.ZipFile(prep[',a)
intro='''**Current checked three-place metric edition: 4,685 pages, 9 October 2026.**
The [integration audit](manuscript/editorial/Liu_adelic_small_sections_staged_integration_audit_v1_20261009.md)
adds a canonical projective metric model over three trivial places.
Field height zero and line-bundle height1/4 are explicit. Positive arithmetic
volume1/2 coexists with no all-places small positive-power section; nontrivial
ample/small-residual approximants have normalized error1/(2p). Appendix L
pins the fully read27-page v4 source and its main-proof reconstruction boundary.
All thirteen selected final pages were actually read in seven fresh matching
views. The [artifacts](manuscript/editorial/artifact_exports/20261009_Liu_adelic_small_sections_v1/README.md)
contain the full book, actual review, minimal source and authored evidence.
Required checks pass; all prior numbered values, contents and index terms
remain, with608 cited entries. The last ordered whole-book read remains
4October. Canonical statuses and original candidates remain unchanged.
Continue cloud-only, Xean suspended. Earlier checkpoints retain dated scopes.

'''
prog='''## Current checked three-place metric edition: 4,685 pages, 9 October 2026

The [integration audit](Liu_adelic_small_sections_staged_integration_audit_v1_20261009.md)
adds the direct canonical-metric model. Q's three trivial places give field
height0, while O(1) shifts total1/4 and give line-bundle height1/4 and volume1/2.
No positive-power section is small at every place, but explicit nontrivial
ample factors with a small residual give normalized volume error1/(2p).
The transition returns to the usual number-field adelic structure.
The general Fujita main theorem remains UNVERIFIED FOR BOOK IMPORT.

All27 primary pages and thirteen selected final book pages were actually
read with matching complete text/images. Page4434 now contains provenance;
no selected page is blank. All607 prior cited labels remain, giving608
entries; all13,382 numbered values,2,766 contents entries and900 index terms
are preserved. Required validation and six existing tests pass; all955
underfull blocks have identical normalized contents/multiplicities.
Other423 core TeX inputs and the complex bibliography are unchanged.
See the [artifacts](artifact_exports/20261009_Liu_adelic_small_sections_v1/README.md).

The last ordered whole-book reading remains4October. Canonical42 atoms,
twelve problems and tiers(0,3,7,15,17) remain unchanged. BJ22 general
homogeneous Siu/envelopes stay OPEN, LPWZ density UNVERIFIED. The latest
incoming-research metadata still has the actually audited309 head and
adds no proof credit. Original candidates remain UNVERIFIED, with no
new production receipt. Native catalogue/editor and historical PDF are
preserved; native compilation is unverified. Cloud-only, Xean suspended.
Earlier checkpoints below remain frozen dated evidence.

'''
block="intro="+repr(intro)+"\np=S/'README.md';s=p.read_text();first=s.index('\\n');markdown(p,s[:first+1]+'\\n'+intro+s[first+1:])\nintro="+repr(prog)+"\np=S/programme;s=p.read_text();first=s.index('\\n');markdown(p,s[:first+1]+'\\n'+intro+s[first+1:])\n"
s=s[:a]+block+s[b:]
x="files={f'records/{q.name}':q for q in C.glob('*.json')}";assert s.count(x)==1
s=s.replace(x,x+"\nfiles['actual/own_book_reading_note_precision_addendum_v1_20261009.md']=C/'own_book_reading_note_precision_addendum_v1_20261009.md'\nfiles['editorial/Liu_adelic_small_sections_book_integration_summary_v1_20261009.md']=Path('/tmp/Liu_adelic_small_sections_book_integration_summary_v1_20261009.md')")
x="markdown(paths['reading_notes'],'# Actual final three-place model book reading\\n\\nThirteen selected final pages in seven fresh displays; page 4434 contains provenance, not a blank.\\n'+''.join('\\n---\\n\\n'+x for x in notes))";assert s.count(x)==1
s=s.replace(x,x+"\nmarkdown(paths['reading_notes'],paths['reading_notes'].read_text()+'\\n\\n---\\n\\n'+(C/'own_book_reading_note_precision_addendum_v1_20261009.md').read_text())")
p=Path('/tmp/Liu_adelic_small_sections_export_book_v1_20261009.py');assert not p.exists();p.write_text(s)
