from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R / 'source_material/Liu_adelic_small_sections_book_integration_20261009'
K = R / 'source_material/Arithmetic_Fujita_adelic_curves_review_20261009/LiuArxivV4'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda n: json.loads((C / n).read_text())
prep = load('book_staging_preparation_v1_20261009.json')
release = load('book_release_checks_v1_20261009.json')
validation = load('book_validation_v1_20261009.json')
under = load('book_underfull_delta_v1_20261009.json')
manifest = json.loads(Path(release['manifest_path']).read_text())
assert validation['returncode'] == 0
assert under['all_normalized_blocks_and_multiplicities_identical']
assert sha(release['PDF']['path']) == release['PDF']['SHA256']
receipts = []
for n, item in enumerate(manifest, 1):
    p = C / f'book_notes_v1/note_{n:02d}_receipt.json'
    note = C / f'book_notes_v1/note_{n:02d}.md'
    x = json.loads(p.read_text())
    assert x['number'] == n and x['physical_pages'] == item['physical_pages']
    assert x['complete_selected_text_actually_read'] and x['matching_image_individually_displayed_and_reviewed']
    assert x['source_PDF_SHA256'] == release['PDF']['SHA256']
    assert sha(note) == x['note_SHA256']
    assert sha(item['path']) == x['image_SHA256']
    assert sha(item['selected_text_path']) == x['selected_text_SHA256']
    assert x['previous_receipt_SHA256'] == (receipts[-1]['receipt_SHA256'] if n > 1 else None)
    receipts.append(dict(number=n, physical_pages=x['physical_pages'], note_SHA256=sha(note), receipt_SHA256=sha(p)))
pages = [p for x in receipts for p in x['physical_pages']]
assert pages == release['selected_book_physical_pages'] and len(set(pages)) == 13 and len(receipts) == 7
assert sha(K / 'actual_complete_source_checkpoint_v1_20261009.json') == prep['source_checkpoint_SHA256']
assert sha(K / 'literal_exact_calibrations_v1_20261009.json') == prep['normalization_calibration_SHA256']
source = json.loads((K / 'actual_complete_source_checkpoint_v1_20261009.json').read_text())
assert sha(K / 'own_three_place_model_reconstruction_v1_20261009.md') == prep['classical_model_reconstruction_SHA256']
assert sha(R / 'manuscript/editorial/Liu_adelic_Fujita_complete_source_GitHub_publication_v1_20261009.json') == prep['source_publication_SHA256']
assert source['physical_pages_read'] == list(range(1, 28)) and source['full_source_read']
reading = dict(
    UTC=datetime.now(timezone.utc).isoformat(), status='DONE — actual scoped final V1 book reading',
    PDF=release['PDF'], actual_book_physical_pages=pages, actual_unique_book_pages=13,
    fresh_matching_views=7, reused_matching_views=0, receipts=receipts,
    explicitly_reviewed_blank_versos=[],
    blank_justification='No selected page is blank; page 4434 now contains the continuation of the new Liu provenance.',
    remaining_repairs=[], actual_primary_source_reading_credit=0,
    note_precision_addendum_SHA256=sha(C/'own_book_reading_note_precision_addendum_v1_20261009.md'),
    whole_book_new_reading_claim=False, whole_chapter_reading_claim=False,
    index_actual_pages=[4643, 4654], middle_index_pages_mechanical_only=True,
    release_checks_SHA256=sha(C / 'book_release_checks_v1_20261009.json'),
    validation_SHA256=sha(C / 'book_validation_v1_20261009.json'),
    underfull_comparison_SHA256=sha(C / 'book_underfull_delta_v1_20261009.json'),
    active_book_changed=False, canonical_status_changes=[], original_results_promoted=[],
    helper_source=__file__, helper_SHA256=sha(__file__))
p = C / 'actual_book_reading_v1_20261009.json'
assert not p.exists()
p.write_text(json.dumps(reading, ensure_ascii=False, indent=2) + '\n')
checks = ['Controlling source arXiv:2401.15271v4,25 January2026 has all 27 physical pages actually read in fourteen matching views; internal footer27January remains separate.', 'This is a direct classical canonical quotient/constant-shift model, using the norm data of Example4.4 p18 but excluding its nonexistence inference and the general main Fujita proof.', 'F=Q has THREE unit-weight copies of the trivial absolute value; sigma-algebra discrete, field perfect/countable, each nonzero scalar has norm1 and the product formula is zero.', 'The field coordinate height h_F is zero. The O(1) metric is separately shifted by constants (1/2,1/2,-3/4), total C=1/4. Its ordinary closed-point height is C, not the unchanged coordinate height.', 'Every nonzero section has canonical sup norm1, with the Gauss point giving the lower bound. Its shifted norms are exp(-n c_i); the third exp(3n/4)>1 excludes all-places small sections in every positive power.', 'Finite extensions of a trivial absolute value are trivial; the ordinary point-height assertion and arithmetic intersection use the correct point-degree normalization.', 'Rank H0(O(n))=n+1. All HN slopes are nC, positive degree n(n+1)C, and probability moment nC needs the rank factor.', 'Arithmetic volume divides positive degree by n^2/2 and is 2C=1/2. No signed chi-volume or squared-norm convention is substituted.', 'Canonical quotient metrics with constant shifts stay semipositive. For O(m),m>0,total B>0, every closed point has height B and arithmetic self-intersection is 2mB; a positive epsilon<B verifies ampleness on every integral closed subscheme.', 'For p>=2,A_p has O(p-1) with shifts p c_i,M_p has O(1) with zero shifts. Tensor data add exactly to L^p. The residual x0 has sup norm1 at every place.', 'A_p is arithmetically ample and its volume is 2(p-1)pC=p(p-1)/2; normalized p^(-2) volume=1/2-1/(2p). Both factors have positive underlying degrees.', 'The source argument that arithmetic ampleness forces every section norm<=1 at every place is excluded. Global positive slopes/intersections differ from simultaneous placewise smallness.', 'The general main theorem retains proper/perfect and common countable-density/discrete hypotheses and remains UNVERIFIED FOR BOOK IMPORT pending exact original/spectral norm, analytic-point and Veronese reconstruction.', 'The following paragraph returns explicitly to the USUAL number-field adelic structure. Ballaÿ--Sombra Question6.21 and logarithmic Remark7.16 stay open at their respective scopes.', 'The book import is an explanatory worked special case/direct formal calculation with ordinary source and mathematical audits under the repository protocol, not a new mathematical result or production receipt.', 'No original result, homogeneous Siu repair, LPWZ density theorem, canonical problem atom or closure is promoted.']
math = dict(
    UTC=datetime.now(timezone.utc).isoformat(),
    status='PASS — ordinary primary-source and mathematical audit of a direct classical three-place metric example',
    actual_final_book_reading_SHA256=sha(p), current_source_hashes=prep['after'],
    source_checkpoint_SHA256=prep['source_checkpoint_SHA256'], source_publication_SHA256=prep['source_publication_SHA256'], classical_model_reconstruction_SHA256=prep['classical_model_reconstruction_SHA256'],
    normalization_calibration_SHA256=prep['normalization_calibration_SHA256'],
    signature='F=Q; three unit-weight trivial places; P1, canonical quotient metrics shifted by (1/2,1/2,-3/4), total1/4; ordinary norms, rank(n+1), arithmetic factorial2, explicit A_p/M_p,p>=2.',
    scope_checks=checks, deeper_imports_recursively_verified=False, production_VERIFIED=False,
    independent_verifier_receipt=False, original_result_promoted=False,
    canonical_status_changes=[], native_editor_changed=False, native_compile_success_verified=False,
    helper_source=__file__, helper_SHA256=sha(__file__))
q = C / 'book_mathematical_self_audit_v1_20261009.json'
assert not q.exists()
q.write_text(json.dumps(math, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(reading_SHA256=sha(p), mathematical_audit_SHA256=sha(q), actual_pages=13, fresh_views=7)))
