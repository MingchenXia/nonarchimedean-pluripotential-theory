from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile, shutil, fitz

R=Path('/workspace/nonarchimedean-pluripotential-theory'); E=R/'manuscript/editorial'
C=R/'source_material/Liu_adelic_small_sections_book_integration_20261009'
K=R/'source_material/Arithmetic_Fujita_adelic_curves_review_20261009/LiuArxivV4'
S=Path('/workspace/book-completion-drafts/Liu-adelic-small-sections-staging-v1-20261009')
D=Path('/workspace/book-completion-drafts/Liu-adelic-small-sections-integration-v1-20261009')
W=Path('/tmp/Liu_adelic_small_sections_staged_book_views_v1_20261009')
O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
def write(p,a):
    assert not p.exists()
    p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
def markdown(p,s):
    p.write_text(s.rstrip()+'\n')
prep=load('book_staging_preparation_v1_20261009.json'); release=load('book_release_checks_v1_20261009.json')
reading=load('actual_book_reading_v1_20261009.json'); math=load('book_mathematical_self_audit_v1_20261009.json')
validation=load('book_validation_v1_20261009.json'); under=load('book_underfull_delta_v1_20261009.json')
assert validation['returncode']==0 and under['all_normalized_blocks_and_multiplicities_identical']
assert reading['actual_unique_book_pages']==13 and reading['fresh_matching_views']==7 and reading['reused_matching_views']==0
assert not reading['remaining_repairs'] and reading['explicitly_reviewed_blank_versos']==[]
assert release['PDF']['physical_pages']==4685 and release['PDF']['SHA256']==reading['PDF']['SHA256']
assert math['actual_final_book_reading_SHA256']==sha(C/'actual_book_reading_v1_20261009.json')
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['before'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
paths={k:E/f'Liu_adelic_small_sections_staged_integration_{k}_v1_20261009.{ext}' for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
full=O/'Non-Archimedean_Pluripotential_Theory_Adelic_Small_Sections_V1_2026-10-09.pdf'
review=O/'Liu_Adelic_Small_Sections_Actual_Book_Review_V1_2026-10-09.pdf'
minimal=O/'Liu_Adelic_Small_Sections_Minimal_Source_V1_2026-10-09.zip'
evidence=O/'Liu_Adelic_Small_Sections_Book_Evidence_V1_2026-10-09.zip'
dest=E/'artifact_exports/20261009_Liu_adelic_small_sections_v1'; record=C/'book_export_v1_20261009.json'
assert not any(p.exists() for p in [*paths.values(),full,review,minimal,evidence,dest,record])
shutil.copyfile(release['PDF']['path'],full); assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as source:
    doc=fitz.open()
    for n in reading['actual_book_physical_pages']:doc.insert_pdf(source,from_page=n-1,to_page=n-1)
    assert len(doc)==13
    doc.set_metadata(dict(title='Global positivity and simultaneous small sections — actual book review',subject='Thirteen final physical pages actually read in seven fresh displays. Page 4434 contains the provenance continuation. Export grants no reading credit.'))
    doc.save(review,garbage=4,deflate=True); doc.close()
summary="The checked 4,685-page edition adds a direct three-place constant-metric\nmodel to Chapter 27 and exact-source provenance to Appendix L. Over\nQ with three unit-weight trivial absolute values, the field coordinate\nheight is zero. Canonical O(1) metrics shifted by (1/2,1/2,-3/4) instead\ngive the line-bundle height C=1/4. Every positive-power section has third\nsup norm exp(3n/4)>1, so none is small at all places simultaneously. Yet\nthe positive degree is n(n+1)C, the arithmetic volume is 1/2, and the\nbundle is arithmetically ample in the stated global intersection sense.\nFor p>=2, O(p-1) with shifts p c_i and canonical O(1) give nontrivial\nample/small-residual factors. Their normalized ample-volume error is\n1/(2p). All metric data are explicit. The following paragraph returns\nto the USUAL number-field adelic structure for Ballaÿ–Sombra's questions.\n\nThis is an explanatory imported norm model and direct classical formal\ncalculation under the repository's ordinary mathematical/source audits,\nnot a new result requiring promotion. It uses canonical projective\nquotient metrics, determinant degrees, degree-normalized point heights,\nconstant-shift intersections and elementary section growth. It excludes\nthe printed nonexistence inference of Liu Example 4.4 and the general\nmain Fujita proof. The general statement remains UNVERIFIED FOR BOOK\nIMPORT pending original/spectral norm, analytic-point, Veronese degree\nand approximation reconstruction; its intended conclusion is not refuted.\n\nAll 27 physical pages of arXiv:2401.15271v4,25 January2026 were actually\nread in fourteen ordered complete-text/image views before import. The\n27January footer stays separate. Its 43-member authored source evidence\nand separately published source record are pinned. Exact rank/factorial,\nsymbolic limit, Veronese and nontrivial decomposition checks support the\nmodel without certifying a general theorem. Failed/corrected helpers and\nprecision addenda remain frozen. Other versions and later journal full\ntext have not been read or diagnosed.\n\nThirteen selected final book pages were actually read in seven fresh\nmatching displays: contents, preceding GVF/new model and usual-number-\nfield transition, complete provenance, Appendix M opening, index boundaries\nand Liu26Fujita bibliography. Physical page4434 now contains provenance;\nit is not a blank page. The index span4643–4654 is twelve pages inclusive,\nwith ten intervening pages mechanically checked only; a fresh addendum\ncorrects the earlier note's span phrase. This is a scoped final-page\nreview, not an entire index/chapter/book reread. The last ordered whole-\nbook reading remains4October. Export/upload adds no reading credit.\n\nRequired manuscript validation and six existing reference-check tests\npass. There are zero errors, missing glyphs, overfull boxes, unresolved\nreferences/citations, package/pdfTeX warnings or rerun requests. All955\ninherited underfull blocks retain normalized contents/multiplicities.\nAll13,382 numbered values,607 prior cited keys/labels,2,766 contents\nentries/hierarchy and900 index terms remain; Liu26Fujita gives608 cited\nentries. Every internal destination resolves. Two of425 core TeX inputs\nand the NA bibliography change; other423 inputs and the complex\nbibliography are preserved. No formal environment, semantic label,\nmanual tag or contents title is added. The page count remains4,685.\n\nThe earlier checked GVF representation, Luo–Yu, Guo–Yuan, translated\nabelian, Fubini–Study and Ballaÿ–Sombra integrations remain intact.\nCanonical42 atoms/twelve problems and tiers(0,3,7,15,17) stay unchanged.\nBJ22 general homogeneous Siu/envelopes remain OPEN; LPWZ density\nUNVERIFIED. Incoming continuation309 and generic-line GVF original\ncandidates remain UNVERIFIED. Latest research-branch metadata still\nmatches the pinned309 head; it grants no new proof reading credit.\nCurrent G331 literal body, companions and active298 packets remain\nunread. No supplied program, native external engine or Xean was executed.\nThe native catalogue/editor and historical PDF are preserved; native\ncompilation remains unverified. Work continues cloud-only.\n"
markdown(paths['audit'],'# Three-place metric book integration, 9 October 2026\n\n'+summary+'\nScoped mathematical checks:\n\n'+''.join(f'{i}. {x}\n\n' for i,x in enumerate(math['scope_checks'],1)))
notes=[]
for item in reading['receipts']:
    n=item['number']; note=C/f'book_notes_v1/note_{n:02d}.md'; receipt=C/f'book_notes_v1/note_{n:02d}_receipt.json'
    assert sha(note)==item['note_SHA256'] and sha(receipt)==item['receipt_SHA256']
    notes.append(note.read_text())
markdown(paths['reading_notes'],'# Actual final three-place model book reading\n\nThirteen selected final pages in seven fresh displays; page 4434 contains provenance, not a blank.\n'+''.join('\n---\n\n'+x for x in notes))
markdown(paths['reading_notes'],paths['reading_notes'].read_text()+'\n\n---\n\n'+(C/'own_book_reading_note_precision_addendum_v1_20261009.md').read_text())
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md'
intro='**Current checked three-place metric edition: 4,685 pages, 9 October 2026.**\nThe [integration audit](manuscript/editorial/Liu_adelic_small_sections_staged_integration_audit_v1_20261009.md)\nadds a canonical projective metric model over three trivial places.\nField height zero and line-bundle height1/4 are explicit. Positive arithmetic\nvolume1/2 coexists with no all-places small positive-power section; nontrivial\nample/small-residual approximants have normalized error1/(2p). Appendix L\npins the fully read27-page v4 source and its main-proof reconstruction boundary.\nAll thirteen selected final pages were actually read in seven fresh matching\nviews. The [artifacts](manuscript/editorial/artifact_exports/20261009_Liu_adelic_small_sections_v1/README.md)\ncontain the full book, actual review, minimal source and authored evidence.\nRequired checks pass; all prior numbered values, contents and index terms\nremain, with608 cited entries. The last ordered whole-book read remains\n4October. Canonical statuses and original candidates remain unchanged.\nContinue cloud-only, Xean suspended. Earlier checkpoints retain dated scopes.\n\n'
p=S/'README.md';s=p.read_text();first=s.index('\n');markdown(p,s[:first+1]+'\n'+intro+s[first+1:])
intro="## Current checked three-place metric edition: 4,685 pages, 9 October 2026\n\nThe [integration audit](Liu_adelic_small_sections_staged_integration_audit_v1_20261009.md)\nadds the direct canonical-metric model. Q's three trivial places give field\nheight0, while O(1) shifts total1/4 and give line-bundle height1/4 and volume1/2.\nNo positive-power section is small at every place, but explicit nontrivial\nample factors with a small residual give normalized volume error1/(2p).\nThe transition returns to the usual number-field adelic structure.\nThe general Fujita main theorem remains UNVERIFIED FOR BOOK IMPORT.\n\nAll27 primary pages and thirteen selected final book pages were actually\nread with matching complete text/images. Page4434 now contains provenance;\nno selected page is blank. All607 prior cited labels remain, giving608\nentries; all13,382 numbered values,2,766 contents entries and900 index terms\nare preserved. Required validation and six existing tests pass; all955\nunderfull blocks have identical normalized contents/multiplicities.\nOther423 core TeX inputs and the complex bibliography are unchanged.\nSee the [artifacts](artifact_exports/20261009_Liu_adelic_small_sections_v1/README.md).\n\nThe last ordered whole-book reading remains4October. Canonical42 atoms,\ntwelve problems and tiers(0,3,7,15,17) remain unchanged. BJ22 general\nhomogeneous Siu/envelopes stay OPEN, LPWZ density UNVERIFIED. The latest\nincoming-research metadata still has the actually audited309 head and\nadds no proof credit. Original candidates remain UNVERIFIED, with no\nnew production receipt. Native catalogue/editor and historical PDF are\npreserved; native compilation is unverified. Cloud-only, Xean suspended.\nEarlier checkpoints below remain frozen dated evidence.\n\n"
p=S/programme;s=p.read_text();first=s.index('\n');markdown(p,s[:first+1]+'\n'+intro+s[first+1:])
with zipfile.ZipFile(prep['baseline_minimal_source']['path']) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    members=old.namelist(); assert len(members)==len(set(members))==472
    for n in members:z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
    assert z.testzip() is None
    for n in z.namelist():assert z.read(n)==(S/n).read_bytes()
files={f'records/{q.name}':q for q in C.glob('*.json')}
files['actual/own_book_reading_note_precision_addendum_v1_20261009.md']=C/'own_book_reading_note_precision_addendum_v1_20261009.md'
files['editorial/Liu_adelic_small_sections_book_integration_summary_v1_20261009.md']=Path('/tmp/Liu_adelic_small_sections_book_integration_summary_v1_20261009.md')
for q in C.glob('book_validation_*_20261009.log'):files[f'logs/{q.name}']=q
for n in prep['after']:files['staged_inputs/'+n]=S/n
for q in D.iterdir():
    assert q.suffix in ['.tex','.bib']; files['drafts/'+q.name]=q
for q in (C/'book_compiled_staged_v1').iterdir():
    if q.suffix!='.pdf':files['compiled/'+q.name]=q
for item in reading['receipts']:
    n=item['number']
    for kind,q in [('notes',C/f'book_notes_v1/note_{n:02d}.md'),('receipts',C/f'book_notes_v1/note_{n:02d}_receipt.json'),('images',W/f'sheet_{n:02d}.png'),('text',W/f'sheet_{n:02d}.txt')]:files[f'actual/{kind}/{q.name}']=q
files['actual/prepared_manifest.json']=W/'manifest.json'
for q in Path('/tmp').glob('Liu_adelic_small_sections_*_book_*_20261009.py'):files['helpers/'+q.name]=q
for q in Path('/tmp').glob('Liu_adelic_small_sections_underfull_delta_*_20261009.py'):files['helpers/'+q.name]=q
for q in [paths['audit'],paths['reading_notes'],S/programme,S/'README.md']:files['editorial/'+q.name]=q
sourcezip=K/'Liu_Adelic_Fujita_Complete_Source_Evidence_V1_2026-10-09.zip'
assert sha(sourcezip)=='c380b81ea0960cab78d2648ff5523f245d7e6556b95c53bcb4dbdf4eaeaf09a1'
files['source_owned_records/'+sourcezip.name]=sourcezip
for n in ['actual_complete_source_checkpoint_v1_20261009.json','complete_evidence_export_v1_20261009.json','literal_exact_calibrations_v1_20261009.json','own_complete_source_review_v1_20261009.md','own_three_place_model_reconstruction_v1_20261009.md','GitHub_complete_source_publication_v1_20261009.json']:files['source_owned_records/'+n]=K/n
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(files) and z.testzip() is None
    for n,q in files.items():assert z.read(n)==q.read_bytes()
artifacts={k:dict(path=str(q),bytes=q.stat().st_size,SHA256=sha(q)) for k,q in [('full_book_PDF',full),('selected_review_PDF',review),('minimal_TeX_source_archive',minimal),('actual_book_evidence_archive',evidence)]}
artifacts['full_book_PDF']['physical_pages']=4685; artifacts['selected_review_PDF']['physical_pages']=13
artifacts['minimal_TeX_source_archive']['members']=472; artifacts['actual_book_evidence_archive']['members']=len(files)
progress={n:sha(S/n) for n in ['README.md',programme]}
write(paths['manifest'],dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — scoped source/math/mechanical/actual-render gate',preparation=prep,release=release,validation=validation,actual_reading=reading,mathematical_audit=math,underfull_comparison=under,artifacts=artifacts,active_book_changed=False,GitHub_published=False))
write(paths['artifacts'],dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — all export members byte-verified',artifacts=artifacts,actual_final_book_pages=13,fresh_matching_views=7,explicitly_reviewed_blank_versos=[],reading_credit_from_export=0,GitHub_published=False))
dest.mkdir(parents=True)
for q in [full,review,minimal,evidence]:shutil.copyfile(q,dest/q.name); assert sha(dest/q.name)==sha(q)
(dest/'SHA256SUMS').write_text(''.join(sha(q)+'  '+q.name+'\n' for q in [full,review,minimal,evidence]))
markdown(dest/'README.md','# Three-place metric book artifacts\n\n'+summary+f'\nArtifacts: full 4,685-page PDF, 13-page actual review, 472-member minimal\nsource and {len(files)}-member byte-verified authored book evidence. The nested\n43-member source evidence excludes primary PDFs, literal source text and\nprimary-source images. Rendered images in this package are our book pages.\n')
editorial={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in paths.values()}
for p in dest.iterdir():editorial[str(p.relative_to(R))]=dict(bytes=p.stat().st_size,SHA256=sha(p))
write(record,dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — final three-place metric book/evidence export',artifacts=artifacts,editorial_files=editorial,progress_document_hashes=progress,actual_final_book_pages=13,actual_final_matching_views=7,reused_matching_views=0,explicitly_reviewed_blank_versos=[],source_evidence_SHA256=sha(sourcezip),source_checkpoint_SHA256=prep['source_checkpoint_SHA256'],source_publication_SHA256=prep['source_publication_SHA256'],classical_model_reconstruction_SHA256=prep['classical_model_reconstruction_SHA256'],active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)))
print(json.dumps(dict(status='EXPORTED',record_SHA256=sha(record),evidence_members=len(files),artifacts=artifacts)))
