from pathlib import Path
old=Path('/tmp/GVF_Foundations_prepare_book_staging_v1_20261009.py').read_text()
repls={
"C=R/'source_material/GVF_Foundations_representation_book_integration_20261009'":"C=R/'source_material/Liu_adelic_small_sections_book_integration_20261009'",
"K=R/'source_material/Hultberg_GVF_dependency_review_20261009/GVFFoundations26ArxivV2'":"K=R/'source_material/Arithmetic_Fujita_adelic_curves_review_20261009/LiuArxivV4'",
"B=Path('/workspace/book-completion-drafts/Luo-Yu-small-points-staging-v1-20261009')":"B=Path('/workspace/book-completion-drafts/GVF-Foundations-representation-staging-v1-20261009')",
"S=Path('/workspace/book-completion-drafts/GVF-Foundations-representation-staging-v1-20261009')":"S=Path('/workspace/book-completion-drafts/Liu-adelic-small-sections-staging-v1-20261009')",
"D=Path('/workspace/book-completion-drafts/GVF-Foundations-representation-integration-v1-20261009')":"D=Path('/workspace/book-completion-drafts/Liu-adelic-small-sections-integration-v1-20261009')",
"2ba857e51919a39b7cade608d1c91cd9a2ce6b9f":"c67551df524a4f85f908e4e0a335c85853278e86",
"fe852d8ed8115d4268b718ce9551fa54bd5940b1fa47851fb1c446790f04be1f":"5d8e58d3eb27c655d9efe9da2abd6de87cd01b2b77fb8e3c914b2e87c7c27ef3",
"source_material/Luo_Yu_small_points_book_integration_20261009/book_export_v1_20261009.json":"source_material/GVF_Foundations_representation_book_integration_20261009/book_export_v1_20261009.json",
"ch27_gvf_representation_fragment.tex":"ch27_adelic_small_sections_fragment.tex",
"appL_gvf_representation_fragment.tex":"appL_adelic_small_sections_fragment.tex",
"bibliography_gvf_representation_fragment.bib":"bibliography_adelic_small_sections_fragment.bib",
"BDHS26GVFFoundationsV2":"Liu26AdelicFujitaV4",
"imported GVF representation/symmetric extension scopes and source open question":"direct classical three-place metric/positive volume/simultaneous small-section comparison",
"source_material/Luo_Yu_small_points_book_integration_20261009/book_compiled_staged_v1":"source_material/GVF_Foundations_representation_book_integration_20261009/book_compiled_staged_v1",
"manuscript/editorial/GVF_Foundations_complete_source_GitHub_publication_v1_20261009.json":"manuscript/editorial/Liu_adelic_Fujita_complete_source_GitHub_publication_v1_20261009.json",
"book_application_source_repeat_SHA256=sha(C/'actual_book_application_source_repeat_v1_20261009.json'),source_locator_addendum_SHA256=sha(K/'book_application_locator_addendum_v1_20261009.md')":"classical_model_reconstruction_SHA256=sha(K/'own_three_place_model_reconstruction_v1_20261009.md'),source_note_precision_addendum_SHA256=sha(K/'own_reading_note_precision_addendum_v1_20261009.md')"
}
for a,b in repls.items():
 assert a in old,a;old=old.replace(a,b)
line="p.write_text(text.replace(marker,(D/'ch27_adelic_small_sections_fragment.tex').read_text().rstrip()+'\\n\\n'+marker,1))"
assert old.count(line)==1
new="text=text.replace(marker,(D/'ch27_adelic_small_sections_fragment.tex').read_text().rstrip()+'\\n\\n'+marker,1)\ntransition='Returning to the number-field setting, the sufficient intrinsic condition'\nassert text.count(transition)==1\ntext=text.replace(transition,'Returning to the usual number-field adelic structure, the sufficient intrinsic condition',1)\np.write_text(text)"
old=old.replace(line,new)
p=Path('/tmp/Liu_adelic_small_sections_prepare_book_staging_v1_20261009.py');assert not p.exists();p.write_text(old)
source=Path('/tmp/GVF_Foundations_validate_staged_book_v1_20261009.py').read_text()
source=source.replace('source_material/GVF_Foundations_representation_book_integration_20261009','source_material/Liu_adelic_small_sections_book_integration_20261009').replace('/workspace/book-completion-drafts/GVF-Foundations-representation-staging-v1-20261009','/workspace/book-completion-drafts/Liu-adelic-small-sections-staging-v1-20261009')
p=Path('/tmp/Liu_adelic_small_sections_validate_staged_book_v1_20261009.py');assert not p.exists();p.write_text(source)
