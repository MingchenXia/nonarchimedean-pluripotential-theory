# Three trivial places: exact classical model reconstruction

This is a direct calculation with constant shifts of canonical quotient
metrics on projective space. It reconstructs the numerical data in
Liu arXiv:2401.15271v4 Example 4.4, physical page 18. It does not use the
source's asserted nonexistence inference, general arithmetic Fujita proof,
or an original open-problem closure.

## Data and the entire section norm

Take K=Q, with THREE unit-measure copies of the trivial absolute value.
The sigma-algebra is discrete, K is perfect, and the product formula is
zero term by term. On X=P1_K, start with the canonical trivial-field
quotient metric on O(1). On H0(O(n)), the supremum norm of every nonzero
section is one: the upper bound follows from trivial coefficient norms;
the canonical Gauss point gives the lower bound. This specifies the
entire section norm, not merely the two degree-one basis norms.

At the three places multiply the O(1) norms by exp(-c_i), with
(c_1,c_2,c_3)=(1/2,1/2,-3/4). The total constant C is 1/4. Each metric
is continuous and semipositive; a constant shift of the canonical
quotient metric stays a quotient metric. For every nonzero section
s of O(n), its three sup norms are exp(-n c_i). The third is
exp(3n/4)>1 when n>0. Thus NO positive tensor power has a nonzero
section simultaneously small at all places. Trivial scalar multiplication
cannot alter any of these norms.

## Degree, slopes, volume and positivity

The rank is n+1. Each nonzero one-dimensional quotient has degree nC,
and a rank-r subspace has degree rnC. Hence every HN slope is nC and
positive degree is n(n+1)C. The slope probability measure is delta_(nC),
whose positive first moment is nC; it needs the rank factor to recover
total positive degree. The rescaled probability measure is delta_C.

With the source's arithmetic factorial convention,
  arithmetic volume = lim 2 n(n+1)C / n^2 = 2C = 1/2.
The asymptotic minimal slope is C=1/4.

Positivity can also be checked directly on all integral subschemes of P1.
For O(m) with constant shifts a_i and A=sum a_i>0, every closed point
has ordinary degree-normalized height A; finite extensions of the trivial
absolute value are trivial. The arithmetic restriction to a closed
point is A times its degree. The canonical top self-intersection before
shifts is zero, and the constant-shift formula gives 2mA. Taking epsilon
between zero and A verifies the arithmetic ampleness inequality of
section 3.1.3 both for closed points and for the whole curve. Relative
ampleness follows from m>0 and the semipositive quotient metrics.
These are standard projective-space, determinant and constant-shift
intersection calculations, not a new general positivity criterion.

## A nontrivial ample/small-residual decomposition

For each integer p>=2, let A_p have underlying O(p-1) and metric shifts
p c_i. Let M_p have underlying O(1) with canonical metric and no shifts.
The tensor metric identity is
  L^p = A_p tensor M_p.
All of M_p's nonzero sections have norm one at every place, so x0 is a
nonzero small section. A_p is arithmetically ample by the preceding
calculation, with total shift pC>0. Its underlying degree is strictly
less than p and its residual has positive degree, so this example does
not rely on allowing a trivial residual.

The arithmetic volume of A_p is 2(p-1)pC. Therefore
  p^(-2) arithmetic volume(A_p) = 1/2 - 1/(2p).
It tends to arithmetic volume(L)=1/2 from below. The tensor powers of
A_p themselves still have a third-place sup norm greater than one;
arithmetic ampleness is a global intersection/slope condition and does
not assert all-places smallness of its sections.

Consequently the valid absence of simultaneously small positive-power
sections of L coexists with explicit ample/small-residual decompositions.
The nonexistence inference in the source example cannot be obtained
from the arithmetic ampleness definition printed in that same version.
This diagnosis concerns that concrete realization of the norm data; it
neither denies the intended main Fujita statement nor transfers to an
unread later journal edition.

## Scope

All calculations retain the unit place weights, ordinary norms, the
relative dimension one and the arithmetic dimension-two factorial.
The exact finite/symbolic calibration record checks the rank factor,
positive degrees, Veronese scaling and 64 nontrivial decompositions.
Those checks support this explicit model but are not a universal theorem
verifier or an independent production-verifier receipt. A book import
still needs its own staging, ordinary mathematical audit, required checks
and actual selected final-page reading. No canonical problem status,
original theorem typography or existing verifier receipt is changed.
