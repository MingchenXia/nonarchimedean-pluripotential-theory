from pathlib import Path
from datetime import datetime, timezone
import urllib.request, hashlib, json, subprocess, fitz
from PIL import Image, ImageDraw

C = Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009')
W = Path('/tmp/Xue_semiabelian_primary_views_v1_20261009')
assert not C.exists() and not W.exists()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
url = 'https://arxiv.org/pdf/2608.08262v2'
request = urllib.request.Request(url, headers={'User-Agent': 'Book-source-audit/1.0'})
with urllib.request.urlopen(request, timeout=45) as response:
    data = response.read(); resolved = response.url; content_type = response.headers.get('Content-Type')
assert data.startswith(b'%PDF-') and len(data) > 10000
C.mkdir(parents=True)
pdf = C / 'Xue_Equidistribution_semiabelian_2608.08262v2.pdf'
pdf.write_bytes(data)
with fitz.open(pdf) as doc:
    count = len(doc); first = doc[0].get_text()
    assert 'equidistribution for semiabelian' in first.lower() and 'wei xue' in first.lower()
    assert '2608.08262v2' in first and '30 Aug 2026' in first
text_path = C / 'Xue_Equidistribution_semiabelian_2608.08262v2_preparation_text.txt'
subprocess.run(['pdftotext', '-layout', str(pdf), str(text_path)], check=True)
texts = text_path.read_text().split('\f')
assert len(texts) == count + 1 and not texts[-1].strip()
identity = dict(UTC=datetime.now(timezone.utc).isoformat(), status='ACQUIRED — zero actual-reading credit',
    exact_version='arXiv:2608.08262v2', metadata_revision_UTC='2026-08-30 13:21:05',
    metadata_pages=82, physical_pages=count, internal_date='September 1, 2026',
    discrepancy='The abstract-page comment says 82 pages; acquired exact-version PDF has %s physical pages. Physical PDF controls reading locators.' % count,
    requested_URL=url, resolved_URL=resolved, content_type=content_type, path=str(pdf), bytes=len(data),
    SHA256=sha(pdf), preparation_text_path=str(text_path), preparation_text_SHA256=sha(text_path),
    first_page_identity=first[:2300], actual_reading_credit=0, mathematical_clearance=False,
    book_changed=False, helper_source=__file__, helper_SHA256=sha(__file__))
(C / 'source_acquisition_v1_20261009.json').write_text(json.dumps(identity, ensure_ascii=False, indent=2)+'\n')
W.mkdir()
views = []
with fitz.open(pdf) as doc:
    for number, start in enumerate(range(1, count+1, 2), 1):
        pages = list(range(start, min(start+2, count+1)))
        images = []
        for p in pages:
            pix = doc[p-1].get_pixmap(matrix=fitz.Matrix(1.4, 1.4), alpha=False)
            images.append(Image.frombytes('RGB', (pix.width, pix.height), pix.samples))
        canvas = Image.new('RGB', (sum(i.width for i in images)+20, max(i.height for i in images)+38), 'white')
        draw = ImageDraw.Draw(canvas); x = 0
        for p, img in zip(pages, images):
            draw.text((x+8, 8), 'Xue arXiv 2608.08262v2: physical page %s' % p, fill='black')
            canvas.paste(img, (x, 30)); x += img.width+20
        image_path = W / ('sheet_%02d.png' % number); canvas.save(image_path)
        selected = W / ('sheet_%02d.txt' % number)
        selected.write_text('\n\n'.join('XUE ARXIV V2 PHYSICAL PAGE %s\n' % p + texts[p-1] for p in pages))
        views.append(dict(number=number, physical_pages=pages, path=str(image_path), image_SHA256=sha(image_path),
            selected_text_path=str(selected), selected_text_SHA256=sha(selected), source_PDF_SHA256=sha(pdf),
            actually_viewed=False, selected_text_read=False))
manifest = W / 'manifest.json'; manifest.write_text(json.dumps(views, ensure_ascii=False, indent=2)+'\n')
(C / 'primary_notes_v1').mkdir()
prep = dict(UTC=datetime.now(timezone.utc).isoformat(), status='PREPARED — zero actual-reading credit',
    source=identity, prepared_unique_pages=count, prepared_views=len(views),
    manifest_path=str(manifest), manifest_SHA256=sha(manifest), actual_primary_reading_credit=0,
    mathematical_clearance=False, book_changed=False, helper_source=__file__, helper_SHA256=sha(__file__))
(C / 'source_preparation_v1_20261009.json').write_text(json.dumps(prep, ensure_ascii=False, indent=2)+'\n')
print(json.dumps(dict(status=prep['status'], physical_pages=count, metadata_pages=82,
    views=len(views), PDF_SHA256=sha(pdf), bytes=len(data), preparation_SHA256=sha(C/'source_preparation_v1_20261009.json'))))
