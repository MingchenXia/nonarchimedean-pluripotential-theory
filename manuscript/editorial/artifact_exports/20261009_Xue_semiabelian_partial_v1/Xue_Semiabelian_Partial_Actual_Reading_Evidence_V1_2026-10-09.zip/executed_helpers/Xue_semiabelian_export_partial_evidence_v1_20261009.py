from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Xue_semiabelian_review_20261009'
E=R/'manuscript/editorial'
X=E/'artifact_exports/20261009_Xue_semiabelian_partial_v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cp=C/'source_checkpoint_v1_20261009.json'; d=json.loads(cp.read_text())
assert d['actual_unique_pages']==list(range(1,21)) and d['actual_matching_views']==10
assert not X.exists()
prefix='Xue_semiabelian_partial_source_'
paths={key:E/(prefix+key+'_v1_20261009.'+ext) for key,ext in
 [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in paths.values())
audit='''# Xue: partial source review of semiabelian equidistribution

Controlling source: Wei Xue, *Equidistribution for semiabelian varieties
over number fields*, arXiv:2608.08262v2, revised 30 August 2026.
Exact PDF SHA256: `fc81cd8cb291fac389bc0bab50e96711240249498bec0ac4be3a90578edd12d5`.
The PDF has **83 physical pages**, although the abstract-page comment says
82. Its internal date is 1 September. Neither discrepancy transfers
reading credit from a different version.

**Partial reading only: physical pages 1–20, ten ordered full text/image
displays. Pages 21–83 remain unread at this checkpoint.** Main
equidistribution and Bogomolov proofs are **unverified and not integrated**.
This record does not change the active 4,675-page book or any of its
42 canonical open-problem atoms.

## Exact proposed scope

The main generic theorem uses a number-field semiabelian variety with
split toric part, a normal proper toric compactification, big T-effective
geometry, a semipositive monocritical toric metric, and **arithmetic
T-effectivity**. The last condition is attainment of the global roof
maximum at the origin by the distinguished zero-character section; it
is not automatic for a big semipositive metric. The abelian factor is
symmetric ample with its canonical metric. The quasi-canonical case
displays a normalized **mixed** local measure, whose mass is the mixed
intersection rather than the unadjusted full top self-intersection.

The Bogomolov statement additionally requires ample geometry. It explicitly
distinguishes the standard product-of-P1 compactification from a general
fan: the latter requires an independently established curvature–Haar slice
formula, lattice-index normalization and absence of extra boundary mass
for all subvarieties used by the difference-morphism argument. Its
special-point hypothesis is also retained for the converse. Those source
conditions cannot be dropped because the abstract-page summary is shorter.

## Findings from the actually read pages

- Definition 3.3, p. 7: integral support slopes require a stated real
  extension when treating real divisors.
- Proposition 3.6, p. 7: a section over the full tropical space cannot
  have its entire image in the valuation-zero compact unit torus; the
  full toric skeleton section is a different object.
- Definition 3.20, p. 11: Archimedean semipositivity tests the Chern current
  itself. The printed additional ddc of that closed current is not this
  test.
- Definition 3.21, p. 11: a normalized variety-height quotient requires
  nonzero geometric degree before division.
- Theorem 4.1, pp. 13–16: the unit-norm period-transition assertion rests
  on a verbal theta/descent cancellation without the required period
  absolute-value calculation. Changing local sections with fixed lifts
  is different from changing period-lattice lifts. This is a flagged
  input to the induced-metric gluing in Proposition 4.17.
- Proposition 4.18, p. 17: the nef limit needs a variable ample base
  coefficient; choosing an ample toric divisor on a merely proper fan
  needs projectivity or a modified-model argument.
- Corollary 4.19, p. 17: the full top intersection versus its leading
  mixed term omits the binomial coefficient. On P1 times an elliptic
  curve, (D+N)^2=2 D*N. Positivity survives this factor, but probability
  normalizations must keep it.
- Definition 4.21, p. 19: the proposed skeleton-point norm must use a
  multiplicative canonical/unique-Shilov base norm. An arbitrary affinoid
  supremum norm is not enough; the annulus calculation is in the notes.
- Proposition 4.24, pp. 19–20: the displayed transformation law with
  lambda=0 still permits a nonzero additive c_trop period term, so it
  does not imply a constant tropical correction. Rigidification fixes
  an additive constant, not all period slopes. The raw-theta/canonical-
  norm identification and principal-divisor passage remain unverified.

The exact published theta and Kühne sources are the next checks. The
arXiv metadata for Foster–Rabinoff–Shokrieh–Soto explicitly warns that
published numbering differs. Their arXiv locators therefore cannot
authenticate the journal locators cited by Xue. These diagnostics do
not establish a counterexample to the intended main theorem, and no
independent-model receipt is claimed.

## Evidence and next work

The accompanying archive contains our notes, chronological receipts,
source identity/preparation records, checkpoint, preparation-view
manifest and executed helpers. It does not redistribute the paper or
its rendered pages. The exact public source is
https://arxiv.org/pdf/2608.08262v2. Rendering/preparation flags remain
separate from the actual reading receipts. Further pages require fresh
notes and a new checkpoint; this partial checkpoint will not be rewritten.

The Ballaÿ–Sombra arithmetic questions are a separate catalogue supplement.
Its source audit is complete and its native-editor compilation remains
pending at this checkpoint. No Xue claim has been added to that document.
'''
paths['review'].write_text(audit)
paths['reading_notes'].write_text('# Actual partial Xue v2 reading\n\nTwenty pages in ten matching displays; no other reading credit.\n\n'+
 '\n\n---\n\n'.join((C/'primary_notes_v1'/('note_%02d.md'%i)).read_text().rstrip() for i in range(1,11))+'\n')
manifest=dict(UTC=datetime.now(timezone.utc).isoformat(),status=d['status'],
 controlling_source_URL='https://arxiv.org/pdf/2608.08262v2',PDF_SHA256=d['source_PDF_SHA256'],
 physical_pages=83,metadata_pages=82,actual_pages=list(range(1,21)),actual_views=10,
 unread_pages=list(range(21,84)),checkpoint_SHA256=sha(cp),actual_receipts=d['receipts'],
 mathematical_clearance=False,independent_verifier_receipt=False,book_changed=False,canonical_status_changes=[])
paths['manifest'].write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
X.mkdir(parents=True)
archive=X/'Xue_Semiabelian_Partial_Actual_Reading_Evidence_V1_2026-10-09.zip'
members={}
for i in range(1,11):
 for suffix in ['.md','_receipt.json']:
  p=C/'primary_notes_v1'/('note_%02d'%i+suffix);members['primary_notes_v1/'+p.name]=p
for name in ['source_acquisition_v1_20261009.json','source_preparation_v1_20261009.json','source_checkpoint_v1_20261009.json']:
 members['records/'+name]=C/name
members['records/prepared_view_manifest.json']=Path('/tmp/Xue_semiabelian_primary_views_v1_20261009/manifest.json')
for name in ['Xue_semiabelian_acquire_prepare_v1_20261009.py','Xue_semiabelian_record_reading_v1_20261009.py',
 'Xue_semiabelian_checkpoint_v1_20261009.py','Xue_semiabelian_export_partial_evidence_v1_20261009.py']:
 members['executed_helpers/'+name]=Path('/tmp')/name
assert len(members)==28
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for name,p in sorted(members.items()):z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert len(z.namelist())==28 and len(set(z.namelist()))==28
 for name,p in members.items():assert z.read(name)==p.read_bytes()
(X/'README.md').write_text('# Partial actual-source evidence\n\nXue arXiv:2608.08262v2: pages 1–20 of 83, ten matching text/image views.\nMain proofs remain unverified and have not been added to the book.\n\nThe ZIP contains 28 authored evidence/receipt/helper members. Source PDF,\npreparation text and images are not redistributed. Fetch the exact paper\nfrom https://arxiv.org/pdf/2608.08262v2 and use the recorded SHA256.\n')
(X/'SHA256SUMS').write_text(sha(archive)+'  '+archive.name+'\n')
artifacts=dict(UTC=datetime.now(timezone.utc).isoformat(),status='EXPORTED — partial evidence only',
 archive=str(archive.relative_to(R)),bytes=archive.stat().st_size,SHA256=sha(archive),members=28,
 actual_source_pages=20,total_source_pages=83,matching_views=10,book_changed=False,
 no_theorem_clearance=True,no_reading_credit_for_upload=True)
paths['artifacts'].write_text(json.dumps(artifacts,ensure_ascii=False,indent=2)+'\n')
update='''
## Xue semiabelian candidate: partial source evidence, 9 October 2026

The latest checked book remains **4,675 pages**. The candidate
arXiv:2608.08262v2 has been read on physical pages **1–20 of 83**, in ten
matching text/image views. Its main proofs remain unverified and have
not been integrated. The source's general-fan Bogomolov conclusion keeps
its explicit curvature–Haar slice input. Period-transition and
theta/canonical-metric normalization checks continue against the original
sources; no canonical problem status changes.

See [partial source audit](manuscript/editorial/Xue_semiabelian_partial_source_review_v1_20261009.md)
and [authored evidence](manuscript/editorial/artifact_exports/20261009_Xue_semiabelian_partial_v1/).
'''
readme=R/'README.md';readme.write_text(readme.read_text().rstrip()+'\n'+update)
progress=E/'second_reading_and_research_programme_20261002.md'
progress_update=update.replace('manuscript/editorial/Xue_', 'Xue_').replace('manuscript/editorial/artifact_exports/', 'artifact_exports/')
progress.write_text(progress.read_text().rstrip()+'\n'+progress_update)
owned=[str(p.relative_to(R)) for p in paths.values()]+[str(p.relative_to(R)) for p in sorted(X.iterdir())]+[
 str(readme.relative_to(R)),str(progress.relative_to(R))]
assert len(owned)==9
out=C/'partial_evidence_export_v1_20261009.json';assert not out.exists()
record=dict(UTC=datetime.now(timezone.utc).isoformat(),status='READY FOR EXPLICIT NINE-FILE PUBLICATION — partial evidence only',
 owned_files=[dict(path=p,bytes=(R/p).stat().st_size,SHA256=sha(R/p)) for p in owned],
 archive_members=28,actual_pages=20,total_pages=83,book_changed=False,
 native_catalogue_changed_by_this_helper=False,helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=record['status'],owned_files=owned,archive_SHA256=sha(archive),record_SHA256=sha(out))))
