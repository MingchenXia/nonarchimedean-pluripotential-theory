from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

C = Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Xue_semiabelian_review_20261009')
W = Path('/tmp/Xue_semiabelian_primary_views_v1_20261009')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
prep = json.loads((C/'source_preparation_v1_20261009.json').read_text())
manifest = json.loads((W/'manifest.json').read_text())
records = []
pages = []
for number in range(1,11):
    note = C/'primary_notes_v1'/('note_%02d.md' % number)
    receipt = note.with_name('note_%02d_receipt.json' % number)
    r = json.loads(receipt.read_text()); v = manifest[number-1]
    assert r['view_number'] == number and r['physical_pages'] == v['physical_pages']
    assert r['source_PDF_SHA256'] == prep['source']['SHA256']
    assert sha(note) == r['note_SHA256']
    assert sha(v['path']) == r['image_SHA256'] and sha(v['selected_text_path']) == r['selected_text_SHA256']
    assert r['full_selected_text_read'] and r['matching_rendered_image_displayed_and_read']
    if number > 1: assert r['previous_receipt_SHA256'] == records[-1]['receipt_SHA256']
    pages.extend(r['physical_pages'])
    records.append(dict(view_number=number,physical_pages=r['physical_pages'],note_path=str(note),
        note_SHA256=sha(note),receipt_path=str(receipt),receipt_SHA256=sha(receipt)))
assert pages == list(range(1,21))
obj = dict(UTC=datetime.now(timezone.utc).isoformat(), status='PARTIAL ACTUAL PRIMARY READING — 20 of 83 pages; main proof unverified',
    exact_version='arXiv:2608.08262v2', source_PDF_SHA256=prep['source']['SHA256'],
    source_bytes=prep['source']['bytes'], total_physical_pages=83, metadata_pages=82,
    actual_unique_pages=pages, actual_matching_views=10, unread_pages=list(range(21,84)),
    receipts=records, preparation_SHA256=sha(C/'source_preparation_v1_20261009.json'),
    manifest_SHA256=sha(W/'manifest.json'), mathematical_clearance=False,
    independent_verifier_receipt=False, book_changed=False, canonical_status_changes=[],
    findings=[
      dict(locator='p. 1 and Theorem 1.4, pp. 4–5', kind='EXPLICIT SOURCE RESTRICTION',
        detail='General-fan Bogomolov requires independently established curvature–Haar slice formula with lattice-index and no-boundary-mass assertions; standard product-of-P1 case distinguished.'),
      dict(locator='Definition 3.3, p. 7',kind='COEFFICIENT SCOPE',detail='Integral support slopes versus real-divisor scalar extension must be kept distinct.'),
      dict(locator='Proposition 3.6, p. 7',kind='LITERAL GEOMETRIC MISSTATEMENT',detail='Section over full tropical space cannot have all values in valuation-zero compact unit torus; usual toric skeleton section differs.'),
      dict(locator='Definition 3.20, p. 11',kind='LITERAL DIFFERENTIAL MISSTATEMENT',detail='Archimedean positivity of the Chern current is the condition; printed ddc of that closed current is not that test.'),
      dict(locator='Definition 3.21, p. 11',kind='ZERO-DEGREE SCOPE',detail='Normalized variety-height quotient needs nonzero geometric degree before it is formed.'),
      dict(locator='Theorem 4.1 proof, pp. 13–16',kind='FLAGGED LOAD-BEARING INPUT',detail='Unit-norm period transitions and theta/descent cancellation are asserted without the needed period absolute-value formula; original sources remain to be checked.'),
      dict(locator='Proposition 4.18 proof, p. 17',kind='MISSING STEP/SCOPE',detail='Nef limit requires varying the ample base coefficient; choice of an ample toric divisor on a merely proper fan requires a projectivity/modified-model argument.'),
      dict(locator='Corollary 4.19 proof, p. 17',kind='LITERAL NORMALIZATION ERROR',detail='Full top self-intersection versus leading mixed term omits binomial(g+t,t), already visible on P1 times an elliptic curve. Positivity conclusion survives the positive factor.'),
      dict(locator='Definition 4.20 and Section 4.1, pp. 17–18',kind='VALID ELEMENTARY REFORMULATION',detail='Arithmetic T-effectivity is global-roof maximum attainment at zero for the distinguished section; not known necessary for equidistribution itself.'),
      dict(locator='Definition 4.21, p. 19',kind='BASE-POINT SCOPE',detail='Supremum norm must be tied to a multiplicative canonical/unique-Shilov point; arbitrary affinoid sup norms fail multiplicativity.'),
      dict(locator='Proposition 4.24 proof, pp. 19–20',kind='FLAGGED LOAD-BEARING INFERENCE',detail='lambda=0 does not from the displayed transformation law force a constant tropical correction while the additive c_trop period term is retained; raw-theta/canonical-norm comparison remains unverified.')
    ],
    exact_primary_dependencies_pending=[
      dict(title='Non-Archimedean and tropical theta functions',source='Foster–Rabinoff–Shokrieh–Soto',
        arxiv='1705.08212v2',DOI='10.1007/s00208-018-1646-3',
        edition_caution='arXiv metadata explicitly says journal numbering differs; published edition needed for Xue journal locators.'),
      dict(title='Points of small height on semiabelian varieties',source='Kühne',DOI='10.4171/JEMS/1125',
        edition='JEMS 24 (2022), 2077–2131; publisher PDF 55 pages, CC BY 4.0',
        reading_status='Metadata/citation acquisition only at this checkpoint; no full local text/image reading credit.')
    ],
    native_catalogue='Separate two-source-question supplement has source audit complete and native compiler still pending; not Xue integration.',
    scope='These diagnostics do not establish a counterexample to the intended main equidistribution/Bogomolov theorem.',
    helper_source=__file__,helper_SHA256=sha(__file__))
out=C/'source_checkpoint_v1_20261009.json'; assert not out.exists()
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],actual_pages=20,views=10,checkpoint_SHA256=sha(out))))
