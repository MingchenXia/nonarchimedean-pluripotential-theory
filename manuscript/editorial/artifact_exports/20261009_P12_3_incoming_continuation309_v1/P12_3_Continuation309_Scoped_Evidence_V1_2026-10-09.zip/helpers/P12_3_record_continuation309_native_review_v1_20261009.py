from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

D = Path('/workspace/nonarchimedean-pluripotential-theory/source_material/GitHub_incoming_continuation309_20261009')
manifest = json.loads((D / 'acquisition_v2_20261009.json').read_text())
mapping = {Path(r['local_path']).name: r for r in manifest['files']}

def binding(name):
    p = D / name
    row = mapping[name]
    assert hashlib.sha256(p.read_bytes()).hexdigest() == row['SHA256']
    return row

actual = json.loads((D / 'native296-actual-FINAL-all-five-fields.json').read_text())
assembled = json.loads((D / 'native296-assembled-notes-separate-from-actual.json').read_text())
assert actual['candidate'] is False and assembled['candidate'] is False
assert actual == assembled
native_source = (D / 'native-standalone-DATA.tex').read_text()
root_source = (D / 'P12.3-quotients-and-wild-conductors.tex').read_text()
assert native_source.count(',qquad') == 2
assert native_source.replace(',qquad', ',\\qquad') == root_source
rows = []
for n in range(1, 6):
    name = f'actual-n{n}-all-five-fields.json'
    obj = json.loads((D / name).read_text())
    assert list(obj) == ['id', 'summary', 'detailedSummary', 'text', 'support']
    assert actual['notes'][n-1] == assembled['notes'][n-1] == obj
    formal = D / f'n{n}.tex'
    text = formal.read_text()
    assert text in native_source
    repaired = text.replace(',qquad', ',\\qquad')
    assert repaired in root_source
    rows.append(dict(id=obj['id'], actual_five_fields=binding(name),
                     formal=binding(formal.name), formal_lines=len(text.splitlines()),
                     actual_all_five_fields_read=True, complete_formal_proof_read=True,
                     different_current_actual_assembled_fields=[],
                     native_formal_exact_containment=True,
                     root_formal_exact_containment_after_separator_only_errata=True))
assert sum(r['formal']['bytes'] for r in rows) == 43201
assert sum(r['formal_lines'] for r in rows) == 787
note = D / 'own_reading_notes_v1/note_07_native296_actual_and_formal.md'
record = dict(UTC=datetime.now(timezone.utc).isoformat(), remote_commit=manifest['remote_commit'],
              status='ACTUAL five-field and formal source reading; byte identity independently checked',
              actual=binding('native296-actual-FINAL-all-five-fields.json'),
              assembled=binding('native296-assembled-notes-separate-from-actual.json'),
              current_actual_assembled_structural_identity=True, rows=rows,
              native_source=binding('native-standalone-DATA.tex'),
              root_source=binding('P12.3-quotients-and-wild-conductors.tex'),
              only_reader_source_errata=[',qquad -> ,\\qquad', ',qquad -> ,\\qquad'],
              earlier_actual294_differences_report_complete_read=False,
              note_path=str(note), note_SHA256=hashlib.sha256(note.read_bytes()).hexdigest(),
              independent_verifier=False, imported_primary_source_read=False,
              supplied_programs_executed=False, supplied_programs_imported=False,
              native_model_started=False, original_results_promoted=[], book_changed=False,
              helper_source=__file__, helper_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
out = D / 'actual_native296_reading_and_byte_comparison_v1_20261009.json'
with out.open('x') as f:
    f.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(dict(actual_all_five_fields_read=5, formal_proofs_read=5,
                      formal_lines=787, formal_bytes=43201, current_actual_assembled_identical=True,
                      record_SHA256=hashlib.sha256(out.read_bytes()).hexdigest())))
