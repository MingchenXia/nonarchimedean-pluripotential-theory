from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction
from math import comb, inf
import hashlib, json

D = Path('/workspace/nonarchimedean-pluripotential-theory/source_material/GitHub_incoming_continuation309_20261009')
primes = [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]
wild = []
for p in primes:
    left = {}
    for degree in [p, p+1]:
        for j in range(degree+1):
            exponent = (degree-j, j)
            left[exponent] = (left.get(exponent, 0) + comb(degree, j)) % p
        left[(degree, 0)] = (left.get((degree, 0), 0) - 1) % p
    left = {e: c for e, c in left.items() if c}
    right = {(0, p): 1, (1, p): 1, (0, p+1): 1, (p, 1): 1}
    assert left == right
    contact = Fraction(p, p-1)
    gap = 3-contact
    assert gap >= 1 and 4 > 1+contact
    wild.append(dict(characteristic=p, nonzero_difference_terms={str(k):v for k,v in left.items()},
                     contact=str(contact), L=4, gap=str(gap), derivative='t^p, nonzero'))

def poly_add(a, b, N):
    return [((a[i] if i<len(a) else 0) + (b[i] if i<len(b) else 0)) % 2 for i in range(N)]

def poly_mul(a, b, N):
    out = [0]*N
    for i, ai in enumerate(a):
        if ai:
            for j, bj in enumerate(b[:N-i]):
                out[i+j] = (out[i+j]+ai*bj) % 2
    return out

arcs = []
for N in [16, 32, 64, 128]:
    b = [0]*N
    for i in range(1, N):
        b[i] = (b[i-1] + (b[i//2] if i%2==0 else 0) + (1 if i==2 else 0)) % 2
    s = [0, 1]+[0]*(N-2)
    tau = poly_add(s, b, N)
    b2 = poly_mul(b, b, N)
    relation = poly_add(poly_add(poly_add(b, poly_mul(s,b,N), N), b2, N), poly_mul(s,s,N), N)
    assert not any(relation)
    tau2 = poly_mul(tau, tau, N)
    tau3 = poly_mul(tau2, tau, N)
    target = poly_add(poly_mul(s,s,N), poly_mul(poly_mul(s,s,N),s,N), N)
    assert poly_add(tau2,tau3,N) == target
    assert next(i for i,c in enumerate(b) if c) == 2
    assert next(i for i,c in enumerate(tau) if c) == 1
    arcs.append(dict(characteristic=2, modulus=f's^{N}',
                     b_nonzero_exponents=[i for i,c in enumerate(b) if c],
                     equation='b+s*b+b^2+s^2=0', equation_coefficients_zero=True,
                     P_tau_equals_P_s=True, tau_order=1, contact=2))

weights = [Fraction(0), Fraction(1,2), Fraction(1), Fraction(2), Fraction(5), inf]
norm_cases = []
for A in weights:
    for B in weights:
        for Z in [Fraction(1), Fraction(2), Fraction(4)]:
            coefficient_value = min(A+B, Z+min(A,B), 2*Z)
            orbit_sum = min(A,Z)+min(B,Z)
            assert coefficient_value == orbit_sum
            norm_cases.append(dict(A=str(A),B=str(B),Z=str(Z),value=str(coefficient_value)))

truncation_cases = 0
for L in [4, 5, 8]:
    for Y in [Fraction(1),Fraction(3,2),Fraction(2),Fraction(5),Fraction(16),inf]:
        for a in [Fraction(0),Fraction(1,2),Fraction(1),Fraction(3,2),Fraction(2),Fraction(4),inf]:
            obstacle = -1-(min(Y+a,L)-min(Y,L))
            assert -L <= obstacle <= -1
            for n in range(1,33):
                competitor = -1-min(Y/n+a,L)
                assert competitor <= obstacle
                truncation_cases += 1

path_witnesses = []
for p in primes:
    a = Fraction(p,p-1)
    gap = 3-a
    for n in [1, 2, 4, 8, 16, 32, 64]:
        # This finite radius kills the fixed competitor's contact advantage.
        radius = n*(4-a)+1
        q = -1-min(radius/n+a,4)
        assert q == -5 and max(q,-4) == -4
    radius = Fraction(64)
    late_n = 4096
    near_sup = -1-min(radius/late_n+a,4)
    assert 0 <= (-1-a)-near_sup == radius/late_n
    assert near_sup-(-4) == gap-radius/late_n > 0
    path_witnesses.append(dict(p=p, contact=str(a), limiting_sup=str(-1-a),
                               constant_barrier=-4, gap=str(gap),
                               finite_radius=str(radius),late_degree=late_n,
                               late_competitor=str(near_sup),finite_gap=str(near_sup+4)))

degree_cases = 0
for d in range(1,9):
    for m in range(1,17):
        for s in range(d):
            ell = d*m+s
            for K in [Fraction(0),Fraction(1,2),Fraction(1),Fraction(7,3)]:
                for M1 in [Fraction(0),Fraction(1),Fraction(3)]:
                    for P in [Fraction(0),-M1/2,-M1]:
                        graded_lower = Fraction(d*m,ell)*(P-K/m)-Fraction(s,ell)*M1
                        claimed_lower = P-Fraction(d,ell)*(K+M1)
                        assert graded_lower >= claimed_lower
                        degree_cases += 1

record = dict(UTC=datetime.now(timezone.utc).isoformat(),status='PASS on stated finite exact domains ONLY',
              wild_polynomial_and_contact_cases=wild,
              characteristic2_actual_truncated_conjugate_arcs=arcs,
              quotient_support_orbit_norm_weight_cases=norm_cases,
              truncation_profile_cases=truncation_cases,
              finite_conductor_path_order_of_limits_witnesses=path_witnesses,
              signed_all_degree_transfer_bound_cases=degree_cases,
              source_programs_executed=False,source_programs_imported=False,
              universal_formal_series_or_ideal_claim_certified=False,
              geometric_positivity_certified=False,independent_verifier=False,
              original_results_promoted=[],
              mathematical_scope='Finite diagnostics of polynomial identity, actual truncated char2 conjugates, support-truncated norm values, obstacle signs and degree-transfer arithmetic; not universal proof',
              helper_source=__file__,helper_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
out = D/'own_exact_diagnostics_v1_20261009.json'
with out.open('x') as f:
    f.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(status=record['status'],wild_polynomial_cases=len(wild),
                      explicit_characteristic2_arcs=len(arcs),norm_cases=len(norm_cases),
                      truncation_cases=truncation_cases,degree_bound_cases=degree_cases,
                      record_SHA256=hashlib.sha256(out.read_bytes()).hexdigest())))
