from pathlib import Path
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
import hashlib, json, subprocess, base64

R = Path('/workspace/nonarchimedean-pluripotential-theory')
D = R / 'source_material/GitHub_incoming_continuation309_20261009'
HEAD = '9556f41667eb56aea7e4ec0ddf1b8665a320698e'
PREFIX = 'research-checkpoints/continuation309/'
PUBLIC = PREFIX + 'frozen-files/root-checks/public-P12.3-continuation430-formal-group-quotients-and-wild-separable-conductors-unreviewed/'
REPO = 'repos/MingchenXia/nonarchimedean-pluripotential-theory/'

def api(endpoint):
    return json.loads(subprocess.check_output(['gh', 'api', REPO + endpoint], cwd=R, text=True))

tree = api('git/trees/' + HEAD + '?recursive=1')
assert not tree['truncated']
mapping = {r['path']: r for r in tree['tree'] if r['type'] == 'blob'}
paths = {
    'checkpoint_README_v1_20261009.md': PREFIX + 'README.md',
    'current-research-status.json': PREFIX + 'current-research-status.json',
    'desktop-compiler-observations.json': PREFIX + 'desktop-compiler-observations.json',
    'UPLOAD_MANIFEST-continuation309.json': 'manuscript/editorial/xean_research_20261003/UPLOAD_MANIFEST-continuation309.json',
}
for name in ('P12.3-quotients-and-wild-conductors.tex', 'native-standalone-DATA.tex',
             'native296-actual-FINAL-all-five-fields.json', 'native296-assembled-notes-separate-from-actual.json',
             'native-report-actual-assembled-exact-differences.json',
             'ROOT-whole-proof-source-application-scope-and-residual.json',
             'ROOT-whole-proof-source-scope-and-binding.json', 'ROOT-whole-companion-containment-ledger.json',
             'scoped-verdict.md', 'source-application-reading-ledger.md', 'original-task.json',
             'original-completion-criteria.txt', 'original-residual.md',
             'round296-terminal-actual-final-ROOT-retention-20261009.json',
             'native-report-command-evidence.json', 'native-report-environment.json',
             'native-report-exact-checks.json', 'native-report-input-byte-audit.json',
             'native-report-own-hashes.json', 'native-report-verification.json', 'exact-check-input.json'):
    paths[name] = PUBLIC + name
for n in range(1, 6):
    for name in (f'actual-n{n}-all-five-fields.json', f'n{n}.tex', f'native-assembled-n{n}.txt'):
        paths[name] = PUBLIC + name
for name in ('P12.3-continuation429-normalization-envelope-compatibility-and-fibre-gap-working-paper-20261009.tex',
             'P12.3-continuation429-ROOT-whole-paper-source-scope-and-binding-20261009.json',
             'P12.3-continuation429-ROOT-whole-proof-source-scope-and-residual-20261009.json',
             'P12.3-continuation429-desktop-compiler-observation-20261009.json'):
    paths[name] = PREFIX + 'frozen-files/root-checks/' + name

def acquire(item):
    name, remote = item
    row = mapping[remote]
    blob = api('git/blobs/' + row['sha'])
    assert blob['encoding'] == 'base64'
    data = base64.b64decode(blob['content'])
    assert len(data) == row['size']
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == row['sha']
    p = D / name
    preexisting = p.exists()
    if preexisting:
        assert name == 'checkpoint_README_v1_20261009.md' and p.read_bytes() == data
    else:
        with p.open('xb') as f:
            f.write(data)
    return dict(remote_path=remote, local_path=str(p), remote_commit=HEAD,
                Git_blob_SHA1=row['sha'], SHA256=hashlib.sha256(data).hexdigest(),
                bytes=len(data), existing_bytes_preserved=preexisting,
                actual_content_read=False)

with ThreadPoolExecutor(max_workers=5) as pool:
    files = list(pool.map(acquire, paths.items()))
omitted = [dict(remote_path=p, bytes=row.get('size'), reason='not acquired; no proof-reading credit')
           for p, row in mapping.items() if p.startswith(PREFIX) and p not in paths.values()]
record = dict(UTC=datetime.now(timezone.utc).isoformat(),
              status='ACQUIRED PASSIVE DATA; mathematical reading pending',
              branch='codex/xean-research-20261003', remote_commit=HEAD, files=files,
              omitted=omitted, programs_executed=False, programs_imported=False,
              native_model_started=False, book_changed=False, original_results_promoted=[],
              helper_source=__file__, helper_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
out = D / 'acquisition_v1_20261009.json'
with out.open('x') as f:
    f.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(dict(commit=HEAD, acquired_files=len(files), total_bytes=sum(r['bytes'] for r in files),
                      unread_companions=[r for r in omitted if 'companion' in r['remote_path']],
                      manifest_SHA256=hashlib.sha256(out.read_bytes()).hexdigest())))
