from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, sys

D = Path('/workspace/nonarchimedean-pluripotential-theory/source_material/GitHub_incoming_continuation309_20261009')
source_name, first, last, note_name = sys.argv[1:]
first, last = int(first), int(last)
source = D / source_name
note = D / 'own_reading_notes_v1' / note_name
receipt = note.with_suffix('.json')
assert source.is_file() and note.is_file() and not receipt.exists()
data = source.read_bytes()
lines = data.decode().splitlines(keepends=True)
assert 1 <= first <= last <= len(lines)
manifest = json.loads((D / 'acquisition_v2_20261009.json').read_text())
entry = next(r for r in manifest['files'] if r['local_path'] == str(source))
assert hashlib.sha256(data).hexdigest() == entry['SHA256']
record = dict(UTC=datetime.now(timezone.utc).isoformat(),
              status='ACTUAL COMPLETE displayed line interval read; own scoped mathematical note recorded afterwards',
              remote_commit=manifest['remote_commit'], source=entry,
              actual_line_interval=[first, last], total_source_lines=len(lines),
              displayed_interval_SHA256=hashlib.sha256(''.join(lines[first-1:last]).encode()).hexdigest(),
              note_path=str(note), note_SHA256=hashlib.sha256(note.read_bytes()).hexdigest(),
              rendered_PDF_read=False, independent_verifier=False, original_results_promoted=[],
              acquisition_programs_executed=False, inherited_recursive_proof_read=False,
              helper_source=__file__, helper_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
with receipt.open('x') as f:
    f.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(dict(note=note.name, interval=record['actual_line_interval'],
                      source_SHA256=entry['SHA256'], receipt_SHA256=hashlib.sha256(receipt.read_bytes()).hexdigest())))
