from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess, zipfile

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R/'source_material/GitHub_incoming_continuation309_20261009'
E = R/'manuscript/editorial'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
now = lambda: datetime.now(timezone.utc).isoformat()

def fresh(p, text):
    assert not p.exists(), str(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x') as f:
        f.write(text.rstrip()+'\n')

def record(p, value):
    fresh(p, json.dumps(value, ensure_ascii=False, indent=2))

def item(p):
    return dict(path=str(p), bytes=p.stat().st_size, SHA256=sha(p))

parent = subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert parent == 'd0fcb8d67cd31f721a39240042e9ed659a41f9dc'
assert not subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).strip()
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).strip()
acq = json.loads((C/'acquisition_v2_20261009.json').read_text())
for row in acq['files']:
    p = Path(row['local_path'])
    assert sha(p)==row['SHA256'] and p.stat().st_size==row['bytes']
receipts = [json.loads(p.read_text()) for p in sorted((C/'own_reading_notes_v1').glob('*.json'))]
assert len(receipts)==6
for row in receipts:
    assert sha(row['source']['local_path'])==row['source']['SHA256']
    assert sha(row['note_path'])==row['note_SHA256']
paper429 = 'P12.3-continuation429-normalization-envelope-compatibility-and-fibre-gap-working-paper-20261009.tex'
assert [r['actual_line_interval'] for r in receipts if Path(r['source']['local_path']).name==paper429]==[[1,314]]
assert [r['actual_line_interval'] for r in receipts if Path(r['source']['local_path']).name=='P12.3-quotients-and-wild-conductors.tex']==[[1,180],[181,360],[361,540],[541,720],[721,897]]
native = json.loads((C/'actual_native296_reading_and_byte_comparison_v1_20261009.json').read_text())
assert native['current_actual_assembled_structural_identity']
assert len(native['rows'])==5 and all(r['actual_all_five_fields_read'] and r['complete_formal_proof_read'] for r in native['rows'])
assert sha(native['note_path'])==native['note_SHA256']
checks = json.loads((C/'own_exact_diagnostics_v1_20261009.json').read_text())
assert checks['status']=='PASS on stated finite exact domains ONLY'
book = R/'manuscript/book.pdf'
catalogue = R/'output/open_problems_catalogue_2026-10-03.tex'
assert sha(book)=='fe852d8ed8115d4268b718ce9551fa54bd5940b1fa47851fb1c446790f04be1f'
assert sha(catalogue)=='ec3a2a9d8c4d713afe2c0ff8dcf17720ef0d77442b6086d515dea382fe7b77ec'
reading = C/'actual_complete_current_scoped_reading_v1_20261009.json'
record(reading,dict(UTC=now(),status='ACTUAL complete current scoped source reading; original claims UNVERIFIED',
    remote_commit=acq['remote_commit'],acquisition=item(C/'acquisition_v2_20261009.json'),
    paper429=dict(source=next(r for r in acq['files'] if Path(r['local_path']).name==paper429),
                  actual_complete_lines=[1,314],complete_current_core_read=True),
    paper430=dict(source=next(r for r in acq['files'] if Path(r['local_path']).name=='P12.3-quotients-and-wild-conductors.tex'),
                  actual_complete_lines=[1,897],complete_core_and_scope_attachments_read=True),
    actual_native296_reading_and_identity=item(C/'actual_native296_reading_and_byte_comparison_v1_20261009.json'),
    reading_receipts=[item(p) for p in sorted((C/'own_reading_notes_v1').glob('*.json'))],
    complete_separate_records_actually_read=['original-task.json','original-completion-criteria.txt','original-residual.md',
        'scoped-verdict.md','source-application-reading-ledger.md','current-research-status.json','desktop-compiler-observations.json',
        'ROOT-whole-proof-source-application-scope-and-residual.json',
        'P12.3-continuation429-ROOT-whole-proof-source-scope-and-residual-20261009.json',
        'round296-terminal-actual-final-ROOT-retention-20261009.json'],
    current_G331_body_acquired=False,current_G331_body_identity_checked=False,
    new_primary_carrier_or_pixel_reading_credit=0,recursive_primary_audit_complete=False,
    unacquired_unread_companions=[r for r in acq['omitted'] if 'companion' in r['remote_path']],
    earlier_actual294_differences_report_whole_read=False,
    source_programs_executed=False,source_programs_imported=False,native_model_started=False,
    active298_mathematics_read=False,rendered_PDF_read=False,independent_production_verifier_receipt=None,
    original_results_promoted=[],canonical_status_changes=[],book_changed=False,native_editor_changed=False))

base = 'P12_3_incoming_continuation309'
review = E/(base+'_scoped_review_v1_20261009.md')
fresh(review,(C/'own_scoped_proof_review_v1_20261009.md').read_text())
public_notes = E/(base+'_scoped_reading_notes_v1_20261009.md')
fresh(public_notes,'# Actual current scoped reading\n\nOriginal deductions remain UNVERIFIED. '+
      'Both complete current cores, all actual296 five-field objects and all five formal proofs were read. '+
      'No current G331 whole-body identity, fresh primary pixel or recursively complete audit is claimed. '+
      'The same4,681-page book and native catalogue/editor are preserved.\n\n```json\n'+
      reading.read_text().rstrip()+'\n```')
manifest = E/(base+'_scoped_manifest_v1_20261009.json')
record(manifest,dict(UTC=now(),status='SCOPED SOURCE AUDIT — UNVERIFIED original claims',
    parent=parent,remote_commit=acq['remote_commit'],acquisition=acq,
    reading=item(reading),native296=item(C/'actual_native296_reading_and_byte_comparison_v1_20261009.json'),
    own_review=item(C/'own_scoped_proof_review_v1_20261009.md'),
    diagnostics=item(C/'own_exact_diagnostics_v1_20261009.json'),
    book_pages=4681,book_PDF_SHA256=sha(book),native_catalogue_SHA256=sha(catalogue),
    book_changed=False,native_editor_changed=False,production_verifier_receipt=None,
    original_results_promoted=[],canonical_status_changes=[],user_evidence_upload_authorized=True))

dest = E/'artifact_exports/20261009_P12_3_incoming_continuation309_v1'
dest.mkdir(exist_ok=False)
archive = dest/'P12_3_Continuation309_Scoped_Evidence_V1_2026-10-09.zip'
members = [(p,'reading_notes/'+p.name) for p in sorted((C/'own_reading_notes_v1').iterdir())]
for name in ['acquisition_helper_failure_v1_20261009.json','acquisition_v2_20261009.json',
             'actual_native296_reading_and_byte_comparison_v1_20261009.json',
             'actual_complete_current_scoped_reading_v1_20261009.json','own_exact_diagnostics_v1_20261009.json',
             'own_scoped_proof_review_v1_20261009.md','own_reading_note_errata_v1_20261009.md']:
    members.append((C/name,name))
members.append((manifest,'public_scoped_manifest_v1_20261009.json'))
for name in ['P12_3_acquire_continuation309_v1_20261009.py','P12_3_acquire_continuation309_v2_20261009.py',
             'P12_3_record_continuation309_reading_v1_20261009.py',
             'P12_3_record_continuation309_native_review_v1_20261009.py',
             'P12_3_continuation309_exact_diagnostics_v1_20261009.py',Path(__file__).name]:
    members.append((Path('/tmp')/name,'helpers/'+name))
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED) as z:
    for p,name in members:
        z.write(p,name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==len(members)
    for p,name in members:
        assert z.read(name)==p.read_bytes()
fresh(dest/'README.md',f'''# continuation309 authored evidence

The{len(members)}-member ZIP preserves authored current-core/five-field/formal
reading notes and receipts, byte comparisons, finite exact diagnostics,
acquisition failure/fallback records and frozen own helpers. Every member
was extracted and compared byte-for-byte. Incoming proof bodies, primary
full text/pixels, source programs, active298 packets and the unacquired
companions are excluded. Current sources already exist on the pinned
research branch. New claims remain UNVERIFIED; no exact-current independent
production receipt, canonical status change or book integration is claimed.
The book remains4,681 pages and the native catalogue/editor is unchanged.
Upload adds no mathematical verification or physical-reading credit.
''')
fresh(dest/'SHA256SUMS',sha(archive)+'  '+archive.name)
artifacts = E/(base+'_scoped_artifacts_v1_20261009.md')
fresh(artifacts,'# continuation309 scoped evidence\n\nStatus: UNVERIFIED conditional original deductions.\n\n'+
      f'[{len(members)}-member authored evidence](artifact_exports/20261009_P12_3_incoming_continuation309_v1/{archive.name})\n\n'+
      'The whole current429/430 cores and five actual/formal native296 records were read. '+
      'The companions, current G331 full body and fresh primary pixels remain unread. '+
      'The same4,681-page book and native catalogue/editor are preserved.\n\n'+
      'Evidence SHA256: `'+sha(archive)+'`.')
summary = '''## Incoming GitHub continuation309 audit, 9 October 2026

At pinned research commit9556f41667eb56aea7e4ec0ddf1b8665a320698e, read
the complete314-line429 and897-line430 current cores, all five fields of
every actual296 record and all five separate formal proofs(787 lines).
Current actual/assembled296 records are structurally identical; historical
actual294 differences remain distinct. Conductor localization/compatibility,
normal characteristic-zero finite-group quotients and NONNORMAL separable/
wild formal conductor failures remain UNVERIFIED scoped candidates.

Own finite diagnostics pass12 characteristic identities, four actual
characteristic-2 conjugate truncations,108 orbit weights,4032 signed
truncation inequalities and20736 all-degree arithmetic cases. See the
[scoped review](REVIEW) and [authored evidence](EVIDENCE). Both companions,
the current G331 literal body and deeper primary/book/pixel audit remain
unread; no recursive clearance or independent production receipt is claimed.
General normal dimension≥3 and arbitrary conductor classification remain
OPEN. The4,681-page book, same native editor/catalogue and42 canonical
problem statuses are unchanged. Xean remains suspended in the cloud.
'''
for p,prefix in [(R/'README.md','manuscript/editorial/'),
                 (E/'second_reading_and_research_programme_20261002.md','')]:
    text = summary.replace('REVIEW',prefix+review.name).replace('EVIDENCE',prefix+'artifact_exports/20261009_P12_3_incoming_continuation309_v1/README.md')
    p.write_text(p.read_text().rstrip()+'\n\n'+text.rstrip()+'\n')
owned = [review,public_notes,manifest,artifacts,archive,dest/'README.md',dest/'SHA256SUMS',
         R/'README.md',E/'second_reading_and_research_programme_20261002.md']
record(C/'scoped_evidence_export_v1_20261009.json',dict(UTC=now(),status='LOCAL EXPORT BYTE VERIFIED — publication pending',
    parent=parent,owned_files=[dict(path=str(p.relative_to(R)),bytes=p.stat().st_size,SHA256=sha(p)) for p in owned],
    archive_members=[dict(member=name,**item(p)) for p,name in members],archive_SHA256=sha(archive),
    actual_current_scoped_reading=item(reading),native296_reading=item(C/'actual_native296_reading_and_byte_comparison_v1_20261009.json'),
    diagnostics=item(C/'own_exact_diagnostics_v1_20261009.json'),book_pages=4681,book_PDF_SHA256=sha(book),
    native_catalogue_SHA256=sha(catalogue),book_changed=False,native_editor_changed=False,
    original_claims_status='UNVERIFIED',original_results_promoted=[],canonical_status_changes=[],
    helper_source=__file__,helper_SHA256=sha(__file__)))
print(json.dumps(dict(status='PASS',archive_members=len(members),archive_bytes=archive.stat().st_size,
                      archive_SHA256=sha(archive),owned_files=len(owned),book_pages=4681)))
