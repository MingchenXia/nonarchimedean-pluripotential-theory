# Paper429 complete current core: actual lines1–314

Pinned research commit:9556f41667eb56aea7e4ec0ddf1b8665a320698e.
Read the entire displayed current TeX source after public acquisition and
Git-blob/byte verification. This is source reading, not rendered-page reading
or independent verification. The325842-byte companion is not acquired/read.

The exact category is a positive-dimensional excellent local DOMAIN with
finite normalization, actual primary gauge, all marked semilocal source
centres and all prime supports. G331 supplies the compact quotient,
finite-conductor singleton fibres and positive geometric full-fibre descent.
Those are scoped imported dependencies, not independently proved by this
new reading. The canonical ideals represent the continuous/decreasing
minorant raw supremum; every degree converges pointwise. Continuity is
equivalent to uniform canonical convergence and greatest minorant existence.

The conductor localization competitor is the actual target ideal
c J_m^n+a^(mnM). Its negative profile is max(q_m−w(c)/(mn),−M),
including infinite conductor value; the boundary summand supplies primary
support and geometric ampleness before passage to the limit. Equality with
the source raw envelope is obtained only on finite-conductor points, while
the global comparison has target≤source orientation.

Given source continuity and finite-conductor density, full-fibre constancy
is sufficient through POSITIVE descent and necessary through equality of
continuous pullbacks on a dense set. A source fibre discrepancy Delta
gives a target upward limiting gap at least Delta. The same net bounds every
decreasing-completion minorant, including each canonical degree, from above
at the special point and gives sup(p−g)≥Delta. Finite homogeneous generation
would yield a rational primary profile via a common multiple of generator
degrees, contradicting discontinuity. Perturbation uses source universal
continuity and the envelope1-Lipschitz estimate, leaving Delta−2 epsilon.

The density proof actually addresses every formal series: completion to
k[[z]], quotient by the given support, completed valued fraction field H,
translation z=alpha+T in a radius-sigma Tate algebra, injective restriction
to Gauss radius r and multiplicativity via initial polynomials in a graded
domain. The positive-degree tail is bounded by a constant times r/sigma.
Normalization by the finite boundary minimum tends to1. This controls
infinite-supported values as well as finite ones. Smooth CLOSED centres
over algebraically closed k are used; the density construction itself needs
no characteristic-zero condition. The source envelope regularity used in
the final corollary does require the qualified smooth affine closed,
algebraically closed characteristic-zero BFJ source.

Checks made while reading: all finite-conductor limit signs are consistent;
the source discrepancy is compared at the same target fibre; a decreasing
net is upper semicontinuous; primary radical in the finite-generation
argument uses degree-one generators spanning A1, which contains a boundary
power. Completion, positive descent, BFJ closed-simplex/retraction and
historical multiplier/resolution inputs remain load-bearing. This note does
not clear them recursively or certify a new theorem. General excellent
NORMAL dimension≥3, positive/mixed-characteristic source regularity and
intrinsic arbitrary-conductor classification remain OPEN. P12.3 and its
canonical book status remain unchanged; all current deductions UNVERIFIED.
