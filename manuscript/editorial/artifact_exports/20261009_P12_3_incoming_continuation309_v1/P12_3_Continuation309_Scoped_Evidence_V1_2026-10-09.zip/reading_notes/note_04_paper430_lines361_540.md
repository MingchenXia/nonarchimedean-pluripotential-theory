# Paper430 current core: actual lines361–540

Read the complete interval. Complete Noetherian local excellence and invariant
normality finish the formal ring hypotheses. G331 completion transports the
smooth characteristic-zero source CE and its model rate; it does not
algebraize the group action. Every restriction fibre is an orbit, hence the
greatest pulled-obstacle source envelope is invariant. POSITIVE descent,+not fibre minimization, yields the target greatest C/D envelope. Explicit
orbit-coefficient profiles give actual ample primary presentations before
the uniform limit. This is a NORMAL quotient sector; its own normalization
conductor is a unit and its finite-cover orbits are not conductor fibres.

Canonical ideals contract exactly: A_m^R=J_m^S intersect R. Extension equality
is not claimed. Stable source ideals yield N_G(J_m) subset A_dm^R and
h_dm^R pullback≥h_m^S. Writing l=dm+s and using nonpositive P gives the
correct all-degree upper error d(K+M1)/l; the low degrees follow from
(A1)^l subset A_l. Only finite signed primary MODEL obstacles have the
algebraic rate; arbitrary continuous obstacles have uniform convergence.
The decreasing-obstacle extension is an actual decreasing envelope net,
without arbitrary-net flattening. The example ac=b² is a singular normal
quotient in characteristic zero, not a counterexample to normal CE.

The conditional conductor obstruction assumes one normal source centre,
two distinct full-fibre lifts distinguished by b, an approaching finite-
conductor net and comparison nu(IS)≤K o(I) for ALL downstairs primary/unit
ideals. All are actual hypotheses, not inferred from cardinality. The
obstacle uses truncated ideals (cb)+a^L and c+a^L, avoiding infinite
subtraction. The competitors use c b^n, with ONE conductor factor, giving
q_n=−1−min(Y/n+a,L). Their actual primary blowups are ample before limits.
The comparison sign is g(o)≤g(nu)/K, and the discontinuity gap is
D0/K−1−min(A,L)>0. Small perturbations require
(K+1)epsilon<D0−K(1+min(A,L)). No source CE, local etaleness or positive
finite-fibre minimum is used here. The full formal-family construction
begins in the next interval.

All original deductions remain UNVERIFIED; deep G331/BFJ dependencies and
ordinary complete-algebra background are explicitly retained imports.
