# Paper430 current core: actual lines541–720

Read the entire displayed formal separable-cover/wild proof. For ANY field,
e≥2,d≥3, P in k[[t]] has order e and P'≠0; A=k[[u,y,s,Z]],
S=k[[t,y,s,Z]],u=P(t),R=A+yS. Repeated division by P and reduction mod t^e
give the finite free A-basis1,t,…,t^(e−1). The explicit finite closed
subalgebra R is a complete excellent local domain, with mS=(P,y,s,Z),
fraction field equal to S's and normalization S with one regular centre.
The conductor is exactly yS: modulo y a nonzero conductor would force the
degree-e quotient fraction-field extension to become trivial.

The characteristic polynomial Q(T,u) is degree e and minimal; the formal
kernel identity Q=H(u−P(T)), with H a unit, gives Q_T(t,P(t))≠0.
A distinct conjugate tau in a finite normal closure therefore exists.
Integral closure of the complete excellent DVR is finite and complete;
idempotent lifting makes this domain local; normal dimension-one gives a
complete DVR. Hence convergent substitutions have v(tau)=v(s)=1 and finite
contact a=v(tau−s)≥1. The two full-source semivaluations kill yS, agree on
EVERY downstairs element and differ on t−s. No exhaustiveness of these two
fibre points is needed.

The approaching Gauss path assigns weight r to y after substituting t=tau,
Z=0. Multiplicativity uses the graded coefficient domain and a finite
initial polynomial. For EVERY formal series the constant-y coefficient
eventually controls its finite value, or all values tend to infinity.
This is full-element pointwise convergence, not just coordinate convergence.
The monomial comparison in coordinates(s,b=t−s,y,Z) uses weights(1,L,1,1)
and the nonzero pure s^N term whenever o(f)=N. It proves nu(IS)≤o(I) for
ALL downstairs primary/unit ideals, with K=1, and needs no Izumi input.

With c=y,b=t−s,L>1+a, F lies in[−L,−1], F(nu)=−L,F(o)=−1.
Every geometric minorant has g(o)≤−L; the constant barrier attains it.
Thus p(o)=h_m(o)=−L for EVERY canonical degree, while approaching raw
values are at least−1−a. The uniform error lower bound is L−1−a and
persists if2 epsilon is smaller. This failure is NONNORMAL and does not
assume source envelope regularity.

For P=t^p+t^(p+1), the derivative t^p is nonzero. The exact characteristic-p
identity factors the difference as b[b^(p−1)(1+s+b)+s^p]. The unit factor
forces a=p/(p−1); L=4 gives p(o)=−4 and every-degree gap
3−p/(p−1)≥1, including p=2. No perfection or roots of unity in k are needed;
the conjugate may lie in the finite extension. Gauge transport continues
in the next interval. The proof remains UNVERIFIED pending current
independent receipt and dependency clearance.
