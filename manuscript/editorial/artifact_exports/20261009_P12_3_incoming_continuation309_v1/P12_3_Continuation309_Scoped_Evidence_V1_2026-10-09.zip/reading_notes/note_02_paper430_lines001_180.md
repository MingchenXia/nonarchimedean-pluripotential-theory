# Paper430 current core: actual lines1–180

Read the full displayed interval at pinned research commit9556f416.
No retained companion, primary-source pixel or native five-field proof
reading credit is created by this interval.

The cones are independently geometric REAL Cartier presentations on actual
primary blowups, nonnegative on every contracted proper integral curve,
followed by uniform completion and actual decreasing-net completion.
Full finite-injection positive descent/completion/gauge comparison are
qualified G331 dependencies. All prime supports and bottom conventions
remain essential. Nonempty formulas require positive-dimensional reduction.

Canonical A_m contain a boundary power, are unit-or-primary and integrally
closed by the unique-lowest-value contradiction in an ideal-integrality
equation. Finite ideals give continuous profiles; the actual primary blowup
has an effective Cartier exceptional divisor and negative divisor relatively
ample. Raw suprema and D suprema agree by rational approximation and the
compact directed-open-cover argument. Grading gives the all-degree bound
H_N−N M1/m≤h_m≤p. Continuity, greatest C/D minorant existence and uniform
canonical convergence are equivalent; no continuity of a raw supremum is
presumed in advance. Negative shifts give the obstacle Lipschitz bound.

The smooth source claim is expressly restricted to smooth affine CLOSED
germs over algebraically closed characteristic-zero fields and transported
completions. The printed proof invokes BFJ closed-simplex continuity,
ALL-retraction infima, divisorial/full-support testing through primary
truncations, completed-primary contraction and the equality of L-infinity
ideals. Thinness is bounded on one FIXED dual complex, not globally.
The real parameter t=m+C is retained to obtain K/m rather than falsely
rounding it away. Published smooth resolution, multiplier subadditivity and
Izumi remain disclosed imports. No new primary-source or recursive proof
audit of those inputs has occurred in this reader's interval.

The curve argument begins from finite local DVR centres and finite
conductor values on every branch; the next interval contains its final
envelope formula. Scope excludes arbitrary normal sources, positive-
characteristic smooth CE and higher-dimensional general CE. All candidate
deductions remain UNVERIFIED outside formal book theorem typography.
