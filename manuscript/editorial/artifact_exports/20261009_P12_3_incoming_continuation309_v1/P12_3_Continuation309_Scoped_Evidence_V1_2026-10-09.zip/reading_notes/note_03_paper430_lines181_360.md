# Paper430 current core: actual lines181–360

Read the complete displayed interval. The reduced-curve formula finishes
as min(f,0) branchwise and retains the distinction from literal CLD radial
classes. Instructions to rerun supplied programs are treated as source data;
no supplied program is executed or imported.

The invariant-inclusion argument assumes excellent REDUCED local R=S^G,
S finite over R and local finite-group action. No characteristic or
invertibility of group order is used in the orbit-fibre proof. For an actual
primary/unit ideal J, the coefficient ideal of the product of translated
generic generator linear forms is invariant, generator-independent,
unit-or-primary, and has value sum_sigma(w sigma)(J). For arbitrary support
the Gauss argument takes place in Frac(S/P), where the initial polynomial
product is nonzero. Primary powers guarantee a finite least coefficient.

The difference span of primary ideal gauges is a lattice: the displayed
IH+KJ identity has the correct minimum orientation. Boundary powers supply
constants, primary truncations distinguish full-support points, and the
two finite-subcover lattice approximation proves uniform density. Equal
integrals therefore give equal finite orbit measures and equal supports,
so EVERY restriction fibre is one orbit. Existence of lifts, compactness
and positive descent remain G331 imports. Ordinary topological quotient
openness supplies no positivity by itself. Orbit-averaged rational profiles
are represented by an actual coefficient ideal on its own primary blowup.

The affine fixed-point case proves invariant finiteness from orbit-polynomial
coefficients, normality in the fraction field, and uniqueness of the prime
over the fixed marked point. Localizing the finite algebra is therefore the
exact smooth closed source, with invariants equal to R. The formal case
does NOT assume algebraization: a power-series coefficient ring A0,
Artinian monomial residue representatives and recursively convergent
coefficients prove S finite over A0. R is a finite A0-submodule, hence
Noetherian, local and complete. Excellence/normality and the completed
smooth-source use continue in the next interval.

These are scoped original candidates, UNVERIFIED; no current independent
production receipt, recursive primary clearance or canonical status change.
