# Frozen reading-note typographic addendum

Note04, paragraph1 has a stray literal '+' after 'POSITIVE descent,'. Read
the sentence as 'POSITIVE descent, not fibre minimization, yields the target
greatest C/D envelope.' This is prose typography only; its frozen note and
receipt are preserved. No mathematical statement or source bytes change.
