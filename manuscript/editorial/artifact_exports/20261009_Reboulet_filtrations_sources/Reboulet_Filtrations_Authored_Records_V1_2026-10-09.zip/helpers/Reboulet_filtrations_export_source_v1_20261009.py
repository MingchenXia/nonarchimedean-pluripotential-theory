from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,zipfile

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Reboulet_filtrations_review_20261009';E=R/'manuscript/editorial'
O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
reading=json.loads((C/'actual_primary_reading_v1_20261009.json').read_text())
diag=json.loads((C/'exact_diagnostics_v1_20261009.json').read_text())
assert reading['actual_source_unique_pages']==39 and reading['actual_individually_displayed_matching_views']==20 and len(diag['families'])==12
for name,h in reading['preparation_record_SHA256'].items():
    prep=json.loads((C/name).read_text());assert sha(C/name)==h
    for n,pin in prep['protected_core_inputs'].items():assert sha(R/n)==pin
paths={k:E/f'Reboulet_filtrations_source_{k}_20261009.{ext}' for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
record=C/'source_checkpoint_v1_20261009.json'
owned=O/'Reboulet_Filtrations_Authored_Records_V1_2026-10-09.zip'
full=O/'Reboulet_Filtrations_Actual_Source_Evidence_V1_2026-10-09.zip'
dest=E/'artifact_exports/20261009_Reboulet_filtrations_sources'
assert not any(p.exists() for p in [*paths.values(),record,owned,full,dest])
draft=Path('/tmp/Reboulet_filtrations_source_review_draft_v1_20261009.md')
assert draft.exists() and len(draft.read_bytes())>12000
paths['review'].write_bytes(draft.read_bytes());assert sha(paths['review'])==sha(draft)
paths['reading_notes'].write_text('# Actual Reboulet 2026 revision source notes, 9 October 2026\n\nComplete pinned v2: 39 physical pages in twenty individually displayed matching views.\n'+''.join('\n---\n\n'+Path(v['note_path']).read_text() for v in reading['views']))
files={f'records/{p.name}':p for p in C.glob('*.json')}
for v in reading['views']:
    for k,folder in [('note_path','notes'),('observation_receipt_path','receipts')]:
        p=Path(v[k]);files[f'primary/{folder}/{p.name}']=p
files['manifests/manifest.json']=Path(prep['manifest_path'])
for p in sorted(Path('/tmp').glob('Reboulet_filtrations_*_v*_20261009.py')):files[f'helpers/{p.name}']=p
files['helpers/CM15_Reboulet_filtrations_acquire_primaries_v1_20261009.py']=Path('/tmp/CM15_Reboulet_filtrations_acquire_primaries_v1_20261009.py')
files[f'drafts/{draft.name}']=draft
for k in ['review','reading_notes']:files[f'editorial/{paths[k].name}']=paths[k]
def archive(target,entries):
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,p in sorted(entries.items()):z.write(p,n)
    with zipfile.ZipFile(target) as z:
        assert len(z.namelist())==len(entries) and z.testzip() is None
        for n,p in entries.items():assert z.read(n)==p.read_bytes()
archive(owned,files)
fullfiles=dict(files)
for extension in ['pdf','txt','abs.html']:
    p=C/f'Reboulet_2508.16322v2.{extension}';fullfiles[f'primary/{p.name}']=p
for v in reading['views']:
    for k,folder in [('image_path','images'),('selected_text_path','text')]:
        p=Path(v[k]);fullfiles[f'primary/{folder}/{p.name}']=p
archive(full,fullfiles)
artifacts={k:dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p),members=count) for k,p,count in [('authored_records_archive',owned,len(files)),('cloud_complete_source_evidence_archive',full,len(fullfiles))]}
paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete pinned 2026 revision reading and qualified ordinary source audit',actual_reading=reading,exact_diagnostics=diag,artifacts=artifacts,active_book_changed=False,native_editor_changed=False,GitHub_published=False,canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — every archive member byte-verified',artifacts=artifacts,reading_credit_from_export=0,external_primary_PDF_text_images_uploaded=False,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
dest.mkdir(parents=True);target=dest/owned.name;shutil.copyfile(owned,target);assert sha(target)==sha(owned)
(dest/'SHA256SUMS').write_text(sha(target)+'  '+target.name+'\n')
(dest/'README.md').write_text(f'''# Reboulet 2026 filtration revision checkpoint, 9 October 2026

All 39 physical pages of arXiv:2508.16322v2 were actually read in order
with complete text, twenty individually displayed matching images and
chronological notes/receipts. Twelve elementary diagnostic families
check probability/determinant signs and factors, degree/power conventions,
the actual bounded graded class, selected rays, strong convergence,
stop-loss shifts, flat function domains and completion dependencies.

The finite product-gauge envelope admits direct infinity comparisons.
The intended general radial and flat conclusions remain qualified:
monotone boundedness alone does not give strong graded convergence, and
finite-degree spectral values need not lie in the limiting support.
These diagnostics do not refute the intended corrected main theorems.
No original general theorem or independent model receipt is claimed.

The {len(files)}-member authored archive pins notes, receipts, diagnostic
calculations, records, helpers and the audit. The separate {len(fullfiles)}-member
cloud archive also retains external PDF, full text, images and metadata.
Only authored evidence is in this GitHub checkpoint. An initial rational
JSON serialization failure and its dependent finalizer failure are frozen;
fresh v2 passes with exact rational strings. Failures, preparation, export
and upload supply zero reading credit. The arXiv stamp is 3 March 2026;
the internal title page says 4 March 2026.

The 4,661-page book, core inputs, bibliographies, native editor and canonical
42 atoms/twelve problem statuses stay unchanged. General BJ22 critical
homogeneous Siu/envelopes remain OPEN, LPWZ density UNVERIFIED, and the
BJ22 Theorem 6.21 proof warning remains binding. The last complete ordered
whole-book pass remains the 4 October pass. Publication has a separate
later expected-head and remote byte-verification record.
''')
readme=R/'README.md';s=readme.read_text();marker='**Latest Chen–Maclean spectral primary checkpoint, 9 October 2026:**';assert s.count(marker)==1
intro='''**Latest Reboulet 2026 filtration revision checkpoint, 9 October 2026:**
the [complete primary audit](manuscript/editorial/Reboulet_filtrations_source_review_20261009.md)
reads all 39 pages of arXiv:2508.16322v2 in twenty individual matching
displays. Twelve elementary diagnostic families check calibrated finite
norm actions and the separate graded/radial/flat proof interfaces.
Monotone boundedness does not alone imply strong graded convergence;
finite-degree spectral values can lie outside the limiting support.
The [authored evidence](manuscript/editorial/artifact_exports/20261009_Reboulet_filtrations_sources/README.md)
preserves the notes and exact diagnostics. The intended corrected main
theorems remain qualified pending their original dependencies. The book,
native editor and canonical statuses stay unchanged; upload adds no
reading or independent-verification credit.

''';readme.write_text(s.replace(marker,intro+marker,1))
programme=E/'second_reading_and_research_programme_20261002.md';s=programme.read_text();marker='## Latest Chen–Maclean spectral source checkpoint, 9 October 2026\n';assert s.count(marker)==1
intro='''## Latest Reboulet 2026 filtration revision source checkpoint, 9 October 2026

The [complete source audit](Reboulet_filtrations_source_review_20261009.md)
reads all 39 physical pages of arXiv:2508.16322v2 with complete text,
twenty individual matching image displays and chronological notes.
The external version stamp is 3 March 2026; the internal title page is
4 March. Twelve exact elementary diagnostic families pass. Initial
rational-number JSON serialization and dependent finalization failures
are frozen with zero output/credit; fresh v2 passes without changing
the primary source or actual notes.

The finite product-gauge envelope gives direct infinity contraction;
determinant means, relative spectral signs and power scaling are
calibrated explicitly. The general graded/radial/flat conclusions remain
qualified: the literal boundedness definition is vacuous, an increasing
linearly bounded graded family can fail strong convergence, and finite
spectral values need not lie in the limiting measure support. These
diagnostics do not refute the intended corrected main theorems.
Parreau's selected-ray apartment input, full scalar-extension/root-limit
compatibility, RWN25's admissible function construction and completion
injectivity/finite-energy identifications remain explicit source gates.

The [authored archive](artifact_exports/20261009_Reboulet_filtrations_sources/README.md)
preserves notes, receipts, calculations and helpers; the cloud archive
also keeps the external primary PDF/text/images. Upload/export add zero
credit. The 4,661-page book, 425 core inputs, bibliographies, native editor,
42 atoms/twelve problem statuses and last complete ordered 4 October
pass stay unchanged. General BJ22 critical Siu/envelopes remain OPEN,
LPWZ density UNVERIFIED, and the BJ22 Theorem 6.21 warning remains binding.
No original general theorem or independent-model receipt is claimed.

Continue cloud-only with RWN25's actual revised support/function domain,
Parreau 2000 Proposition 2.18, BE21 Theorem 9.5, the underlying analytic
coefficient/lattice inputs and exact published comparison editions.
Check incoming author research and regularly push verified authored
evidence. Xean stays suspended.

''';programme.write_text(s.replace(marker,intro+marker,1))
published=[*paths.values(),*sorted(dest.iterdir()),readme,programme];assert len(published)==9
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete pinned source checkpoint and byte-verified authored artifacts exported',editorial_files={str(p.relative_to(R)):dict(SHA256=sha(p),bytes=p.stat().st_size) for p in published},artifacts=artifacts,actual_primary_pages=39,actual_matching_views=20,active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],GitHub_published=False,helper_source=__file__)
record.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],files=9,owned_members=len(files),cloud_members=len(fullfiles),record_SHA256=sha(record))))
