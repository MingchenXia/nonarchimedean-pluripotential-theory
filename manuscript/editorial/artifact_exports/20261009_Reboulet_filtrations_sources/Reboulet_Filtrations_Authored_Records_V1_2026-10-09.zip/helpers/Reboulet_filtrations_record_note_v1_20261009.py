# Adapted frozen note helper SHA256: 12e88ffe8d35f82a21acabd18672f87729fc0b0eecd6ff6eb42f5591b6d22458
from pathlib import Path
from datetime import datetime, timezone
import sys, json, hashlib
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Reboulet_filtrations_review_20261009')
W=Path('/tmp/Reboulet_filtrations_primary_views_v1_20261009')
N=C/'primary_notes_v1'
number=int(sys.argv[1]); rows=json.loads((W/'manifest.json').read_text())
assert 1<=number<=len(rows)
p=N/f'note_{number:02d}.md'; r=N/f'note_{number:02d}_receipt.json'
assert not p.exists() and not r.exists()
if number>1: assert (N/f'note_{number-1:02d}_receipt.json').exists()
row=rows[number-1]; sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not row['actually_viewed'] and not row['selected_text_read']
assert sha(row['path'])==row['image_SHA256'] and sha(row['selected_text_path'])==row['selected_text_SHA256']
body=sys.stdin.read()
assert len(body)>150 and 'Read the complete selected text and displayed matching rendered image.' in body
stamp=datetime.now(timezone.utc).isoformat()
p.write_text(f'# Reboulet filtrations actual primary view {number:02d}\n\nUTC: {stamp}. Physical pages: '+', '.join(map(str,row['physical_pages']))+'.\n\n'+body.rstrip()+'\n')
obj=dict(number=number,UTC=stamp,physical_pages=row['physical_pages'],source_PDF_SHA256=row['source_PDF_SHA256'],image_path=row['path'],image_SHA256=row['image_SHA256'],selected_text_path=row['selected_text_path'],selected_text_SHA256=row['selected_text_SHA256'],complete_selected_text_actually_read=True,matching_image_individually_displayed_and_reviewed=True,note_path=str(p),note_SHA256=sha(p),reading_credit=len(row['physical_pages']),not_an_independent_model_receipt=True,whole_primary_PDF_reading_claim=False,whole_book_new_reading_claim=False,preparation_flags_unchanged=True,helper_source=__file__)
r.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(number=number,pages=row['physical_pages'],receipt_SHA256=sha(r))))
