# Reboulet filtrations actual primary view 01

UTC: 2026-10-09T03:04:48.328042+00:00. Physical pages: 1, 2.

Read the complete selected text and displayed matching rendered image.

The controlling recent source is Reboulet arXiv:2508.16322v2, stamped 3 March 2026, 39 physical pages; the title page internally says March 4, 2026. The introduction distinguishes norms homogeneous for the given absolute value from filtration norms homogeneous for the trivial absolute value on the same vector space. Their underlying ground categories are not identified. The introductory infinity-distance display must range over nonzero vectors, or use an explicit zero convention, to avoid 0/0. Finite-p distances are described by normalized absolute spectral moments, and the CAT(0) and earlier pluripotential correspondences are external cited inputs, not established by the abstract. The table of contents identifies finite-dimensional action/continuity/rays, then graded action/radial spectra/flatness and completion; the updated section 2.6 and corrected-ray argument require actual reading later. Both whole rendered pages and the arXiv/version/date stamps were inspected; this supplies only the actual two-page reading scope so far.
