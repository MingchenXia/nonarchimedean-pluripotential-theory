# Reboulet filtrations actual primary view 03

UTC: 2026-10-09T03:05:43.889585+00:00. Physical pages: 5, 6.

Read the complete selected text and displayed matching rendered image.

The author identifies several genuine further directions rather than settled consequences: contraction/Busemann convexity for general dp, a two-point apartment picture beyond constructed flat cones, geodesic lines in the graded norm space, and pluripotential characterization of Ep for p>1. These are source research directions, not changes to the book's canonical 42-atom inventory. The pluripotential discussion explicitly still involves continuity of envelopes and BJ22/BJ25; our binding BJ22 6.21 proof warning cannot be bypassed by this mention. The convention section fixes Cauchy-complete ultrametric ground fields and distinguishes the trivial-valuation zero subscript from evaluation of a ray at time zero. The finite-dimensional formal setup has a genuine partial order, multiplication by exp(c) translating norms, and scaling the trivial norm by its t-th power only for t>0. At t=0 on nonzero vectors a separate convention is needed if the action is extended there; 0^0 at the zero vector must not be read literally. The final order-completeness assertion continues onto the next page. Both full pages and all source research boundaries were actually reviewed; no abstract claim has been promoted.
