# Reboulet filtrations actual primary view 19

UTC: 2026-10-09T03:21:33.207726+00:00. Physical pages: 37, 38.

Read the complete selected text and displayed matching rendered image.

Physical pages 37–38 are references, actually read and visually checked. They identify CM15 as the 2015 manuscripta mathematica publication, volume 146(3–4), pages 365–394; the completed upstream review in this repository concerns arXiv 1304.5842v3, not the published 2015 edition. The present source's citation to that publication therefore still requires edition comparison before asserting exact published proof correspondence.

The finite building dependency Par00 is Anne Parreau's 2000 contribution, pages 263–302 in Crystallographic groups and their generalizations II. The source's Proposition 2.18 citation has not been primary-read here. Gerardin's cited 1981 chapter spans pages 138–178, so the earlier locator page 162 is bibliographically plausible but not independently audited.

Reb21a is the 2021 published Mathematische Zeitschrift article 299(3–4):2341–2378; the existing complete review covers the 2020 arXiv v1 and cannot be relabelled as the published edition. Reb22 is J. Reine Angew. Math. 793:59–103 (2022), the external geodesic convexity input cited in the present proof. RWN25 is Reboulet and Witt Nystrom, Infinite-dimensional flats in the space of positive metrics on an ample line bundle, IMRN 2025(22), article rnaf342, 17 pages. Its actual primary function-domain and norm construction need to be read to assess §2.6.

Finski's section-ring article is cited as arXiv 2209.03853v2, whereas Submultiplicative norms and filtrations on section rings is the 2025 PLMS article 131(2):e70077. Darvas–McCleerey's Lines in the space of Kahler metrics is cited as arXiv 2507.17375 (2025). These are related directions for later primary-source acquisition, not newly verified results. No theorem credit is assigned merely from these bibliography entries.
