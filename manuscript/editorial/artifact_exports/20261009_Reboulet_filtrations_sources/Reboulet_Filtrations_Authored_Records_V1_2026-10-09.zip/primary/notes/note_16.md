# Reboulet filtrations actual primary view 16

UTC: 2026-10-09T03:19:34.787585+00:00. Physical pages: 31, 32.

Read the complete selected text and displayed matching rendered image.

Physical pages 31–32 continue Proposition 2.12 and begin the stop-loss-transform proof of Theorem 2.10. The continuation relies explicitly on the strong d_infinity convergence asserted on page 30: it calls the limit a geodesic because it is a d_infinity limit of geodesics, and passes the signed volume to the limit using its d_infinity Lipschitz property. Thus these pages do not supply the missing uniform-in-degree convergence argument. The minimality and identification of the direction as F maximum G are coherent conditional on having constructed the selected ray and having the direction-to-ray reconstruction at this diagonal initial norm. The sentence referring to the 'third part' when using the minimality proof should refer to the second part.

The proof of Theorem 2.10 uses the continuous stop-loss test max(x,c), rather than discontinuous distribution-function tests. Under a genuine uniform spectral support bound, convergence of these transforms determines the probability law; CM15 Proposition 5.1 is the cited input. The correct truncation identity with the source convention lambda=log(norm prime/norm) is integral max(x,c) d sigma(F,G)=vol(F, exp(c times degree)F maximum G).

The graded scalar bookkeeping in the second chain needs correction. Writing A(F,eta) for the action, the identity is exp(tc times degree) A(tF,eta)=A(t(exp(c times degree)F),eta), where tF denotes the t-th power of the trivially valued norm. Equivalently t(exp(c times degree)F)=exp(tc times degree)(tF). The displayed chain instead writes t applied to exp(tc times degree)F; under its own power convention this introduces t squared c, not tc. The same incorrect scaled direction then enters the final displayed volume. This is a separate explicit scalar diagnostic, not merely a problem with extracted text; the rendered image shows the tc exponent inside the powered direction. The first equality integral max(x/t,c)=t^{-1} integral max(x,tc) is correct.

These observations mark a conditional source proof and literal normalization corrections. They do not assert that the intended radial spectral convergence or quotient isometry is false, and do not close any canonical open problem. No independent hostile-model receipt is claimed.
