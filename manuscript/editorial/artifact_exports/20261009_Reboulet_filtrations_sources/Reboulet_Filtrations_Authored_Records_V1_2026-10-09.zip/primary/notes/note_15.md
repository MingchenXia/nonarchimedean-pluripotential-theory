# Reboulet filtrations actual primary view 15

UTC: 2026-10-09T03:18:54.427064+00:00. Physical pages: 29, 30.

Read the complete selected text and displayed matching rendered image.

Physical pages 29–30 finish Lemma 2.9 and begin §2.5. The same-direction ray comparison is bounded independently of time by the distance between the initial graded norms, using the action contraction. Dividing by time gives the claimed zero radial distance, provided the graded norms belong to a genuinely linearly bounded reference class.

Theorem 2.10 claims convergence of the rescaled relative spectral measures for the two associated rays. Corollary 2.11 identifies the finite-p radial quotient with the trivially valued graded-norm quotient; here the second limiting norm is correctly primed. Proposition 2.12 is the central volume-of-maximum asymptotic statement. Its proof considers the selected geodesic from the common initial norm to the maximum of the two ray endpoints at time t. At a fixed s, the resulting norm C_{t,s} increases with t by the maximum principle.

The proof then claims that this increasing family converges in the strong graded d_infinity metric, and invokes Proposition 2.1(4), saying it suffices to establish a uniform d_infinity bound. That proposition establishes that the supremum is a bounded graded norm; it does not by itself establish uniform convergence over all section degrees. The displayed bound, proportional to s times fixed distances of the two directions, correctly establishes boundedness, but supplies no uniform tail estimate in the degree m.

A direct diagnostic of the general inference is available without making any claim about this special chord family: on the section ring of (P1,O(1)) with Gauss graded norm eta, set zeta^{(k)}_m=exp(min(m,k)) eta_m, degree zero unchanged. Since min(m+n,k) <= min(m,k)+min(n,k), these are submultiplicative graded norms. They increase with k, and 0 <= log(zeta^{(k)}_m/eta_m) <= m gives a common valid linear bound. At each fixed degree they converge to zeta_m=exp(m) eta_m. Nevertheless the strong distance from zeta^{(k)} to zeta is sup_{m>=1}(m-min(m,k))/m=1 for every finite k. Thus monotone boundedness alone does not give the claimed strong convergence. This does not disprove Proposition 2.12 or show that its specific constructed family behaves this way. A separate convergence argument or a weaker topology with sufficient volume control remains necessary; the continuation of the proof must be checked before importing the conclusion.

The section remains a source audit, with no new general theorem or open-problem resolution claimed, and no independent hostile-model receipt.
