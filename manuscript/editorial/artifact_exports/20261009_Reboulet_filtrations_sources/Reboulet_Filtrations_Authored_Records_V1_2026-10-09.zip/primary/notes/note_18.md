# Reboulet filtrations actual primary view 18

UTC: 2026-10-09T03:21:13.980624+00:00. Physical pages: 35, 36.

Read the complete selected text and displayed matching rendered image.

Physical pages 35–36 give §2.7 and the first part of the references. The formal metric completions N^p and N^p_0 are legitimate once the underlying finite-p pseudometric quotient has been specified correctly. An established isometry extends uniquely to completions, so that step is conditional on the previously claimed radial isometry. The displayed inclusions of the completions for q>=p require an injectivity argument: d_p<=d_q gives a continuous map of completions, but metric domination by itself does not prove that this map is injective. The source calls the inclusions clear without supplying the additional structure; this is a dependency to verify, not a disproof of the intended graded-norm inclusions.

The pluripotential interpretation is explicitly conditioned on the envelope property. The identification of N^1 with E^1 is attributed to adapting BJ22 Theorem 12.8 with the synthetic inputs of BJ25. No proof of this adapted nontrivially valued identification appears here. It must not be promoted into an independently checked result, and the user's warning concerning the proof of BJ22 Theorem 6.21 remains binding when tracing dependencies. The same caution applies to the trivially valued completion and to extending the finite-dimensional action to finite-energy spaces. The paragraph itself says that p>1 lacks a pluripotential characterization; it does not resolve the corresponding research direction.

The historical known-envelope cases cite Thuillier and BFJ16. Any book import must recover the original field, smoothness, and residue-characteristic assumptions from those primary results, rather than reuse the phrase 'local of equal characteristic zero' as an unchecked general hypothesis.

The reference pages confirm BE21 as Advances in Mathematics 378:107501 (2021), BJ22 as the published 2022 Toulouse article, and BJ25 as the 2025 synthetic finite-energy contribution in Convex and complex, pages 159–208. Published references do not convert an unaudited dependency into reviewed evidence. This is an actual review of these physical pages only, with no new whole-book reading or independent hostile-model receipt.
