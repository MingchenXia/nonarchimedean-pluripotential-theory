from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BE21_supnorm_basechange_review_20261009'
out=C/'actual_primary_reading_v1_20261009.json'; assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sets=[('primary_view_preparation_v1_20261009.json',C/'primary_notes_v1'),('supplement_view_preparation_v1_20261009.json',C/'supplement_notes_v1')]
views=[];pages=[];pins={};last=None
for name,N in sets:
    p=C/name;prep=json.loads(p.read_text());pins[name]=sha(p)
    assert prep['actual_source_reading_credit']==prep['actually_read_pages']==0
    assert sha(prep['source_PDF']['path'])==prep['source_PDF']['SHA256']
    mp=Path(prep['manifest_path']); assert sha(mp)==prep['manifest_SHA256']
    rows=json.loads(mp.read_text()); assert len(rows)==prep['prepared_views']
    for i,row in enumerate(rows,1):
        receipt=N/f'note_{i:02d}_receipt.json';a=json.loads(receipt.read_text())
        assert a['number']==i and a['physical_pages']==row['physical_pages']
        assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
        assert last is None or a['UTC']>last
        last=a['UTC']
        assert not row['actually_viewed'] and not row['selected_text_read']
        for k,h in [('image_path','image_SHA256'),('selected_text_path','selected_text_SHA256'),('note_path','note_SHA256')]:
            assert sha(a[k])==a[h]
        assert a['source_PDF_SHA256']==prep['source_PDF']['SHA256']==row['source_PDF_SHA256']
        assert 'Read the complete selected text and displayed matching rendered image.' in Path(a['note_path']).read_text()
        views.append(dict(batch=name,**a,observation_receipt_path=str(receipt),observation_receipt_SHA256=sha(receipt)))
        pages.extend(row['physical_pages'])
    for n,h in prep['protected_core_inputs'].items(): assert sha(R/n)==h
    assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==prep['baseline_commit']
assert len(views)==6 and len(pages)==len(set(pages))==11
previous=R/'source_material/local_psh_dependencies_review_20261008/actual_BE21_selected_reading_v1_20261008.json'
prior=json.loads(previous.read_text());old=set(prior['selected_physical_pages']);new=set(pages)
assert len(old)==29 and old&new=={22,23} and len(new-old)==9 and len(old|new)==38
d=C/'exact_diagnostics_v1_20261009.json';diag=json.loads(d.read_text())
assert len(diag['families'])==4 and all(a['status'].startswith('PASS') for a in diag['families'])
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — eleven selected primary pages freshly read; partial published PDF',
    source_PDF=prep['source_PDF'],actual_source_unique_pages=11,actual_individually_displayed_matching_views=6,
    selected_physical_pages=sorted(new),views=views,preparation_record_SHA256=pins,
    exact_diagnostics_SHA256=sha(d),previous_partial_reading_record_SHA256=sha(previous),
    new_unique_pages_relative_to_prior_checkpoint=9,overlap_pages_freshly_read=[22,23],
    cumulative_distinct_pages_in_these_two_checkpoints=38,cumulative_distinct_page_list=sorted(old|new),
    remaining_primary_pages_not_read_in_these_two_checkpoints=87,
    complete_selected_text_read=True,preparation_flags_unchanged=True,whole_primary_PDF_reading_claim=False,
    active_book_changed=False,native_editor_changed=False,book_PDF_SHA256=sha(R/'manuscript/book.pdf'),
    baseline_commit=prep['baseline_commit'],primary_attested_inputs=['Theorem 6.6 and its complete printed proof','Theorem 6.4 and finite-family Theorem 6.5','Proposition 1.25 including corrected pairwise-ratio interpretation','Lemma 1.26 countable norm extension','Lemma 1.29(iv) lattice scalar extension'],
    earlier_inputs_not_recursively_certified=['Earlier norm diagonalization/density and joint-basis inputs','Shilov/reduced-fibre Theorems 4.19–4.20 and classical foundations','A.6 coherence and finite special-fibre supported quotient annihilation','Model existence/pullback Lemmas 5.8 and 5.10','Complete Theorem 8.12 logarithmic integrability and classical flattening'],
    general_local_weak_psh_or_affine_regularization_admitted=False,general_envelope_theorem_admitted=False,
    canonical_status_changes=[],original_results_promoted=[],independent_model_receipt=None,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],pages=11,views=6,new_distinct_pages=9,cumulative_distinct_pages=38,record_SHA256=sha(out))))
