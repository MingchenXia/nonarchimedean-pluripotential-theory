from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, zipfile

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BE21_supnorm_basechange_review_20261009'
E=R/'manuscript/editorial'
O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
reading=json.loads((C/'actual_primary_reading_v1_20261009.json').read_text())
diag=json.loads((C/'exact_diagnostics_v1_20261009.json').read_text())
assert reading['actual_source_unique_pages']==11 and reading['actual_individually_displayed_matching_views']==6
assert len(diag['families'])==4
for name in reading['preparation_record_SHA256']:
    prep=json.loads((C/name).read_text())
    assert sha(C/name)==reading['preparation_record_SHA256'][name]
    for n,h in prep['protected_core_inputs'].items():assert sha(R/n)==h
paths={k:E/f'BE21_supnorm_basechange_source_{k}_20261009.{ext}' for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
record=C/'source_checkpoint_v1_20261009.json'
owned=O/'BE21_Supnorm_Basechange_Authored_Records_V1_2026-10-09.zip'
full=O/'BE21_Supnorm_Basechange_Actual_Source_Evidence_V1_2026-10-09.zip'
dest=E/'artifact_exports/20261009_BE21_supnorm_basechange_sources'
assert not any(p.exists() for p in [*paths.values(),record,owned,full,dest])
paths['review'].write_text(r'''# Section supnorms under complete field extension: exact asymptotic scope

Date: 9 October 2026. Controlling source: Boucksom--Eriksson, *Spaces
of norms, determinant of cohomology and Fekete points in non-Archimedean
geometry*, published in Advances in Mathematics 378 (2021), 107501.
The cached Chalmers PDF has 125 physical pages, including its cover.
This checkpoint actually reads physical pages 20--24 and 55--60, eleven
pages in six individually displayed matching views with full text and
sequential notes. Pages 22--23 overlap the preceding 29-page checkpoint:
only nine are new distinct pages, giving 38 distinct pages across those
two checkpoints, with 87 not read in that combined scope. This is not
a whole-paper claim. Acquisition or view preparation gives zero reading credit.

## The precise global estimate

Section 6 assumes a projective scheme over a complete valued field and a
line bundle. Theorem 6.6, physical pages 59--60, assumes geometric
reducedness and a continuous metric. For an arbitrary complete field
extension $F/K$, the section supnorms satisfy

$$
d_\infty\!\left(\|\cdot\|_{m\phi_F},
                 (\|\cdot\|_{m\phi})_F\right)=o(m).
$$

For a model metric, or an Archimedean field, the error is $O(1)$.
Neither ampleness nor pshness is assumed for this norm estimate.
The constants are for the fixed source data; uniformity over varying
metrics or field extensions is not supplied by this statement.

Lemma 6.1 preserves the norm on the original $K$-sections but gives
only $\|\cdot\|_{\phi_F}\le (\|\cdot\|_\phi)_F$ on the full extended
section space. Lemma 6.2's exact equality for every bounded metric is
equivalent to tameness in the finite Galois, nontrivially discretely
valued setting. Its external Galois-norm and spectral-norm sources are
attributed and not recursively certified here. Neither lemma licenses
exact equality for all extensions and all section norms.

For model metrics, Theorem 6.4 takes a finite model map with reduced
special fibre. A coherent quotient supported on that fibre is killed by
one scalar, giving a multiplicative norm comparison constant independent
of tensor power. Theorem 6.5 extends this to a finite family on a common
model and $r$-fold products, with bound $C^r$. The denominator-remainder
step in Theorem 6.6 uses this finite-family bound, or the same quotient
argument, for $q\mathcal L+r\mathcal M$. A fixed finite number of small
or zero-exponent cases is handled separately. Lemma 1.29(iv), physical
pages 23--24, is the actual lattice scalar-extension statement.

For continuous metrics over a nontrivially valued field, uniform model
approximation gives $C_\varepsilon+2m\varepsilon$. Dividing by $m$ gives
$\limsup E_m/m\le 2\varepsilon$; letting $\varepsilon$ tend to zero
proves the claimed sublinear limit. The printed intermediate bound
$\le\varepsilon$ misses a factor two, without invalidating that conclusion.
No uniform rate follows without controlling $C_\varepsilon$.

For trivially valued fields, Lemma 1.26 chooses a Laurent-series extension
whose valuation step avoids the countable rational span of weight
differences. A common further extension and the isometry in Proposition
1.25 complete the argument. This is a countable family of finite-dimensional
norms, not an assertion about a dense subfield of every complete field.

## The printed uniqueness condition and an exact diagnostic

Proposition 1.25(v), physical page 21, prints the same index in the ratio
$\|e_i\|/\|e_i\|$. Its proof on pages 21--22 uses different basis weights.
The intended condition is

$$
\{\|e_i\|/\|e_j\|:1\le i,j\le N\}\cap |F^\times|=\{1\},
\qquad \widetilde F=\widetilde K.
$$

The literal same-index condition is tautological and insufficient.
Take $K=\mathbf Q$ with trivial absolute value and $F=\mathbf Q((t))$
with $|t|=1/2$. On $K e_1\oplus K e_2$ use weights $1/2,1$.
The maximal extension has norm

$$
\|a e_1+b e_2\|_F=\max\{\tfrac12|a|,|b|\}.
$$

Use instead the basis $u=e_1-t e_2,e_2$ with weights $1/4,1$:

$$
\|a e_1+b e_2\|'=\max\{\tfrac14|a|,|ta+b|\}.
$$

For $a,b\in\mathbf Q$, if $b\ne0$ then $|ta+b|=1$; if $b=0$ and
$a\ne0$, then $|ta|=1/2$. Both norms thus restrict to the original
$K$-norm. On $e_1-t e_2$ their values are $1/2$ and $1/4$.
The residue fields are equal. The corrected pairwise condition fails
because $\|e_1\|/\|e_2\|=|t|$; this example does not refute that condition
or Lemma 1.26's intended proof.

## Other exact boundaries and printed slips

The finite extension $A=\mathbf Q[t][tx,x^2,x^3]\subset
A'=\mathbf Q[t][x]$ illustrates the product loss in Theorem 6.5.
The quotient is killed by $t$, whereas on $r$ tensor factors the monomial
$x_1\cdots x_r$ requires $t^r$ to enter the smaller tensor algebra.
Thus $t^{r-1}$ does not annihilate that quotient. This is a finite affine
algebra illustration, not a new global reduced-fibre theorem.

On $\operatorname{Spec} K[z]/(z^2)$ the nonzero section $z$ has zero
analytic sup-seminorm. Reducedness is needed to use norms and logarithmic
norm distance on the whole section space. This is outside Theorem 6.6.

Local printed clarifications: Lemma 6.3's proof says (iv) for (iii);
the model-quotient annihilator line has a stray $K'$ where the established
extension is $F$; Theorem 6.5's intermediate tensor inclusion leaves an
$A'$ in its final factor, whereas multiplying all factors gives the
stated $a^r$ conclusion; Theorem 6.6 cites Lemma 1.28 for the lattice
extension actually in 1.29(iv). Example 1.30 has stray $L/F$ notation;
only its explicit equality of value groups is used here.

The full printed proofs and the ordinary source audit are distinct from
recursive certification of every earlier foundation. Norm diagonalization
and density, Shilov/reduced-fibre Theorems 4.19--4.20, A.6 coherence,
model existence/pullback and the external classical inputs retain their
separate source scopes. Theorem 8.12 logarithmic integrability is not
newly read in this checkpoint.

## Remaining local comparison interfaces

Theorem 6.6 accommodates nondiscrete complete field extensions for the
stated global section-norm problem. It does not prove affine lower-growth
regularization over a completed residue field, convert a lower coercive
bound to an upper majorant, or prove local weak-psh descent. The norm
psh theorem's projective/geometrically reduced/ample/continuous scope
remains as in L.97. General BJ22 critical homogeneous Siu/envelopes remain
OPEN and LPWZ density UNVERIFIED. No original general theorem or independent
model receipt is asserted. The 4,657-page book, core sources and native
catalogue/editor are unchanged during this primary-source checkpoint.
''')
paths['reading_notes'].write_text('# Actual BE21 supnorm/base-change source notes, 9 October 2026\n\nEleven fresh selected pages in six matching displays; nine new distinct pages relative to the preceding checkpoint.\n'+''.join('\n---\n\n'+Path(v['note_path']).read_text() for v in reading['views']))
files={f'records/{p.name}':p for p in C.glob('*.json')}
for v in reading['views']:
    for k,folder in [('note_path','notes'),('observation_receipt_path','receipts')]:
        p=Path(v[k]);files[f'{v["batch"]}/{folder}/{p.name}']=p
for name in reading['preparation_record_SHA256']:
    p=Path(json.loads((C/name).read_text())['manifest_path']);files[f'manifests/{name}']=p
for p in Path('/tmp').glob('BE21_Supnorm_basechange_*_v1_20261009.py'):files[f'helpers/{p.name}']=p
for k in ['review','reading_notes']:files[f'editorial/{paths[k].name}']=paths[k]
with zipfile.ZipFile(owned,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,p in sorted(files.items()):z.write(p,n)
with zipfile.ZipFile(owned) as z:
    assert len(z.namelist())==len(files)
    for n,p in files.items():assert z.read(n)==p.read_bytes()
fullfiles=dict(files)
p=Path(reading['source_PDF']['path']);fullfiles['primary/Boucksom_Eriksson_2021_published.pdf']=p
for v in reading['views']:
    for k,folder in [('image_path','images'),('selected_text_path','text')]:
        p=Path(v[k]);fullfiles[f'{v["batch"]}/{folder}/{p.name}']=p
with zipfile.ZipFile(full,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,p in sorted(fullfiles.items()):z.write(p,n)
with zipfile.ZipFile(full) as z:
    assert len(z.namelist())==len(fullfiles)
    for n,p in fullfiles.items():assert z.read(n)==p.read_bytes()
artifacts={k:dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p),members=count) for k,p,count in [('authored_records_archive',owned,len(files)),('cloud_complete_source_evidence_archive',full,len(fullfiles))]}
paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — actual partial primary reading and ordinary source audit',actual_reading=reading,exact_diagnostics=diag,artifacts=artifacts,active_book_changed=False,native_editor_changed=False,GitHub_published=False,canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — byte-verified source exports',artifacts=artifacts,reading_credit_from_export=0,external_primary_PDF_text_images_uploaded=False,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
dest.mkdir(parents=True)
target=dest/owned.name;shutil.copyfile(owned,target);assert sha(target)==sha(owned)
(dest/'SHA256SUMS').write_text(sha(target)+'  '+target.name+'\n')
(dest/'README.md').write_text(f'''# Supnorm and complete-field extension primary checkpoint, 9 October 2026

The {len(files)}-member authored archive contains the ordinary source audit,
eleven-page/six-view actual notes and receipts, immutable preparation records,
four elementary diagnostic families and their helpers. Only nine pages are new
relative to the preceding 29-page checkpoint; the combined scope has 38 distinct
pages of the 125-page published PDF, leaving 87 unread in those two checkpoints.
This is not a whole-paper or book-pass claim.

The exact attributed estimate is o(m) for continuous metrics on projective
geometrically reduced schemes under arbitrary complete field extension, and
O(1) for model metrics or the Archimedean case. Original-section equality does
not imply equality on the extended section space. The printed uniqueness
condition needs pairwise weights; the displayed same-index condition has an
elementary counterexample. The epsilon-limit factor two and lattice locator
are corrected without rejecting the intended theorem.

External primary PDF/text/images stay in the separate {len(fullfiles)}-member
cloud evidence archive. SHA256SUMS pins this owned archive. Preparation,
export and upload supply zero extra reading credit. The 4,657-page book,
native catalogue/editor and 42-atom/twelve-problem inventory are unchanged.
General BJ22 critical homogeneous Siu/envelopes remain OPEN; LPWZ density
UNVERIFIED. No original general theorem or independent-model receipt is asserted.
Remote publication receives a separate subsequent verification record.
''')
readme=R/'README.md';s=readme.read_text();marker='**Latest verified model Green-current and norm GitHub publication, 9 October 2026:**';assert s.count(marker)==1
intro='''**Latest section-supnorm field-extension primary checkpoint, 9 October 2026:**
the [source audit](manuscript/editorial/BE21_supnorm_basechange_source_review_20261009.md)
reads eleven selected published BE21 pages in six individual matching displays.
It retains the exact projective/geometrically reduced/continuous o(m) estimate,
the stronger model O(1) estimate, pairwise norm weights and lattice locator.
Four elementary diagnostic families pass. The
[authored evidence](manuscript/editorial/artifact_exports/20261009_BE21_supnorm_basechange_sources/README.md)
distinguishes nine new pages from two overlaps with the preceding checkpoint.
No arbitrary local weak-psh or affine regularization theorem is imported;
the active book and native editor are unchanged during this source checkpoint.

''';readme.write_text(s.replace(marker,intro+marker,1))
programme=E/'second_reading_and_research_programme_20261002.md';s=programme.read_text();marker='## Latest model Green-current and norm GitHub publication, 9 October 2026\n';assert s.count(marker)==1
intro='''## Latest section-supnorm base-change source checkpoint, 9 October 2026

The [source audit](BE21_supnorm_basechange_source_review_20261009.md)
freshly reads published BE21 physical pages 20--24 and 55--60: eleven pages
in six individually displayed matching views with full text and sequential
notes/receipts. Two pages overlap the preceding selection; nine are new.
Those two checkpoints have 38 distinct pages, with 87 unread in their
combined scope. Four exact elementary diagnostic families pass.

Theorem 6.6 retains projectivity, geometric reducedness, continuity and
arbitrary complete field extension. Its section-norm distance is o(m), and
O(1) for model metrics or the Archimedean case; ampleness and pshness are
not assumptions of this norm estimate. Exact equality on original sections
is separated from comparison on the whole extended section space.
The printed norm-uniqueness condition needs pairwise weights, its intended
proof and Lemma 1.26 remain supported in that corrected scope, and the
factor-two epsilon line does not invalidate the final sublinear conclusion.
The lattice extension locator is Lemma 1.29(iv). Earlier reduced-fibre,
coherence and diagonalization foundations are attributed, not recursively
certified by this partial reading.

The [authored archive](artifact_exports/20261009_BE21_supnorm_basechange_sources/README.md)
retains actual notes, receipts, diagnostics and helpers; external primary
PDF/text/images remain in the cloud. Export/upload gives zero reading credit.
The 4,657-page book, 425 core TeX inputs, bibliographies, native catalogue/editor
and 42 atoms/twelve problems are unchanged during this source checkpoint.
General BJ22 critical homogeneous Siu/envelopes remain OPEN; LPWZ density
UNVERIFIED. No original general theorem or independent-model receipt is claimed.

Continue cloud-only by checking whether the exact asymptotic norm interface
can sharpen the existing local/global explanation without extending its
hypotheses. Then read the remaining reduced-fibre and logarithmic-integrability
inputs where they are load-bearing. Integrate qualified source material only
through the full build and actual rendered-book gates. Check incoming author
updates and periodically push checked evidence. Xean stays suspended.

''';programme.write_text(s.replace(marker,intro+marker,1))
published=[*paths.values(),*sorted(dest.iterdir()),readme,programme]
assert len(published)==9
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — primary checkpoint and byte-verified authored artifacts exported',
    editorial_files={str(p.relative_to(R)):dict(SHA256=sha(p),bytes=p.stat().st_size) for p in published},
    artifacts=artifacts,actual_primary_pages=11,actual_matching_views=6,new_distinct_pages=9,
    cumulative_distinct_pages_in_two_checkpoints=38,active_book_changed=False,native_editor_changed=False,
    canonical_status_changes=[],GitHub_published=False,helper_source=__file__)
record.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],files=9,owned_members=len(files),cloud_members=len(fullfiles),record_SHA256=sha(record))))
