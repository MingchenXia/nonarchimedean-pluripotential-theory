# Model Green currents and finite flat norms actual book view 14

UTC: 2026-10-09T00:45:29.718793+00:00. Physical pages: 4620, 4621.

Read the complete selected text and displayed matching rendered image. Physical pages 4620 and 4621 cover L through early O in the final index. The new norm metrics / finite flat morphisms subentry points to printed page 4323, correctly alongside the existing finite-locally-free norm entry. Model metric, minus-log/additive-weight, Monge--Ampere, multiplier-ideal, nonpluripolar, normalization and open-problem locators remain legible and separately organized. Long vector-space and normalized-volume subentries wrap within the two columns; special characters and mathematical notation render properly. This is a complete actual reading of final V3 navigation pages and their matching image, without proof claims for indexed results or partial-V2 reading reuse.
