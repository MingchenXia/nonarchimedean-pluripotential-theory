# Model Green currents and finite flat norms actual book view 16

UTC: 2026-10-09T00:45:54.196096+00:00. Physical pages: 4624, 4625.

Read the complete selected text and displayed matching rendered image. Physical pages 4624 and 4625 continue the Siu decomposition subentries from the preceding page and finish S through Y. They separate complex-surface residual and positive-pluriharmonic topics from the skeletal characterization locator; an index entry is not a claim that the general BJ22 decomposition proof is repaired. Skeleton, source-audit, strong-topology, toric, tropical, valuation and variational entries remain readable with intact mathematical and accented notation. Multi-line Monge--Ampere and sign-convention locators fit within their columns and the running heads are clean. This complete final V3 text/image reading checks typography and navigation only; no prior partial edition or indexed-proof certification is reused.
