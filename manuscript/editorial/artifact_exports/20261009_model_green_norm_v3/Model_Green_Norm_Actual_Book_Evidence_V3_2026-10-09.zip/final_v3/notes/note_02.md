# Model Green currents and finite flat norms actual book view 02

UTC: 2026-10-09T00:40:10.665007+00:00. Physical pages: 1213, 1214.

Read the complete selected text and displayed matching rendered image. Fresh final-v3 pages 1213–1214 retain the full hypothesis ledger and contain the entire new Chapter 17 Green-current paragraph. Its excellent-DVR regular-model category, own metrics/differential and required CLD comparison map are explicit; Dub26G and L.97 resolve. The regular-sequence hypothesis is correctly distinguished from blowup regularity, and no existing analytic Bochner–Martinelli statement is weakened or replaced. Surrounding CLD, curve/Tate and source locators remain readable. Both pages fit without clipping or overlap; the final v3 display is actually examined, with zero partial-v2 reuse.
