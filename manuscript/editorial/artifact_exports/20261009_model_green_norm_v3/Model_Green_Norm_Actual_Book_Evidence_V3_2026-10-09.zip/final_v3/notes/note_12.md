# Model Green currents and finite flat norms actual book view 12

UTC: 2026-10-09T00:45:11.168508+00:00. Physical pages: 4616, 4617.

Read the complete selected text and displayed matching rendered image. Physical pages 4616 and 4617 continue the final index from Berkovich tree entries through C, D and early E. The two-column hierarchy is readable, including multi-line Calabi--Yau, Chambert--Loir, comparison, current and Duistermaat--Heckman entries. Linked page numbers, subentry indentation, mathematical ddc and L-one notation render correctly; neither columns nor running heads overlap. This actual reading checks navigation and typography, not the proofs of all indexed topics. The complete final V3 text and matching image were inspected, and no earlier partial-book reading is substituted.
