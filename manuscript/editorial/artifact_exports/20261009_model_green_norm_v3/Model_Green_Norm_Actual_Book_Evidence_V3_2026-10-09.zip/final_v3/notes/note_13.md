# Model Green currents and finite flat norms actual book view 13

UTC: 2026-10-09T00:45:20.366421+00:00. Physical pages: 4618, 4619.

Read the complete selected text and displayed matching rendered image. Physical pages 4618 and 4619 cover the E-through-K index continuation. Envelope and finite-descent entries remain distinct from the newly added Green currents entry, whose regular model scope subentry points to printed page 4323, the start of L.97. Gauss extension, harmonic, Hessian, Hodge--Riemann, intersection and K-stability entries are legible with consistent indentation and page-link styling. Long subentries wrap inside their columns and mathematical notation is intact. This is an actual navigation and layout read of the full final V3 pages, not proof credit for the indexed topics and not reused V2 reading.
