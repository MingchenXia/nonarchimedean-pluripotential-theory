# Model Green currents and finite flat norms actual book view 15

UTC: 2026-10-09T00:45:43.803864+00:00. Physical pages: 4622, 4623.

Read the complete selected text and displayed matching rendered image. Physical pages 4622 and 4623 continue O through S index entries, including separate local-growth psh functions, local/global psh metric, pluriharmonic-current, regularization and provenance locators. The BFJ, BJ, CLD and other psh subentries retain their distinct page references and hierarchy. The Siu decomposition heading at the end of page 4623 continues onto the following index page; no theorem status is inferred from this locator. The entire text and both final V3 rendered columns were inspected: long subentries, mathematical I/P notation and page-number links are readable and fit. This is navigation/layout review only, with no whole-book or earlier-version reading credit claimed.
