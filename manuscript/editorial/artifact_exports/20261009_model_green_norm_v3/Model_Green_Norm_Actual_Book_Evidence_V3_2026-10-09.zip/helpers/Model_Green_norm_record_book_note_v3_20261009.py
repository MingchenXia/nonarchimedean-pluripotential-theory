# Frozen preceding v2 helper SHA256: d7c42fe82fe393a8bed09b09efd89e8195c531abd2776a135787be4b40d2230e
# Frozen preceding v1 helper SHA256: 42c38eb33f60756941cd8b1faf26184e9e910c2b4a672754ed899c8e58e401d6
# Frozen note helper template SHA256: 78f382a4c038ce2fa87c5b17739855075bb3be54aef6e3a065284730a7fe43e6
# Frozen preceding v2 helper SHA256: 1a3a5a4b05d090a59e9594049671114a1ff000dbb8056522f9c1540f7ab493da
# Book note template SHA256: 3e8e42e9f85ca62650b6a2a312ab8c719924c73c64dfb1c8573859b1d40c5b57
from pathlib import Path
from datetime import datetime,timezone
import sys,json,hashlib
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Dubocs_Green_currents_review_20261008');W=Path('/tmp/Model_Green_norm_staged_book_views_v3_20261009');N=C/'staged_book_notes_v3'
number=int(sys.argv[1]);assert 1<=number<=len(json.loads((W/'manifest.json').read_text()))
p=N/f'note_{number:02d}.md';receipt=N/f'note_{number:02d}_receipt.json';assert not p.exists() and not receipt.exists()
if number>1:assert (N/f'note_{number-1:02d}_receipt.json').exists()
row=json.loads((W/'manifest.json').read_text())[number-1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(Path(row['path']))==row['image_SHA256'] and sha(Path(row['selected_text_path']))==row['selected_text_SHA256']
body=sys.stdin.read();assert len(body)>150 and 'Read the complete selected text and displayed matching rendered image.' in body
stamp=datetime.now(timezone.utc).isoformat();p.write_text(f'# Model Green currents and finite flat norms actual book view {number:02d}\n\nUTC: {stamp}. Physical pages: '+', '.join(map(str,row['physical_pages']))+'.\n\n'+body.rstrip()+'\n')
obj=dict(number=number,UTC=stamp,physical_pages=row['physical_pages'],source_PDF_SHA256=row['source_PDF_SHA256'],image_path=row['path'],image_SHA256=row['image_SHA256'],selected_text_path=row['selected_text_path'],selected_text_SHA256=row['selected_text_SHA256'],complete_selected_text_actually_read=True,matching_image_individually_displayed_and_reviewed=True,note_path=str(p),note_SHA256=sha(p),reading_credit=len(row['physical_pages']),not_an_independent_model_receipt=True,whole_book_new_reading_claim=False,preparation_flags_unchanged=True,helper_source=__file__)
receipt.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(number=number,pages=row['physical_pages'],receipt_SHA256=sha(receipt))))
