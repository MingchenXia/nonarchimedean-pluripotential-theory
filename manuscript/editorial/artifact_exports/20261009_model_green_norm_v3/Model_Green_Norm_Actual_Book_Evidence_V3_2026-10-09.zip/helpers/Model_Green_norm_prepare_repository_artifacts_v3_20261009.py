from pathlib import Path
from datetime import datetime, timezone
import json,hashlib,shutil

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Dubocs_Green_currents_review_20261008'
A=R/'manuscript/editorial/artifact_exports/20261009_model_green_norm_v3'
out=C/'repository_artifact_preparation_v3_20261009.json'
assert not A.exists() and not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
export=json.loads((C/'staged_export_v3_20261009.json').read_text())
active=json.loads((R/'manuscript/editorial/Model_Green_norm_cloud_activation_v3_20261009.json').read_text())
assert sha(R/'manuscript/book.pdf')==active['active_PDF']['SHA256']==export['artifacts']['full_book_PDF']['SHA256']
A.mkdir()
for key,row in export['artifacts'].items():
 q=Path(row['path']);assert sha(q)==row['SHA256']
 p=A/q.name;shutil.copyfile(q,p);assert sha(p)==row['SHA256']
np=active['active_PDF']['physical_pages'];nb=active['actual_selected_book_pages'];nv=active['fresh_book_matching_views']
rows={q.name:dict(bytes=q.stat().st_size,SHA256=sha(q)) for q in A.iterdir()}
(A/'SHA256SUMS').write_text(''.join(a['SHA256']+'  '+n+'\n' for n,a in sorted(rows.items())))
(A/'README.md').write_text(f'''# Checked model Green-current and finite flat norm edition, 9 October 2026

This directory contains the complete {np:,}-page book PDF, the {nb}-page
selected review PDF, the 472-member minimal build source archive and the
{export['artifacts']['actual_book_evidence_archive']['members']}-member actual
book evidence archive. SHA256SUMS pins the four owned artifacts. All {nb}
final selected pages were freshly read with complete text in {nv} individually
displayed matching v3 images, with sequential notes/receipts. Preparation,
export and upload supply zero reading credit.

Chapter 17's new paragraph distinguishes operational model-Chow Green
currents from CLD analytic currents. Chapter 19's new paragraph retains
finite-flat scheme lengths/residue degrees, minus-log weights and the precise
projective/geometrically reduced/ample/continuous psh norm scope. New L.97
gives the singular generic and raw-total blowup examples, rank-one and
section-ideal model constructions, split Chern coefficients and remaining
comparison dependencies. The example's section is regular; its length-four
zero scheme is lci, nonreduced and not regular. No general higher-rank formula
or local weak-psh descent is imported.

Frozen v1's 7.49791pt overflow and actual one-page diagnosis remain in the
evidence. Two view-selection preflights failed before images/text. V2 wraps
the display and corrects citation typography; its partial sixteen-page/
eight-display review caught the regular-section heading ambiguity. V3 fixes
that heading and freshly reads the complete final scope, with no reuse.
Full validation, six existing tests and post-render gates pass. All 955
underfull blocks, prior numbered values/citations, 225 historical blocks
including 75 proofs and six manual tags are preserved. Other 422 core
TeX inputs and ComplexGeometry are unchanged.

Source scopes are the complete 27-page Dubocs arXiv:2606.19160v1 reading
in fourteen views and prior partial 29-page published BE21 reading in
fifteen views. Their authored source checkpoints are separately uploaded and
verified; external primary PDFs/text/images remain in the cloud. Earlier
classical sources are attributed, not recursively certified.

Native catalogue/editor, 42 atoms/twelve problems and the last complete
4 October ordered book pass retain their scopes. General BJ22 critical
homogeneous Siu/envelopes remain OPEN; LPWZ density UNVERIFIED.
No original general theorem or independent-model receipt is asserted.
Remote publication receives a separate subsequent record.
''')
files={str(q.relative_to(R)):dict(bytes=q.stat().st_size,SHA256=sha(q)) for q in A.iterdir()}
assert len(files)==6
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — six repository artifact files byte verified',
 files=files,active_PDF_SHA256=active['active_PDF']['SHA256'],
 actual_selected_book_pages=nb,actual_fresh_matching_views=nv,reading_credit_from_export=0,
 GitHub_published=False,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',record_SHA256=sha(out),repository_artifact_files=len(files))))
