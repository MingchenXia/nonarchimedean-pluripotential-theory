from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile, shutil, subprocess, re

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Dubocs_Green_currents_review_20261008'
B=Path('/workspace/book-completion-drafts/wu-local-psh-staging-v3-20261008')
S=Path('/workspace/book-completion-drafts/model-green-norm-staging-v1-20261009')
D=Path('/workspace/book-completion-drafts/model-green-norm-integration-v1-20261009')
out=C/'staging_preparation_v1_20261009.json'
assert not out.exists() and not S.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cp=C/'source_checkpoint_v1_20261009.json';p=json.loads(cp.read_text())
publication=C/'GitHub_source_publication_v1_20261009.json'
pub=json.loads(publication.read_text())
assert len(pub['files'])==10 and p['actual_source_pages']==27 and p['actual_matching_views']==14
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head==pub['commit']=='03fddb8a1fc634d78cc09670f3edd4264aa8d185'
for n,h in p['protected_core_inputs'].items():assert sha(R/n)==h
for n,h in p['editorial_files'].items():assert sha(n)==h
assert sha(B/'manuscript/book.pdf')==sha(R/'manuscript/book.pdf')
minimal=Path('/workspace/book-completion-drafts/research-integration/Wu_Local_Psh_Growth_Staged_Minimal_Source_V3_2026-10-08.zip')
with zipfile.ZipFile(minimal) as z:
 members=z.namelist();assert len(members)==len(set(members))==472
 assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in members)
 for n in members:
  assert (R/n).is_file()
  if n!='README.md':assert z.read(n)==(R/n).read_bytes(),n
 S.mkdir();z.extractall(S)
for n in ['README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']:
 shutil.copy2(R/n,S/n)
changed=[
 'manuscript/parts/part2/ch17_metrized_bundles.tex',
 'manuscript/parts/part2/ch19_cld_examples.tex',
 'manuscript/appendices/appL_provenance.tex',
 'manuscript/bibliography/NonArchimedean.bib']
before={n:sha(S/n) for n in changed}
assert all(sha(R/n)==h for n,h in before.items())
q=S/changed[0];s=q.read_text();marker=r'\paragraph{Item by item.}'
assert s.count(marker)==1
q.write_text(s.replace(marker,(D/'ch17_model_green_fragment.tex').read_text()+marker,1))
q=S/changed[1];s=q.read_text();marker=r'\section{A first CLD--BFJ comparison}'
assert s.count(marker)==1
q.write_text(s.replace(marker,(D/'ch19_finite_flat_norm_fragment.tex').read_text()+marker,1))
q=S/changed[2]
q.write_text(q.read_text()+(D/'appL_model_green_norm_fragment.tex').read_text().rstrip()+'\n')
q=S/changed[3]
q.write_text(q.read_text()+(D/'bibliography_fragment.bib').read_text().rstrip()+'\n')
assert q.read_text().count('@misc{Dubocs26GreenV1,')==1
tex={n:h for n,h in p['protected_core_inputs'].items() if n.startswith('manuscript/') and n.endswith('.tex')}
assert len(tex)==425
unchanged={n:h for n,h in tex.items() if n not in changed}
assert len(unchanged)==422
for n,h in unchanged.items():assert sha(R/n)==sha(S/n)==h
formal=[]
envs=['theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important']
for n in changed[:3]:
 old=(R/n).read_text();new=(S/n).read_text()
 starts=re.findall(r'\\begin\{('+('|'.join(envs))+r')\}',old)
 assert starts==re.findall(r'\\begin\{('+('|'.join(envs))+r')\}',new)
 counts={}
 for env in envs:
  blocks=re.findall(r'\\begin\{'+env+r'\}.*?\\end\{'+env+r'\}',old,re.S)
  assert all(block in new for block in blocks)
  counts[env]=len(blocks)
 tags=re.findall(r'\\tag\{([^}]+)\}',old)
 assert tags==re.findall(r'\\tag\{([^}]+)\}',new)
 formal.append(dict(path=n,historical_formal_starts=len(starts),historical_proofs=starts.count('proof'),historical_manual_tags=len(tags),environment_counts=counts,new_manual_tags=[]))
 for marker in [r'\begin{',r'\end{']:
  assert new.count(marker)>=old.count(marker)
for q in D.iterdir():assert all(s==s.rstrip() for s in q.read_text().splitlines())
for rel in p['editorial_files']:
 q=Path(rel);target=S/q.relative_to(R);target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(q,target)
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),
 status='DONE — model Green-current boundary and precise finite-flat norms prepared in isolated stage',
 stage_path=str(S),baseline_stage_path=str(B),baseline_commit=head,
 baseline_minimal_source=dict(path=str(minimal),SHA256=sha(minimal),members=472),
 draft_path=str(D),before=before,after={n:sha(S/n) for n in changed},
 draft_fragments={str(q):sha(q) for q in sorted(D.iterdir())},
 active_inputs_preserved={n:sha(R/n) for n in changed},
 other_active_TeX_preserved=unchanged,
 unchanged_bibliography=dict(path='manuscript/bibliography/ComplexGeometry.bib',SHA256=sha(R/'manuscript/bibliography/ComplexGeometry.bib')),
 historical_formal_blocks_preserved=formal,active_book_PDF_SHA256=sha(R/'manuscript/book.pdf'),
 native_catalogue_preserved={n:h for n,h in p['protected_core_inputs'].items() if n.startswith('output/')},
 source_checkpoint_SHA256=sha(cp),actual_primary_reading_SHA256=sha(C/'actual_primary_reading_v1_20261009.json'),
 exact_diagnostics_SHA256=sha(C/'exact_diagnostics_v2_20261009.json'),
 source_publication_SHA256=sha(publication),
 norm_dependency_publication_SHA256=sha(R/'source_material/local_psh_dependencies_review_20261008/GitHub_source_publication_v1_20261008.json'),
 new_bibliographic_keys=['Dubocs26GreenV1'],new_formal_environments=0,
 original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],
 active_book_changed=False,GitHub_published=False,actual_book_reading_credit=0,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',record_SHA256=sha(out),other_TeX=len(unchanged),historical=formal)))
