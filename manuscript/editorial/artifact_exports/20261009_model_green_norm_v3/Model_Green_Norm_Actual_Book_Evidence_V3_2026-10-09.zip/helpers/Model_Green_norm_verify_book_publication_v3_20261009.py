from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Dubocs_Green_currents_review_20261008'
out=C/'GitHub_book_publication_v3_20261009.json';assert not out.exists()
repo='MingchenXia/nonarchimedean-pluripotential-theory'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
api=lambda ep:json.loads(subprocess.check_output(['gh','api',ep],cwd=R,text=True))
local=json.loads((C/'local_book_commit_v3_20261009.json').read_text())
head=local['commit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==head
assert api(f'repos/{repo}/git/ref/heads/work')['object']['sha']==head
main=api(f'repos/{repo}/git/ref/heads/main')['object']['sha']
assert main=='00957114db21b627e97369563032ceda9cea09c7'
tree=api(f'repos/{repo}/git/trees/{head}?recursive=1');assert not tree['truncated']
mapping={a['path']:a for a in tree['tree'] if a['type']=='blob'}
rows=[]
for rel,h in local['files'].items():
 p=R/rel;assert sha(p)==h
 blob=subprocess.check_output(['git','hash-object',str(p)],cwd=R,text=True).strip()
 assert mapping[rel]['sha']==blob and mapping[rel]['size']==p.stat().st_size
 rows.append(dict(path=rel,bytes=p.stat().st_size,SHA256=h,local_and_remote_Git_blob_SHA1=blob))
assert len(rows)==18
for n,h in local['native_catalogue_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==local['active_PDF']['SHA256']
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — eighteen final source/progress/audit/addendum/artifact remote blobs verified',
 repository=repo,branch='work',commit=head,main_unchanged=main,files=rows,
 active_book_PDF=local['active_PDF'],actual_selected_book_pages=34,fresh_matching_views=17,
 primary_Green_source_record_SHA256=sha(C/'GitHub_source_publication_v1_20261009.json'),
 prior_norm_dependency_record_SHA256=sha(R/'source_material/local_psh_dependencies_review_20261008/GitHub_source_publication_v1_20261008.json'),
 general_higher_rank_formula_admitted=False,CLD_comparison_established=False,
 general_envelope_theorem_admitted=False,native_editor_changed=False,
 reading_credit_from_upload=0,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',commit=head,files=len(rows),record_SHA256=sha(out))))
