from pathlib import Path
from datetime import datetime, timezone
import json,hashlib,subprocess

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Dubocs_Green_currents_review_20261008'
out=C/'local_book_commit_v3_20261009.json';assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
export=load('staged_export_v3_20261009.json')
artifact=load('repository_artifact_preparation_v3_20261009.json')
prep=load('staging_preparation_v3_20261009.json')
activation=R/'manuscript/editorial/Model_Green_norm_cloud_activation_v3_20261009.json'
active=json.loads(activation.read_text())
def git(*a):return subprocess.check_output(['git',*a],cwd=R,text=True).strip()
assert git('branch','--show-current')=='work' and git('rev-parse','HEAD')==prep['baseline_commit']
assert not git('diff','--cached','--name-only')
changes=active['after_source_hashes'];assert len(changes)==6
assert sorted(git('diff','--name-only').splitlines())==sorted(changes)
for n,h in changes.items():assert sha(R/n)==h
for n,h in export['editorial_files'].items():assert sha(n)==h
for n,a in artifact['files'].items():assert sha(R/n)==a['SHA256']
assert sha(R/'manuscript/book.pdf')==active['active_PDF']['SHA256']
for n,h in prep['other_active_TeX_preserved'].items():assert sha(R/n)==h
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h
files=list(changes)+[str(Path(n).relative_to(R)) for n in export['editorial_files']]+[str(activation.relative_to(R))]+list(artifact['files'])
assert len(files)==len(set(files))==18
subprocess.run(['git','diff','--check'],cwd=R,check=True)
subprocess.run(['git','add','--']+[n for n in files if n not in artifact['files']],cwd=R,check=True)
subprocess.run(['git','add','-f','--']+list(artifact['files']),cwd=R,check=True)
assert sorted(git('diff','--cached','--name-only').splitlines())==sorted(files)
subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
subprocess.run(['git','commit','-m','Distinguish regular-model Green currents and precise finite-flat norm metrics'],cwd=R,check=True)
head=git('rev-parse','HEAD')
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — eighteen-file checked book unit committed; remote verification pending',
 baseline_commit=prep['baseline_commit'],commit=head,files={n:sha(R/n) for n in files},
 active_PDF=active['active_PDF'],actual_selected_book_pages=34,fresh_matching_views=17,
 canonical_status_changes=[],source_scope=active['source_scope'],
 native_catalogue_preserved=prep['native_catalogue_preserved'],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',commit=head,files=len(files),record_SHA256=sha(out))))
