# Frozen preceding v2 helper SHA256: b74c923302908de918b3fd5b7df1e4822a425cdb20f797562f782f56be367106
# Frozen preceding v1 helper SHA256: 39ba4f1c83c4dfd7669fff3e855cfdf3a3ea993eaf9194b953ac5ef567f15006
# Frozen finalizer template SHA256: 5675e3f5d4705b09ee13d3e1417fdecb6b53736cfb26448154f172112dbac6e4
# Frozen preceding v2 helper SHA256: c5b299ebe6b5c1c75ecebc1ec7eb7ac33ae91ead99549c7d030218660fa1239d
# Prepared unexecuted v1 finalizer SHA256: 390f22feb156131659ca6f00809e832edd411c9c171e1c8829f3b8ea413e4b5a
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, json, re, subprocess, difflib

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Dubocs_Green_currents_review_20261008'
S=Path('/workspace/book-completion-drafts/model-green-norm-staging-v3-20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
release=C/'staged_book_release_checks_v3_20261009.json'
ch=json.loads(release.read_text())
manifest=Path(ch['manifest_path'])
assert sha(manifest)==ch['manifest_SHA256']
xs=json.loads(manifest.read_text())
views=[]
last=None
for x in xs:
    assert not x['actually_viewed'] and not x['selected_text_read']
    n=C/'staged_book_notes_v3'/f"note_{x['number']:02d}.md"
    r=n.with_name(n.stem+'_receipt.json')
    receipt=json.loads(r.read_text())
    assert 'Read the complete selected text and displayed matching rendered image' in n.read_text()
    assert receipt['complete_selected_text_actually_read']
    assert receipt['matching_image_individually_displayed_and_reviewed']
    assert receipt['number']==x['number'] and receipt['physical_pages']==x['physical_pages']
    assert receipt['source_PDF_SHA256']==ch['PDF']['SHA256']
    assert sha(n)==receipt['note_SHA256']
    assert sha(x['path'])==receipt['image_SHA256']==x['image_SHA256']
    assert sha(x['selected_text_path'])==receipt['selected_text_SHA256']==x['selected_text_SHA256']
    assert last is None or receipt['UTC']>last
    last=receipt['UTC']
    y={k:v for k,v in x.items() if k not in ['actually_viewed','selected_text_read']}
    y.update(inspection_mode='Fresh complete text and individual matching image display',
             actual_complete_text_read=True,actual_matching_image_freshly_displayed=True,
             sequential_note_path=str(n),sequential_note_SHA256=sha(n),
             observation_receipt_path=str(r),observation_receipt_SHA256=sha(r))
    views.append(y)
pages=sorted({p for x in xs for p in x['physical_pages']})
assert pages==ch['selected_book_physical_pages']
assert sum(len(x['physical_pages']) for x in xs)==len(pages)
reading=C/'actual_staged_book_reading_v3_20261009.json'
audit=C/'staged_mathematical_self_audit_v3_20261009.json'
post=C/'post_render_checks_v3_20261009.json'
assert not any(q.exists() for q in (reading,audit,post))
prep=json.loads((C/'staging_preparation_v3_20261009.json').read_text())
checks=[]
for command in (['python3','editorial/tools/refcheck.py'],
                ['python3','editorial/tools/check_open_problem_inventory.py']):
    run=subprocess.run(command,cwd=S/'manuscript',text=True,
                       stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    assert run.returncode==0,run.stdout
    checks.append(dict(command=command,returncode=run.returncode,output=run.stdout))
for n,h in prep['after'].items():
    assert sha(S/n)==h
for n,h in prep['other_active_TeX_preserved'].items():
    assert sha(R/n)==sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():
    assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
for n,h in prep['native_catalogue_preserved'].items():
    assert sha(R/n)==h
assert sha(R/prep['unchanged_bibliography']['path'])==prep['unchanged_bibliography']['SHA256']
assert sha(S/prep['unchanged_bibliography']['path'])==prep['unchanged_bibliography']['SHA256']
historical={}
whitespace={}
for n in ('manuscript/parts/part2/ch17_metrized_bundles.tex','manuscript/parts/part2/ch19_cld_examples.tex','manuscript/appendices/appL_provenance.tex'):
    before=(R/n).read_text()
    after=(S/n).read_text()
    counts={}
    for env in ('theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important'):
        patt=r'\\begin\{'+env+r'\}.*?\\end\{'+env+r'\}'
        blocks=re.findall(patt,before,re.S)
        assert all(b in after for b in blocks)
        assert len(blocks)==len(re.findall(patt,after,re.S))
        counts[env]=len(blocks)
    tags=re.findall(r'\\tag\{([^}]+)\}',before)
    assert tags==re.findall(r'\\tag\{([^}]+)\}',after)
    historical[n]=dict(byte_preserved_environment_blocks=counts,prior_manual_equation_tags=tags)
assert sum(sum(v['byte_preserved_environment_blocks'].values()) for v in historical.values())==225
assert sum(v['byte_preserved_environment_blocks']['proof'] for v in historical.values())==75
assert sum(len(v['prior_manual_equation_tags']) for v in historical.values())==6
for n in prep['after']:
    before=(R/n).read_text().splitlines()
    after=(S/n).read_text().splitlines()
    wb=Counter(x for x in before if x!=x.rstrip())
    wa=Counter(x for x in after if x!=x.rstrip())
    assert wb==wa
    added=[x[2:] for x in difflib.ndiff(before,after) if x.startswith('+ ')]
    assert all(x==x.rstrip() for x in added)
    run=subprocess.run(['git','diff','--no-index','--check',str(R/n),str(S/n)],
                       text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    assert run.returncode in (0,1) and run.stdout=='',(run.returncode,run.stdout)
    whitespace[n]=dict(historical_whitespace_lines_preserved=sum(wb.values()),
                       added_lines_checked=len(added),added_trailing_whitespace_lines=0,
                       no_index_returncode=run.returncode,no_index_diagnostic_output=run.stdout,
                       EOF_whitespace_check='PASS')
for q,h in prep['draft_fragments'].items():
    assert sha(q)==h
    assert all(x==x.rstrip() for x in Path(q).read_text().splitlines())
underfull=json.loads((C/'staged_underfull_delta_v3_20261009.json').read_text())
reading.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — all selected book pages freshly read and individually displayed',
    PDF=ch['PDF'],actual_unique_book_pages=len(pages),
    fresh_complete_text_and_individually_displayed_pages=len(pages),
    fresh_matching_views=len(views),reused_exact_complete_text_and_rendered_pixel_pages=0,
    reused_matching_views=0,views=views,legacy_preparation_flags_rewritten=False,
    remaining_repairs=[],whole_book_new_reading_claim=False,
    active_book_changed=False,GitHub_published=False,canonical_status_changes=[],
    helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
mathchecks=['Source scope is complete Dubocs 2606.19160v1, 27 primary pages in 14 matching displays, and partial published BE21, 29 selected pages in 15 matching displays. Classical earlier sources are attributed and not recursively certified.', 'The model current category requires an excellent DVR, proper smooth generic variety and regular/cofinal proper flat total models. Operational Chow cohomology is distinguished from cycles and from CLD test-form currents.', 'The model derivative i^* E^{-1} i_* and integration current use total-model Poincare duality and scheme-cycle multiplicities. There is no supplied arbitrary current product, generic-open restriction, or CLD comparison map.', 'Rank-one Poincare-Lelong uses the vertical part with the stated opposite BGS div_nu sign, cancels the horizontal closure and retains the existing book minus-log conventions. Norm-square analogy alone does not identify differentials.', 'Top-dimensional coefficient minimum commutes with degree-one strict-transform pushforward and discards contracted divisors. The higher-degree counterexample requires equal residue degree; no psh-envelope theorem is inferred.', 'Minimum component orders are invariant under an integral GL_r frame change and its inverse, using ord(0)=infinity. Model-open gluing has explicit overlap and transition requirements.', 'The proper projective regular section (X^2,Y^2) of O(2)^2 has local regular sequence (x^2,y^2), a length-four quotient and singular generic blowup chart y^2-u x^2. At u=1 the dimension-two local ring has embedding dimension three. A regular exact-generic-fibre R-model is impossible by localization.', 'The raw total blowup of (tX,Y) on P^2_R has chart tx-vy, dimension three and embedding dimension four at the special point, though the generic chart is smooth. A valid regular domination/principalization and exceptional identities remain unprovided; the intended corrected Green identity is not declared false.', 'The split Chern coefficient sum is one. Inserting the printed missing (-1)^k differentiation factor gives z^k(1+z)^(r-1-k); elementary coefficient algebra does not repair the geometric gap.', 'Proper integral global functions form a finite field extension. A regular positive-rank trivial-bundle section has empty zero scheme componentwise. The source specialization does not establish a nontrivial local affine Martinelli theorem; the existing CLD theorem retains its independent scope.', 'Finite flat fibres retain Artinian composition length times completed-residue-field degree. The determinant norm is det f_*L tensor inverse det f_*O; section additive weights use minus log, and the weighted trace has degree-d pullback and Lipschitz identities.', 'The F2((t)) algebra K[z]/((z^2-t)^2) has rank four, length two, residue degree two, nonzero square-zero epsilon and norm(z)=t^2. It is outside the geometrically reduced source theorem scope.', 'BE21 Proposition 8.22 retains projective geometrically reduced schemes, ample rational source polarization and a continuous global psh metric. Reduction-tube trivializations, nef-model approximation and classical flattening scopes remain explicit.', 'BE21 Theorem 7.8 is ample/continuous; Remark 7.10 is only a semiample expectation. The separate Theorem 7.31 has continuous/semiample/geometrically reduced projective hypotheses and an earlier base-change input.', 'The global weighted maximum iteration types N_f(f^*L)=L^d and handles d=1 separately. It does not supply arbitrary local USC weak-psh descent or affine regularization over nondiscrete completed residue fields.', 'All 225 historical environment blocks including 75 proofs and six manual tags in the three changed TeX roots remain byte preserved. The other 422 core TeX inputs and ComplexGeometry bibliography remain unchanged; no new formal environment or manual tag is added.', 'The native catalogue/editor, 42 canonical atoms and twelve formal problems stay unchanged. General BJ22 critical homogeneous Siu/envelopes remain OPEN and LPWZ density UNVERIFIED. No original general theorem, independent-model receipt or fresh complete book pass is asserted.']

audit.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — ordinary scoped mathematical audit and actual rendered clearance',
    checks=mathchecks,source_input_hashes=prep['after'],draft_fragments=prep['draft_fragments'],
    actual_final_book_reading_SHA256=sha(reading),actual_final_book_reading_credit=len(pages),
    source_scope='Dubocs 2606.19160v1 complete 27 primary pages/14 views; published BE21 partial 29 pages/15 views; elementary diagnostics and precise attributed inputs',
    exact_diagnostics_SHA256=sha(C/'exact_diagnostics_v2_20261009.json'),
    norm_diagnostics_SHA256=sha(R/'source_material/local_psh_dependencies_review_20261008/exact_norm_diagnostics_v1_20261008.json'),
    underfull_comparison_SHA256=sha(C/'staged_underfull_delta_v3_20261009.json'),
    new_underfull_blocks=underfull['added_blocks'],original_results_promoted=[],
    independent_model_receipt=None,canonical_status_changes=[],whole_book_new_reading_claim=False,
    helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
post.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE',
    checks=checks,source_input_hashes=prep['after'],rendered_gate_SHA256=sha(reading),
    historical_formal_proof_warning_important_blocks_byte_preserved=historical,
    other_active_TeX_inputs_byte_preserved=422,whitespace_gate='PASS including EOF',
    whitespace_details=whitespace,legacy_writing_audit_unavailable=True,
    manual_semantic_delimiter_source_and_rendered_audits_used=True,
    active_book_changed=False,GitHub_published=False,canonical_status_changes=[],
    helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',actual_reading_SHA256=sha(reading),
                     math_audit_SHA256=sha(audit),post_render_SHA256=sha(post),
                     actual_pages=len(pages),fresh_views=len(views))))
