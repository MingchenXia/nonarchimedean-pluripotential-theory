# Frozen preceding v2 helper SHA256: 028a4d8d326ea43c51b0f77785ca7dd11d8a64bdaad75350153c9bf75cd8bb84
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile, shutil, fitz

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Dubocs_Green_currents_review_20261008'
S=Path('/workspace/book-completion-drafts/model-green-norm-staging-v3-20261009')
E=R/'manuscript/editorial'
O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
prep=load('staging_preparation_v3_20261009.json')
release=load('staged_book_release_checks_v3_20261009.json')
reading=load('actual_staged_book_reading_v3_20261009.json')
post=load('post_render_checks_v3_20261009.json')
math=load('staged_mathematical_self_audit_v3_20261009.json')
under=load('staged_underfull_delta_v3_20261009.json')
assert reading['status'].startswith('DONE') and not reading['remaining_repairs']
assert all(a['returncode']==0 for a in post['checks'])
assert not under['added_blocks'] and not under['removed_blocks']
assert math['source_scope'].startswith('Dubocs 2606.19160v1')
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
np=release['PDF']['physical_pages'];nb=reading['actual_unique_book_pages'];nv=reading['fresh_matching_views']
assert nb==reading['fresh_complete_text_and_individually_displayed_pages']==len(release['selected_book_physical_pages'])
assert nv==len(reading['views']) and nb>0
assert reading['reused_exact_complete_text_and_rendered_pixel_pages']==0
full=O/'Non-Archimedean_Pluripotential_Theory_Model_Green_Norm_Staged_Preview_V3_2026-10-09.pdf'
review=O/'Model_Green_Norm_Staged_Book_Review_V3_2026-10-09.pdf'
minimal=O/'Model_Green_Norm_Staged_Minimal_Source_V3_2026-10-09.zip'
evidence=O/'Model_Green_Norm_Actual_Book_Evidence_V3_2026-10-09.zip'
record=C/'staged_export_v3_20261009.json'
paths={k:E/f'Model_Green_norm_staged_integration_{k}_v3_20261009.{ext}'
 for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in [full,review,minimal,evidence,record,*paths.values()])
shutil.copy2(release['PDF']['path'],full);assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as book:
 d=fitz.open()
 for n in release['selected_book_physical_pages']:d.insert_pdf(book,from_page=n-1,to_page=n-1)
 assert len(d)==nb
 d.set_metadata(dict(title='Model Green currents and finite flat norms — actual book review',
  subject=f'{nb} genuinely reviewed pages; export gives no reading credit.'))
 d.save(review,garbage=4,deflate=True);d.close()
paths['audit'].write_text(f'''# Model Green currents and finite flat norm metrics: book integration

Date: 9 October 2026. The validated staged book has {np:,} pages. New
paragraphs in the source interface of Chapter 17 and the common model core
of Chapter 19 lead to L.97, “Model Green currents and finite flat norm
metrics.” It distinguishes the operational model-Chow current category
from CLD analytic currents, gives the two explicit blowup regularity
diagnostics, and retains the precise global norm metric hypotheses.
The general higher-rank formula is not imported. No intended identity
after a valid additional principalization construction is asserted false.

The primary basis is Dubocs arXiv:2606.19160v1, all 27 pages actually read
in fourteen matching displays with complete text and sequential notes,
and the previous partial published BE21 reading, 29 selected pages in
fifteen matching displays. The source checkpoints are remotely verified
in 03fddb8a1fc634d78cc09670f3edd4264aa8d185 and
e4b7b2ae57a0a2481ad723f64c4b635afadd84c2, respectively.
Six Green-current and five norm-dependency elementary diagnostic families
pass. Earlier BGS/Fulton, resolution/flattening, logarithmic-integrability
and supremum-norm/base-change sources are attributed; they are not
recursively certified by these readings.

All {nb} final selected book pages were freshly read with complete text,
{nv} individual matching image displays and sequential notes/receipts.
The scope contains the new contents row, complete Chapter 17 source
interface and seams, complete Chapter 19 common-core section and seams,
complete L.97 and seams, complete index and complete new Dub26G entry.
Preparation flags remain false; no earlier display is reused for final
reading credit. This is a scoped book gate, not a new whole-book pass.

Frozen v1 passed compilation but failed the release gate on one
7.49791pt fibre-algebra overflow. Its physical page 4404 was actually
read as an overflow diagnosis, with zero final-release credit. Two
diagnostic view-selection probes failed before creating images or texts;
their empty directories and failure records are retained. V2 wraps the
fibre-algebra display and moves two citation locators from math displays
into their introductory prose. It changes no mathematical assertion. Partial v2 reading then covered sixteen pages in eight matching displays and caught the heading that confused a regular section with a regular zero scheme. Fresh v3 corrects that heading; the length-four zero scheme is lci but nonreduced and not regular. All final v3 pages are freshly read, with no partial-v2 reuse.
The source-level failed SymPy integer-type helper is also retained, with
fresh corrected v2 diagnostics passing.

Full validation, all six existing regression tests, reference closure
and canonical inventory pass. Post-render references/inventory and actual
semantic, notation, delimiter, source, whitespace and rendered audits pass.
The legacy writing audit is unavailable and is not reported as an automated
pass. There are zero TeX errors, LaTeX/package/pdfTeX warnings, missing
glyphs, overfull boxes, unresolved references/citations or rerun requests.
All 955 underfull blocks are inherited with identical normalized content
and multiplicities. All {release['all_prior_numbered_label_values_preserved']:,}
prior numbered values and {release['bibliography']['prior_labels_preserved']}
citation labels are preserved. One semantic label, one contents row,
Dub26G and two index terms are new. All {release['index']['accepted']}
index entries are accepted, with zero warnings/rejections; all
{release['navigation']['internal_links']:,} internal links pass.
External URL availability is not certified.

The three changed TeX roots preserve 225 historical environment blocks,
including 75 proofs, and six manual equation tags. No formal environment
or manual tag is added. The other 422 core TeX inputs and ComplexGeometry
bibliography remain unchanged. The native catalogue/editor and all 42
atoms/twelve problems keep their statuses: general BJ22 critical homogeneous
Siu/envelopes OPEN, LPWZ density UNVERIFIED. The warning about BJ22
Theorem 6.21 remains binding. The last complete ordered whole-book pass
is 4 October. No original general theorem or independent-model receipt
is asserted.

The mathematical audit checks:

'''+''.join(f'{i}. {a}\n\n' for i,a in enumerate(math['checks'],1))+'''This export supplies byte-verified full/review PDFs, minimal build sources
and actual book evidence. Cloud activation and remote publication require
their separate later records. Export/upload adds zero reading credit.
''')
paths['reading_notes'].write_text(f'# Actual final rendered-book notes, 9 October 2026\n\n{nb} pages freshly read in {nv} individual v3 matching displays. No reuse; preparation flags remain frozen.\n'+''.join('\n---\n\n'+Path(a['sequential_note_path']).read_text() for a in reading['views']))
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md'
p=S/programme;s=(R/programme).read_text()
marker='## Latest model Green-current primary checkpoint, 9 October 2026\n';assert s.count(marker)==1
intro=f'''## Latest model Green-current and norm book checkpoint, 9 October 2026

The [integration audit](Model_Green_norm_staged_integration_audit_v3_20261009.md)
adds Chapter 17's regular-model Green-current interface, Chapter 19's
finite-flat norm hypotheses, and L.97. It retains the operational
Chow/CLD distinction, regular/cofinal model assumptions, two explicit
singular blowup examples and the projective/geometrically reduced/ample/
continuous norm scope. No general higher-rank formula, local weak-psh
descent, nondiscrete affine regularization or general envelope theorem
is imported.

The staged book has {np:,} pages. All {nb} selected final pages were
freshly read in {nv} individual matching displays with complete text
and sequential notes. Required validation and post-render gates pass.
All 955 underfull blocks, prior numbered values and 595 citation labels
are preserved. The other 422 TeX inputs, ComplexGeometry, 225 historical
blocks including 75 proofs and six manual tags are unchanged.
Frozen v1's 7.49791pt overflow and one actual diagnostic page remain;
two failed view-selection preflights created no images or reading credit.
V2 wraps the display and corrects citation typography. Partial v2 reading
found the regular-section/regular-zero-scheme heading ambiguity; fresh v3
corrects it. All final v3 pages are freshly read, with no reuse. No earlier diagnostic display is reused for final reading credit.

Source scopes remain the complete 27-page Dubocs v1 and previous partial
29-page published BE21 reading, with remote evidence verification.
The [activation record](Model_Green_norm_cloud_activation_v3_20261009.json)
controls the new cloud book edition; remote publication gets a separate
subsequent record. Native catalogue/editor and 42 atoms/twelve problems
stay unchanged. General BJ22 critical homogeneous Siu/envelopes OPEN,
LPWZ density UNVERIFIED; the last complete ordered book pass is 4 October.
No original general theorem or independent-model receipt is claimed.

Continue related primary literature and sequential open-problem interfaces,
including exact comparison maps and missing approximation/base-change
dependencies. Check incoming author updates and periodically push checked
evidence. Execution remains cloud-only and Xean remains suspended.

'''
p.write_text(s.replace(marker,intro+marker,1))
p=S/'README.md';s=(R/'README.md').read_text()
assert s.count('**4,651 pages**')==1;s=s.replace('**4,651 pages**',f'**{np:,} pages**')
marker='**Latest model Green-current primary checkpoint, 9 October 2026:**';assert s.count(marker)==1
intro=f'''**Latest checked model Green-current and norm book integration, 9 October 2026:**
the [integration audit](manuscript/editorial/Model_Green_norm_staged_integration_audit_v3_20261009.md)
adds precise interfaces to Chapters 17 and 19 and new L.97. It distinguishes
model-Chow from CLD currents, gives two explicit blowup regularity examples
and retains the exact global psh norm hypotheses. All {nb} final selected
pages were freshly read in {nv} individual matching displays; full validation
and post-render gates pass. Frozen v1's overflow is corrected in v2; v3 fixes the regular-section
heading found during the partial v2 review, with no change to the example. The
[activation record](manuscript/editorial/Model_Green_norm_cloud_activation_v3_20261009.json)
controls the {np:,}-page cloud edition. General higher-rank and weak-local
bridges, canonical statuses and the native editor retain their boundaries.
No original general theorem or fresh whole-book pass is claimed.

'''
p.write_text(s.replace(marker,intro+marker,1))
oldzip=Path(prep['baseline_minimal_source']['path'])
with zipfile.ZipFile(oldzip) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 members=old.namelist();assert len(members)==len(set(members))==472
 for n in members:assert (S/n).is_file();z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
 for n in z.namelist():assert z.read(n)==(S/n).read_bytes()
files={f'records/{q.name}':q for q in C.glob('*.json')}
for q in C.glob('staged_book_validation_v*_20261009.log'):files[f'logs/{q.name}']=q
for a in reading['views']:
 for key,folder in [('sequential_note_path','notes'),('observation_receipt_path','receipts'),('path','images'),('selected_text_path','text')]:
  q=Path(a[key]);files[f'final_v3/{folder}/{q.name}']=q
mp=Path(release['manifest_path']);files['final_v3/prepared_manifest.json']=mp
partial=load('partial_actual_book_reading_v2_terminology_correction_20261009.json')
for a in partial['views']:
 for key,folder in [('note_path','notes'),('observation_receipt_path','receipts'),('image_path','images'),('selected_text_path','text')]:
  q=Path(a[key]);files[f'partial_v2/{folder}/{q.name}']=q
addendum=E/'Dubocs_Green_currents_terminology_addendum_20261009.md';files[f'editorial/{addendum.name}']=addendum
for v in [1,2,3]:
 for q in Path(f'/workspace/book-completion-drafts/model-green-norm-integration-v{v}-20261009').iterdir():files[f'drafts/v{v}/{q.name}']=q
 for rel in prep['after']:files[f'staged_inputs/v{v}/{rel}']=Path(f'/workspace/book-completion-drafts/model-green-norm-staging-v{v}-20261009')/rel
for q in Path('/tmp/Model_Green_norm_v1_overfull_diagnostic_v3_20261009').iterdir():files[f'failed_v1_actual_diagnostic/{q.name}']=q
for q in Path('/tmp').glob('Model_Green_norm_*_20261009.py'):files[f'helpers/{q.name}']=q
for q in [*([paths[k] for k in ['audit','reading_notes']]),S/programme,S/'README.md']:
 files[f'editorial/{q.name}']=q
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
 assert len(z.namelist())==len(files)
 for n,q in files.items():assert z.read(n)==q.read_bytes()
artifacts={}
for key,q in [('full_book_PDF',full),('selected_review_PDF',review),('minimal_TeX_source_archive',minimal),('actual_book_evidence_archive',evidence)]:
 artifacts[key]=dict(path=str(q),bytes=q.stat().st_size,SHA256=sha(q))
artifacts['selected_review_PDF']['physical_pages']=nb
artifacts['minimal_TeX_source_archive']['members']=472
artifacts['actual_book_evidence_archive']['members']=len(files)
progress_hashes={n:sha(S/n) for n in ['README.md',programme]}
manifest=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — staged mathematical, mechanical and actual rendered gate',
 preparation=prep,release=release,actual_reading=reading,mathematical_audit=math,
 post_render=post,underfull_comparison=under,artifacts=artifacts,
 progress_document_hashes=progress_hashes,source_publication_record_SHA256=prep['source_publication_SHA256'],
 norm_dependency_publication_record_SHA256=prep['norm_dependency_publication_SHA256'],
 active_book_changed=False,GitHub_published=False,canonical_status_changes=[])
paths['manifest'].write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — byte-verified owned book exports',artifacts=artifacts,reading_credit_from_export=0,active_book_changed=False,GitHub_published=False,canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — staged book checkpoint and owned artifacts exported',
 artifacts=artifacts,editorial_files={str(q):sha(q) for q in [*paths.values(),addendum]},
 progress_document_hashes=progress_hashes,
 actual_final_book_pages=nb,actual_final_matching_views=nv,active_book_changed=False,
 GitHub_published=False,canonical_status_changes=[],helper_source=__file__)
record.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',record_SHA256=sha(record),book_pages=np,actual_selected_pages=nb,fresh_views=nv,evidence_members=len(files),artifacts=artifacts)))
