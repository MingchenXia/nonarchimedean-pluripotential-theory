# Model Green currents and finite flat norms actual book view 01

UTC: 2026-10-09T00:29:41.028475+00:00. Physical pages: 73, 1212.

Read the complete selected text and displayed matching rendered image. Physical 73 shows the complete new L.97 contents row, printed page 4323, followed by the preserved M/N hierarchy and shifted index/reference destinations. The number/title spacing and all rows fit. Physical 1212 is the Chapter 17 pre-interface seam: the later-use and smallest-instance tables retain the CLD Bochner–Martinelli, smooth proper curve, fixed-bundle degree-zero and residual/Tate distinctions. The new model-current discussion must not alter these existing analytic statements. Both full pages and their matching v2 image are reviewed; no clipping, overlap or missing glyph is visible. This is fresh final-v2 reading, with no reuse of the failed-v1 diagnostic.
