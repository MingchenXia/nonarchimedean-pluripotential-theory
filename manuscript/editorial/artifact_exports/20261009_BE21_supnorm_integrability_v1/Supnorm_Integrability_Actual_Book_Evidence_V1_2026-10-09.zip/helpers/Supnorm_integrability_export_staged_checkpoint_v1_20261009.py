from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile, shutil, fitz

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BE21_reduced_fibre_integrability_review_20261009'
S=Path('/workspace/book-completion-drafts/supnorm-integrability-staging-v1-20261009')
E=R/'manuscript/editorial';O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
prep=load('staging_preparation_v1_20261009.json');release=load('staged_book_release_checks_v1_20261009.json')
reading=load('actual_staged_book_reading_v1_20261009.json');post=load('post_render_checks_v1_20261009.json')
math=load('staged_mathematical_self_audit_v1_20261009.json');under=load('staged_underfull_delta_v1_20261009.json')
assert reading['status'].startswith('DONE') and not reading['remaining_repairs']
assert all(a['returncode']==0 for a in post['checks']) and not under['added_blocks'] and not under['removed_blocks']
assert math['source_scope'].startswith('Published BE21 partial union 53')
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
np=release['PDF']['physical_pages'];nb=reading['actual_unique_book_pages'];nv=reading['fresh_matching_views']
assert np==4659 and nb==24 and nv==12 and reading['reused_exact_complete_text_and_rendered_pixel_pages']==0
full=O/'Non-Archimedean_Pluripotential_Theory_Supnorm_Integrability_Staged_Preview_V1_2026-10-09.pdf'
review=O/'Supnorm_Integrability_Staged_Book_Review_V1_2026-10-09.pdf'
minimal=O/'Supnorm_Integrability_Staged_Minimal_Source_V1_2026-10-09.zip'
evidence=O/'Supnorm_Integrability_Actual_Book_Evidence_V1_2026-10-09.zip'
record=C/'staged_export_v1_20261009.json'
paths={k:E/f'BE21_supnorm_integrability_staged_integration_{k}_v1_20261009.{ext}' for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in [full,review,minimal,evidence,record,*paths.values()])
shutil.copy2(release['PDF']['path'],full);assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as book:
 d=fitz.open()
 for n in release['selected_book_physical_pages']:d.insert_pdf(book,from_page=n-1,to_page=n-1)
 assert len(d)==nb
 d.set_metadata(dict(title='Section supnorms, reduced fibres and logarithmic integrability — actual book review',subject=f'{nb} actually reviewed pages; export supplies zero reading credit.'))
 d.save(review,garbage=4,deflate=True);d.close()
paths['audit'].write_text(f'''# Section supnorms, reduced fibres and logarithmic integrability: book integration

Date: 9 October 2026. The validated staged edition has {np:,} pages.
The new paragraph in Chapter 19's local–global common core leads to L.98,
“Section norms, reduced fibres, and logarithmic integrability.” It separates
asymptotic scalar-extension norms, relative-model normalization and the
global logarithmic-integrability theorem, with their distinct hypotheses.

The primary basis is the published BE21 article. The previous 29-page/
15-view selection, new 11-page/6-view supnorm selection and new 18-page/
9-view reduced-fibre/log-integrability selection have a union of 53 distinct
pages of the controlling 125-page PDF; 72 remain unread in those checkpoints.
The latter two nine-file source units are separately uploaded and remotely
verified in 1078c9f41128ee4049250bf889c85a38e5c7b178 and
265c02ae7e55b5e365329d8d701a00ca94ca1ebf. Four supnorm and six
reduced-fibre/log-integrability elementary diagnostic families pass. The
first reduced-fibre helper failed Python parsing before computations or
output; that failure is frozen and the fresh corrected v2 passes.
Earlier BGR, Berkovich, CLD and classical projective inputs remain attributed
and are not recursively certified by these selections.

The norm estimate retains projectivity, geometric reducedness, continuity,
any line bundle and any complete extension: o(m), with model O(1), rather
than exact equality on every extended section space. The lattice reference
and factor-two intermediate bound are clarified. The explicit completed
Gauss-field example illustrates the nonfinite closure boundary already
identified by Remark 4.21; it does not contradict the algebraically-closed
model construction in the norm proof.

The logarithmic-integrability explanation retains the fundamental cycle,
continuous global psh-regularizable factors and a regular Cartier section.
It replaces the printed non-Archimedean ordinary log-sum smoothness step
using existing FS maximum regularization, two regularizable reference
metrics, a j-independent CLN estimate and a finite smooth anchor. Dimension
zero is handled separately. The printed CLN plus sign is corrected to minus;
its absolute-value bound survives. This is an explanatory reformulation of
the cited theorem and direct worked boundaries, without promotion of a new
original theorem or extension to arbitrary local weak-psh functions.

All {nb} selected final book pages were freshly read with complete selected
text, {nv} individual matching image displays and sequential notes/receipts.
The scope covers the new contents row, complete Chapter 19 common core and
seams, complete L.98 and seams, and complete index. No bibliography entry
is added. Preparation flags remain false; no prior-edition review is reused.
This is a scoped gate, not a new complete whole-book reading.

Required full validation, six existing tests, references and canonical
inventory pass. The post-render references/inventory and actual semantic,
notation, delimiter, source, whitespace and rendered audits pass. The
unavailable legacy writing audit is not reported as an automated pass.
There are zero TeX errors, LaTeX/package/pdfTeX warnings, missing glyphs,
overfull boxes, unresolved references/citations or rerun requests. All 955
underfull blocks retain identical normalized content and multiplicities.
All {release['all_prior_numbered_label_values_preserved']:,} prior numbered
values and 596 citation labels are preserved. One semantic label, one
contents row and two index terms are new. All {release['index']['accepted']}
index entries are accepted with zero warnings/rejections, and all
{release['navigation']['internal_links']:,} internal links pass. External URL
availability is not certified.

The two changed TeX roots preserve 92 historical environment blocks,
including 25 proofs, and six manual tags; no formal environment or manual
tag is added. The other 423 core TeX inputs and both bibliographies remain
unchanged. The native catalogue/editor, 42 atoms/twelve problems and their
statuses remain unchanged. General BJ22 critical homogeneous Siu/envelopes
stay OPEN and LPWZ density UNVERIFIED; the BJ22 Theorem 6.21 proof warning
remains binding. The last complete ordered book pass is 4 October.
No original general theorem or independent-model receipt is claimed.

The mathematical audit checks:

'''+''.join(f'{i}. {a}\n\n' for i,a in enumerate(math['checks'],1))+'''This export supplies byte-verified full/review PDFs, minimal build sources
and actual book evidence. Cloud activation and remote publication receive
their separate later records. Export/upload supplies zero reading credit.
''')
paths['reading_notes'].write_text(f'# Actual rendered-book notes, 9 October 2026\n\n{nb} pages freshly read in {nv} individual v1 matching displays. No reuse; preparation flags remain frozen.\n'+''.join('\n---\n\n'+Path(a['sequential_note_path']).read_text() for a in reading['views']))
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md'
marker='## Latest reduced-fibre and logarithmic-integrability source checkpoint, 9 October 2026\n'
t=(R/programme).read_text();assert t.count(marker)==1
intro=f'''## Latest supnorm and logarithmic-integrability book checkpoint, 9 October 2026

The [integration audit](BE21_supnorm_integrability_staged_integration_audit_v1_20261009.md)
adds Chapter 19's qualified global interface and L.98. It retains the exact
o(m)/model O(1) scalar-extension estimate, the nonfinite relative-closure
example over a dense Gauss field, and the regular-section/psh-regularizable
global log-integrability explanation with the corrected smoothing and CLN
steps. It does not provide arbitrary local weak-psh descent or affine
lower-growth regularization.

The staged book has {np:,} pages. All {nb} selected pages were freshly read
in {nv} individual matching displays with complete text and sequential
notes. Full validation and post-render checks pass. All 955 underfull
blocks, 13,378 prior numbered values and 596 citations are preserved.
The other 423 TeX inputs and both bibliographies are unchanged; 92
historical blocks, including 25 proofs and six manual tags, are preserved.
The source basis is partial BE21, a union of 53 of 125 pages across three
related selections, with 72 unread in these checkpoints. Earlier foundations
are attributed rather than recursively certified. The source-level failed
first Python parse preflight and corrected v2 diagnostics remain frozen.

The [activation record](BE21_supnorm_integrability_cloud_activation_v1_20261009.json)
controls the new cloud edition; publication receives a later separate record.
Native catalogue/editor, 42 atoms/twelve problems and their statuses stay
unchanged. General BJ22 critical homogeneous Siu/envelopes remain OPEN;
LPWZ density UNVERIFIED. No original general theorem, independent-model
receipt or new complete ordered book pass is claimed; the latter is 4 October.

Continue cloud-only with related primary literature and sequential remaining
open-problem interfaces. Check incoming author updates and periodically push
checked evidence. Xean stays suspended.

'''
(S/programme).write_text(t.replace(marker,intro+marker,1))
t=(R/'README.md').read_text();assert t.count('**4,657 pages**')==1;t=t.replace('**4,657 pages**',f'**{np:,} pages**')
marker='**Latest reduced-fibre and logarithmic-integrability primary checkpoint, 9 October 2026:**';assert t.count(marker)==1
intro=f'''**Latest checked supnorm and logarithmic-integrability book integration, 9 October 2026:**
the [integration audit](manuscript/editorial/BE21_supnorm_integrability_staged_integration_audit_v1_20261009.md)
adds Chapter 19's global comparison paragraph and L.98. The exact section-norm,
relative-closure and regular-section integrability scopes remain explicit;
the printed smoothing and CLN proof steps are clarified using existing inputs.
All {nb} selected pages were freshly read in {nv} individual matching displays;
full validation and post-render gates pass. The
[activation record](manuscript/editorial/BE21_supnorm_integrability_cloud_activation_v1_20261009.json)
controls the {np:,}-page cloud edition. The native editor, canonical statuses
and general local/Siu/envelope boundaries remain unchanged. The BE21 source
basis is a partial union of 53 of 125 pages, not a complete article reading.
No original general theorem or new whole-book pass is claimed.

'''
(S/'README.md').write_text(t.replace(marker,intro+marker,1))
with zipfile.ZipFile(prep['baseline_minimal_source']['path']) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 members=old.namelist();assert len(members)==len(set(members))==472
 for n in members:assert (S/n).is_file();z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
 for n in z.namelist():assert z.read(n)==(S/n).read_bytes()
files={f'records/{q.name}':q for q in C.glob('*.json')}
q=C/'staged_book_validation_v1_20261009.log';files[f'logs/{q.name}']=q
for a in reading['views']:
 for key,folder in [('sequential_note_path','notes'),('observation_receipt_path','receipts'),('path','images'),('selected_text_path','text')]:
  q=Path(a[key]);files[f'final_v1/{folder}/{q.name}']=q
files['final_v1/prepared_manifest.json']=Path(release['manifest_path'])
for q in Path(prep['draft_path']).iterdir():files[f'drafts/v1/{q.name}']=q
for rel in prep['after']:files[f'staged_inputs/v1/{rel}']=S/rel
for q in Path('/tmp').glob('Supnorm_integrability_*_v1_20261009.py'):files[f'helpers/{q.name}']=q
for q in [paths['audit'],paths['reading_notes'],S/programme,S/'README.md']:files[f'editorial/{q.name}']=q
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
 assert len(z.namelist())==len(files)
 for n,q in files.items():assert z.read(n)==q.read_bytes()
artifacts={k:dict(path=str(q),bytes=q.stat().st_size,SHA256=sha(q)) for k,q in [('full_book_PDF',full),('selected_review_PDF',review),('minimal_TeX_source_archive',minimal),('actual_book_evidence_archive',evidence)]}
artifacts['selected_review_PDF']['physical_pages']=nb;artifacts['minimal_TeX_source_archive']['members']=472;artifacts['actual_book_evidence_archive']['members']=len(files)
progress={n:sha(S/n) for n in ['README.md',programme]}
manifest=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — staged mathematical, mechanical and actual rendered gate',preparation=prep,release=release,actual_reading=reading,mathematical_audit=math,post_render=post,underfull_comparison=under,artifacts=artifacts,progress_document_hashes=progress,source_publication_record_SHA256=prep['source_publication_SHA256'],norm_basechange_publication_record_SHA256=prep['norm_basechange_publication_SHA256'],active_book_changed=False,GitHub_published=False,canonical_status_changes=[])
paths['manifest'].write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — byte-verified owned book exports',artifacts=artifacts,reading_credit_from_export=0,active_book_changed=False,GitHub_published=False,canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
record.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — staged book checkpoint and owned artifacts exported',artifacts=artifacts,editorial_files={str(q):sha(q) for q in paths.values()},progress_document_hashes=progress,actual_final_book_pages=nb,actual_final_matching_views=nv,active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',record_SHA256=sha(record),book_pages=np,actual_selected_pages=nb,fresh_views=nv,evidence_members=len(files),artifacts=artifacts)))
