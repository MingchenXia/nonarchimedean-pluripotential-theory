from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, shutil, subprocess, zipfile

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BE21_reduced_fibre_integrability_review_20261009'
B=Path('/workspace/book-completion-drafts/model-green-norm-staging-v3-20261009')
S=Path('/workspace/book-completion-drafts/supnorm-integrability-staging-v1-20261009')
D=Path('/workspace/book-completion-drafts/supnorm-integrability-integration-v1-20261009')
out=C/'staging_preparation_v1_20261009.json'
assert not S.exists() and not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
publication=C/'GitHub_source_publication_v1_20261009.json'
pub=json.loads(publication.read_text())
assert head==pub['commit']=='265c02ae7e55b5e365329d8d701a00ca94ca1ebf'
assert pub['actual_primary_pages']==18 and pub['actual_matching_images']==9 and len(pub['files'])==9
sourceprep=json.loads((C/'primary_view_preparation_v1_20261009.json').read_text())
protected=sourceprep['protected_core_inputs']
for n,h in protected.items():
    if n not in ['README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']:
        assert sha(R/n)==h
for row in pub['files']:
    assert sha(R/row['path'])==row['SHA256'] and (R/row['path']).stat().st_size==row['bytes']
assert sha(R/'manuscript/book.pdf')==sha(B/'manuscript/book.pdf')=='911b133246651852333ba9bd0165643af389320a4acace1ccda1577660a10176'
minimal=Path('/workspace/book-completion-drafts/research-integration/Model_Green_Norm_Staged_Minimal_Source_V3_2026-10-09.zip')
assert sha(minimal)=='5d12cd03e34b9ed4256f409ca674378ef5262a350554124c169b1f5463045abf'
progress=['README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']
with zipfile.ZipFile(minimal) as z:
    members=z.namelist()
    assert len(members)==len(set(members))==472
    assert all(not Path(n).is_absolute() and '..' not in Path(n).parts for n in members)
    for n in members:
        assert (R/n).is_file()
        if n not in progress:assert z.read(n)==(R/n).read_bytes(),n
    S.mkdir();z.extractall(S)
for n in progress:
    target=S/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/n,target)
changed=['manuscript/parts/part2/ch19_cld_examples.tex','manuscript/appendices/appL_provenance.tex']
before={n:sha(R/n) for n in changed}
for n,h in before.items():assert sha(S/n)==h
fragments=sorted(D.iterdir());assert len(fragments)==2 and all(p.suffix=='.tex' for p in fragments)
for p in fragments:assert all(line==line.rstrip() for line in p.read_text().splitlines())
newlabel='sec:appL-supnorm-reduced-fibre-log-scope'
alltex={n:h for n,h in protected.items() if n.startswith('manuscript/') and n.endswith('.tex')}
assert len(alltex)==425
labels=set()
for n in alltex:labels.update(re.findall(r'\\label\{([^}]+)\}',(R/n).read_text()))
assert newlabel not in labels
assert {'sec:appL-local-psh-growth-boundary','sec:appL-model-green-norm-scope'}<=labels
q=S/changed[0];s=q.read_text();marker=r'\section{A first CLD--BFJ comparison}'
assert s.count(marker)==1
q.write_text(s.replace(marker,(D/'ch19_supnorm_integrability_fragment.tex').read_text()+marker,1))
q=S/changed[1];q.write_text(q.read_text()+(D/'appL_supnorm_integrability_fragment.tex').read_text().rstrip()+'\n')
unchanged={n:h for n,h in alltex.items() if n not in changed};assert len(unchanged)==423
for n,h in unchanged.items():assert sha(R/n)==sha(S/n)==h
envs=['theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important']
historical=[]
for n in changed:
    old=(R/n).read_text();new=(S/n).read_text();counts={}
    for env in envs:
        pattern=r'\\begin\{'+env+r'\}.*?\\end\{'+env+r'\}'
        blocks=re.findall(pattern,old,re.S)
        assert all(b in new for b in blocks)
        assert len(blocks)==len(re.findall(pattern,new,re.S))
        counts[env]=len(blocks)
    tags=re.findall(r'\\tag\{([^}]+)\}',old)
    assert tags==re.findall(r'\\tag\{([^}]+)\}',new)
    historical.append(dict(path=n,environment_counts=counts,historical_environment_blocks=sum(counts.values()),historical_proofs=counts['proof'],historical_manual_tags=len(tags),manual_tag_values=tags))
for row in pub['files']:
    if row['path'].startswith('manuscript/editorial/') and '/artifact_exports/' not in row['path']:
        target=S/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/row['path'],target)
normpub=R/'source_material/BE21_supnorm_basechange_review_20261009/GitHub_source_publication_v1_20261009.json'
assert json.loads(normpub.read_text())['commit']=='1078c9f41128ee4049250bf889c85a38e5c7b178'
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — exact attributed norm, reduced-fibre and logarithmic-integrability interfaces prepared in isolated stage',
    stage_path=str(S),baseline_stage_path=str(B),baseline_commit=head,
    baseline_minimal_source=dict(path=str(minimal),SHA256=sha(minimal),members=472),
    draft_path=str(D),before=before,after={n:sha(S/n) for n in changed},
    draft_fragments={str(p):sha(p) for p in fragments},active_inputs_preserved=before,
    other_active_TeX_preserved=unchanged,other_active_TeX_count=423,
    unchanged_bibliographies={n:sha(R/n) for n in ['manuscript/bibliography/ComplexGeometry.bib','manuscript/bibliography/NonArchimedean.bib']},
    historical_formal_blocks_preserved=historical,
    historical_environment_block_total=sum(x['historical_environment_blocks'] for x in historical),
    historical_proof_total=sum(x['historical_proofs'] for x in historical),
    historical_manual_tag_total=sum(x['historical_manual_tags'] for x in historical),
    active_book_PDF_SHA256=sha(R/'manuscript/book.pdf'),
    native_catalogue_preserved={n:h for n,h in protected.items() if n.startswith('output/')},
    source_checkpoint_SHA256=sha(C/'source_checkpoint_v1_20261009.json'),
    actual_primary_reading_SHA256=sha(C/'actual_primary_reading_v1_20261009.json'),
    exact_diagnostics_SHA256=sha(C/'exact_diagnostics_v2_20261009.json'),
    source_publication_SHA256=sha(publication),norm_basechange_publication_SHA256=sha(normpub),
    new_bibliographic_keys=[],new_semantic_label=newlabel,new_formal_environments=0,
    original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],
    active_book_changed=False,GitHub_published=False,actual_book_reading_credit=0,
    helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],record_SHA256=sha(out),other_TeX=423,
    historical_blocks=obj['historical_environment_block_total'],historical_proofs=obj['historical_proof_total'],
    historical_manual_tags=obj['historical_manual_tag_total'])))
