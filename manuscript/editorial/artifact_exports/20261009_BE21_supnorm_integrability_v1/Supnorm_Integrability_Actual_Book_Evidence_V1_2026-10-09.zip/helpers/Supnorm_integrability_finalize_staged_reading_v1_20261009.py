# Adapted frozen finalizer SHA256: da992338fb05efb86e6c19ed8ad552520f5a90ab2e9cf674ace10d6d701ae3b6
# Frozen preceding v2 helper SHA256: b74c923302908de918b3fd5b7df1e4822a425cdb20f797562f782f56be367106
# Frozen preceding v1 helper SHA256: 39ba4f1c83c4dfd7669fff3e855cfdf3a3ea993eaf9194b953ac5ef567f15006
# Frozen finalizer template SHA256: 5675e3f5d4705b09ee13d3e1417fdecb6b53736cfb26448154f172112dbac6e4
# Frozen preceding v2 helper SHA256: c5b299ebe6b5c1c75ecebc1ec7eb7ac33ae91ead99549c7d030218660fa1239d
# Prepared unexecuted v1 finalizer SHA256: 390f22feb156131659ca6f00809e832edd411c9c171e1c8829f3b8ea413e4b5a
from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, json, re, subprocess, difflib

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BE21_reduced_fibre_integrability_review_20261009'
S=Path('/workspace/book-completion-drafts/supnorm-integrability-staging-v1-20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
release=C/'staged_book_release_checks_v1_20261009.json'
ch=json.loads(release.read_text())
manifest=Path(ch['manifest_path'])
assert sha(manifest)==ch['manifest_SHA256']
xs=json.loads(manifest.read_text())
views=[]
last=None
for x in xs:
    assert not x['actually_viewed'] and not x['selected_text_read']
    n=C/'staged_book_notes_v1'/f"note_{x['number']:02d}.md"
    r=n.with_name(n.stem+'_receipt.json')
    receipt=json.loads(r.read_text())
    assert 'Read the complete selected text and displayed matching rendered image' in n.read_text()
    assert receipt['complete_selected_text_actually_read']
    assert receipt['matching_image_individually_displayed_and_reviewed']
    assert receipt['number']==x['number'] and receipt['physical_pages']==x['physical_pages']
    assert receipt['source_PDF_SHA256']==ch['PDF']['SHA256']
    assert sha(n)==receipt['note_SHA256']
    assert sha(x['path'])==receipt['image_SHA256']==x['image_SHA256']
    assert sha(x['selected_text_path'])==receipt['selected_text_SHA256']==x['selected_text_SHA256']
    assert last is None or receipt['UTC']>last
    last=receipt['UTC']
    y={k:v for k,v in x.items() if k not in ['actually_viewed','selected_text_read']}
    y.update(inspection_mode='Fresh complete text and individual matching image display',
             actual_complete_text_read=True,actual_matching_image_freshly_displayed=True,
             sequential_note_path=str(n),sequential_note_SHA256=sha(n),
             observation_receipt_path=str(r),observation_receipt_SHA256=sha(r))
    views.append(y)
pages=sorted({p for x in xs for p in x['physical_pages']})
assert pages==ch['selected_book_physical_pages']
assert sum(len(x['physical_pages']) for x in xs)==len(pages)
reading=C/'actual_staged_book_reading_v1_20261009.json'
audit=C/'staged_mathematical_self_audit_v1_20261009.json'
post=C/'post_render_checks_v1_20261009.json'
assert not any(q.exists() for q in (reading,audit,post))
prep=json.loads((C/'staging_preparation_v1_20261009.json').read_text())
checks=[]
for command in (['python3','editorial/tools/refcheck.py'],
                ['python3','editorial/tools/check_open_problem_inventory.py']):
    run=subprocess.run(command,cwd=S/'manuscript',text=True,
                       stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    assert run.returncode==0,run.stdout
    checks.append(dict(command=command,returncode=run.returncode,output=run.stdout))
for n,h in prep['after'].items():
    assert sha(S/n)==h
for n,h in prep['other_active_TeX_preserved'].items():
    assert sha(R/n)==sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():
    assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
for n,h in prep['native_catalogue_preserved'].items():
    assert sha(R/n)==h
for n,h in prep['unchanged_bibliographies'].items():
    assert sha(R/n)==sha(S/n)==h
historical={}
whitespace={}
for n in ('manuscript/parts/part2/ch19_cld_examples.tex','manuscript/appendices/appL_provenance.tex'):
    before=(R/n).read_text()
    after=(S/n).read_text()
    counts={}
    for env in ('theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important'):
        patt=r'\\begin\{'+env+r'\}.*?\\end\{'+env+r'\}'
        blocks=re.findall(patt,before,re.S)
        assert all(b in after for b in blocks)
        assert len(blocks)==len(re.findall(patt,after,re.S))
        counts[env]=len(blocks)
    tags=re.findall(r'\\tag\{([^}]+)\}',before)
    assert tags==re.findall(r'\\tag\{([^}]+)\}',after)
    historical[n]=dict(byte_preserved_environment_blocks=counts,prior_manual_equation_tags=tags)
assert sum(sum(v['byte_preserved_environment_blocks'].values()) for v in historical.values())==92
assert sum(v['byte_preserved_environment_blocks']['proof'] for v in historical.values())==25
assert sum(len(v['prior_manual_equation_tags']) for v in historical.values())==6
for n in prep['after']:
    before=(R/n).read_text().splitlines()
    after=(S/n).read_text().splitlines()
    wb=Counter(x for x in before if x!=x.rstrip())
    wa=Counter(x for x in after if x!=x.rstrip())
    assert wb==wa
    added=[x[2:] for x in difflib.ndiff(before,after) if x.startswith('+ ')]
    assert all(x==x.rstrip() for x in added)
    run=subprocess.run(['git','diff','--no-index','--check',str(R/n),str(S/n)],
                       text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    assert run.returncode in (0,1) and run.stdout=='',(run.returncode,run.stdout)
    whitespace[n]=dict(historical_whitespace_lines_preserved=sum(wb.values()),
                       added_lines_checked=len(added),added_trailing_whitespace_lines=0,
                       no_index_returncode=run.returncode,no_index_diagnostic_output=run.stdout,
                       EOF_whitespace_check='PASS')
for q,h in prep['draft_fragments'].items():
    assert sha(q)==h
    assert all(x==x.rstrip() for x in Path(q).read_text().splitlines())
underfull=json.loads((C/'staged_underfull_delta_v1_20261009.json').read_text())
reading.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — all selected book pages freshly read and individually displayed',
    PDF=ch['PDF'],actual_unique_book_pages=len(pages),
    fresh_complete_text_and_individually_displayed_pages=len(pages),
    fresh_matching_views=len(views),reused_exact_complete_text_and_rendered_pixel_pages=0,
    reused_matching_views=0,views=views,legacy_preparation_flags_rewritten=False,
    remaining_repairs=[],whole_book_new_reading_claim=False,
    active_book_changed=False,GitHub_published=False,canonical_status_changes=[],
    helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
mathchecks=['Published BE21 is a partial source reading: previous 29 pages/15 views, new supnorm 11 pages/6 views, and reduced-fibre/log-integrability 18 pages/9 views have a union of 53 distinct controlling PDF pages of 125; 72 are unread in these checkpoints. Earlier analytic/algebraic inputs remain attributed, not recursively certified.', 'Theorem 6.6 uses projective geometrically reduced X, any line bundle, a continuous metric and any complete field extension. It gives o(m) logarithmic norm distance and model O(1); neither ampleness nor pshness is required. Zero section spaces have distance zero and no rate/uniform varying-data estimate is asserted.', 'Equality on original K-sections is weaker than equality on the scalar-extended section space. Lemma 6.1 has pulled-back supnorm less than or equal to extended norm; the exact-equality criterion of 6.2 retains finite Galois, nontrivially discretely valued and tame hypotheses.', 'The model comparison retains one coherent-quotient annihilator, finite common-model twist families, exponent-independent bounds and C^r product scaling. Actual lattice extension is Lemma 1.29(iv), not just printed 1.28. The continuous metric estimate C_epsilon+2m epsilon gives limsup at most 2epsilon and no free convergence rate.', 'Total-model regularity does not imply reduced special fibre: Q[[pi]] to Q[[z]], pi=z^2, has nonreduced special fibre. Theorem 4.19 converse uses a dense value group; 4.20 finite closure requires nontrivial discrete or algebraically closed ground field, with special-fibre reducedness in the algebraically closed case.', 'The completed Gauss field H has value group Z+sqrt(2)Z, dense and missing 1/2. L=H(z), z^2=pi, is degree two and reduced; disjoint value cosets give the minimum formula and L^circ=H^circ plus Iz, with I an open valuation cut. No least value implies nonfinite relative closure. This concrete direct worked boundary is attributed to Remark 4.21 and does not contradict the algebraically-closed step of 6.6.', 'Theorem 8.12 uses the fundamental n-cycle, continuous global psh-regularizable metrics and a regular Cartier section. Nonzero on a disconnected scheme is insufficient. In dimension zero a regular section is a unit on every Artinian factor.', 'Ordinary half-log(1+|T|^2) is not non-Archimedean CLD-smooth near a rational zero, since any finite analytic-unit logarithm presentation is locally constant there. This diagnoses Lemma 8.13 smoothing, not a counterexample to 8.12. The existing regularized-maximum input of 7.12/7.14 supplies the explanatory reformulation.', 'The FS metrics psi_j=max(log|s|+psi_prime,theta-j) are continuous psh-regularizable on very ample A=L+A_prime. With phi_ref=theta-psi_prime, f_j=psi_j-theta decreases to the target log; both metrics in the difference are explicitly regularizable. An arbitrary smooth dpsh reference would not establish that premise.', 'The CLN estimate extends by uniform approximation and fixed positive masses; its dd^c(phi_0-phi_prime_0) expansion requires minus, although the absolute bound survives. The tuple comparison constant is independent of j. A cited local smooth logarithmic-L1 anchor, decreasing bounded-above f_j and finite inequalities give all tuple integrals and continuity without infinity-minus-infinity. Arbitrary continuous metric change adds a bounded continuous function handled by 8.4.', 'Poincare-Lelong and Deligne restriction retain uniform logarithmic-integral continuity, regular sections and minus-log conventions. Weak convergence alone is insufficient. The unit does not prove arbitrary local USC weak-psh descent, affine lower-growth regularization, model-Chow-to-CLD comparisons or critical homogeneous Siu/envelopes.', 'The two changed TeX roots preserve 92 historical environment blocks including 25 proofs and six manual tags. No new formal environment or manual tag is added; all other 423 core TeX inputs and both bibliographies remain byte unchanged.', 'The native catalogue/editor, 42 canonical atoms and twelve formal problems retain their statuses. General BJ22 critical homogeneous Siu/envelopes remain OPEN, LPWZ density UNVERIFIED. The BJ22 6.21 proof warning remains binding; no original general theorem, independent-model receipt or new complete whole-book reading is claimed.']

audit.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — ordinary scoped mathematical audit and actual rendered clearance',
    checks=mathchecks,source_input_hashes=prep['after'],draft_fragments=prep['draft_fragments'],
    actual_final_book_reading_SHA256=sha(reading),actual_final_book_reading_credit=len(pages),
    source_scope='Published BE21 partial union 53 of 125 primary pages: earlier 29/15, supnorm 11/6 and reduced-fibre/log-integrability 18/9; direct worked boundaries and attributed foundations',
    exact_diagnostics_SHA256=sha(C/'exact_diagnostics_v2_20261009.json'),
    norm_basechange_diagnostics_SHA256=sha(R/'source_material/BE21_supnorm_basechange_review_20261009/exact_diagnostics_v1_20261009.json'),
    underfull_comparison_SHA256=sha(C/'staged_underfull_delta_v1_20261009.json'),
    new_underfull_blocks=underfull['added_blocks'],original_results_promoted=[],
    independent_model_receipt=None,canonical_status_changes=[],whole_book_new_reading_claim=False,
    helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
post.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE',
    checks=checks,source_input_hashes=prep['after'],rendered_gate_SHA256=sha(reading),
    historical_formal_proof_warning_important_blocks_byte_preserved=historical,
    other_active_TeX_inputs_byte_preserved=423,whitespace_gate='PASS including EOF',
    whitespace_details=whitespace,legacy_writing_audit_unavailable=True,
    manual_semantic_delimiter_source_and_rendered_audits_used=True,
    active_book_changed=False,GitHub_published=False,canonical_status_changes=[],
    helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',actual_reading_SHA256=sha(reading),
                     math_audit_SHA256=sha(audit),post_render_SHA256=sha(post),
                     actual_pages=len(pages),fresh_views=len(views))))
