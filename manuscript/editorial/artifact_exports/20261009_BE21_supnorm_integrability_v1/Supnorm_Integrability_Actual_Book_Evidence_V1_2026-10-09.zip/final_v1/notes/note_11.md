# Supnorm and logarithmic-integrability book review — view 11

Physical pages: [4625, 4626].

Read the complete selected text and displayed matching rendered image.

Read all Q-continuation through T entries on printed 4547–4548. The two new nested entries, relative integral closure/nonfinite case and supnorm/ground field extension, both render with the intended L.98 section-start locator 4327. Their parent names, indentation and blue numbers are legible. Existing Siu-decomposition, source-audit, special-fibre, strong-topology and toric entries remain intact; adding these navigational terms makes no theorem-status change. No new column collision or clipped locator appears.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
