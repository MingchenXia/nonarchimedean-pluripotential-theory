# Supnorm and logarithmic-integrability book review — view 5

Physical pages: [4406, 4407].

Read the complete selected text and displayed matching rendered image.

The full scalar-extension comparison retains fixed-data o(m), model O(1), lack of ampleness/psh assumptions, the correct inequality direction, finite tame Galois scope, exponent-independent model constants, and the corrected 2-epsilon limsup. The relative-closure example shows regular total DVR with nonreduced special fibre, the discrete/algebraically-closed restriction of 4.20, and the dense Gauss group without 1/2. The extension z-squared=pi, two disjoint valuation cosets and open-cut ideal establish nonfiniteness; the three-part valuation display fits the text width. The log-integrability statement preserves the fundamental cycle and regular section, explains the ordinary log-sum smoothness defect at a rational zero, separates n=0, and starts the FS maximum construction with both very ample bundles. Formulas and citation seams are legible.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
