# Supnorm and logarithmic-integrability book review — view 3

Physical pages: [1366, 1367].

Read the complete selected text and displayed matching rendered image.

The new common-core paragraph prints o(m) and O(1) correctly, keeps geometric reducedness, projectivity, continuity and arbitrary line bundle visible, and explicitly separates asymptotic extended-section norms from exact equality. Its logarithmic-integrability statement requires a regular Cartier section and refers to L.98 for the smoothing repair. The complete 19.8 endpoint and first two pages of 19.9 retain the BFJ scope (19.60), distinction between K and its completed algebraic closure, readable framework table, minus-log convention and initial comparison theorem. Citations and cross-references render without missing text or collisions.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
