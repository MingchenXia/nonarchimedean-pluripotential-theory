# Supnorm and logarithmic-integrability book review — view 9

Physical pages: [4621, 4622].

Read the complete selected text and displayed matching rendered image.

Read all G-continuation through M entries on printed 4543–4544. The existing Green-current regular-model locator remains 4323; integral-closure terms and model/metric distinctions stay separate. The harmonic, Hessian, Hodge–Riemann, Kähler, Kołodziej, Lê and Legendre entries retain readable accents and indentation. The long canonical-formal-metric and K3 captions wrap within columns. No overlap, clipped nested entry or malformed mathematical font is visible.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
