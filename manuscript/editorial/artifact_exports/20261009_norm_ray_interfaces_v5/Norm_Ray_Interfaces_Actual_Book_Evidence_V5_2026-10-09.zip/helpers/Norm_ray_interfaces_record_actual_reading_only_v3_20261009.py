# Records the completed actual V3 reading separately from failed release clearance. Frozen failed finalizer SHA256: a24445f570d0313a389548e92b54b93083f8242c78af35a0b7453016010172aa
# Fresh v3 follows actual layout review. Frozen preceding unexecuted helper SHA256: 766775a17ac85bd241ab8c057bf8a4c18f3b79712da7b1b0f6674c6d14755599
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,re,subprocess,difflib
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Metric_radial_dependencies_review_20261009';S=Path('/workspace/book-completion-drafts/norm-ray-interfaces-staging-v3-20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda n:json.loads((C/n).read_text())
ch=load('staged_book_release_checks_v3_20261009.json');prep=load('staging_preparation_v3_20261009.json');mp=Path(ch['manifest_path']);assert sha(mp)==ch['manifest_SHA256'];xs=json.loads(mp.read_text());views=[];last=None
for x in xs:
    assert not x['actually_viewed'] and not x['selected_text_read']
    n=C/'staged_book_notes_v3'/f"note_{x['number']:02d}.md";r=n.with_name(n.stem+'_receipt.json');a=json.loads(r.read_text())
    assert 'Read the complete selected text and displayed matching rendered image' in n.read_text()
    assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
    assert a['number']==x['number'] and a['physical_pages']==x['physical_pages'] and a['source_PDF_SHA256']==ch['PDF']['SHA256']
    assert sha(n)==a['note_SHA256'] and sha(x['path'])==a['image_SHA256']==x['image_SHA256'] and sha(x['selected_text_path'])==a['selected_text_SHA256']==x['selected_text_SHA256']
    assert last is None or a['UTC']>last;last=a['UTC']
    y={k:v for k,v in x.items() if k not in ['actually_viewed','selected_text_read']};y.update(actual_complete_text_read=True,actual_matching_image_freshly_displayed=True,sequential_note_path=str(n),sequential_note_SHA256=sha(n),observation_receipt_path=str(r),observation_receipt_SHA256=sha(r));views.append(y)
pages=sorted({p for x in xs for p in x['physical_pages']});assert pages==ch['selected_book_physical_pages'] and sum(len(x['physical_pages']) for x in xs)==len(pages)
reading=C/'actual_staged_book_reading_v3_20261009.json';assert not reading.exists()
reading.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — actual complete selected V3 reading only; separate source whitespace check failed; no final release clearance',PDF=ch['PDF'],actual_unique_book_pages=len(pages),fresh_complete_text_and_individually_displayed_pages=len(pages),fresh_matching_views=len(views),reused_exact_complete_text_and_rendered_pixel_pages=0,reused_matching_views=0,views=views,legacy_preparation_flags_rewritten=False,remaining_repairs=[],whole_book_new_reading_claim=False,active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(sha(reading))
