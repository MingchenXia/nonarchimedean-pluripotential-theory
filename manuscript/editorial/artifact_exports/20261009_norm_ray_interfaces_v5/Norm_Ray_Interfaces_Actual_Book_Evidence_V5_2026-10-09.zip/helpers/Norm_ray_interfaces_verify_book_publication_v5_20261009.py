# Fresh V5 editorial/artifact publication only; frozen V4 helper SHA256 05ee227779178db496099bd82ac498cf1d6f3ed644491cfb295327df4cf44b4f
# Fresh v5 follows source whitespace check. Frozen v3 helper SHA256: 017b786e6cc12d96a763d7bd97520bef7b60e0ee76d256c3d6b58b126fa47ceb
# Adapted frozen publication verifier SHA256: e6f80e945cb7a669c7c99129d13b91b8f89035adb02d9023197529284ff3d6cf
# Adapted frozen helper SHA256: 4b1ea42fded4ddc50f88ca78e2870f19dc9317d259a106f30e335c2848809059
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Metric_radial_dependencies_review_20261009'
out=C/'GitHub_book_publication_v5_20261009.json';assert not out.exists()
repo='MingchenXia/nonarchimedean-pluripotential-theory'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
api=lambda ep:json.loads(subprocess.check_output(['gh','api',ep],cwd=R,text=True))
local=json.loads((C/'local_book_commit_v5_20261009.json').read_text())
head=local['commit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==head
assert api(f'repos/{repo}/git/ref/heads/work')['object']['sha']==head
main=api(f'repos/{repo}/git/ref/heads/main')['object']['sha']
assert main=='00957114db21b627e97369563032ceda9cea09c7'
tree=api(f'repos/{repo}/git/trees/{head}?recursive=1');assert not tree['truncated']
mapping={a['path']:a for a in tree['tree'] if a['type']=='blob'}
rows=[]
for rel,h in local['files'].items():
 p=R/rel;assert sha(p)==h
 blob=subprocess.check_output(['git','hash-object',str(p)],cwd=R,text=True).strip()
 assert mapping[rel]['sha']==blob and mapping[rel]['size']==p.stat().st_size
 rows.append(dict(path=rel,bytes=p.stat().st_size,SHA256=h,local_and_remote_Git_blob_SHA1=blob))
assert len(rows)==16
for n,h in local['native_catalogue_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==local['active_PDF']['SHA256']
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — sixteen final source/progress/audit/artifact remote blobs verified',
 repository=repo,branch='work',commit=head,main_unchanged=main,files=rows,
 active_book_PDF=local['active_PDF'],actual_selected_book_pages=local['actual_selected_book_pages'],fresh_matching_views=local['fresh_matching_views'],reused_matching_views=local['reused_matching_views'],
 selected_dependency_source_record_SHA256=sha(C/'GitHub_source_publication_v1_20261009.json'),
 arbitrary_local_weak_psh_descent_established=False,affine_lower_growth_regularization_established=False,
 general_envelope_theorem_admitted=False,native_editor_changed=False,
 reading_credit_from_upload=0,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',commit=head,files=len(rows),record_SHA256=sha(out))))
