# Fresh V5 editorial/artifact publication only; frozen V4 helper SHA256 24f2e3a267c4608945bc64cd3e9d28b9bb1059f35cbeee37d0415cb27b2894f0
# Fresh norm-ray publication verifier from frozen helper SHA256 0fb77a4aa2ef8258db314ed9e493dac3668117cb1c59477567e17a697b00d46d
# Adapted frozen verifier SHA256: 792f91f0299c7f42a19416a0e8bdb50995b47157126fdb9c169beccef36c57d5
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R / 'source_material/Metric_radial_dependencies_review_20261009'
out = C / 'GitHub_publication_documentation_verified_v5_20261009.json'
assert not out.exists()
repo = 'MingchenXia/nonarchimedean-pluripotential-theory'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
api = lambda ep: json.loads(subprocess.check_output(['gh', 'api', ep], cwd=R, text=True))
doc = json.loads((C / 'publication_documentation_v5_20261009.json').read_text())
head = doc['commit']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == head
assert api(f'repos/{repo}/git/ref/heads/work')['object']['sha'] == head
main = api(f'repos/{repo}/git/ref/heads/main')['object']['sha']
assert main == '00957114db21b627e97369563032ceda9cea09c7'
tree = api(f'repos/{repo}/git/trees/{head}?recursive=1')
assert not tree['truncated']
mapping = {x['path']: x for x in tree['tree'] if x['type'] == 'blob'}
rows = []
for rel, h in doc['files'].items():
    p = R / rel
    assert sha(p) == h
    blob = subprocess.check_output(['git', 'hash-object', str(p)], cwd=R, text=True).strip()
    assert mapping[rel]['sha'] == blob and mapping[rel]['size'] == p.stat().st_size
    rows.append(dict(path=rel, bytes=p.stat().st_size, SHA256=h, local_and_remote_Git_blob_SHA1=blob))
assert len(rows) == 3
book = json.loads((C / 'GitHub_book_publication_v5_20261009.json').read_text())
for row in book['files']:
    if row['path'] not in doc['files']:
        assert mapping[row['path']]['sha'] == row['local_and_remote_Git_blob_SHA1'] and mapping[row['path']]['size'] == row['bytes']
body = Path('/tmp/book_continuation_PR2_body_norm_ray_v5_20261009.md')
patch = json.loads(Path('/tmp/book_continuation_PR2_patch_norm_ray_v5_20261009.json').read_text())
pr = api(f'repos/{repo}/pulls/2')
assert pr['draft'] and pr['state'] == 'open' and pr['base']['ref'] == 'main' and pr['head']['ref'] == 'work'
assert pr['head']['sha'] == head and pr['body'] == body.read_text() == patch['body'] and pr['title'] == patch['title']
prep = json.loads((C / 'staging_preparation_v4_20261009.json').read_text())
for n, h in prep['native_catalogue_preserved'].items():
    assert sha(R / n) == h
assert sha(R / 'manuscript/book.pdf') == book['active_book_PDF']['SHA256']
assert not subprocess.check_output(['git', 'diff', '--name-only'], cwd=R, text=True).strip()
assert not subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=R, text=True).strip()
obj = dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — publication documentation and final draft PR text remotely verified',
    commit=head, book_and_evidence_commit=book['commit'], main_unchanged=main, files=rows,
    other_book_artifact_blobs_still_match=True,
    PR=dict(number=2, url=pr['html_url'], draft=True, title=pr['title'], body_SHA256=sha(body), body_characters=len(pr['body']), body_exactly_matches=True),
    native_editor_changed=False, reading_credit_from_publication=0, canonical_status_changes=[], helper_source=__file__)
out.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(status='DONE', commit=head, record_SHA256=sha(out), PR=pr['html_url'])))
