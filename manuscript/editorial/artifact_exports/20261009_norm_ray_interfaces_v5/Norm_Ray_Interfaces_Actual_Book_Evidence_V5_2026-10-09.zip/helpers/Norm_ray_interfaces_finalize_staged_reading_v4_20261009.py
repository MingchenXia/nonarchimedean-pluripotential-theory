# Fresh V4 verifies exact reading reuse after one blank EOF line removal; frozen failed V3 helper SHA256 a24445f570d0313a389548e92b54b93083f8242c78af35a0b7453016010172aa
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,re,subprocess,difflib,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Metric_radial_dependencies_review_20261009';S=Path('/workspace/book-completion-drafts/norm-ray-interfaces-staging-v4-20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda n:json.loads((C/n).read_text())
ch=load('staged_book_release_checks_v4_20261009.json');prep=load('staging_preparation_v4_20261009.json');old=load('actual_staged_book_reading_v3_20261009.json');mp=Path(ch['manifest_path']);assert sha(mp)==ch['manifest_SHA256'];xs=json.loads(mp.read_text());assert len(xs)==len(old['views'])==13
reading=C/'actual_staged_book_reading_v4_20261009.json';audit=C/'staged_mathematical_self_audit_v4_20261009.json';post=C/'post_render_checks_v4_20261009.json';reuse=C/'staged_exact_render_reuse_v4_20261009.json';assert not any(p.exists() for p in [reading,audit,post,reuse])
oldprep=load('staging_preparation_v3_20261009.json');oldstage=Path(oldprep['stage_path']);deltas={}
for n in prep['after']:
    a=(oldstage/n).read_bytes();b=(S/n).read_bytes()
    if n.endswith('ch65_rays_filtrations.tex'):assert a==b+b'\n';deltas[n]='Exactly one trailing blank line removed'
    else:assert a==b;deltas[n]='Byte identical'
assert sha(old['PDF']['path'])==old['PDF']['SHA256'];assert sha(ch['PDF']['path'])==ch['PDF']['SHA256'];views=[];proofs=[];last=None
with fitz.open(old['PDF']['path']) as a,fitz.open(ch['PDF']['path']) as b:
    assert len(a)==len(b)==4663
    for x,y in zip(xs,old['views']):
        assert not x['actually_viewed'] and not x['selected_text_read'];assert x['number']==y['number'] and x['physical_pages']==y['physical_pages']
        n=Path(y['sequential_note_path']);r=Path(y['observation_receipt_path']);receipt=json.loads(r.read_text());assert sha(n)==y['sequential_note_SHA256']==receipt['note_SHA256'];assert sha(r)==y['observation_receipt_SHA256'];assert receipt['complete_selected_text_actually_read'] and receipt['matching_image_individually_displayed_and_reviewed'];assert receipt['source_PDF_SHA256']==old['PDF']['SHA256'];assert last is None or receipt['UTC']>last;last=receipt['UTC']
        assert sha(y['path'])==y['image_SHA256']==receipt['image_SHA256'];assert sha(y['selected_text_path'])==y['selected_text_SHA256']==receipt['selected_text_SHA256'];assert sha(x['path'])==x['image_SHA256'];assert sha(x['selected_text_path'])==x['selected_text_SHA256']
        pp=[]
        for number in x['physical_pages']:
            p=a[number-1];q=b[number-1];assert p.rect==q.rect and p.rotation==q.rotation
            tx=p.get_text();ty=q.get_text();assert tx==ty
            px=p.get_pixmap(matrix=fitz.Matrix(1.4,1.4),alpha=False);py=q.get_pixmap(matrix=fitz.Matrix(1.4,1.4),alpha=False);assert (px.width,px.height,px.n)==(py.width,py.height,py.n) and px.samples==py.samples
            item=dict(physical_page=number,complete_extracted_text_SHA256=hashlib.sha256(tx.encode()).hexdigest(),full_rendered_RGB_pixels_SHA256=hashlib.sha256(px.samples).hexdigest(),pixel_dimensions=[px.width,px.height],matrix=1.4);proofs.append(item);pp.append(item)
        row={k:v for k,v in x.items() if k not in ['actually_viewed','selected_text_read']};row.update(actual_complete_text_read=True,actual_matching_image_freshly_displayed=False,actual_matching_image_reused_after_exact_text_and_rendered_pixel_identity=True,original_actually_reviewed_view=y,exact_complete_page_text_and_full_pixel_proofs=pp,sequential_note_path=str(n),sequential_note_SHA256=sha(n),observation_receipt_path=str(r),observation_receipt_SHA256=sha(r));views.append(row)
pages=sorted({p for x in xs for p in x['physical_pages']});assert pages==ch['selected_book_physical_pages'] and len(proofs)==len(pages)==25
reuse.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — exact selected complete text and full rendered book-pixel identity; original V3 actual reading retained',source_delta=deltas,old_PDF=old['PDF'],new_PDF=ch['PDF'],original_actual_reading_SHA256=sha(C/'actual_staged_book_reading_v3_20261009.json'),original_actual_views=13,original_actual_pages=25,selected_page_equality_proofs=proofs,new_fresh_display_credit=0,preparation_flags_rewritten=False,helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
checks=[]
for command in [['python3','editorial/tools/refcheck.py'],['python3','editorial/tools/check_open_problem_inventory.py']]:
    run=subprocess.run(command,cwd=S/'manuscript',text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);assert run.returncode==0,run.stdout;checks.append(dict(command=command,returncode=run.returncode,output=run.stdout))
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
for n,h in prep['other_active_TeX_preserved'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['unchanged_bibliographies'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
assert (S/'manuscript/bibliography/ComplexGeometry.bib').read_bytes()==(R/'manuscript/bibliography/ComplexGeometry.bib').read_bytes()+Path(prep['draft_path'],'ComplexGeometry_norm_ray_entries.bib').read_bytes()
historical={};whitespace={}
for row in prep['historical_formal_blocks_preserved']:
    n=row['path'];before=(R/n).read_text();after=(S/n).read_text();counts={}
    for e,count in row['environment_counts'].items():
        pat=r'\\begin\{'+e+r'\}.*?\\end\{'+e+r'\}';blocks=re.findall(pat,before,re.S);assert all(b in after for b in blocks);assert len(blocks)==len(re.findall(pat,after,re.S))==count;counts[e]=count
    assert re.findall(r'\\tag\{([^}]+)\}',after)==row['historical_manual_tags'];historical[n]=row
for n in prep['after']:
    before=(R/n).read_text().splitlines();after=(S/n).read_text().splitlines();assert Counter(x for x in before if x!=x.rstrip())==Counter(x for x in after if x!=x.rstrip())
    added=[x[2:] for x in difflib.ndiff(before,after) if x.startswith('+ ')];assert all(x==x.rstrip() for x in added)
    run=subprocess.run(['git','diff','--no-index','--check',str(R/n),str(S/n)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);assert run.returncode in [0,1] and not run.stdout
    whitespace[n]=dict(added_lines=len(added),added_trailing_whitespace=0,check_returncode=run.returncode)
for p,h in prep['draft_fragments'].items():assert sha(p)==h
under=load('staged_underfull_delta_v4_20261009.json');assert not under['added_blocks'] and not under['removed_blocks']
reading.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — selected V3 actual reading retained under exact complete text and full rendered pixel identity for V4',PDF=ch['PDF'],actual_unique_book_pages=len(pages),fresh_complete_text_and_individually_displayed_pages=0,fresh_matching_views=0,reused_exact_complete_text_and_rendered_pixel_pages=len(pages),reused_matching_views=len(views),original_fresh_V3_actual_pages=25,original_fresh_V3_matching_views=13,views=views,exact_reuse_record_SHA256=sha(reuse),legacy_preparation_flags_rewritten=False,remaining_repairs=[],whole_book_new_reading_claim=False,active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
mathchecks=[
    'The finite complex sum envelope uses finite decompositions, positivity bounds from finitely many weights, and the largest-genuine-norm property. The adapted quadratic Hermitian construction is separate.',
    'For Hermitian reference and orthonormal adapted basis, filtration weight is the least nonzero coordinate weight. Hence H<=gauge, H<=A, and coordinate Cauchy–Schwarz gives A<=sqrt(N)H. These are direct attributed finite-dimensional explanations, not a new general theorem.',
    'The C2 example has gauge eta on e1 and sqrt(2)eta elsewhere. Supporting a+b and a-b give A(1,±1)=2 versus H(1,1)=sqrt(3); homogeneity and coordinate supporting functionals give A(2,0)=2,A(0,2)=2sqrt(2), so the parallelogram identity fails.',
    'Ordinary log length distance delta_infinity differs by factor 2 from the published complex Finski distance. Thus the sqrt(rank) comparison has error log(rank) in the latter, and divided degree error tends to zero under polynomial Hilbert growth. The chapter squared radial parameter t=2s is explicit.',
    'The graded product argument assumes genuine submultiplicativity of the base norm and filtration, sums all pairs of decomposition pieces, excludes zero products before taking logarithmic weights, factors the sums and then takes infima. It does not assert arbitrary Hermitian rays are multiplicative.',
    'Published Finski Lemma 2.6 and Corollary 3.5 supply version-specific locators. The finite-p FS theorem retains ample, bounded and submultiplicative premises and regularized FS; infinity needs raw continuity. Section 4 tensor classification and original Darvas quantization are not recursively certified by the selected 1–24 pages.',
    'The complete RWN25 arXiv v2 supplies the affine extension below the limiting DH support when the right derivative is finite. The rare outlier probability example has a full finite interval and finite-p vanishing difference, but possibly persistent maximal difference. It is explanatory, not a proof of the general main flat theorem.',
    'Parreau selected 21–26 expressly requires a maximal apartment system for ray/line and Euclidean-flat containment. An arbitrary chosen basis atlas needs an additional identification or direct argument; the general Euclidean proof does not automatically apply to L1. Scalar norm directions are retained.',
    'BE21 Section 9 uses a complete field and geometric reducedness, with geometric integrality added by 9.5. Boundedness is relative to a fixed metric. Complete algebraically closed extension has a controlled o(m^(n+1)) determinant error before the rational regular point. Separate superadditive leaf logs are distinguished from their difference.',
    'Signed total volume n!/m^(n+1) and probability mean 1/(mN_m) differ by vol(L); P1,O(2) gives 2c versus c. Nonbig total volume is zero. Signed mean convergence is not all-moment or spectral-law convergence.',
    'The trivial classical-disc coefficient paragraph and nonpure top-component injection need the source-local repairs stated. These diagnose proof scope rather than claim false intended volume theorems. General BJ22 Siu/envelopes remain OPEN and LPWZ density UNVERIFIED.',
    'V4 removes only one extra EOF blank line after V3 actual reading. Its exact source delta, matching text and pixels are pinned. Fresh v2 appends the new chapter section after its historical source note, preserving its implicit old label 65.18. V1 compiles but fails that preservation preflight and is not activated. All other 423 core TeX and NA bibliography remain unchanged. Complex bibliography appends exactly two pinned entries with distinct shorthands preserving old labels.',
    'Actual complete V3 reading is retained for V4 only after exact complete selected page text and full rendered pixel equality checks. The selected changed sections and seams, contents, new bibliography entries and all affected index pages remain the only book-reading scope. Last full ordered book pass remains 4 October. No new original general theorem, independent hostile-model receipt or canonical status change is claimed.'
]
audit.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — ordinary scoped mathematical audit and actual rendered clearance',checks=mathchecks,actual_final_book_reading_SHA256=sha(reading),source_scope='Partial Finski published 1–24, Parreau author 21–26 and BE21 published 87–94; complete separately audited RWN25 arXiv v2; external foundational proofs remain attributed',source_input_hashes=prep['after'],draft_fragments=prep['draft_fragments'],original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
post.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — post-render reference/inventory and source preservation checks',checks=checks,historical_formal_blocks_preserved=historical,whitespace_checks=whitespace,underfull_delta_SHA256=sha(C/'staged_underfull_delta_v4_20261009.json'),actual_final_reading_SHA256=sha(reading),mathematical_audit_SHA256=sha(audit),release_checks_SHA256=sha(C/'staged_book_release_checks_v4_20261009.json'),semantic_notation_delimiter_review='Actual complete selected text and individual corresponding image review; no unavailable legacy automated audit claimed',active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',selected_book_pages=len(pages),views=len(views),reading_SHA256=sha(reading),math_SHA256=sha(audit),post_SHA256=sha(post))))
