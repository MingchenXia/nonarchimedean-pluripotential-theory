from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R / 'source_material/Metric_radial_dependencies_review_20261009'
E = R / 'manuscript/editorial'
out = E / 'norm_ray_interfaces_GitHub_publication_v4_20261009.json'
record = C / 'publication_documentation_v4_20261009.json'
assert not out.exists() and not record.exists()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
git = lambda *a: subprocess.check_output(['git', *a], cwd=R, text=True).strip()
remote = C / 'GitHub_book_publication_v4_20261009.json'
x = json.loads(remote.read_text())
source = C / 'GitHub_source_publication_v1_20261009.json'
s = json.loads(source.read_text())
export = json.loads((C / 'staged_export_v4_20261009.json').read_text())
reading = json.loads((C / 'actual_staged_book_reading_v4_20261009.json').read_text())
assert len(x['files']) == 16 and x['active_book_PDF']['physical_pages'] == 4663
assert x['actual_selected_book_pages'] == 25 and x['fresh_matching_views'] == 0 and x['reused_matching_views'] == 13
assert len(s['files']) == 9 and s['actual_primary_pages'] == 38 and s['actual_matching_images'] == 19
assert git('rev-parse', 'HEAD') == x['commit'] and not git('diff', '--name-only') and not git('diff', '--cached', '--name-only')
for row in x['files']:
    assert sha(R / row['path']) == row['SHA256']
for row in s['files']:
    b = subprocess.check_output(['git', 'show', s['commit'] + ':' + row['path']], cwd=R)
    assert hashlib.sha256(b).hexdigest() == row['SHA256'] and len(b) == row['bytes']
artifact_directory = 'manuscript/editorial/artifact_exports/20261009_norm_ray_interfaces_v4'
obj = dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — verified norm-ray and source-interface book/evidence GitHub publication',
    book_publication=x, book_publication_record_SHA256=sha(remote),
    selected_dependency_source_publication=s, selected_dependency_source_record_SHA256=sha(source),
    artifact_directory=artifact_directory, actual_final_book_pages=25,
    original_fresh_V3_book_pages=25, original_fresh_V3_matching_views=13,
    fresh_V4_book_pages=0, fresh_V4_matching_views=0,
    exact_complete_text_and_full_rendered_pixel_reused_book_pages=25,
    exact_reused_matching_views=13,
    exact_reuse_record_SHA256=sha(C / 'staged_exact_render_reuse_v4_20261009.json'),
    source_scope='Partial Finski published 1–24, Parreau author 21–26, BE21 published 87–94; complete separately audited RWN25 arXiv v2 19 pages/10 views. External foundations remain attributed.',
    prior_label_layout_and_whitespace_preflights_preserved=True,
    user_evidence_upload_authorized=True, native_catalogue_and_editor_preserved=True,
    reading_credit_from_upload=0, whole_book_new_reading_claim=False,
    canonical_status_changes=[], original_results_promoted=[], independent_model_receipt=None,
    helper_source=__file__)
out.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
commit = x['commit']
members = export['artifacts']['actual_book_evidence_archive']['members']
p = R / 'README.md'
t = p.read_text()
marker = '**Latest checked norm-ray/interface book integration, 9 October 2026:**'
assert t.count(marker) == 1
intro = f'''**Latest verified norm-ray/interface GitHub publication, 9 October 2026:**
the 4,663-page book and six owned artifact files are uploaded on work at
{commit}. All sixteen source/progress/audit/artifact remote blobs match
local hashes and sizes. The [artifact directory]({artifact_directory}/README.md)
contains the full PDF, 25-page review, {members}-member actual evidence
and 472-member minimal source. All 25 pages were actually read in 13
matching V3 text/image views; V4 removes one blank source line and retains
that reading only under exact full-text and rendered-pixel equality.
The [publication record](manuscript/editorial/norm_ray_interfaces_GitHub_publication_v4_20261009.json)
also pins the separately verified nine-file selected source checkpoint:
38 source/page pairs in 19 actual displays, with frozen overlap correction.
General Siu/envelopes remain OPEN and canonical statuses and native editor
are unchanged. Upload supplies zero reading credit.

'''
p.write_text(t.replace(marker, intro + marker, 1))
p = E / 'second_reading_and_research_programme_20261002.md'
t = p.read_text()
marker = '## Latest norm-ray/interface book checkpoint, 9 October 2026\n'
assert t.count(marker) == 1
intro = f'''## Latest norm-ray/interface GitHub publication, 9 October 2026

The [publication record](norm_ray_interfaces_GitHub_publication_v4_20261009.json)
verifies {commit} on work: sixteen source/progress/audit/artifact remote
hashes and sizes match. The six [artifact files](artifact_exports/20261009_norm_ray_interfaces_v4/README.md)
contain the 4,663-page PDF, 25-page review, {members}-member actual evidence
and 472-member minimal sources. Twenty-five selected pages were completely
read in thirteen individually displayed matching V3 views. V4 removes
only one extra blank EOF source line; exact complete selected text and
full rendered pixel equality retain that reading without fresh credit.
Full validation and source/release/post-render gates pass. All 13,380
prior numbered values and 597 prior citation labels are preserved; two
source entries give 599 citations. All 955 inherited underfull blocks
have identical normalized content and multiplicities. Other 423 core
TeX inputs and the NA bibliography are unchanged. Fifty-one historical
formal blocks and 92 manual tags are preserved. Failed V1 label, V2
layout and V3 whitespace preflights and actual notes remain frozen.

The nine-file selected dependency source checkpoint at {s['commit']} is
separately verified: Finski published 1–24, Parreau author 21–26 and BE21
published 87–94, 38 source/page pairs in 19 actual views, all partial.
The named previous-record comparison adds 33 unique pairs; the old BE21
87–88 overlap correction is an addendum, not an overwritten receipt.
Separately audited RWN25 arXiv v2 is fully read, 19 pages/10 views; the
IMRN published edition remains unread. The tensor classification and
original Darvas/Okounkov inputs remain external to this selection.

Main remains 00957114db21b627e97369563032ceda9cea09c7; PR #2 stays a draft.
Native editor, 42 atoms/twelve formal problems and the last complete
ordered 4 October book pass retain their scopes. General BJ22 critical
homogeneous Siu/envelopes remain OPEN, LPWZ density UNVERIFIED and the
BJ22 Theorem 6.21 proof warning binding. No original general theorem or
independent-model receipt is claimed. Continue cloud-only with Finski's
remaining published pages 25–47 and the tensor classification proof,
incoming author research and related recent primary literature; push
checked units regularly. Xean stays suspended.

'''
p.write_text(t.replace(marker, intro + marker, 1))
files = ['README.md', str(p.relative_to(R)), str(out.relative_to(R))]
assert sorted(git('diff', '--name-only').splitlines()) == sorted(files[:2])
subprocess.run(['git', 'diff', '--check'], cwd=R, check=True)
subprocess.run(['git', 'add', '--', *files], cwd=R, check=True)
assert sorted(git('diff', '--cached', '--name-only').splitlines()) == sorted(files)
subprocess.run(['git', 'diff', '--cached', '--check'], cwd=R, check=True)
subprocess.run(['git', 'commit', '-m', 'Record verified norm-ray book and actual evidence publication'], cwd=R, check=True)
record.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — three-file publication documentation committed; remote verification pending',
    commit=git('rev-parse', 'HEAD'), book_and_evidence_commit=commit,
    files={f: sha(R / f) for f in files}, book_publication_record_SHA256=sha(remote),
    canonical_status_changes=[], reading_credit_from_publication=0, helper_source=__file__),
    ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(status='DONE', commit=git('rev-parse', 'HEAD'), record_SHA256=sha(record), publication_SHA256=sha(out))))
