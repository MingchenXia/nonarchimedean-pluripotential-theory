# V5 is editorial/artifact publication only; validated compiled V4 is reused unchanged. Frozen V4 export helper SHA256 10079af7cc7bb71ddcc2573653a8520be3d59acc062a35d63e68e9e6f88e0c85
# Fresh v5 follows source whitespace check. Frozen v3 helper SHA256: 73cb1c5c27311b932f3c2b119bf2464eb378549f7bf84b3be00ebbb14e561caa
# Fresh v5 follows actual layout review. Frozen preceding unexecuted helper SHA256: 42f3a64077c6ae47c9220a460c44f2a03fac06b9fc62a8f74a6fd0c27e317a43
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile,shutil,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Metric_radial_dependencies_review_20261009';S=Path('/workspace/book-completion-drafts/norm-ray-interfaces-publication-v5-20261009');E=R/'manuscript/editorial';O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda n:json.loads((C/n).read_text())
prep=load('staging_preparation_v4_20261009.json');release=load('staged_book_release_checks_v4_20261009.json');reading=load('actual_staged_book_reading_v4_20261009.json');post=load('post_render_checks_v4_20261009.json');math=load('staged_mathematical_self_audit_v4_20261009.json');under=load('staged_underfull_delta_v4_20261009.json')
assert reading['status'].startswith('DONE') and not reading['remaining_repairs'] and all(x['returncode']==0 for x in post['checks'])
assert not under['added_blocks'] and not under['removed_blocks'] and reading['reused_exact_complete_text_and_rendered_pixel_pages']==reading['actual_unique_book_pages']
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['after'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==release['PDF']['SHA256']
np=release['PDF']['physical_pages'];nb=reading['actual_unique_book_pages'];nv=reading['fresh_matching_views']+reading['reused_matching_views']
full=O/'Non-Archimedean_Pluripotential_Theory_Norm_Ray_Interfaces_Staged_Preview_V5_2026-10-09.pdf';review=O/'Norm_Ray_Interfaces_Staged_Book_Review_V5_2026-10-09.pdf';minimal=O/'Norm_Ray_Interfaces_Staged_Minimal_Source_V5_2026-10-09.zip';evidence=O/'Norm_Ray_Interfaces_Actual_Book_Evidence_V5_2026-10-09.zip'
record=C/'staged_export_v5_20261009.json';paths={k:E/f'norm_ray_interfaces_staged_integration_{k}_v5_20261009.{ext}' for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]};assert not any(p.exists() for p in [full,review,minimal,evidence,record,*paths.values()])
shutil.copyfile(release['PDF']['path'],full);assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as book:
    d=fitz.open()
    for n in release['selected_book_physical_pages']:d.insert_pdf(book,from_page=n-1,to_page=n-1)
    assert len(d)==nb;d.set_metadata(dict(title='Norm rays, maximal apartments and relative-volume interfaces — actual selected book review',subject=f'{nb} actually reviewed pages; export gives zero reading credit.'));d.save(review,garbage=4,deflate=True);d.close()
paths['audit'].write_text(f'''# Norm-ray and volume-interface book integration, 9 October 2026

The checked staged book has {np:,} pages. Chapter 65 adds a readable
construction of the complex sum envelope and adapted Hermitian ray,
their H<=A<=sqrt(N)H comparison, a C2 example showing they differ,
the factor-two squared metric convention and the complete double-sum
graded product argument. L.100 records version-specific Finski locators,
the RWN25 full finite spectral extension, maximal-apartment premises,
and signed total-volume versus probability normalization. The existing
L.99 rare-direction FS example supplies the finite-p/strong distinction.

This is explanatory mathematics and attributed source integration.
Finski published 1–24, Parreau author 21–26 and BE21 published 87–94 are
partial selections, 38 source/page pairs in 19 actual matching displays.
Their specifically pinned old-record comparison adds 33 unique pairs;
the correction for old BE21 pages 87–88 is preserved as an addendum.
The separately audited RWN25 arXiv v2 is complete: 19 pages/10 displays.
The published IMRN edition is not claimed read. Finski Section 4 and
original quantization/analytic foundations remain external inputs.

The final {nb} selected book pages retain complete V3 actual reading
in {nv} individual matching displays and chronological notes: changed
sections and seams, contents, full new bibliography entries and all
affected index pages. Preparation flags stay false. Retained actual V3 reading has an exact
complete text and full book-pixel equality receipt for V4.
The V4 publication audit whitespace preflight is preserved; V5 trims
only that document EOF in fresh audit and artifact versions.
V4 removes only an extra chapter EOF blank line. V5 trims only an
extra EOF blank line in this editorial audit; compiled V4 is unchanged. Exact complete selected text
and full rendered pixel equality to V3 retain its actual reading; zero
new V4/V5 fresh displays and no new reading credit are assigned.
The last complete ordered whole-book pass remains 4 October.

Full validation, the six existing tests and post-render reference and
canonical inventory checks pass. The final log has no TeX errors,
LaTeX/package/pdfTeX warnings, missing glyphs, overfull boxes, unresolved
references/citations or rerun requests. All 955 inherited underfull
blocks have identical normalized content and multiplicities.
All {release['all_prior_numbered_label_values_preserved']:,} old numbered
values and {release['bibliography']['prior_labels_preserved']} citation
labels are preserved. Two entries give {release['bibliography']['cited_entries']}
cited sources, with distinct shorthands Fin25SM and RWN25F.
Two section destinations/contents rows and four index terms are added.
All {release['index']['accepted']} index entries are accepted without
warnings or rejections. All {release['navigation']['internal_links']:,}
internal links are valid; external URL availability is not certified.

The two changed TeX roots preserve 51 historical formal blocks and 92
manual equation tags; no formal environment or manual tag is added.
Other 423 core TeX inputs and NonArchimedean.bib are byte unchanged.
ComplexGeometry.bib appends exactly two pinned entries. V1 compiles
but placing the new section before the source note shifts its implicit
old label 65.18 to 65.19. That failed preservation preflight is frozen.
Fresh v2 appends after the historical note and preserves all old values.
Actual v2 reading then finds two short standalone closing paragraphs.
Fresh v3 condenses repeated prose and consolidates the complete FS
distance hypotheses in L.100; all selected v3 pages were read anew.
V4 removes a single trailing blank source line and retains that reading
after exact selected complete-text and full rendered-pixel equality.
V1 has no actual rendered-reading or activation credit.

The native catalogue/editor, 42 atoms/twelve problems and their statuses
are preserved. General BJ22 critical homogeneous Siu/envelopes remain
OPEN, LPWZ density UNVERIFIED, and the BJ22 Theorem 6.21 proof warning
remains binding. No original general theorem or independent-model
receipt is claimed. Activation and Github publication get separate
later records; preparation/export/upload add zero reading credit.

The scoped mathematical checks are:

'''+''.join(f'{i}. {a}\n\n' for i,a in enumerate(math['checks'],1)))
paths['reading_notes'].write_text(f'# Actual norm-ray-interface book notes, 9 October 2026\n\n{nb} complete selected pages read in {nv} individual matching V3 displays; retained for V4 under exact text and full rendered pixel equality; V5 only fixes editorial EOF whitespace and adds no reading credit.\n'+''.join('\n---\n\n'+Path(x['sequential_note_path']).read_text() for x in reading['views']))
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md'
for rel in ['README.md',programme]:
    p=S/rel;s=p.read_text();assert 'norm_ray_interfaces_' in s
    p.write_text(s.replace('_v4_20261009','_v5_20261009'))
# Fresh V5 audit has exactly one terminal newline; all frozen V4 records remain unchanged.
p=paths['audit'];p.write_text(p.read_text().rstrip()+'\n')
with zipfile.ZipFile(prep['baseline_minimal_source']['path']) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    members=old.namelist();assert len(members)==len(set(members))==472
    for n in members:z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
    assert z.testzip() is None
    for n in z.namelist():assert z.read(n)==(S/n).read_bytes()
files={f'records/{q.name}':q for q in C.glob('*.json')}
for v in [1,2,3,4]:
    q=C/f'staged_book_validation_v{v}_20261009.log';files[f'logs/{q.name}']=q
for a in reading['views']:
    for key,folder in [('sequential_note_path','notes'),('observation_receipt_path','receipts'),('path','images'),('selected_text_path','text')]:
        q=Path(a[key]);files[f'compiled_v4/{folder}/{q.name}']=q
files['compiled_v4/prepared_manifest.json']=Path(release['manifest_path'])
for a in reading['views']:
    original=a['original_actually_reviewed_view']
    for key,folder in [('path','images'),('selected_text_path','text')]:
        q=Path(original[key]);files[f'actual_v3/{folder}/{q.name}']=q
files['actual_v3/prepared_manifest.json']=Path(load('staged_book_release_checks_v3_20261009.json')['manifest_path'])
# Preserve actual partial v2 review evidence without assigning it final-v5 credit.
v2release=load('staged_book_release_checks_v2_20261009.json')
v2rows=json.loads(Path(v2release['manifest_path']).read_text())
files['superseded_v2/prepared_manifest.json']=Path(v2release['manifest_path'])
for row in v2rows[:7]:
    n=C/'staged_book_notes_v2'/f"note_{row['number']:02d}.md";r=n.with_name(n.stem+'_receipt.json');receipt=json.loads(r.read_text());assert receipt['number']==row['number']
    files[f'superseded_v2/notes/{n.name}']=n;files[f'superseded_v2/receipts/{r.name}']=r
    for k,folder in [('path','images'),('selected_text_path','text')]:
        q=Path(row[k]);files[f'superseded_v2/{folder}/{q.name}']=q

for q in Path(prep['draft_path']).iterdir():files[f'drafts/v2/{q.name}']=q
for rel in prep['after']:files[f'staged_inputs/v5/{rel}']=S/rel
for q in sorted(Path('/tmp').glob('Norm_ray_interfaces_*_v*_20261009.py')):files[f'helpers/{q.name}']=q
for q in [paths['audit'],paths['reading_notes'],S/programme,S/'README.md']:files[f'editorial/{q.name}']=q
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
    assert len(z.namelist())==len(files) and z.testzip() is None
    for n,q in files.items():assert z.read(n)==q.read_bytes()
artifacts={k:dict(path=str(q),bytes=q.stat().st_size,SHA256=sha(q)) for k,q in [('full_book_PDF',full),('selected_review_PDF',review),('minimal_TeX_source_archive',minimal),('actual_book_evidence_archive',evidence)]};artifacts['selected_review_PDF']['physical_pages']=nb;artifacts['minimal_TeX_source_archive']['members']=472;artifacts['actual_book_evidence_archive']['members']=len(files)
progress={n:sha(S/n) for n in ['README.md',programme]};paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — staged mathematical/mechanical/actual-rendered gate',preparation=prep,release=release,actual_reading=reading,mathematical_audit=math,post_render=post,underfull_comparison=under,artifacts=artifacts,progress_document_hashes=progress,active_book_changed=False,GitHub_published=False,canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — byte-verified owned book exports',artifacts=artifacts,reading_credit_from_export=0,active_book_changed=False,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
record.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — selected staged book checkpoint and owned artifacts exported',artifacts=artifacts,editorial_files={str(q):sha(q) for q in paths.values()},progress_document_hashes=progress,actual_final_book_pages=nb,actual_final_matching_views=nv,actual_final_fresh_matching_views=0,actual_final_reused_matching_views=nv,active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',book_pages=np,selected_pages=nb,views=nv,evidence_members=len(files),record_SHA256=sha(record))))
