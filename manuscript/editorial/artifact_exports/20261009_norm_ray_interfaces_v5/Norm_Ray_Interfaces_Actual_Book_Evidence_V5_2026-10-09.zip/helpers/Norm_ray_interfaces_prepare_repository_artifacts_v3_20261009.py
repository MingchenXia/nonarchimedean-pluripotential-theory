from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,shutil
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Metric_radial_dependencies_review_20261009';A=R/'manuscript/editorial/artifact_exports/20261009_norm_ray_interfaces_v3';out=C/'repository_artifact_preparation_v3_20261009.json';assert not A.exists() and not out.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
export=json.loads((C/'staged_export_v3_20261009.json').read_text());active=json.loads((R/'manuscript/editorial/norm_ray_interfaces_cloud_activation_v3_20261009.json').read_text());assert sha(R/'manuscript/book.pdf')==active['active_PDF']['SHA256']==export['artifacts']['full_book_PDF']['SHA256'];A.mkdir()
for key,row in export['artifacts'].items():
    q=Path(row['path']);assert sha(q)==row['SHA256'];p=A/q.name;shutil.copyfile(q,p);assert sha(p)==row['SHA256']
rows={q.name:dict(bytes=q.stat().st_size,SHA256=sha(q)) for q in A.iterdir()};(A/'SHA256SUMS').write_text(''.join(a['SHA256']+'  '+n+'\n' for n,a in sorted(rows.items())))
np=active['active_PDF']['physical_pages'];nb=active['actual_selected_book_pages'];nv=active['fresh_book_matching_views']
(A/'README.md').write_text(f'''# Checked norm-ray and volume-interface edition, 9 October 2026

Full {np:,}-page book PDF, {nb}-page selected review PDF, 472-member
minimal build source and {export['artifacts']['actual_book_evidence_archive']['members']}-member
actual evidence archive. SHA256SUMS pins all four owned artifacts.
All {nb} final selected pages were freshly read with {nv} individual
matching image displays and chronological notes; no reused page credit.
Preparation/export/upload give zero reading credit.

Chapter 65 constructs the complex sum envelope and quadratic Hermitian
ray, proves the sqrt(rank) comparison, works out a C2 non-Hermitian
example, retains the factor-two metric convention and sums the full
graded product decomposition. L.100 consolidates published Finski
Lemma 2.6/Corollary 3.5, finite spectral extension, maximal apartment
and signed-volume/probability premises. Original general classifications
and analytic foundations remain attributed, not recursively certified.

All old numbered values and 597 citation labels are preserved; two
pinned entries give 599 citations. All 955 inherited underfull blocks
have identical normalized content and multiplicities. Validation, six
existing tests, references, inventory, navigation and rendered checks
pass. Other 423 TeX inputs and the NA bibliography are unchanged.
Historical 51 formal blocks and 92 manual tags are preserved. V1's
source-note label shift and actual v2 short closing pages are recorded;
fresh v3 retains the label and condenses duplicated prose.

Selected Finski 1–24, Parreau 21–26 and BE21 87–94 are partial readings,
38 source/page pairs in 19 displays; the named earlier-record comparison
adds 33 unique pairs, with the overlap correction frozen. Separately
audited RWN25 arXiv v2 is fully read, 19 pages/10 displays; its published
IMRN edition is not claimed read. External primary PDFs stay in the cloud.
Native editor, 42 atoms/twelve problems and last complete 4 October
ordered book pass retain their scopes. BJ22 critical Siu/general envelopes
remain OPEN, LPWZ density UNVERIFIED and the Theorem 6.21 warning binding.
No original general theorem or independent-model receipt is claimed.
Remote publication receives a separate verified record.
''')
files={str(q.relative_to(R)):dict(bytes=q.stat().st_size,SHA256=sha(q)) for q in A.iterdir()};assert len(files)==6;obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — six repository artifact files byte verified',files=files,active_PDF_SHA256=active['active_PDF']['SHA256'],actual_selected_book_pages=nb,actual_fresh_matching_views=nv,reading_credit_from_export=0,GitHub_published=False,canonical_status_changes=[],helper_source=__file__);out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='DONE',files=6,record_SHA256=sha(out))))
