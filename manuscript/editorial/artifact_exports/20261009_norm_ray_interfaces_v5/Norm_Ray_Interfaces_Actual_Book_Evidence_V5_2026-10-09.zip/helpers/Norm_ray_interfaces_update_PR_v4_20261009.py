from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R / 'source_material/Metric_radial_dependencies_review_20261009'
repo = 'MingchenXia/nonarchimedean-pluripotential-theory'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
api = lambda ep: json.loads(subprocess.check_output(['gh', 'api', ep], cwd=R, text=True))
doc = json.loads((C / 'publication_documentation_v4_20261009.json').read_text())
book = json.loads((C / 'GitHub_book_publication_v4_20261009.json').read_text())
export = json.loads((C / 'staged_export_v4_20261009.json').read_text())
assert api(f'repos/{repo}/git/ref/heads/work')['object']['sha'] == doc['commit']
assert api(f'repos/{repo}/git/ref/heads/main')['object']['sha'] == '00957114db21b627e97369563032ceda9cea09c7'
pr = api(f'repos/{repo}/pulls/2')
assert pr['draft'] and pr['state'] == 'open' and pr['head']['sha'] == doc['commit']
previous = Path('/tmp/book_continuation_PR2_body_graded_FS_v1_20261009.md')
assert sha(previous) == '418f52649ad4adf512ca51b05fcddda11353ffd71bfedbae06c873a9fb2f5300'
assert pr['body'] == previous.read_text()
snapshot = C / 'PR2_before_norm_ray_update_v4_20261009.json'
record = C / 'PR2_norm_ray_update_v4_20261009.json'
body_path = Path('/tmp/book_continuation_PR2_body_norm_ray_v4_20261009.md')
patch_path = Path('/tmp/book_continuation_PR2_patch_norm_ray_v4_20261009.json')
assert not any(p.exists() for p in [snapshot, record, body_path, patch_path])
snapshot.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    number=2, url=pr['html_url'], title=pr['title'], body=pr['body'],
    head=pr['head']['sha'], draft=pr['draft'], state=pr['state']), ensure_ascii=False, indent=2) + '\n')
members = export['artifacts']['actual_book_evidence_archive']['members']
commit = book['commit']
root = f'https://github.com/{repo}'
editorial = root + '/blob/work/manuscript/editorial/'
artifacts = root + '/tree/' + commit + '/manuscript/editorial/artifact_exports/20261009_norm_ray_interfaces_v4'
title = 'Complete book second reading and checked research integrations through 4,663 pages'
body = f'''The book now has a checked 4,663-page edition, with the completed 4 October ordered second reading covering all 72 chapters, Appendices A–N and nine front-matter files. Later additions have scoped primary-source and rendered-book reviews. Reader routes, conventions, dependencies and source boundaries are aligned; the later scoped reviews do not claim another whole-book pass.

Boucksom–Jonsson (2022), Theorem 6.21, retains its recorded proof gap: decreasing approximants with changing divisor coefficients do not imply decreasing residuals. The general critical homogeneous Siu-division and envelope input remains OPEN. No proof repair or counterexample to the theorem itself is claimed. The canonical 42 atoms in twelve formal problems and the 86-page standalone catalogue retain their statuses; LPWZ density remains UNVERIFIED.

### Changes

- Chapter 65 now distinguishes the complex sum-envelope ray from the quadratic Hermitian ray. It proves H <= A <= sqrt(rank) H, gives a complete C2 example where A is not Hermitian, calibrates ordinary norm lengths against squared metric potentials, and includes the full double-sum graded product argument. Hermitian-ray multiplicativity is a separate obligation.
- New L.100 identifies the controlling published Finski locators and their ample, bounded, submultiplicative and FS-regularity hypotheses. It explains why functions must be extended to finite spectral values outside limiting DH support, why maximal-apartment premises must be established for a chosen atlas, and why signed relative volume differs from probability normalization. Trivial classical-disc and nonpure-component proof issues receive explicit local qualifications without declaring the intended asymptotic volume theorems false.
- Chapters 17 and 19 and L.96–L.99 retain the distinctions between local and global psh growth, model-Chow and analytic currents, supnorm base change, signed and absolute spectral limits, and raw FS limits versus upper semicontinuous regularization. The bounded P1 example has asymptotic d1 distance zero, positive operator distance, and a raw FS limit with a downward jump; Q and Q* differ in this example.
- Earlier checked integrations retain explicit field, positivity, normalization and proof-interface hypotheses: Lorentzian/Hodge and Nakano comparisons; entropy and section-ball asymptotics; harmonic quiver norms; transcendental approximation; adiabatic stability; higher-rank integral data; relative Hessian energies; polarized Calabi–Yau uniformity; and hybrid degeneration. Their source audits preserve the exact ranges of attributed and conditional results.
- Preserve original theorem/status boundaries, supplied research scopes and historical receipts. No original general theorem or independent-model verification receipt is introduced. External foundations remain attributed in their stated scopes.

### Validation and evidence

Required full-book validation, six existing reference-checker regression tests, canonical inventory and post-render checks pass. The final build has no TeX errors, LaTeX/package/pdfTeX warnings, missing glyphs, overfull boxes, unresolved references/citations, rerun requests or invalid internal links. All 955 inherited underfull diagnostic blocks have identical normalized text and multiplicities. External URL availability is not certified; the unavailable legacy writing audit is not represented as an automated pass.

For the latest norm-ray increment, all 13,380 prior numbered values and 597 citation labels are preserved. Two pinned bibliography entries, Fin25SM and RWN25F, give 599 citations. Two semantic labels/contents rows and four index terms are added. The two changed TeX roots preserve 51 historical formal blocks and 92 manual equation tags; no formal environment or manual tag is added. Other 423 core TeX inputs and NonArchimedean.bib remain byte unchanged. ComplexGeometry.bib appends exactly two entries.

All 25 selected final book pages were completely read in thirteen individually displayed matching V3 text/image views with chronological notes and receipts, covering changed sections and seams, contents, all affected index pages and both full new bibliography entries. V4 removes one extra EOF blank source line and retains that actual reading only after exact complete-text and entire rendered-page pixel equality on all 25 pages; it adds zero fresh reading credit. The failed V1 label-preservation check, partial V2 layout review and V3 whitespace check remain frozen with their diagnostics and actual notes. The mathematical content and source qualifications survive the final prose/layout corrections.

The source basis is edition-specific. Finski's published 47-page author copy was read on physical pages 1–24, Parreau's 41-page author copy on 21–26 and published BE21's 125-page copy on 87–94: 38 source/page pairs in 19 actual matching displays, all partial. Their named previous-record comparison adds 33 unique pairs; the BE21 87–88 overlap correction is preserved as an addendum. This is not a claim about the union of every historical BE21 checkpoint. RWN25 arXiv:2311.13451v2 was separately read in full, 19 pages/10 views; its IMRN published edition is not claimed read. The separately completed Reboulet filtration v2, Chen–Maclean spectral v3 and Reboulet asymptotic-FS v1 source reviews retain their own scope and proof-interface qualifications. Finski's Section 4 classification and original Darvas/Okounkov foundations remain outside the latest selection.

The [verified artifact directory]({artifacts}) contains the complete 4,663-page PDF, 25-page review, {members}-member actual book evidence archive and 472-member minimal source checkpoint. All sixteen source/progress/audit/artifact remote blobs match local hashes and sizes; SHA256SUMS pins the four binaries. The separately published nine-file selected dependency checkpoint at 8987e5cefb9cc75145bb78dba6db1c46500a96cf retains its source audit, actual notes and exact diagnostics. External primary PDFs stay in the cloud. Preparation, export and upload supply zero reading credit.

This remains a draft PR on work, with main unchanged. The native catalogue/editor is unchanged. Continue with the remaining published Finski pages and original tensor classification, author updates and related recent primary literature.

- [Current publication record]({editorial}norm_ray_interfaces_GitHub_publication_v4_20261009.json)
- [Norm-ray and source-interface integration audit]({editorial}norm_ray_interfaces_staged_integration_audit_v4_20261009.md)
- [Selected metric/radial dependency source audit]({editorial}Metric_radial_dependencies_source_review_20261009.md)
- [Complete RWN25 arXiv v2 audit]({editorial}RWN25_flats_source_review_20261009.md)
- [Previous graded normalization and raw/usc FS integration audit]({editorial}graded_FS_staged_integration_audit_v1_20261009.md)
- [Whole-book second-reading audit]({editorial}book_second_reading_completion_audit_20261004.md)
- [Siu proof-boundary audit]({editorial}bj22_siu_proof_boundary_audit_20261004.md)
'''
body_path.write_text(body)
patch_path.write_text(json.dumps(dict(title=title, body=body), ensure_ascii=False, indent=2) + '\n')
updated = json.loads(subprocess.check_output(['gh', 'api', '-X', 'PATCH', f'repos/{repo}/pulls/2', '--input', str(patch_path)], cwd=R, text=True))
assert updated['body'] == body and updated['title'] == title and updated['draft'] and updated['head']['sha'] == doc['commit']
record.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(), status='DONE — final draft PR description updated and response verified',
    number=2, url=updated['html_url'], head=updated['head']['sha'], title=title,
    previous_snapshot_SHA256=sha(snapshot), body_path=str(body_path), body_SHA256=sha(body_path),
    body_characters=len(body), reading_credit_from_publication=0, canonical_status_changes=[], helper_source=__file__), ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(status='DONE', record_SHA256=sha(record), body_characters=len(body), PR=updated['html_url'])))
