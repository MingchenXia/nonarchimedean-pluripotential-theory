# Fresh v3 condenses repeated prose to repair actual v2 short closing pages. Frozen v2 helper SHA256: ea8ac6d9140b3c65a1b9fc76709034d3a98f63a538a28568273c001bfa6f1783
# Fresh v2 places the added section after the historical source note to preserve its implicit current label. Frozen v1 helper SHA256: 0baad1030098885fcbb37803f210149d9f0c49490e0f4923470636a1f41f55bf
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,shutil,subprocess,zipfile
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Metric_radial_dependencies_review_20261009'
B=Path('/workspace/book-completion-drafts/graded-FS-staging-v1-20261009');S=Path('/workspace/book-completion-drafts/norm-ray-interfaces-staging-v3-20261009');D=Path('/workspace/book-completion-drafts/norm-ray-interfaces-integration-v2-20261009')
out=C/'staging_preparation_v3_20261009.json';assert not S.exists() and not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
publication=C/'GitHub_source_publication_v1_20261009.json';pub=json.loads(publication.read_text());assert head==pub['commit']=='8987e5cefb9cc75145bb78dba6db1c46500a96cf'
assert pub['actual_primary_pages']==38 and pub['actual_matching_images']==19 and not pub['whole_pinned_primary_read']
protected=json.loads((C/'primary_view_preparation_v1_20261009.json').read_text())['protected_core_inputs'];progress=['README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']
for n,h in protected.items():
    if n not in progress:assert sha(R/n)==h
for row in pub['files']:assert sha(R/row['path'])==row['SHA256']
assert sha(R/'manuscript/book.pdf')==sha(B/'manuscript/book.pdf')=='945ee38ff0dd414fb798422258fd7113256f9f1894830ae5a0f0a83d5e77ea3d'
oldexport=json.loads((R/'source_material/Reboulet_asymptotic_FS_review_20261009/staged_export_v1_20261009.json').read_text());m=oldexport['artifacts']['minimal_TeX_source_archive'];minimal=Path(m['path']);assert sha(minimal)==m['SHA256']
with zipfile.ZipFile(minimal) as z:
    members=z.namelist();assert len(members)==len(set(members))==472
    for n in members:
        assert not Path(n).is_absolute() and '..' not in Path(n).parts and (R/n).is_file()
        if n not in progress:assert z.read(n)==(R/n).read_bytes(),n
    S.mkdir();z.extractall(S)
for n in progress:shutil.copyfile(R/n,S/n)
changed=['manuscript/parts/part6/ch65_rays_filtrations.tex','manuscript/appendices/appL_provenance.tex','manuscript/bibliography/ComplexGeometry.bib'];before={n:sha(R/n) for n in changed}
alltex={n:h for n,h in protected.items() if n.startswith('manuscript/') and n.endswith('.tex')};assert len(alltex)==425
labels=set()
for n in alltex:labels.update(re.findall(r'\\label\{([^}]+)\}',(R/n).read_text()))
newlabels=['sec:rf-norm-envelope-rays','sec:appL-norm-ray-volume-interfaces'];assert not labels.intersection(newlabels)
assert all(line==line.rstrip() for p in D.iterdir() for line in p.read_text().splitlines())
q=S/changed[0];s=q.read_text();assert s.rstrip().endswith('\\end{minipage}\\par');q.write_text(s+'\n'+(D/'ch65_norm_ray_fragment.tex').read_text())
q=S/changed[1];q.write_text(q.read_text()+(D/'appL_norm_ray_fragment.tex').read_text().rstrip()+'\n')
q=S/changed[2];entry=D/'ComplexGeometry_norm_ray_entries.bib';keys=['Finski25SubmultiplicativePublished','RWN25FlatsArxivV2'];assert not any(k in q.read_text() for k in keys);q.write_bytes(q.read_bytes()+entry.read_bytes())
unchanged={n:h for n,h in alltex.items() if n not in changed};assert len(unchanged)==423
for n,h in unchanged.items():assert sha(R/n)==sha(S/n)==h
historical=[]
for n in changed[:2]:
    old=(R/n).read_text();new=(S/n).read_text();counts={}
    for e in ['theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important']:
        pat=r'\\begin\{'+e+r'\}.*?\\end\{'+e+r'\}';blocks=re.findall(pat,old,re.S);assert all(b in new for b in blocks);assert len(blocks)==len(re.findall(pat,new,re.S));counts[e]=len(blocks)
    tags=re.findall(r'\\tag\{([^}]+)\}',old);assert tags==re.findall(r'\\tag\{([^}]+)\}',new)
    historical.append(dict(path=n,environment_counts=counts,historical_manual_tags=tags))
for row in pub['files']:
    if row['path'].startswith('manuscript/editorial/') and '/artifact_exports/' not in row['path']:
        target=S/row['path'];target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(R/row['path'],target)
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — norm-ray and source-interface explanation prepared in isolated stage',stage_path=str(S),baseline_stage_path=str(B),baseline_commit=head,baseline_minimal_source=m,draft_path=str(D),before=before,after={n:sha(S/n) for n in changed},draft_fragments={str(p):sha(p) for p in D.iterdir()},active_inputs_preserved=before,other_active_TeX_preserved=unchanged,other_active_TeX_count=423,unchanged_bibliographies={'manuscript/bibliography/NonArchimedean.bib':sha(R/'manuscript/bibliography/NonArchimedean.bib')},historical_formal_blocks_preserved=historical,active_book_PDF_SHA256=sha(R/'manuscript/book.pdf'),native_catalogue_preserved={n:h for n,h in protected.items() if n.startswith('output/')},source_checkpoint_SHA256=sha(C/'source_checkpoint_v1_20261009.json'),actual_primary_reading_SHA256=sha(C/'actual_primary_reading_v1_20261009.json'),exact_diagnostics_SHA256=sha(C/'exact_diagnostics_v1_20261009.json'),source_publication_SHA256=sha(publication),new_bibliographic_keys=keys,new_semantic_labels=newlabels,new_formal_environments=0,original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],active_book_changed=False,GitHub_published=False,actual_book_reading_credit=0,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='DONE',record_SHA256=sha(out),other_TeX=423,historical_blocks=sum(sum(x['environment_counts'].values()) for x in historical),historical_tags=sum(len(x['historical_manual_tags']) for x in historical))))
