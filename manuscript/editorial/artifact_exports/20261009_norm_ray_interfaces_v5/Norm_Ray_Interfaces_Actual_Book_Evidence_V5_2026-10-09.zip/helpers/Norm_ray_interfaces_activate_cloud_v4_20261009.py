# Fresh v4 follows source whitespace check. Frozen v3 helper SHA256: 066eecb5e8fb07c9517c8287f769a2ce3bcf5ed82676e4ff37aaac6c130d545e
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,zipfile,subprocess
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Metric_radial_dependencies_review_20261009';S=Path('/workspace/book-completion-drafts/norm-ray-interfaces-staging-v4-20261009')
J=R/'manuscript/editorial/norm_ray_interfaces_cloud_activation_v4_20261009.json';assert not J.exists();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda n:json.loads((C/n).read_text())
names=['staging_preparation_v4_20261009.json','staged_export_v4_20261009.json','actual_staged_book_reading_v4_20261009.json','staged_book_release_checks_v4_20261009.json','post_render_checks_v4_20261009.json','staged_mathematical_self_audit_v4_20261009.json','staged_book_validation_v4_20261009.json','staged_underfull_delta_v4_20261009.json','exact_diagnostics_v1_20261009.json','actual_primary_reading_v1_20261009.json','staged_layout_label_preflight_v1_20261009.json','staged_layout_readability_preflight_v2_20261009.json','staged_post_render_whitespace_failure_v3_20261009.json','staged_exact_render_reuse_v4_20261009.json','actual_staged_book_reading_v3_20261009.json'];pins={n:sha(C/n) for n in names};prep,export,reading,release,post,math=[load(n) for n in names[:6]]
assert reading['status'].startswith('DONE') and not reading['remaining_repairs'] and reading['reused_exact_complete_text_and_rendered_pixel_pages']==reading['actual_unique_book_pages']
nb=reading['actual_unique_book_pages'];nv=reading['fresh_matching_views']+reading['reused_matching_views'];assert nb==reading['fresh_complete_text_and_individually_displayed_pages']+reading['reused_exact_complete_text_and_rendered_pixel_pages']==len(release['selected_book_physical_pages']) and nv==len(reading['views'])
assert release['PDF']['SHA256']==reading['PDF']['SHA256']==export['artifacts']['full_book_PDF']['SHA256'];assert math['actual_final_book_reading_SHA256']==pins[names[2]]
assert all(x['returncode']==0 for x in post['checks']) and not load(names[7])['added_blocks'] and not load(names[7])['removed_blocks']
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
for n,h in prep['other_active_TeX_preserved'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['unchanged_bibliographies'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
for n,h in export['editorial_files'].items():assert sha(n)==h
changes=dict(prep['after'],**export['progress_document_hashes']);assert len(changes)==5
for n,h in changes.items():
    assert sha(S/n)==h
    q=subprocess.run(['git','diff','--no-index','--check',str(R/n),str(S/n)],text=True,capture_output=True);assert q.returncode in [0,1] and not(q.stdout+q.stderr).strip()
pdf=Path(reading['PDF']['path']);assert sha(pdf)==reading['PDF']['SHA256'];archive=Path(export['artifacts']['minimal_TeX_source_archive']['path']);assert sha(archive)==export['artifacts']['minimal_TeX_source_archive']['SHA256']
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==472
    for n in z.namelist():
        assert (S/n).read_bytes()==z.read(n)
        if n not in changes:assert (R/n).read_bytes()==z.read(n)
repo='MingchenXia/nonarchimedean-pluripotential-theory';api=lambda ep:json.loads(subprocess.check_output(['gh','api',ep],cwd=R,text=True));head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
w=api(f'repos/{repo}/git/ref/heads/work')['object']['sha'];m=api(f'repos/{repo}/git/ref/heads/main')['object']['sha'];p=api(f'repos/{repo}/pulls/2')
assert head==w==prep['baseline_commit']=='8987e5cefb9cc75145bb78dba6db1c46500a96cf' and m=='00957114db21b627e97369563032ceda9cea09c7'
assert p['state']=='open' and p['draft'] and p['head']['sha']==head
before={n:sha(R/n) for n in changes}
for n,h in changes.items():
    target=R/n;tmp=target.with_name(target.name+'.norm-ray-activation-tmp');assert not tmp.exists();shutil.copyfile(S/n,tmp);assert sha(tmp)==h;os.replace(tmp,target)
target=R/'manuscript/book.pdf';tmp=target.with_name(target.name+'.norm-ray-activation-tmp');assert not tmp.exists();shutil.copyfile(pdf,tmp);assert sha(tmp)==reading['PDF']['SHA256'];os.replace(tmp,target)
with zipfile.ZipFile(archive) as z:
    for n in z.namelist():assert (R/n).read_bytes()==z.read(n)
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h
for n,h in pins.items():assert sha(C/n)==h
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — validated source and PDF activated in cloud workspace',before_source_hashes=before,after_source_hashes={n:sha(R/n) for n in changes},before_book_PDF_SHA256=prep['active_book_PDF_SHA256'],active_PDF=dict(path=str(target),bytes=target.stat().st_size,SHA256=sha(target),physical_pages=release['PDF']['physical_pages']),validation_record_hashes=pins,minimal_source_archive_members_byte_verified_against_active_tree=472,actual_selected_book_pages=nb,fresh_book_matching_views=0,reused_book_matching_views=nv,fresh_complete_text_and_individually_displayed_book_pages=0,exact_reused_actual_book_pages=nb,original_fresh_V3_book_matching_views=13,original_fresh_V3_book_pages=25,source_scope=math['source_scope'],author_update_check=dict(work=w,main=m,PR2_open_draft=True),validation=release['build_checks'],underfull_diagnostics='All 955 inherited; normalized content and multiplicities identical',preserved_numbered_labels=release['all_prior_numbered_label_values_preserved'],preserved_citation_labels=release['bibliography']['prior_labels_preserved'],new_labels=release['new_semantic_labels'],new_bibliography_labels=release['bibliography']['new_labels'],other_TeX_inputs_preserved=423,historical_environment_blocks_including_proofs=51,historical_manual_tags=92,prior_v1_label_and_v2_layout_preflights_preserved=True,open_problem_inventory='42 atoms, 12 formal problems, no status changes',critical_homogeneous_Siu_and_general_envelopes='OPEN',LPWZ_density='UNVERIFIED',native_catalogue_preserved=prep['native_catalogue_preserved'],native_editor_changed=False,whole_book_new_reading_claim=False,original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],active_book_changed=True,GitHub_published=False,helper_source=__file__)
J.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='DONE',record_SHA256=sha(J),active_PDF_SHA256=sha(target),pages=release['PDF']['physical_pages'])))
