# Fresh v3 follows actual layout review. Frozen preceding unexecuted helper SHA256: 42f3a64077c6ae47c9220a460c44f2a03fac06b9fc62a8f74a6fd0c27e317a43
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile,shutil,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Metric_radial_dependencies_review_20261009';S=Path('/workspace/book-completion-drafts/norm-ray-interfaces-staging-v3-20261009');E=R/'manuscript/editorial';O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda n:json.loads((C/n).read_text())
prep=load('staging_preparation_v3_20261009.json');release=load('staged_book_release_checks_v3_20261009.json');reading=load('actual_staged_book_reading_v3_20261009.json');post=load('post_render_checks_v3_20261009.json');math=load('staged_mathematical_self_audit_v3_20261009.json');under=load('staged_underfull_delta_v3_20261009.json')
assert reading['status'].startswith('DONE') and not reading['remaining_repairs'] and all(x['returncode']==0 for x in post['checks'])
assert not under['added_blocks'] and not under['removed_blocks'] and not reading['reused_exact_complete_text_and_rendered_pixel_pages']
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
np=release['PDF']['physical_pages'];nb=reading['actual_unique_book_pages'];nv=reading['fresh_matching_views']
full=O/'Non-Archimedean_Pluripotential_Theory_Norm_Ray_Interfaces_Staged_Preview_V3_2026-10-09.pdf';review=O/'Norm_Ray_Interfaces_Staged_Book_Review_V3_2026-10-09.pdf';minimal=O/'Norm_Ray_Interfaces_Staged_Minimal_Source_V3_2026-10-09.zip';evidence=O/'Norm_Ray_Interfaces_Actual_Book_Evidence_V3_2026-10-09.zip'
record=C/'staged_export_v3_20261009.json';paths={k:E/f'norm_ray_interfaces_staged_integration_{k}_v3_20261009.{ext}' for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]};assert not any(p.exists() for p in [full,review,minimal,evidence,record,*paths.values()])
shutil.copyfile(release['PDF']['path'],full);assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as book:
    d=fitz.open()
    for n in release['selected_book_physical_pages']:d.insert_pdf(book,from_page=n-1,to_page=n-1)
    assert len(d)==nb;d.set_metadata(dict(title='Norm rays, maximal apartments and relative-volume interfaces — actual selected book review',subject=f'{nb} actually reviewed pages; export gives zero reading credit.'));d.save(review,garbage=4,deflate=True);d.close()
paths['audit'].write_text(f'''# Norm-ray and volume-interface book integration, 9 October 2026

The checked staged book has {np:,} pages. Chapter 65 adds a readable
construction of the complex sum envelope and adapted Hermitian ray,
their H<=A<=sqrt(N)H comparison, a C2 example showing they differ,
the factor-two squared metric convention and the complete double-sum
graded product argument. L.100 records version-specific Finski locators,
the RWN25 full finite spectral extension, maximal-apartment premises,
and signed total-volume versus probability normalization. The existing
L.99 rare-direction FS example supplies the finite-p/strong distinction.

This is explanatory mathematics and attributed source integration.
Finski published 1–24, Parreau author 21–26 and BE21 published 87–94 are
partial selections, 38 source/page pairs in 19 actual matching displays.
Their specifically pinned old-record comparison adds 33 unique pairs;
the correction for old BE21 pages 87–88 is preserved as an addendum.
The separately audited RWN25 arXiv v2 is complete: 19 pages/10 displays.
The published IMRN edition is not claimed read. Finski Section 4 and
original quantization/analytic foundations remain external inputs.

The final {nb} selected book pages were freshly read with complete text
in {nv} individual matching displays and chronological notes: changed
sections and seams, contents, full new bibliography entries and all
affected index pages. Preparation flags stay false, with no reuse credit.
The last complete ordered whole-book pass remains 4 October.

Full validation, the six existing tests and post-render reference and
canonical inventory checks pass. The final log has no TeX errors,
LaTeX/package/pdfTeX warnings, missing glyphs, overfull boxes, unresolved
references/citations or rerun requests. All 955 inherited underfull
blocks have identical normalized content and multiplicities.
All {release['all_prior_numbered_label_values_preserved']:,} old numbered
values and {release['bibliography']['prior_labels_preserved']} citation
labels are preserved. Two entries give {release['bibliography']['cited_entries']}
cited sources, with distinct shorthands Fin25SM and RWN25F.
Two section destinations/contents rows and four index terms are added.
All {release['index']['accepted']} index entries are accepted without
warnings or rejections. All {release['navigation']['internal_links']:,}
internal links are valid; external URL availability is not certified.

The two changed TeX roots preserve 51 historical formal blocks and 92
manual equation tags; no formal environment or manual tag is added.
Other 423 core TeX inputs and NonArchimedean.bib are byte unchanged.
ComplexGeometry.bib appends exactly two pinned entries. V1 compiles
but placing the new section before the source note shifts its implicit
old label 65.18 to 65.19. That failed preservation preflight is frozen.
Fresh v2 appends after the historical note and preserves all old values.
Actual v2 reading then finds two short standalone closing paragraphs.
Fresh v3 condenses repeated prose and consolidates the complete FS
distance hypotheses in L.100; all final selected v3 pages are read anew.
V1 has no actual rendered-reading or activation credit.

The native catalogue/editor, 42 atoms/twelve problems and their statuses
are preserved. General BJ22 critical homogeneous Siu/envelopes remain
OPEN, LPWZ density UNVERIFIED, and the BJ22 Theorem 6.21 proof warning
remains binding. No original general theorem or independent-model
receipt is claimed. Activation and Github publication get separate
later records; preparation/export/upload add zero reading credit.

The scoped mathematical checks are:

'''+''.join(f'{i}. {a}\n\n' for i,a in enumerate(math['checks'],1)))
paths['reading_notes'].write_text(f'# Actual norm-ray-interface book notes, 9 October 2026\n\n{nb} complete selected pages in {nv} individual matching displays; no reuse.\n'+''.join('\n---\n\n'+Path(x['sequential_note_path']).read_text() for x in reading['views']))
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md';marker='## Latest selected norm/ray/volume dependencies, 9 October 2026\n';s=(R/programme).read_text();assert s.count(marker)==1
intro=f'''## Latest norm-ray/interface book checkpoint, 9 October 2026

The [integration audit](norm_ray_interfaces_staged_integration_audit_v3_20261009.md)
adds Chapter 65's two norm rays and L.100's source interfaces. The worked
C2 envelope differs from its Hermitian ray; the logarithmic-rank bound,
factor-two convention and summed graded product argument are explicit.
Finite spectral extension, maximal apartment and signed-volume mass
premises retain their source scopes. No general flat theorem is promoted.

The {np:,}-page stage passes validation and rendered checks. All {nb}
selected pages were freshly read in {nv} individual matching displays.
All prior numbered values and 597 citation labels are preserved; two
pinned entries give 599 citations. The 423 other core TeX and NA bibliography
are unchanged. V1's historical source-note label shift is frozen; fresh
v2 preserves the label by moving the new section after that note.
Fresh v3 additionally repairs two short closing pages found by actual
v2 reading, preserving all mathematical hypotheses and source scopes.

The [activation record](norm_ray_interfaces_cloud_activation_v3_20261009.json)
controls this cloud edition; remote publication is recorded separately.
Native editor and canonical 42 atoms/twelve problems retain their status.
General BJ22 critical Siu/envelopes remain OPEN, LPWZ density UNVERIFIED.
No original general result, independent-model receipt or new full ordered
book reading is claimed; the last full pass remains 4 October. Continue
cloud-only with the original tensor/quantization inputs and related
research, incoming author updates and regular verified pushes. Xean
stays suspended.

''';(S/programme).write_text(s.replace(marker,intro+marker,1))
s=(R/'README.md').read_text();assert s.count('**4,661 pages**')==1;s=s.replace('**4,661 pages**',f'**{np:,} pages**');marker='**Latest norm/ray/volume dependency checkpoint, 9 October 2026:**';assert s.count(marker)==1
intro=f'''**Latest checked norm-ray/interface book integration, 9 October 2026:**
the [integration audit](manuscript/editorial/norm_ray_interfaces_staged_integration_audit_v3_20261009.md)
adds Chapter 65's two norm rays and L.100's finite spectral, apartment
and volume interfaces. A complete C2 calculation distinguishes the
envelope from a Hermitian norm, with a logarithmic-rank comparison.
All {nb} affected pages were freshly read in {nv} matching displays;
validation and post-render checks pass, retaining all old numbered
values and citation labels. The
[activation record](manuscript/editorial/norm_ray_interfaces_cloud_activation_v3_20261009.json)
controls the {np:,}-page cloud edition. Two pinned sources are added.
Native editor and canonical statuses stay unchanged; general Siu and
envelope problems remain OPEN. No new whole-book pass is claimed.

''';(S/'README.md').write_text(s.replace(marker,intro+marker,1))
with zipfile.ZipFile(prep['baseline_minimal_source']['path']) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    members=old.namelist();assert len(members)==len(set(members))==472
    for n in members:z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
    assert z.testzip() is None
    for n in z.namelist():assert z.read(n)==(S/n).read_bytes()
files={f'records/{q.name}':q for q in C.glob('*.json')}
for v in [1,2,3]:
    q=C/f'staged_book_validation_v{v}_20261009.log';files[f'logs/{q.name}']=q
for a in reading['views']:
    for key,folder in [('sequential_note_path','notes'),('observation_receipt_path','receipts'),('path','images'),('selected_text_path','text')]:
        q=Path(a[key]);files[f'final_v3/{folder}/{q.name}']=q
files['final_v3/prepared_manifest.json']=Path(release['manifest_path'])
# Preserve actual partial v2 review evidence without assigning it final-v3 credit.
v2release=load('staged_book_release_checks_v2_20261009.json')
v2rows=json.loads(Path(v2release['manifest_path']).read_text())
files['superseded_v2/prepared_manifest.json']=Path(v2release['manifest_path'])
for row in v2rows[:7]:
    n=C/'staged_book_notes_v2'/f"note_{row['number']:02d}.md";r=n.with_name(n.stem+'_receipt.json');receipt=json.loads(r.read_text());assert receipt['number']==row['number']
    files[f'superseded_v2/notes/{n.name}']=n;files[f'superseded_v2/receipts/{r.name}']=r
    for k,folder in [('path','images'),('selected_text_path','text')]:
        q=Path(row[k]);files[f'superseded_v2/{folder}/{q.name}']=q

for q in Path(prep['draft_path']).iterdir():files[f'drafts/v2/{q.name}']=q
for rel in prep['after']:files[f'staged_inputs/v3/{rel}']=S/rel
for q in sorted(Path('/tmp').glob('Norm_ray_interfaces_*_v*_20261009.py')):files[f'helpers/{q.name}']=q
for q in [paths['audit'],paths['reading_notes'],S/programme,S/'README.md']:files[f'editorial/{q.name}']=q
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
    assert len(z.namelist())==len(files) and z.testzip() is None
    for n,q in files.items():assert z.read(n)==q.read_bytes()
artifacts={k:dict(path=str(q),bytes=q.stat().st_size,SHA256=sha(q)) for k,q in [('full_book_PDF',full),('selected_review_PDF',review),('minimal_TeX_source_archive',minimal),('actual_book_evidence_archive',evidence)]};artifacts['selected_review_PDF']['physical_pages']=nb;artifacts['minimal_TeX_source_archive']['members']=472;artifacts['actual_book_evidence_archive']['members']=len(files)
progress={n:sha(S/n) for n in ['README.md',programme]};paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — staged mathematical/mechanical/actual-rendered gate',preparation=prep,release=release,actual_reading=reading,mathematical_audit=math,post_render=post,underfull_comparison=under,artifacts=artifacts,progress_document_hashes=progress,active_book_changed=False,GitHub_published=False,canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — byte-verified owned book exports',artifacts=artifacts,reading_credit_from_export=0,active_book_changed=False,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
record.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — selected staged book checkpoint and owned artifacts exported',artifacts=artifacts,editorial_files={str(q):sha(q) for q in paths.values()},progress_document_hashes=progress,actual_final_book_pages=nb,actual_final_matching_views=nv,active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',book_pages=np,selected_pages=nb,views=nv,evidence_members=len(files),record_SHA256=sha(record))))
