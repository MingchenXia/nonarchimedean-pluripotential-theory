# Adapted frozen v1 helper SHA256: 29cd66bdfc2fd82063ea6cfc30e8f03a558dc27c870ecbdc54c0b1e86efcf019
# Adapted frozen validation helper SHA256: 337f58faef428d0c35a3d8b65ea3b4fce1946b9028c405666523a6c431d3cbf1
# Frozen preceding validation helper SHA256: a438f36d607367e1fca9c4f6864d6a4860215163ca3e763987743b463d96b664
# Frozen preceding v2 helper SHA256: ea7cdaa087235cce3fb8bce6119156293e571c3ef57ae908df23d4d187dff090
# Frozen preceding v1 helper SHA256: f73c8c6bc16daa74bc77d08708fa8099dc2f4c854aa64e2badc4c6bf9d818d8d
# Frozen validation template SHA256: f304b744603d49533ac9b2fddc126451f1447804d806532b6b7a64b162073cb5
# Frozen preceding v2 helper SHA256: 8e945d1a279b221a21c7069e9e4a74be837ea1a4ac1ee7078e379b3f70c979b7
# Frozen v1 validation helper SHA256: a899ef3a68371af9f9e06c29c4351320cb8e7198d2332e1d125860b2837a929c
# Adapted validation template SHA256: 9324679aad84d3a21164bdd40310e52f77fa645ab172dd537b85bb0a6a9a1363
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,shutil,time,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Metric_radial_dependencies_review_20261009';S=Path('/workspace/book-completion-drafts/norm-ray-interfaces-staging-v2-20261009')
O=C/'staged_book_validation_v2_20261009.json';log=C/'staged_book_validation_v2_20261009.log';snap=C/'compiled_staged_v2';assert not O.exists() and not log.exists() and not snap.exists()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
pin=C/'staging_preparation_v2_20261009.json';p=json.loads(pin.read_text())
for n,h in p['after'].items():assert sha(S/n)==h
start=datetime.now(timezone.utc).isoformat();tick=time.monotonic();env=os.environ.copy();env.update(TEXMFHOME='/workspace/.texlive',TEXMFCONFIG='/workspace/.texlive/texmf-config',TEXMFVAR='/workspace/.texlive/texmf-var')
with log.open('w') as dst:run=subprocess.run(['bash','scripts/validate-manuscript.sh'],cwd=S,env=env,stdout=dst,stderr=subprocess.STDOUT)
for n,h in p['after'].items():assert sha(S/n)==h
for n,h in p['active_inputs_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==p['active_book_PDF_SHA256']
for n,h in p['native_catalogue_preserved'].items():assert sha(R/n)==h
for n,h in p['other_active_TeX_preserved'].items():assert sha(R/n)==sha(S/n)==h
obj=dict(start_UTC=start,end_UTC=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-tick,status='DONE' if run.returncode==0 else 'FAILED',returncode=run.returncode,command=['bash','scripts/validate-manuscript.sh'],cwd=str(S),log_path=str(log),log_SHA256=sha(log),staging_preparation_SHA256=sha(pin),source_input_hashes=p['after'],active_book_changed=False,native_catalogue_preserved=True,GitHub_published=False,actual_book_reading_credit=0,original_results_promoted=[],canonical_status_changes=[],helper_source=__file__)
if run.returncode==0:
    snap.mkdir()
    for suffix in ['pdf','aux','toc','bbl','idx','ind','ilg','log','out','fls']:
        q=S/'manuscript'/f'book.{suffix}'
        if q.exists():shutil.copy2(q,snap/q.name)
    q=snap/'book.pdf'
    with fitz.open(q) as doc:pages=len(doc)
    obj['compiled_PDF']=dict(path=str(q),bytes=q.stat().st_size,SHA256=sha(q),physical_pages=pages)
O.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status=obj['status'],record_SHA256=sha(O),compiled_PDF=obj.get('compiled_PDF'),elapsed_seconds=obj['elapsed_seconds'])));raise SystemExit(run.returncode)
