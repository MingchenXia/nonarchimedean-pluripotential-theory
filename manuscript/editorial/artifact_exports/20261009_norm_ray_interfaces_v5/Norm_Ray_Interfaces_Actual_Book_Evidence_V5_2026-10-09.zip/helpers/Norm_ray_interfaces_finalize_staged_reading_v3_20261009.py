# Fresh v3 follows actual layout review. Frozen preceding unexecuted helper SHA256: 766775a17ac85bd241ab8c057bf8a4c18f3b79712da7b1b0f6674c6d14755599
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,re,subprocess,difflib
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Metric_radial_dependencies_review_20261009';S=Path('/workspace/book-completion-drafts/norm-ray-interfaces-staging-v3-20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();load=lambda n:json.loads((C/n).read_text())
ch=load('staged_book_release_checks_v3_20261009.json');prep=load('staging_preparation_v3_20261009.json');mp=Path(ch['manifest_path']);assert sha(mp)==ch['manifest_SHA256'];xs=json.loads(mp.read_text());views=[];last=None
for x in xs:
    assert not x['actually_viewed'] and not x['selected_text_read']
    n=C/'staged_book_notes_v3'/f"note_{x['number']:02d}.md";r=n.with_name(n.stem+'_receipt.json');a=json.loads(r.read_text())
    assert 'Read the complete selected text and displayed matching rendered image' in n.read_text()
    assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
    assert a['number']==x['number'] and a['physical_pages']==x['physical_pages'] and a['source_PDF_SHA256']==ch['PDF']['SHA256']
    assert sha(n)==a['note_SHA256'] and sha(x['path'])==a['image_SHA256']==x['image_SHA256'] and sha(x['selected_text_path'])==a['selected_text_SHA256']==x['selected_text_SHA256']
    assert last is None or a['UTC']>last;last=a['UTC']
    y={k:v for k,v in x.items() if k not in ['actually_viewed','selected_text_read']};y.update(actual_complete_text_read=True,actual_matching_image_freshly_displayed=True,sequential_note_path=str(n),sequential_note_SHA256=sha(n),observation_receipt_path=str(r),observation_receipt_SHA256=sha(r));views.append(y)
pages=sorted({p for x in xs for p in x['physical_pages']});assert pages==ch['selected_book_physical_pages'] and sum(len(x['physical_pages']) for x in xs)==len(pages)
reading=C/'actual_staged_book_reading_v3_20261009.json';audit=C/'staged_mathematical_self_audit_v3_20261009.json';post=C/'post_render_checks_v3_20261009.json';assert not any(p.exists() for p in [reading,audit,post])
checks=[]
for command in [['python3','editorial/tools/refcheck.py'],['python3','editorial/tools/check_open_problem_inventory.py']]:
    run=subprocess.run(command,cwd=S/'manuscript',text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);assert run.returncode==0,run.stdout;checks.append(dict(command=command,returncode=run.returncode,output=run.stdout))
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():assert sha(R/n)==h
for n,h in prep['other_active_TeX_preserved'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['unchanged_bibliographies'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
assert (S/'manuscript/bibliography/ComplexGeometry.bib').read_bytes()==(R/'manuscript/bibliography/ComplexGeometry.bib').read_bytes()+Path(prep['draft_path'],'ComplexGeometry_norm_ray_entries.bib').read_bytes()
historical={};whitespace={}
for row in prep['historical_formal_blocks_preserved']:
    n=row['path'];before=(R/n).read_text();after=(S/n).read_text();counts={}
    for e,count in row['environment_counts'].items():
        pat=r'\\begin\{'+e+r'\}.*?\\end\{'+e+r'\}';blocks=re.findall(pat,before,re.S);assert all(b in after for b in blocks);assert len(blocks)==len(re.findall(pat,after,re.S))==count;counts[e]=count
    assert re.findall(r'\\tag\{([^}]+)\}',after)==row['historical_manual_tags'];historical[n]=row
for n in prep['after']:
    before=(R/n).read_text().splitlines();after=(S/n).read_text().splitlines();assert Counter(x for x in before if x!=x.rstrip())==Counter(x for x in after if x!=x.rstrip())
    added=[x[2:] for x in difflib.ndiff(before,after) if x.startswith('+ ')];assert all(x==x.rstrip() for x in added)
    run=subprocess.run(['git','diff','--no-index','--check',str(R/n),str(S/n)],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);assert run.returncode in [0,1] and not run.stdout
    whitespace[n]=dict(added_lines=len(added),added_trailing_whitespace=0,check_returncode=run.returncode)
for p,h in prep['draft_fragments'].items():assert sha(p)==h
under=load('staged_underfull_delta_v3_20261009.json');assert not under['added_blocks'] and not under['removed_blocks']
reading.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — every selected final book page freshly read with matching individual display',PDF=ch['PDF'],actual_unique_book_pages=len(pages),fresh_complete_text_and_individually_displayed_pages=len(pages),fresh_matching_views=len(views),reused_exact_complete_text_and_rendered_pixel_pages=0,reused_matching_views=0,views=views,legacy_preparation_flags_rewritten=False,remaining_repairs=[],whole_book_new_reading_claim=False,active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
mathchecks=[
    'The finite complex sum envelope uses finite decompositions, positivity bounds from finitely many weights, and the largest-genuine-norm property. The adapted quadratic Hermitian construction is separate.',
    'For Hermitian reference and orthonormal adapted basis, filtration weight is the least nonzero coordinate weight. Hence H<=gauge, H<=A, and coordinate Cauchy–Schwarz gives A<=sqrt(N)H. These are direct attributed finite-dimensional explanations, not a new general theorem.',
    'The C2 example has gauge eta on e1 and sqrt(2)eta elsewhere. Supporting a+b and a-b give A(1,±1)=2 versus H(1,1)=sqrt(3); homogeneity and coordinate supporting functionals give A(2,0)=2,A(0,2)=2sqrt(2), so the parallelogram identity fails.',
    'Ordinary log length distance delta_infinity differs by factor 2 from the published complex Finski distance. Thus the sqrt(rank) comparison has error log(rank) in the latter, and divided degree error tends to zero under polynomial Hilbert growth. The chapter squared radial parameter t=2s is explicit.',
    'The graded product argument assumes genuine submultiplicativity of the base norm and filtration, sums all pairs of decomposition pieces, excludes zero products before taking logarithmic weights, factors the sums and then takes infima. It does not assert arbitrary Hermitian rays are multiplicative.',
    'Published Finski Lemma 2.6 and Corollary 3.5 supply version-specific locators. The finite-p FS theorem retains ample, bounded and submultiplicative premises and regularized FS; infinity needs raw continuity. Section 4 tensor classification and original Darvas quantization are not recursively certified by the selected 1–24 pages.',
    'The complete RWN25 arXiv v2 supplies the affine extension below the limiting DH support when the right derivative is finite. The rare outlier probability example has a full finite interval and finite-p vanishing difference, but possibly persistent maximal difference. It is explanatory, not a proof of the general main flat theorem.',
    'Parreau selected 21–26 expressly requires a maximal apartment system for ray/line and Euclidean-flat containment. An arbitrary chosen basis atlas needs an additional identification or direct argument; the general Euclidean proof does not automatically apply to L1. Scalar norm directions are retained.',
    'BE21 Section 9 uses a complete field and geometric reducedness, with geometric integrality added by 9.5. Boundedness is relative to a fixed metric. Complete algebraically closed extension has a controlled o(m^(n+1)) determinant error before the rational regular point. Separate superadditive leaf logs are distinguished from their difference.',
    'Signed total volume n!/m^(n+1) and probability mean 1/(mN_m) differ by vol(L); P1,O(2) gives 2c versus c. Nonbig total volume is zero. Signed mean convergence is not all-moment or spectral-law convergence.',
    'The trivial classical-disc coefficient paragraph and nonpure top-component injection need the source-local repairs stated. These diagnose proof scope rather than claim false intended volume theorems. General BJ22 Siu/envelopes remain OPEN and LPWZ density UNVERIFIED.',
    'Fresh v2 appends the new chapter section after its historical source note, preserving its implicit old label 65.18. V1 compiles but fails that preservation preflight and is not activated. All other 423 core TeX and NA bibliography remain unchanged. Complex bibliography appends exactly two pinned entries with distinct shorthands preserving old labels.',
    'Actual reading covers the selected final changed sections and seams, contents, new bibliography entries and all affected index pages only. Last full ordered book pass remains 4 October. No new original general theorem, independent hostile-model receipt or canonical status change is claimed.'
]
audit.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — ordinary scoped mathematical audit and actual rendered clearance',checks=mathchecks,actual_final_book_reading_SHA256=sha(reading),source_scope='Partial Finski published 1–24, Parreau author 21–26 and BE21 published 87–94; complete separately audited RWN25 arXiv v2; external foundational proofs remain attributed',source_input_hashes=prep['after'],draft_fragments=prep['draft_fragments'],original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
post.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — post-render reference/inventory and source preservation checks',checks=checks,historical_formal_blocks_preserved=historical,whitespace_checks=whitespace,underfull_delta_SHA256=sha(C/'staged_underfull_delta_v3_20261009.json'),actual_final_reading_SHA256=sha(reading),mathematical_audit_SHA256=sha(audit),release_checks_SHA256=sha(C/'staged_book_release_checks_v3_20261009.json'),semantic_notation_delimiter_review='Actual complete selected text and individual corresponding image review; no unavailable legacy automated audit claimed',active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',selected_book_pages=len(pages),views=len(views),reading_SHA256=sha(reading),math_SHA256=sha(audit),post_SHA256=sha(post))))
