# Norm ray interfaces book review — view 3

Physical pages: [3514, 3515].

Read the complete selected text and displayed matching rendered image.

Read complete physical3514–3515 and displayed the matching image. The H<=A<=sqrt(N)H argument is correct: minimum active filtration weight bounds the quadratic norm by the gauge, and the norm-envelope property supplies H<=A. The coordinate decomposition gives the upper bound. The C2 support-function calculation yields A(1,±1)=2, H(1,1)=sqrt(3), and by homogeneity the parallelogram contradiction is8 versus6. The log-length supremum and factor-two Finski distance are distinguished, with log(rank)/degree vanishing and the squared radial convention t=2s retained. The graded product display includes the full double sum and names base-norm/filtration multiplicativity; zero products are excluded before logarithms. The closing page clearly states the finite-p FS import and the additional infinity continuity premise, with working L.99/L.100 references. It has one spacious closing paragraph before the next chapter; the text is complete, readable and unclipped, with no mathematical or source-scope repair needed.

Scope: actual fresh review of these selected pages only; no additional whole-book or primary-source reading credit.
