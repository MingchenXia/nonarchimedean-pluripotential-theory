from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BBJ21_Finski_original_dependencies_review_20261009'
out=C/'actual_primary_reading_v1_20261009.json'
assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
pp=C/'primary_view_preparation_v1_20261009.json';prep=json.loads(pp.read_text())
assert prep['actual_source_reading_credit']==prep['actually_read_pages']==0
assert sha(prep['manifest_path'])==prep['manifest_SHA256']
rows=json.loads(Path(prep['manifest_path']).read_text());assert len(rows)==33
views=[];last=None
for i,x in enumerate(rows,1):
    rp=C/f'primary_notes_v1/note_{i:02d}_receipt.json';a=json.loads(rp.read_text())
    assert a['number']==i and a['source']==x['source'] and a['physical_pages']==x['physical_pages']
    assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
    assert last is None or a['UTC']>last
    last=a['UTC']
    assert not x['actually_viewed'] and not x['selected_text_read']
    for key,h in [('path','image_SHA256'),('selected_text_path','selected_text_SHA256')]:
        assert sha(x[key])==x[h]==a[h]
    assert sha(a['note_path'])==a['note_SHA256']
    assert sha(prep['sources'][x['source']]['path'])==a['source_PDF_SHA256']==x['source_PDF_SHA256']
    views.append(dict(**a,image_path=x['path'],selected_text_path=x['selected_text_path'],observation_receipt_path=str(rp),observation_receipt_SHA256=sha(rp)))
scopes={}
for key,src in prep['sources'].items():
    selected=[p for v in views if v['source']==key for p in v['physical_pages']]
    assert selected==src['selected_physical_pages'] and len(selected)==len(set(selected))
    full=selected==list(range(1,src['total_physical_pages']+1))
    scopes[key]=dict(**src,actually_read_physical_pages=selected,whole_physical_PDF_actually_read=full,unread_physical_pages=sorted(set(range(1,src['total_physical_pages']+1))-set(selected)))
assert scopes['BBJ21_JAMS2021']['whole_physical_PDF_actually_read']
assert not scopes['Finski_metric_structure_arxiv_v2']['whole_physical_PDF_actually_read']
assert len(scopes['Finski_metric_structure_arxiv_v2']['unread_physical_pages'])==32
for n,h in prep['protected_core_inputs'].items():assert sha(R/n)==h
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==prep['baseline_commit']
dp=C/'exact_diagnostics_v1_20261009.json';diag=json.loads(dp.read_text());assert len(diag['families'])==13
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete BBJ21 published source plus selected Finski original extension source',sources=scopes,actual_selected_source_page_pairs=66,actual_individually_displayed_matching_views=33,views=views,preparation_record_SHA256=sha(pp),preparation_flags_unchanged=True,diagnostics_SHA256=sha(dp),actual_book_reading_credit=0,whole_book_new_reading_claim=False,recursive_original_dependency_certification=False,original_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],active_book_changed=False,native_editor_changed=False,BJ22_Theorem_6_21_repaired=False,general_envelopes_proved=False,baseline_commit=prep['baseline_commit'],protected_core_inputs_unchanged=True,helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',pages=66,views=33,BBJ21_complete_pages=48,Finski_selected_pages=18,SHA256=sha(out))))
