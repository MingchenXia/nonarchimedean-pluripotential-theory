# Fresh revision fixes only the nonmathematical draft-length preflight; failed v1 preserved.
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile, shutil, subprocess

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BBJ21_Finski_original_dependencies_review_20261009'
E=R/'manuscript/editorial';O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
reading=json.loads((C/'actual_primary_reading_v1_20261009.json').read_text())
diag=json.loads((C/'exact_diagnostics_v1_20261009.json').read_text())
prep=json.loads((C/'primary_view_preparation_v1_20261009.json').read_text())
assert reading['actual_selected_source_page_pairs']==66 and len(reading['views'])==33
assert reading['sources']['BBJ21_JAMS2021']['whole_physical_PDF_actually_read']
assert len(diag['families'])==13
for n,h in prep['protected_core_inputs'].items():assert sha(R/n)==h
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==prep['baseline_commit']
paths={k:E/f'BBJ21_Finski_original_dependencies_source_{k}_20261009.{ext}' for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
record=C/'source_checkpoint_v1_20261009.json'
draft=Path('/tmp/BBJ21_Finski_original_dependencies_source_review_draft_v1_20261009.md')
owned=O/'BBJ21_Finski_Original_Dependencies_Authored_Records_V1_2026-10-09.zip'
full=O/'BBJ21_Finski_Original_Dependencies_Actual_Source_Evidence_V1_2026-10-09.zip'
dest=E/'artifact_exports/20261009_BBJ21_Finski_original_dependencies_sources'
assert not any(p.exists() for p in [*paths.values(),record,owned,full,dest])
assert draft.stat().st_size>12000
paths['review'].write_text(draft.read_text().rstrip()+'\n')
paths['reading_notes'].write_text(('# Actual original maximal-ray and extension source notes\n\n'
    'BBJ21: all 48 published physical pages in 24 views. Finski metric structure v2: '
    '18 of 50 pages (1–14 and 47–50), nine views; 15–46 remain unread in this round. '
    '66 source/page pairs, 33 individual matching displays, complete selected text. '
    'No new book pass or recursively certified external proof.\n'+
    ''.join('\n---\n\n'+Path(v['note_path']).read_text() for v in reading['views'])).rstrip()+'\n')
files={f'records/{p.name}':p for p in C.glob('*.json')}
files['manifests/prepared_primary_views.json']=Path(prep['manifest_path'])
for v in reading['views']:
    for key,kind in [('note_path','notes'),('observation_receipt_path','receipts')]:
        p=Path(v[key]);files[f'{kind}/{p.name}']=p
for p in sorted(Path('/tmp').glob('BBJ21_Finski_original_dependencies_*_v*_20261009.py')):files[f'helpers/{p.name}']=p
for p in sorted((R/'source_material/research_discovery_20261009_round1').glob('BBJ21*metadata_v1_20261009.json')):files[f'discovery/{p.name}']=p
files[f'drafts/{draft.name}']=draft
for key in ['review','reading_notes']:files[f'editorial/{paths[key].name}']=paths[key]
def archive(target,entries):
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,p in sorted(entries.items()):z.write(p,n)
    with zipfile.ZipFile(target) as z:
        assert len(z.namelist())==len(entries) and z.testzip() is None
        for n,p in entries.items():assert z.read(n)==p.read_bytes()
archive(owned,files)
fullfiles=dict(files)
for key,src in reading['sources'].items():fullfiles[f'primary/PDF/{key}.pdf']=Path(src['path'])
for v in reading['views']:
    for key,kind in [('image_path','images'),('selected_text_path','text')]:
        p=Path(v[key]);fullfiles[f'primary/{kind}/{p.name}']=p
archive(full,fullfiles)
artifacts={k:dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p),members=count) for k,p,count in [('authored_records_archive',owned,len(files)),('cloud_source_evidence_archive',full,len(fullfiles))]}
paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete BBJ21 and partial original Finski source audit',actual_reading=reading,exact_diagnostics=diag,artifacts=artifacts,active_book_changed=False,native_editor_changed=False,GitHub_published=False,canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — all archive members byte-verified',artifacts=artifacts,reading_credit_from_export=0,external_primary_PDF_text_images_uploaded=False,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
dest.mkdir(parents=True);target=dest/owned.name;shutil.copyfile(owned,target);assert sha(target)==sha(owned)
(dest/'SHA256SUMS').write_text(sha(target)+'  '+target.name+'\n')
(dest/'README.md').write_text(f'''# Original BBJ21 and Finski dependency evidence, 9 October 2026

BBJ21's exact published author offprint is fully read: 48 physical pages,
24 individually displayed matching text/image views. Finski's exact
arXiv:2209.03853v2 is partially read: 1–14 and 47–50, 18 of 50 pages,
nine views. The combined actual selection is 66 source/page pairs in
33 views; Finski 15–46 remain unread in this round.

The {len(files)}-member authored archive retains actual notes, receipts,
acquisition/preparation records, exact elementary diagnostics, helpers,
source audit and scoped discovery metadata. The {len(fullfiles)}-member
cloud source archive additionally retains both controlling PDFs and
matching full selected texts/images. External primary PDF/text/images
stay in the cloud. Every member was checked against its source bytes.
Preparation, export and upload give no additional reading credit.

The literal BBJ21 Lemma A.2 fails for constant potentials; the intended
Corollary A.3 and main variational theorems are not declared disproved.
Fibre energy, origin/epsilon bookkeeping and squared-FS factors are
recorded separately from original NA/OT proof obligations. Finski
Corollary 2.12 retains smooth projective/ample/continuous-psh hypotheses.

The 4,667-page book, both bibliographies, native LaTeX catalogue/editor
and canonical 42 atoms/twelve formal problems are unchanged here.
General BJ22 homogeneous Siu/envelopes remain OPEN, LPWZ density
UNVERIFIED, and the Theorem 6.21 proof warning binding. No original
general result or independent-model receipt is supplied. Last complete
ordered whole-book reading remains 4 October. Continue cloud only.
'''.rstrip()+'\n')
p=R/'README.md';s=p.read_text();marker='**Latest verified Parseval/raw-FS GitHub publication, 9 October 2026:**';assert s.count(marker)==1
intro='''**Latest original maximal-ray/extension source checkpoint, 9 October 2026:**
the [source audit](manuscript/editorial/BBJ21_Finski_original_dependencies_source_review_20261009.md)
reads all 48 published BBJ21 pages and 18 of 50 Finski metric-structure
v2 pages in 33 matching displays. Thirteen elementary diagnostics record
the literal constant-potential failure of BBJ21 Lemma A.2, fibre energy
and squared-FS calibration, while preserving the intended main theorems'
original proof obligations. Finski Corollary 2.12 retains its exact
holomorphic hypotheses. The [authored evidence](manuscript/editorial/artifact_exports/20261009_BBJ21_Finski_original_dependencies_sources/README.md)
pins complete versus partial scope. The 4,667-page book and native editor
are unchanged; general BJ22 Siu/envelopes remain OPEN.

''';p.write_text(s.replace(marker,intro+marker,1))
p=E/'second_reading_and_research_programme_20261002.md';s=p.read_text();marker='## Latest verified Parseval/raw-FS GitHub publication, 9 October 2026\n';assert s.count(marker)==1
intro='''## Latest original maximal-ray/extension source checkpoint, 9 October 2026

The [original-source audit](BBJ21_Finski_original_dependencies_source_review_20261009.md)
completes actual reading of BBJ21's published 48-page offprint in 24
ordered matching displays, including both appendices and references.
Finski metric structure arXiv:2209.03853v2 is read only on 1–14 and
47–50: 18 of 50 pages in nine displays. Physical 15–46 remain unread
in this round. Total: 66 source/page pairs, 33 actual views. Neither
preparation nor export/upload adds reading credit.

The original maximal-ray chain retains Berman16's model construction,
NA MA uniqueness/duality and decreasing model regularization. Ordered
energy strictness and the NA lower slope bound identify the datum;
monotone energy alone does not. Literal BBJ21 Lemma A.2 fails for
constant potentials; Corollary A.3 and the intended main theorems are
not declared false. General-origin, signed-log numerator and epsilon
steps remain explicit obligations. Thirteen exact elementary families
also calibrate fibre energy, multiplier shifts, klt/SNC thresholds,
trivial ratios, squared FS, psh representatives and fixed extension twists.

The read Corollary 2.12 of Finski supplies the exact continuous-psh,
ample, smooth projective/closed-submanifold restriction quotient input.
Its OT/Bernstein–Markov original proofs are separate dependencies.
Next audit exact BoJ18a/BoJ18b and Berman16 inputs, plus the original
semiclassical extension sources and Okounkov lattice arguments, before
further general book integrations. The [authored archive](artifact_exports/20261009_BBJ21_Finski_original_dependencies_sources/README.md)
preserves the actual notes and diagnostics; primary PDFs/images stay cloud.

The current verified 4,667-page book, both bibliographies and native
catalogue/editor are unchanged in this source unit. The canonical
42 atoms/twelve problems and tiers (0,3,7,15,17) are unchanged.
BJ22 critical homogeneous Siu/general envelopes stay OPEN, LPWZ density
UNVERIFIED, and the user's Theorem 6.21 warning binding. No original
general theorem, independent-model receipt or fresh complete book pass
is claimed. Last complete ordered book reading remains 4 October.
Continue cloud-only, integrate incoming author progress and publish
checked units regularly. Xean stays suspended.

''';p.write_text(s.replace(marker,intro+marker,1))
published=[*paths.values(),*sorted(dest.iterdir()),R/'README.md',p];assert len(published)==9
for path in [paths['review'],paths['reading_notes'],dest/'README.md']:
    assert path.read_bytes().endswith(b'\n') and not path.read_bytes().endswith(b'\n\n')
    assert all(line==line.rstrip() for line in path.read_text().splitlines())
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — original dependency source checkpoint and authored evidence exported',editorial_files={str(p.relative_to(R)):dict(SHA256=sha(p),bytes=p.stat().st_size) for p in published},artifacts=artifacts,actual_primary_pages=66,actual_matching_views=33,BBJ21_complete_unique_pages=48,Finski_selected_pages=18,active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],GitHub_published=False,helper_source=__file__,helper_SHA256=sha(__file__))
record.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',files=9,owned_members=len(files),cloud_members=len(fullfiles),record_SHA256=sha(record))))
