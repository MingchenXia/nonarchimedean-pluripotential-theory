from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, fitz, subprocess
from PIL import Image, ImageDraw

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/BBJ21_Finski_original_dependencies_review_20261009'
W=Path('/tmp/BBJ21_Finski_original_dependencies_primary_views_v1_20261009')
N=C/'primary_notes_v1';out=C/'primary_view_preparation_v1_20261009.json'
assert C.exists() and not any(p.exists() for p in [W,N,out])
W.mkdir();N.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
bookprep=json.loads((R/'source_material/BJKS1_Finski_dependencies_review_20261009/staging_preparation_v2_20261009.json').read_text())
names=sorted(set(bookprep['other_active_TeX_preserved'])|{n for n in bookprep['after'] if n.endswith('.tex')})
assert len(names)==425
names+=['manuscript/book.pdf','manuscript/bibliography/ComplexGeometry.bib','manuscript/bibliography/NonArchimedean.bib',
        'output/open_problems_catalogue_2026-10-03.tex','output/open_problems_catalogue_2026-10-03.pdf',
        'README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']
protected={n:sha(R/n) for n in names}
assert protected['manuscript/book.pdf']=='60e0e21a5a966a3a954c171aedd13e6cd623261b01e448db6b67febab253efcf'
sources=[('BBJ21_JAMS2021','BBJ21_published_author.pdf','36c3741fa0c0185099698862a29e301e139c07b56d63519369d77eb06ca4be11',48,list(range(1,49))),
         ('Finski_metric_structure_arxiv_v2','Finski_metric_structure_arxiv_v2.pdf','51f72c62959037a8a2d7e0036c15af1182cb98a1623b88f1e217b3a7b82d87e3',50,list(range(1,15))+list(range(47,51)))]
views=[];pdfs={}
for key,name,pin,total,selected in sources:
    pdf=C/name;assert sha(pdf)==pin
    pdfs[key]=dict(path=str(pdf),bytes=pdf.stat().st_size,SHA256=pin,total_physical_pages=total,
        selected_physical_pages=selected,whole_PDF_selected=len(selected)==total)
    with fitz.open(pdf) as d:
        assert len(d)==total
        for i in range(0,len(selected),2):
            pp=selected[i:i+2];panels=[];texts=[]
            for n in pp:
                pix=d[n-1].get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False)
                panels.append(Image.frombytes('RGB',[pix.width,pix.height],pix.samples))
                texts.append(f'{key} SELECTED PRIMARY PHYSICAL PAGE {n}\n'+d[n-1].get_text())
            canvas=Image.new('RGB',(sum(p.width for p in panels),max(p.height for p in panels)+28),'white')
            draw=ImageDraw.Draw(canvas);x=0
            for n,panel in zip(pp,panels):
                draw.text((x+8,8),f'{key} physical {n}',fill='black');canvas.paste(panel,(x,28));x+=panel.width
            number=len(views)+1;ip=W/f'sheet_{number:02d}.png';tp=W/f'sheet_{number:02d}.txt'
            canvas.save(ip);tp.write_text('\n\n'.join(texts))
            views.append(dict(number=number,source=key,physical_pages=pp,path=str(ip),image_SHA256=sha(ip),
                selected_text_path=str(tp),selected_text_SHA256=sha(tp),source_PDF_SHA256=pin,
                actually_viewed=False,selected_text_read=False))
assert len(views)==33 and sum(len(v['physical_pages']) for v in views)==66
mp=W/'manifest.json';mp.write_text(json.dumps(views,ensure_ascii=False,indent=2)+'\n')
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — original maximal-ray and extension sources/views prepared; zero reading credit',
    sources=pdfs,prepared_source_page_pairs=66,prepared_views=33,manifest_path=str(mp),manifest_SHA256=sha(mp),
    protected_core_inputs=protected,baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    prior_different_BBJ_arxiv_v3='source_material/ch60_audit_20261002/BBJ21v3.pdf; distinct 40-page layout, no reading receipt reused',
    actual_source_reading_credit=0,actually_read_pages=0,whole_primary_PDF_reading_claim=False,
    whole_book_new_reading_claim=False,active_book_changed=False,native_editor_changed=False,
    canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',prepared_source_page_pairs=66,prepared_views=33,record_SHA256=sha(out))))
