from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, requests, fitz

C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/BBJ21_Finski_original_dependencies_review_20261009')
assert not C.exists();C.mkdir()
sources=[('BBJ21_published_author','https://sebastien.boucksom.perso.math.cnrs.fr/publis/BBJ_YTD.pdf'),
         ('Finski_metric_structure_arxiv_v2','https://arxiv.org/pdf/2209.03853v2')]
results=[]
for key,url in sources:
    row=dict(key=key,url=url,UTC=datetime.now(timezone.utc).isoformat(),actual_source_reading_credit=0)
    try:
        r=requests.get(url,timeout=25);row.update(HTTP_status=r.status_code,final_URL=r.url,content_type=r.headers.get('content-type'))
        if r.status_code==200 and r.content.startswith(b'%PDF'):
            p=C/(key+'.pdf');p.write_bytes(r.content)
            with fitz.open(p) as d:pages=len(d);metadata=d.metadata
            row.update(status='ACQUIRED — unread',path=str(p),bytes=p.stat().st_size,
                SHA256=hashlib.sha256(p.read_bytes()).hexdigest(),physical_pages=pages,PDF_metadata=metadata)
        else:row.update(status='FAILED — no primary PDF reading',response_bytes=len(r.content))
    except Exception as e:row.update(status='FAILED — no primary PDF reading',error=type(e).__name__+': '+str(e))
    q=C/(key+'_acquisition_v1_20261009.json');q.write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n')
    results.append(row)
print(json.dumps(results,ensure_ascii=False))
