from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction as F
from math import comb, exp
import hashlib, json

C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/BBJ21_Finski_original_dependencies_review_20261009')
out=C/'exact_diagnostics_v1_20261009.json'
assert not out.exists()
families=[]
def add(key, facts, scope):
    families.append(dict(key=key,status='PASS — elementary calibration only',facts=facts,scope=scope))

for n in range(1,9):
    assert comb(n+1,1)==n+1
add('energy_fibre_constant_factor',dict(dimensions=list(range(1,9)),energy_constant_translation='E(f)=f',ordinary_wedge_coefficient='n+1',correct_fibre_factor='1/((n+1)V)'), 'Spatially constant smooth convex f(t); diagnoses the missing n+1 in printed Lemma 1.6, without disproving convexity or affine-energy characterization.')

c,V=F(3,2),F(7,3)
assert abs(c)*V==F(7,2) and F(0)**F(3,4)==0
add('A2_constant_potential',dict(c=str(c),V=str(V),all_I_functionals='0',left_side=str(abs(c)*V),printed_right_side='0'), 'Literal Lemma A.2 and its constant-insensitive proof bound fail. Does not refute intended Corollary A.3 or main theorems.')

u,j=F(2),F(5)
assert abs(j-u)==3 and abs(j)==5 and abs(abs(j-u)-abs(j))<=abs(u)
add('arbitrary_origin_segment_length',dict(u=str(u),endpoint=str(j),distance_from_zero=str(abs(j)),distance_from_u=str(abs(j-u))), 'Constant potentials give d1=absolute difference under probability normalization. Theorem 2.16 printed parameter is not exactly unit speed at arbitrary origin; asymptotic ratio tends to one.')

for m,m0 in [(1,1),(3,2),(16,7)]:
    a=F(2*m+2*m0,2*m+m0)
    assert a>1 and a*F(-2)<=F(-2)
add('dyadic_multiplier_degree_shift',dict(samples=[[m,m0,str(F(2*m+2*m0,2*m+m0))] for m,m0 in [(1,1),(3,2),(16,7)]],sign='phi_m<=0'), 'Subadditivity supplies dyadic monotonicity with m+m0 denominators only after retaining the nonpositive normalization.')

for eps in [F(1,10),F(1,2),F(9,10)]:
    assert F(-1)<(1-eps)*F(-1)
add('negative_energy_Ding_contradiction',dict(c='-1',epsilons=['1/10','1/2','9/10'],impossible='c >= (1-epsilon)c'), 'Checks the algebra of the original stability contradiction, not compactness or singularity estimates.')

epsilon=F(1,2)
assert F(1)-F(1)/(1+epsilon)==F(1,3)
add('uniform_klt_margin',dict(openness_epsilon='1/2',A_theta_over_A_lower_bound='1/3'), 'B.8 conversion epsilon/(1+epsilon); openness itself is external.')

cu,cv=F(0),F(1,2)
assert cv-cu<1
assert not F(-2)>-1 and F(-2)<1
assert F(2)>-1 and not F(2)<1
add('SNC_integrability_sign',dict(correct='c_V-c_U < 1',printed='c_V-c_U > -1',examples=['-2 is integrable but violates printed condition','2 passes printed condition but is nonintegrable']), 'Squared exponential convention and radial power threshold; preceding uniform margin yields the correct condition.')

s,M=F(-3,2),F(2)
assert s<0 and s+M>=0
add('signed_log_numerator_gate',dict(s=str(s),M=str(M),shifted_numerator_coefficient=str(s+M),extra_epsilon_term='epsilon*M*w(tau)'), 'Negative s log|tau| is not quasi-psh. Simultaneous shifting is an integrability identity but does not alone remove the additional epsilon term in B.7.')

assert F(0)==0
add('trivial_valuation_ratio',dict(A_trivial='0',S_trivial='0',ratio='undefined 0/0'), 'Exclude trivial valuation in A/S; this is distinct from retaining it for maxima of canonical NA potentials.')

a=F(3)
rho=1/a
assert rho**(-2)==a*a and rho!=a*a
add('squared_FS_scalar_calibration',dict(norm_scale=str(a),evaluation_length_norm=str(rho),correct_squared_metric_ratio=str(a*a),formula='rho^{-2}'), 'Lemma 2.14 implies the inverse square, correcting literal (2.33); logarithmic uniform convergence survives.')

assert exp(F(1,2)*10)>exp(F(1,2)*2)
add('USC_upward_spike',dict(weight='1 at x0, 0 elsewhere',distributional_ddc='0',smooth_volume_integral='V',sup_exp_weight='exp(p)'), 'A USC representative with positive distributional curvature need not be the psh representative. (2.20) requires actual psh weights; no statement about valid section-log weights is refuted.')

for k in range(1,10):
    p0=3
    assert (k+p0)-k==p0
add('fixed_twist_extension_comparison',dict(reference_ratio='h/h0 bounded by C',fixed_twist=3,comparison_loss='C^{p0/2} on lengths, independent of k'), 'Theorem 2.5 fixes p0 before k; comparison of the fixed factor is not an exponential degree loss.')

for n in range(1,6):
    for k in range(1,9):
        mass=F(7,3)
        assert mass>0 and F(n,n)==1
add('fixed_MA_mass_and_length_conventions',dict(Finski_mass='c1(L)^n/n!',BBJ_mass='1',length_vs_squared_metric='factor 2 in logarithms',semiclassical_quotient='k^{-(n-m)/2}'), 'Fixed positive mass affects norm constants; it does not become degree-dependent or probability mass without explicit normalization.')

assert len(families)==13
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — thirteen elementary diagnostic families',families=families,original_general_results_promoted=[],independent_model_receipt=None,canonical_status_changes=[],BJ22_Theorem_6_21_repaired=False,helper_source=__file__,helper_SHA256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(families=len(families),SHA256=hashlib.sha256(out.read_bytes()).hexdigest())))
