# Fresh urllib-only acquisition following missing optional requests import; prior helper preserved.
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, urllib.request, fitz

C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/BBJ21_Finski_original_dependencies_review_20261009')
assert not C.exists();C.mkdir()
sources=[('BBJ21_published_author','https://sebastien.boucksom.perso.math.cnrs.fr/publis/BBJ_YTD.pdf'),
         ('Finski_metric_structure_arxiv_v2','https://arxiv.org/pdf/2209.03853v2')]
failed=C/'acquisition_helper_import_failure_v1_20261009.json';failed.write_text(json.dumps(dict(status='FAILED before directory or network access',error='ModuleNotFoundError: No module named requests',failed_helper_source=str(Path(__file__).with_name('BBJ21_Finski_original_dependencies_acquire_v1_20261009.py')),failed_helper_SHA256='fafe1841278b02e20a1d0934a80e9dc1c7be673920f4890385600b7f4274d101',actual_source_reading_credit=0),indent=2)+'\n')
results=[]
for key,url in sources:
    row=dict(key=key,url=url,UTC=datetime.now(timezone.utc).isoformat(),actual_source_reading_credit=0)
    try:
        with urllib.request.urlopen(url,timeout=25) as r:
            content=r.read();row.update(HTTP_status=r.status,final_URL=r.url,content_type=r.headers.get('content-type'))
        if row['HTTP_status']==200 and content.startswith(b'%PDF'):
            p=C/(key+'.pdf');p.write_bytes(content)
            with fitz.open(p) as d:pages=len(d);metadata=d.metadata
            row.update(status='ACQUIRED — unread',path=str(p),bytes=p.stat().st_size,
                SHA256=hashlib.sha256(p.read_bytes()).hexdigest(),physical_pages=pages,PDF_metadata=metadata)
        else:row.update(status='FAILED — no primary PDF reading',response_bytes=len(content))
    except Exception as e:row.update(status='FAILED — no primary PDF reading',error=type(e).__name__+': '+str(e))
    q=C/(key+'_acquisition_v2_20261009.json');q.write_text(json.dumps(row,ensure_ascii=False,indent=2)+'\n')
    results.append(row)
print(json.dumps(results,ensure_ascii=False))
