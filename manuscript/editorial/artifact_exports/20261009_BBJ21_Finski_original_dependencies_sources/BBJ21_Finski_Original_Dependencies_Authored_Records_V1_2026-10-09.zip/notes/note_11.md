# Original maximal-ray/extension dependency review — view 11

Source: BBJ21_JAMS2021. Physical pages: [21, 22].

Read the complete selected text and individually displayed the matching rendered image.

Printed 625–626 retain effective-Q-divisor/klt/cohomological hypotheses for Ding versus log K-stability, with original MMP/Fujita inputs explicit. Section 4's linear growth means sup_X U_t=O(t), and Proposition 4.1 equates it with d1(U_t,0)=O(t) for finite-energy psh rays using affine/convex energy bounds, ordered distance and the source Appendix-A reference-volume estimate. Subtracting at allows the S1-invariant lift to extend across tau=0; w(U)=w(V)-a w(tau) is independent of that auxiliary choice. U_NA=-sigma(v)(U) is initially a function on the extended divisorial family, not an automatic psh metric on all X_NA. Its value at v_triv is lambda_max, including signed constant slopes. The Ross–Witt Nyström Legendre convention is inf_t(U_t-t lambda), with inverse sup_lambda(hat U^lambda+lambda t), and the below-lambda_max valuation formula is kept in that sign convention. Algebraic psh metrics use exp(-2U) h0 in the S1 lift, so later squared-norm and time factors need explicit calibration. Lemma 4.4 only starts here and its full conditions/proof are on the next view. Both full texts and the matched render were read; no automatic general FS membership or Siu decomposition follows from these divisorial definitions.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
