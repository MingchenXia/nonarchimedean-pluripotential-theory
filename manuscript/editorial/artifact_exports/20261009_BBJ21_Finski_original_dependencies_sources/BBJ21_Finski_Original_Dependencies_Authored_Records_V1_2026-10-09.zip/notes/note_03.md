# Original maximal-ray/extension dependency review — view 3

Source: BBJ21_JAMS2021. Physical pages: [5, 6].

Read the complete selected text and individually displayed the matching rendered image.

Printed 609–610 explain the slope route rather than an unconditional identification of every ray with an algebraic one. The NA functional shares notation with its complex version by explicit convention; algebraic rays have equality of normalized slopes, and L_theta uses inf(A_theta+phi). For an arbitrary finite-energy geodesic ray the multiplier-ideal approximants are asserted to control the L slope and bound the energy slope in the required direction; the actual proof is still ahead. The original NA finite-energy framework is attributed to BFJ15/16 and BoJ18a, with its probability MA normalization and quotient by constants explicit. Theorem D uses polarized smooth X and semipositive klt theta with c1 equality, and distinguishes positivity on every nonconstant E1,NA function from uniform stability on test configurations. Introductory decreasing-sequence statements are retained in this source's projective complex setup and not imported into arbitrary directed model systems without their own proof. The source-era recent-development paragraph identifies the extra singular-pair/resolution and automorphism-relative inputs; it is not asserted as a current complete status-of-the-art survey. Both pages and their rendered image were actually read, preserving the forward obligations of Section 6 and Appendix B.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
