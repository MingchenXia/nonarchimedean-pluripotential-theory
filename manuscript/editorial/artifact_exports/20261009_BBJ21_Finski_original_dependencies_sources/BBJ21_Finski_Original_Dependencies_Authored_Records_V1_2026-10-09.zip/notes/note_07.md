# Original maximal-ray/extension dependency review — view 7

Source: BBJ21_JAMS2021. Physical pages: [13, 14].

Read the complete selected text and individually displayed the matching rendered image.

Printed 617–618 retain the Ricci/MA equivalence with a free normalizing constant, so the source's probability MA convention is compatible with the displayed omega0^n reference density. Klt theta means quasi-positive theta with quasi-psh psi and exp(-2psi) integrable, strengthened to Lp for some p>1 by openness; it does not mean theta is semipositive. Lemma 2.4 uses finite-energy zero Lelong numbers, Skoda integrability and Hölder before invoking Kolodziej continuity and local smooth regularity. The cone-angle example is confined to a smooth hypersurface/SNC locus. The probability measure mu_theta is uniquely normalized and has a positive volume-form lower bound from the quasi-psh upper bound, with Lp density from klt. Ding is translation invariant because both L_theta and E shift by c, and coercivity uses the normalized Aubin J. The equivalence of minimizers and twisted KE currents requires theta>=0 through Berndtsson convexity, whereas the earlier one-way minimizer assertion is separate. Entropy is half the relative entropy and its dual uses exp(2g); these constants remain explicit. Both complete texts and the matching rendered image were actually reviewed; openness, Skoda, Kolodziej and Berndtsson foundations remain cited original inputs.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
