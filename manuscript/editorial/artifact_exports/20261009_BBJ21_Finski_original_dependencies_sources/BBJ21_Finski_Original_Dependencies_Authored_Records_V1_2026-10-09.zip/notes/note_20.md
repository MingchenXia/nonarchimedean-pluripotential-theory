# Original maximal-ray/extension dependency review — view 20

Source: BBJ21_JAMS2021. Physical pages: [39, 40].

Read the complete selected text and individually displayed the matching rendered image.

BBJ21 printed 643–644 establishes Lemma B.3 through local projective domination and the external Jonsson–Mustata Proposition 3.7: point-centered analytic prime divisors are determined by their valuations on O_X,x and can be represented on smooth blowups of point-supported ideals. This is not the assertion that all divisors on arbitrary complex manifolds are determined by global meromorphic functions. Section B.6 invokes the classical complex Siu decomposition of a quasi-psh pullback to subtract its generic divisorial Lelong term; this is distinct from the disputed homogeneous NA Siu result in BJ22. Lemma B.4 gives ord_E J(U)<=ord_E U<ord_E J(U)+A_X(E), using OT/Demailly regularization for the first inequality and change of variables plus the SNC integrability threshold for the second. Theorem B.5 assumes an analytic, hence nonnegative-coefficient, numerator U and arbitrary quasi-psh denominator V. Its uniform epsilon criterion tests all prime divisors with centers contained in compact K, or equivalently point-centered divisors there. These exact hypotheses must be kept when applying the criterion to negative coefficients of log|tau|; that extension has not yet been proved by this theorem.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
