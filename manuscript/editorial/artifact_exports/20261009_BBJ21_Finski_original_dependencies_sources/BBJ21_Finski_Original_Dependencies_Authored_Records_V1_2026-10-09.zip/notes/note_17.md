# Original maximal-ray/extension dependency review — view 17

Source: BBJ21_JAMS2021. Physical pages: [33, 34].

Read the complete selected text and individually displayed the matching rendered image.

BBJ21 printed 637–638 fixes S_L(v)=V^{-1} integral vol(L,v>=lambda) d lambda and scales rational L by m^{-1}. Lemma 7.1 is a semiuniform upper estimate S_m <= (1+epsilon) S_L, imported from BlJ20, not an absolute uniform error. Ratios A_theta/S_L and positive S_L must be restricted to nontrivial divisorial valuations: the earlier convention includes v_triv with A=S=0, which would make a literal 0/0 undefined; the lct formula explicitly excludes it. Theorem 7.3 uses the semiuniform estimate to pass the basis lct infima to delta. Lemma 7.4 imports the NA finite-energy Monge–Ampere solution for delta_v and E_dual(delta_v)=S_L, with J>=S_L/n, from BoJ18b. Consequently the threshold/stability proof is not independent of that NA theory. The forward stability implication yields delta>=1+epsilon/n; the converse uses rational delta>=1 and the imported scaling inequality delta E(delta^{-1}phi)>=delta^{-1/n}E(phi) to get D>= (1-delta^{-1/n})J. The nef threshold in Theorem 7.5 is numerical, whereas the definition of beta requires the Ricci remainder to be a smooth semipositive form even though omega itself may be a finite-energy current. The theorem assumes semipositive klt theta and does not assume c1(X,theta)=c1(L).

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
