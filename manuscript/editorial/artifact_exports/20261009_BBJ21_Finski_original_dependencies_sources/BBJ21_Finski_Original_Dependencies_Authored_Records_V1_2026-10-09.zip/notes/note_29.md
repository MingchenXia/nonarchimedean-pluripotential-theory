# Original maximal-ray/extension dependency review — view 29

Source: Finski_metric_structure_arxiv_v2. Physical pages: [9, 10].

Read the complete selected text and individually displayed the matching rendered image.

Finski metric-structure physical pages 9–10 state the uniform OT theorem 2.4 with a canonical-bundle twist, neat analytic weight, smooth multiplier-ideal zero locus, and curvature nonnegativity for alpha in [1,2]. Theorem 2.5 removes the twist by fixing p0 and a smooth positive reference metric, then treating L^{k+p0} with the continuous psh metric on its k part. The comparison of h and h0 costs a constant depending on fixed p0, not an exponential in k; this fixed-twist order is essential. The lower bound gamma(delta_Y)e^{-delta_Y}>=1/17 permits an unweighted L2 extension bound. The residue-measure constant from (2.6) has to be retained or absorbed into C; (2.12) writes only 17 after replacing the residue measure. Eventual surjectivity, not every degree, follows. Theorem 2.6 is a separate sharper semiclassical quotient norm comparison for smooth strictly positive h, normalized by k^{(n-m)/2}, imported from [27] Theorem 1.1. Neither theorem establishes a singular-base or merely big line bundle extension statement. The exact assertion that the distance-log weight has neat analytic rather than only comparable logarithmic singularities rests on its cited original construction, not a proof supplied on these two pages.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
