# Original maximal-ray/extension dependency review — view 33

Source: Finski_metric_structure_arxiv_v2. Physical pages: [49, 50].

Read the complete selected text and individually displayed the matching rendered image.

Finski metric-structure physical pages 49–50 finish the exact bibliography: [27] is Semiclassical Ohsawa–Takegoshi extension theorem and asymptotic of the orthogonal Bergman kernel, arXiv:2109.06851 (2021); [28] is arXiv:2201.04102, and [29] arXiv:2207.02761. These original semiclassical proofs are not newly acquired or read by identifying them here. [43] explicitly includes the 2001 Ohsawa erratum, which must remain part of that original dependency. [48] identifies Reboulet's asymptotic FS paper as Math. Z. 299 (2021), 2341–2378. This completes actual reading of the prepared 18-page selection (1–14 and 47–50), nine individual two-page views, of this exact 50-page arXiv v2. It is not a complete-paper reading: physical pages 15–46, including multiplication, classification, geodesic and most appendix proofs, remain outside this round. The selected Corollary 2.12 proof has been read; recursively imported OT/Bernstein–Markov proofs remain explicit external gates.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
