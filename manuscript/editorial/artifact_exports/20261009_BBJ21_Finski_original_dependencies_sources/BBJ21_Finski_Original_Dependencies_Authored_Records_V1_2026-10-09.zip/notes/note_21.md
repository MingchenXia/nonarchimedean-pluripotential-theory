# Original maximal-ray/extension dependency review — view 21

Source: BBJ21_JAMS2021. Physical pages: [41, 42].

Read the complete selected text and individually displayed the matching rendered image.

BBJ21 printed 645–646 proves B.5 by resolving the analytic numerator, approximating a hypersurface valuation using point-centered rational monomial valuations, and applying the multiplier-ideal inequalities to kV with k tending to infinity. The convergence w_m(V)->ord_E(V) requires this scaling to make the discrepancy/k error vanish; it does not follow from a single unscaled application of B.4. The analytic-singularity case prints c_i(V)-c_i(U)>-1, whereas the required integrability condition is c_i(V)-c_i(U)<1; the preceding uniform-epsilon inequality with nonnegative coefficients gives the correct condition. This is a sign error in the proof line, not a failure of the intended integrability criterion. The final Holder step uses k>=2 and 1/(k-1)<=epsilon; the displayed allowed k>=1 must be read with that denominator restriction. The apparent use of (ii) at the last step actually needs the already established stronger (iv), which controls centers meeting K. B.7 passes to algebraic rational divisorial valuations and requires a compact invariant Zariski closed Y, circle-invariant potentials, and an analytic numerator. Its reduction to invariant point-centered valuations continues on the next page; no signed-log extension has been asserted.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
