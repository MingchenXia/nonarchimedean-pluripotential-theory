# Original maximal-ray/extension dependency review — view 19

Source: BBJ21_JAMS2021. Physical pages: [37, 38].

Read the complete selected text and individually displayed the matching rendered image.

BBJ21 printed 641–642 defines analytic singularities with nonnegative real coefficients and locally bounded errors, rather than only integral ideal powers. Its log resolution uses Hironaka and includes the relative canonical divisor. Strong openness Theorem B.1 is imported from Guan–Zhou/Berndtsson, with a single epsilon near a compact K obtained by finite local covering. For analytic numerator U, Corollary B.2 reduces after resolving U to a holomorphic monomial f and V'=V+sum(m-c_i)log|z_i|; the latter has nonnegative added coefficients, so strong openness applies. The factor V'-V is bounded above locally, which gives the final one-sided domination. All equalities involving bounded singularity errors should be read as local equivalence for integrability. The change of variables places the relative canonical logarithm on the numerator with positive sign. The SNC criterion is c_i+1>d_i for the square-integrability convention e^{2(U-V)}. Analytic prime divisors are equivalence classes on modifications, not determined in general by the valuation on global meromorphic functions: those functions may all be constant. This analytic caveat does not automatically disappear in a nonalgebraic setting.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
