# Original maximal-ray/extension dependency review — view 28

Source: Finski_metric_structure_arxiv_v2. Physical pages: [7, 8].

Read the complete selected text and individually displayed the matching rendered image.

Finski metric-structure physical pages 7–8 separate the extension theorem with a uniform constant (Demailly/Ohsawa) from the author's semiclassical extension theorem. The proof architecture for Theorem 1.8 still imports Phong–Sturm and Berndtsson, not just elementary interpolation. Norms with a chosen measure are explicitly distinguished from those using the metric's Monge–Ampere measure; the notation paragraph appears to write F where L is intended in the latter formula. A bounded bundle metric means bounded above and below by smooth metrics. The multiplier ideal convention here is |f|^2 e^{-psi}, in contrast to BBJ21's |f|^2 e^{-2U}; translating psi=2U is necessary. Neat analytic singularities require a smooth remainder, stricter than the merely bounded remainder used in BBJ21 Appendix B. Lemma 2.3 introduces the distance-log weight at codimension n-m, with the cutoff radius taken small. Its complete hypotheses and consequences are on the next page and have not yet been inferred from this displayed definition.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
