# Original maximal-ray/extension dependency review — view 24

Source: BBJ21_JAMS2021. Physical pages: [47, 48].

Read the complete selected text and individually displayed the matching rendered image.

BBJ21 printed 651–652 finishes the bibliography and author details. The original strong openness input is Guan–Zhou, Annals 182 (2015), 605–616, DOI 10.4007/annals.2015.182.2.5. The analytic point-centered valuation construction cites Jonsson–Mustata, AIF 62 (2012), 2145–2209, DOI 10.5802/aif.2746. RWN14 is Ross–Witt Nystrom, Analytic test configurations and geodesic rays, JSG 12 (2014), 125–169, DOI 10.4310/JSG.2014.v12.n1.a5. No separate correction or additional proof appears after Appendix B. This completes actual ordered full-text and individual-image reading of all 48 physical pages of this exact BBJ21 published author offprint, including appendices and references. Completeness is for this pinned PDF only and does not recursively certify the cited papers, different arXiv editions, or the entire book.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
