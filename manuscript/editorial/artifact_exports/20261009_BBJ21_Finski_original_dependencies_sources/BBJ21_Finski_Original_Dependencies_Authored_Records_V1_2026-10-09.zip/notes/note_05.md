# Original maximal-ray/extension dependency review — view 5

Source: BBJ21_JAMS2021. Physical pages: [9, 10].

Read the complete selected text and individually displayed the matching rendered image.

Printed 613–614 prove weak L1 continuity of psh paths using convexity, the max identity and local-uniform L1 convergence/Fubini; the endpoint geodesic is the envelope of dominated psh paths. Theorem 1.7 uses bounded barriers, decreasing endpoint truncations, monotone energy and the finite-energy limsup criterion, then ordered energy strictness for uniqueness. Two literal source diagnostics are visible in the matched image. First, the final proof paragraph of Proposition 1.5 reverses former/latter cases: if {t:E(U_t)=-infinity} is empty, all U_t belong to E1 and their energies are finite; U_t=0 is an immediate calibration. The intended all-or-none proposition survives after swapping these cases. Second, Lemma 1.6's displayed fiber-integral formula lacks a factor 1/(n+1) under the preceding E and V conventions: for a spatially constant smooth nonaffine psh path U=f(t), E(U)=f, whereas expanding (p1-star omega0+ddc f)^(n+1) and integrating gives (n+1)V ddc f. In dimension one this is a factor two. The factor is positive, so the subsequent convexity and zero-curvature criterion are unaffected; this diagnoses the literal identity, not a counterexample to Theorem 1.7. The full proof and corresponding rendering were actually read. External BK07 and pluripotential regularization/maximality inputs retain their own gates.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
