# Original maximal-ray/extension dependency review — view 26

Source: Finski_metric_structure_arxiv_v2. Physical pages: [3, 4].

Read the complete selected text and individually displayed the matching rendered image.

Finski metric-structure physical pages 3–4 define projective, injective, Hermitian tensor and quotient norms separately. Theorem 1.1 requires smooth positive h and both degrees beyond a threshold; its L2 quotient-to-target ratio is calibrated by (kl/(k+l))^{n/2}. The L1 comparison retains fixed dimension constants, while the L-infinity comparison uses the injective tensor quotient. The claimed sensitivity to tensor norms should not be erased by an arbitrary-dimensional equivalence estimate. The continuous-psh class H_L uses the Bedford–Taylor measure c1(L,h)^n/n!, and its L1/L2/L-infinity equivalence is imported from BBWN [5]. Equivalence of graded norms means d_infinity(N_k,N'_k)/k tending to zero, not unnormalized uniform equality. Multiplicatively generated Hermitian norms satisfy a single sublinear error function for every number r of tensor factors and all sufficiently large constituent degrees, including sum_j f(k_j)+f(k); a two-factor estimate alone is weaker. Later characterization proofs are not covered by these definition pages.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
