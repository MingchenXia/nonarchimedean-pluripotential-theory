# Original maximal-ray/extension dependency review — view 8

Source: BBJ21_JAMS2021. Physical pages: [15, 16].

Read the complete selected text and individually displayed the matching rendered image.

Printed 619–620 state entropy sublevel compactness only on sup-normalized E1, with the klt reference measure and the cited BBEGZ theorem. Theta-entropy growth is a lower bound H_theta-AJ-B and does not itself give a common pointwise lower bound for potentials. The probability dual formulas distinguish L_theta's entropy infimum from the pluricomplex dual energy E-mean; M_theta=Ent_theta(MA(u))-E-dual(MA(u)) is evaluated at a finite-energy MA measure, so its energy term is finite. Lemma 2.15 uses MA surjectivity onto finite-energy measures and the finite-entropy-to-finite-energy input when comparing general probabilities, retaining control of extended values instead of subtracting two infinities. Its coercivity transfer uses epsilon in (0,1), the separate Ding scaling estimate and normalization of the reference-volume mean; semipositive theta is needed for geodesic convexity. Theorem 2.16 begins with translation invariance, lsc, geodesic convexity and theta-entropy growth for klt theta, whose completion is on the next pages. The complete text, normalizations, finite/extended-value distinctions and matching image were actually reviewed. External entropy compactness, Chen–Tian estimates and Ding/convexity results are not independently certified by this reading.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
