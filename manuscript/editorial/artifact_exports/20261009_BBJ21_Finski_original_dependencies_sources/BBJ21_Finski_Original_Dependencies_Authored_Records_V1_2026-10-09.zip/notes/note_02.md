# Original maximal-ray/extension dependency review — view 2

Source: BBJ21_JAMS2021. Physical pages: [3, 4].

Read the complete selected text and individually displayed the matching rendered image.

Printed pages 607–608 retain the smooth-underlying-variety premise in the source's log Fano manifold definition: Theorem B relates a unique twisted KE current, existence with finite automorphism group, and uniform log K-stability. The stability threshold is the divisorial infimum A_theta/S_L, with basis divisor normalized by 1/(m N_m), and log canonical thresholds likewise use the stated valuations. Theorem C gives beta_theta=min(delta_theta,s_theta) for semipositive klt theta without the earlier cohomological equality. Its definition of the Ricci inequality requires a smooth semipositive remainder, not an unrestricted current inequality. The Ding setup uses a probability measure and -1/2 log integral exp(-2u); these log-length conventions must be reconciled with logarithm-of-squares potentials before any book transfer. The introductory proof strategy relies on Darvas completeness, entropy compactness and convexity, and the algebraic-ray correspondence is initially for normal ample test configurations and rays with algebraic singularities emanating from zero. The cited external results and promised later proofs remain source obligations. Both full texts and matching rendered pages were reviewed without a layout defect.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
