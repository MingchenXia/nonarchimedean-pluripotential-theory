# Original maximal-ray/extension dependency review — view 1

Source: BBJ21_JAMS2021. Physical pages: [1, 2].

Read the complete selected text and individually displayed the matching rendered image.

The first page identifies the actual JAMS publisher offprint: volume 34(3), July 2021, printed 605–652, DOI 10.1090/jams/964, electronically published 1 April 2021. This is a distinct 48-page published layout from the locally held forty-page arXiv v3; no old receipt is reused. The contents place finite-energy geodesics at 611, valuations at 622, ray/Lelong interfaces at 625 and NA finite energy/maximal rays at 631. The introduction retains smooth projective X, ample Q-line bundle L and closed quasi-positive theta. Theorem A uses semipositive klt theta and c1(X,theta)=c1(L): existence gives Ding semistability, uniqueness strengthens it to uniform Ding stability, while the converse is uniform stability to existence. Additional uniqueness in the converse retains the stated mild technical singularity condition and later Corollary 5.2. The negative/zero lambda discussion has separate klt assumptions, and no broad singular-X theorem is inferred. Both complete texts and the matching rendered pages, including publication/footer information, were actually reviewed; this view identifies the source and setup without certifying the later proofs.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
