# Original maximal-ray/extension dependency review — view 31

Source: Finski_metric_structure_arxiv_v2. Physical pages: [13, 14].

Read the complete selected text and individually displayed the matching rendered image.

Finski metric-structure physical pages 13–14 defines FS(N_k) as a squared Hermitian metric on L^k and Lemma 2.14 gives sum_i |s_i|^2_FS=1. Consequently if rho_k is the section-length evaluation operator norm in (2.34), the identity (2.33) should read FS(Hilb_k(h))/(h^k)=rho_k^{-2}, rather than rho_k. The intended logarithmic uniform convergence in Theorem 2.15 survives the inverse and factor two because |log rho_k|/k tends uniformly to zero. A scalar rescaling of a one-dimensional norm makes this calibration transparent; no failure of the intended quantization theorem is claimed. Lemma 2.17 needs a nonzero section and a uniform point-extension constant across x; a bare application of Theorem 2.5 with fixed Y={x} does not by itself state that uniformity. Compactness plus uniformly controlled point-extension constructions is an additional step to retain. In the proof, mu should be chosen as a positive smooth volume measure; boundedness from above alone is insufficient for the reverse Bernstein–Markov comparison (2.36). The source's earlier Proposition 2.10 supplies the needed lower bound for a smooth positive mu. Later multiplication and classification proof pages 15–46 remain outside the present selected reading.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
