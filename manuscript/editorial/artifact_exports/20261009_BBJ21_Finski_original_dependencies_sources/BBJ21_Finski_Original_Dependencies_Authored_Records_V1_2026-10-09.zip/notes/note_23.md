# Original maximal-ray/extension dependency review — view 23

Source: BBJ21_JAMS2021. Physical pages: [45, 46].

Read the complete selected text and individually displayed the matching rendered image.

BBJ21 printed 649–650 gives exact original dependency versions: BoJ18a is Singular semipositive metrics on line bundles on varieties over trivially valued fields, arXiv:1801.08229v1 (2018); BoJ18b is A non-Archimedean approach to K-stability, arXiv:1805.11160v1 (2018). These are different papers and should not be collapsed into a generic BJ22 citation without tracing the particular theorem and edition. BFJ15 is JAMS 28 (2015), 617–667, DOI 10.1090/S0894-0347-2014-00806-7; BFJ16 is JAG 25 (2016), 77–139, DOI 10.1090/jag/656. The complex asymptotic slope source BHJ19 is JEMS 21 (2019), 2905–2944, DOI 10.4171/JEMS/894. Regularization uses BK07, PAMS 135 (2007), 2089–2093. The supplied Darvas references distinguish the 2015 finite-energy Mabuchi geometry from the 2017 weak-ray and completion papers. Reading this bibliography verifies identification and stated editions only, not those external proofs or any later corrigendum.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
