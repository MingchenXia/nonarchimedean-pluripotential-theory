# Original maximal-ray/extension dependency review — view 6

Source: BBJ21_JAMS2021. Physical pages: [11, 12].

Read the complete selected text and individually displayed the matching rendered image.

Printed 615–616 characterize psh geodesics by strong continuity, psh interior lift and affine energy, rather than by an arbitrary d1-geodesic condition. Proposition 1.10 uses the stated one-sided endpoint singularity order and the envelope competitor to prove affine relative supremum. The Darvas metric has the ordered identity d1(u,v)=E(u)-E(v) for u>=v and d1(u,0)=-E(u) only with sup normalization; constants are not discarded automatically. The text explicitly says not every metric geodesic is psh. In Proposition 1.11 pointwise convergence means convergence of the maps at each time in the default strong E1 topology, not merely pointwise convergence on X. Endpoint metric convergence controls speeds and equicontinuity, then strong energy convergence supplies affine energy and the earlier path-closure result supplies psh membership. The Ricci setup uses local density exp(-2f)i^(n^2)Omega wedge conjugate, f=log|Omega|_h, and Ric_theta=Ric-theta, with finite-energy MA and locally integrable metric density required in Definition 2.1. These norm/sign/mass conventions remain explicit source hypotheses. Both complete texts and matching image were reviewed; cited Darvas completion and Finsler results remain external dependencies.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
