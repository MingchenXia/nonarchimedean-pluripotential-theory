# Original maximal-ray/extension dependency review — view 14

Source: BBJ21_JAMS2021. Physical pages: [27, 28].

Read the complete selected text and individually displayed the matching rendered image.

Printed 631–632 establish the energy inequality E(phi_m)>=the complex energy slope by directing an algebraic ray above U and applying ordered energy, explicitly allowing strict inequality (Example 6.10). The stability contradiction uses the ray emanating from 0, sup normalization, c<0 and epsilon in (0,1); this is the origin-zero case for which the earlier compactness proof's speed/normalization bookkeeping is direct. Its final c>=(1-epsilon)c is contradictory for c<0. Theorem-B automorphism argument retains the external transitivity/compact-stabilizer facts and smooth log Fano scope. Section 6 begins the canonical NA extension on complex projective X: X_NA includes semivaluations supported on subvarieties, rational divisorial valuations plus v_triv are dense, and Gauss extension has w(tau)=1. HNA flag functions extend continuously; PSHNA is defined by decreasing HNA sequences, with usc, maximum at v_triv, finite divisorial values and uniqueness from those values attributed to BoJ18a/BFJ16. These are canonical psh framework inputs, not facts of an arbitrary raw pointwise FS supremum. Lemma 6.1 begins the globally-generated-ideal construction with mL required to be an actual line bundle. The full proof and the original cited edition identities remain ahead. Both complete texts and corresponding rendered pages were actually read; the constant-mass, degree and canonical representative gates are retained.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
