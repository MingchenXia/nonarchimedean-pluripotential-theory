# Original maximal-ray/extension dependency review — view 4

Source: BBJ21_JAMS2021. Physical pages: [7, 8].

Read the complete selected text and individually displayed the matching rendered image.

Printed 611–612 set the preliminary theory on an n-dimensional compact Kähler manifold with fixed omega0. MA(u)=omega_u^n/V is explicitly a probability measure, E(0)=0 and E(u+c)=E(u)+c; formula (1.1) retains 1/((n+1)V). The extension is monotone usc, taking infima of energies of smooth upper majorants, and E1 means finite energy. The strong topology is weak L1 plus energy continuity, not pointwise convergence alone. Lemma 1.2 gives its limsup-pointwise/energy criterion and uses the cited J_u criterion and reverse Fatou for an upper-bounded psh family; finiteness of mixed integrals remains an external finite-energy input. In complex dimension one the Sobolev characterization is a source specialization. The psh-path definition uses the S1-invariant lift on X times the annulus/punctured disc with t=-log|tau| and p1-star omega0 positivity. This parameter must not be silently identified with logarithm-of-squares time. Both complete texts and their matching render were read; the BK07 approximation and BBGZ/BBEGZ integrability/topology facts are retained as original cited inputs rather than recursively certified.

Scope: actual fresh reading of these two selected primary pages only. No new book reading, original theorem promotion or recursive external-proof certification.
