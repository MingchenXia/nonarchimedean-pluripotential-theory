from pathlib import Path
from datetime import datetime, timezone
from fractions import Fraction
from itertools import product
from math import comb
import hashlib, json

R=Path('/workspace/nonarchimedean-pluripotential-theory')
K=R/'source_material/Hultberg_GVF_dependency_review_20261009/LuoYu25ArxivV3'
W=Path('/tmp/Luo_Yu_primary_views_v1_20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
def write(p,j):
    assert not p.exists()
    p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
prep=json.loads((K/'scope_preparation_v1_20261009.json').read_text())
assert sha(prep['PDF'])==prep['PDF_SHA256']=='95b2b64d3e710ba83f497109f9251d44ad82c74b67e2696c327f3d54c9753b71'
rows=[]; pages=[]; previous_time=None
for n,x in enumerate(prep['entries'],1):
    p=K/f'primary_notes_v1/note_{n:02d}.json'; note=K/f'primary_notes_v1/note_{n:02d}.md'
    j=json.loads(p.read_text())
    assert j['number']==n and j['physical_pages']==x['physical_pages']
    assert j['complete_text_actually_read'] and j['matching_image_actually_viewed']
    assert j['PDF_SHA256']==prep['PDF_SHA256'] and sha(note)==j['note_SHA256']
    assert sha(x['text_path'])==j['text_SHA256'] and sha(x['image_path'])==j['image_SHA256']
    assert previous_time is None or j['UTC']>previous_time
    previous_time=j['UTC']
    rows.append(dict(path=str(p),SHA256=sha(p),physical_pages=j['physical_pages'],note_SHA256=sha(note)))
    pages+=j['physical_pages']
assert pages==list(range(1,32)) and len(rows)==16
extra=dict(UTC=now(),status='ACTUAL REPEATED COMPLETE-TEXT/IMAGE INSPECTION — source scope clarification',physical_pages=[3,4],PDF_SHA256=prep['PDF_SHA256'],image_SHA256=sha(W/'sheet_02.png'),text_SHA256=sha(W/'sheet_02.txt'),additional_unique_source_pages=0,
    clarifications=[
        'Page 4 explicitly defines generation as Z pi(X) being Zariski dense. The preliminary ambiguity flagged in note 12 is resolved by this primary definition; a torsion point is excluded.',
        'Page 5 explicitly assumes algebraically closed k; the preliminary merely-relatively-closed constant-field concern is outside the source working hypotheses.',
        'Example 1.2 on page 3 uses a non-torsion y over C. Its word non-triviality must retain this stronger non-torsion premise for all algebraic points.',
        'The finite-field application has the algebraic-closure overbar visible in the image; plain-text extraction omits it.'
    ],original_results_promoted=[],helper_source=__file__,helper_SHA256=sha(__file__))
add=K/'repeat_source_scope_clarifications_v1_20261009.json';write(add,extra)
matrices=[[[1],[1]],[[1,0,0],[1,1,0],[1,0,1]],[[2,0],[2,1]]]
checks=[]; witnesses=[]
for A in matrices:
    t=len(A[0]); row=max(sum(abs(a) for a in v) for v in A)
    col=max(sum(abs(A[i][j]) for i in range(len(A))) for j in range(t))
    count=0
    for u in product(range(-5,6),repeat=t):
        h=2*sum(abs(x) for x in u)
        image=[sum(a*x for a,x in zip(v,u)) for v in A]
        target=2*sum(abs(x) for x in image)
        assert target<=col*h;count+=1
    u=[1]+[0]*(t-1);h=2;target=2*sum(abs(v[0]) for v in A)
    assert target>row*h
    witnesses.append(dict(matrix=A,source_exponents=u,source_height=h,target_height=target,printed_row_coefficient=row,correct_column_coefficient=col,printed_inequality_fails=True))
    checks.append(dict(matrix=A,exact_integer_height_cases=count))
normalization=[]
for q,r,DY,DF,h in product(range(5),range(6),[1,2,3,7],[1,2,5],[-3,0,2]):
    raw=Fraction((r+1)*DY*DF*h)
    recovered=raw/Fraction((r+1)*DY*DF)
    assert recovered==h
    normalization.append(dict(q=q,r=r,degree_Y=DY,degree_fibre=DF,normalized_height=h,raw=str(raw),printed_without_r_plus_one=str(Fraction(DY*DF*h))))
ratios=[]
for d in range(17):
    for e in range(d+1):
        assert Fraction(comb(d+1,e),(d+1)*comb(d,e))==Fraction(1,d+1-e)
        ratios.append(dict(d=d,e=e,required_geometric_M_exponent=d-e,printed_geometric_M_exponent=1,ratio=str(Fraction(1,d+1-e))))
sequences=[]
for n,a in product(range(1,65),[3,4,7]):
    generic_degree=2*n;intersection=2*a
    assert Fraction(intersection,generic_degree)==Fraction(a,n)>0
    sequences.append(dict(n=n,base_divisor_degree=a,point_degree=generic_degree,M_intersection=intersection,height=str(Fraction(a,n))))
cal=dict(UTC=now(),status='PASS — exact classical/formal diagnostics, not a main-proof certificate',
    operator_norm_cases=checks,operator_norm_total_cases=sum(x['exact_integer_height_cases'] for x in checks),literal_operator_norm_witnesses=witnesses,
    relative_height_normalization_cases=normalization,relative_height_normalization_case_count=len(normalization),
    binomial_normalization_cases=ratios,binomial_normalization_case_count=len(ratios),
    arithmetic_exponent_checks=[dict(d=d,required_full_power=d+1,printed_full_power=d,required_divisor_power=d,printed_divisor_power=d-1) for d in range(1,13)],
    rank_two_curve_sequence_cases=sequences,rank_two_curve_sequence_case_count=len(sequences),
    finite_checks_replace_general_argument=False,geometric_main_statement_refuted=False,number_field_main_statement_refuted=False,
    original_results_promoted=[],independent_verifier_receipt=False,helper_source=__file__,helper_SHA256=sha(__file__))
cp=K/'literal_exact_calibrations_v1_20261009.json';write(cp,cal)
checkpoint=dict(UTC=now(),status='ENTIRE31-PAGE SOURCE ACTUALLY READ — ordinary source audit with explicit proof qualifications',
    PDF_SHA256=prep['PDF_SHA256'],current_version='2505.07193v3',arxiv_submission_date='2025-08-28',PDF_internal_final_date='2025-08-29',
    physical_pages_read=pages,matching_complete_text_image_views=16,reading_receipts=rows,full_source_read=True,
    repeated_pages=[3,4],repeated_pages_add_unique_credit=0,scope_clarification_SHA256=sha(add),calibrations_SHA256=sha(cp),
    preliminary_constant_and_generation_concerns_resolved=True,
    general_geometric_and_number_field_results='UNVERIFIED for book import; complete reading is not complete reconstruction or recursive certification',
    Example_1_2='Eligible imported worked-case candidate subject to complete model-height and integration checks',
    main_statement_refuted=False,primary_dependencies_recursively_read=False,original_results_promoted=[],independent_verifier_receipt=False,
    book_changed=False,native_editor_changed=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__))
p=K/'actual_complete_source_checkpoint_v1_20261009.json';write(p,checkpoint)
print(json.dumps(dict(source_pages=31,matching_views=16,checkpoint_SHA256=sha(p),calibrations_SHA256=sha(cp),operator_norm_cases=cal['operator_norm_total_cases'],relative_normalization_cases=len(normalization),binomial_cases=len(ratios),rank_two_curve_sequence_cases=len(sequences))))
