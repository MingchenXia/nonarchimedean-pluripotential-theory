from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile,shutil

R=Path('/workspace/nonarchimedean-pluripotential-theory');E=R/'manuscript/editorial'
K=R/'source_material/Hultberg_GVF_dependency_review_20261009/LuoYu25ArxivV3'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cp=K/'actual_complete_source_checkpoint_v1_20261009.json';checkpoint=json.loads(cp.read_text())
assert checkpoint['physical_pages_read']==list(range(1,32)) and checkpoint['matching_complete_text_image_views']==16
assert checkpoint['full_source_read'] and not checkpoint['book_changed']
sourcezip=K/'Luo_Yu_Complete_Source_Evidence_V1_2026-10-09.zip'
record=K/'complete_evidence_export_v1_20261009.json'
dest=E/'artifact_exports/20261009_Luo_Yu_complete_v1'
paths={k:E/f'Luo_Yu_complete_source_{k}_v1_20261009.{ext}' for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in [sourcezip,record,dest,*paths.values()])
review=K/'own_complete_source_review_v1_20261009.md';proof=K/'own_rank_two_curve_height_reconstruction_v1_20261009.md'
assert len(review.read_text())>5000 and len(proof.read_text())>3000
files={}
for n in ['source_acquisition_v1_20261009.json','scope_preparation_v1_20261009.json','repeat_source_scope_clarifications_v1_20261009.json','actual_complete_source_checkpoint_v1_20261009.json','literal_exact_calibrations_v1_20261009.json','own_complete_source_review_v1_20261009.md','own_rank_two_curve_height_reconstruction_v1_20261009.md']:
    files['records/'+n]=K/n
notes=[]
for i,row in enumerate(checkpoint['reading_receipts'],1):
    receipt=Path(row['path']);note=K/f'primary_notes_v1/note_{i:02d}.md'
    assert sha(receipt)==row['SHA256'] and sha(note)==row['note_SHA256']
    files['actual_notes/'+note.name]=note;files['actual_receipts/'+receipt.name]=receipt
    notes.append(note.read_text())
helpers=['/tmp/Luo_Yu_prepare_source_views_v1_20261009.py','/tmp/Luo_Yu_record_source_note_v1_20261009.py','/tmp/Luo_Yu_record_complete_source_and_calibrations_v1_20261009.py',__file__]
for p in helpers:
    q=Path(p);files['helpers/'+q.name]=q
assert all(q.suffix in ['.md','.json','.py'] for q in files.values())
with zipfile.ZipFile(sourcezip,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,p in sorted(files.items()):z.write(p,n)
with zipfile.ZipFile(sourcezip) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(files) and z.testzip() is None
    for n,p in files.items():assert z.read(n)==p.read_bytes()
artifact=dict(path=str(sourcezip),bytes=sourcezip.stat().st_size,SHA256=sha(sourcezip),members=len(files))
paths['review'].write_text(review.read_text().rstrip()+'\n')
paths['reading_notes'].write_text(('# Actual complete Luo–Yu source reading\n\nAll 31 physical pages in sixteen ordered matching complete-text/image views.\nPreparation flags are historical; these notes and receipts carry actual credit.\n'+''.join('\n---\n\n'+x for x in notes)).rstrip()+'\n')
manifest=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete primary-source reading with proof qualifications',source_checkpoint=checkpoint,source_checkpoint_SHA256=sha(cp),authored_classical_model_reconstruction=dict(path=str(proof),SHA256=sha(proof),imported_worked_case=True,new_result=False),source_review_SHA256=sha(review),evidence=artifact,primary_full_text_and_images_and_PDFs_excluded=True,book_changed=False,GitHub_published=False,canonical_status_changes=[])
paths['manifest'].write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — byte-verified authored source evidence',evidence=artifact,reading_credit_from_export=0,GitHub_published=False,canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
dest.mkdir(parents=True);shutil.copyfile(sourcezip,dest/sourcezip.name);assert sha(dest/sourcezip.name)==sha(sourcezip)
(dest/'SHA256SUMS').write_text(sha(sourcezip)+'  '+sourcezip.name+'\n')
(dest/'README.md').write_text(('# Luo–Yu complete-source authored evidence\n\n'+review.read_text()+f'\nThe {len(files)}-member archive contains authored notes, actual receipts,\nexact diagnostics, scope clarifications, the classical rank-two curve\nreconstruction and helpers. It excludes primary PDFs, full source text\nand primary-source images. Every member was extracted and byte-verified.\nExport/upload gives no source-reading or theorem-clearance credit.\n').rstrip()+'\n')
editorial={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in [*paths.values(),*dest.iterdir()]}
assert len(editorial)==7
out=dict(UTC=datetime.now(timezone.utc).isoformat(),status='EXPORTED — own complete source evidence, remote verification pending',source_checkpoint_SHA256=sha(cp),evidence=artifact,editorial_files=editorial,member_hashes={n:sha(p) for n,p in sorted(files.items())},book_PDF_SHA256=sha(R/'manuscript/book.pdf'),book_pages=4681,actual_primary_pages=31,matching_views=16,original_results_promoted=[],canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__))
record.write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(evidence_members=len(files),evidence_SHA256=sha(sourcezip),export_SHA256=sha(record),editorial_files=len(editorial))))
