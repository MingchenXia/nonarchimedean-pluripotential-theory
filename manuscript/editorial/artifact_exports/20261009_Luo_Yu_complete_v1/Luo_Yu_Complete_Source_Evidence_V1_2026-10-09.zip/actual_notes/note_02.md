# Actual Luo–Yu v3 source reading, physical pages3–4

Read the complete selected text and displayed matching rendered image of
physical pages3–4, in order. This completes the stabilizer definition,
full Theorem1.1, Example1.2, application and entire proof outline.

The statement quotients by the connected stabilizer and describes an image
of a constant semiabelian variety under a finite-kernel homomorphism plus
a torsion point. Its full proof remains unread. Preserve the exact base-field
language from page1; descent to the stated constant field needs inspection
in the later proof before any book import. In the image the application uses
the algebraic closure of the finite field; the plain extracted text loses its
overbar and must not control that hypothesis.

Example1.2 uses k=C, a constant elliptic curve and a Poincare extension.
A non-torsion constant y gives a ruled model with boundary bundle
2O(1)-f*P_y. Exact zero height is confined to the two boundary sections,
whereas the open torsor fiber is special. Non-torsion is stronger than mere
nontriviality: finite-cover pullback of a torsion line bundle can trivialize
it, so a complete all-algebraic-point explanation must retain the chosen
non-torsion y. This example's details are a further direct height target,
not a newly verified original counterexample.

The relative Faltings–Zhang outline explicitly assumes geometrically
irreducible generic fiber before asserting generic finiteness. That condition
matters for the separate Hultberg component/image diagnosis. The outline's
initial direction label (b)=> (a) describes reductions starting with small
points; the complete later proof must settle the direction. Only pages1–4
of31 are actually read; main theorem and deeper dependencies are not cleared.
