# Actual Luo–Yu v3 source reading, physical pages1–2

Read the complete selected text and displayed matching rendered image of
physical pages1–2, in order. This covers the full abstract, the initial
function-field/polarization setup, historical statements and the beginning
of the split-torus semiabelian height construction; the stabilizer definition
continues on page3 and has not yet been read completely.

K/k is finitely generated with k algebraically closed in K, equipped with a
normal projective model and ample base polarization. Classical abelian GBC
is cited at Xie–Yuan; this does not supply arbitrary-GVF GBC. The semiabelian
boundary height is linear under multiplication, while the abelian canonical
height is quadratic; their sum is the specified L-height. The compactification
is the fiber product of P(O plus Q_i dual), and must not be silently identified
with Chambert–Loir's different compactification. The abstract distinguishes
dense arbitrarily small points from dense points of exact height0. Main theorem
statement and proof are still unread and unverified for book import. Controlling
version is2505.07193v3,28August2025,31 physical pages; this reads two pages.
