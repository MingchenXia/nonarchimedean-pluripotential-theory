from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

R=Path('/workspace/nonarchimedean-pluripotential-theory');M=R/'manuscript';E=M/'editorial'
C=R/'source_material/Truong_relative_Hessian_review_20261008'
B=Path('/workspace/book-completion-drafts/higher-rank-abeloid-staging-v2-20261008')
out=C/'source_checkpoint_v1_20261008.json';assert not out.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths={k:E/f'Truong_relative_Hessian_{k}_20261008.{ext}' for k,ext in [('source_review','md'),('source_reading_notes','md'),('source_reading_manifest','json'),('source_artifacts','json')]}
assert paths['source_review'].exists() and not any(p.exists() for k,p in paths.items() if k!='source_review')
actual=C/'actual_primary_reading_v1_20261008.json';diag=C/'exact_diagnostics_v2_20261008.json'
assert sha(actual)=='b6cf6d16b2e984264ea7dd2e3d56485393ad8aad38d373500e07be79d4ef5ea6'
assert sha(diag)=='7ec956bea0aefbc0d70b55c17cf46bff4aee5d88ed1ec7a2ed4b2820ba605de8'
a=json.loads(actual.read_text());assert a['actual_read_pages']==list(range(1,27))
notes='# Actual sequential relative Hessian arXiv v1 source notes, 8 October 2026\n\nAll 26 pages in thirteen individually displayed matching views. The controlling source is arXiv:2609.12032v1, 10 September 2026. No general theorem is imported. The extraction font warning and exact literal boundary/mass diagnostics remain recorded. External bibliography proofs are not recursively certified.\n'
for n in a['actual_observations']:notes+='\n---\n\n'+Path(n['note_path']).read_text()
paths['source_reading_notes'].write_text(notes)
core=set()
for line in (M/'book.fls').read_text().splitlines():
 if line.startswith('INPUT '):
  p=Path(line[6:]);p=(p if p.is_absolute() else M/p).resolve()
  if p.is_relative_to(M) and p.suffix=='.tex':core.add(p)
assert len(core)==425;core.update((M/'bibliography').glob('*.bib'));assert len(core)==427
for p in core:assert sha(p)==sha(B/p.relative_to(R)),str(p)
core.update([M/'book.pdf',R/'output/open_problems_catalogue_2026-10-03.tex',R/'output/open_problems_catalogue_2026-10-03.pdf'])
protected={str(p):sha(p) for p in sorted(core)}
assert sha(M/'book.pdf')=='4178a551f52b71e59f1f8bfd87b7ecf8c339970f3d823a1abadd8fae7f592f70'
assert sha(R/'output/open_problems_catalogue_2026-10-03.tex')=='322168dd84419eead17f91403527a5817d6d259f630531f240cdee0619a236c91fc4da'
assert sha(R/'output/open_problems_catalogue_2026-10-03.pdf')=='77989065125a7809e34e4dbe2440855df21447f2c38b79dc3dd6f4a46107353dcb53e2'
manifest=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete primary reading and exact literal diagnostics; general source claims excluded',actual_ledger_path=str(actual),actual_ledger_SHA256=sha(actual),actual_record=a,source_audit_SHA256=sha(paths['source_review']),exact_diagnostic_path=str(diag),exact_diagnostic_SHA256=sha(diag),extraction_warning='Syntax Warning: Mismatch between font type and embedded font file',all_actual_views_readable_and_matching=True,failed_symbolic_branch_attempt_preserved=True,general_relative_Hessian_theorems_admitted=False,external_foundation_proofs_recursively_certified=False,whole_book_new_reading_claim=False,active_book_changed=False,canonical_status_changes=[],GitHub_published=False)
paths['source_reading_manifest'].write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
helpers=sorted(Path('/tmp').glob('Truong_relative_Hessian_*_20261008.py'))
files=[p for name in ['Truong_relative_Hessian_sources_20261008','Truong_relative_Hessian_review_20261008'] for p in (R/'source_material'/name).rglob('*') if p.is_file()]
artifacts=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — cloud source checkpoint before authorized publication',files=[dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p)) for p in sorted(files)],helpers={str(p):sha(p) for p in helpers},editorial_files={str(p):sha(p) for k,p in paths.items() if k!='source_artifacts'},protected_core_inputs=protected,active_TeX_inputs_preserved=425,bibliographies_preserved=2,native_catalogue_preserved=True,book_PDF_preserved=True,external_foundation_proofs_recursively_certified=False,reading_credit_from_exports=0,GitHub_published=False)
paths['source_artifacts'].write_text(json.dumps(artifacts,ensure_ascii=False,indent=2)+'\n')
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — cloud source checkpoint; subsequent publication must have its own record',baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),editorial_files={str(p):sha(p) for p in paths.values()},protected_core_inputs=protected,actual_source_pages=26,actual_images=13,actual_primary_reading_SHA256=sha(actual),exact_diagnostics_SHA256=sha(diag),unqualified_general_relative_Hessian_theorem_admitted=False,active_book_changed=False,GitHub_published=False,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
for p,h in protected.items():assert sha(Path(p))==h
print(json.dumps(dict(status=obj['status'],checkpoint_SHA256=sha(out),editorial_files=len(paths),protected_inputs=len(protected))))
