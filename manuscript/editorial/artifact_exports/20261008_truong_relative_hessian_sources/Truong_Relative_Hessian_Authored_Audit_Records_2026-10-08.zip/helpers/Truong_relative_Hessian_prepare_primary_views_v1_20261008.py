# Frozen adapted primary-preparation helper SHA256: 86f54290157fd2d39256c29dc35ac430f7a7f9ba80e8499a497f6d0ec771aca4
# Frozen full-primary-view template SHA256: 5fa950bd537666b1f8e13e7350f8fac63eb6a5c574c548cdf4bdbc08683168d6
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,fitz
from PIL import Image,ImageDraw
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Truong_relative_Hessian_review_20261008';S=R/'source_material/Truong_relative_Hessian_sources_20261008';W=Path('/tmp/Truong_relative_Hessian_primary_views_v1_20261008');notes=C/'primary_notes_v1';out=C/'primary_view_preparation_v1_20261008.json'
assert not any(p.exists() for p in [W,notes,out]);W.mkdir();notes.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
pdf=S/'Truong_relative_Hessian_arxiv_v1.pdf';assert sha(pdf)=='9b7d92cf183b7e378f44cb57859eb766c23388f217496914d6135496562cf534';doc=fitz.open(pdf);assert len(doc)==26
views=[]
for i in range(0,len(doc),2):
 pages=list(range(i+1,min(i+3,len(doc)+1)));panels=[];texts=[]
 for n in pages:
  pix=doc[n-1].get_pixmap(matrix=fitz.Matrix(1.45,1.45),alpha=False);panels.append(Image.frombytes('RGB',[pix.width,pix.height],pix.samples));texts.append(f'TRUONG RELATIVE HESSIAN 2609.12032v1 PHYSICAL PAGE {n}\n'+doc[n-1].get_text())
 canvas=Image.new('RGB',(sum(p.width for p in panels),max(p.height for p in panels)+28),'white');draw=ImageDraw.Draw(canvas);x=0
 for n,p in zip(pages,panels):draw.text((x+8,8),f'Truong 2609.12032v1 physical page {n}',fill='black');canvas.paste(p,(x,28));x+=p.width
 number=i//2+1;ip=W/f'sheet_{number:02d}.png';tp=W/f'sheet_{number:02d}.txt';canvas.save(ip);tp.write_text('\n\n'.join(texts))
 views.append(dict(number=number,physical_pages=pages,path=str(ip),image_SHA256=sha(ip),selected_text_path=str(tp),selected_text_SHA256=sha(tp),source_PDF_SHA256=sha(pdf),actually_viewed=False,selected_text_read=False))
mp=W/'manifest.json';mp.write_text(json.dumps(views,indent=2)+'\n');obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete-primary view preparation; zero reading credit',source_PDF=dict(path=str(pdf),SHA256=sha(pdf),physical_pages=26),prepared_pages=26,prepared_views=13,manifest_path=str(mp),manifest_SHA256=sha(mp),actual_source_reading_credit=0,actually_read_pages=0,active_book_changed=False,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status=obj['status'],pages=26,views=13,record_SHA256=sha(out))))
