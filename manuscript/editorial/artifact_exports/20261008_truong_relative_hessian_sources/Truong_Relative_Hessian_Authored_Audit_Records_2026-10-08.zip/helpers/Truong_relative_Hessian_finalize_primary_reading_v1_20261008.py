from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R / 'source_material/Truong_relative_Hessian_review_20261008'
W = Path('/tmp/Truong_relative_Hessian_primary_views_v1_20261008')
out = C / 'actual_primary_reading_v1_20261008.json'
assert not out.exists()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
prep = C / 'primary_view_preparation_v1_20261008.json'
expected = 'cac887b975da0a0407d700ea929b3d703aceb44301f734a39f068ccdd08a55f3'
assert sha(prep) == expected
prepared = json.loads(prep.read_text())
assert prepared['actually_read_pages'] == prepared['actual_source_reading_credit'] == 0
manifest = json.loads((W / 'manifest.json').read_text())
assert len(manifest) == 13
assert all(x['actually_viewed'] is False and x['selected_text_read'] is False for x in manifest)
notes, pages, times = [], [], []
for i, row in enumerate(manifest, 1):
    p = C / 'primary_notes_v1' / f'note_{i:02d}_receipt.json'
    n = json.loads(p.read_text())
    assert n['number'] == i and n['physical_pages'] == row['physical_pages']
    assert n['source_PDF_SHA256'] == prepared['source_PDF']['SHA256']
    assert n['complete_selected_text_actually_read'] and n['matching_image_individually_displayed_and_reviewed']
    for path_key, hash_key in [('note_path', 'note_SHA256'), ('image_path', 'image_SHA256'), ('selected_text_path', 'selected_text_SHA256')]:
        assert sha(Path(n[path_key])) == n[hash_key]
    notes.append(dict(receipt_path=str(p), receipt_SHA256=sha(p), **n))
    pages.extend(n['physical_pages']); times.append(n['UTC'])
assert pages == list(range(1, 27)) and times == sorted(times)
assert sha(R / 'manuscript/book.pdf') == '4178a551f52b71e59f1f8bfd87b7ecf8c339970f3d823a1abadd8fae7f592f70'
obj = dict(status='DONE — complete pinned 26-page primary read in 13 matching individual views and sequential notes', UTC=datetime.now(timezone.utc).isoformat(), source_PDF=prepared['source_PDF'], actual_distinct_source_page_pairs=26, actual_matching_images=13, actual_sequential_notes=13, actual_read_pages=pages, actual_observations=notes, preparation_record_SHA256=sha(prep), prepared_flags_preserved=True, extraction_warning_preserved=True, all_image_text_pairs_readable_with_no_detected_content_loss=True, general_relative_Hessian_theorems_admitted=False, external_foundation_proofs_recursively_certified=False, independent_model_receipt_claimed=False, canonical_status_changes=[], active_book_changed=False, last_whole_book_pass='2026-10-04', reading_credit_from_exports_or_uploads=0, helper_source=__file__)
out.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(status=obj['status'], record_SHA256=sha(out), pages=26, images=13)))
