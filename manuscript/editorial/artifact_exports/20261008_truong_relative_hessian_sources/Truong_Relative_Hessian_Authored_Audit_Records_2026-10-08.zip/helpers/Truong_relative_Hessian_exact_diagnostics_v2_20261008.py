# Frozen failed v1 helper SHA256: 17eb413d1a620fcbe804a649d45aaafacde8abb705830d0d1ffd8a16e2901e6e
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json
import sympy as S

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R / 'source_material/Truong_relative_Hessian_review_20261008'
out = C / 'exact_diagnostics_v2_20261008.json'
assert not out.exists()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
s, eps, t, c = S.symbols('s eps t c', positive=True)
psi = s - 2
fixtures = {'u': S.Integer(-3), 'v': psi - 1, 'w': psi - 2}
def radial_hessian_density(f): return S.simplify(S.diff(s * S.diff(f, s), s))
def disk_integral(f): return S.simplify(2 * S.integrate(f, (s, 0, 1)))
rows = {}
for name, f in fixtures.items():
    q = radial_hessian_density(f)
    energy = disk_integral((f - psi) * (q + 1) / 2)
    mass = disk_integral(q)
    rows[name] = dict(function=str(f), difference_from_reference=str(S.expand(f-psi)), relative_bound=2 if name in ['u','w'] else 1, Hessian_density_relative_to_beta=str(q), total_mass=str(mass), signed_energy=str(energy), strictly_decreasing_approximant=str(f+1/S.Symbol('j',positive=True)), approximant_energy=str(S.simplify(energy+(mass+2)/(2*S.Symbol('j',positive=True)))))
assert [rows[n]['total_mass'] for n in fixtures] == ['0', '2', '2']
assert [rows[n]['signed_energy'] for n in fixtures] == ['-3/2', '-2', '-4']
assert S.simplify(fixtures['v'] - fixtures['u']) == s
assert S.simplify(fixtures['v'] - fixtures['w']) == 1
path = -3 + t*(s+1)
path_energy = disk_integral((path-psi)*(radial_hessian_density(path)+1)/2)
assert S.simplify(path_energy-S.Rational(3,2)*(t**2-1)) == 0
assert S.diff(path_energy,t,2) == 3

alpha = S.Rational(3,4)
h = -(1-s+eps)**alpha + eps**alpha
hp, hpp = S.diff(h,s), S.diff(h,s,2)
assert S.simplify(hp-alpha*(1-s+eps)**(alpha-1)) == 0
assert S.simplify(hpp-alpha*(1-alpha)*(1-s+eps)**(alpha-2)) == 0
mass = S.simplify(2 * (s*S.diff(psi+h,s)).subs(s,1) - 2*S.limit(s*S.diff(psi+h,s),s,0,dir='+'))
assert S.simplify(mass-(2+S.Rational(3,2)*eps**(-S.Rational(1,4)))) == 0
gradient_integral = S.Rational(4,3)*(1+eps)**S.Rational(3,2)-2*S.sqrt(eps)-S.Rational(4,3)*eps**S.Rational(3,2)
primitive = -2*(1+eps)*S.sqrt(1-s+eps)+S.Rational(2,3)*(1-s+eps)**S.Rational(3,2)
assert S.simplify(S.diff(primitive,s)-s*(1-s+eps)**(-S.Rational(1,2))) == 0
assert S.simplify(primitive.subs(s,1)-primitive.subs(s,0)-gradient_integral) == 0
reference_term = -2*(((1+eps)**(alpha+1)-eps**(alpha+1))/(alpha+1)-eps**alpha)
energy = reference_term - alpha**2*gradient_integral
limit_energy = S.limit(energy,eps,0,dir='+')
assert limit_energy == -S.Rational(53,28)
assert alpha**2*S.integrate(s*(1-s)**(2*alpha-2),(s,0,1)) == S.Rational(3,4)
assert S.limit(mass,eps,0,dir='+') == S.oo
boundary_product = S.simplify((h*s*hp).subs(s,1))
assert boundary_product == 0
limit_mass_on_radius = 2*s*(1+alpha*(1-s)**(alpha-1))
assert S.limit(limit_mass_on_radius.subs(s,1-eps),eps,0,dir='+') == S.oo
samples=[]
for j in [1,2,4,16,256,65536]:
    e = S.Rational(1,j)
    val=S.N(energy.subs(eps,e),20)
    assert 0 > val > -S.Rational(11,4)
    samples.append(dict(j=j, epsilon=str(e), total_mass=str(S.simplify(mass.subs(eps,e))), signed_energy_decimal=str(val)))

obj = dict(status='DONE — exact elementary diagnostics of the pinned literal definitions and selected statements',UTC=datetime.now(timezone.utc).isoformat(),source_arxiv_version='2609.12032v1',source_PDF_SHA256='9b7d92cf183b7e378f44cb57859eb766c23388f217496914d6135496562cf534',normalization=dict(d_c='i/(2*pi)*(bar_partial-partial)',dd_c='i/pi*partial*bar_partial',beta='dd_c |z|^2',disk_beta_mass=2,complex_two_ball_beta_squared_mass=4,radial_Hessian_measure='H_1(f(|z|^2))=(f_prime(s)+s*f_double_prime(s))*beta',disk_radial_integral='integral_D g(|z|^2)*beta=2*integral_0^1 g(s) ds'),smooth_disk=dict(reference='psi=|z|^2-2',fixtures=rows,sublevel_set_u_less_v='unit disk minus origin',comparison_left=2,comparison_right=0,distinct_same_nonzero_Hessian=['v','w'],stability_sequence='u_j=w, target u=v, mu_j=mu=beta; difference=-1',Lp_density='beta=(2/pi)dV is in every finite L^p and L^infinity on the disk',boundaries=dict(psi=-1,u=-3,v=-2,w=-3),canonical_truncations='u_k=u for integer k>=2; v_k=v and w_k=w for k>=2',energy_increasing_monotonicity_failure='u<=v but E(u)=-3/2 > E(v)=-2',energy_path=dict(path=str(path),signed_energy=str(path_energy),second_derivative=3)),smooth_global_Stokes=dict(domain='unit ball in C^2',m=2,n=2,reference='psi=|z|^2-2',u='psi-1',v='psi-2',w_1='psi',constant_difference=1,left_integral=4,right_integral=0,signed_energies=dict(u=-4,v=-8,w_1=0),claim_target='Theorem 3.11 as printed, not a normalized Dirichlet formula'),bounded_radial_boundary_mass=dict(domain='unit disk',reference='psi=|z|^2-2',alpha='3/4',perturbation=str(h),epsilon_sequence='epsilon_j=1/j decreases to zero',ordering_argument='partial_epsilon h=alpha*(epsilon^(alpha-1)-(1-s+epsilon)^(alpha-1))>0, so decreasing epsilon gives decreasing functions',bounds='-1<=h_epsilon<=0; h_epsilon(1)=0',Hessian_positivity='h_prime>0 and h_double_prime>0',mass_formula=str(mass),signed_energy_formula=str(energy),signed_energy_limit=str(limit_energy),uniform_absolute_energy_upper_bound='11/4',bound_argument='absolute reference term <=2; gradient integral <=3/4',class_membership='each psi+h_epsilon is smooth with finite global Hessian mass, same boundary trace, relative bound 1, and uniform absolute signed energy; hence limit belongs to Definition 2.5',limit='u=psi-(1-|z|^2)^(3/4), locally smooth and locally finite Hessian but infinite total mass',canonical_truncation='max(u,psi-k)=u for every integer k>=1; not in E^0 because of infinite total Hessian mass',exact_boundary_product=str(boundary_product),sample_values=samples,not_a_counterexample_to_local_m1_distributional_continuity=True),measure_hypothesis_scaling=dict(reference_mass=2,shift='phi=psi-C, C>0',shift_signed_energy='-2C',required_inequality='C*mu(Omega)<=A*(2C)^(m/(m+1)) for every C>0',consequence='mu(Omega)=0 for a finite positive reference mass; adding normalization or revising the estimate is necessary for nonzero data',beta_not_claimed_to_satisfy_Theorem_6_1_hypothesis=True,positive_energy_issue='Section 6 permits psi+C with positive signed energy; the fractional power of -E is not real for m=1'),literal_claims_excluded=['introductory Theorem 1.3 comparison and injectivity','Theorem 5.1 comparison','Corollary 5.2 boundary-free domination','Corollary 5.3 injectivity','Theorem 3.11 global integration by parts','Lemma 3.6 canonical E^0 membership','Theorem 7.2 unnormalized stability','Theorem 7.3 unnormalized uniqueness for L^p data'],proof_only_qualifications=['relative boundedness versus ordinary local boundedness with pole sets','operator definition at reference singularities','weighted energy to unweighted mass and uniform integrability','moving test coefficients and restricted measures','mu hypothesis transferred to mu_j','decreasing continuity applied to mere L1_loc subsequences','finite energy versus same singularity type'],no_general_relative_Hessian_theorem_import=True,no_general_corrected_theorem_claim=True,no_original_general_theorem_promotion=True,independent_model_receipt_claimed=False,canonical_status_changes=[],active_book_changed=False,helper_source=__file__,helper_SHA256=sha(Path(__file__)),SymPy_version=S.__version__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],record_SHA256=sha(out),radial_energy_limit=str(limit_energy),radial_mass_limit='infinity',smooth_comparison=[2,0],global_Stokes=[4,0])))
