from pathlib import Path
from datetime import datetime, timezone
import json, hashlib, zipfile, shutil

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Truong_relative_Hessian_review_20261008'
S=R/'source_material/Truong_relative_Hessian_sources_20261008'
E=R/'manuscript/editorial';W=Path('/tmp/Truong_relative_Hessian_primary_views_v1_20261008')
O=Path('/workspace/book-completion-drafts/research-integration')
out=C/'source_export_v1_20261008.json';assert not out.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
cp=C/'source_checkpoint_v2_20261008.json'
assert sha(cp)=='5084ada55d0ca5e2c8ed277d2b788fa1456f0244a2508efc746bdc4c562a810c'
obj=json.loads(cp.read_text())
for p,h in obj['protected_core_inputs'].items():assert sha(Path(p))==h
editorial=[Path(p) for p in obj['editorial_files']]
assert all(sha(p)==obj['editorial_files'][str(p)] for p in editorial)
cache=[p for p in C.rglob('*') if p.is_file()]
helpers=sorted(Path('/tmp').glob('Truong_relative_Hessian_*_20261008.py'))
full={f'primary/{p.name}':p for p in S.iterdir() if p.is_file()}
full.update({f'actual_views/{p.name}':p for p in W.iterdir() if p.is_file()})
authored={f'authored_records/{p.relative_to(C)}':p for p in cache}
authored.update({f'editorial/{p.name}':p for p in editorial})
authored.update({f'helpers/{p.name}':p for p in helpers})
full.update(authored)
def export(path,items):
 assert not path.exists()
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,p in sorted(items.items()):z.write(p,name)
 with zipfile.ZipFile(path) as z:
  assert sorted(z.namelist())==sorted(items)
  for name,p in items.items():assert z.read(name)==p.read_bytes(),name
 return dict(path=str(path),bytes=path.stat().st_size,SHA256=sha(path),members=len(items),members_byte_verified=True)
fullzip=export(O/'Truong_Relative_Hessian_Actual_Source_Evidence_2026-10-08.zip',full)
authzip=export(O/'Truong_Relative_Hessian_Authored_Audit_Records_2026-10-08.zip',authored)
review=O/'Truong_Relative_Hessian_Actual_Source_Review_2026-10-08.pdf'
assert not review.exists();shutil.copy2(S/'Truong_relative_Hessian_arxiv_v1.pdf',review)
D=E/'artifact_exports/20261008_truong_relative_hessian_sources'
assert not D.exists();D.mkdir()
p=D/Path(authzip['path']).name;shutil.copy2(authzip['path'],p)
assert sha(p)==authzip['SHA256']
(D/'SHA256SUMS').write_text(sha(p)+'  '+p.name+'\n')
(D/'README.md').write_text('''# Relative Hessian boundary and mass source audit, 8 October 2026

The authored archive records the complete 26-page reading of arXiv:2609.12032v1, posted 10 September 2026, in thirteen individually displayed matching views and thirteen sequential notes. Source: https://arxiv.org/abs/2609.12032v1.

It contains authored notes, receipts, hash and actual-reading records, four editorial audit files, and acquisition/diagnostic helpers. The original primary PDF, extracted full text, matching images and complete source evidence stay in the cloud and are not included in this repository upload.

The audit excludes the preprint's general theorems under its literal definitions. Direct smooth examples test missing boundary hypotheses in comparison, injectivity, global integration by parts and stability. A bounded radial family with the same boundary trace has uniformly finite signed relative energy but diverging total Hessian mass; its limit also defeats the stated canonical basic-class membership. A constant-shift calculation tests the unnormalized measure hypothesis. These are elementary reproducible diagnostics, not a new general theorem, an independent-model receipt or a replacement Dirichlet existence theory.

The extraction font warning, failed direct fractional-power limit, and failed manually copied catalogue-hash assertion remain frozen with their corrective records. No extra reading is credited for repairs or exports. All actual image/text pairs were readable and matched. External bibliography proofs are not recursively certified.

The active validated book remains the 4,636-page edition at this source checkpoint. All 425 TeX inputs, both bibliographies and the native catalogue/editor are preserved. The 42 atoms/twelve formal problems are unchanged; general BJ22 critical homogeneous Siu division/envelopes remain OPEN and LPWZ density remains UNVERIFIED. The last complete book pass is 4 October. SHA256SUMS pins the archive and every member was byte-verified.
''')
record=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — source archives byte-verified; repository publication pending at export',full_source_evidence=fullzip,authored_source_evidence=authzip,source_review_PDF=dict(path=str(review),bytes=review.stat().st_size,SHA256=sha(review),physical_pages=26),repository_artifact_directory=str(D.relative_to(R)),repository_artifact_files={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in sorted(D.iterdir())},external_primary_artifact_upload=False,actual_source_pages=26,actual_images=13,general_relative_Hessian_theorems_admitted=False,export_reading_credit=0,canonical_status_changes=[],GitHub_published=False,helper_source=__file__)
out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
for p,h in obj['protected_core_inputs'].items():assert sha(Path(p))==h
print(json.dumps(dict(status=record['status'],record_SHA256=sha(out),full_source_evidence=fullzip,authored_source_evidence=authzip,repository_artifact_directory=record['repository_artifact_directory'])))
