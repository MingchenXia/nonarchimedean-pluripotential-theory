# Truong relative Hessian v1 actual source view 03

UTC: 2026-10-08T20:52:20.081260+00:00. Physical pages: 5, 6.

Read the complete selected text and displayed matching rendered image. The m-positive cone and distributional m-subharmonic definition are stated, and the bounded local Bedford–Taylor–Błocki–Dinew products have an explicit locally bounded premise. The m-hyperconvex domain uses a negative exhaustion. Section 2.4 now fixes psi with analytic singularities, strengthening the earlier arbitrary-negative reference wording; equality of singularity types is a bounded global difference. No boundary normalization has appeared on these pages. The relative finite-energy definition is still ahead, so constant-shift injectivity and unbounded canonical-product issues remain questions to check, not yet established diagnostics. The actual image keeps eigenvalue signs, subscript ranges, accents and reference-ring symbols readable; the acquisition warning remains preserved.
