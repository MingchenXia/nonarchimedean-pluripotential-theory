# Truong relative Hessian v1 actual source view 01

UTC: 2026-10-08T20:50:56.322037+00:00. Physical pages: 1, 2.

Read the complete selected text and displayed matching rendered image. The title/author and arXiv v1 date agree with the pinned metadata. The local setting is a bounded m-hyperconvex domain in C^n, 1<=m<=n, with negative reference psi, beta=dd^c|z|^2 and claimed relative energy/products/comparison/existence-uniqueness. These are introductory source claims, not yet accepted theorem imports. Theorem 1.1 begins at the bottom of page 2 and continues on the next page. The finite-energy/singularity and boundary normalization definitions must be checked before uniqueness or measure classes can be assessed. Displayed pages are readable despite the retained extraction font warning; accents in external author names are visible. Cegrell, Dinew, Lu, compact Hessian and relative singularity foundations remain attributed references with no fresh recursive proof credit.
