from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, re, shutil, subprocess, fitz

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/GVF_model_companion_catalogue_supplement_20261009'
F=R/'source_material/Hultberg_GVF_dependency_review_20261009/GVFFoundations26ArxivV2'
p=R/'output/open_problems_catalogue_2026-10-03.tex'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
digest=lambda s:hashlib.sha256(s.encode()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
assert not C.exists()
assert sha(p)=='ec3a2a9d8c4d713afe2c0ff8dcf17720ef0d77442b6086d515dea382fe7b77ec'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()=='8e693b7713bf069f97120dba2354f416271f5c7c'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=R,text=True).strip()
C.mkdir()
before=p.read_text()
(C/'catalogue_before_v1_20261009.tex').write_bytes(p.read_bytes())
fragment=Path('/tmp/GVF_catalogue_model_companion_fragment_v1_20261009.tex').read_text()
(C/'own_model_companion_supplement_v1_20261009.tex').write_text(fragment)
booksha=sha(R/'manuscript/book.pdf')
historicalsha=sha(p.with_suffix('.pdf'))
assert booksha=='79a07672385e2ace08e064474a0948b8acdaae8ac6b43f94aecbc36afd10e45c'
assert historicalsha=='65125a7809e34e4dbe2440855df21447f2c38b79dc3dd6f4a46107353dcb53e2'
s=before
old='conditional and source-scoped results. A dated supplement gives two\narithmetic source questions outside that canonical count.'
new=('conditional and source-scoped results. Dated supplements give two\n'
     'arithmetic source questions and a globally valued field model-companion\n'
     'question outside that canonical count.')
assert s.count(old)==1
s=s.replace(old,new,1)
old='The general homogeneous Siu issue below remains unresolved.'
new=('A further 9 October supplement formulates the fixed-parameter GVF\n'
     'model-companion conjecture from the fully read arXiv version~2 of\n'
     'the foundations paper. Its source status remains open; no new\n'
     'general literature cutoff is inferred.\n'+old)
assert s.count(old)==1
s=s.replace(old,new,1)
marker=r'\section*{Settled questions excluded from the active count}'
assert s.count(marker)==1
s=s.replace(marker,fragment+marker,1)
old='The arithmetic supplement records its own published-source reading and\ntargeted 9 October searches separately from the original extraction.'
new=(old+'\nThe GVF supplement records a separate complete reading of its pinned\n'
     '52-page source and preserves the conditional classification and\n'
     'normalization qualifications. It makes no new exhaustive search claim.')
assert s.count(old)==1
s=s.replace(old,new,1)
bib=r"""\bibitem[BDHS26]{BDHS26GVFFoundationsV2}
Ita{\"i} Ben Yaacov, Pablo Destic, Ehud Hrushovski, and Micha{\l} Szachniewicz.
\newblock Globally valued fields: foundations.
\newblock arXiv:2409.04570v2, 2026.
\newblock Version 2, 30 August 2026.
\newblock \url{https://arxiv.org/abs/2409.04570v2}.

"""
assert s.count(r'\end{thebibliography}')==1
s=s.replace(r'\end{thebibliography}',bib+r'\end{thebibliography}',1)
problems=lambda t:re.findall(r'\\begin\{problem\}.*?\\end\{problem\}',t,re.S)
atoms=lambda t:re.findall(r'\\label\{atom:[^}]+\}',t)
bibliography=lambda t:dict(re.findall(r'(\\bibitem(?:\[[^\]]*\])?\{[^}]+\})(.*?)(?=\\bibitem|\\end\{thebibliography\})',t,re.S))
assert problems(before)==problems(s) and len(problems(s))==12
assert atoms(before)==atoms(s) and len(atoms(s))==42
start=r'\clearpage\section{Regularization of arbitrary classical psh functions}'
end=r'\clearpage'+'\n'+r'\section*{Supplementary source questions: arithmetic equidistribution}'
core=lambda t:t[t.index(start):t.index(end)]
assert core(before)==core(s)
bs=lambda t:t[t.index(end):t.index(marker)]
assert bs(before)==bs(s).replace(fragment,'',1)
oldbib,newbib=bibliography(before),bibliography(s)
assert len(oldbib)==31 and len(newbib)==32
assert all(newbib[k]==v for k,v in oldbib.items())
labels=re.findall(r'\\label\{([^}]+)\}',s)
assert len(labels)==len(set(labels))
refs=re.findall(r'\\(?:eqref|ref|[Cc]ref)\{([^}]+)\}',s)
refs+=re.findall(r'\\hyperref\[([^]]+)\]',s)
assert all(k in labels for group in refs for k in group.split(','))
cites=[]
for group in re.findall(r'\\cite(?:\[[^]]*\])?\{([^}]+)\}',s):cites.extend(group.split(','))
keys=re.findall(r'\\bibitem(?:\[[^\]]*\])?\{([^}]+)\}',s)
assert set(cites)<=set(keys) and len(keys)==len(set(keys))
tiers=re.findall(r'\\subsubsection\*\{(P\d+\.\d+) \(T(\d)\):',s)
assert len(tiers)==42
counts=[sum(t==str(n) for _,t in tiers) for n in range(1,6)]
assert counts==[0,3,7,15,17]
doc=fitz.open(F/'GVFFoundations26ArxivV2.pdf')
locators={'Definition 1.1.':3,'Corollary 7.11.':33,'Lemma 10.2.':38,'Example 11.4.':41,
          'Definition 11.8.':43,'Definition 12.1.':47,'Definition 12.3.':47,
          'Definition 12.5.':48,'Lemma 12.6.':48,'Conjecture 12.7.':48}
assert len(doc)==52
for needle,page in locators.items():assert needle in ' '.join(doc[page-1].get_text().split())
p.write_text(s)
assert sha(R/'manuscript/book.pdf')==booksha and sha(p.with_suffix('.pdf'))==historicalsha
edit=dict(UTC=now(),status='IN-PLACE SOURCE EDITED AND AUDITED; native compilation not yet checked for this edit',
 source=str(p.relative_to(R)),before_SHA256=digest(before),after_SHA256=sha(p),after_bytes=p.stat().st_size,
 canonical_family_block_byte_identical=True,canonical_family_block_SHA256=digest(core(s)),
 original_formal_problem_bodies_byte_identical=12,original_atom_labels_byte_identical=42,
 original_bibliography_entries_byte_identical=31,added_bibliography_entries=1,
 BS_source_question_section_byte_identical=True,canonical_tiers=counts,canonical_status_changes=[],
 new_supplement='GVF.C12.7',source_status='OPEN in arXiv:2409.04570v2',
 source_PDF_SHA256=sha(F/'GVFFoundations26ArxivV2.pdf'),
 existing_actual_complete_source_checkpoint_SHA256=sha(F/'actual_complete_source_checkpoint_v1_20261009.json'),
 existing_full_primary_reading_pages=52,new_unique_primary_reading_credit=0,
 physical_locator_extraction_checked=locators,locator_extraction_is_not_new_actual_page_reading=True,
 literal_scale_normalization='Lemma 10.2 gives h(1,2)=r log(2); match H with r=H/log(2)',
 unbounded_language_zero_tuple=-1,ordinary_height_zero_tuple='-infinity',
 fixed_e_normalization='h(1,2)<=e, not equality',expected_EC_classification='conditional and up to scaling',
 ordinary_source_audit=True,original_results_promoted=[],independent_verifier_receipt=None,
 full_book_reading_claim=False,book_PDF_unchanged=True,book_PDF_SHA256=booksha,book_pages=4685,
 historical_catalogue_PDF_unchanged=True,historical_PDF_SHA256=historicalsha,historical_PDF_current_for_edited_source=False,
 native_editor_kept_open=True,replacement_document_created=False,native_compile_success_verified=False,
 new_native_PDF_exported=False,source_labels_duplicate=0,unresolved_checked_refs=0,unresolved_checked_cites=0,
 helper_source=__file__,helper_SHA256=sha(__file__))
(C/'catalogue_edit_and_source_audit_v1_20261009.json').write_text(json.dumps(edit,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(source_SHA256=sha(p),bytes=p.stat().st_size,formal_problems=12,canonical_atoms=42,
                     canonical_tiers=counts,old_bibliography=31,new_bibliography=32,source_status='OPEN',
                     source_audit_SHA256=sha(C/'catalogue_edit_and_source_audit_v1_20261009.json'))))
