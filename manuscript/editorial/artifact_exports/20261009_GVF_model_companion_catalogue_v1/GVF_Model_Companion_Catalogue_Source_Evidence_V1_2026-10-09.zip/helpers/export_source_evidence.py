from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/GVF_model_companion_catalogue_supplement_20261009'
F=R/'source_material/Hultberg_GVF_dependency_review_20261009/GVFFoundations26ArxivV2'
E=R/'manuscript/editorial'
A=E/'artifact_exports/20261009_GVF_model_companion_catalogue_v1'
source=R/'output/open_problems_catalogue_2026-10-03.tex'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
now=lambda:datetime.now(timezone.utc).isoformat()
edit=json.loads((C/'catalogue_edit_and_source_audit_v1_20261009.json').read_text())
wait=json.loads((C/'native_compiler_client_wait_ended_v1_20261009.json').read_text())
assert sha(source)==edit['after_SHA256']==wait['source_SHA256']
assert not wait['native_compile_success_verified'] and not wait['native_compiler_failure_verdict']
assert sha(R/'manuscript/book.pdf')==edit['book_PDF_SHA256']
assert sha(source.with_suffix('.pdf'))==edit['historical_PDF_SHA256']
assert not A.exists()
A.mkdir(parents=True)
review=E/'GVF_model_companion_catalogue_supplement_source_review_v1_20261009.md'
notes=E/'GVF_model_companion_catalogue_supplement_source_reading_notes_v1_20261009.md'
manifest=E/'GVF_model_companion_catalogue_supplement_source_manifest_v1_20261009.json'
artifacts=E/'GVF_model_companion_catalogue_supplement_source_artifacts_v1_20261009.json'
for p in [review,notes,manifest,artifacts]:assert not p.exists()
review.write_bytes(Path('/tmp/GVF_catalogue_model_companion_own_review_v1_20261009.md').read_bytes())
notes.write_bytes(Path('/tmp/GVF_catalogue_model_companion_reading_notes_v1_20261009.md').read_bytes())
saved=A/'Open_Problems_Catalogue_GVF_Supplement_V1_2026-10-09.tex'
saved.write_bytes(source.read_bytes())
members={
 'source/catalogue_before.tex':C/'catalogue_before_v1_20261009.tex',
 'source/catalogue_after.tex':source,
 'source/own_model_companion_supplement.tex':C/'own_model_companion_supplement_v1_20261009.tex',
 'records/in_place_edit_and_source_audit.json':C/'catalogue_edit_and_source_audit_v1_20261009.json',
 'records/native_compiler_client_wait_ended.json':C/'native_compiler_client_wait_ended_v1_20261009.json',
 'own_notes/complete_source_formulation_review.md':review,
 'own_notes/formulation_reading_notes.md':notes,
 'prior_primary_identity/actual_complete_source_checkpoint.json':F/'actual_complete_source_checkpoint_v1_20261009.json',
 'prior_primary_identity/own_book_application_locator_addendum.md':F/'book_application_locator_addendum_v1_20261009.md',
 'helpers/edit_and_source_audit.py':Path('/tmp/GVF_catalogue_model_companion_edit_and_audit_v1_20261009.py'),
 'helpers/record_compiler_wait.py':Path('/tmp/GVF_catalogue_model_companion_record_compiler_wait_v1_20261009.py'),
 'helpers/export_source_evidence.py':Path(__file__)}
assert len(members)==12
archive=A/'GVF_Model_Companion_Catalogue_Source_Evidence_V1_2026-10-09.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
 for name,p in members.items():z.writestr(name,p.read_bytes())
with zipfile.ZipFile(archive) as z:
 assert set(z.namelist())==set(members)
 for name,p in members.items():assert z.read(name)==p.read_bytes()
obj=dict(UTC=now(),status='SOURCE AUDITED; native compilation unverified, backend state UNKNOWN',
 source_path=str(source.relative_to(R)),source_SHA256=sha(source),source_bytes=source.stat().st_size,
 saved_source=str(saved.relative_to(R)),saved_source_byte_identical=True,
 added_source_question='GVF.C12.7',source_question_status='OPEN in arXiv:2409.04570v2',
 supplementary_source_questions=['BS.Q6.21','BS.R7.16','GVF.C12.7'],
 canonical_atoms=42,formal_problems=12,canonical_tiers=[0,3,7,15,17],canonical_status_changes=[],
 canonical_family_block_byte_identical=True,canonical_family_block_SHA256=edit['canonical_family_block_SHA256'],
 original_problem_bodies_byte_identical=True,old_31_bibliography_entries_byte_identical=True,
 original_BS_supplement_byte_identical=True,new_bibliography_key='BDHS26GVFFoundationsV2',
 source_audit_SHA256=sha(C/'catalogue_edit_and_source_audit_v1_20261009.json'),
 native_compiler_wait_SHA256=sha(C/'native_compiler_client_wait_ended_v1_20261009.json'),
 native_compile_tool_calls_for_this_edit=1,native_compile_success_verified=False,
 native_compiler_failure_verdict=False,native_compiler_backend='UNKNOWN',
 native_preview_actually_read=False,native_editor_kept_open=True,new_native_PDF_exported=False,
 replacement_document_created=False,historical_catalogue_PDF_pages=86,
 historical_catalogue_PDF_SHA256=edit['historical_PDF_SHA256'],historical_PDF_current_for_updated_source=False,
 book_pages=4685,book_changed=False,book_PDF_SHA256=edit['book_PDF_SHA256'],
 primary_source_version='arXiv:2409.04570v2, 30 August 2026',
 primary_source_PDF_SHA256=edit['source_PDF_SHA256'],existing_primary_pages_read=52,
 existing_complete_primary_checkpoint_SHA256=edit['existing_actual_complete_source_checkpoint_SHA256'],
 prior_source_evidence_64_member_archive_SHA256='5229d412499a2fc7d5037fcd21675c9374075388d1550d366bab9b45580fa491',
 prior_source_evidence='Already published within GVF foundations book evidence; not duplicated here',
 new_primary_reading_credit=0,new_original_result=False,independent_verifier_receipt=None,
 BJ22_general_homogeneous_Siu='OPEN',LPWZ_density='UNVERIFIED',
 archive=str(archive.relative_to(R)),archive_SHA256=sha(archive),archive_bytes=archive.stat().st_size,
 archive_members=12,evidence_members_byte_verified=True,
 archive_excludes=['Primary paper PDF','Primary paper full text','Primary rendered source pages','Catalogue PDF'],
 helper_source=__file__,helper_SHA256=sha(__file__))
manifest.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
artifacts.write_text(json.dumps(dict(UTC=now(),archive=obj['archive'],archive_SHA256=sha(archive),
 archive_members=12,standalone_source=obj['saved_source'],source_SHA256=sha(saved),
 native_compile_success_verified=False,new_catalogue_PDF=False,book_changed=False,
 helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
(A/'README.md').write_text(
 '# Open-problem catalogue: GVF source supplement, 9 October 2026\n\n'
 'The standalone LaTeX source contains the unchanged 42 canonical atoms\n'
 'and twelve problem families, plus BS.Q6.21, BS.R7.16 and GVF.C12.7.\n'
 'The new question gives full tuple-height conventions, the fixed-e\n'
 'continuous-language problem, the precise approximate existential-closure\n'
 'condition, known representation results and conditional classification.\n\n'
 '**Source audit passes; native compilation is unverified.** The fresh\n'
 'built-in compiler call returned no diagnostics during bounded client\n'
 'waits. The client was ended and backend state is unknown. No updated\n'
 'catalogue PDF or native preview reading is claimed. The historical\n'
 '86-page PDF is not a rendering of this source. The same editor stays open.\n\n'
 'The evidence ZIP has twelve authored source, audit, wait, helper and\n'
 'prior-source identity members, all checked byte-for-byte. It excludes\n'
 'the primary paper PDF, full text and page images. The active 4,685-page\n'
 'book is unchanged. No original theorem or canonical problem is promoted.\n')
(A/'SHA256SUMS').write_text(''.join(sha(p)+'  '+p.name+'\n' for p in [saved,archive,A/'README.md']))
p=R/'README.md'
p.write_text(p.read_text().rstrip()+
 '\n\n**GVF open-problem catalogue source update, 9 October 2026:**\n'
 'the [saved standalone LaTeX source](manuscript/editorial/artifact_exports/20261009_GVF_model_companion_catalogue_v1/Open_Problems_Catalogue_GVF_Supplement_V1_2026-10-09.tex)\n'
 'adds the complete fixed-parameter GVF model-companion question alongside\n'
 'the two arithmetic source questions. The [source audit](manuscript/editorial/GVF_model_companion_catalogue_supplement_source_review_v1_20261009.md)\n'
 'preserves all twelve canonical problem bodies, 42 atoms and their tiers.\n'
 'Native compilation is unverified after the fresh editor call returned no\n'
 'diagnostics; no updated catalogue PDF is claimed. The 4,685-page book is\n'
 'unchanged. [Twelve-member evidence](manuscript/editorial/artifact_exports/20261009_GVF_model_companion_catalogue_v1/README.md)\n'
 'records the source formulation, checks and compiler limitation.\n')
p=E/'second_reading_and_research_programme_20261002.md'
p.write_text(p.read_text().rstrip()+
 '\n\n### GVF catalogue source question, 9 October 2026\n\n'
 'Edited the existing open-problem catalogue in the same native editor.\n'
 'Added GVF.C12.7 with full fixed-e height/language conventions, model\n'
 'companion definition, approximate bounded-height existential closure,\n'
 'known representation results, and conditional scaled classification.\n'
 'All twelve formal problem bodies, the complete canonical family block,\n'
 '42 atoms, tiers (0,3,7,15,17), prior arithmetic supplement and 31 previous\n'
 'bibliography entries are byte-identical. The source leaves the conjecture\n'
 'OPEN. No exhaustive current literature verdict is claimed.\n\n'
 'The fresh built-in compiler call returned no diagnostics in bounded\n'
 'waits; the waiting client was ended. Backend state is UNKNOWN, without\n'
 'a success or failure verdict. Preserve the source and same open editor;\n'
 'no replacement document, updated catalogue PDF or native preview reading.\n'
 'The active 4,685-page book and historical 86-page catalogue PDF are exact.\n'
 'See [source audit](GVF_model_companion_catalogue_supplement_source_review_v1_20261009.md)\n'
 'and [twelve-member evidence](artifact_exports/20261009_GVF_model_companion_catalogue_v1/README.md).\n'
 'No primary reading credit, original-result promotion or independent\n'
 'verifier clearance is added by this supplement or its upload.\n')
owned=[review,notes,manifest,artifacts,saved,archive,A/'README.md',A/'SHA256SUMS',
       R/'README.md',E/'second_reading_and_research_programme_20261002.md']
assert len(owned)==10
export=dict(UTC=now(),status='AUTHORED SOURCE EVIDENCE EXPORTED AND BYTE VERIFIED; native compilation unverified',
 owned_files=[dict(path=str(p.relative_to(R)),SHA256=sha(p),bytes=p.stat().st_size) for p in owned],
 archive_members=[dict(name=n,SHA256=sha(p),bytes=p.stat().st_size) for n,p in members.items()],
 archive_SHA256=sha(archive),catalogue_source_SHA256=sha(source),
 native_compile_success_verified=False,book_PDF_SHA256=sha(R/'manuscript/book.pdf'),
 helper_source=__file__,helper_SHA256=sha(__file__))
out=C/'catalogue_evidence_export_v1_20261009.json';assert not out.exists()
out.write_text(json.dumps(export,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(owned_files=10,archive_members=12,archive_bytes=archive.stat().st_size,
 archive_SHA256=sha(archive),export_SHA256=sha(out),native_compile_success_verified=False)))
