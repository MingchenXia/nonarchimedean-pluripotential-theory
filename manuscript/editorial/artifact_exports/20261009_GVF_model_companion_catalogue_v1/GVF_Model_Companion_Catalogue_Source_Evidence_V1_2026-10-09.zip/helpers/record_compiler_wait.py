from pathlib import Path
from datetime import datetime,timezone
import hashlib,json
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/GVF_model_companion_catalogue_supplement_20261009'
p=R/'output/open_problems_catalogue_2026-10-03.tex'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
edit=json.loads((C/'catalogue_edit_and_source_audit_v1_20261009.json').read_text())
assert sha(p)==edit['after_SHA256']
out=C/'native_compiler_client_wait_ended_v1_20261009.json'
assert not out.exists()
record=dict(UTC=datetime.now(timezone.utc).isoformat(),
 status='CLIENT WAIT ENDED WITHOUT RETURNED COMPILER DIAGNOSTICS',
 source_path=str(p),source_SHA256=sha(p),fresh_source_edit=True,
 compile_tool='codex_app__compile_latex_document',orchestration_cell_id='114',
 tool_calls_for_this_fresh_edit=1,wait_results='two bounded waits yielded the same still-running cell without diagnostics',
 client_termination='functions.wait cell_id 114 terminate true returned Script terminated',
 backend_job_state='UNKNOWN; client termination is not a compiler verdict',
 native_compile_success_verified=False,native_compiler_failure_verdict=False,
 source_errors_reported=False,native_preview_actually_read=False,
 native_editor_kept_open=True,new_native_PDF_exported=False,replacement_document_created=False,
 old_compiler_records_untouched=True,old_compiler_calls_add_no_success_evidence=True,
 helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=record['status'],record_SHA256=sha(out))))
