from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile, shutil, fitz

R=Path('/workspace/nonarchimedean-pluripotential-theory'); E=R/'manuscript/editorial'
C=R/'source_material/Guo_Yuan_relative_minima_book_integration_20261009'
K=R/'source_material/Hultberg_GVF_dependency_review_20261009/GuoYuan26ArxivV2'
S=Path('/workspace/book-completion-drafts/Guo-Yuan-relative-minima-staging-v2-20261009')
D=Path('/workspace/book-completion-drafts/Guo-Yuan-relative-minima-integration-v2-20261009')
W=Path('/tmp/Guo_Yuan_relative_minima_staged_book_views_v2_20261009')
O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
def write(p,a):
    assert not p.exists()
    p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
def markdown(p,s):
    p.write_text(s.rstrip()+'\n')
prep=load('book_staging_preparation_v2_20261009.json'); release=load('book_release_checks_v2_20261009.json')
reading=load('actual_book_reading_v2_20261009.json'); math=load('book_mathematical_self_audit_v2_20261009.json')
validation=load('book_validation_v2_20261009.json'); under=load('book_underfull_delta_v2_20261009.json')
assert validation['returncode']==0 and under['all_normalized_blocks_and_multiplicities_identical']
assert reading['actual_unique_book_pages']==14 and reading['fresh_matching_views']==7 and reading['reused_matching_views']==0
assert not reading['remaining_repairs'] and reading['explicitly_reviewed_blank_versos']==[4430]
assert release['PDF']['physical_pages']==4681 and release['PDF']['SHA256']==reading['PDF']['SHA256']
assert math['actual_final_book_reading_SHA256']==sha(C/'actual_book_reading_v2_20261009.json')
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['before'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
paths={k:E/f'Guo_Yuan_relative_minima_staged_integration_{k}_v2_20261009.{ext}' for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
full=O/'Non-Archimedean_Pluripotential_Theory_Relative_Minima_V2_2026-10-09.pdf'
review=O/'Guo_Yuan_Relative_Minima_Actual_Book_Review_V2_2026-10-09.pdf'
minimal=O/'Guo_Yuan_Relative_Minima_Minimal_Source_V2_2026-10-09.zip'
evidence=O/'Guo_Yuan_Relative_Minima_Book_Evidence_V2_2026-10-09.zip'
dest=E/'artifact_exports/20261009_Guo_Yuan_relative_minima_v2'; record=C/'book_export_v2_20261009.json'
assert not any(p.exists() for p in [*paths.values(),full,review,minimal,evidence,dest,record])
shutil.copyfile(release['PDF']['path'],full); assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as source:
    doc=fitz.open()
    for n in reading['actual_book_physical_pages']:doc.insert_pdf(source,from_page=n-1,to_page=n-1)
    assert len(doc)==14
    doc.set_metadata(dict(title='Relative successive minima — actual book review',subject='Fourteen final physical pages actually read in seven fresh displays, including intentional blank verso 4430. Export grants no reading credit.'))
    doc.save(review,garbage=4,deflate=True); doc.close()
summary='''The checked 4,681-page edition adds Guo–Yuan's polarized geometric
function-field example to Chapter 27 and its exact-source provenance to
Appendix L. For a smooth projective C over algebraically closed k, genus
g>1 and rho(C x J)=3, the nef and pseudoeffective cone is ab>=g c^2 in
the alpha_1, theta_2, Q basis. Keep K=k(J), the chosen symmetric theta
polarization and L=f_1,1*theta. L is nef on the model, with ample degree-g
generic restriction. Both minima equal (g-1/g)(g-1)!, whereas the curve
height is (g-1)(g-1)!. At g=2 the minima are 3/2 and height is 1. The
lower average-of-minima bound fails over this higher-dimensional base;
the essential-minimum upper comparison is consistent. The following
paragraph explicitly returns to number fields and BS26Eq Theorem 6.17.

All sixteen physical pages of arXiv:2511.12509v2 were actually read in
eight matching complete-text/image displays. Proposition 2.2, Theorem 2.4
and Theorem 3.2 are pinned with their complete controlling proofs. The
addition pullback identity yields Q^2 theta_2^(g-1)=-2 g! by coefficient
extraction; it avoids a printed diagonal-sign slip and missing factor g
on source page 12. The source's main cone and height statements are not
refuted. Attaining divisors use the rational minimizing ray and an explicit
translation automorphism, avoiding general irrational semiampleness.
Thirty-one genus checks, 558 cone-height points and 155 attaining-degree
cases are exact diagnostics, not substitutes for the general argument.
Deeper classical Jacobian/Picard-functor/Bertini inputs remain disclosed
imports. This is a classical worked example with direct formal checks;
no original result or independent production-verifier receipt is claimed.

All fourteen selected final V2 pages were actually read in seven fresh
matching displays: both contents pages, chapter seams and full example,
complete provenance, intentional blank verso 4430, following Appendix M
opening, first/last index pages and the complete GY26 reference. No V1
reading credit was reused. The V1 partial reading and artifacts remain
frozen; V2 repairs the transition from geometric function fields back to
number fields. This is a scoped read. The last ordered whole-book reading
remains 4 October; export and upload add no reading or proof credit.

Required validation and six existing reference-check tests pass. Final
output has zero errors, missing glyphs, overfull boxes, unresolved references
or citations, package/pdfTeX warnings or rerun requests. All 955 inherited
underfull blocks retain normalized content and multiplicities. All 13,382
prior numbered values, 604 cited keys/labels, 2,766 contents titles/hierarchy
and 900 index terms remain; GY26 gives 605 citations. All internal
destinations resolve. Two core TeX files and the NA bibliography change;
the other 423 core TeX inputs and complex bibliography are identical.
No formal environment, semantic label, manual tag or contents title is added.

The canonical inventory remains 42 atoms/twelve formal problems and tiers
(0,3,7,15,17). BJ22 general homogeneous Siu/envelopes stay OPEN and LPWZ
density UNVERIFIED. The incoming conductor/power-cover, generic-line GVF
and toric-attainment candidates remain unverified outside book theorem
typography. The native catalogue/editor and historical PDF are preserved;
native compilation remains unverified. Activation and GitHub publication
are separate records. Continue cloud-only with Xean suspended.
Luo–Yu arXiv:2505.07193v3 has four of 31 pages actually read; its main
proof is unread and no claim from it is imported. GVF foundations
arXiv:2409.04570v2 is acquired but has zero of 52 pages actually read.
'''
markdown(paths['audit'],'# Relative successive-minima book integration, 9 October 2026\n\n'+summary+'\nScoped mathematical checks:\n\n'+''.join(f'{i}. {x}\n\n' for i,x in enumerate(math['scope_checks'],1)))
notes=[]
for item in reading['receipts']:
    n=item['number']; note=C/f'book_notes_v2/note_{n:02d}.md'; receipt=C/f'book_notes_v2/note_{n:02d}_receipt.json'
    assert sha(note)==item['note_SHA256'] and sha(receipt)==item['receipt_SHA256']
    notes.append(note.read_text())
markdown(paths['reading_notes'],'# Actual final relative-minima book reading\n\nFourteen selected final V2 pages in seven fresh displays; intentional verso 4430 included.\n'+''.join('\n---\n\n'+x for x in notes))
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md'
intro='''**Current checked edition: 4,681 pages, 9 October 2026.**
The [relative-minima integration audit](manuscript/editorial/Guo_Yuan_relative_minima_staged_integration_audit_v2_20261009.md)
adds Guo–Yuan's curve over the polarized base k(J) to Chapter 27. Both
minima exceed the normalized curve height, even for a nef model bundle
with ample generic restriction. The base theta polarization and the exact
cone hypotheses remain explicit; Appendix L explains two literal source
slips and the direct coefficient reconstruction. The following discussion
returns explicitly to number fields. All sixteen source pages and fourteen
selected final book pages were read with matching text/image displays.
Required checks pass; previous numbering, citations, contents and index
are preserved. The [artifacts](manuscript/editorial/artifact_exports/20261009_Guo_Yuan_relative_minima_v2/README.md)
contain the full book, actual review, minimal source and authored evidence.
The last whole-book ordered reading remains 4 October. Original research
candidates and canonical problem statuses remain unchanged. Work continues
in the cloud; Xean stays suspended and the native catalogue/editor is preserved.

'''
p=S/'README.md'; s=p.read_text(); marker='**Latest verified translated-abelian GitHub publication, 9 October 2026:**'
assert s.count(marker)==1; markdown(p,s.replace(marker,intro+marker,1))
intro='''## Current checked relative-minima edition: 4,681 pages, 9 October 2026

The [integration audit](Guo_Yuan_relative_minima_staged_integration_audit_v2_20261009.md)
imports the Guo–Yuan model-height example into Chapter 27, with full
sixteen-page primary reading and explicit theta-polarized base k(J).
The coefficient identity gives Q^2 theta^(g-1)=-2 g!; the minimizing
rational ray has integral attaining divisors via a product automorphism.
For g=2 both minima are 3/2 and the normalized curve height is 1. Only
the lower average-of-minima comparison fails in this example; the next
paragraph returns to number fields. Appendix L preserves hypotheses,
printed-source corrections and the deeper imported dependency boundary.

All fourteen final V2 selected pages were actually read in seven fresh
views, including intentional blank verso 4430. V1 partial records remain
frozen and confer no V2 reading credit. Required validation and six existing
tests pass. All 13,382 prior numbered values, 604 cited labels, 2,766
contents titles/hierarchy and 900 index terms remain; GY26 gives 605
citations. All destinations resolve and 955 underfull blocks are unchanged.
Other 423 core TeX inputs and the complex bibliography are identical.
See the [artifacts](artifact_exports/20261009_Guo_Yuan_relative_minima_v2/README.md).

The last ordered whole-book reading remains 4 October. Hultberg GVF v1
has a separate complete 43-page audit; selected Sedillot v2 reading is
five of 43 pages. Luo–Yu 2505.07193v3 currently has four of 31 pages
actually read; its main proof remains unread and unintegrated. The latest
GVF foundations 2409.04570v2 is acquired but zero of 52 pages are read.
Incoming continuation306 has a separately published scoped audit; its
same-centre power-cover and distinct-centre candidates remain UNVERIFIED.
Continuation307 is observed through metadata only, without proof reading.
Canonical 42-atom/twelve-problem tiers remain (0,3,7,15,17); P12.2/P12.3
and BJ22 general homogeneous Siu/envelopes remain OPEN, LPWZ density
UNVERIFIED. No original result or independent verifier receipt is promoted.
The native catalogue/editor and historical PDF remain preserved with
native compilation unverified. Continue cloud-only; Xean stays suspended.

'''
p=S/programme; s=p.read_text(); first=s.index('\n'); markdown(p,s[:first+1]+'\n'+intro+s[first+1:])
with zipfile.ZipFile(prep['baseline_minimal_source']['path']) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    members=old.namelist(); assert len(members)==len(set(members))==472
    for n in members:z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
    assert z.testzip() is None
    for n in z.namelist():assert z.read(n)==(S/n).read_bytes()
files={f'records/{q.name}':q for q in C.glob('*.json')}
for q in C.glob('book_validation_*_20261009.log'):files[f'logs/{q.name}']=q
for n in prep['after']:files['staged_inputs/'+n]=S/n
for q in D.iterdir():
    assert q.suffix=='.tex'; files['drafts/'+q.name]=q
for q in (C/'book_compiled_staged_v2').iterdir():
    if q.suffix!='.pdf':files['compiled/'+q.name]=q
for item in reading['receipts']:
    n=item['number']
    for kind,q in [('notes',C/f'book_notes_v2/note_{n:02d}.md'),('receipts',C/f'book_notes_v2/note_{n:02d}_receipt.json'),('images',W/f'sheet_{n:02d}.png'),('text',W/f'sheet_{n:02d}.txt')]:files[f'actual/{kind}/{q.name}']=q
files['actual/prepared_manifest.json']=W/'manifest.json'
for q in Path('/tmp').glob('Guo_Yuan_*_book_*_20261009.py'):files['helpers/'+q.name]=q
for q in Path('/tmp').glob('Guo_Yuan_underfull_delta_*_20261009.py'):files['helpers/'+q.name]=q
for q in [paths['audit'],paths['reading_notes'],S/programme,S/'README.md']:files['editorial/'+q.name]=q
sourcezip=K/'Guo_Yuan_Complete_Source_Evidence_V1_2026-10-09.zip'
assert sha(sourcezip)=='8b41bae3d121bb0838fbec2c9604c2852fbeddaf434911da786aa7625a1b52c8'
files['source_owned_records/'+sourcezip.name]=sourcezip
for n in ['actual_complete_source_checkpoint_v1_20261009.json','complete_evidence_export_v1_20261009.json','literal_exact_calibrations_v1_20261009.json','own_complete_source_review_v1_20261009.md']:files['source_owned_records/'+n]=K/n
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(files) and z.testzip() is None
    for n,q in files.items():assert z.read(n)==q.read_bytes()
artifacts={k:dict(path=str(q),bytes=q.stat().st_size,SHA256=sha(q)) for k,q in [('full_book_PDF',full),('selected_review_PDF',review),('minimal_TeX_source_archive',minimal),('actual_book_evidence_archive',evidence)]}
artifacts['full_book_PDF']['physical_pages']=4681; artifacts['selected_review_PDF']['physical_pages']=14
artifacts['minimal_TeX_source_archive']['members']=472; artifacts['actual_book_evidence_archive']['members']=len(files)
progress={n:sha(S/n) for n in ['README.md',programme]}
write(paths['manifest'],dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — scoped source/math/mechanical/actual-render gate',preparation=prep,release=release,validation=validation,actual_reading=reading,mathematical_audit=math,underfull_comparison=under,artifacts=artifacts,active_book_changed=False,GitHub_published=False))
write(paths['artifacts'],dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — all export members byte-verified',artifacts=artifacts,actual_final_book_pages=14,fresh_matching_views=7,explicitly_reviewed_blank_versos=[4430],reading_credit_from_export=0,GitHub_published=False))
dest.mkdir(parents=True)
for q in [full,review,minimal,evidence]:shutil.copyfile(q,dest/q.name); assert sha(dest/q.name)==sha(q)
(dest/'SHA256SUMS').write_text(''.join(sha(q)+'  '+q.name+'\n' for q in [full,review,minimal,evidence]))
markdown(dest/'README.md','# Relative successive-minima book artifacts\n\n'+summary+f'\nArtifacts: full 4,681-page PDF, 14-page actual review, 472-member minimal\nsource and {len(files)}-member byte-verified authored book evidence. The nested\n27-member source evidence excludes primary PDFs, literal source text and\nprimary-source images. Rendered images in this package are our book pages.\n')
editorial={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in paths.values()}
for p in dest.iterdir():editorial[str(p.relative_to(R))]=dict(bytes=p.stat().st_size,SHA256=sha(p))
write(record,dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — final relative-minima book/evidence export',artifacts=artifacts,editorial_files=editorial,progress_document_hashes=progress,actual_final_book_pages=14,actual_final_matching_views=7,reused_matching_views=0,explicitly_reviewed_blank_versos=[4430],source_evidence_SHA256=sha(sourcezip),source_checkpoint_SHA256=prep['source_checkpoint_SHA256'],active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)))
print(json.dumps(dict(status='EXPORTED',record_SHA256=sha(record),evidence_members=len(files),artifacts=artifacts)))
