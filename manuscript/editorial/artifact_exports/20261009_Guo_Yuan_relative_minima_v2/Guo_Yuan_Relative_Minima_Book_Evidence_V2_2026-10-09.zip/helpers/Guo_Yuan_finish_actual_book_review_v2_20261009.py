from pathlib import Path
from datetime import datetime, timezone
import hashlib, json

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R / 'source_material/Guo_Yuan_relative_minima_book_integration_20261009'
K = R / 'source_material/Hultberg_GVF_dependency_review_20261009/GuoYuan26ArxivV2'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
load = lambda n: json.loads((C / n).read_text())
prep = load('book_staging_preparation_v2_20261009.json')
release = load('book_release_checks_v2_20261009.json')
validation = load('book_validation_v2_20261009.json')
under = load('book_underfull_delta_v2_20261009.json')
manifest = json.loads(Path(release['manifest_path']).read_text())
assert validation['returncode'] == 0
assert under['all_normalized_blocks_and_multiplicities_identical']
assert sha(release['PDF']['path']) == release['PDF']['SHA256']
receipts = []
for n, item in enumerate(manifest, 1):
    p = C / f'book_notes_v2/note_{n:02d}_receipt.json'
    note = C / f'book_notes_v2/note_{n:02d}.md'
    x = json.loads(p.read_text())
    assert x['number'] == n and x['physical_pages'] == item['physical_pages']
    assert x['complete_selected_text_actually_read'] and x['matching_image_individually_displayed_and_reviewed']
    assert x['source_PDF_SHA256'] == release['PDF']['SHA256']
    assert sha(note) == x['note_SHA256']
    assert sha(item['path']) == x['image_SHA256']
    assert sha(item['selected_text_path']) == x['selected_text_SHA256']
    assert x['previous_receipt_SHA256'] == (receipts[-1]['receipt_SHA256'] if n > 1 else None)
    receipts.append(dict(number=n, physical_pages=x['physical_pages'], note_SHA256=sha(note), receipt_SHA256=sha(p)))
pages = [p for x in receipts for p in x['physical_pages']]
assert pages == release['selected_book_physical_pages'] and len(set(pages)) == 14 and len(receipts) == 7
assert sha(K / 'actual_complete_source_checkpoint_v1_20261009.json') == prep['source_checkpoint_SHA256']
assert sha(K / 'literal_exact_calibrations_v1_20261009.json') == prep['normalization_calibration_SHA256']
source = json.loads((K / 'actual_complete_source_checkpoint_v1_20261009.json').read_text())
assert source['physical_pages_read'] == list(range(1, 17)) and source['full_source_read']
reading = dict(
    UTC=datetime.now(timezone.utc).isoformat(), status='DONE — actual scoped final V2 book reading',
    PDF=release['PDF'], actual_book_physical_pages=pages, actual_unique_book_pages=14,
    fresh_matching_views=7, reused_matching_views=0, receipts=receipts,
    explicitly_reviewed_blank_versos=[4430],
    blank_justification='Rendered intentional blank verso following complete Appendix L provenance and before Appendix M recto.',
    remaining_repairs=[], actual_primary_source_reading_credit=0,
    whole_book_new_reading_claim=False, whole_chapter_reading_claim=False,
    index_actual_pages=[4639, 4650], middle_index_pages_mechanical_only=True,
    release_checks_SHA256=sha(C / 'book_release_checks_v2_20261009.json'),
    validation_SHA256=sha(C / 'book_validation_v2_20261009.json'),
    underfull_comparison_SHA256=sha(C / 'book_underfull_delta_v2_20261009.json'),
    active_book_changed=False, canonical_status_changes=[], original_results_promoted=[],
    helper_source=__file__, helper_SHA256=sha(__file__))
p = C / 'actual_book_reading_v2_20261009.json'
assert not p.exists()
p.write_text(json.dumps(reading, ensure_ascii=False, indent=2) + '\n')
checks = [
    'The controlling source is arXiv:2511.12509v2; its entire sixteen pages and complete cone/height proofs have prior actual reading receipts.',
    'Keep algebraically closed k, smooth projective C, genus g>1, rho(C x J)=3, degree-one alpha and chosen symmetric principal theta.',
    'The addition convention is fixed by f_m,n*theta = g m^2 alpha_1 + n^2 theta_2 + mn Q, not the inconsistent printed diagonal sign.',
    'Imported Nef=Psef cone is a,b>=0 and ab>=g c^2; it applies to every effective point-closure divisor.',
    'Base K=k(J) and theta polarization remain in both point and normalized curve height formulas.',
    'L=f_1,1*theta is nef on the total model and has ample degree-g generic restriction.',
    'Extracting m^2 n^(2g) from the vanishing (g+1)-fold pullback yields Q^2 theta_2^(g-1)=-2 g!, and avoids the missing-factor slip.',
    'Alpha_1^2=0, alpha_1 theta_2^g=g!, and one-Q intersections vanish by fibrewise algebraic triviality.',
    'Point closure degree a>0 gives s=b/a >=g(c/a)^2; completing the square gives height >=g! (1-1/g^2).',
    'The rational minimizing ray f_g,1*theta/g^3 is sufficient; no irrational real boundary semiampleness is asserted.',
    'Sufficiently ample theta divisors are smooth and connected; the explicit translation automorphism identifies each pullback with C x H_n.',
    'The attaining closed-point degrees g^3 n are unbounded, hence the sequence is generic on the curve.',
    'Both minima equal (g-1/g)(g-1)! and curve height is (g-1)(g-1)!; g=2 gives 3/2 versus 1.',
    'The failed inequality is only the lower average-of-minima comparison over a polarized higher-dimensional base; the essential-minimum upper comparison is consistent.',
    'The adjoining remaining-directions paragraph explicitly returns to number fields and cites BS26Eq Theorem 6.17.',
    'Classical Jacobian/Picard-functor/Bertini dependencies are disclosed imports; this is an explanatory imported example with direct formal computations.',
    'The two literal auxiliary slips are not interpreted as refutations of the source main cone or height statements.',
    'No original result, new verifier receipt, homogeneous Siu repair, density assertion or canonical problem closure is promoted.'
]
math = dict(
    UTC=datetime.now(timezone.utc).isoformat(),
    status='PASS — ordinary primary-source and mathematical audit of an imported classical example',
    actual_final_book_reading_SHA256=sha(p), current_source_hashes=prep['after'],
    source_checkpoint_SHA256=prep['source_checkpoint_SHA256'],
    normalization_calibration_SHA256=prep['normalization_calibration_SHA256'],
    signature='Curve C over algebraically closed k, genus g>1, rho(C x J)=3; K=k(J) polarized by symmetric theta; L=f_1,1*theta; model intersection heights.',
    scope_checks=checks, deeper_imports_recursively_verified=False, production_VERIFIED=False,
    independent_verifier_receipt=False, original_result_promoted=False,
    canonical_status_changes=[], native_editor_changed=False, native_compile_success_verified=False,
    helper_source=__file__, helper_SHA256=sha(__file__))
q = C / 'book_mathematical_self_audit_v2_20261009.json'
assert not q.exists()
q.write_text(json.dumps(math, ensure_ascii=False, indent=2) + '\n')
print(json.dumps(dict(reading_SHA256=sha(p), mathematical_audit_SHA256=sha(q), actual_pages=14, fresh_views=7)))
