# Guo–Yuan relative successive minima: complete v2 source audit

Controlling source: Ruoyi Guo and Xinyi Yuan, *Nef cone and successive
minima: an example*, arXiv2511.12509v2, submitted19February2026,
internally dated20February. All16 physical pages were actually read in
eight sequential matching complete-text/image displays. Current primary
metadata lists v1 and v2 and no journal reference. November2025 v1 is
unread; the January2026 Hultberg citation must not be assigned these v2
physical pages or literal wording. The acquired Luo–Yu v3 (31 pages)
and GVF foundations v2 (52 pages) remain unread at this checkpoint.

The curve C is smooth projective of genus g>1 over algebraically closed k.
Its Jacobian J must satisfy rho(C times J)=3. A degree-one alpha with
(2g-2)alpha=omega_C determines the Abel–Jacobi map and symmetric principal
theta polarization. The three numerical classes alpha1,theta2,Q use
the explicit addition pullback convention

    f_m,n^*theta=g*m^2*alpha1+n^2*theta2+mn*Q.

Proposition2.2 and its whole proof are on physical7. Theorem2.4 and its
whole proof on9–10 identify both nef and pseudo-effective cones with
a,b>=0 and ab>=g*c^2. Negative c requires m of either sign in the
real approximation step; the printed R>0 qualification is too narrow.
The effective Kodaira divisor belongs on C times J; one printed J is a
typographical slip. The specific rational boundary classes used for
attainment are semiample pullbacks. No claim about arbitrary irrational
real boundary rays being semiample line bundles is needed or imported.

With K=k(J), model C times J -> J, base polarization theta and
L=f_1,1^*theta, heights are intersection against theta2^(g-1), divided
by the algebraic point degree. The curve height divides L^2 times
theta2^(g-1) by2*deg(L_K)=2g. The source does not discard the base
polarization. L is nef on the whole model; its generic restriction has
positive degree g. The main result is a failure of the lower
average-of-minima bound over a higher-dimensional function field.

The two literal internal slips in Lemma3.1 on physical12 are repaired
without replacing the intended main result. First the diagonal restriction
Delta-alpha1-alpha2 has degree-2g on the diagonal, whereas the addition
identity forces+2g there: [2]^*theta has degree4g and the two subtracted
theta pullbacks have total degree2g. Its sign must be reversed in this
convention. The square is unchanged by that sign. Second the line
Q^2 theta2^(g-1)=-2(g-1)! drops a factor g from the immediately preceding
-2g(g-1)!. The lemma statement and all downstream height formulas use
the correct -2g!.

A direct formal coefficient check supplies the needed square: the top
intersection of f_m,n^*theta vanishes, since its target has dimension g.
The coefficient of m^2 n^(2g), using alpha1^2=0 and
alpha1 theta2^g=g!, is

    (g+1)*g*g! + binom(g+1,2)*Q^2 theta2^(g-1)=0.

Hence Q^2 theta2^(g-1)=-2g!. The fiberwise degree-zero cross terms vanish,
giving (a alpha1+b theta2+c Q)L theta2^(g-1)=(a+gb-2c)g!.
This is a formal reconstruction of the imported numerical calculation;
it is not an original theorem or a production-verifier receipt.

For a point closure put a=deg(x)>0,s=b/a,t=c/a. The effective-cone
condition s>=g*t^2 gives

    h(x)/g! >=1+g^2*t^2-2t >=1-1/g^2.

The rational minimizing boundary class is f_g,1^*theta/g^3. Smooth
connected theta divisors H_n pull back to integral divisors E_n; the
automorphism (x,y)->(x,g*i_alpha(x)+y) identifies them with C times H_n.
Their generic points have degree g^3*n and attain the minimum, so form
a generic sequence on the curve. This removes any need to infer
flatness merely from the displayed fibers. Theorem3.2 and its complete
proof on physical12–14 consequently give

    mu_ess=mu_abs=(g-1/g)*(g-1)!,
    h(C_K)=(g-1)*(g-1)!.

For genus2, both minima are3/2 and the curve height is1. The lower
average inequality fails while mu_ess>=h(C_K) holds. Common rescaling
of height units does not change that comparison. The stronger arithmetic
higher-base remarks in the introduction have no full proof here and are
not imported. No refutation of number-field successive minima,
Bogomolov/equidistribution main results, or Hultberg's intended main
gap statements is claimed from this example.

The full ordinary source audit includes all statements, proofs, references
and final addresses. The classical Jacobian/Picard/theta/Bertini background
is disclosed and has not received a new recursively complete primary
audit. Exact finite calibrations record31 genera,558 constrained height
samples and155 attaining divisor degrees. They support the normalization
checks and do not certify universal geometry by finite enumeration.
Imported classical statements and their direct formal consequences can
enter book prose under ordinary source/integration audits; no original
candidate is promoted and no independent model receipt is claimed.

The current book and native catalogue/editor have not changed by this
source evidence export. Book integration is separately staged. Canonical
42 atoms/twelve problems, tier counts and BJ22/P12.2/P12.3/LPWZ statuses
receive no change. Export/upload creates no extra reading or proof credit.
