from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Metric_radial_dependencies_review_20261009'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
out=C/'actual_primary_reading_v1_20261009.json';assert not out.exists()
p=C/'primary_view_preparation_v1_20261009.json';prep=json.loads(p.read_text());assert prep['actual_source_reading_credit']==prep['actually_read_pages']==0
assert sha(prep['manifest_path'])==prep['manifest_SHA256'];rows=json.loads(Path(prep['manifest_path']).read_text());views=[];pairs=[];last=None
for name,s in prep['sources'].items():assert sha(s['path'])==s['SHA256']
for i,row in enumerate(rows,1):
    rp=C/f'primary_notes_v1/note_{i:02d}_receipt.json';a=json.loads(rp.read_text())
    assert a['number']==i and a['source']==row['source'] and a['physical_pages']==row['physical_pages']
    assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
    assert last is None or a['UTC']>last;last=a['UTC']
    assert not row['actually_viewed'] and not row['selected_text_read']
    for k,h in [('image_path','image_SHA256'),('selected_text_path','selected_text_SHA256'),('note_path','note_SHA256')]:assert sha(a[k])==a[h]
    assert a['source_PDF_SHA256']==row['source_PDF_SHA256']==prep['sources'][row['source']]['SHA256']
    views.append(dict(**a,observation_receipt_path=str(rp),observation_receipt_SHA256=sha(rp)))
    pairs.extend((row['source'],x) for x in row['physical_pages'])
assert len(views)==19 and len(pairs)==len(set(pairs))==38
for n,h in prep['protected_core_inputs'].items():assert sha(R/n)==h
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==prep['baseline_commit']
prior={};pinrecords={}
f=R/'source_material/finski_endpoint_dependencies_20261005/selective_reading_progress.json';j=json.loads(f.read_text())
prior['Finski_PLMS2025']=sorted({x for v in j['actual_views'] if v['source_PDF_sha256']==prep['sources']['Finski_PLMS2025']['SHA256'] for x in v['physical_pages']});pinrecords[str(f)]=sha(f)
f=R/'source_material/Ben_Bassat_harmonic_quiver_review_20261008/actual_source_composite_v1_20261008.json';j=json.loads(f.read_text())
prior['Parreau_author']=next(v['physical_pages_read'] for v in j['sources'] if v['SHA256']==prep['sources']['Parreau_author']['SHA256']);pinrecords[str(f)]=sha(f)
f=R/'source_material/BE21_global_psh_approximation_review_20261009/actual_primary_reading_v2_20261009.json';j=json.loads(f.read_text())
prior['BE21_published']=j['cumulative_distinct_page_list'];assert len(prior['BE21_published'])==58;pinrecords[str(f)]=sha(f)
scopes={}
for name,s in prep['sources'].items():
    selected={x for source,x in pairs if source==name};assert selected==set(s['selected_physical_pages']);old=set(prior[name])
    scopes[name]=dict(selected_pages=sorted(selected),selected_count=len(selected),prior_pinned_page_list=sorted(old),overlap_pages=sorted(selected&old),new_unique_pages_relative_to_pinned_prior=sorted(selected-old),new_unique_count=len(selected-old),union_in_these_named_checkpoints=sorted(selected|old),union_count=len(selected|old),total_PDF_pages=s['total_physical_pages'],all_other_historical_checkpoints_aggregated=False,whole_primary_PDF_reading_claim=False)
assert [scopes[n]['new_unique_count'] for n in prep['sources']]==[22,5,6]
add=C/'scope_correction_addendum_v1_20261009.md';assert not add.exists()
add.write_text('# Scope correction to frozen dependency note 16\n\nThe final comparison against the earlier BE21 four-checkpoint union shows physical pages 87 and 88 were already read. The sentence in frozen note 16 suggesting all eight selected pages were new is incorrect. This selection freshly reviews eight pages, adds six unique pages relative to that pinned union, and gives 64 pages in the named five-checkpoint set. Other older BE21 checkpoint unions are not all aggregated by that count. No old note/receipt/preparation has been rewritten. Finski adds 22 unique pages relative to its pinned four-page October 5 selection; Parreau adds five relative to its pinned 23-page October 8 selection. Preparation, export and upload give zero reading credit.\n')
d=C/'exact_diagnostics_v1_20261009.json';diag=json.loads(d.read_text());assert len(diag['families'])==10 and all(x['status'].startswith('PASS') for x in diag['families'])
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — 38 selected source/page pairs actually read in 19 matching displays; all three primaries partial',sources=prep['sources'],actual_selected_source_page_pairs=38,actual_individually_displayed_matching_views=19,views=views,source_scopes=scopes,prior_scope_record_SHA256=pinrecords,scope_correction_addendum=dict(path=str(add),SHA256=sha(add)),preparation_record_SHA256={p.name:sha(p)},exact_diagnostics_SHA256=sha(d),complete_selected_text_read=True,preparation_flags_unchanged=True,whole_primary_PDF_reading_claim=False,whole_book_new_reading_claim=False,active_book_changed=False,native_editor_changed=False,baseline_commit=prep['baseline_commit'],original_results_promoted=[],canonical_status_changes=[],independent_model_receipt=None,general_envelope_theorem_admitted=False,BJ22_Theorem_6_21_repaired=False,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',selected_pairs=38,views=19,new_unique_pairs_in_pinned_comparison=33,record_SHA256=sha(out))))
