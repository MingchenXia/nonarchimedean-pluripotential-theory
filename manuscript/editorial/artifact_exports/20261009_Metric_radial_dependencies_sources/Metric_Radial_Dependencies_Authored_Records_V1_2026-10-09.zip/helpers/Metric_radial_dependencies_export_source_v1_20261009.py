from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,zipfile,shutil
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Metric_radial_dependencies_review_20261009';E=R/'manuscript/editorial'
O=Path('/workspace/book-completion-drafts/research-integration');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
reading=json.loads((C/'actual_primary_reading_v1_20261009.json').read_text());diag=json.loads((C/'exact_diagnostics_v1_20261009.json').read_text())
assert reading['actual_selected_source_page_pairs']==38 and len(reading['views'])==19 and len(diag['families'])==10
prep=json.loads((C/'primary_view_preparation_v1_20261009.json').read_text())
for n,h in prep['protected_core_inputs'].items():assert sha(R/n)==h
paths={k:E/f'Metric_radial_dependencies_source_{k}_20261009.{ext}' for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
record=C/'source_checkpoint_v1_20261009.json';draft=Path('/tmp/Metric_radial_dependencies_source_review_draft_v1_20261009.md')
owned=O/'Metric_Radial_Dependencies_Authored_Records_V1_2026-10-09.zip';full=O/'Metric_Radial_Dependencies_Actual_Source_Evidence_V1_2026-10-09.zip'
dest=E/'artifact_exports/20261009_Metric_radial_dependencies_sources'
assert not any(p.exists() for p in [*paths.values(),record,owned,full,dest]);assert draft.stat().st_size>10000
paths['review'].write_bytes(draft.read_bytes())
paths['reading_notes'].write_text('# Actual selected metric/radial dependency notes, 9 October 2026\n\n38 selected pairs in 19 individually displayed matching images; all three PDFs partial.\n'+''.join('\n---\n\n'+Path(v['note_path']).read_text() for v in reading['views'])+'\n---\n\n'+Path(reading['scope_correction_addendum']['path']).read_text())
files={f'records/{p.name}':p for p in C.glob('*.json')}
files['records/scope_correction_addendum_v1_20261009.md']=Path(reading['scope_correction_addendum']['path'])
for v in reading['views']:
    for k,folder in [('note_path','notes'),('observation_receipt_path','receipts')]:
        p=Path(v[k]);files[f'primary/{folder}/{p.name}']=p
files['manifests/manifest.json']=Path(prep['manifest_path'])
for p in sorted(Path('/tmp').glob('Metric_radial_dependencies_*_v*_20261009.py')):files[f'helpers/{p.name}']=p
files[f'drafts/{draft.name}']=draft
for k in ['review','reading_notes']:files[f'editorial/{paths[k].name}']=paths[k]
def archive(target,entries):
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for n,p in sorted(entries.items()):z.write(p,n)
    with zipfile.ZipFile(target) as z:
        assert len(z.namelist())==len(entries) and z.testzip() is None
        for n,p in entries.items():assert z.read(n)==p.read_bytes()
archive(owned,files);fullfiles=dict(files)
for name,s in reading['sources'].items():fullfiles[f'primary/PDF/{name}.pdf']=Path(s['path'])
for v in reading['views']:
    for k,folder in [('image_path','images'),('selected_text_path','text')]:
        p=Path(v[k]);fullfiles[f'primary/{folder}/{p.name}']=p
archive(full,fullfiles)
artifacts={k:dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p),members=count) for k,p,count in [('authored_records_archive',owned,len(files)),('cloud_source_evidence_archive',full,len(fullfiles))]}
paths['manifest'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — selected dependency source audit',actual_reading=reading,exact_diagnostics=diag,artifacts=artifacts,active_book_changed=False,native_editor_changed=False,GitHub_published=False,canonical_status_changes=[]),ensure_ascii=False,indent=2)+'\n')
paths['artifacts'].write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — every archive member byte-verified',artifacts=artifacts,reading_credit_from_export=0,external_primary_PDF_text_images_uploaded=False,GitHub_published=False),ensure_ascii=False,indent=2)+'\n')
dest.mkdir(parents=True);target=dest/owned.name;shutil.copyfile(owned,target);assert sha(target)==sha(owned)
(dest/'SHA256SUMS').write_text(sha(target)+'  '+target.name+'\n')
(dest/'README.md').write_text(f'''# Selected norm/ray/volume dependencies, 9 October 2026

Finski published physical 1–24, Parreau author 21–26, and BE21 published
87–94 were actually read as 38 selected source/page pairs with nineteen
matching individual displays and chronological notes. All PDFs are partial.
Compared with the specifically pinned old records, 33 selected pairs are
new; the BE21 overlap correction is a fresh addendum to frozen note 16.

Ten elementary diagnostic families calibrate factor-two distances, complex
envelope/Hermitian comparison, actual-limit premises, maximal apartment
systems, signed volume/probability normalization, and local proof scopes.
Published Finski Lemma 2.6 and Corollary 3.5 supply the exact version-specific
ray and FS-isometry interfaces. Their original classification/quantization
dependencies are not all recursively audited.

The {len(files)}-member authored archive contains notes, receipts, diagnostics,
helpers and the review. The {len(fullfiles)}-member cloud archive additionally
preserves the external source PDFs and matching selected text/images.
Preparation/export/upload supply zero reading credit. The 4,661-page book,
native editor and canonical 42 atoms/twelve problems stay unchanged here.
BJ22 critical Siu/general envelopes remain OPEN, LPWZ density UNVERIFIED.
No independent-model receipt or new whole-book pass is claimed.
''')
intro='''**Latest norm/ray/volume dependency checkpoint, 9 October 2026:**
the [selected-source audit](manuscript/editorial/Metric_radial_dependencies_source_review_20261009.md)
reads 38 source/page pairs in nineteen matching displays across Finski's
published norm classification, Parreau's maximal apartment system and
BE21's relative-volume proof. Published Lemma 2.6/Corollary 3.5 supply
version-specific ray/FS locators; ten elementary diagnostics retain norm
factors, limit premises, apartment maximality and signed-volume mass.
The [authored evidence](manuscript/editorial/artifact_exports/20261009_Metric_radial_dependencies_sources/README.md)
includes a correction for overlapping old BE21 pages. All PDFs remain
partial; the book, native editor and canonical statuses stay unchanged.

'''
p=R/'README.md';s=p.read_text();marker='**Latest Reboulet–Witt Nyström revised flat checkpoint, 9 October 2026:**';assert s.count(marker)==1;p.write_text(s.replace(marker,intro+marker,1))
intro='''## Latest selected norm/ray/volume dependencies, 9 October 2026

The [qualified primary audit](Metric_radial_dependencies_source_review_20261009.md)
reads Finski published 1–24, Parreau author 21–26 and BE21 published
87–94 with 38 complete selected source/page pairs, nineteen matching
individual displays and chronological notes. All three PDFs remain partial.
Against the specifically pinned earlier records, 33 selected pairs are
new. Frozen note 16's BE21 novelty sentence is corrected by a fresh
addendum: physical 87–88 overlap the earlier four-checkpoint union.

Published Finski Lemma 2.6 and Corollary 3.5 identify the actual ray and
finite-p FS-isometry interfaces. The factor-two norm convention, genuine
bounded references, actual distance limits, complex envelope/Hermitian
comparison, endpoint continuity and external tensor/quantization proofs
stay explicit. Parreau's ray and Euclidean flat containment require a
maximal apartment system. BE21 adds geometric integrality, a complete
algebraically closed extension before the regular rational point, and
signed determinant rather than probability normalization. Its trivial
classical-disc and nonpure component proof scopes are qualified.

Ten elementary diagnostic families and the [owned evidence archive](artifact_exports/20261009_Metric_radial_dependencies_sources/README.md)
preserve the observations. Preparation/export/upload add zero reading
credit. The 4,661-page book, native editor, both bibliographies and canonical
42 atoms/twelve problems stay unchanged at this source checkpoint.
General BJ22 critical Siu/envelopes remain OPEN, LPWZ density UNVERIFIED,
and the Theorem 6.21 warning binding. No independent-model receipt or
new whole-book pass is claimed. The last complete ordered pass is 4 October.

Continue cloud-only with a staged explanatory integration of the calibrated
ray construction, finite-p/strong topology and volume interfaces; original
general claims still require independent hostile verification. Monitor
incoming author research and regularly publish reviewed authored evidence.
Xean stays suspended.

'''
p=E/'second_reading_and_research_programme_20261002.md';s=p.read_text();marker='## Latest Reboulet–Witt Nyström revised flat source checkpoint, 9 October 2026\n';assert s.count(marker)==1;p.write_text(s.replace(marker,intro+marker,1))
published=[*paths.values(),*sorted(dest.iterdir()),R/'README.md',E/'second_reading_and_research_programme_20261002.md'];assert len(published)==9
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — selected primary checkpoint and byte-verified authored artifacts exported',editorial_files={str(p.relative_to(R)):dict(SHA256=sha(p),bytes=p.stat().st_size) for p in published},artifacts=artifacts,actual_primary_pages=38,actual_matching_views=19,active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],GitHub_published=False,helper_source=__file__)
record.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',files=9,owned_members=len(files),cloud_members=len(fullfiles),record_SHA256=sha(record))))
