from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,fitz,subprocess
from PIL import Image,ImageDraw
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Metric_radial_dependencies_review_20261009'
W=Path('/tmp/Metric_radial_dependencies_primary_views_v1_20261009')
N=C/'primary_notes_v1';out=C/'primary_view_preparation_v1_20261009.json'
assert not any(p.exists() for p in [C,W]);C.mkdir();W.mkdir();N.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
bookprep=json.loads((R/'source_material/Reboulet_asymptotic_FS_review_20261009/staging_preparation_v1_20261009.json').read_text())
names=sorted(set(bookprep['other_active_TeX_preserved'])|{n for n in bookprep['after'] if n.endswith('.tex')});assert len(names)==425
names+=['manuscript/book.pdf','manuscript/bibliography/ComplexGeometry.bib','manuscript/bibliography/NonArchimedean.bib','output/open_problems_catalogue_2026-10-03.tex','output/open_problems_catalogue_2026-10-03.pdf','README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']
protected={n:sha(R/n) for n in names}
sources=[('Finski_PLMS2025','source_material/finski_endpoint_dependencies_20261005/Finski_submultiplicative_author_PLMS.pdf','1d0c7c19f3d5bf36aada5ac7f2530c9b1bafb8de0264ad1ddad84edd7260b740',47,list(range(1,25))),('Parreau_author','source_material/Ben_Bassat_harmonic_quiver_dependencies_20261008/Parreau_affine_norms_author.pdf','a02e84c63418a5e7afd6890dfc4cc72bb48096639fe60f025071426bd122bc1a',41,list(range(21,27))),('BE21_published','source_material/Ben_Bassat_harmonic_quiver_dependencies_20261008/Boucksom_Eriksson_2021_published.pdf','f9b8d54cfb2733486f35d450f5f763acf81a51816368ccd2c24c0663845d84f9',125,list(range(87,95)))]
views=[];pdfs={}
for key,name,pin,total,selected in sources:
    pdf=R/name;assert sha(pdf)==pin
    pdfs[key]=dict(path=str(pdf),bytes=pdf.stat().st_size,SHA256=pin,total_physical_pages=total,selected_physical_pages=selected,whole_PDF_selected=False)
    with fitz.open(pdf) as d:
        assert len(d)==total
        for i in range(0,len(selected),2):
            pp=selected[i:i+2];panels=[];texts=[]
            for n in pp:
                pix=d[n-1].get_pixmap(matrix=fitz.Matrix(1.5,1.5),alpha=False)
                panels.append(Image.frombytes('RGB',[pix.width,pix.height],pix.samples))
                texts.append(f'{key} SELECTED PRIMARY PHYSICAL PAGE {n}\n'+d[n-1].get_text())
            canvas=Image.new('RGB',(sum(p.width for p in panels),max(p.height for p in panels)+28),'white');draw=ImageDraw.Draw(canvas);x=0
            for n,panel in zip(pp,panels):draw.text((x+8,8),f'{key} physical {n}',fill='black');canvas.paste(panel,(x,28));x+=panel.width
            number=len(views)+1;ip=W/f'sheet_{number:02d}.png';tp=W/f'sheet_{number:02d}.txt';canvas.save(ip);tp.write_text('\n\n'.join(texts))
            views.append(dict(number=number,source=key,physical_pages=pp,path=str(ip),image_SHA256=sha(ip),selected_text_path=str(tp),selected_text_SHA256=sha(tp),source_PDF_SHA256=pin,actually_viewed=False,selected_text_read=False))
assert len(views)==19 and sum(len(v['physical_pages']) for v in views)==38
mp=W/'manifest.json';mp.write_text(json.dumps(views,ensure_ascii=False,indent=2)+'\n')
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — selected original dependency views prepared; zero reading credit',sources=pdfs,prepared_source_page_pairs=38,prepared_views=19,manifest_path=str(mp),manifest_SHA256=sha(mp),protected_core_inputs=protected,baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),actual_source_reading_credit=0,actually_read_pages=0,whole_primary_PDF_reading_claim=False,whole_book_new_reading_claim=False,active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',prepared_source_page_pairs=38,prepared_views=19,record_SHA256=sha(out))))
