# Original metric/radial dependency actual view 14

UTC: 2026-10-09T04:02:28.892452+00:00. Source: Parreau_author. Physical pages: 23, 24.

Read the complete selected text and displayed matching rendered image.

Parreau author physical pages 23–24 keep the spherical building at infinity separate from the full CAT(0) boundary for an arbitrary chosen apartment system. Corollary 2.19 identifies the former with the Tits-metric subspace of endpoints of rays contained in apartments. With the maximal system, Proposition 2.18 makes all ray endpoints included. A nonessential model has a trivial Euclidean factor; its boundary is a spherical join with that factor's sphere, so it is not merely the standard simplicial spherical-building realization. This matters when passing between determinant-normalized norms and the full norm space with its scalar direction.

Definition 2.20 modifies the Kleiner–Leeb geometric formulation to include noncomplete buildings. It expressly includes the ray-from-every-basepoint asymptotic property, apartment containment of segments/rays/lines (EB3), Weyl chart transitions (EB4), and finite angle rigidity (EB2). Proposition 2.21 equates this formulation with Tits buildings equipped with their maximal apartment system; it does not remove maximality. Its forward proof uses Proposition 2.18 for ray containment and constructs asymptotic rays from the sector axioms.

The reverse proof invokes Kleiner–Leeb Lemmas 4.1.2,3.4.1,3.4.2, restated as Lemmas 2.22–2.23; their original proofs are not printed here. These identify germs with metric directions and establish chamber-image rigidity. The opposite-chamber argument uses a full geodesic in an apartment, and the auxiliary Lemma 2.24 that chambers with the same interior ray coincide. Its proof continues on page 25, not complete in this view. Building CAT(0) metric completeness, completeness of a ground field, and maximality of the chosen apartment atlas are different conditions; none is silently substituted for another. No particular norm-apartment maximality is established by these two general-building pages.
