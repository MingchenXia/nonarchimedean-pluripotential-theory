# Original metric/radial dependency actual view 17

UTC: 2026-10-09T04:03:47.327924+00:00. Source: BE21_published. Physical pages: 89, 90.

Read the complete selected text and displayed matching rendered image.

BE21 published pages 89–90 (printed 88–89) give Lemma 9.4: scalar extensions of bounded submultiplicative graded norms remain so, and their total relative volumes differ by o(m^(n+1)). The proof uses extension invariance of finite-norm d_infinity, Theorem 6.6's o(m) sup-norm extension error, determinant comparison Proposition 2.14, and N_m log N_m=O(m^n log m). None of this requires an exact arbitrary sup-norm extension equality; the logarithmic-rank determinant defect vanishes after normalization.

Theorem 9.5 adds geometric integrality to the Section 9 hypotheses and proves existence of the signed total determinant-volume limit for any L. Definition 9.6 uses n!/m^(n+1), distinct from the probability spectral mean 1/(m N_m). If L is not big, N_m=o(m^n) and the O(m N_m) volume bound gives a zero normalized limit. That alone is not a probability spectral-distribution theorem in degrees of zero rank.

For big L the proof explicitly passes to a complete algebraically closed field using Lemma 9.4; geometric integrality keeps X integral. A regular K-rational point and regular parameters are then available. This supplies the rational-regular-point reduction missing from a bare application of CM15 over an arbitrary original field, with the scalar-extension error recorded rather than omitted. Cohen completion gives the lexicographic initial-term valuation trivial on K. Each valuation leaf has dimension at most one, Gamma_m has cardinality N_m, and bigness yields full generated lattice Z^(n+1). The uniform linear coordinate bound is explicitly required, with the Okounkov-body results and cited Boucksom lemmas as external inputs. Their proofs are not on these pages.

The final paragraph chooses normalized initial monomials and begins determinant/leaf-norm comparison, continued on page 91. Therefore these pages read the essential reduction and theorem signature, but not yet its full local proof. No unsigned dp convergence is inferred merely from signed determinant-volume convergence, and no original general theorem or open-problem solution is promoted.
