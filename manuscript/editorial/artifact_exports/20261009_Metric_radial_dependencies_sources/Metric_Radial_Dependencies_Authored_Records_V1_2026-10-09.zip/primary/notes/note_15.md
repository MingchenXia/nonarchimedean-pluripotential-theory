# Original metric/radial dependency actual view 15

UTC: 2026-10-09T04:02:49.718662+00:00. Source: Parreau_author. Physical pages: 25, 26.

Read the complete selected text and displayed matching rendered image.

Parreau author pages 25–26 finish Lemma 2.24 by showing the common chamber intersection is open as well as closed, and complete the germ-apartment (GG) step of Proposition 2.21. The text then explicitly says the apartment system is henceforth assumed maximal. That premise applies to Proposition 2.25: every entire Euclidean totally geodesic subspace is contained in an apartment, so apartments are maximal-dimensional Euclidean flats and ambient isometries preserve them. It is not a conclusion about arbitrary Euclidean subsets or a chosen nonmaximal atlas.

The printed proof of 2.25 chooses a line of maximal direction-facet dimension in a flat E. A positive angular gap to competing lower-dimensional facets prevents a nearby ray from leaving its containing apartment; a first exit would contradict the two-point Weyl-hull agreement. A cone around the line, together with the whole line, spans E by convexity. This is a Euclidean CAT(0) building argument, not a corresponding general result for non-strictly-convex L1 norm metrics.

Proposition 2.26 characterizes uniqueness of apartments for regular lines under thickness of the building at infinity; Proposition 2.27 uses thickness to deduce that isometries preserve Weyl chambers. These additional thickness and regularity premises must not be dropped. The initial setup of Section 3 only assumes a field with a real-valued valuation and a finite-dimensional vector space: it does not at this point impose completeness, discrete valuation, spherical completeness, or nontrivial valuation. Those later requirements must be recovered from the precise norm propositions, not from the title GL_n(F).

This closes this checkpoint's selected Parreau pages 21–26. Page 26 was already reviewed in the earlier October 8 field-hypothesis addendum, so this selection adds five unique pages rather than six; the published journal pagination and this author-PDF pagination are not equated. The selected general maximal-atlas theorem and flat-containment proof do not establish maximality of a particular basis-norm atlas over every valued field. No full 41-page or whole-book reading is claimed.
