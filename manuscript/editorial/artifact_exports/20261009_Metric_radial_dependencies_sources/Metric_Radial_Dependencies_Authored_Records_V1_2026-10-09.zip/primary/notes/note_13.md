# Original metric/radial dependency actual view 13

UTC: 2026-10-09T04:02:08.897669+00:00. Source: Parreau_author. Physical pages: 21, 22.

Read the complete selected text and displayed matching rendered image.

Parreau author-PDF physical pages 21–22 contain the Weyl convex-hull compatibility and the full maximal-apartment-system argument. Proposition 2.14 identifies a two-point Weyl hull independently of its containing apartment. Lemma 2.15 extends endpoint agreement for a segment-type-preserving isometry to the appropriate Weyl hull; Corollary 2.16 says a full model-space type-preserving isometry agrees with an original apartment on every bounded subset. This is an inductive, eventually locally identical limit, not just an arbitrary pointwise metric limit.

Proposition 2.17 constructs the unique maximal system containing the initial apartment system from all type-preserving model-space isometries, equivalently those inductive apartment limits. Its proof verifies the building axioms and opposite-chamber condition using compatible apartments on an exhaustion by two-sided Weyl hulls. The earlier Lemmas 1.13,1.18 and Theorem 1.21 are explicit dependencies, not proved anew on these two pages.

Proposition 2.18's proof is entirely present on physical page 22: maximality is equivalent to every geodesic ray and geodesic line being contained in an apartment. The converse starts with a regular interior Weyl direction whose two-sided hull exhausts the model space. For maximality implies ray containment, apartments through x=r(0) and y_n=r(n) are chosen to agree on a common opposite chamber region; this creates compatible restrictions on an exhaustion. Closure under inductive limits places the resulting full apartment in the maximal system. The line case uses opposite chambers at a point.

Therefore the proposition is not a statement that every ray of every chosen nonmaximal apartment system is contained in one of its original apartments. Applying it to norm apartments requires identification of the relevant chosen system with the maximal system, or a separate direct containment argument. Reading the general building proposition cannot by itself prove the standard basis apartments are maximal over an arbitrary valued field. Both these pages are newly selected relative to the earlier Parreau checkpoint. These are full selected-page observations only, not a full 41-page audit, not proof of an arbitrary norm-ray FS isometry.
