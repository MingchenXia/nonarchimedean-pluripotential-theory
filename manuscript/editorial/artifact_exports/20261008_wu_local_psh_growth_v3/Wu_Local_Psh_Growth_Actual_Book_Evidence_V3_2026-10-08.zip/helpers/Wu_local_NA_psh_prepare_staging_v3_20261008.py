# Frozen preceding v2 helper SHA256: af2dbf24fb1e45fdfb7f11f4e3e6463b784a9e66e7d04f03935deff56306345f
# Frozen v1 staging helper SHA256: 07a3eb2e6f991f70a4fdce589866fad91e14a4c36264824f0b62f84d0b8d0e59
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, re, subprocess

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R/'source_material/Wu_local_NA_psh_review_20261008'
B = Path('/workspace/book-completion-drafts/polarized-CY-finiteness-staging-v2-20261008')
S = Path('/workspace/book-completion-drafts/wu-local-psh-staging-v3-20261008')
D = Path('/workspace/book-completion-drafts/wu-local-psh-integration-v3-20261008')
out = C/'staging_preparation_v3_20261008.json'
assert not out.exists() and not S.exists()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
cp = C/'source_checkpoint_v1_20261008.json'
p = json.loads(cp.read_text())
assert p['actual_source_pages']==55 and p['actual_images']==28
for n,h in p['protected_core_inputs'].items():
    assert sha(n)==h
for n,h in p['editorial_files'].items():
    assert sha(n)==h
publication = C/'GitHub_source_publication_v1_20261008.json'
assert len(json.loads(publication.read_text())['files'])==9
assert sha(B/'manuscript/book.pdf')==sha(R/'manuscript/book.pdf')
shutil.copytree(B,S,ignore=shutil.ignore_patterns(
    '*.pdf','*.aux','*.log','*.fls','*.fdb_latexmk','*.bbl','*.blg',
    '*.toc','*.out','*.idx','*.ind','*.ilg','__pycache__'))
changed = [Path('manuscript/parts/part2/ch19_cld_examples.tex'),
           Path('manuscript/appendices/appL_provenance.tex'),
           Path('manuscript/bibliography/NonArchimedean.bib')]
before = {str(n):sha(S/n) for n in changed}
assert all(sha(R/n)==h for n,h in before.items())
z=S/changed[0]
t=z.read_text()
marker=r'\section{A first CLD--BFJ comparison}'
assert t.count(marker)==1
z.write_text(t.replace(marker,(D/'ch19_local_psh_fragment.tex').read_text()+marker,1))
z=S/changed[1]
z.write_text(z.read_text()+(D/'appL_local_psh_fragment.tex').read_text().rstrip()+'\n')
assert not z.read_bytes().endswith(b'\n\n')
z=S/changed[2]
z.write_text(z.read_text()+(D/'bibliography_fragment.bib').read_text().rstrip()+'\n')
assert z.read_text().count('@misc{Wu26LocalNApshV1,')==1
tex = {str(Path(n).relative_to(R)):h for n,h in p['protected_core_inputs'].items()
       if Path(n).is_relative_to(R/'manuscript') and Path(n).suffix=='.tex'}
assert len(tex)==425
unchanged = {n:h for n,h in tex.items() if Path(n) not in changed}
assert len(unchanged)==423
for n,h in unchanged.items():
    assert sha(R/n)==sha(S/n)==h
assert sha(S/'manuscript/bibliography/ComplexGeometry.bib')==sha(R/'manuscript/bibliography/ComplexGeometry.bib')
formal=[]
envs=['theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important']
for n in changed[:2]:
    old=(R/n).read_text()
    new=(S/n).read_text()
    starts=re.findall(r'\\begin\{('+('|'.join(envs))+r')\}',old)
    assert starts==re.findall(r'\\begin\{('+('|'.join(envs))+r')\}',new)
    for env in envs:
        blocks=re.findall(r'\\begin\{'+env+r'\}.*?\\end\{'+env+r'\}',old,re.S)
        assert all(block in new for block in blocks)
    tags=re.findall(r'\\tag\{([^}]+)\}',old)
    assert tags==re.findall(r'\\tag\{([^}]+)\}',new)
    formal.append(dict(path=str(n),historical_formal_starts=len(starts),
                       historical_proofs=starts.count('proof'),historical_manual_tags=len(tags),
                       new_manual_tags=[]))
for rel in ['README.md','manuscript/editorial/second_reading_and_research_programme_20261002.md']:
    shutil.copy2(R/rel,S/rel)
for rel in p['editorial_files']:
    q=Path(rel)
    target=S/q.relative_to(R)
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(q,target)
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — local psh growth and qualified envelope unit prepared in isolated stage',
    stage_path=str(S),baseline_stage_path=str(B),
    baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),
    draft_path=str(D),before=before,after={str(n):sha(S/n) for n in changed},
    draft_fragments={str(z):sha(z) for z in sorted(D.iterdir())},
    active_inputs_preserved={str(n):sha(R/n) for n in changed},
    other_active_TeX_preserved=unchanged,
    unchanged_bibliography=dict(path='manuscript/bibliography/ComplexGeometry.bib',SHA256=sha(R/'manuscript/bibliography/ComplexGeometry.bib')),
    historical_formal_blocks_preserved=formal,active_book_PDF_SHA256=sha(R/'manuscript/book.pdf'),
    native_catalogue_preserved={str(Path(n).relative_to(R)):h for n,h in p['protected_core_inputs'].items() if Path(n).is_relative_to(R/'output')},
    source_checkpoint_SHA256=sha(cp),
    actual_primary_reading_SHA256=sha(C/'actual_primary_reading_v1_20261008.json'),
    exact_diagnostics_SHA256=sha(C/'exact_diagnostics_v1_20261008.json'),
    source_publication_SHA256=sha(publication),new_bibliographic_keys=['Wu26LocalNApshV1'],
    new_formal_environments=0,original_results_promoted=[],independent_model_receipt=None,
    canonical_status_changes=[],active_book_changed=False,GitHub_published=False,
    actual_book_reading_credit=0,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',record_SHA256=sha(out),
                     other_TeX=len(unchanged),historical=formal)))
