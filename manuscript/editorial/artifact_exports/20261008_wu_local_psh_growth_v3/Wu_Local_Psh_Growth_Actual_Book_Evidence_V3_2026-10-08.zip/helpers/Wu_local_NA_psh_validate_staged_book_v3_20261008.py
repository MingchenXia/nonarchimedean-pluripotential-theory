# Frozen preceding v2 helper SHA256: 8e945d1a279b221a21c7069e9e4a74be837ea1a4ac1ee7078e379b3f70c979b7
# Frozen v1 validation helper SHA256: a899ef3a68371af9f9e06c29c4351320cb8e7198d2332e1d125860b2837a929c
# Adapted validation template SHA256: 9324679aad84d3a21164bdd40310e52f77fa645ab172dd537b85bb0a6a9a1363
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,subprocess,shutil,time,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Wu_local_NA_psh_review_20261008';S=Path('/workspace/book-completion-drafts/wu-local-psh-staging-v3-20261008')
O=C/'staged_book_validation_v3_20261008.json';log=C/'staged_book_validation_v3_20261008.log';snap=C/'compiled_staged_v3';assert not O.exists() and not log.exists() and not snap.exists()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
pin=C/'staging_preparation_v3_20261008.json';p=json.loads(pin.read_text())
for n,h in p['after'].items():assert sha(S/n)==h
start=datetime.now(timezone.utc).isoformat();tick=time.monotonic();env=os.environ.copy();env.update(TEXMFHOME='/workspace/.texlive',TEXMFCONFIG='/workspace/.texlive/texmf-config',TEXMFVAR='/workspace/.texlive/texmf-var')
with log.open('w') as dst:run=subprocess.run(['bash','scripts/validate-manuscript.sh'],cwd=S,env=env,stdout=dst,stderr=subprocess.STDOUT)
for n,h in p['after'].items():assert sha(S/n)==h
for n,h in p['active_inputs_preserved'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==p['active_book_PDF_SHA256']
for n,h in p['native_catalogue_preserved'].items():assert sha(R/n)==h
for n,h in p['other_active_TeX_preserved'].items():assert sha(R/n)==sha(S/n)==h
obj=dict(start_UTC=start,end_UTC=datetime.now(timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-tick,status='DONE' if run.returncode==0 else 'FAILED',returncode=run.returncode,command=['bash','scripts/validate-manuscript.sh'],cwd=str(S),log_path=str(log),log_SHA256=sha(log),staging_preparation_SHA256=sha(pin),source_input_hashes=p['after'],active_book_changed=False,native_catalogue_preserved=True,GitHub_published=False,actual_book_reading_credit=0,original_results_promoted=[],canonical_status_changes=[],helper_source=__file__)
if run.returncode==0:
    snap.mkdir()
    for suffix in ['pdf','aux','toc','bbl','idx','ind','ilg','log','out','fls']:
        q=S/'manuscript'/f'book.{suffix}'
        if q.exists():shutil.copy2(q,snap/q.name)
    q=snap/'book.pdf'
    with fitz.open(q) as doc:pages=len(doc)
    obj['compiled_PDF']=dict(path=str(q),bytes=q.stat().st_size,SHA256=sha(q),physical_pages=pages)
O.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status=obj['status'],record_SHA256=sha(O),compiled_PDF=obj.get('compiled_PDF'),elapsed_seconds=obj['elapsed_seconds'])));raise SystemExit(run.returncode)
