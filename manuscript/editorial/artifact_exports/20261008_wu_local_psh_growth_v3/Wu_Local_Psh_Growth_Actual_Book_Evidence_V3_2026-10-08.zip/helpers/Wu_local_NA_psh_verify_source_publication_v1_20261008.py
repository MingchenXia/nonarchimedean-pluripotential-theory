from pathlib import Path
from datetime import datetime, timezone
import subprocess, json, hashlib

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R/'source_material/Wu_local_NA_psh_review_20261008'
out = C/'GitHub_source_publication_v1_20261008.json'
assert not out.exists()
repo = 'MingchenXia/nonarchimedean-pluripotential-theory'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
api = lambda ep: json.loads(subprocess.check_output(['gh','api',ep],cwd=R,text=True))
local = json.loads((C/'local_source_commit_v1_20261008.json').read_text())
head = local['commit']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()==head
assert api(f'repos/{repo}/git/ref/heads/work')['object']['sha']==head
main = api(f'repos/{repo}/git/ref/heads/main')['object']['sha']
assert main=='00957114db21b627e97369563032ceda9cea09c7'
tree = api(f'repos/{repo}/git/trees/{head}?recursive=1')
assert not tree['truncated']
mapping = {x['path']:x for x in tree['tree'] if x['type']=='blob'}
rows = []
for rel,h in local['files'].items():
    p=R/rel
    assert sha(p)==h
    blob = subprocess.check_output(['git','hash-object',str(p)],cwd=R,text=True).strip()
    assert mapping[rel]['sha']==blob and mapping[rel]['size']==p.stat().st_size
    rows.append(dict(path=rel,bytes=p.stat().st_size,SHA256=h,local_and_remote_Git_blob_SHA1=blob))
assert len(rows)==9
cp = json.loads((C/'source_checkpoint_v1_20261008.json').read_text())
for p,h in cp['protected_core_inputs'].items():
    assert sha(p)==h
obj = dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — nine authored source/progress/artifact remote blobs verified',
    repository=repo,branch='work',commit=head,main_unchanged=main,files=rows,
    actual_primary_pages=55,actual_matching_images=28,active_book_pages=4647,
    active_book_changed=False,general_envelope_theorem_admitted=False,
    weak_local_global_comparison_admitted=False,external_primary_PDF_text_images_uploaded=False,
    reading_credit_from_upload=0,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',commit=head,record_SHA256=sha(out))))
