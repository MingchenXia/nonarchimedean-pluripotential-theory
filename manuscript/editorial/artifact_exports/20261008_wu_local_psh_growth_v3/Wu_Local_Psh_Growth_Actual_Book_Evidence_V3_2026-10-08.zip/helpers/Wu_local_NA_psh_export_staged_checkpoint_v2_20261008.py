from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, shutil, zipfile, fitz

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Wu_local_NA_psh_review_20261008'
S=Path('/workspace/book-completion-drafts/wu-local-psh-staging-v2-20261008')
E=R/'manuscript/editorial'
O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
prep=load('staging_preparation_v2_20261008.json')
release=load('staged_book_release_checks_v2_20261008.json')
reading=load('actual_staged_book_reading_v2_20261008.json')
post=load('post_render_checks_v2_20261008.json')
math=load('staged_mathematical_self_audit_v2_20261008.json')
underfull=load('staged_underfull_delta_v2_20261008.json')
assert reading['status'].startswith('DONE') and not reading['remaining_repairs']
assert all(x['returncode']==0 for x in post['checks'])
assert not underfull['added_blocks'] and not underfull['removed_blocks']
assert math['source_scope'].startswith('Wu 2609.27610v1')
for n,h in prep['after'].items():
    assert sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():
    assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
np=release['PDF']['physical_pages']
nb=reading['actual_unique_book_pages']
nv=reading['fresh_matching_views']
assert nb==reading['fresh_complete_text_and_individually_displayed_pages']==len(release['selected_book_physical_pages'])
assert nv==len(reading['views']) and nb>0
assert reading['reused_exact_complete_text_and_rendered_pixel_pages']==0
full=O/'Non-Archimedean_Pluripotential_Theory_Local_Psh_Growth_Staged_Preview_V2_2026-10-08.pdf'
review=O/'Wu_Local_Psh_Growth_Staged_Book_Review_V2_2026-10-08.pdf'
minimal=O/'Wu_Local_Psh_Growth_Staged_Minimal_Source_V2_2026-10-08.zip'
evidence=O/'Wu_Local_Psh_Growth_Actual_Book_Evidence_V2_2026-10-08.zip'
record=C/'staged_export_v2_20261008.json'
paths={k:E/f'Wu_local_NA_psh_staged_integration_{k}_v2_20261008.{ext}'
       for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
assert not any(p.exists() for p in [full,review,minimal,evidence,record,*paths.values()])
shutil.copy2(release['PDF']['path'],full)
assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as book:
    d=fitz.open()
    for n in release['selected_book_physical_pages']:
        d.insert_pdf(book,from_page=n-1,to_page=n-1)
    assert len(d)==nb
    d.set_metadata(dict(title='Local psh growth and envelope scope — actual book review',
                        subject=f'{nb} genuinely reviewed pages; export gives no reading credit.'))
    d.save(review,garbage=4,deflate=True)
    d.close()
paths['audit'].write_text(f'''# Local psh growth and qualified envelope claims: book integration

Date: 8 October 2026. The validated staged edition has {np:,} pages. An
unnumbered paragraph in Section 19.8 connects the existing common model core
with growth at infinity and local/global integrability. New L.96, “Local psh
growth and the scope of envelopes,” gives explicit affine-line and
localization examples and preserves the unresolved proof dependencies of
Wu's arXiv:2609.27610v1, posted 23 September 2026. The general weak/global
comparison and geometrically-unibranch envelope claims are not admitted.
An intended corrected main theorem may be true; no counterexample to it is
asserted. No original general theorem or independent-model receipt is claimed.

All 55 primary pages were actually read in 28 individually displayed matching
images with complete selected text and sequential notes/receipts. Thirteen
elementary diagnostic families pass. The nine-file authored source checkpoint
is published and remotely verified in cb78bba2fde97d4de0272f4506043ddf72651b4d.
The extraction font warning remains recorded. The source's cited external
proofs are not recursively certified. An exact-title arXiv metadata query
found no matches for the two APW dependencies; this is metadata evidence
only, not a proof of their unavailability.

The final book review genuinely reads all {nb} selected pages in {nv}
individual matching displays, with complete text and sequential notes.
It covers the new contents row, the entire local/global common-core section
and seams, the complete L.96 and appendix seams, the entire index and the
new Wu26L bibliography entry. Prepared flags remain false. The first
compiled stage had one 17.51697pt overflow in the introductory title/citation/
arXiv line. That stage and its failed release helper remain frozen; one
diagnostic page was actually read and displayed, with zero final gate credit.
Isolated v2 moves the posted date into a separate sentence and relies on the
exact versioned bibliography for the identifier. The mathematics is unchanged.
All final v2 pages are freshly read; no v1 pixel-reuse credit is claimed.

Required full validation, six existing regression tests, reference closure
and canonical inventory pass. Fresh post-render references/inventory and
direct semantic, notation, delimiter, source, whitespace and rendered audits
pass. The legacy writing audit is unavailable and is not reported as an
automated pass. There are no TeX errors, LaTeX/package/pdfTeX warnings,
missing glyphs, overfull boxes, unresolved references/citations or rerun
requests. All 955 underfull diagnostics are inherited with identical
normalized text and multiplicities. All
{release['all_prior_numbered_label_values_preserved']:,} prior numbered values
and {release['bibliography']['prior_labels_preserved']} citation labels are
preserved. One semantic label, one contents row, Wu26L and two index terms are
new. All {release['index']['accepted']} index entries are accepted without
warnings or rejections, and all {release['navigation']['internal_links']:,}
internal links pass. External URL availability is not certified.

The two changed TeX roots preserve 92 historical environment blocks,
including 25 proofs, and six manual tags. No formal environment or manual
tag is added. The other 423 TeX inputs and the ComplexGeometry bibliography
are unchanged. The native catalogue/editor and all 42 atoms/twelve formal
problems retain their statuses: general BJ22 critical homogeneous
Siu/envelopes OPEN and LPWZ density UNVERIFIED. The warning about BJ22
Theorem 6.21 is preserved. The last complete ordered whole-book pass remains
4 October; this is a scoped review.

The mathematical audit checks the following boundaries:

'''+''.join(f'{i}. {x}\n\n' for i,x in enumerate(math['checks'],1))+'''This byte-verified export does not itself claim cloud activation or remote
publication of the book unit. Those actions have separate subsequent records.
Export and upload add zero reading credit.
''')
paths['reading_notes'].write_text(
    f'# Actual final rendered-book notes, 8 October 2026\n\n'
    f'{nb} pages freshly read in {nv} individual v2 matching displays. '
    'No reuse; preparation flags remain frozen.\n'+
    ''.join('\n---\n\n'+Path(v['sequential_note_path']).read_text() for v in reading['views']))
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md'
prog=(R/programme).read_text()
marker='## Latest Wu local psh primary checkpoint, 8 October 2026\n'
assert prog.count(marker)==1
header=f'''## Latest Wu local psh book checkpoint, 8 October 2026

The validated edition has {np:,} pages. The
[integration audit](Wu_local_NA_psh_staged_integration_audit_v2_20261008.md)
adds an unnumbered paragraph in Section 19.8 and L.96. Affine FS lower
coercivity, upper logarithmic growth and decreasing global approximation are
kept distinct. The radial example has a lower bound, quadratic growth and
locally finite curvature with infinite total mass. The localization example
controls actual pole orders rather than a nonradical formal denominator.
The source's general weak/global and envelope claims remain unadmitted;
this is not a counterexample to an intended corrected main theorem.

All 55 primary pages were read in 28 individual matching views. The final
book gate freshly reads {nb} pages in {nv} individual v2 matching displays.
The first stage's one introductory prose overflow and diagnostic view remain
frozen; the corrected v2 reruns full validation and adds no reuse credit.
Post-render checks pass. All 955 underfull diagnostics, prior numbered values
and citation labels are preserved. Other 423 TeX inputs, ComplexGeometry,
92 historical blocks including 25 proofs, and six manual tags are unchanged.

The [activation record](Wu_local_NA_psh_cloud_activation_v2_20261008.json)
controls the cloud edition; remote publication receives a separate record.
The native catalogue/editor and 42 atoms/twelve formal problems are unchanged.
General BJ22 critical homogeneous Siu/envelopes remain OPEN; LPWZ density
UNVERIFIED. No original general theorem, independent receipt or fresh complete
book pass is claimed. The last ordered whole-book pass remains 4 October.

Continue cloud-only with related primary literature and sequential research,
including identification and verification of the source's tropical/curve
dependencies. The exact-title APW arXiv query found no matches and has zero
proof-reading credit. Check incoming author updates and publish verified
evidence normally. Xean remains suspended.

'''
(S/programme).write_text(prog.replace(marker,header+marker,1))
readme=(R/'README.md').read_text()
assert readme.count('**4,647 pages**')==1
readme=readme.replace('**4,647 pages**',f'**{np:,} pages**')
marker='**Latest Wu local psh source checkpoint, 8 October 2026:**'
assert readme.count(marker)==1
intro=f'''**Latest checked local psh book integration, 8 October 2026:** the
[integration audit](manuscript/editorial/Wu_local_NA_psh_staged_integration_audit_v2_20261008.md)
adds the growth paragraph in Section 19.8 and new L.96. It distinguishes
coercive lower growth, upper majorants, decreasing approximation, local
integrability and actual pole orders. General weak/global comparison and
envelope claims from arXiv:2609.27610v1 remain qualified. All {nb} final
book pages were freshly read in {nv} individual matching displays; full
validation and post-render gates pass. The first stage's introductory overflow
is preserved and corrected in v2. The
[activation record](manuscript/editorial/Wu_local_NA_psh_cloud_activation_v2_20261008.json)
controls the {np:,}-page cloud edition. No original general theorem, new
whole-book pass or canonical status change is claimed.

'''
(S/'README.md').write_text(readme.replace(marker,intro+marker,1))
oldzip=O/'Polarized_CY_Finiteness_Staged_Minimal_Source_V2_2026-10-08.zip'
with zipfile.ZipFile(oldzip) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    members=old.namelist()
    assert len(members)==len(set(members))==472
    for n in members:
        assert (S/n).is_file()
        z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
    for n in z.namelist():
        assert z.read(n)==(S/n).read_bytes()
paths['manifest'].write_text(json.dumps(dict(
    UTC=datetime.now(timezone.utc).isoformat(),status='DONE — source/math/rendered staged gates',
    staging_preparation_SHA256=sha(C/'staging_preparation_v2_20261008.json'),
    validation_SHA256=sha(C/'staged_book_validation_v2_20261008.json'),
    release_checks=release,actual_reading=reading,post_render_checks=post,
    mathematical_self_audit=math,underfull_delta=underfull,
    failed_v1_release_record=load('failed_release_gate_v1_20261008.json'),
    source_input_hashes=prep['after'],
    progress_document_hashes={n:sha(S/n) for n in ['README.md',programme]},
    active_book_changed=False,GitHub_published=False,canonical_status_changes=[],
    original_results_promoted=[],independent_model_receipt=None),
    ensure_ascii=False,indent=2)+'\n')
files={f'records/{q.name}':q for q in C.glob('*.json')}
for q in sorted(C.glob('staged_book_validation_*.log')):
    files['records/'+q.name]=q
files['records/'+review.name]=review
files['records/final_views_manifest.json']=Path(release['manifest_path'])
for v in reading['views']:
    for key,folder in [('path','images'),('selected_text_path','text'),
                       ('sequential_note_path','notes'),('observation_receipt_path','receipts')]:
        q=Path(v[key]);files[folder+'/'+q.name]=q
for q in (C/'primary_notes_v1').iterdir():
    files['authored_primary_notes/'+q.name]=q
for q in (C/'failed_release_v1_diagnostic_view').iterdir():
    files['failed_v1_diagnostic/'+q.name]=q
for key in ['audit','reading_notes','manifest']:
    q=paths[key];files['editorial/'+q.name]=q
for q in sorted(Path('/tmp').glob('Wu_local_NA_psh_*_20261008.py')):
    files['helpers/'+q.name]=q
for suffix in ['v1','v2']:
    D=Path(f'/workspace/book-completion-drafts/wu-local-psh-integration-{suffix}-20261008')
    for q in D.iterdir():
        if q.is_file():files[f'draft_{suffix}/'+q.name]=q
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
    assert len(z.namelist())==len(files)
    for n,q in files.items():assert z.read(n)==q.read_bytes()
artifacts=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — byte-verified staged book exports',
    full_book_PDF=dict(path=str(full),bytes=full.stat().st_size,SHA256=sha(full),physical_pages=np),
    actual_book_review_PDF=dict(path=str(review),bytes=review.stat().st_size,SHA256=sha(review),physical_pages=nb),
    minimal_TeX_source_archive=dict(path=str(minimal),bytes=minimal.stat().st_size,SHA256=sha(minimal),members=472,all_members_byte_verified=True),
    actual_book_evidence_archive=dict(path=str(evidence),bytes=evidence.stat().st_size,SHA256=sha(evidence),members=len(files),all_members_byte_verified=True),
    actual_source_export_record_SHA256=sha(C/'source_export_v1_20261008.json'),
    source_publication_record_SHA256=sha(C/'GitHub_source_publication_v1_20261008.json'),
    external_primary_files_uploaded_in_book_exports=False,actual_reading_credit_from_export=0,
    fresh_v2_book_reading_pages=nb,fresh_v2_book_matching_views=nv,reused_book_reading_pages=0,
    active_book_changed=False,native_editor_changed=False,GitHub_published=False,
    canonical_status_changes=[],helper_source=__file__)
paths['artifacts'].write_text(json.dumps(artifacts,ensure_ascii=False,indent=2)+'\n')
record.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — frozen staged checkpoint and exports',
    editorial_files={str(q):sha(q) for q in paths.values()},artifacts=artifacts,
    progress_document_hashes={n:sha(S/n) for n in ['README.md',programme]},
    active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__),
    ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',record_SHA256=sha(record),artifacts=artifacts)))
