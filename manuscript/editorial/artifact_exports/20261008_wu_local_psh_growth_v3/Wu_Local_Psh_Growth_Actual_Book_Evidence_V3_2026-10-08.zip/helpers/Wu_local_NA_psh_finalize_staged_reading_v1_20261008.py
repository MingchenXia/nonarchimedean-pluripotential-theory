from pathlib import Path
from datetime import datetime, timezone
from collections import Counter
import hashlib, json, re, subprocess, difflib

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Wu_local_NA_psh_review_20261008'
S=Path('/workspace/book-completion-drafts/wu-local-psh-staging-v1-20261008')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
release=C/'staged_book_release_checks_v1_20261008.json'
ch=json.loads(release.read_text())
manifest=Path(ch['manifest_path'])
assert sha(manifest)==ch['manifest_SHA256']
xs=json.loads(manifest.read_text())
views=[]
last=None
for x in xs:
    assert not x['actually_viewed'] and not x['selected_text_read']
    n=C/'staged_book_notes_v1'/f"note_{x['number']:02d}.md"
    r=n.with_name(n.stem+'_receipt.json')
    receipt=json.loads(r.read_text())
    assert 'Read the complete selected text and displayed matching rendered image' in n.read_text()
    assert receipt['complete_selected_text_actually_read']
    assert receipt['matching_image_individually_displayed_and_reviewed']
    assert receipt['number']==x['number'] and receipt['physical_pages']==x['physical_pages']
    assert receipt['source_PDF_SHA256']==ch['PDF']['SHA256']
    assert sha(n)==receipt['note_SHA256']
    assert sha(x['path'])==receipt['image_SHA256']==x['image_SHA256']
    assert sha(x['selected_text_path'])==receipt['selected_text_SHA256']==x['selected_text_SHA256']
    assert last is None or receipt['UTC']>last
    last=receipt['UTC']
    y={k:v for k,v in x.items() if k not in ['actually_viewed','selected_text_read']}
    y.update(inspection_mode='Fresh complete text and individual matching image display',
             actual_complete_text_read=True,actual_matching_image_freshly_displayed=True,
             sequential_note_path=str(n),sequential_note_SHA256=sha(n),
             observation_receipt_path=str(r),observation_receipt_SHA256=sha(r))
    views.append(y)
pages=sorted({p for x in xs for p in x['physical_pages']})
assert pages==ch['selected_book_physical_pages']
assert sum(len(x['physical_pages']) for x in xs)==len(pages)
reading=C/'actual_staged_book_reading_v1_20261008.json'
audit=C/'staged_mathematical_self_audit_v1_20261008.json'
post=C/'post_render_checks_v1_20261008.json'
assert not any(q.exists() for q in (reading,audit,post))
prep=json.loads((C/'staging_preparation_v1_20261008.json').read_text())
checks=[]
for command in (['python3','editorial/tools/refcheck.py'],
                ['python3','editorial/tools/check_open_problem_inventory.py']):
    run=subprocess.run(command,cwd=S/'manuscript',text=True,
                       stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    assert run.returncode==0,run.stdout
    checks.append(dict(command=command,returncode=run.returncode,output=run.stdout))
for n,h in prep['after'].items():
    assert sha(S/n)==h
for n,h in prep['other_active_TeX_preserved'].items():
    assert sha(R/n)==sha(S/n)==h
for n,h in prep['active_inputs_preserved'].items():
    assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
for n,h in prep['native_catalogue_preserved'].items():
    assert sha(R/n)==h
assert sha(R/prep['unchanged_bibliography']['path'])==prep['unchanged_bibliography']['SHA256']
assert sha(S/prep['unchanged_bibliography']['path'])==prep['unchanged_bibliography']['SHA256']
historical={}
whitespace={}
for n in ('manuscript/parts/part2/ch19_cld_examples.tex','manuscript/appendices/appL_provenance.tex'):
    before=(R/n).read_text()
    after=(S/n).read_text()
    counts={}
    for env in ('theorem','proposition','lemma','corollary','definition','example','remark','warning','proof','important'):
        patt=r'\\begin\{'+env+r'\}.*?\\end\{'+env+r'\}'
        blocks=re.findall(patt,before,re.S)
        assert all(b in after for b in blocks)
        assert len(blocks)==len(re.findall(patt,after,re.S))
        counts[env]=len(blocks)
    tags=re.findall(r'\\tag\{([^}]+)\}',before)
    assert tags==re.findall(r'\\tag\{([^}]+)\}',after)
    historical[n]=dict(byte_preserved_environment_blocks=counts,prior_manual_equation_tags=tags)
assert sum(sum(v['byte_preserved_environment_blocks'].values()) for v in historical.values())==92
assert sum(v['byte_preserved_environment_blocks']['proof'] for v in historical.values())==25
assert sum(len(v['prior_manual_equation_tags']) for v in historical.values())==6
for n in prep['after']:
    before=(R/n).read_text().splitlines()
    after=(S/n).read_text().splitlines()
    wb=Counter(x for x in before if x!=x.rstrip())
    wa=Counter(x for x in after if x!=x.rstrip())
    assert wb==wa
    added=[x[2:] for x in difflib.ndiff(before,after) if x.startswith('+ ')]
    assert all(x==x.rstrip() for x in added)
    run=subprocess.run(['git','diff','--no-index','--check',str(R/n),str(S/n)],
                       text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    assert run.returncode in (0,1) and run.stdout=='',(run.returncode,run.stdout)
    whitespace[n]=dict(historical_whitespace_lines_preserved=sum(wb.values()),
                       added_lines_checked=len(added),added_trailing_whitespace_lines=0,
                       no_index_returncode=run.returncode,no_index_diagnostic_output=run.stdout,
                       EOF_whitespace_check='PASS')
for q,h in prep['draft_fragments'].items():
    assert sha(q)==h
    assert all(x==x.rstrip() for x in Path(q).read_text().splitlines())
underfull=json.loads((C/'staged_underfull_delta_v1_20261008.json').read_text())
reading.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — all selected book pages freshly read and individually displayed',
    PDF=ch['PDF'],actual_unique_book_pages=len(pages),
    fresh_complete_text_and_individually_displayed_pages=len(pages),
    fresh_matching_views=len(views),reused_exact_complete_text_and_rendered_pixel_pages=0,
    reused_matching_views=0,views=views,legacy_preparation_flags_rewritten=False,
    remaining_repairs=[],whole_book_new_reading_claim=False,
    active_book_changed=False,GitHub_published=False,canonical_status_changes=[],
    helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
mathchecks=[
    'The source version is 2609.27610v1, 23 September 2026. All 55 primary pages were read in 28 individually displayed matching views; external bibliography proofs are not recursively certified.',
    'The printed FS lower-growth condition in 3.15 and upper-growth condition in 6.1 are kept distinct. Every affine-line FS family has a positive-degree generator; its large-radius growth is unbounded below and at most linear above.',
    'The explicit FS functions max(log|T|-j,0) decrease to 0; the finite psh limit has no FS coercive lower bound. This diagnoses the printed lower-growth closure, not a consistently corrected upper-growth theory.',
    'The radial function w=max_{k>=0}(k log|T|-k^2), w(0)=0, is a locally finite genuine convex PL maximum. Completion of squares gives w at radius exp(2m) equal to m^2. It has the stated linear lower bound but no finite FS upper majorant or decreasing global FS presentation.',
    'In the specified DVR normalization and unit curve calibration, slopes jump by one at t=2k+1. The resulting positive Radon curvature is locally finite and has infinite total mass; 1 is not globally L1. No local Bedford-Taylor theorem is rejected.',
    'Generic-finiteness exceptions are explicit: constants -j and the whole-product vertical radius give identically minus infinity. The finite-limit hypothesis actually present in Corollary 4.18(1) is preserved.',
    'The redundant constant constraint example refutes simultaneous tightening of an arbitrary polytope presentation, rather than a corrected polynomial-convexity/Runge statement.',
    'The nonradical f=T^2,g=T example has actual pole order one and formal denominator coefficient c1*r=1>c=1/2 while its FS maximum equals u_c. It refutes the asserted formal pole estimate, not the final localization theorem by itself.',
    'The slice proof actually invokes 4.19 over H(s); an irrational-radius Gauss point gives a nondiscrete value group containing Z+sqrt(2)Z. The arbitrary-field curve uniqueness lemma does not supply the missing regularization theorem.',
    'Integer-valued continuity gives local constancy only; a common branch rank needs an additional statement. Gamma=1 must be handled separately.',
    'The stated general claims have their discrete/trivial, characteristic-zero, countable-density, ample-polarization and geometrically-unibranch scopes. They remain unadmitted because of essential earlier proof interfaces, not because every proofreading slip refutes them.',
    'Appendix A uses essential unversioned APW tropical inputs and a fixed-neighbourhood decreasing approximation argument. No blanket CLD comparison, LPWZ density or BJ22 Theorem 6.21 repair is inferred.',
    'Historical 92 environment blocks including 25 proofs and six manual tags, the other 423 TeX inputs and ComplexGeometry bibliography are preserved. No formal environment or manual tag is added.',
    'The native catalogue/editor, 42 canonical atoms and twelve formal problems remain unchanged. General BJ22 critical homogeneous Siu/envelopes OPEN; LPWZ density UNVERIFIED. No original general theorem, independent-model receipt or fresh whole-book pass is asserted.'
]
audit.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),
    status='DONE — ordinary scoped mathematical audit and actual rendered clearance',
    checks=mathchecks,source_input_hashes=prep['after'],draft_fragments=prep['draft_fragments'],
    actual_final_book_reading_SHA256=sha(reading),actual_final_book_reading_credit=len(pages),
    source_scope='Wu 2609.27610v1, all 55 actual primary pages and 28 matching views; direct elementary diagnostics, general claims qualified',
    exact_diagnostics_SHA256=sha(C/'exact_diagnostics_v1_20261008.json'),
    underfull_comparison_SHA256=sha(C/'staged_underfull_delta_v1_20261008.json'),
    new_underfull_blocks=underfull['added_blocks'],original_results_promoted=[],
    independent_model_receipt=None,canonical_status_changes=[],whole_book_new_reading_claim=False,
    helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
post.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE',
    checks=checks,source_input_hashes=prep['after'],rendered_gate_SHA256=sha(reading),
    historical_formal_proof_warning_important_blocks_byte_preserved=historical,
    other_active_TeX_inputs_byte_preserved=423,whitespace_gate='PASS including EOF',
    whitespace_details=whitespace,legacy_writing_audit_unavailable=True,
    manual_semantic_delimiter_source_and_rendered_audits_used=True,
    active_book_changed=False,GitHub_published=False,canonical_status_changes=[],
    helper_source=__file__),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',actual_reading_SHA256=sha(reading),
                     math_audit_SHA256=sha(audit),post_render_SHA256=sha(post),
                     actual_pages=len(pages),fresh_views=len(views))))
