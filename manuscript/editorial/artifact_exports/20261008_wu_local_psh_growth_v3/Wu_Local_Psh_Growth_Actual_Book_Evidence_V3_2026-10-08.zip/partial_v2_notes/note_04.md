# Local psh growth and envelope scope actual book view 04

UTC: 2026-10-08T23:28:57.830576+00:00. Physical pages: 4397, 4398.

Read the complete selected text and displayed matching rendered image for physical pages 4397–4398 of the pinned compiled v2 PDF. This is a fresh actual reading, with the copied external banner clarified separately, not an independent-model receipt. A scope clarification was found and final clearance is pending.

L.95's final extra-point Hilbert example and restricted smooth-family/Ehresmann conclusion remain readable and retain their qualifications. The L.96 introduction now fits within the margin and correctly dates the controlling version, states the claimed field/countability/polarization/geometrically-unibranch scopes and leaves the general theorem unadmitted. The FS definition has a finite floor, positive rational slopes and coordinate-ring generators. Its lower/upper inequalities are distinct, and max(log|T|-j,0) has the stated finite noncoercive limit.

The local radial maximum is finite on bounded-radius sets and has the linear lower bound. The next sentence begins the formula at eta_{exp(2m)} but has not defined m. The completion-of-squares value m^2 requires m to be a nonnegative integer, not an arbitrary real or negative number. Add that explicit quantifier before the sentence and rebuild; the exact diagnostic helper and source audit already have this correct scope. This is a missing exposition hypothesis in the draft, not a change to the established calculation. The v2 source, views and partial notes remain frozen. These two pages have actual partial reading credit only and do not clear the final book gate.
