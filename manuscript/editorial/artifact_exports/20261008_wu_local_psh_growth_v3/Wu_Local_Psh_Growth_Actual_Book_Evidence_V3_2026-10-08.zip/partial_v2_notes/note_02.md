# Local psh growth and envelope scope actual book view 02

UTC: 2026-10-08T23:26:49.867487+00:00. Physical pages: 1364, 1365.

Read the complete selected text and displayed matching rendered image for physical pages 1364–1365 of the pinned compiled v2 PDF. The copied external v1 banner is covered by the separate annotation record; this is a fresh actual reading, not an independent-model receipt.

The mixed-reduction continuation keeps binomial factor 2 and gives mass 2*m*c*ell, consistent with the preceding compatible polarization data. It distinguishes harmonic charts from ordinary delta-metricity using the residual torsion condition and the exact cited harmonic Bedford–Taylor input. The entire 19.8 common-core theorem and proof retain their algebraically closed, complete, nontrivially valued field, proper variety and formal metric hypotheses; the R-PL/classical comparison keeps its additional theorem hypotheses. The five equivalent model conditions and measure identities are historically unchanged.

The new unnumbered paragraph then separates upper growth, lower coercivity and decreasing global FS approximation. Its finite limit 0 is locally psh but noncoercive; the radial example is explicitly located in L.96 and has no global FS upper majorant. The statement about infinite curvature mass is separate from locally finite curvature. The citation Wu26L resolves and the source's general envelope claim is explicitly qualified. This paragraph links naturally from the existing warning that singular BFJ theory needs global compactness/envelopes/energy, before the historical 19.9 comparison begins. Both pages are readable; theorem continuation, proof square, paragraph spacing and section transition are intact. No mathematical or layout repair is needed.
