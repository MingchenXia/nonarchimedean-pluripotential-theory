# Local psh growth and envelope scope actual book view 03

UTC: 2026-10-08T23:27:14.533792+00:00. Physical pages: 1366, 4396.

Read the complete selected text and displayed matching rendered image for physical pages 1366 and 4396 of the pinned compiled v2 PDF. This is a fresh actual reading with the copied external banner clarified by the annotation record, not an independent-model receipt.

The 19.9 seam expressly restores the original complete discrete characteristic-zero BFJ setting, smooth connected projective X, and normal flat projective models, and distinguishes the completed algebraic closure F used for ordinary delta/functorial curve tests from the DV base K used for model measures. The entire side-by-side table preserves model form, divisor weight, exponential metric change, positivity, measure, continuous limit and singular-domain conventions. Its last paragraph limits the following comparison to the computable model/continuous scope, consistent with the newly qualified local-growth paragraph. The dense table is legible and does not introduce an overflow or changed theorem number.

The appendix seam on page 4396 retains L.95's scale-dependent disjoint-ball packing bound, qualified derivative/compactness inputs, and the correctly scoped Bergman example on P1 rather than a CY counterexample. Pointwise sum 2/V and sum of section suprema 4/V are kept distinct; integrating gives h0<=C_B V0 and the larger C_B^2 V0 sum estimate. Common very ampleness and projective separation remain separate assumptions. The final scheme/topological paragraph starts with the correctly powered degree q^n and continues on the next page. No new source claim or layout repair is needed on this seam.
