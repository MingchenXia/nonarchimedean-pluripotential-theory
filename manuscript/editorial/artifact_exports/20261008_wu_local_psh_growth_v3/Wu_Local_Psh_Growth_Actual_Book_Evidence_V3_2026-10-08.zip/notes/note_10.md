# Local psh growth and envelope scope actual book view 10

UTC: 2026-10-08T23:35:07.870425+00:00. Physical pages: 4616, 4617.

Read the complete selected text and displayed matching rendered image. Full P–S index pages retain the substantial plurisubharmonic-function hierarchy across BFJ/BJ/CLD/complex and other frameworks. The new psh functions/local growth entry clearly points to 4319 under its own heading. Poincaré–Lelong normalization, projection formulas, proper support, Q valuations, R regularization and residual characteristic, and S semivaluation/singularity entries remain readable with stable destinations. Siu decomposition indexes its inherited complex-current applications only; no new BJ22 theorem promotion is implied. Long psh destination lists and the reverse Khovanskii–Teissier entry stay inside the two-column margins. Complete text and the displayed matching images have been examined with correct staged-v3 banners and no remaining repair or clipping.
