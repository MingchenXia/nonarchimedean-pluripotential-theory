# Local psh growth and envelope scope actual book view 11

UTC: 2026-10-08T23:35:19.574420+00:00. Physical pages: 4618, 4619.

Read the complete selected text and displayed matching rendered image. The complete S–Z index pages preserve the skeleton continuation, source-audit entries, split norms, subintegral and Stein-factorization references, and tropical/toric, universal-homeomorphism and valuation hierarchies. Long entries such as Ricci entropy source audit, Monge–Ampère computations and curve quantitative volumes wrap without column collisions. Printed 4540–4541 is correct; the zero-volume class entry continues at the next page rather than being lost. No new verification of inherited envelope-theorem references is inferred from this index review. Every selected line and both matching v3 images have been read/displayed; borders and blue page destinations are clean and no repair is found.
