# Local psh growth and envelope scope actual book view 07

UTC: 2026-10-08T23:34:36.543109+00:00. Physical pages: 4610, 4611.

Read the complete selected text and displayed matching rendered image. These full index pages carry the B tail through C, D and early E: Berkovich/BFJ and birational entries, Calabi–Yau and calibration, CLD hierarchy and comparison, current/curve tests, delta forms, divisorial and dual-energy entries. Existing research references including base translation 4304 and CY finiteness 4316 remain readable and aligned. The long Mesquita–Piccione–Darvas–Xia–Zhang subentry wraps onto its numeric line within the column; cone continues normally from the bottom of page 4532 to the next page. Both images show clear headings, blue destinations and indented subentries without overlap or clipping. These pages add no proof verification; their complete text and layout have been reviewed afresh in v3 and need no repair.
