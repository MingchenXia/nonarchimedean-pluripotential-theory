# Local psh growth and envelope scope actual book view 08

UTC: 2026-10-08T23:34:46.423501+00:00. Physical pages: 4612, 4613.

Read the complete selected text and displayed matching rendered image. The complete E–L index segment is legible in both columns. The newly added plural envelopes/weak psh descent entry points to printed 4319 and stays distinct from the inherited envelope, envelope property and envelope theorem entries, avoiding an index-level implication that the claimed theorem was verified. Finite descent, finite-energy classes, FS functions, Gauss extensions and valuation, harmonic/tropical and Hessian entries retain their destinations. The I/K sections include ideal evaluation, integral closure, intersection theory, K-stability and Kähler–Einstein scope entries. Continuations at graded reduction and Lagerberg are normal page/column boundaries. No overflow, overlap, missing character or repair identified; v3 actual reading credit covers only these two complete pages.
