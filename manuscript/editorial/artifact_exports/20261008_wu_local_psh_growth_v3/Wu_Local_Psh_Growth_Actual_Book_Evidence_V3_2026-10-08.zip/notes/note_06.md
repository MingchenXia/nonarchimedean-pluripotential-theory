# Local psh growth and envelope scope actual book view 06

UTC: 2026-10-08T23:34:24.712059+00:00. Physical pages: 4401, 4609.

Read the complete selected text and displayed matching rendered image. The Appendix M successor opens cleanly with its full title and keeps the supplied classical-pluriharmonic-to-PL theorem's good, separated, strict, boundaryless and nontrivial valuation scope. It explicitly separates the still-continuous zero-current question and Problem 72.1.5, so new L.96 does not silently alter that ledger or archived receipts. The first complete index page has stable A/B ordering and indented subentries, including abeloid/higher-rank and prior CY Bergman references. Its printed page 4531 corresponds to physical 4609. Both columns, page numbers and reference links are readable, no collisions or clipping appear, and all content is within the matching v3 image. No repair or new theorem credit.
