# Local psh growth and envelope scope actual book view 01

UTC: 2026-10-08T23:33:28.657124+00:00. Physical pages: 73, 1363.

Read the complete selected text and displayed matching rendered image. Page 73 places new L.96 after uniform Calabi–Yau finiteness and before Appendix M, with printed page 4319; Appendix M begins at 4323, index at 4531, references at 4543. The dotted leaders and rows are legible. Page 1363 preserves the preceding canonical-metric examples: determinant 3 yields total mass 6 and polarization type (1,3), the primitive-line densities agree with the stated matrix values, and the mixed-reduction example explicitly assumes compatible Raynaud descent data. The continuation into its measure is a normal page seam. The external view banners correctly say staged v3. No repair identified; this is two scoped pages, not a whole-book reading.
