from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,zipfile,shutil
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Truong_polarized_CY_finiteness_review_20261008';S=R/'source_material/Truong_polarized_CY_finiteness_sources_20261008';E=R/'manuscript/editorial';W=Path('/tmp/Truong_polarized_CY_finiteness_primary_views_v1_20261008');O=Path('/workspace/book-completion-drafts/research-integration');out=C/'source_export_v1_20261008.json';assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cp=C/'source_checkpoint_v1_20261008.json';obj=json.loads(cp.read_text())
for p,h in obj['protected_core_inputs'].items():assert sha(p)==h
editorial=[Path(p) for p in obj['editorial_files']];assert all(sha(p)==obj['editorial_files'][str(p)] for p in editorial)
cache=[p for p in C.rglob('*') if p.is_file()];helpers=sorted(Path('/tmp').glob('Truong_polarized_CY_finiteness_*_20261008.py'))
full={f'primary/{p.name}':p for p in S.iterdir() if p.is_file()};full.update({f'actual_views/{p.name}':p for p in W.iterdir() if p.is_file()})
authored={f'authored_records/{p.relative_to(C)}':p for p in cache};authored.update({f'editorial/{p.name}':p for p in editorial});authored.update({f'helpers/{p.name}':p for p in helpers});full.update(authored)
def export(path,items):
 assert not path.exists()
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,p in sorted(items.items()):z.write(p,name)
 with zipfile.ZipFile(path) as z:
  assert sorted(z.namelist())==sorted(items)
  for name,p in items.items():assert z.read(name)==p.read_bytes(),name
 return dict(path=str(path),bytes=path.stat().st_size,SHA256=sha(path),members=len(items),members_byte_verified=True)
fullzip=export(O/'Truong_Polarized_CY_Finiteness_Actual_Source_Evidence_2026-10-08.zip',full);authzip=export(O/'Truong_Polarized_CY_Finiteness_Authored_Audit_Records_2026-10-08.zip',authored)
review=O/'Truong_Polarized_CY_Finiteness_Actual_Source_Review_2026-10-08.pdf';assert not review.exists();shutil.copy2(S/'Truong_polarized_CY_finiteness_arxiv_v1.pdf',review)
D=E/'artifact_exports/20261008_truong_polarized_CY_finiteness_sources';assert not D.exists();D.mkdir();p=D/Path(authzip['path']).name;shutil.copy2(authzip['path'],p);assert sha(p)==authzip['SHA256'];(D/'SHA256SUMS').write_text(sha(p)+'  '+p.name+'\n')
(D/'README.md').write_text(f'''# Polarized Calabi–Yau finiteness primary audit, 8 October 2026

The authored archive has {authzip['members']} byte-verified members recording all 34 pages of arXiv:2610.00361v1, posted 30 September 2026, in seventeen individually displayed matching images with complete selected text and sequential notes. Source: https://arxiv.org/abs/2610.00361v1.

It contains authored notes, receipts, actual-reading and hash records, four editorial files and available acquisition/diagnostic helpers. The primary PDF, extracted full text and matching images are absent from this uploaded archive; the complete {fullzip['members']}-member source evidence remains in the cloud.

The paper explicitly proposes a program and leaves capacity-perimeter and uniform metric-to-projective-embedding bridges unfinished. The audit retains the program and qualified classical conditional interfaces, rather than a completed finiteness theorem. Exact elementary tests expose a freely changed iteration exponent, the printed truncation identity, a reversed Bishop-Gromov numerical diameter estimate, interchange of Bergman pointwise sums with individual suprema, and an overly broad arbitrary-scheme Hilbert-polynomial statement. The actual theorem statements, proof gaps and counterexamples have separate scopes. The correctly scale-dependent diameter conclusion has a direct packing argument. Smooth connected pure-dimensional algebraic boundedness is not refuted by the extra-point scheme example. External comparison, PDE, compactness, Hilbert-scheme, stratification and Ehresmann proofs are not recursively certified.

The source extraction font warning and a nonfatal descriptive-string escape warning in the successful symbolic helper are retained. Every mathematical assertion in that helper passes. Prepared flags remain false; export/upload gives zero reading credit. These are direct diagnostics and elementary conditional bookkeeping, not a new original general theorem or an independent-model receipt.

The active 4,642-page book, all 425 TeX inputs, both bibliographies and native catalogue/editor remain unchanged at this source checkpoint. The 42 atoms/twelve formal problems retain status: general BJ22 critical homogeneous Siu/envelopes OPEN, LPWZ density UNVERIFIED. The last complete ordered book reading remains 4 October. SHA256SUMS pins the authored archive. Book integration, activation and publication have separate subsequent gates and records.
''')
record=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — source archives byte-verified; repository publication pending at export',full_source_evidence=fullzip,authored_source_evidence=authzip,source_review_PDF=dict(path=str(review),bytes=review.stat().st_size,SHA256=sha(review),physical_pages=34),repository_artifact_directory=str(D.relative_to(R)),repository_artifact_files={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in sorted(D.iterdir())},external_primary_artifact_upload=False,actual_source_pages=34,actual_images=17,unconditional_CY_finiteness_theorem_admitted=False,export_reading_credit=0,canonical_status_changes=[],GitHub_published=False,helper_source=__file__)
out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
for p,h in obj['protected_core_inputs'].items():assert sha(p)==h
print(json.dumps(dict(status='DONE',record_SHA256=sha(out),full_source_evidence=fullzip,authored_source_evidence=authzip)))
