from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Truong_polarized_CY_finiteness_review_20261008';S=Path('/workspace/book-completion-drafts/relative-Hessian-staging-v4-20261008');out=C/'actual_primary_reading_v1_20261008.json';baseline=C/'protected_source_baseline_v1_20261008.json';assert not out.exists() and not baseline.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prep=C/'primary_view_preparation_v1_20261008.json';p=json.loads(prep.read_text());manifest=Path(p['manifest_path']);assert sha(manifest)==p['manifest_SHA256'];xs=json.loads(manifest.read_text());assert len(xs)==17;last=None;obs=[];pages=[]
for row in xs:
 assert not row['actually_viewed'] and not row['selected_text_read']
 receipt=C/'primary_notes_v1'/f"note_{row['number']:02d}_receipt.json";x=json.loads(receipt.read_text());assert x['number']==row['number'] and x['physical_pages']==row['physical_pages']
 assert x['complete_selected_text_actually_read'] and x['matching_image_individually_displayed_and_reviewed']
 assert sha(x['image_path'])==x['image_SHA256']==row['image_SHA256'] and sha(x['selected_text_path'])==x['selected_text_SHA256']==row['selected_text_SHA256']
 assert sha(x['note_path'])==x['note_SHA256'] and 'Read the complete selected text and displayed matching rendered image' in Path(x['note_path']).read_text()
 assert x['source_PDF_SHA256']==p['source_PDF']['SHA256'];assert last is None or last<x['UTC'];last=x['UTC'];obs.append(dict(receipt_path=str(receipt),receipt_SHA256=sha(receipt),**x));pages+=x['physical_pages']
assert pages==list(range(1,35)) and sha(p['source_PDF']['path'])==p['source_PDF']['SHA256']
prior=json.loads((R/'source_material/Kaib_Werner_higher_rank_review_20261008/source_checkpoint_v2_20261008.json').read_text());protected={name:sha(name) for name in prior['protected_core_inputs']};assert len(protected)==430
for name,h in protected.items():
 rel=Path(name).relative_to(R)
 if rel.suffix in ['.tex','.bib'] and '/manuscript/' in name:assert h==sha(S/rel)
 if '/output/' in name:assert h==prior['protected_core_inputs'][name]
a=json.loads((R/'manuscript/editorial/Truong_relative_Hessian_cloud_activation_20261008.json').read_text());assert sha(R/'manuscript/book.pdf')==a['active_PDF']['SHA256']
baseline.write_text(json.dumps(dict(UTC=datetime.now(timezone.utc).isoformat(),protected_core_inputs=protected,active_TeX_inputs=425,bibliographies=2,active_book_PDF=a['active_PDF'],native_catalogue_and_editor_preserved=True,baseline_Git_commit='8827fdeb22bf08a4ee3b910a73d208e0a3d87ecc',source_record_only=True),ensure_ascii=False,indent=2)+'\n')
obj=dict(status='DONE — complete primary text and seventeen individually displayed matching views',UTC=datetime.now(timezone.utc).isoformat(),source_PDF=p['source_PDF'],actual_distinct_source_page_pairs=17,actual_matching_images=17,actual_sequential_notes=17,actual_read_pages=pages,actual_observations=obs,preparation_record_SHA256=sha(prep),prepared_flags_preserved=True,extraction_warning_preserved=True,all_image_text_pairs_readable_with_no_detected_content_loss=True,unconditional_CY_finiteness_theorem_admitted=False,external_foundation_proofs_recursively_certified=False,independent_model_receipt_claimed=False,canonical_status_changes=[],active_book_changed=False,last_whole_book_pass='4 October 2026',reading_credit_from_exports_or_uploads=0,protected_baseline_SHA256=sha(baseline),helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status='DONE',actual_pages=len(pages),views=len(obs),ledger_SHA256=sha(out),protected_baseline_SHA256=sha(baseline))))
