from pathlib import Path
from datetime import datetime,timezone
import urllib.request,hashlib,json,fitz,subprocess
R=Path('/workspace/nonarchimedean-pluripotential-theory')
S=R/'source_material/Dubocs_Green_currents_sources_20261008'
C=R/'source_material/Dubocs_Green_currents_review_20261008'
S.mkdir(exist_ok=True);C.mkdir(exist_ok=True)
out=C/'primary_acquisition_v1_20261008.json';pdf=S/'Dubocs_Green_currents_arxiv_v1.pdf';txt=S/'Dubocs_Green_currents_arxiv_v1.txt'
assert not any(p.exists() for p in [out,pdf,txt])
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
discovery=R/'source_material/local_psh_dependencies_review_20261008/recent_NA_psh_metadata_discovery_v2_20261008.json'
entry=[r for r in json.loads(discovery.read_text())['entries'] if r['id'].endswith('/2606.19160v1')];assert len(entry)==1
obj=dict(start_UTC=datetime.now(timezone.utc).isoformat(),source_arxiv_id='2606.19160v1',metadata_discovery_SHA256=sha(discovery),metadata=entry[0],actual_primary_pages_read=0,matching_source_images_displayed=0,baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),active_book_PDF_SHA256=sha(R/'manuscript/book.pdf'),active_book_pages=4651,active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],helper_source=__file__)
url='https://arxiv.org/pdf/2606.19160v1'
req=urllib.request.Request(url,headers={'User-Agent':'book-source-audit/1.0'})
with urllib.request.urlopen(req,timeout=35) as r:
 raw=r.read();obj.update(request_URL=url,final_URL=r.url,HTTP_status=r.status,content_type=r.headers.get('Content-Type'))
assert raw.startswith(b'%PDF-') and len(raw)<32*1024*1024
pdf.write_bytes(raw)
with fitz.open(pdf) as doc:
 pages=len(doc);metadata=doc.metadata
 txt.write_text('\n\f\n'.join(p.get_text() for p in doc))
obj.update(end_UTC=datetime.now(timezone.utc).isoformat(),status='DONE — exact version acquired; zero primary-reading credit',PDF=dict(path=str(pdf),bytes=pdf.stat().st_size,SHA256=sha(pdf),physical_pages=pages,embedded_metadata=metadata),extracted_navigation_text=dict(path=str(txt),bytes=txt.stat().st_size,SHA256=sha(txt),not_actual_reading_credit=True))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],PDF=obj['PDF'],record_SHA256=sha(out)),ensure_ascii=False))
