from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, math
import sympy as sp

R = Path('/workspace/nonarchimedean-pluripotential-theory')
C = R/'source_material/Dubocs_Green_currents_review_20261008'
out = C/'exact_diagnostics_v1_20261009.json'
assert not out.exists()
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
x, y, u, w, t, v, z = sp.symbols('x y u w t v z')
checks = []

# A regular sequence need not produce a smooth generic blowup.
# y^2 is a non-zero-divisor modulo (x^2): divisibility is monomial.
monomials = [1, x, y, x*y]
G = sp.groebner([x**2, y**2], x, y, order='lex')
assert all(G.reduce(a)[1] == a for a in monomials)
assert all(G.reduce(a)[1] == 0 for a in [x**2, y**2, x**2*y, x*y**2])
generic_equation = y**2-u*x**2
gradient = [sp.diff(generic_equation, a) for a in [x, y, u]]
assert generic_equation.subs({x:0, y:0, u:1}) == 0
assert all(a.subs({x:0, y:0, u:1}) == 0 for a in gradient)
at_point = sp.Poly(generic_equation.subs(u, 1+w), x, y, w)
assert min(sum(a) for a in at_point.monoms()) == 2
checks.append(dict(name='Nonreduced regular zero scheme with singular generic blowup',
 status='PASS', field='Q((t))', proper_X='P^2_K',
 bundle_and_section='O(2) direct-sum O(2), section (X^2,Y^2)',
 affine_ideal='(x^2,y^2), a regular sequence in K[x,y]',
 zero_scheme_length=4, quotient_basis=list(map(str, monomials)),
 blowup_chart=str(generic_equation), point=dict(x=0,y=0,u=1),
 gradient=list(map(str, gradient)), hypersurface_dimension=2,
 local_embedding_dimension=3,
 inference='The generic blowup is singular. A regular R-model with this exact generic fibre cannot exist, since regularity localizes.',
 limit='A typing/regularity defect in the stated construction, not a counterexample to a Green identity after an additional resolution construction.'))

# A smooth generic centre does not make the particular total model regular.
model_equation = t*x-v*y
assert all(sp.diff(model_equation,a).subs({t:0,x:0,y:0,v:0}) == 0 for a in [t,x,y,v])
assert min(sum(a) for a in sp.Poly(model_equation,t,x,y,v).monoms()) == 2
assert sp.expand(model_equation.subs(x,v*y/t)) == 0
checks.append(dict(name='Singular raw total blowup with smooth generic blowup',
 status='PASS', ring='Q[[t]]', original_model='P^2_R',
 model_bundle_and_section='O(1) direct-sum O(1), section (tX,Y)',
 affine_ideal='(tx,y)', raw_chart=str(model_equation),
 closed_point='t=x=y=v=0', total_dimension=3, local_embedding_dimension=4,
 generic_chart_after_inverting_t='x=vy/t, hence K[y,v]',
 inference='The regular generic centre is (x,y), but the raw model blowup is singular. Domination by an appropriate regular model must be constructed before E^{-1} is applied.',
 limit='Regular-model cofinality can support an appropriate domination in its exact hypotheses; it does not make the printed raw model regular.'))

# Strict transforms of divisors have degree one; contracted divisors vanish.
cycle_pairs = []
for a in [(0,0,0), (2,-1,7), (-3,5,1), (1,1,-9)]:
 for b in [(0,0,0), (-2,4,8), (3,-5,2)]:
  lhs = tuple(min(a[i],b[i]) for i in [0,1])
  rhs = tuple(min(a[i],b[i]) for i in [0,1])
  assert lhs == rhs
  cycle_pairs.append(dict(a=a,b=b,push_min=lhs,min_push=rhs))
assert min(1,0)+min(0,1) == 0
assert min(1+0,0+1) == 1
checks.append(dict(name='Typed minimum and pushforward',
 status='PASS', top_cycle_map='(strict coefficient a, strict coefficient b, contracted coefficient c) -> (a,b)',
 exact_pairs=cycle_pairs,
 higher_degree_counterexample=dict(alpha=[1,0],beta=[0,1],pushforward_matrix=[1,1],push_min=0,min_push=1),
 limit='The matrix tests the coefficient mechanism; the proper birational codimension-one theorem is an attributed classical geometric input. Choose two k(x)-rational exceptional points for unit residue degrees.'))

def order(poly):
 p=sp.Poly(sp.expand(poly),t)
 return None if p.is_zero else min(a[0] for a in p.monoms())
matrices = [
 sp.Matrix([[1,-1],[0,1]]),
 sp.Matrix([[1,t],[t,1+t**2]]),
 sp.Matrix([[0,1],[-1,0]])]
vectors = [sp.Matrix([t**2,t**2+t**5]),sp.Matrix([0,t**3]),sp.Matrix([t,t**7])]
rows=[]
for A in matrices:
 assert sp.expand(A.det()) == 1
 for f in vectors:
  a=[order(q) for q in f];b=[order(q) for q in A*f]
  assert min(q for q in a if q is not None)==min(q for q in b if q is not None)
  assert sp.simplify(A.inv()*(A*f)-f)==sp.zeros(2,1)
  rows.append(dict(matrix=str(A),components=list(map(str,f)),orders_before=a,orders_after=b))
checks.append(dict(name='DVR frame invariance with cancellation and zero components',
 status='PASS', exact_cases=rows, zero_order='infinity; encoded null',
 general_argument='Both a GL_r(O_DVR) matrix and its inverse have integral entries, so each gives one inequality for the minimum order.',
 limit='This checks the elementary section-ideal coefficient construction, not analytic psh invariance or unrestricted current pullback.'))

coefficient_rows=[]
for r in range(1,33):
 for k in range(r):
  s=sum(math.comb(r,r-1-j)*math.comb(j,k)*(-1)**(j-k) for j in range(k,r))
  assert s==1
  coefficient_rows.append(dict(r=r,k=k,sum=s))
derivative_rows=[]
for k in range(9):
 corrected=sp.simplify((-1)**k*sp.diff(1/(1+z),z,k)-math.factorial(k)/(1+z)**(k+1))
 assert corrected==0
 derivative_rows.append(dict(k=k,corrected_difference=str(corrected)))
assert sp.diff(1/(1+z),z)==-1/(1+z)**2
checks.append(dict(name='Split Chern coefficient and the omitted derivative sign',
 status='PASS', finite_checks=coefficient_rows, sign_checks=derivative_rows,
 exact_identity='sum_{j=k}^{r-1} binom(r,r-1-j) binom(j,k) (-1)^(j-k)=1',
 corrected_generating_function='(1+z)^r z^k/k! times (-1)^k derivative^k (1+z)^(-1) = z^k(1+z)^(r-1-k)',
 limit='Elementary algebra supports the final coefficient identity; it does not remove the geometric regularity gap in Theorem 4.1.'))

assert sp.expand(y-u*x).subs(y,u*x)==0
assert sp.expand(y-u*x).diff(y)==1
assert sp.log(sp.exp(1))==1 and sp.log(sp.exp(2))==2
checks.append(dict(name='Supported coordinate geometry and normalization boundaries',
 status='PASS', coordinate_centre='(x,y) in the affine chart of P^2',
 blowup_chart='y=ux, polynomial regular chart R[x,u]',
 rank_one='Blowup of an invertible principal ideal is the identity; the Cartier-section Poincare–Lelong cancellation stays in the stated model category.',
 normalization_test=dict(uniformizer_valuation=1,chosen_norm='exp(-1)',minus_log_norm=1,minus_log_norm_squared=2),
 proper_trivial_bundle_example=dict(global_P1_sections=[2,3],zero_ideal='(2,3)=(1)',zero_scheme_empty=True),
 limit='The model dd^c has no supplied analytic comparison map. A factor for norm-squared alone does not fix a CLD comparison. Proper integral H^0(O) is a finite field extension, so regular global tuples in O^r have empty zero scheme; this uses the stated classical properness input.'))

obj=dict(UTC=datetime.now(timezone.utc).isoformat(),
 status='DONE — six exact elementary diagnostic families; no original general theorem',
 source_PDF_SHA256=sha(R/'source_material/Dubocs_Green_currents_sources_20261008/Dubocs_Green_currents_arxiv_v1.pdf'),
 checks=checks, canonical_status_changes=[],original_results_promoted=[],
 independent_model_receipt=None, helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],checks=len(checks),record_SHA256=sha(out))))
