from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile, subprocess, shutil

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Dubocs_Green_currents_review_20261008'
E=R/'manuscript/editorial'
O=Path('/workspace/book-completion-drafts/research-integration')
A=E/'artifact_exports/20261009_dubocs_green_current_sources'
out=C/'source_checkpoint_v1_20261009.json'
assert not A.exists() and not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
reading=load('actual_primary_reading_v1_20261009.json')
diag=load('exact_diagnostics_v2_20261009.json')
assert reading['actual_source_unique_pages']==27 and reading['actual_individually_displayed_matching_views']==14
assert reading['whole_primary_PDF_reading_claim'] and not reading['whole_book_new_reading_claim']
assert len(diag['checks'])==6 and all(a['status']=='PASS' for a in diag['checks'])
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head==reading['baseline_commit']
for rel,h in reading['protected_core_inputs'].items():assert sha(R/rel)==h
paths={k:E/f'Dubocs_Green_currents_source_{k}_20261009.{ext}'
 for k,ext in [('review','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
addendum=E/'Local_psh_norm_dependencies_formula_rendering_addendum_20261009.md'
old_audit=E/'Local_psh_norm_dependencies_source_review_20261008.md'
assert paths['review'].exists() and addendum.exists()
assert not any(paths[k].exists() for k in ['reading_notes','manifest','artifacts'])
owned=O/'Dubocs_Green_Currents_Authored_Records_V1_2026-10-09.zip'
full=O/'Dubocs_Green_Currents_Actual_Source_Evidence_V1_2026-10-09.zip'
assert not owned.exists() and not full.exists()
paths['reading_notes'].write_text(
 '# Actual Dubocs Green-current primary reading notes, 8–9 October 2026\n\n'
 'All 27 pinned primary pages, fourteen individually displayed matching images, '
 'complete selected text and sequential observation receipts. No whole-book reading claim.\n'
 +''.join('\n---\n\n'+Path(v['note_path']).read_text() for v in reading['views']))
prior_publication=R/'source_material/local_psh_dependencies_review_20261008/GitHub_source_publication_v1_20261008.json'
paths['manifest'].write_text(json.dumps(dict(
 UTC=datetime.now(timezone.utc).isoformat(),
 status='DONE — complete exact primary-source audit with qualified higher-rank formula',
 actual_reading=reading,actual_reading_record_SHA256=sha(C/'actual_primary_reading_v1_20261009.json'),
 exact_diagnostics=diag,exact_diagnostics_record_SHA256=sha(C/'exact_diagnostics_v2_20261009.json'),
 protected_core_inputs=reading['protected_core_inputs'],baseline_commit=head,
 source_qualification=reading['qualification'],
 prior_norm_dependency_remote_record_SHA256=sha(prior_publication),
 formula_addendum=dict(path=str(addendum),SHA256=sha(addendum),
  frozen_audit_path=str(old_audit),frozen_audit_SHA256=sha(old_audit),
  new_reading_credit=0,mathematical_status_change=False),
 whole_primary_PDF_reading_claim=True,whole_book_new_reading_claim=False,
 active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],
 original_results_promoted=[],independent_model_receipt=None),
 ensure_ascii=False,indent=2)+'\n')

files={f'records/{q.name}':q for q in C.glob('*.json')}
manifest=Path(load('primary_view_preparation_v1_20261008.json')['manifest_path'])
files['records/prepared_view_manifest.json']=manifest
for a in reading['views']:
 for key,folder in [('note_path','notes'),('observation_receipt_path','receipts')]:
  q=Path(a[key]);files[f'{folder}/{q.name}']=q
for q in Path('/tmp').glob('Dubocs_Green_currents_*_2026100*.py'):
 files[f'helpers/{q.name}']=q
for k in ['review','reading_notes','manifest']:
 q=paths[k];files[f'editorial/{q.name}']=q
files[f'editorial/{addendum.name}']=addendum
def writezip(path,mapping):
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for n,q in sorted(mapping.items()):z.write(q,n)
 with zipfile.ZipFile(path) as z:
  assert len(z.namelist())==len(mapping)
  for n,q in mapping.items():assert z.read(n)==q.read_bytes()
writezip(owned,files)
allfiles=dict(files)
for a in reading['views']:
 for key,folder in [('image_path','images'),('selected_text_path','text')]:
  q=Path(a[key]);allfiles[f'{folder}/{q.name}']=q
acquisition=load('primary_acquisition_v1_20261008.json')
for q in [Path(reading['source_PDF']['path']),Path(acquisition['extracted_navigation_text']['path'])]:
 allfiles[f'primary/{q.name}']=q
writezip(full,allfiles)
A.mkdir()
copy=A/owned.name;shutil.copyfile(owned,copy);assert sha(copy)==sha(owned)
(A/'SHA256SUMS').write_text(sha(copy)+'  '+copy.name+'\n')
(A/'README.md').write_text(f'''# Authored Green-current source evidence, 9 October 2026

The audit reads all 27 physical pages of Dubocs arXiv:2606.19160v1 with complete
selected text and fourteen individually displayed matching images, in source
order. Sequential notes/receipts pin the exact source PDF, text and images.
The {len(files)}-member authored archive is byte verified and contains the audit,
notes, manifests, preparation/actual-reading records, six exact elementary
diagnostic families, reproduction helpers and the norm-audit formula-rendering
addendum. The failed first diagnostic helper remains frozen; fresh v2 passes.

The separate {len(allfiles)}-member full source evidence archive retains the exact
external primary PDF, navigation text, selected texts and rendered images in
the cloud. The uploaded authored archive preserves their digests and observation
records. SHA256SUMS pins that archive. Preparation/export/upload supplies zero
reading credit and no independent-model receipt.

The model-Chow category, regular/cofinal models and induced vector-bundle
metrics remain explicit. Rank-one Poincare–Lelong and the vertical minimum
coefficient construction are distinguished from the general higher-rank
blowup formula. A regular zero scheme need not have a smooth generic blowup,
and a raw total blowup can be singular even with a smooth generic centre.
No general higher-rank formula or CLD comparison is imported. The intended
formula is not asserted false after an appropriate additional construction.

The 4,651-page active book, 425 core TeX inputs, two bibliographies and native
catalogue/editor are unchanged. The 42 atoms/twelve problems retain their
statuses: general BJ22 critical homogeneous Siu/envelopes OPEN and LPWZ density
UNVERIFIED. The last complete ordered book pass is 4 October. Qualified book
integration has a separate full-build and actual rendered-reading gate.
Remote publication receives a later verification record.
''')
artifact_files={str(q.relative_to(R)):dict(bytes=q.stat().st_size,SHA256=sha(q)) for q in A.iterdir()}
art=dict(UTC=datetime.now(timezone.utc).isoformat(),
 status='DONE — byte-verified source evidence exports',
 authored_archive=dict(path=str(owned),bytes=owned.stat().st_size,SHA256=sha(owned),members=len(files)),
 full_cloud_evidence_archive=dict(path=str(full),bytes=full.stat().st_size,SHA256=sha(full),members=len(allfiles)),
 repository_artifact_files=artifact_files,external_primary_files_uploaded=False,
 actual_source_pages=27,actual_matching_views=14,actual_reading_credit_from_export=0,
 active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__)
paths['artifacts'].write_text(json.dumps(art,ensure_ascii=False,indent=2)+'\n')
editorial_files={str(q):sha(q) for q in [*paths.values(),addendum]}
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),
 status='DONE — source audit, correction addendum and byte-verified evidence prepared',
 baseline_commit=head,editorial_files=editorial_files,
 repository_artifact_files=artifact_files,artifacts=art,
 protected_core_inputs=reading['protected_core_inputs'],
 frozen_norm_audit_SHA256=sha(old_audit),
 actual_source_pages=27,actual_matching_views=14,
 active_book_changed=False,native_editor_changed=False,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='DONE',record_SHA256=sha(out),
 authored_members=len(files),full_cloud_members=len(allfiles),
 editorial_files=len(editorial_files),repository_artifact_files=len(artifact_files))))
