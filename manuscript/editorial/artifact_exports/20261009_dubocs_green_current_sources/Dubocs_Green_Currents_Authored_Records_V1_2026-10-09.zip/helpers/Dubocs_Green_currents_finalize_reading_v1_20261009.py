from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, subprocess

R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Dubocs_Green_currents_review_20261008'
out=C/'actual_primary_reading_v1_20261009.json'
assert not out.exists()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prep_path=C/'primary_view_preparation_v1_20261008.json'
prep=json.loads(prep_path.read_text())
assert prep['actual_source_reading_credit']==0 and prep['actually_read_pages']==0
assert sha(prep['source_PDF']['path'])==prep['source_PDF']['SHA256']
assert sha(prep['manifest_path'])==prep['manifest_SHA256']
rows=json.loads(Path(prep['manifest_path']).read_text())
assert len(rows)==14
views=[];pages=[];last_stamp=''
for n,row in enumerate(rows,1):
 receipt=C/'primary_notes_v1'/f'note_{n:02d}_receipt.json'
 a=json.loads(receipt.read_text())
 assert a['number']==n and a['physical_pages']==row['physical_pages']
 assert a['complete_selected_text_actually_read'] and a['matching_image_individually_displayed_and_reviewed']
 assert a['UTC']>last_stamp;last_stamp=a['UTC']
 for pathkey,hashkey in [('image_path','image_SHA256'),('selected_text_path','selected_text_SHA256'),('note_path','note_SHA256')]:
  assert sha(a[pathkey])==a[hashkey]
 assert a['source_PDF_SHA256']==prep['source_PDF']['SHA256']==row['source_PDF_SHA256']
 assert not row['actually_viewed'] and not row['selected_text_read']
 assert 'Read the complete selected text and displayed matching rendered image.' in Path(a['note_path']).read_text()
 views.append(dict(**a,observation_receipt_path=str(receipt),observation_receipt_SHA256=sha(receipt)))
 pages.extend(row['physical_pages'])
assert pages==list(range(1,28))
baseline=json.loads((R/'source_material/local_psh_dependencies_review_20261008/local_source_commit_v1_20261008.json').read_text())
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
assert head==baseline['commit']=='e4b7b2ae57a0a2481ad723f64c4b635afadd84c2'
assert len(baseline['protected_core_inputs'])==430
for rel,h in baseline['protected_core_inputs'].items():
 assert sha(R/rel)==h
d=C/'exact_diagnostics_v2_20261009.json'
diag=json.loads(d.read_text())
assert len(diag['checks'])==6 and all(a['status']=='PASS' for a in diag['checks'])
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),
 status='DONE — all 27 pinned primary pages with complete text and 14 individually displayed matching views',
 source_PDF=prep['source_PDF'], actual_source_unique_pages=27,
 actual_individually_displayed_matching_views=14, selected_physical_pages=pages,
 views=views,preparation_record_SHA256=sha(prep_path),
 acquisition_record_SHA256=sha(C/'primary_acquisition_v1_20261008.json'),
 exact_diagnostics_SHA256=sha(d),failed_diagnostic_v1_record_SHA256=sha(C/'failed_exact_diagnostics_v1_20261009.json'),complete_selected_text_read=True,
 preparation_flags_unchanged=True,whole_primary_PDF_reading_claim=True,
 whole_book_new_reading_claim=False,active_book_changed=False,
 native_editor_changed=False,book_PDF_SHA256=sha(R/'manuscript/book.pdf'),
 active_book_pages=4651,baseline_commit=head,
 protected_core_inputs=baseline['protected_core_inputs'],
 essential_earlier_inputs_not_recursively_verified=[
  'BGS95 model Chow-current construction and metric foundations',
  'Fulton98 operational/Gysin axioms, Chern classes and projective bundle formula',
  'Raynaud–Gruson71 flattening and any needed resolution/cofinal domination',
  'BGS94 complex Green-current construction and its normalization'],
 general_higher_rank_formula_admitted=False,
 qualification='The raw blowup is not established regular; a regular-section ideal can have singular generic blowup. Safe rank-one/model coefficient results retain the exact model hypotheses. No comparison with CLD analytic currents is supplied.',
 general_envelope_theorem_admitted=False,canonical_status_changes=[],
 original_results_promoted=[],independent_model_receipt=None,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status=obj['status'],pages=27,views=14,protected_inputs=430,record_SHA256=sha(out))))
