# Hattori v2 actual source view 21

UTC: 2026-10-08T19:08:20.664698+00:00. Physical pages: 41, 42.

Complete pages 41–42 and matching image were read. A.10's last local calculation is consistent once a nontrivial zero-beta prime F is available from the qualified special-test reduction. For ample L, S_L(F)<T_L(F); zero beta gives A(F)=S(F), hence alpha_F<=A/T<1, so an effective D in |L|_Q can satisfy v_F(D)>A(F). The proof's integral inequality needs that strict S<T fact, not only vol<=V. The resulting unnormalized beta after simultaneous boundary/polarization change is epsilon(1-epsilon)^n V[A(F)-v_F(D)]<0. Dividing by its new volume gives epsilon[A-v(D)], consistently with normalized DF and its scalar invariance.

The existence and nontriviality of the zero-beta special test still rely on the prior Li–Xu/Fujita reductions. A positive norm penalty in the reduction must preserve nontriviality; no new autonomous extraction theorem is provided by this reading. The small boundary must also remain klt, as possible for sufficiently small epsilon because the fixed pair is klt.

The references on these pages identify the imported Abban–Zhuang adapted-basis lemma, Ambro moduli/discriminant foundations, Birkar–Cascini–Hacon–McKernan, Blum–Jonsson threshold theory, BHJ uniform norms/filtrations, Chen J-equation, Chen–Cheng cscK existence, Dervan/Fine/Floris–Lazic and Fujita sources. Reading their bibliography entries supplies metadata/context only, not proof-reading credit for those papers. The listed BJ18 arXiv identifier is a separate cited input; it does not close the book's BJ22 critical homogeneous Siu problem. All selected proof and bibliography text is legible. No active book or canonical status change occurs.
