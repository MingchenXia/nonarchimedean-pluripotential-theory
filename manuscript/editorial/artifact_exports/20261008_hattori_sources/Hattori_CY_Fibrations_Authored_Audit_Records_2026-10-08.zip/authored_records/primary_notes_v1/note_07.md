# Hattori v2 actual source view 07

UTC: 2026-10-08T18:54:49.741696+00:00. Physical pages: 13, 14.

Complete pages 13–14 and matching image were read. The canonical bundle formula uses B_C=sum(1-lct_generic(f*D))D and K_X+Delta Q-linearly equivalent to f*(K_C+M_C+B_C). Moduli and discriminant traces transform differently; an Ambro model means M pulls back under every birational base change, and a good Ambro model additionally has semiample M. The source's Ambro terminology omits the customary log-smooth-base condition. Nefness alone must not be substituted for semiampleness when the later special-test theorem needs the latter.

The b-semiampleness conjecture is called open in this 2023 source, which gives no present-2026 status certification. No canonical problem atom is added or changed. Smooth-curve good-Ambro and the log-twisted-Fano semiampleness lemma are attributed Ambro/Kawamata–Mori inputs. Lemma 2.30's local argument is consistent: M nef and -(K+B+M) big/nef imply -(K+B) big/nef; a klt base and the basepoint-free theorem then give M semiample.

The elliptic table records lct values 1, 5/6, 3/4, 2/3, 1/2, 1/6, 1/4, 1/3, and 1/m for the stated fiber types, with cited Kodaira foundations. For rational elliptic index m, deg(M+B)=2-1/m, hence the twisted anticanonical degree is 1/m. Combined conditionally with the already displayed curve S=deg/2, the corresponding delta equals 2m times the minimum fiber threshold. This gives an arithmetic consistency check on the strict and equality boundaries, but awaits the log-twisted delta criterion and main implication proofs. No elliptic surface construction or fiber-classification proof has been newly supplied.

The last paragraph switches to relatively ample H for elliptic fibrations despite the earlier globally ample polarized-total-space definition. A base-ample shift makes the eventual classes ample; any future transport should write that shift explicitly. This is a definitional scope issue, not evidence of a main-theorem counterexample. Formula glyphs and the full selected pages are legible; no active book edit occurs.
