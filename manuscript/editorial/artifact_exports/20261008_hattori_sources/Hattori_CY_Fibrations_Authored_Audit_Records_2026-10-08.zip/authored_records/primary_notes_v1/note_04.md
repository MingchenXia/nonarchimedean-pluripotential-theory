# Hattori v2 actual source view 04

UTC: 2026-10-08T18:52:50.126053+00:00. Physical pages: 7, 8.

Complete pages 7–8 and matching image were read. Definition 2.5 uses canonical compactifications over P1, with trivialization off zero and line-bundle action trivialized at infinity. Component valuations are ord_E restricted to X divided by central multiplicity b_E. All intersection functionals in 2.8 divide by V=L^n; DF uses the ordinary relative canonical divisor, whereas M uses its logarithmic nonreduced-central-fiber correction. These must not be conflated.

Direct substitution into the displayed definitions, for a fixed model and positive rational polarization factor lambda, gives E(lambda L)=lambda E(L), J(lambda L)=lambda J(L), I(lambda L)=lambda I(L), but J^H(lambda L)=J^H(L) for fixed auxiliary H. The canonical slope scales by lambda^{-1}, so the displayed volume-normalized DF and M are invariant under polarization scaling. The identity I-J=J^L is consistent when both the reference L and model polarization scale. This elementary dictionary concerns polarization rescaling, not a normalized base change: 2.11 gives exact degree scaling for M and only the stated inequality for DF.

Thus A_epsilon=epsilon(H+epsilon^{-1}f*L) transports a uniform inequality DF_A>=c J_A to DF_{P_k}>=c/k J_{P_k}, k=epsilon^{-1}. This conclusion is directly conditional on the matched classes/models and the displayed normalization, without using the main cscK theorem. The next formal adiabatic definition still must be read.

Two printed preliminary slips are retained as qualifications: the entropy sum has A_(X,B) although this subsection's boundary is Delta; its intersection identity fixes the intended boundary. Lemma 2.9's final upper-bound typography is malformed, while the accompanying prose cites the standard norm equivalence. No quantitative constant is imported from that malformed final expression. Pullback invariance, entropy formulas and general norm equivalence remain attributed BHJ inputs, not freshly proved external results. No main theorem is certified from these definitions alone.
