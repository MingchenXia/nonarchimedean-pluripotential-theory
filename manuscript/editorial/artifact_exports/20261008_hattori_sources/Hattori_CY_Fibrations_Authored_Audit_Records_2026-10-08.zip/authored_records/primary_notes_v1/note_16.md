# Hattori v2 actual source view 16

UTC: 2026-10-08T19:03:54.974113+00:00. Physical pages: 31, 32.

Complete pages 31–32 and matching image were read. The non-nef-canonical sufficiency combines a fixed base delta margin, K+Delta=-(2-s)f*O(1), the nonstrict form of Lemma 4.14 and A.6 to yield M>=delta(I-J), with one delta over the whole small interval. This constant mechanism matches Definition 2.18 after fixed dimension norm equivalence. The algebraic dependency remains qualified by the earlier alpha/delta and model proof issues.

The smooth cscK clause is a separate analytic import: coercivity from Zhang/Chen followed by Chen–Cheng. The source does not provide those analytical proofs here. Its final one-paragraph proof of Theorem 1.1 refers to the nef-canonical stability corollary, but that algebraic corollary alone does not establish cscK existence; the corresponding analytic nef-canonical inputs discussed in the introduction remain necessary. No general YTD implication is inferred merely from uniform K-stability.

The rational elliptic criterion is max s_Q<1-1/(2m), equivalent to min fiber-lct>1/(2m). The printed strict/equality cases agree with the arithmetic from note 07: index-one I_N* at lct=1/2, index-two III* at 1/4, and index-three II* at 1/6 are equality boundaries, not automatically unstable. The source's stable/unstable lists leave these semistable cases distinct. Imported Kodaira classification and actual surface existence are not freshly verified. Remark 4.19 explains why placing B inside the twist loses discriminant information: degree alone can stabilize the boundary-free base while the log boundary records a bad fiber.

Appendix A begins by defining a uniquely determined central divisor for Ding using the line-bundle trivialization off zero. The twist can be represented by a general difference when it is not nef. Independence of that representative and the beta/Ding criterion are pending subsequent proof reading. The exact Ding energy denominator is (n+1)L^n. No main theorem admission, canonical status change or active book edit occurs.
