# Hattori v2 actual source view 12

UTC: 2026-10-08T18:59:24.242976+00:00. Physical pages: 23, 24.

Complete pages 23–24 and matching image were read. Theorem 4.1 compares the volume-weighted numerator V_epsilon DF, not an unnormalized assertion about a polynomial DF. Its leading volume is binom(n,c) epsilon^(n-c) H_fiber^(n-c) L^c, and the normalized slope is c/n times the base slope plus O(epsilon). The final displayed combined base bracket has the correct factor c/(c+1), since binom(n+1,c+1)c/(n+1)=binom(n,c)c/(c+1). One intermediate leading-term line omits the common epsilon power and n/(n+1) factor; it is not used literally in a transported formula.

The codimension-two exceptional locus from Proposition 4.3 cannot contribute to the leading term with c powers of the pulled-back base line bundle, by dimension/projection. The moduli comparison rho*M_base-M_model effective is an attributed b-nef/negativity input. With reduced base central fiber DF_twisted=M_twisted, normalized base change scales M by its degree, and negativity persists for all small rational epsilon. This reconciles the introductory polynomial shorthand: multiplying by volume yields a finite intersection polynomial, while the defined DF is volume-normalized.

Lemma 4.5 obtains one G and epsilon0 by ampleness on the fixed base, independently of test configurations. Lemma 4.6's constant absorption is consistent after the standard J/minimum-norm equivalence: if M>=delta N and J^K>=-G N, then M>=t entropy+[(1-t)delta-tG]N. Choosing a fixed t<delta/(2(delta+G)) gives a positive common margin. General norm equivalence remains an imported foundation.

Equation (13) starts a strict inequality stated for every normal test, which cannot include the trivial test (both energies are zero). It should at least be restricted to nontrivial tests or read nonstrict where only semistability is needed. The continuation must determine its actual use. The Fano/Ambro/klt restrictions of Theorem 4.7 remain explicit. No theorem refutation, external proof certification, active book edit or canonical status change is claimed.
