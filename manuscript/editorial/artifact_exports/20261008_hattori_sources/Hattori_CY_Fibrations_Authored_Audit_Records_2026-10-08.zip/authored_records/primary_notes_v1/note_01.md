# Hattori v2 actual source view 01

UTC: 2026-10-08T18:51:03.217499+00:00. Physical pages: 1, 2.

The complete selected text and matching two-page image were actually read. The pinned header confirms 2203.11460v2, 9 August 2023, Masafumi Hattori. Definition 1.1 uses epsilon H+f*L and all sufficiently small epsilon, not a threshold chosen separately for each test. The precise quantitative uniform definition is deferred to 2.18 and has not yet been read.

Theorem 1.1 is currently an attributed statement pending proof review: a polarized klt-trivial fibration over a smooth curve, with canonical-bundle-formula discriminant B and moduli M, is uniformly adiabatically K-stable exactly when the base is log-twisted K-stable. The cscK conclusion additionally requires Delta=0, smooth total X and sufficiently small positive rational epsilon. The f* on L is suppressed in the theorem's displayed final class; no change of meaning is inferred. Singular fibers are allowed in this setup, unlike the smooth-fiber frameworks discussed above.

Miranda's conjecture and the reported failure of its part (b) are historical source claims; the forthcoming-paper remark gives no present-day open-status certification. The abstract and introduction supply no proof credit for external cscK, YTD, moduli or canonical-bundle-formula foundations. Applicability to the projective-bundle unit cannot be inferred from the common word adiabatic; its relative canonical hypotheses still require checking. Mathematical glyphs and theorem hypotheses are legible in the displayed image. No repair or canonical status change follows from these introductory pages.
