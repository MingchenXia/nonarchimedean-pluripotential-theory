# Hattori v2 actual source view 20

UTC: 2026-10-08T19:07:28.211307+00:00. Physical pages: 39, 40.

Complete pages 39–40 and matching image were read. A.12/A.13 reduce the semiample-twist problem to relative anticanonical and special tests via equivariant MMP and model independence for sufficiently general representatives. Those Li–Xu/Fujita/BCHM foundations remain imported; a fixed chosen model and finite centers are the scope of the general-divisor comparisons. The ensuing beta criterion is therefore attributed rather than independently recertified by this reading.

A.15 divides beta and j by vol(L), matching the earlier volume-normalized definitions. Its proof prints beta_(X,B,T)=beta_(X,B), but the established A.3 comparison is beta_(X,B,T)=beta_(X,B+T1). The boundary-free ordinary beta would use a different anticanonical polarization when T is nonzero. The intended boundary B+T1 must be retained. A.16 has the stated delta in [0,1), with uniform margins transported only through the standard norm/scaling equivalences.

The P1 criterion in A.17 is arithmetically consistent: if s=deg(Delta+T)<2 and a=max point boundary coefficient, S_L(P)=(2-s)/2 gives beta(P)/vol(L)=(s/2)-a_P. Uniform positivity therefore means a<s/2, and semipositivity means a<=s/2, under the attributed all-test beta criterion. For m=0, the printed max over the empty set needs the explicit convention a=max({0} union {a_i}), since points outside the boundary have coefficient zero. Otherwise the ordinary untwisted P1 would incorrectly look uniformly stable; with this convention T=0 gives only equality and positive deg T gives a strict margin. No present-day open-status conclusion follows.

The rational elliptic arithmetic uses this strict/equality boundary and must not treat equality as instability. A.10's promised destabilizing-boundary proof continues on the next page. No active book edit, original general theorem, canonical atom or independent-model receipt changes. All displayed formulas are legible.
