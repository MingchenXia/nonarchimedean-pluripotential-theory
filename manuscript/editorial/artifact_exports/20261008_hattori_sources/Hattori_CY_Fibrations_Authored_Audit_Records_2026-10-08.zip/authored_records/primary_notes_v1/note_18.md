# Hattori v2 actual source view 18

UTC: 2026-10-08T19:05:34.477865+00:00. Physical pages: 35, 36.

Complete pages 35–36 and matching image were read. A.7's final discrepancy calculation cancels the flag cutoff and yields A(F)-delta T(F)-(1-delta)S(F)>=0, equivalent to beta>=delta j. The finite flag-ideal approximation and asymptotic volume inputs remain Fujita imports. The earlier cutoff wording e+>r T(F) cannot be held literally while e+ is a fixed cutoff in a limit r→infinity; its intended Cartier-denominator-scaled fixed cutoff must be distinguished from the approximation index. No autonomous flag-ideal proof is claimed.

Propositions A.8/A.9 provide a component-minimum Ding formula after a dominating lc-modification and normalized base change. Their general log-resolution, lc-modification and valuation-filtration foundations remain imported. The converse Ding argument is only beginning here and continues on the next page.

A.6's printed polarization scaling is incompatible with Definition 2.8: it writes entropy(rL)=r^n entropy(L) and (I-J)(rL)=r^(n+1)(I-J)(L), which are unnormalized degrees. For the actual volume-normalized definitions entropy is invariant and I-J scales by r, as directly checked in note 04. The following printed equality with an r^(n+1) multiplier is also inconsistent. The desired final entropy estimate can nevertheless be deduced from the first assertion using the correct dictionary: for positive rational r<delta(L), delta(rL)>=1 gives entropy(L)=entropy(rL)>=(I-J)(rL)=r(I-J)(L); let r increase to delta(L). This does not prove the pending Ding criterion itself or refute the entropy estimate.

The distinction between unnormalized intersection numerators and normalized functionals is now a concrete primary-source issue, reinforcing why the book comparison must explicitly state its conventions. No general theorem or canonical status is promoted; all selected formulas and image text are legible.
