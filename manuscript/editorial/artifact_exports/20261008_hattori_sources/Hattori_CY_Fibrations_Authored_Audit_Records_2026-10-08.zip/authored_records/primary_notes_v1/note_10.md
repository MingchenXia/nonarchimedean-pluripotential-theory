# Hattori v2 actual source view 10

UTC: 2026-10-08T18:57:20.306192+00:00. Physical pages: 19, 20.

Complete pages 19–20 and matching image were read. Theorem 4.1 is a contrapositive descent statement: a polarized lc-trivial fibration with Q-Cartier moduli and log-twisted unstable base is adiabatically unstable. Proposition 4.2 prepares an equivariant good minimal model W and one relative lc model Xcal valid over a small rational epsilon interval, then obtains polarized test configurations after adding a suitable ample base divisor.

The proof explicitly uses dlt modification, Hashizume–Xu good-minimal-model extension, MMP termination/equivariance and log-model uniqueness foundations. These sources have not been recursively proof-read. Its finite MMP-step perturbation threshold depends on the chosen model and ample representative. The absence of central-only lc centers is justified via the assumed snc union of boundary and central fiber; it is not available for arbitrary singular boundary data.

The common lc-model construction is locally consistent: start from a semiample unperturbed model over Ccal, take its Proj Z, choose one positive perturbation with a good model over Z, and interpolate its relative canonical divisor with the pullback of a Z/Ccal-ample divisor. For sufficiently small positive interpolation parameter, relative ampleness and non-positivity give the same lc model. The paragraph fixes epsilon' in an interval named epsilon0 before epsilon0 is defined; choosing it in the preceding epsilon1 interval removes that circular notation without supplying a new MMP proof.

The final polarization on this page is only being constructed; no statement yet establishes an eventual negative DF for every small parameter. The later base-comparison expansion and volume denominator remain to be checked. No general descent theorem, equivariant flatness result or independent-model receipt is certified by this preparatory argument alone. All selected formulas are readable; no active book or canonical status change occurs.
