# Hattori v2 actual source view 19

UTC: 2026-10-08T19:06:40.864593+00:00. Physical pages: 37, 38.

Complete pages 37–38 and matching image were read. The Ding converse in A.6 compares the filtered graded algebra with each component valuation: its shifted section filtration is contained in the corresponding valuation filtration, so the volume integral is bounded by S_L(v_E). With A>=S, the component minimum is nonnegative. The integration-by-parts expression and filtration/weight-support formula remain attributed BHJ foundations. This completes the primary's displayed Ding proof, with the normalized polarization correction in note 18 still required for its entropy scaling paragraph.

A.10 changes the polarization together with the boundary: B→B+epsilon D and L→(1-epsilon)L, preserving the log-twisted Fano equality. Section 4's use at fixed L needs the separately checked scalar-polarization invariance of DF, so this class change must not be omitted without explanation. Its twist-semiample assumption is essential to the special-test reduction.

A.11's proof writes exact DF equality after normalized base change. This is stronger than the source's own 2.11 and fails in general for nonreduced central fibers; the needed direction is DF(X^(d))<=d DF(X). Replacing that equality by the inequality still gives the stated upper bound. Ding scales exactly. The model domination here is domination of underlying varieties, since Llc=h*L^(d)-epsilon F is not the exact pullback polarization required by Definition 2.8's stronger domination terminology.

The exceptional boundary E in the lc-modification paragraph is not precisely introduced, and lc-model independence/equivariant MMP comparisons are delegated to Li–Xu/Fujita/BCHM. These proofs have not been recursively verified. A.12 starts another log-twisted anticanonical modification; the statement retains T semiample and lc central boundary. No special-test reduction, general cscK equivalence or canonical status is independently certified from these imported model arguments. All selected pages and formulas were legible.
