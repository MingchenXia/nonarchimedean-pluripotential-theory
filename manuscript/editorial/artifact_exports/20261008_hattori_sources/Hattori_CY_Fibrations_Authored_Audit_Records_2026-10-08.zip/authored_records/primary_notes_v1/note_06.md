# Hattori v2 actual source view 06

UTC: 2026-10-08T18:54:05.095934+00:00. Physical pages: 11, 12.

Complete pages 11–12 and matching image were read. Log-twisted DF=DF_B+J^T and log-twisted M=M_B+J^T are defined for a Q-line-bundle twist T which need not be nef. The stability definition in 2.20 is stated with M, not by silently substituting DF for each individual nonreduced test. The log-twisted Fano condition is L Q-linearly equivalent to -(K_X+B+T), with (X,B) klt. Later special-test reduction in 2.25 additionally assumes T semiample.

Lemma 2.22 is a test-dependent general-divisor comparison: a representative D of T must avoid the finite centers of the component valuations of the given model. The difference between its total and strict transforms then has zero intersection with the pulled-back polarization by the exceptional projection formula. This does not produce one general divisor simultaneously adapted to every test configuration. Negative twists use a difference of sufficiently positive general divisors; external reduction arguments remain attributed.

Definition 2.26 fixes the klt/lc-trivial hypothesis K_X+Delta Q-linearly trivial over C, connected fibers, and (for subpairs) the rank-one discrepancy-sheaf condition. In the effective globally klt/lc case the source uses the simpler definition. For the preceding Delta=0 projective bundles with fiber P^(r-1), r>1, the fiber canonical class is O(-r), hence is not Q-trivial. Hattori's main klt-trivial theorem therefore does not apply directly to those projective bundles. Its normalization/quantifier definitions can still be compared independently.

The short proofs of 2.23/2.24 explicitly defer substantial singularity and entropy foundations, with the second assertion of 2.23 left to the reader. These are attributed inputs pending relevant proof checks, not independently verified main-theorem ingredients. The scalar-polarization dictionary from notes 04–05 continues to concern only definitions. No source proof repair or new stable family is claimed, and no active book edit or canonical status change occurs.
