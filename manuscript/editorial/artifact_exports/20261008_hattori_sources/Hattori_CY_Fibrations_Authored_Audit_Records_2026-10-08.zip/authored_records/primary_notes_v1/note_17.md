# Hattori v2 actual source view 17

UTC: 2026-10-08T19:04:40.605748+00:00. Physical pages: 33, 34.

Complete pages 33–34 and matching image were read. The log-twisted beta invariant is V(A_B(F)-S_L(F)); its j invariant is V(T_L(F)-S_L(F)). Lemma A.3 chooses a sufficiently general twist representative for the fixed test or fixed valuation, avoiding its centers. Its resolution argument relies on snc support and horizontal coefficients below one, so the central lct does not change; this is not one divisor independent of all tests. The second beta comparison is explicitly achieved by avoiding the chosen F center.

Proposition A.5 imports Ding pullback invariance, exact normalized-base-change scaling and Ding<=DF with its relative anticanonical/equality conditions from Fujita and the subpair extension. These external proofs are not freshly read. Ding and DF scaling under base change is separate from the scalar polarization dictionary already checked directly.

Theorem A.6 is the remaining major entropy input: for any polarized klt pair and T=-(K+Delta+L), delta>=1 is equivalent to twisted Ding semistability, and entropy>=delta(I-J). T need not be nef; this flexibility is central to the previous Section 3/4 arguments. Theorem A.7 starts the Fujita flag-ideal approximation giving valuation beta positivity from Ding bounds. Its flag-ideal degree/range symbols, log-resolution/model semiample claims and asymptotic estimates are attributed Fujita machinery and still await the continuation. The printed j_(X,B,T) notation denotes the previously defined j_L, not a new independent norm.

No Ding/entropy general theorem has yet been promoted based on the theorem statement alone. The selected formulas and both pages are legible, and no active book, canonical atom or independent-model receipt changes.
