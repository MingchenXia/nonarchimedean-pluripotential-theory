# Hattori v2 actual source view 11

UTC: 2026-10-08T18:58:23.289397+00:00. Physical pages: 21, 22.

Complete pages 21–22 and matching image were read. Proposition 4.3 normalizes a finite base change, arranges reduced base central fiber, constructs an ample total-space test for H+rL, and obtains the canonical-bundle comparison only above a base open U with codimension-at-least-two complement. It does not assert a global equality on the entire model. The later leading-order expansion must account for divisors over the omitted codimension-two set.

The discriminant calculation has unit fiber multiplicities after reduced compatible central fibers: over a generic central component P its coefficient is max_G(1-A(G)). The excess divisor D then has coefficients A(Q)-min_G A(G)>=0 and misses at least one component of each generic fiber. The claimed elimination of its insufficient-fiber-type part uses Lai/Hashizume–Xu negativity and good-model foundations, not a direct elementary effectivity cancellation. All semistable-reduction/MMP/b-divisor imports remain unverified recursively.

Two wording scopes need care. The phrase Y0+rho*Theta is a reduced snc divisor cannot literally preserve arbitrary rational coefficients of Theta or multiplicities of its total transform; the required snc support and reduced central fiber must be distinguished from boundary coefficients. Also Hartshorne generic smoothness alone does not justify ordinary relative log smoothness over a neighborhood including a special central divisor. The threshold formula can instead be motivated by the displayed snc divisor and unit central multiplicities; a complete model justification remains a source dependency. No main-descent refutation is claimed from these abbreviated phrases.

The lift from the generic Q-linear triviality to the crepant pair Xi, the moduli trace and the codimension-two exclusion are recorded in their precise scopes. The final polarization may be increased along the base to an integral r without changing the eventual family. This is preparatory proof reading; no eventual DF sign has yet been established, and no active book or canonical status change occurs.
