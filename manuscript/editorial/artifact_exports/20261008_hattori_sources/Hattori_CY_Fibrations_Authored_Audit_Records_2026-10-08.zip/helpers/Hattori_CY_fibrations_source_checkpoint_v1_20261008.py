from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess
R=Path('/workspace/nonarchimedean-pluripotential-theory');M=R/'manuscript';E=M/'editorial';C=R/'source_material/Hattori_CY_fibrations_review_20261008';out=C/'source_checkpoint_v1_20261008.json';assert not out.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths={k:E/f'Hattori_CY_fibrations_{k}_20261008.{ext}' for k,ext in [('source_review','md'),('source_reading_notes','md'),('source_reading_manifest','json'),('source_artifacts','json')]};assert paths['source_review'].exists() and not any(p.exists() for k,p in paths.items() if k!='source_review')
actual=C/'actual_primary_reading_v1_20261008.json';a=json.loads(actual.read_text());assert sha(actual)=='06412e23cad506faf4da5b48e8b7f9e4ec2467afd12ec05aa25bf75478deb50a' and a['actual_distinct_source_page_pairs']==44
prep=C/'primary_view_preparation_v1_20261008.json';assert sha(prep)=='38bcec9ee43ab2aae7007c682f303a0c167ab46e0f6341c19deeb6d53a5d4e94'
diag=C/'exact_diagnostics_v1_20261008.json';assert sha(diag)=='24ee27a0ac98d8a01cb332636b6128bcbdac8476a25b310738b5ff39b449ac4b'
notes='# Actual sequential Hattori arXiv v2 source notes, 8 October 2026\n\nAll 44 pages in 22 individually displayed matching views. These observations concern only the pinned 2023 v2; journal 2025 proof text remains unread. Earlier pending questions remain in their sequential notes, with later resolutions recorded later.\n'
for n in a['actual_observations']:notes+='\n---\n\n'+Path(n['note_path']).read_text()
paths['source_reading_notes'].write_text(notes)
core=set()
for line in (M/'book.fls').read_text().splitlines():
 if line.startswith('INPUT '):
  p=Path(line[6:]);p=(p if p.is_absolute() else M/p).resolve()
  if p.is_relative_to(M) and p.suffix=='.tex':core.add(p)
assert len(core)==425;core.update((M/'bibliography').glob('*.bib'));assert len(core)==427
core.update([M/'book.pdf',R/'output/open_problems_catalogue_2026-10-03.tex',R/'output/open_problems_catalogue_2026-10-03.pdf']);protected={str(p):sha(p) for p in sorted(core)}
assert sha(M/'book.pdf')=='6e4502385c0a82d6fb554feae08f2e9f45a47efdd87f147ff792c3a14e3f8ca1'
manifest=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — complete primary reading and exact scoped diagnostic; general equivalence qualified',actual_ledger_path=str(actual),actual_ledger_SHA256=sha(actual),actual_record=a,source_audit_SHA256=sha(paths['source_review']),exact_diagnostic_path=str(diag),exact_diagnostic_SHA256=sha(diag),journal_metadata_checked=True,journal_PDF_request_status='FAILED — returned HTML; frozen acquisition record; zero journal proof credit',journal_full_text_read=False,whole_book_new_reading_claim=False,active_book_changed=False,canonical_status_changes=[],GitHub_published=False)
paths['source_reading_manifest'].write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
helpers=[p for p in Path('/tmp').glob('Hattori_CY_fibrations_*_20261008.py') if p.name!='Hattori_CY_fibrations_source_checkpoint_v1_20261008.py']+[Path(__file__)]
files=[p for name in ['Hattori_CY_fibrations_sources_20261008','Hattori_CY_fibrations_review_20261008'] for p in (R/'source_material'/name).rglob('*') if p.is_file()]
artifacts=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — cloud source checkpoint before authorized publication',files=[dict(path=str(p),bytes=p.stat().st_size,SHA256=sha(p)) for p in sorted(files)],helpers={str(p):sha(p) for p in sorted(helpers)},editorial_files={str(p):sha(p) for k,p in paths.items() if k!='source_artifacts'},protected_core_inputs=protected,active_TeX_inputs_preserved=425,bibliographies_preserved=2,native_catalogue_preserved=True,book_PDF_preserved=True,journal_full_text_read=False,reading_credit_from_exports=0,GitHub_published=False)
paths['source_artifacts'].write_text(json.dumps(artifacts,ensure_ascii=False,indent=2)+'\n')
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — cloud source checkpoint; subsequent publication must have its own record',baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),editorial_files={str(p):sha(p) for p in paths.values()},protected_core_inputs=protected,actual_source_pages=44,actual_images=22,actual_primary_reading_SHA256=sha(actual),exact_diagnostics_SHA256=sha(diag),general_equivalence_admitted=False,active_book_changed=False,GitHub_published=False,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
for p,h in protected.items():assert sha(Path(p))==h
print(json.dumps(dict(status=obj['status'],checkpoint_SHA256=sha(out),editorial_files=len(paths),protected_inputs=len(protected))))
