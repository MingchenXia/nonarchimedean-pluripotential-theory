from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,urllib.request,subprocess,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Hattori_CY_fibrations_review_20261008';S=R/'source_material/Hattori_CY_fibrations_sources_20261008'
out=C/'primary_acquisition_v1_20261008.json';pdf=S/'Hattori_CY_fibrations_arxiv_v2.pdf';assert not out.exists() and not pdf.exists()
meta=json.loads((C/'metadata_acquisition_v1_20261008.json').read_text())['metadata'];assert meta['id'].endswith('2203.11460v2') and meta['updated']=='2023-08-09T01:19:00Z'
url='https://arxiv.org/pdf/2203.11460v2'
with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Scholarly-source-review/1.0'}),timeout=30) as r:data=r.read();status=r.status;resolved=r.url
assert data.startswith(b'%PDF');pdf.write_bytes(data)
txt=pdf.with_suffix('.txt');assert not txt.exists();result=subprocess.run(['pdftotext','-layout',str(pdf),str(txt)],capture_output=True,text=True);assert result.returncode==0
with fitz.open(pdf) as d:pages=len(d)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — pinned primary acquisition only; zero reading credit',source=dict(path=str(pdf),requested_URL=url,resolved_URL=resolved,HTTP_status=status,bytes=len(data),SHA256=sha(pdf),physical_pages=pages,text_path=str(txt),text_SHA256=sha(txt),text_extraction_stderr=result.stderr),metadata=meta,baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),active_book_PDF_SHA256=sha(R/'manuscript/book.pdf'),native_catalogue_source_SHA256=sha(R/'output/open_problems_catalogue_2026-10-03.tex'),actual_proof_reading_credit=0,active_book_changed=False,canonical_status_changes=[],helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status=obj['status'],record_SHA256=sha(out),source=obj['source']),ensure_ascii=False))
