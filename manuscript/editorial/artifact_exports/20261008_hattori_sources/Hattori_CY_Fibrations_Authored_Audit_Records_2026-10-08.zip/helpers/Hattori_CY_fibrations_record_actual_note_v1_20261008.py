from pathlib import Path
from datetime import datetime,timezone
import sys,json,hashlib
C=Path('/workspace/nonarchimedean-pluripotential-theory/source_material/Hattori_CY_fibrations_review_20261008');W=Path('/tmp/Hattori_CY_fibrations_primary_views_v1_20261008');N=C/'primary_notes_v1'
number=int(sys.argv[1]);assert 1<=number<=22
p=N/f'note_{number:02d}.md';receipt=N/f'note_{number:02d}_receipt.json';assert not p.exists() and not receipt.exists()
if number>1:assert (N/f'note_{number-1:02d}_receipt.json').exists()
row=json.loads((W/'manifest.json').read_text())[number-1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(Path(row['path']))==row['image_SHA256'] and sha(Path(row['selected_text_path']))==row['selected_text_SHA256']
body=sys.stdin.read();assert len(body)>150
stamp=datetime.now(timezone.utc).isoformat();p.write_text(f'# Hattori v2 actual source view {number:02d}\n\nUTC: {stamp}. Physical pages: '+', '.join(map(str,row['physical_pages']))+'.\n\n'+body.rstrip()+'\n')
obj=dict(number=number,UTC=stamp,physical_pages=row['physical_pages'],source_PDF_SHA256=row['source_PDF_SHA256'],image_path=row['path'],image_SHA256=row['image_SHA256'],selected_text_path=row['selected_text_path'],selected_text_SHA256=row['selected_text_SHA256'],complete_selected_text_actually_read=True,matching_image_individually_displayed_and_reviewed=True,note_path=str(p),note_SHA256=sha(p),reading_credit=len(row['physical_pages']),not_an_independent_model_receipt=True,preparation_flags_unchanged=True,helper_source=__file__)
receipt.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(number=number,pages=row['physical_pages'],receipt_SHA256=sha(receipt))))
