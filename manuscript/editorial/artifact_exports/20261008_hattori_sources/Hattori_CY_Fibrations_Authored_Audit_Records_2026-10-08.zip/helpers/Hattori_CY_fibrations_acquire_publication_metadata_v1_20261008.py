from pathlib import Path
from datetime import datetime,timezone
import urllib.request,json,hashlib
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Hattori_CY_fibrations_review_20261008';S=R/'source_material/Hattori_CY_fibrations_sources_20261008';out=C/'publication_metadata_acquisition_v1_20261008.json';p=S/'Hattori_CY_fibrations_Crossref_metadata.json';assert not out.exists() and not p.exists()
url='https://api.crossref.org/works/10.1017/S1474748024000598'
try:
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Scholarly-source-review/1.0'}),timeout=30) as r:data=r.read();status=r.status;resolved=r.url
 p.write_bytes(data);m=json.loads(data)['message'];metadata={k:m.get(k) for k in ['DOI','title','author','container-title','volume','issue','page','published','published-print','published-online','license','link']};record=dict(status='DONE — journal metadata only; journal proof text unread',UTC=datetime.now(timezone.utc).isoformat(),path=str(p),URL=url,resolved_URL=resolved,HTTP_status=status,SHA256=hashlib.sha256(data).hexdigest(),metadata=metadata,proof_reading_credit=0)
except Exception as e:record=dict(status='FAILED — no journal text or metadata credit',UTC=datetime.now(timezone.utc).isoformat(),URL=url,error_type=type(e).__name__,error=str(e),proof_reading_credit=0)
record['helper_source']=__file__;out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n');print(json.dumps(record,ensure_ascii=False))
