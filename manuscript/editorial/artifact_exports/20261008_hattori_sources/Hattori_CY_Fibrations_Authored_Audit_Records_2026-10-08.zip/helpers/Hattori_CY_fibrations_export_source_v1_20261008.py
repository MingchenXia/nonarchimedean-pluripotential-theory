from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,zipfile,shutil
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Hattori_CY_fibrations_review_20261008';S=R/'source_material/Hattori_CY_fibrations_sources_20261008';E=R/'manuscript/editorial';W=Path('/tmp/Hattori_CY_fibrations_primary_views_v1_20261008');O=Path('/workspace/book-completion-drafts/research-integration');out=C/'source_export_v1_20261008.json';assert not out.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
cp=C/'source_checkpoint_v1_20261008.json';assert sha(cp)=='aeb449585ea3126087f3eb4584485106d6c24c2426d48072b9d96c8bad1d1375';obj=json.loads(cp.read_text())
for p,h in obj['protected_core_inputs'].items():assert sha(Path(p))==h
editorial=[Path(p) for p,h in obj['editorial_files'].items()];assert all(sha(p)==obj['editorial_files'][str(p)] for p in editorial)
cache=[p for p in C.rglob('*') if p.is_file()];helpers=sorted(Path('/tmp').glob('Hattori_CY_fibrations_*_20261008.py'))
full={f'primary/{p.name}':p for p in S.iterdir() if p.is_file()}
full.update({f'actual_views/{p.name}':p for p in W.iterdir() if p.is_file()})
full.update({f'authored_records/{p.relative_to(C)}':p for p in cache});full.update({f'editorial/{p.name}':p for p in editorial});full.update({f'helpers/{p.name}':p for p in helpers})
authored={f'authored_records/{p.relative_to(C)}':p for p in cache};authored.update({f'editorial/{p.name}':p for p in editorial});authored.update({f'helpers/{p.name}':p for p in helpers})
def export(path,items):
 assert not path.exists()
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for name,p in sorted(items.items()):z.write(p,name)
 with zipfile.ZipFile(path) as z:
  assert sorted(z.namelist())==sorted(items)
  for name,p in items.items():assert z.read(name)==p.read_bytes(),name
 return dict(path=str(path),bytes=path.stat().st_size,SHA256=sha(path),members=len(items),members_byte_verified=True)
fullzip=export(O/'Hattori_CY_Fibrations_Actual_Source_Evidence_2026-10-08.zip',full)
authzip=export(O/'Hattori_CY_Fibrations_Authored_Audit_Records_2026-10-08.zip',authored)
review=O/'Hattori_CY_Fibrations_Actual_Source_Review_2026-10-08.pdf';assert not review.exists();shutil.copy2(S/'Hattori_CY_fibrations_arxiv_v2.pdf',review)
D=E/'artifact_exports/20261008_hattori_sources';assert not D.exists();D.mkdir()
p=D/Path(authzip['path']).name;shutil.copy2(authzip['path'],p);assert sha(p)==authzip['SHA256']
(D/'SHA256SUMS').write_text(sha(p)+'  '+p.name+'\n')
(D/'README.md').write_text('''# Hattori source audit, 8 October 2026\n\nThe authored audit archive records the complete 44-page arXiv:2203.11460v2 reading in 22 individually displayed matching views and 22 sequential notes, with exact normalization/intersection diagnostics. Its controlling edition was updated 9 August 2023; this is a foundational dependency review for the book's adiabatic unit.\n\nThe archive contains authored notes, actual-reading/hash records, the four editorial audit files and diagnostic/acquisition helpers. The original primary PDF, extracted full text, matching images and complete source evidence archive remain in the cloud cache. The source is linked at https://arxiv.org/abs/2203.11460v2.\n\nCrossref and publisher metadata identify the 2025 JIMJ publication, DOI 10.1017/S1474748024000598. The publisher-linked PDF returned HTML; its failed acquisition has zero journal proof credit. The old-version proof observations do not assert defects in that unread journal edition.\n\nThe directly checked material is the volume-normalized polarization dictionary, uniform delta/epsilon0 quantifiers and one reducible-fiber proof-equality diagnostic. The source's general klt-trivial stability/cscK equivalence retains its qualifications. No new original general theorem or independent-model receipt is claimed. The active book is still the validated 4,632-page edition at this source checkpoint.\n\nSHA256SUMS pins the archive. All members were byte-verified against their source files. Export/upload gives zero extra reading credit. The 42 atoms and twelve formal problems are unchanged; general BJ22 critical homogeneous Siu division/envelopes remain OPEN and LPWZ density remains UNVERIFIED. This is not a new whole-book pass.\n''')
record=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — source archives byte-verified; repository upload still pending at this export',full_source_evidence=fullzip,authored_source_evidence=authzip,source_review_PDF=dict(path=str(review),bytes=review.stat().st_size,SHA256=sha(review),physical_pages=44),repository_artifact_directory=str(D.relative_to(R)),repository_artifact_files={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in sorted(D.iterdir())},external_primary_artifact_upload=False,actual_source_pages=44,actual_images=22,journal_full_text_read=False,export_reading_credit=0,canonical_status_changes=[],GitHub_published=False,helper_source=__file__)
out.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
for p,h in obj['protected_core_inputs'].items():assert sha(Path(p))==h
print(json.dumps(dict(status=record['status'],record_SHA256=sha(out),full_source_evidence=fullzip,authored_source_evidence=authzip,repository_artifact_directory=record['repository_artifact_directory'])))
