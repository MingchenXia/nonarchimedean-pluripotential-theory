from pathlib import Path
from datetime import datetime,timezone
from html.parser import HTMLParser
import urllib.request,json,hashlib,subprocess,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Hattori_CY_fibrations_review_20261008';S=R/'source_material/Hattori_CY_fibrations_sources_20261008';out=C/'journal_PDF_acquisition_v2_20261008.json';pdf=S/'Hattori_CY_fibrations_journal_2025.pdf';assert not out.exists() and not pdf.exists()
class P(HTMLParser):
 def handle_starttag(self,tag,attrs):
  d=dict(attrs)
  if tag=='meta' and d.get('name')=='citation_pdf_url':self.url=d['content']
p=P();p.feed((S/'Hattori_CY_fibrations_journal_VoR_response').read_text());url=p.url;assert url.startswith('https://www.cambridge.org/core/services/aop-cambridge-core/content/view/')
try:
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Scholarly-source-review/1.0'}),timeout=30) as r:data=r.read();status=r.status;resolved=r.url;mime=r.headers.get('Content-Type')
 assert data.startswith(b'%PDF'),f'Expected PDF, got {mime}';pdf.write_bytes(data)
 with fitz.open(pdf) as d:pages=len(d)
 txt=pdf.with_suffix('.txt');assert not txt.exists();x=subprocess.run(['pdftotext','-layout',str(pdf),str(txt)],capture_output=True,text=True);assert x.returncode==0
 source=dict(path=str(pdf),URL=url,resolved_URL=resolved,HTTP_status=status,content_type=mime,bytes=len(data),SHA256=hashlib.sha256(data).hexdigest(),physical_pages=pages,text_path=str(txt),text_SHA256=hashlib.sha256(txt.read_bytes()).hexdigest(),text_extraction_stderr=x.stderr)
 obj=dict(status='DONE — publisher-linked VoR PDF acquired; zero reading credit',UTC=datetime.now(timezone.utc).isoformat(),source=source,actual_proof_reading_credit=0,journal_full_text_read=False,helper_source=__file__)
except Exception as e:obj=dict(status='FAILED — journal PDF unavailable; no journal reading credit',UTC=datetime.now(timezone.utc).isoformat(),URL=url,error_type=type(e).__name__,error=str(e),actual_proof_reading_credit=0,journal_full_text_read=False,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(obj,ensure_ascii=False))
