from pathlib import Path
from datetime import datetime,timezone
import json,hashlib
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Hattori_CY_fibrations_review_20261008';W=Path('/tmp/Hattori_CY_fibrations_primary_views_v1_20261008');out=C/'actual_primary_reading_v1_20261008.json';assert not out.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
prep=C/'primary_view_preparation_v1_20261008.json';expected='38bcec9ee43ab2aae7007c682f303a0c167ab46e0f6341c19deeb6d53a5d4e94';assert sha(prep)==expected
prepared=json.loads(prep.read_text());assert prepared['actually_read_pages']==0 and prepared['actual_source_reading_credit']==0
manifest=json.loads((W/'manifest.json').read_text());assert len(manifest)==22 and all(x['actually_viewed'] is False and x['selected_text_read'] is False for x in manifest)
notes=[];pages=[]
for i,row in enumerate(manifest,1):
 p=C/'primary_notes_v1'/f'note_{i:02d}_receipt.json';note=json.loads(p.read_text());assert note['number']==i and note['physical_pages']==row['physical_pages'] and note['source_PDF_SHA256']==prepared['source_PDF']['SHA256'];assert note['complete_selected_text_actually_read'] and note['matching_image_individually_displayed_and_reviewed'];assert sha(Path(note['note_path']))==note['note_SHA256'];assert sha(Path(note['image_path']))==note['image_SHA256'];assert sha(Path(note['selected_text_path']))==note['selected_text_SHA256']
 notes.append(dict(receipt_path=str(p),receipt_SHA256=sha(p),**note));pages.extend(note['physical_pages'])
assert pages==list(range(1,45));assert sha(R/'manuscript/book.pdf')=='6e4502385c0a82d6fb554feae08f2e9f45a47efdd87f147ff792c3a14e3f8ca1'
obj=dict(status='DONE — complete pinned 44-page primary read in 22 matching individual views and sequential notes',UTC=datetime.now(timezone.utc).isoformat(),source_PDF=prepared['source_PDF'],actual_distinct_source_page_pairs=44,actual_matching_images=22,actual_sequential_notes=22,actual_read_pages=pages,actual_observations=notes,prepared_flags_preserved=False if sha(prep)!=expected else True,preparation_record_SHA256=sha(prep),general_equivalence_admitted=False,independent_model_receipt_claimed=False,canonical_status_changes=[],active_book_changed=False,journal_2025_full_text_read=False,last_whole_book_pass='2026-10-04',reading_credit_from_exports_or_uploads=0,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status=obj['status'],record_SHA256=sha(out),pages=44,images=22)))
