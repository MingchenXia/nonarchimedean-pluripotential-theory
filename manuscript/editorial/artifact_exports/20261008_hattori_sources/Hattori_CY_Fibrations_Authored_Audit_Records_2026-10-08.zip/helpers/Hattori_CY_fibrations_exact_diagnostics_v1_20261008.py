from pathlib import Path
from datetime import datetime,timezone
import sympy as sp,json,hashlib
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Hattori_CY_fibrations_review_20261008';out=C/'exact_diagnostics_v1_20261008.json';assert not out.exists()
x,V,Q,T,U,A,Kref,Kmod=sp.symbols('x V Q T U A Kref Kmod',positive=True)
rows=[]
for n in range(1,7):
 E=T/((n+1)*V);J=Q/V-E;I=Q/V-(T-U)/V;N=I-J;entropy=A/V;aux=U/V-n*E;DF=Kmod/V-n*Kref/V*E
 Vr=x**n*V;Er=x**(n+1)*T/((n+1)*Vr);Jr=x**(n+1)*Q/Vr-Er;Ir=x**(n+1)*Q/Vr-(x**(n+1)*T-x**(n+1)*U)/Vr;Hr=x**n*A/Vr
 DFr=x**n*Kmod/Vr-n*x**(n-1)*Kref/Vr*Er
 fixed_aux=x**n*U/Vr-n*x**(n-1)*V/Vr*Er
 expected_fixed_aux=U/V-n*E
 residuals=dict(E=sp.simplify(Er-x*E),J=sp.simplify(Jr-x*J),I=sp.simplify(Ir-x*I),minimum_norm=sp.simplify(Ir-Jr-x*N),entropy=sp.simplify(Hr-entropy),DF=sp.simplify(DFr-DF),fixed_auxiliary_J=sp.simplify(fixed_aux-expected_fixed_aux))
 assert all(z==0 for z in residuals.values());rows.append(dict(dimension=n,zero_residuals={k:str(v) for k,v in residuals.items()}))
e,a,b,tau=sp.symbols('epsilon a b tau',positive=True);volume=[]
for n in range(1,7):
 v=n*e**(n-1)*a+e**n*b;integral=n*sp.Rational(1,2)*e**(n-1)*a+e**n*b;printed=sp.Rational(1,2)*e**(n-1)*a+e**n*b
 corrected=sp.limit(integral/v,e,0,dir='+');literal=sp.limit(printed/v,e,0,dir='+');assert corrected==sp.Rational(1,2)
 volume.append(dict(dimension=n,corrected_integral_over_volume_limit=str(corrected),literal_v2_printed_integral_limit=str(literal),tail_is_assumed_bounded_by='epsilon^(n+1)*tau*b'))
# Intersection order is (S,F,E) on the blowup of P1 x P1 at one point.
mat=sp.Matrix([[0,1,0],[1,0,0],[0,0,-1]])
S=sp.Matrix([1,0,0]);F=sp.Matrix([0,1,0]);Exc=sp.Matrix([0,0,1]);G=F-Exc;H=2*S+2*F-Exc;C1=S+F;C2=S;Chor=C1+C2
pair=lambda l,r:(l.T*mat*r)[0]
assert Chor+G==H and pair(F,G)==0
fixture=dict(surface='Bl_point(P1 x P1)',fiber='E+G; G=F-E',ample_H='2S+2F-E',H_square=str(pair(H,H)),horizontal_C1='S+F, through P on G away from E, avoiding blown-up point',horizontal_C2='S, through the same P, avoiding blown-up point',horizontal_class='2S+F',D_hor='epsilon(C1+C2)',D_vert='F+epsilon G',D_total='F+epsilon H',H_dot_G=str(pair(H,G)),D_hor_dot_G=str(e*pair(Chor,G)),D_vert_dot_G=str(pair(F+e*G,G)),D_hor_point_multiplicity_at_transverse_crossing=str(2*e),printed_discarded_vertical_intersection_is_zero=False,correct_fiber_degree_budget=str(e*pair(H,F)),geometric_ampleness_explanation='H^2=7, H.E=1; for any other irreducible strict transform of aS+bF with multiplicity m<=a+b, H.C=2a+2b-m>0. Nakai-Moishezon is an attributed foundation.',scope='Direct worked diagnostic of one printed proof equality; not a counterexample to Lemma 4.8 or the main theorem.')
assert fixture['H_dot_G']=='1' and fixture['D_hor_dot_G']=='2*epsilon' and fixture['D_vert_dot_G']=='-epsilon'
Cm=sp.Rational(1,2);Sm=sp.Rational(2,5);TC=sp.Integer(1);Tm=sp.Rational(6,5);val=Tm;fac=(1-Cm)/(1-Sm);assert TC==fac*Tm and val<=Tm
finite=dict(C=str(Cm),S_m=str(Sm),T_C=str(TC),T_m=str(Tm),S_m_E=str(val),premises_hold=True,printed_minimum_factor_bound=str(min(1,fac)*TC),printed_bound_holds=bool(val<=min(1,fac)*TC),correct_upper_factor_bound=str(max(1,1/fac)*TC),correct_bound_holds=bool(val<=max(1,1/fac)*TC),scope='Algebraic implication fixture only; no valuation or variety realizing these independent numbers is claimed.')
assert finite['printed_bound_holds'] is False and finite['correct_bound_holds'] is True
k,Jk=sp.symbols('k J_k',positive=True);assert sp.simplify((1/k)*Jk-Jk/k)==0
obj=dict(status='DONE — exact definition homogeneities and local worked diagnostics; no general theorem promotion',UTC=datetime.now(timezone.utc).isoformat(),source='arXiv:2203.11460v2',homogeneity_checks=rows,normalized_dictionary=dict(polarization_scale='lambda',E_I_J_minimum_norm='linear in lambda',entropy_DF_fixed_auxiliary_J='invariant under lambda',adiabatic_classes='A_epsilon=epsilon P_(1/epsilon)',uniform_quantifiers='exists delta>0,epsilon0>0; every rational epsilon in (0,epsilon0); every semiample test',large_k_inequality='DF(P_k)>=delta/k J(P_k)',not_a_new_stability_assertion=True),curve_volume_limits=volume,reducible_fiber_fixture=fixture,finite_factor_fixture=finite,entropy_scale_correction='If delta(rL)>=1 implies entropy(rL)>=N(rL), then H(L)>=rN(L); let rational r increase to delta(L). The Ding premise is not independently proved here.',trivial_test_strictness='I=J=entropy=DF=0; strict positive inequalities require nontrivial scope.',general_equivalence_admitted=False,independent_model_receipt_claimed=False,canonical_status_changes=[],active_book_changed=False,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status=obj['status'],record_SHA256=hashlib.sha256(out.read_bytes()).hexdigest(),homogeneity_dimensions=6,volume_dimensions=6,fixture=fixture,finite_factor=finite),ensure_ascii=False))
