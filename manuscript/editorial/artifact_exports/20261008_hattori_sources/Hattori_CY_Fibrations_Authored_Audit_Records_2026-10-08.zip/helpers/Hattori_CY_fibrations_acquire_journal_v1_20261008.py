from pathlib import Path
from datetime import datetime,timezone
import urllib.request,json,hashlib,subprocess,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Hattori_CY_fibrations_review_20261008';S=R/'source_material/Hattori_CY_fibrations_sources_20261008';out=C/'journal_acquisition_v1_20261008.json';p=S/'Hattori_CY_fibrations_journal_VoR_response';assert not out.exists() and not p.exists()
url='https://www.cambridge.org/core/services/aop-cambridge-core/content/view/S1474748024000598'
try:
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Scholarly-source-review/1.0'}),timeout=30) as r:data=r.read();status=r.status;resolved=r.url;mime=r.headers.get('Content-Type')
 p.write_bytes(data);source=dict(path=str(p),URL=url,resolved_URL=resolved,HTTP_status=status,content_type=mime,bytes=len(data),SHA256=hashlib.sha256(data).hexdigest())
 if data.startswith(b'%PDF'):
  pdf=p.with_suffix('.pdf');assert not pdf.exists();p.rename(pdf);source['path']=str(pdf)
  with fitz.open(pdf) as d:source['physical_pages']=len(d)
  txt=pdf.with_suffix('.txt');assert not txt.exists();x=subprocess.run(['pdftotext','-layout',str(pdf),str(txt)],capture_output=True,text=True);assert x.returncode==0;source['text_path']=str(txt);source['text_SHA256']=hashlib.sha256(txt.read_bytes()).hexdigest();source['text_extraction_stderr']=x.stderr
 obj=dict(status='DONE — journal response acquired; zero reading credit',UTC=datetime.now(timezone.utc).isoformat(),source=source,actual_proof_reading_credit=0,journal_full_text_read=False,helper_source=__file__)
except Exception as e:obj=dict(status='FAILED — no journal reading credit',UTC=datetime.now(timezone.utc).isoformat(),URL=url,error_type=type(e).__name__,error=str(e),actual_proof_reading_credit=0,journal_full_text_read=False,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(obj,ensure_ascii=False))
