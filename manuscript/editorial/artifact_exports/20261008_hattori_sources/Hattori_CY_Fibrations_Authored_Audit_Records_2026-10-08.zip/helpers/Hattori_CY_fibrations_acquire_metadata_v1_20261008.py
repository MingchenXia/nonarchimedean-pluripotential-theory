from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,urllib.request,concurrent.futures,subprocess,xml.etree.ElementTree as ET,re
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Hattori_CY_fibrations_review_20261008';S=R/'source_material/Hattori_CY_fibrations_sources_20261008'
C.mkdir(exist_ok=True);S.mkdir(exist_ok=True);out=C/'metadata_acquisition_v1_20261008.json';assert not out.exists()
def get(item):
 name,url=item;p=S/name;assert not p.exists()
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Scholarly-source-review/1.0'}),timeout=30) as r:data=r.read();status=r.status;resolved=r.url
  p.write_bytes(data);return dict(path=str(p),requested_URL=url,resolved_URL=resolved,HTTP_status=status,bytes=len(data),SHA256=hashlib.sha256(data).hexdigest(),actual_proof_reading_credit=0)
 except Exception as e:return dict(requested_URL=url,error_type=type(e).__name__,error=str(e),actual_proof_reading_credit=0)
items=[('Hattori_CY_fibrations_current_abs.html','https://arxiv.org/abs/2203.11460'),('Hattori_CY_fibrations_API.xml','https://export.arxiv.org/api/query?id_list=2203.11460')]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(get,items))
meta={}
for row in rows:
 if row.get('path','').endswith('.xml'):
  root=ET.parse(row['path']).getroot();ns={'a':'http://www.w3.org/2005/Atom'};entry=root.find('a:entry',ns)
  if entry is not None:meta={k:entry.findtext('a:'+k,namespaces=ns) for k in ['id','updated','published','title','summary']};meta['authors']=[x.findtext('a:name',namespaces=ns) for x in entry.findall('a:author',ns)]
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — metadata only; zero proof-reading credit' if all('path' in x for x in rows) else 'PARTIAL — metadata only',baseline_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),sources=rows,metadata=meta,active_book_changed=False,canonical_status_changes=[],actual_proof_reading_credit=0,helper_source=__file__)
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');print(json.dumps(dict(status=obj['status'],metadata=meta,record_SHA256=hashlib.sha256(out.read_bytes()).hexdigest()),ensure_ascii=False))
