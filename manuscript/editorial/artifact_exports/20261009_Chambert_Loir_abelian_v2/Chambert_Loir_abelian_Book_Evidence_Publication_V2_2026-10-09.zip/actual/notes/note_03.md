# Translated abelian staged book — actual reading 3

Read the complete selected text and displayed matching rendered image for physical pages 1852–1853. The abelian computation is complete: the fibre-line normalization gives the point-height identity, translated torsion gives both minima, the sole nonzero mixed arithmetic term has coefficient -2/g, and the full power visibly includes binomial(g+1,2). Division by (g+1)(T^g) gives the same -h_q.

Flat Picard-zero curvature, complex Haar probability and the constant approximation with inradius one and zero defect are stated coherently. The source citation resolves as CL00. Existing necessity/logarithmic-test questions and the transition to the chapter's notes remain separate and readable. The note continuation and historical source references fit cleanly. No equation clipping, symbol error or mathematical repair is found.
