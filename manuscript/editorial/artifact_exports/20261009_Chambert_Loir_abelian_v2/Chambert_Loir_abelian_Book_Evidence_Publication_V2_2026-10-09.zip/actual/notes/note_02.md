# Translated abelian staged book — actual reading 2

Read the complete selected text and displayed matching rendered image for physical pages 1850–1851. The quadratic wide-roof example and the full Fubini–Study calculation remain readable, including ordinary-norm height, squared-norm curvature and the strict normalized Zhang inequality.

The new abelian paragraph begins after the Fubini–Study conclusion and explicitly changes the variety to B/Q with canonically rigidified ample symmetric L and rational q. Its definition of T retains the constant metrized fibre line and R=T-L. The displayed definition is complete at the page end; its explanation continues on the next page. The circle-curvature distinction and BJ22 warning remain explicit. No typesetting repair is needed.
