# Translated abelian staged book — actual reading 5

Read the complete selected text and displayed matching rendered image for physical pages 4427–4428. Page 4427 contains the complete translated-abelian provenance paragraph. It states the published Theorem 2.5 locator and full proof, all 34 source pages/17 matching displays, canonical rigidification, constant fibre line, binomial coefficient and normalized denominator. It identifies the torsion argument as a direct classical consequence and imports no general nonsplit assertion.

The paragraph is complete, with no dangling final line. Page 4428 is an intentional blank verso before the next appendix's recto opening; it was individually displayed and reviewed and must be recorded as a blank, not omitted from the actual-page list. No mathematical or typesetting repair is needed. The running numbered-section header is inherited from the appendix's existing supplementary-paragraph layout.
