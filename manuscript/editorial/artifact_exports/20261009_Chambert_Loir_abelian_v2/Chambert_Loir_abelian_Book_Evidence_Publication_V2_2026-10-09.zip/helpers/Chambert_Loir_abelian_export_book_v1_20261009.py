from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, zipfile, shutil, fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory'); E=R/'manuscript/editorial'
C=R/'source_material/Chambert_Loir_abelian_book_integration_20261009'
K=R/'source_material/Xue_semiabelian_review_20261009/dependencies_v1/ChambertLoir00Published'
S=Path('/workspace/book-completion-drafts/Chambert-Loir-abelian-staging-v1-20261009')
D=Path('/workspace/book-completion-drafts/Chambert-Loir-abelian-integration-v1-20261009')
W=Path('/tmp/Chambert_Loir_abelian_staged_book_views_v1_20261009')
O=Path('/workspace/book-completion-drafts/research-integration')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda n:json.loads((C/n).read_text())
def write(p,a):
    assert not p.exists()
    p.write_text(json.dumps(a,ensure_ascii=False,indent=2)+'\n')
prep=load('book_staging_preparation_v1_20261009.json'); release=load('book_release_checks_v1_20261009.json')
reading=load('actual_book_reading_v1_20261009.json'); math=load('book_mathematical_self_audit_v1_20261009.json')
validation=load('book_validation_v1_20261009.json'); under=load('book_underfull_delta_v1_20261009.json')
assert validation['returncode']==0 and under['all_normalized_blocks_and_multiplicities_identical']
assert reading['actual_unique_book_pages']==14 and reading['fresh_matching_views']==7 and reading['reused_matching_views']==0
assert not reading['remaining_repairs'] and reading['explicitly_reviewed_blank_versos']==[4428]
assert release['PDF']['physical_pages']==4679 and release['PDF']['SHA256']==reading['PDF']['SHA256']
assert math['actual_final_book_reading_SHA256']==sha(C/'actual_book_reading_v1_20261009.json')
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['before'].items():assert sha(R/n)==h
assert sha(R/'manuscript/book.pdf')==prep['active_book_PDF_SHA256']
paths={k:E/f'Chambert_Loir_abelian_staged_integration_{k}_v1_20261009.{ext}' for k,ext in [('audit','md'),('reading_notes','md'),('manifest','json'),('artifacts','json')]}
full=O/'Non-Archimedean_Pluripotential_Theory_Translated_Abelian_V1_2026-10-09.pdf'
review=O/'Chambert_Loir_Translated_Abelian_Actual_Book_Review_V1_2026-10-09.pdf'
minimal=O/'Chambert_Loir_Translated_Abelian_Minimal_Source_V1_2026-10-09.zip'
evidence=O/'Chambert_Loir_Translated_Abelian_Book_Evidence_V1_2026-10-09.zip'
dest=E/'artifact_exports/20261009_Chambert_Loir_abelian_v1'; record=C/'book_export_v1_20261009.json'
assert not any(p.exists() for p in [*paths.values(),full,review,minimal,evidence,dest,record])
shutil.copyfile(release['PDF']['path'],full); assert sha(full)==release['PDF']['SHA256']
with fitz.open(full) as source:
    doc=fitz.open()
    for n in reading['actual_book_physical_pages']:doc.insert_pdf(source,from_page=n-1,to_page=n-1)
    assert len(doc)==14
    doc.set_metadata(dict(title='Translated abelian canonical height — actual book review',subject='Fourteen final physical pages actually read in seven fresh displays, including intentional blank verso 4428. Export grants no reading credit.'))
    doc.save(review,garbage=4,deflate=True); doc.close()
summary='''The checked 4,679-page edition adds a classical translated-abelian
worked case to Chapter 27 and its published-source provenance to Appendix L.
For an abelian B/Q, ample symmetric canonically rigidified L and rational q,
subtract the metrized fibre L|q from t_q*L. With h_q the canonical height,
both minima and the normalized self-intersection are -h_q. The source
mixed coefficient -2/g receives binomial(g+1,2) in the full arithmetic
power, giving -(g+1)(L^g)h_q before normalization. Flat Picard-zero metrics
preserve complex curvature; its normalized top measure is Haar. Constant
approximation has zero defect and inradius one, so the already imported
Ballaÿ–Sombra criterion gives the original curvature measure. This equality
case complements the preceding strict Fubini–Study case. Ordinary-norm
heights and squared-norm Chern curvature remain separate.

The published Chambert–Loir source was actually read in all 34 physical
pages and 17 matching complete-text/image displays. Theorem 2.5 and its
whole proof are pinned to article pages 798–799 / physical pages 11–12.
Six exact dimension calibrations check mixed, full and normalized values.
No general nonsplit extension, point-attainment clause, original theorem
or independent production-verifier receipt is imported. The arithmetic
base and rational translation are explicit to keep place normalization.

All fourteen selected final pages were actually read in seven fresh
matching displays: the chapter seams and worked case, complete provenance,
intentional blank verso 4428 and following appendix opening, two contents
pages, first/last index pages and complete CL00 reference. The other ten
index pages were mechanically compared. This is a scoped read; the last
ordered whole-book reading remains 4 October. Export/upload adds no credit.

Required validation and six existing reference-check tests pass. Final
output has zero errors, missing glyphs, overfull boxes, unresolved references
or citations, package/pdfTeX warnings or rerun requests. All 955 inherited
underfull blocks retain normalized content and multiplicities. All 13,382
earlier numbered values, 603 cited keys/labels, 2,766 contents titles/hierarchy
and 900 index terms remain; the CL00 shorthand gives 604 citations. All
internal destinations resolve. Two core TeX inputs and the NA bibliography
change; the other 423 core TeX inputs and complex bibliography are identical.
No formal environment, semantic label, manual tag or contents title is added.

Canonical inventory stays 42 atoms/twelve problems and tiers (0,3,7,15,17).
BJ22 homogeneous Siu/envelopes stay OPEN and LPWZ density UNVERIFIED.
The incoming P12.3 candidate and toric attainment candidate remain unverified.
The native catalogue/editor and historical PDF are preserved; its native
compilation remains unverified. Activation and GitHub publication are
separate records. Work continues in the cloud with Xean suspended.
'''
paths['audit'].write_text('# Translated abelian canonical-height book integration, 9 October 2026\n\n'+summary+'\nScoped mathematical checks:\n\n'+''.join(f'{i}. {x}\n\n' for i,x in enumerate(math['scope_checks'],1)))
notes=[]
for item in reading['receipts']:
    n=item['number']; note=C/f'book_notes_v1/note_{n:02d}.md'; receipt=C/f'book_notes_v1/note_{n:02d}_receipt.json'
    assert sha(note)==item['note_SHA256'] and sha(receipt)==item['receipt_SHA256']
    notes.append(note.read_text())
paths['reading_notes'].write_text('# Actual final translated-abelian book reading\n\nFourteen selected final pages in seven fresh displays; intentional verso 4428 included.\n'+''.join('\n---\n\n'+x for x in notes))
programme='manuscript/editorial/second_reading_and_research_programme_20261002.md'
intro='''**Current checked edition: 4,679 pages, 9 October 2026.**
The [translated-abelian integration audit](manuscript/editorial/Chambert_Loir_abelian_staged_integration_audit_v1_20261009.md)
adds the canonical equality case to Chapter 27 beside the strict Fubini–Study
example. It keeps the rational translation, fibre constant, binomial factor
and normalized height explicit; Appendix L pins the full published proof.
All fourteen selected final pages were read in seven fresh displays,
including one intentional blank verso. Required checks and compilation pass.
All prior numbered values, citations, contents and index terms remain.
The [artifacts](manuscript/editorial/artifact_exports/20261009_Chambert_Loir_abelian_v1/README.md)
contain the full book, actual review, minimal source and authored evidence.
The last complete ordered book reading remains 4 October. Canonical open
problem statuses and the native catalogue/editor remain unchanged.

'''
p=S/'README.md'; s=p.read_text(); marker='**Latest verified arithmetic-example GitHub publication, 9 October 2026:**'
assert s.count(marker)==1; p.write_text(s.replace(marker,intro+marker,1))
intro='''## Current checked translated-abelian edition: 4,679 pages, 9 October 2026

The [integration audit](Chambert_Loir_abelian_staged_integration_audit_v1_20261009.md)
records the canonical equality case in Chapter 27. For rational q over Q,
the translated bundle minus its fibre constant has both minima and normalized
arithmetic height -h_q. Theorem 2.5's mixed term receives binomial(g+1,2)
in the full power. Flat Picard-zero curvature is unchanged; zero-defect
constant approximation yields the original normalized measure. The published
34-page source and complete proof are separately pinned. No original result
or independent production-verifier receipt is introduced.

All fourteen final selected pages were actually read in seven fresh views,
including intentional blank verso 4428. Required validation and six existing
tests pass. All 13,382 earlier numbered values, 603 cited labels, 2,766 contents
titles/hierarchy and 900 index terms remain; CL00 gives 604 citations. All
destinations resolve and the 955 inherited underfull diagnostics are unchanged.
Other 423 core TeX inputs and the complex bibliography are identical.

See the [artifacts](artifact_exports/20261009_Chambert_Loir_abelian_v1/README.md).
The last ordered whole-book reading remains 4 October; this increment is a
scoped final-PDF read. Earlier reports and evidence are historical and frozen.
The incoming continuation302 P12.3 core and whole qualified G331 have a separate
scoped audit; no exact-current independent receipt, so P12.2/P12.3 remain OPEN.
BJ22 general homogeneous Siu/envelopes remain OPEN, LPWZ density UNVERIFIED,
and the native catalogue/editor is preserved with compilation unverified.
Continue cloud-only. Hultberg's GVF gap-principle arXiv:2601.04972v1 is being
read: only its first two of 43 pages are actually read at this checkpoint.
No claims from its unread proof are integrated. Xean stays suspended.

'''
p=S/programme; s=p.read_text(); first=s.index('\n'); p.write_text(s[:first+1]+'\n'+intro+s[first+1:])
with zipfile.ZipFile(prep['baseline_minimal_source']['path']) as old,zipfile.ZipFile(minimal,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    members=old.namelist(); assert len(members)==len(set(members))==472
    for n in members:z.write(S/n,n)
with zipfile.ZipFile(minimal) as z:
    assert z.testzip() is None
    for n in z.namelist():assert z.read(n)==(S/n).read_bytes()
files={f'records/{q.name}':q for q in C.glob('*.json')}
q=C/'book_validation_v1_20261009.log'; files[f'logs/{q.name}']=q
for n in prep['after']:files['staged_inputs/'+n]=S/n
for q in D.iterdir():
    assert q.suffix=='.tex'; files['drafts/'+q.name]=q
for q in (C/'book_compiled_staged_v1').iterdir():
    if q.suffix!='.pdf':files['compiled/'+q.name]=q
for item in reading['receipts']:
    n=item['number']
    for kind,q in [('notes',C/f'book_notes_v1/note_{n:02d}.md'),('receipts',C/f'book_notes_v1/note_{n:02d}_receipt.json'),('images',W/f'sheet_{n:02d}.png'),('text',W/f'sheet_{n:02d}.txt')]:files[f'actual/{kind}/{q.name}']=q
files['actual/prepared_manifest.json']=W/'manifest.json'
for q in Path('/tmp').glob('Chambert_Loir_abelian_*_v1_20261009.py'):files['helpers/'+q.name]=q
for q in [paths['audit'],paths['reading_notes'],S/programme,S/'README.md']:files['editorial/'+q.name]=q
sourcezip=E/'artifact_exports/20261009_Chambert_Loir_complete_v1/Chambert_Loir_Complete_Actual_Reading_Evidence_V1_2026-10-09.zip'
assert sha(sourcezip)=='a6550036efb7887dbd9ef7e55f95e38c0b555a8b618f9140fad6f4b43558e000'
files['source_owned_records/'+sourcezip.name]=sourcezip
for n in ['actual_source_checkpoint_v1_20261009.json','GitHub_complete_publication_v1_20261009.json','GitHub_complete_documentation_v1_20261009.json']:files['source_owned_records/'+n]=K/n
with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for n,q in sorted(files.items()):z.write(q,n)
with zipfile.ZipFile(evidence) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(files) and z.testzip() is None
    for n,q in files.items():assert z.read(n)==q.read_bytes()
artifacts={k:dict(path=str(q),bytes=q.stat().st_size,SHA256=sha(q)) for k,q in [('full_book_PDF',full),('selected_review_PDF',review),('minimal_TeX_source_archive',minimal),('actual_book_evidence_archive',evidence)]}
artifacts['full_book_PDF']['physical_pages']=4679; artifacts['selected_review_PDF']['physical_pages']=14
artifacts['minimal_TeX_source_archive']['members']=472; artifacts['actual_book_evidence_archive']['members']=len(files)
progress={n:sha(S/n) for n in ['README.md',programme]}
write(paths['manifest'],dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — scoped source/math/mechanical/actual-render gate',preparation=prep,release=release,validation=validation,actual_reading=reading,mathematical_audit=math,underfull_comparison=under,artifacts=artifacts,active_book_changed=False,GitHub_published=False))
write(paths['artifacts'],dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — all export members byte-verified',artifacts=artifacts,actual_final_book_pages=14,fresh_matching_views=7,explicitly_reviewed_blank_versos=[4428],reading_credit_from_export=0,GitHub_published=False))
dest.mkdir(parents=True)
for q in [full,review,minimal,evidence]:shutil.copyfile(q,dest/q.name); assert sha(dest/q.name)==sha(q)
(dest/'SHA256SUMS').write_text(''.join(sha(q)+'  '+q.name+'\n' for q in [full,review,minimal,evidence]))
(dest/'README.md').write_text('# Translated abelian canonical-height book artifacts\n\n'+summary+f'\nArtifacts: full 4,679-page PDF, 14-page actual review, 472-member minimal\nsource and {len(files)}-member byte-verified authored evidence. Primary PDFs\nand literal full-source images/text are excluded from redistribution.\n')
editorial={str(p.relative_to(R)):dict(bytes=p.stat().st_size,SHA256=sha(p)) for p in paths.values()}
for p in dest.iterdir():editorial[str(p.relative_to(R))]=dict(bytes=p.stat().st_size,SHA256=sha(p))
write(record,dict(UTC=datetime.now(timezone.utc).isoformat(),status='DONE — final translated-abelian book/evidence export',artifacts=artifacts,editorial_files=editorial,progress_document_hashes=progress,actual_final_book_pages=14,actual_final_matching_views=7,reused_matching_views=0,explicitly_reviewed_blank_versos=[4428],active_book_changed=False,GitHub_published=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__)))
print(json.dumps(dict(status='EXPORTED',record_SHA256=sha(record),evidence_members=len(files),artifacts=artifacts)))
