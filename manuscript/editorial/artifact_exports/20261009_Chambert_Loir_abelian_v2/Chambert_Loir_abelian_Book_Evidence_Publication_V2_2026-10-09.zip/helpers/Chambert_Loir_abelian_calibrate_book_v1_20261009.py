from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,sympy as s
R=Path('/workspace/nonarchimedean-pluripotential-theory')
C=R/'source_material/Chambert_Loir_abelian_book_integration_20261009'
K=R/'source_material/Xue_semiabelian_review_20261009/dependencies_v1/ChambertLoir00Published'
D=Path('/workspace/book-completion-drafts/Chambert-Loir-abelian-integration-v1-20261009')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not C.exists();C.mkdir()
cp=K/'actual_source_checkpoint_v1_20261009.json';c=json.loads(cp.read_text())
assert c['actual_pages']==list(range(1,35)) and c['whole_source_read'] and not c['production_VERIFIED']
pub=K/'GitHub_complete_publication_v1_20261009.json';p=json.loads(pub.read_text());assert p['actual_Chambert_Loir_pages']==34
g=s.symbols('g',integer=True,positive=True);degree,h=s.symbols('degree h',positive=True)
mixed=-2*degree*h/g;full=s.simplify(g*(g+1)/2*mixed)
normalized=s.simplify(full/((g+1)*degree));assert normalized==-h
checks=[dict(g=n,mixed=str(mixed.subs(g,n)),binomial=int(s.binomial(n+1,2)),full=str(full.subs(g,n)),normalized=str(normalized)) for n in range(1,7)]
obj=dict(UTC=datetime.now(timezone.utc).isoformat(),status='PASS — imported classical example and direct formal consequences',signature='Abelian B/Q of dimension g>=1; ample symmetric canonically rigidified L; rational q; translated T=t_q*L minus pulled-back metrized fibre L|q; ordinary-norm heights and squared-norm complex Chern curvature',source_checkpoint_SHA256=sha(cp),source_publication_SHA256=sha(pub),actual_source_pages=34,actual_source_displays=17,primary_locator='Theorem 2.5 and complete proof, article 798–799 / physical 11–12; rigidified translation identity in Corollary 2.2, article 796–797',actual_primary_notes=[dict(note=n,SHA256=sha(K/'primary_notes_v1'/('note_%02d.md'%n)),receipt_SHA256=sha(K/'primary_notes_v1'/('note_%02d_receipt.json'%n))) for n in [5,6]],checks=checks,essential_and_absolute_minimum='-hhat_L(q), from nonnegative canonical height and generic translated torsion',semipositivity='Translation preserves local semipositivity and a constant metrized line does not change it; geometric T is ample',complex_curvature='Canonical Picard-zero R is flat; normalized c1(T)^g equals normalized c1(L)^g and complex Haar',approximation='constant Q=T, remainder zero, r(T;T)=1, essential-to-absolute defect zero; apply already-read Ballay–Sombra Theorem 6.9',field_normalization='Q base avoids unnormalized source field-degree discrepancy; algebraic point heights use the book weighted product formula',source_normalized_height='raw full power / [(g+1)(T^g)]',raw_formula=str(full),normalized_formula=str(normalized),draft_fragments={x.name:sha(x) for x in sorted(D.iterdir())},frozen_source_audits_rewritten=False,original_result_promoted=False,independent_verifier_receipt=False,book_changed=False,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__))
out=C/'normalization_calibration_v1_20261009.json';assert not out.exists()
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(status='PASS',checks=len(checks),normalized=str(normalized),SHA256=sha(out))))
