from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,fitz
R=Path('/workspace/nonarchimedean-pluripotential-theory');C=R/'source_material/Chambert_Loir_abelian_book_integration_20261009'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();now=lambda:datetime.now(timezone.utc).isoformat()
prep=json.loads((C/'book_staging_preparation_v1_20261009.json').read_text())
release=json.loads((C/'book_release_checks_v1_20261009.json').read_text())
vp=C/'book_validation_v1_20261009.json';validation=json.loads(vp.read_text());assert validation['returncode']==0
under=C/'book_underfull_delta_v1_20261009.json';u=json.loads(under.read_text());assert u['all_normalized_blocks_and_multiplicities_identical']
S=Path(prep['stage_path']);pdf=Path(release['PDF']['path']);assert sha(pdf)==release['PDF']['SHA256']==validation['compiled_PDF']['SHA256']
views=json.loads(Path(release['manifest_path']).read_text());assert len(views)==7
N=C/'book_notes_v1';pages=[];receipts=[];previous=None
for n,x in enumerate(views,1):
    p=N/('note_%02d.md'%n);q=N/('note_%02d_receipt.json'%n);d=json.loads(q.read_text())
    assert d['number']==x['number']==n and d['physical_pages']==x['physical_pages']
    assert d['source_PDF_SHA256']==sha(pdf) and d['note_SHA256']==sha(p)
    assert d['complete_selected_text_actually_read'] and d['matching_image_individually_displayed_and_reviewed']
    assert d['image_SHA256']==sha(x['path']) and d['selected_text_SHA256']==sha(x['selected_text_path'])
    assert d['previous_receipt_SHA256']==previous;previous=sha(q);pages+=d['physical_pages']
    receipts.append(dict(number=n,physical_pages=x['physical_pages'],note_SHA256=sha(p),receipt_SHA256=sha(q)))
assert pages==release['selected_book_physical_pages'] and len(set(pages))==14
with fitz.open(pdf) as doc:
    assert len(doc)==4679
    blanks=[n for n in pages if not doc[n-1].get_text().strip()];assert blanks==[4428]
for n,h in prep['after'].items():assert sha(S/n)==h
for n,h in prep['before'].items():assert sha(R/n)==h
for n,h in prep['other_active_TeX_preserved'].items():assert sha(R/n)==sha(S/n)==h
for n,h in prep['native_catalogue_preserved'].items():assert sha(R/n)==h
out=C/'actual_book_reading_v1_20261009.json';assert not out.exists()
obj=dict(UTC=now(),status='DONE — actual scoped final-book reading, no repairs outstanding',PDF=release['PDF'],actual_book_physical_pages=pages,actual_unique_book_pages=14,fresh_matching_views=7,reused_matching_views=0,receipts=receipts,explicitly_reviewed_blank_versos=blanks,blank_justification='Intentional verso before Appendix M recto opening; complete preceding provenance paragraph',remaining_repairs=[],actual_primary_source_reading_credit=0,whole_book_new_reading_claim=False,whole_chapter_reading_claim=False,index_actual_pages=[4637,4648],middle_index_pages_mechanical_only=True,release_checks_SHA256=sha(C/'book_release_checks_v1_20261009.json'),validation_SHA256=sha(vp),underfull_comparison_SHA256=sha(under),active_book_changed=False,canonical_status_changes=[],original_results_promoted=[],helper_source=__file__,helper_SHA256=sha(__file__))
out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
cal=C/'normalization_calibration_v1_20261009.json';c=json.loads(cal.read_text())
draft=Path(prep['draft_path'])
assert (draft/'ch27_translated_abelian_fragment.tex').read_text().strip() in (S/'manuscript/parts/part3/ch27_differentiability.tex').read_text()
assert (draft/'appL_translated_abelian_fragment.tex').read_text().strip() in (S/'manuscript/appendices/appL_provenance.tex').read_text()
assert c['normalized_formula']=='-h' and not c['original_result_promoted']
audit=C/'book_mathematical_self_audit_v1_20261009.json';assert not audit.exists()
audit.write_text(json.dumps(dict(UTC=now(),status='PASS — ordinary source/math audit of an imported classical worked case',actual_final_book_reading_SHA256=sha(out),normalization_calibration_SHA256=sha(cal),current_source_hashes=prep['after'],signature=c['signature'],scope_checks=['Q base and rational translation retain normalized place convention','Canonically rigidified ample symmetric L has nonnegative canonical point height','Generic torsion translates attain both essential and absolute minimum','The constant fibre line contributes exactly h_q','Theorem 2.5 mixed coefficient receives binomial(g+1,2) in the full power','Arithmetic normalization divides by (g+1)(T^g)','Translation and constant shifts preserve local semipositivity; T is geometrically ample','Flat Picard-zero complex metric preserves curvature; top probability is Haar','Constant approximation has zero defect, r(T;T)=1 and zero remainder','The h_q=0 torsion boundary gives zero raw/normalized heights; g=1 has binomial factor one','No general nonsplit equidistribution or unverified attainment clause is imported'],deeper_imports_recursively_verified=False,production_VERIFIED=False,independent_verifier_receipt=False,original_result_promoted=False,canonical_status_changes=[],native_editor_changed=False,native_compile_success_verified=False,helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(actual_pages=14,matching_views=7,blank_versos=blanks,reading_SHA256=sha(out),math_audit_SHA256=sha(audit))))
