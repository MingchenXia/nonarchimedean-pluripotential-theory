from pathlib import Path
from datetime import datetime,timezone
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,subprocess,base64,time
R=Path('/workspace/nonarchimedean-pluripotential-theory');E=R/'manuscript/editorial'
C=R/'source_material/Chambert_Loir_abelian_book_integration_20261009'
K=R/'source_material/Xue_semiabelian_review_20261009/dependencies_v1/ChambertLoir00Published'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();now=lambda:datetime.now(timezone.utc).isoformat()
repo='repos/MingchenXia/nonarchimedean-pluripotential-theory/'
def api(ep):
    for attempt in range(3):
        result=subprocess.run(['gh','api',repo+ep],cwd=R,text=True,capture_output=True)
        if result.returncode==0:return json.loads(result.stdout)
        if attempt<2:time.sleep(attempt+1)
    raise RuntimeError('GitHub read failed after three attempts: '+ep+'; '+result.stderr[:500])
git=lambda *a:subprocess.check_output(['git',*a],cwd=R,text=True).strip()
def commit_owned(files,message,parent,record_name):
    paths=[x['path'] for x in files];assert len(paths)==len(set(paths))
    for x in files:assert sha(R/x['path'])==x['SHA256'] and (R/x['path']).stat().st_size==x['bytes']
    assert git('rev-parse','HEAD')==parent and not git('diff','--cached','--name-only')
    subprocess.run(['git','add','--',*paths],cwd=R,check=True)
    assert set(git('diff','--cached','--name-only').splitlines())==set(paths)
    subprocess.run(['git','diff','--cached','--check'],cwd=R,check=True)
    subprocess.run(['git','commit','-m',message],cwd=R,check=True)
    head=git('rev-parse','HEAD');assert set(git('diff-tree','--no-commit-id','--name-only','-r',head).splitlines())==set(paths)
    out=C/record_name;assert not out.exists()
    out.write_text(json.dumps(dict(UTC=now(),status='COMMITTED LOCALLY — remote verification pending',commit=head,parent=parent,files=files,helper_source=__file__,helper_SHA256=sha(__file__)),indent=2)+'\n')
    return head
def push_verify(head,files,push=True):
    if push:subprocess.run(['git','-c','credential.helper=!gh auth git-credential','push','origin','work'],cwd=R,check=True)
    assert api('branches/work')['commit']['sha']==head
    tree=api('git/trees/'+head+'?recursive=1');assert not tree['truncated']
    mapping={x['path']:x for x in tree['tree'] if x['type']=='blob'}
    def check(x):
        p=R/x['path'];blob=mapping[x['path']]['sha']
        assert blob==git('hash-object',str(p)) and mapping[x['path']]['size']==x['bytes']
        d=api('git/blobs/'+blob);assert d['encoding']=='base64'
        payload=base64.b64decode(d['content'])
        assert payload==p.read_bytes() and len(payload)==x['bytes'] and hashlib.sha256(payload).hexdigest()==x['SHA256']
        return dict(**x,remote_Git_blob_SHA1=blob,remote_blob_payload_byte_verified=True)
    with ThreadPoolExecutor(max_workers=4) as pool:return list(pool.map(check,files))

activation=E/'Chambert_Loir_abelian_cloud_activation_v1_20261009.json'
a=json.loads(activation.read_text()); e=json.loads((C/'book_export_v1_20261009.json').read_text())
owned=dict(a['after_source_hashes']); owned.update({n:x['SHA256'] for n,x in e['editorial_files'].items()})
owned[str(activation.relative_to(R))]=sha(activation); assert len(owned)==16
files=[dict(path=n,SHA256=h,bytes=(R/n).stat().st_size) for n,h in owned.items()]
parent='692943c6c94f10552355fe36af0a3935adb31c0b'
assert git('rev-parse','HEAD')==api('branches/work')['commit']['sha']==parent
assert api('branches/main')['commit']['sha']=='00957114db21b627e97369563032ceda9cea09c7'
pr=api('pulls/2'); assert pr['state']=='open' and pr['draft'] and pr['head']['sha']==parent
assert pr['body']==Path('/tmp/P12_3_incoming_PR2_body_v1_20261009.md').read_text()
head=commit_owned(files,'Add checked translated abelian height equality case and book evidence',parent,'local_book_commit_v1_20261009.json')
verified=push_verify(head,files); main=api('branches/main')['commit']['sha']; pr=api('pulls/2')
assert pr['state']=='open' and pr['draft'] and pr['head']['sha']==head
title='Complete book second reading and checked research integrations through 4,679 pages'
bp=Path('/tmp/Chambert_Loir_abelian_PR2_body_v1_20261009.md'); body=bp.read_text()
payload=Path('/tmp/Chambert_Loir_abelian_PR2_payload_v1_20261009.json'); assert not payload.exists()
payload.write_text(json.dumps(dict(title=title,body=body),ensure_ascii=False)+'\n')
updated=json.loads(subprocess.run(['gh','api','--method','PATCH',repo+'pulls/2','--input',str(payload)],cwd=R,text=True,capture_output=True,check=True).stdout)
assert updated['body']==body and updated['title']==title and updated['head']['sha']==head and updated['state']=='open' and updated['draft']
obj=dict(UTC=now(),status='REMOTE BYTE VERIFIED — all sixteen book/source/progress/audit/artifact blobs and exact draft PR',commit=head,main_head_at_check=main,files=verified,active_book_PDF=a['active_PDF'],actual_selected_book_pages=14,fresh_matching_views=7,reused_matching_views=0,explicitly_reviewed_blank_versos=[4428],evidence_members=67,minimal_source_members=472,original_source_publication=dict(path=str(K/'GitHub_complete_publication_v1_20261009.json'),SHA256=sha(K/'GitHub_complete_publication_v1_20261009.json'),commit='173818ea12531966e5916bcd8dd6a150913be031'),PR2=dict(URL=pr['html_url'],title=title,body_SHA256=hashlib.sha256(body.encode()).hexdigest(),head=head,open=True,draft=True),user_evidence_upload_authorized=True,original_results_promoted=[],independent_model_receipt=None,general_BJ22_Siu_envelopes='OPEN',LPWZ_density='UNVERIFIED',native_editor_changed=False,native_compile_success_verified=False,native_catalogue_preserved=a['native_catalogue_preserved'],reading_credit_from_upload=0,canonical_status_changes=[],helper_source=__file__,helper_SHA256=sha(__file__))
out=C/'GitHub_book_publication_v1_20261009.json'; pub=E/'Chambert_Loir_abelian_GitHub_publication_v1_20261009.json'
assert not out.exists() and not pub.exists(); out.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n'); pub.write_bytes(out.read_bytes())
p=R/'README.md'; s=p.read_text(); marker='**Current checked edition: 4,679 pages, 9 October 2026.**'; assert s.count(marker)==1
intro='''**Latest verified translated-abelian GitHub publication, 9 October 2026:**
the 4,679-page book and [artifacts](manuscript/editorial/artifact_exports/20261009_Chambert_Loir_abelian_v1/README.md)
are published on work at `'''+head+'''`. All sixteen remote blobs were
downloaded and verified byte-for-byte against local hashes and sizes.
The [publication record](manuscript/editorial/Chambert_Loir_abelian_GitHub_publication_v1_20261009.json)
pins the complete published classical source checkpoint and fourteen final
pages read in seven fresh views, including one intentional blank verso.
Canonical statuses remain unchanged; general BJ22 Siu/envelopes stay OPEN.

'''
p.write_text(s.replace(marker,intro+marker,1))
p=E/'second_reading_and_research_programme_20261002.md'
p.write_text(p.read_text().rstrip()+'\n\nThe sixteen translated-abelian book/source/progress/audit/artifact blobs\nwere downloaded from GitHub and verified byte-for-byte at `'+head+'`.\nSee the [publication record](Chambert_Loir_abelian_GitHub_publication_v1_20261009.json).\nUpload adds no reading credit or theorem clearance.\n')
docs=[dict(path=str(p.relative_to(R)),SHA256=sha(p),bytes=p.stat().st_size) for p in [pub,R/'README.md',E/'second_reading_and_research_programme_20261002.md']]
dochead=commit_owned(docs,'Document verified translated abelian book and evidence publication',head,'local_documentation_commit_v1_20261009.json')
docfiles=push_verify(dochead,docs); latest=api('pulls/2')
assert latest['head']['sha']==dochead and latest['body']==body and latest['title']==title and latest['state']=='open' and latest['draft']
rec=C/'GitHub_documentation_v1_20261009.json'; assert not rec.exists()
rec.write_text(json.dumps(dict(UTC=now(),status='REMOTE BYTE VERIFIED — all three documentation files and exact draft PR',commit=dochead,parent=head,files=docfiles,PR2=dict(URL=latest['html_url'],head=dochead,title=title,body_SHA256=hashlib.sha256(body.encode()).hexdigest(),open=True,draft=True),book_PDF_SHA256=a['active_PDF']['SHA256'],book_pages=4679,new_reading_credit=0,original_results_promoted=[],helper_source=__file__,helper_SHA256=sha(__file__)),ensure_ascii=False,indent=2)+'\n')
print(json.dumps(dict(book_commit=head,book_files_byte_verified=16,documentation_commit=dochead,documentation_files_byte_verified=3,main_head=main,publication_SHA256=sha(pub),documentation_record_SHA256=sha(rec))))

