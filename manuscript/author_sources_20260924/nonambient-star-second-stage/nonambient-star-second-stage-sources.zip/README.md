# A second-stage obstruction on a nonambient affine tropical star

This folder contains a paper about P07.1 in `unresolved_problems.pdf`. It constructs a compact affine G-tropical space with a bounded continuous second-stage CLD psh function whose node germ is not first-stage. The paper does not construct a Berkovich analytic space with this restricted affinage and does not resolve that stricter analytic-space version.

## Sources

- `nonambient-star-second-stage.tex`: manuscript source.
- `cgeometry.sty`: required house style.
- `ComplexGeometry.bib`: one project-local bibliography database, retaining one `Stacks` entry.
- `xean-runtime.patch`: exact diff from the base Xean commit to the isolated runtime commit.

## Rebuild

Run `latexmk -pdf -interaction=nonstopmode -halt-on-error nonambient-star-second-stage.tex` in this folder. The build uses BibLaTeX/Biber through `latexmk`.

## Research provenance

- Source problem PDF SHA-256: `bd44ed9ce92fa04aeabdef8d104d7c9429b16336aa6cb7315365215de1f2c539`.
- Xean runtime commit: `a353ec7c005e170954c74fb59df34fa62b104088`.
- Xean base worktree commit: `e70849cb37c0b5931221f6e0b9f7aeda7efe3cde`.
- Bun dependency lockfile SHA-256: `94d10a9c5b4ba279383314446a13e036a65ffa7df34838fb2fe73934280a6b56`.
- Campaign database: `/Users/mingchen/Projects/Xean/runs/p07-first-stage/campaign.db`.

As of 24 September 2026 (Asia/Shanghai), Xean note `n75` passed correctness and source verification over the verified source and site notes `n35`, `n36`, `n56`, `n72`, and `n74`. The verification covers the affine G-tropical result as stated, not the analytic-space completion criterion of that campaign. The companion positive paper is in `../cld-first-stage-good-analytic/`.
