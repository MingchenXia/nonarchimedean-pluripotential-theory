# Zero-Hessian rigidity on non-Archimedean polycylinders

This folder contains an independent proof for the polycylinder case of P21.3 in `unresolved_problems.pdf`. The problem inventory already records fixed-domain strict polycylinder pairs among its established positive cases. Over a complete algebraically closed nontrivially valued field, a continuous function with zero ordinary CLD Hessian on a full product of open disks and annuli is affine in the annular logarithmic radii. This gives the equal-curvature multiplication identity for positive doubly closed currents on these domains. The general question on arbitrary ordinary opens and ground fields remains outside the theorem.

## Sources

- `zero-hessian-polycylinder-rigidity.tex`: manuscript source.
- `cgeometry.sty`: required house style.
- `ComplexGeometry.bib`: one project-local bibliography database, retaining one `Stacks` entry.
- `xean-runtime.patch`: exact diff from the base Xean commit to the isolated runtime commit.

## Rebuild

Run `latexmk -pdf -interaction=nonstopmode -halt-on-error zero-hessian-polycylinder-rigidity.tex` in this folder. The build uses BibLaTeX/Biber through `latexmk`.

## Research provenance

- Source problem PDF SHA-256: `bd44ed9ce92fa04aeabdef8d104d7c9429b16336aa6cb7315365215de1f2c539`.
- Xean runtime commit: `a353ec7c005e170954c74fb59df34fa62b104088`.
- Xean base worktree commit: `e70849cb37c0b5931221f6e0b9f7aeda7efe3cde`.
- Bun dependency lockfile SHA-256: `94d10a9c5b4ba279383314446a13e036a65ffa7df34838fb2fe73934280a6b56`.
- Campaign database: `/Users/mingchen/Projects/Xean/runs/p21-equal-curvature/campaign.db`.

As of 24 September 2026 (Asia/Shanghai), Xean notes `n49`, `n50`, and `n51` passed correctness and source verification. The verification covers the affinoid rational-point lemma, full polyannuli, and products with disk factors. It does not certify the full P21.3 question on general ordinary opens.
