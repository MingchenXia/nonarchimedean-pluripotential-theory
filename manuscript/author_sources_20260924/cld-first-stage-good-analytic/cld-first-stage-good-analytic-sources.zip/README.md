# CLD first-stage collapse on analytic spaces and branching-star products

This folder contains the source and PDF for scope-limited theorems related to P07.1 in `unresolved_problems.pdf`. They prove first-stage collapse for good, topologically separated Berkovich analytic spaces and for the all-node germ of a finite product of CLD stars with arbitrary branch sets. A separate paper in `../nonambient-star-second-stage/` gives a counterexample for a restricted affine G-tropical structure.

## Sources

- `cld-first-stage-good-analytic.tex`: manuscript source.
- `cgeometry.sty`: required house style.
- `ComplexGeometry.bib`: single project-local bibliography database. The Stacks Project, if cited, uses one `Stacks` entry.
- `xean-runtime.patch`: exact source diff from the base Xean commit to the isolated runtime commit used by the campaign.

## Rebuild

Run `latexmk -pdf -interaction=nonstopmode -halt-on-error cld-first-stage-good-analytic.tex` in this folder. The build uses BibLaTeX/Biber via `latexmk`.

## Research provenance

- Source problem PDF SHA-256: `bd44ed9ce92fa04aeabdef8d104d7c9429b16336aa6cb7315365215de1f2c539`.
- Xean runtime commit: `a353ec7c005e170954c74fb59df34fa62b104088`.
- Xean base worktree commit: `e70849cb37c0b5931221f6e0b9f7aeda7efe3cde`.
- Bun dependency lockfile SHA-256: `94d10a9c5b4ba279383314446a13e036a65ffa7df34838fb2fe73934280a6b56`.
- Campaign database: `/Users/mingchen/Projects/Xean/runs/p07-first-stage/campaign.db`.

The manuscript identifies the exact source definitions it uses in the 25 July 2025 Chambert--Loir--Ducros revision. Verification outcomes are recorded in the Xean campaign database.

As of 24 September 2026 (Asia/Shanghai), the Xean correctness and source gates passed the good-analytic-space theorem (note `n37`), the finite double-star theorem (note `n50`), and the arbitrary-valence finite star-product theorem (note `n70`). The restricted-affinage second-stage counterexample passed the same gates as note `n75`. It is not a Berkovich analytic-space counterexample.
