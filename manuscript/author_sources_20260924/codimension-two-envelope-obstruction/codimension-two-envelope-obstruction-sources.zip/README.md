# A codimension-two envelope obstruction

This folder contains a scope-limited result related to P03.1 in `unresolved_problems.pdf`. It refutes the proposed sufficiency of normality or geometric unibranchness only in codimension one, even for a geometrically integral, geometrically seminormal strict affinoid surface smooth outside one codimension-two point. It does not classify the everywhere-normal or everywhere-geometrically-unibranch cases.

## Sources

- `codimension-two-envelope-obstruction.tex`: paper source.
- `cgeometry.sty`: required house style.
- `ComplexGeometry.bib`: the single project-local bibliography database, with one `Stacks` entry for all Stacks Project tags.
- `xean-runtime.patch`: source diff from the base Xean commit to the isolated runtime commit used for verification.

## Rebuild

Run `latexmk -pdf -interaction=nonstopmode -halt-on-error codimension-two-envelope-obstruction.tex` in this folder. The build runs BibLaTeX/Biber through `latexmk`.

## Research provenance

- Source problem PDF SHA-256: `bd44ed9ce92fa04aeabdef8d104d7c9429b16336aa6cb7315365215de1f2c539`.
- Xean runtime commit: `a353ec7c005e170954c74fb59df34fa62b104088`.
- Xean base worktree commit: `e70849cb37c0b5931221f6e0b9f7aeda7efe3cde`.
- Bun dependency lockfile SHA-256: `94d10a9c5b4ba279383314446a13e036a65ffa7df34838fb2fe73934280a6b56`.
- Campaign database: `/Users/mingchen/Projects/Xean/runs/p03-classical-envelope/campaign.db`.

As of 24 September 2026 (Asia/Shanghai), Xean note `n17`, supported by the pinched-bidisc construction `n16`, passed correctness, source, requirements, and independent reconstruction checks. These checks cover the counterexample and the scope stated in the paper. The full P03.1 classification remains open.
