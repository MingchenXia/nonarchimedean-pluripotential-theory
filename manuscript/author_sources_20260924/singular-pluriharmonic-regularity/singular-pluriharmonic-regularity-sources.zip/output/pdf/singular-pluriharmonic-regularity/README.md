# Real piecewise linearity of pluriharmonic functions on singular Berkovich spaces

The paper is `singular-pluriharmonic-regularity.pdf`. Its source is `singular-pluriharmonic-regularity.tex`, built with the project-local `cgeometry.sty` and `ComplexGeometry.bib`.

Build it in this directory with:

```sh
latexmk -pdf -interaction=nonstopmode -halt-on-error singular-pluriharmonic-regularity.tex
```

The manuscript addresses P06.1 in `unresolved_problems.pdf`. Its central descent statements are proved in the manuscript. The cited alteration inputs are Exposé II, Théorème 3.2.1 and Exposé VII, Théorème 1.1 of the single Astérisque 363–364 volume. The Stacks Project has only one bibliography entry, `Stacks`, in `ComplexGeometry.bib`.

The Xean research record is in `runs/p06-pl-singular` at the Xean repository root. The campaign reached `accepted` on note `n87` after correctness, source, requirements, and proof-reconstruction checks. `accepted-argument.txt` is the exported argument, and `campaign.db` holds the complete research and verification record. `manifest.json` gives the exact Xean commit and Bun lockfile SHA-256. `xean-research.bundle` contains that exact isolated Git commit on top of the recorded base commit; `xean-transport.patch` gives a readable diff. `settings.json` records `gpt-6-astra` with `xhigh` reasoning for each role. The second research campaign, for P06.2, is in `runs/p06-zero-hessian`.

To inspect the source code and the accepted campaign from an extracted source archive, start with a clone of `https://github.com/chaoxu/xean` containing the base commit recorded in `manifest.json`. Fetch `runs/p06-pl-singular/xean-research.bundle` into that clone and check out the exact `xeanCommit` from the manifest. Verify the SHA-256 of `bun.lock` against `bunLockSha256` before installing the locked dependencies. The readable source changes are also in `xean-transport.patch`. With Bun installed, the campaign can be inspected without rerunning model calls:

```sh
bun packages/solve/solve.ts inspect /path/to/runs/p06-pl-singular/campaign.db
bun packages/solve/solve.ts export /path/to/runs/p06-pl-singular/campaign.db
```

`task.json` and `settings.json` specify the exact problem and model settings for a fresh run; the archived `campaign.db` is the record of the run that was accepted.
